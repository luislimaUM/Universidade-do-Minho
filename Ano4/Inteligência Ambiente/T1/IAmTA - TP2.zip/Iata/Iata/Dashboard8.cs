﻿using Iveonik.Stemmers;
using Syn.WordNet;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Iata
{
    public partial class Dashboard8 : Form
    {
        private static List<string> items1 = null; //items checkListBox
        private static Dictionary<string, double> keywords = null;
        private static string texto;
        
        //N-GRAM

        public Dashboard8(string text)
        {
            InitializeComponent();
            texto = String.Copy(text);
            keywords = new Dictionary<string, double>();
            IDFKeywords(text);
            addItems();
        }

        public static void IDFKeywords(string text)
        {
            int i;
            /* ----------------- Tokenizer ----------------*/
            List<string> tokens = new List<string>();
            Tokenizer tokenizer = new Tokenizer();
            tokens = tokenizer.Tokenize(text);
            /*------------------ KeyWords -----------------*/
            //Dictionary<string, double> keywords = new Dictionary<string, double>();
            for (i = 0; i < tokens.Count; i++)
            {
                tokens[i] = tokens[i].ToLower(); // All small characters for syntax purposes
                string keyword = tokens[i];

                //if (!keywords.ContainsKey(keyword))
                //keywords.Add(keyword, 1);
                //else keywords[keyword]++;

                /*------------------ IDFKeyWords ----------------*/

                if (!keywords.ContainsKey(keyword))
                    keywords.Add(keyword, 1);
                else keywords[keyword]++;
            }
        }

        public void addItems()
        {
            int i = 1;
            double total = 0;
            var items = keywords.OrderByDescending(pair => pair.Value).
               ToDictionary(pair => pair.Key, pair => pair.Value);
            foreach (KeyValuePair<string, double> pair in items)
            {
                total += pair.Value;
            }

            foreach (KeyValuePair<string, double> pair in items)
            {
                checkedListBox1.Items.Add(pair.Key);
            }

            //1
            if (items.ElementAt(0).Key != null)
            {
                char1.Text = items.ElementAt(0).Key;
                totalCh1.Text = (items.ElementAt(0).Value).ToString();
                progressBar1.Value = Convert.ToInt32((items.ElementAt(0).Value / (double)total) * 100);
                pct1.Text = ((items.ElementAt(0).Value / (double)total) * 100).ToString("F2");
            }
            else
            {
                char1.Text = "-";
                totalCh1.Text = "0";
                progressBar1.Value = 0;
                pct1.Text = "0";
            }
            //2
            char2.Text = items.ElementAt(1).Key;
            totalCh2.Text = (items.ElementAt(1).Value).ToString();
            progressBar2.Value = Convert.ToInt32((items.ElementAt(1).Value / (double)total) * 100);
            pct2.Text = ((items.ElementAt(1).Value / (double)total) * 100).ToString("F2");
            //3
            char3.Text = items.ElementAt(2).Key;
            totalCh3.Text = (items.ElementAt(2).Value).ToString();
            progressBar3.Value = Convert.ToInt32((items.ElementAt(2).Value / (double)total) * 100);
            pct3.Text = ((items.ElementAt(2).Value / (double)total) * 100).ToString("F2");
            //4
            char4.Text = items.ElementAt(3).Key;
            totalCh4.Text = (items.ElementAt(3).Value).ToString();
            progressBar4.Value = Convert.ToInt32((items.ElementAt(3).Value / (double)total) * 100);
            pct4.Text = ((items.ElementAt(3).Value / (double)total) * 100).ToString("F2");
            //5
            char5.Text = items.ElementAt(4).Key;
            totalCh5.Text = (items.ElementAt(4).Value).ToString();
            progressBar5.Value = Convert.ToInt32((items.ElementAt(4).Value / (double)total) * 100);
            pct5.Text = ((items.ElementAt(4).Value / (double)total) * 100).ToString("F2");
            //6
            if (items.ElementAt(5).Key != null)
            {
                char6.Text = items.ElementAt(5).Key;
                totalCh6.Text = (items.ElementAt(5).Value).ToString();
                progressBar6.Value = Convert.ToInt32((items.ElementAt(5).Value / (double)total) * 100);
                pct6.Text = ((items.ElementAt(5).Value / (double)total) * 100).ToString("F2");
            }
            else
            {
                char6.Text = "-";
                totalCh6.Text = "0";
                progressBar6.Value = 0;
                pct6.Text = "0";
            }
            //7
            if (items.ElementAt(6).Key != null)
            {
                char7.Text = items.ElementAt(6).Key;
                totalCh7.Text = (items.ElementAt(6).Value).ToString();
                progressBar7.Value = Convert.ToInt32((items.ElementAt(6).Value / (double)total) * 100);
                pct7.Text = ((items.ElementAt(6).Value / (double)total) * 100).ToString("F2");
            }
            else
            {
                char7.Text = "-";
                totalCh7.Text = "0";
                progressBar7.Value = 0;
                pct7.Text = "0";
            }
            //8
            if (items.ElementAt(7).Key != null)
            {
                char8.Text = items.ElementAt(7).Key;
                totalCh8.Text = (items.ElementAt(7).Value).ToString();
                progressBar8.Value = Convert.ToInt32((items.ElementAt(7).Value / (double)total) * 100);
                pct8.Text = ((items.ElementAt(7).Value / (double)total) * 100).ToString("F2");
            }
            else
            {
                char8.Text = "-";
                totalCh8.Text = "0";
                progressBar8.Value = 0;
                pct8.Text = "0";
            }
            //9
            if (items.ElementAt(8).Key != null)
            {
                char9.Text = items.ElementAt(8).Key;
                totalCh9.Text = (items.ElementAt(8).Value).ToString();
                progressBar9.Value = Convert.ToInt32((items.ElementAt(8).Value / (double)total) * 100);
                pct9.Text = ((items.ElementAt(8).Value / (double)total) * 100).ToString("F2");
            }
            else
            {
                char9.Text = "-";
                totalCh9.Text = "0";
                progressBar9.Value = 0;
                pct9.Text = "0";
            }
            //10
            if (items.ElementAt(9).Key != null)
            {
                char10.Text = items.ElementAt(9).Key;
                totalCh10.Text = (items.ElementAt(9).Value).ToString();
                progressBar10.Value = Convert.ToInt32((items.ElementAt(9).Value / (double)total) * 100);
                pct10.Text = ((items.ElementAt(9).Value / (double)total) * 100).ToString("F2");
            }
            else
            {
                char10.Text = "-";
                totalCh10.Text = "0";
                progressBar10.Value = 0;
                pct10.Text = "0";
            }

        }

        private void Dashboard8_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            items1 = new List<string>();
            items1.Clear();
            foreach (string s in checkedListBox1.CheckedItems)
            {
                items1.Add(s);
            }
            UAnalyzer();
            this.Hide();
            Dashboard10 d10 = new Dashboard10(items1, texto);
            d10.ShowDialog();
        }

        public static void UAnalyzer()
        {
            /*---------------- Uni-Gram Analyser ----------- */

            for (int j = 0; j < items1.Count; j++)
                for (int i = 0; i < keywords.Count; i++)
                    if (keywords.ElementAt(i).Key == items1[j])
                    {
                        string keyword = keywords.ElementAt(i).Key;
                        keywords.Remove(keyword);
                    }

        }

        private void Dashboard8_Load_1(object sender, EventArgs e)
        {

        }

        private void label18_Click(object sender, EventArgs e)
        {

        }

        private void Dashboard8_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Dashboard2 d2 = new Dashboard2();
            d2.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Dashboard9 d9 = new Dashboard9(texto);
            d9.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Dashboard5 d5 = new Dashboard5(texto);
            d5.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Dashboard4 d4 = new Dashboard4(texto);
            d4.ShowDialog();
        }
    }
}
