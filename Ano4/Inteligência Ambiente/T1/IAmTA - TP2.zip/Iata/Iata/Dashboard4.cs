﻿using Iveonik.Stemmers;
using MySql.Data.MySqlClient;
using Syn.WordNet;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Iata
{
    public partial class Dashboard4 : Form
    {   
        //TD-IDF Dashboard
        private static string texto = null;
        private static Dictionary<string, double> keywords_IDF = null;
        private static Dictionary<string, double> keywords_TFIDF = null; // stores keyword - TF-IDFcalc pair
        private static Dictionary<string, double> words = null;
        private static List<string> items1 = null; //items checkListBox

        public Dashboard4(string text)
        {
            InitializeComponent();
            texto = String.Copy(text);
            keywords_IDF = new Dictionary<string, double>();
            keywords_TFIDF = new Dictionary<string, double>();
            IDFKeywords(texto);
            importData();
            execute();
            //print();
            addItems();

        }

        public void IDFKeywords(string text)
        {
            int i;
            /* ----------------- Tokenizer ----------------*/
            List<string> tokens = new List<string>();
            Tokenizer tokenizer = new Tokenizer();
            tokens = tokenizer.Tokenize(text);
            /*------------------ KeyWords -----------------*/
            //Dictionary<string, double> keywords = new Dictionary<string, double>();
            for (i = 0; i < tokens.Count; i++)
            {
                tokens[i] = tokens[i].ToLower(); // All small characters for syntax purposes
                string keyword = tokens[i];

                //if (!keywords.ContainsKey(keyword))
                //keywords.Add(keyword, 1);
                //else keywords[keyword]++;

                /*------------------ IDFKeyWords ----------------*/

                if (!keywords_IDF.ContainsKey(keyword))
                    keywords_IDF.Add(keyword, 1);
                else keywords_IDF[keyword]++;
            }
        }

        private void save()
        {
            int i = 1;
            string constring = "datasource=localhost;port=3306;username=root;password=";
            string Query = "truncate iata.iata;";
            foreach(KeyValuePair<string, double> pair in keywords_TFIDF)
            {
                Query = Query + "insert into iata.iata values ('" + i + "','" + pair.Key + "','" + pair.Value + "') ;";
                i++;
            }
            MySqlConnection conDatabase = new MySqlConnection(constring);
            MySqlCommand cmdDatabase = new MySqlCommand(Query, conDatabase);
            MySqlDataReader myReader;
            try
            {
                conDatabase.Open();
                myReader = cmdDatabase.ExecuteReader();
                MessageBox.Show("Saved");
                while (myReader.Read())
                {
                    
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void addItems()
        {
            int i = 1;
            double total = 0; //total words
            var items = words.OrderByDescending(pair => pair.Value).
               ToDictionary(pair => pair.Key, pair => pair.Value);
            foreach (KeyValuePair<string, double> pair in keywords_TFIDF)
            {
                total += pair.Value;
            }

            foreach (KeyValuePair<string, double> pair in words)
            {
                checkedListBox1.Items.Add(pair.Key);
            }

            //1
            char1.Text = items.ElementAt(0).Key;
            totalCh1.Text = (items.ElementAt(0).Value).ToString();
            progressBar1.Value = Convert.ToInt32((items.ElementAt(0).Value / (double)total) * 100);
            pct1.Text = ((items.ElementAt(0).Value / (double)total) * 100).ToString("F2");
            //2
            char2.Text = items.ElementAt(1).Key;
            totalCh2.Text = (items.ElementAt(1).Value).ToString();
            progressBar2.Value = Convert.ToInt32((items.ElementAt(1).Value / (double)total) * 100);
            pct2.Text = ((items.ElementAt(1).Value / (double)total) * 100).ToString("F2");
            //3
            char3.Text = items.ElementAt(2).Key;
            totalCh3.Text = (items.ElementAt(2).Value).ToString();
            progressBar3.Value = Convert.ToInt32((items.ElementAt(2).Value / (double)total) * 100);
            pct3.Text = ((items.ElementAt(2).Value / (double)total) * 100).ToString("F2");
            //4
            char4.Text = items.ElementAt(3).Key;
            totalCh4.Text = (items.ElementAt(3).Value).ToString();
            progressBar4.Value = Convert.ToInt32((items.ElementAt(3).Value / (double)total) * 100);
            pct4.Text = ((items.ElementAt(3).Value / (double)total) * 100).ToString("F2");
            //5
            char5.Text = items.ElementAt(4).Key;
            totalCh5.Text = (items.ElementAt(4).Value).ToString();
            progressBar5.Value = Convert.ToInt32((items.ElementAt(4).Value / (double)total) * 100);
            pct5.Text = ((items.ElementAt(4).Value / (double)total) * 100).ToString("F2");
            //6
            char6.Text = items.ElementAt(5).Key;
            totalCh6.Text = (items.ElementAt(5).Value).ToString();
            progressBar6.Value = Convert.ToInt32((items.ElementAt(5).Value / (double)total) * 100);
            pct6.Text = ((items.ElementAt(5).Value / (double)total) * 100).ToString("F2");
            //7
            char7.Text = items.ElementAt(6).Key;
            totalCh7.Text = (items.ElementAt(6).Value).ToString();
            progressBar7.Value = Convert.ToInt32((items.ElementAt(6).Value / (double)total) * 100);
            pct7.Text = ((items.ElementAt(6).Value / (double)total) * 100).ToString("F2");
            //8
            char8.Text = items.ElementAt(7).Key;
            totalCh8.Text = (items.ElementAt(7).Value).ToString();
            progressBar8.Value = Convert.ToInt32((items.ElementAt(7).Value / (double)total) * 100);
            pct8.Text = ((items.ElementAt(7).Value / (double)total) * 100).ToString("F2");
            //9
            char9.Text = items.ElementAt(8).Key;
            totalCh9.Text = (items.ElementAt(8).Value).ToString();
            progressBar9.Value = Convert.ToInt32((items.ElementAt(8).Value / (double)total) * 100);
            pct9.Text = ((items.ElementAt(8).Value / (double)total) * 100).ToString("F2");
            //10
            char10.Text = items.ElementAt(9).Key;
            totalCh10.Text = (items.ElementAt(9).Value).ToString();
            progressBar10.Value = Convert.ToInt32((items.ElementAt(9).Value / (double)total) * 100);
            pct10.Text = ((items.ElementAt(9).Value / (double)total) * 100).ToString("F2");

        }

        private void execute()
        {
            words = new Dictionary<string, double>();
            /*------------------ KeyWords -----------------*/
            foreach (KeyValuePair<string, double> pair in keywords_IDF)
            {
                string keyword = pair.Key;
                /*------------------ Atualizar TF-IDFKeyWords ----------------*/

                if (!keywords_TFIDF.ContainsKey(keyword))
                    keywords_TFIDF.Add(keyword, 1);
                else keywords_TFIDF[keyword]+=pair.Value;
            }
            foreach (KeyValuePair<string, double> pair in keywords_IDF)
            {
                words.Add(pair.Key,keywords_TFIDF[pair.Key]);
            }
        }

        /*private void print()
        {
            foreach(KeyValuePair<string, double> pair in keywords_TFIDF)
            {
                checkedListBox1.Items.Add(pair);
            }
        }~*/

        private void importData()
        {
            string constring = "datasource=localhost;port=3306;username=root;password=";
            string Query = "select * from iata.iata;";
            MySqlConnection conDatabase = new MySqlConnection(constring);
            MySqlCommand cmdDatabase = new MySqlCommand(Query, conDatabase);
            MySqlDataReader myReader;
            try
            {
                conDatabase.Open();
                myReader = cmdDatabase.ExecuteReader();
                //MessageBox.Show("Imported");
                while (myReader.Read())
                {
                    string char1 = myReader.GetString("char");
                    string value = myReader.GetString("value").ToString();
                    double value1 = double.Parse(value);
                    keywords_TFIDF.Add(char1, value1);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Dashboard2 d2 = new Dashboard2();
            d2.ShowDialog();
        }

        private void Dashboard4_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            save();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label17_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Dashboard5 d5 = new Dashboard5(texto);
            d5.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            items1 = new List<string>();
            items1.Clear();
            foreach (string s in checkedListBox1.CheckedItems)
            {
                items1.Add(s);
            }
            UAnalyzer();
            this.Hide();
            Dashboard6 d6 = new Dashboard6(keywords_IDF, texto);
            d6.ShowDialog();
        }

        public static void UAnalyzer()
        {
            /*---------------- Uni-Gram Analyser ----------- */

            for (int j = 0; j < items1.Count; j++)
                for (int i = 0; i < keywords_IDF.Count; i++)
                    if (keywords_IDF.ElementAt(i).Key == items1[j])
                    {
                        string keyword = keywords_IDF.ElementAt(i).Key;
                        keywords_IDF.Remove(keyword);
                    }

        }

        private void Dashboard4_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            Dashboard9 d9 = new Dashboard9(texto);
            d9.ShowDialog();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            Dashboard8 d8 = new Dashboard8(texto);
            d8.ShowDialog();
        }
    }
}
