﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Iata
{
    public partial class Dashboard7 : Form
    {
        private static string texto = null;
        private static Dictionary<string, double> keywords;
        private static double positive, negative, anger, anticipation, disgust,
                   fear, joy, sadness, surprise, trust, total;

        private void Dashboard7_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        public Dashboard7(Dictionary<string, List<int>> Dictionary, Dictionary<string, double> words, string text)
        {
            InitializeComponent();
            texto = String.Copy(text);
            keywords = new Dictionary<string, double>();
            foreach (KeyValuePair<string, double> pair in words)
            {
                keywords.Add(pair.Key, pair.Value);
            }
            positive = negative = anger = anticipation = disgust = fear = joy = sadness = surprise = trust = total = 0.0;
            importData();
            SentimentAnalysis(Dictionary, words);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int i = 1;
            string constring = "datasource=localhost;port=3306;username=root;password=";
            string Query = "truncate iata.sentiment;";
            Query = Query + "insert into iata.sentiment values ('" + i + "','" + positive + "','" + negative + "','" + anger + "','" + anticipation + "','" + disgust + "','" + fear + "','" + joy + "','" + sadness + "','" + surprise + "','" + trust+ "') ;";
            
            MySqlConnection conDatabase = new MySqlConnection(constring);
            MySqlCommand cmdDatabase = new MySqlCommand(Query, conDatabase);
            MySqlDataReader myReader;
            try
            {
                conDatabase.Open();
                myReader = cmdDatabase.ExecuteReader();
                MessageBox.Show("Saved");
                while (myReader.Read())
                {

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Dashboard6 d6 = new Dashboard6(keywords,texto);
            d6.ShowDialog();
        }

        public void SentimentAnalysis(Dictionary<string, List<int>> keywordDictionary, Dictionary<string, double> keywords)
        {
            // Convert to List (Only keys , values can be discarded)
            List<string> listkeywords = keywords.Select(kvp => kvp.Key).ToList();

            for (int i = 0; i < listkeywords.Count; i++)
            {
                foreach (KeyValuePair<string, List<int>> keysdic in keywordDictionary)
                {
                    if (listkeywords[i] == keysdic.Key)
                    {
                        if (keysdic.Value[0] == 1)
                            positive = positive + 1.0;
                        if (keysdic.Value[1] == 1)
                            negative = negative + 1.0;
                        if (keysdic.Value[2] == 1)
                            anger = anger + 1.0;
                        if (keysdic.Value[3] == 1)
                            anticipation = anticipation + 1.0;
                        if (keysdic.Value[4] == 1)
                            disgust = disgust + 1.0;
                        if (keysdic.Value[5] == 1)
                            fear = fear + 1.0;
                        if (keysdic.Value[6] == 1)
                            joy = joy + 1.0;
                        if (keysdic.Value[7] == 1)
                            sadness = sadness + 1.0;
                        if (keysdic.Value[8] == 1)
                            surprise = surprise + 1.0;
                        if (keysdic.Value[9] == 1)
                            trust = trust + 1.0;

                        break;
                    }
                }
            }
            total = positive + negative + anger + anticipation + disgust + fear + joy + sadness + surprise + trust;
            char1.Text = "Positive"; totalCh1.Text = positive.ToString(); progressBar1.Value = Convert.ToInt32((positive / (double)total) * 100); pct1.Text = ((positive / (double)total) * 100).ToString("F2");
            char2.Text = "Negative"; totalCh2.Text = negative.ToString(); progressBar2.Value = Convert.ToInt32((negative / (double)total) * 100); pct2.Text = ((negative / (double)total) * 100).ToString("F2");
            char3.Text = "Anger"; totalCh3.Text = anger.ToString(); progressBar3.Value = Convert.ToInt32((anger / (double)total) * 100); pct3.Text = ((anger / (double)total) * 100).ToString("F2");
            char4.Text = "Anticipation"; totalCh4.Text = anticipation.ToString(); progressBar4.Value = Convert.ToInt32((anticipation / (double)total) * 100); pct4.Text = ((anticipation / (double)total) * 100).ToString("F2");
            char5.Text = "Disgust"; totalCh5.Text = disgust.ToString(); progressBar5.Value = Convert.ToInt32((disgust / (double)total) * 100); pct5.Text = ((disgust / (double)total) * 100).ToString("F2");
            char6.Text = "Fear"; totalCh6.Text = fear.ToString(); progressBar6.Value = Convert.ToInt32((fear / (double)total) * 100); pct6.Text = ((fear / (double)total) * 100).ToString("F2");
            char7.Text = "Joy"; totalCh7.Text = joy.ToString(); progressBar7.Value = Convert.ToInt32((joy / (double)total) * 100); pct7.Text = ((joy / (double)total) * 100).ToString("F2");
            char8.Text = "Sadness"; totalCh8.Text = sadness.ToString(); progressBar8.Value = Convert.ToInt32((sadness / (double)total) * 100); pct8.Text = ((sadness / (double)total) * 100).ToString("F2");
            char9.Text = "Surprise"; totalCh9.Text = surprise.ToString(); progressBar9.Value = Convert.ToInt32((surprise / (double)total) * 100); pct9.Text = ((surprise / (double)total) * 100).ToString("F2");
            char10.Text = "Trust"; totalCh10.Text = trust.ToString(); progressBar10.Value = Convert.ToInt32((trust / (double)total) * 100); pct10.Text = ((trust / (double)total) * 100).ToString("F2");
        }

        private void importData()
        {
            string constring = "datasource=localhost;port=3306;username=root;password=";
            string Query = "select * from iata.sentiment;";
            MySqlConnection conDatabase = new MySqlConnection(constring);
            MySqlCommand cmdDatabase = new MySqlCommand(Query, conDatabase);
            MySqlDataReader myReader;
            try
            {
                conDatabase.Open();
                myReader = cmdDatabase.ExecuteReader();
                //MessageBox.Show("Imported");
                while (myReader.Read())
                {
                    positive += double.Parse(myReader.GetString("positive"));
                    negative += double.Parse(myReader.GetString("negative"));
                    anger += double.Parse(myReader.GetString("anger"));
                    anticipation += double.Parse(myReader.GetString("anticipation"));
                    disgust += double.Parse(myReader.GetString("disgust"));
                    fear += double.Parse(myReader.GetString("fear"));
                    joy += double.Parse(myReader.GetString("joy"));
                    sadness += double.Parse(myReader.GetString("sadness"));
                    surprise += double.Parse(myReader.GetString("surprise"));
                    trust += double.Parse(myReader.GetString("trust"));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Dashboard7_Load(object sender, EventArgs e)
        {

        }
    }
}
