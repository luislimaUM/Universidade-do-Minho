﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LumenWorks.Framework.IO.Csv;
using System.IO;

namespace Iata
{
    public partial class Dashboard6 : Form
    {
        private static string texto = null;
        private static Dictionary<string, double> keywords;
        private static string path = "C:\\Users\\Luis Lima\\Documents\\Visual Studio 2017\\Projects\\Iata\\Iata\\Iata\\bin\\Debug\\NRC-Emotion-Lexicon-v0.92-InManyLanguages.csv";
        public static Dictionary<string, List<int>> keywordDictionary; // stores keyword - Feelings

        public Dashboard6(Dictionary<string, double> words, string text)
        {
            InitializeComponent();
            texto = String.Copy(text);
            keywords = new Dictionary<string, double>();
            foreach(KeyValuePair <string,double> pair in words)
            {
                keywords.Add(pair.Key, pair.Value);
            }
            StoreCSVInfo(path);
            SentimentAnalysis(keywords);
        }

        public void SentimentAnalysis(Dictionary<string, double> keywords)
        {
            double positive, negative, anger, anticipation, disgust,
                   fear, joy, sadness, surprise, trust, total;

            positive = negative = anger = anticipation = disgust
                   = fear = joy = sadness = surprise = trust = total = 0.0;

            // Convert to List (Only keys , values can be discarded)
            List<string> listkeywords = keywords.Select(kvp => kvp.Key).ToList();

            for (int i = 0; i < listkeywords.Count; i++)
            {
                foreach (KeyValuePair<string, List<int>> keysdic in keywordDictionary)
                {
                    if (listkeywords[i] == keysdic.Key)
                    {
                        if (keysdic.Value[0] == 1)
                            positive = positive + 1.0;
                        if (keysdic.Value[1] == 1)
                            negative = negative + 1.0;
                        if (keysdic.Value[2] == 1)
                            anger = anger + 1.0;
                        if (keysdic.Value[3] == 1)
                            anticipation = anticipation + 1.0;
                        if (keysdic.Value[4] == 1)
                            disgust = disgust + 1.0;
                        if (keysdic.Value[5] == 1)
                            fear = fear + 1.0;
                        if (keysdic.Value[6] == 1)
                            joy = joy + 1.0;
                        if (keysdic.Value[7] == 1)
                            sadness = sadness + 1.0;
                        if (keysdic.Value[8] == 1)
                            surprise = surprise + 1.0;
                        if (keysdic.Value[9] == 1)
                            trust = trust + 1.0;

                        break;
                    }
                }
            }
            total = positive + negative + anger + anticipation + disgust + fear + joy + sadness + surprise + trust;

            if(total != 0){
                char1.Text = "Positive"; totalCh1.Text = positive.ToString(); progressBar1.Value = Convert.ToInt16((positive / (double)total) * 100); pct1.Text = ((positive / (double)total) * 100).ToString("F2");
                char2.Text = "Negative"; totalCh2.Text = negative.ToString(); progressBar2.Value = Convert.ToInt32((negative / (double)total) * 100); pct2.Text = ((negative / (double)total) * 100).ToString("F2");
                char3.Text = "Anger"; totalCh3.Text = anger.ToString(); progressBar3.Value = Convert.ToInt32((anger / (double)total) * 100); pct3.Text = ((anger / (double)total) * 100).ToString("F2");
                char4.Text = "Anticipation"; totalCh4.Text = anticipation.ToString(); progressBar4.Value = Convert.ToInt32((anticipation / (double)total) * 100); pct4.Text = ((anticipation / (double)total) * 100).ToString("F2");
                char5.Text = "Disgust"; totalCh5.Text = disgust.ToString(); progressBar5.Value = Convert.ToInt32((disgust / (double)total) * 100); pct5.Text = ((disgust / (double)total) * 100).ToString("F2");
                char6.Text = "Fear"; totalCh6.Text = fear.ToString(); progressBar6.Value = Convert.ToInt32((fear / (double)total) * 100); pct6.Text = ((fear / (double)total) * 100).ToString("F2");
                char7.Text = "Joy"; totalCh7.Text = joy.ToString(); progressBar7.Value = Convert.ToInt32((joy / (double)total) * 100); pct7.Text = ((joy / (double)total) * 100).ToString("F2");
                char8.Text = "Sadness"; totalCh8.Text = sadness.ToString(); progressBar8.Value = Convert.ToInt32((sadness / (double)total) * 100); pct8.Text = ((sadness / (double)total) * 100).ToString("F2");
                char9.Text = "Surprise"; totalCh9.Text = surprise.ToString(); progressBar9.Value = Convert.ToInt32((surprise / (double)total) * 100); pct9.Text = ((surprise / (double)total) * 100).ToString("F2");
                char10.Text = "Trust"; totalCh10.Text = trust.ToString(); progressBar10.Value = Convert.ToInt32((trust / (double)total) * 100); pct10.Text = ((trust / (double)total) * 100).ToString("F2");
            }else
            {
                char1.Text = "Positive"; totalCh1.Text = positive.ToString(); progressBar1.Value = 0; pct1.Text = "0";
                char2.Text = "Negative"; totalCh2.Text = negative.ToString(); progressBar2.Value = 0; pct2.Text = "0";
                char3.Text = "Anger"; totalCh3.Text = anger.ToString(); progressBar3.Value = 0; pct3.Text = "0";
                char4.Text = "Anticipation"; totalCh4.Text = anticipation.ToString(); progressBar4.Value = 0; pct4.Text = "0";
                char5.Text = "Disgust"; totalCh5.Text = disgust.ToString(); progressBar5.Value = 0; pct5.Text = "0";
                char6.Text = "Fear"; totalCh6.Text = fear.ToString(); progressBar6.Value = 0; pct6.Text = "0";
                char7.Text = "Joy"; totalCh7.Text = joy.ToString(); progressBar7.Value = 0; pct7.Text = "0";
                char8.Text = "Sadness"; totalCh8.Text = sadness.ToString(); progressBar8.Value = 0; pct8.Text = "0";
                char9.Text = "Surprise"; totalCh9.Text = surprise.ToString(); progressBar9.Value = 0; pct9.Text = "0";
                char10.Text = "Trust"; totalCh10.Text = trust.ToString(); progressBar10.Value = 0; pct10.Text = "0";
            }
        }

        static void StoreCSVInfo(string s)
        {
            keywordDictionary = new Dictionary<string, List<int>>();
            using (CsvReader csv = new CsvReader(new StreamReader(s), true))
            {

                int fieldCount = csv.FieldCount;
                string[] headers = csv.GetFieldHeaders();

                while (csv.ReadNextRecord())
                {
                    List<int> numbers = new List<int>();
                    string[] part = csv[0].Split(';');

                    for (int i = 1; i < part.Count(); i++)
                    {

                        if (part[i] == "0" || part[i] == "1")
                            numbers.Add(Convert.ToInt32(part[i]));
                    }
                    keywordDictionary.Add(part[0], numbers);
                }
            }
        }

        private void Dashboard6_Load(object sender, EventArgs e)
        {

        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Dashboard5 d5 = new Dashboard5(texto);
            d5.ShowDialog();
        }

        private void Dashboard6_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Dashboard7 d7 = new Dashboard7(keywordDictionary,keywords,texto);
            d7.ShowDialog();
        }
    }
}
