﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Iata
{
    public partial class Dashboard2 : Form
    {   
        private static string strfilename = null;
        public static StreamReader reader; // reader for textfile

        public Dashboard2()
        {
            InitializeComponent();
        }

        private void Dashboard2_Load(object sender, EventArgs e)
        {

        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Dashboard1 d1 = new Dashboard1();
            d1.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Stream myStream;
            OpenFileDialog opd = new OpenFileDialog();
            opd.Filter = "text |*.txt";
            if (opd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                if ((myStream = opd.OpenFile()) != null)
                {
                    //MessageBox.Show(opd.SafeFileName);
                    textBox1.Text = opd.SafeFileName;
                    strfilename = opd.FileName;
                    string fileText = File.ReadAllText(strfilename);
                    richTextBox1.Text = fileText;
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int index = 0;
            String temp = richTextBox1.Text;
            richTextBox1.Text = "";
            richTextBox1.Text = temp;

            while (index < richTextBox1.Text.LastIndexOf(textBox2.Text))
            {
                richTextBox1.Find(textBox2.Text, index, richTextBox1.TextLength, RichTextBoxFinds.None);
                richTextBox1.SelectionBackColor = Color.Red;
                index = richTextBox1.Text.IndexOf(textBox2.Text, index) + 1;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            using (reader = new StreamReader(strfilename))
            {
                string text = reader.ReadToEnd();
                this.Hide();
                Dashboard5 d5 = new Dashboard5(text);
                //MessageBox.Show(strfilename);
                d5.ShowDialog();
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Dashboard2_Load_1(object sender, EventArgs e)
        {

        }

        private void Dashboard2_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }
}
