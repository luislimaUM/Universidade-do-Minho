﻿namespace IAmTA___TP1
{
    partial class Dashboard1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dashboard1));
            this.sidepanel = new System.Windows.Forms.Panel();
            this.BackButton = new System.Windows.Forms.Button();
            this.SaveButton = new System.Windows.Forms.Button();
            this.WordsAnalysisButton = new System.Windows.Forms.Button();
            this.DigraphEventsButton = new System.Windows.Forms.Button();
            this.KeyStrokeEventsButton = new System.Windows.Forms.Button();
            this.titlepanel = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.title = new System.Windows.Forms.Label();
            this.headerpanel = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pct10 = new System.Windows.Forms.Label();
            this.pct9 = new System.Windows.Forms.Label();
            this.pct8 = new System.Windows.Forms.Label();
            this.pct7 = new System.Windows.Forms.Label();
            this.pct6 = new System.Windows.Forms.Label();
            this.pct5 = new System.Windows.Forms.Label();
            this.pct4 = new System.Windows.Forms.Label();
            this.pct3 = new System.Windows.Forms.Label();
            this.pct2 = new System.Windows.Forms.Label();
            this.totalCh10 = new System.Windows.Forms.Label();
            this.totalCh9 = new System.Windows.Forms.Label();
            this.totalCh8 = new System.Windows.Forms.Label();
            this.totalCh7 = new System.Windows.Forms.Label();
            this.totalCh6 = new System.Windows.Forms.Label();
            this.totalCh5 = new System.Windows.Forms.Label();
            this.totalCh4 = new System.Windows.Forms.Label();
            this.totalCh3 = new System.Windows.Forms.Label();
            this.totalCh2 = new System.Windows.Forms.Label();
            this.char10 = new System.Windows.Forms.Label();
            this.char9 = new System.Windows.Forms.Label();
            this.char8 = new System.Windows.Forms.Label();
            this.char7 = new System.Windows.Forms.Label();
            this.char6 = new System.Windows.Forms.Label();
            this.char5 = new System.Windows.Forms.Label();
            this.char4 = new System.Windows.Forms.Label();
            this.char3 = new System.Windows.Forms.Label();
            this.char2 = new System.Windows.Forms.Label();
            this.totalCh1 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.char1 = new System.Windows.Forms.Label();
            this.pct1 = new System.Windows.Forms.Label();
            this.progressBar10 = new System.Windows.Forms.ProgressBar();
            this.progressBar9 = new System.Windows.Forms.ProgressBar();
            this.progressBar8 = new System.Windows.Forms.ProgressBar();
            this.progressBar7 = new System.Windows.Forms.ProgressBar();
            this.progressBar6 = new System.Windows.Forms.ProgressBar();
            this.progressBar5 = new System.Windows.Forms.ProgressBar();
            this.progressBar4 = new System.Windows.Forms.ProgressBar();
            this.progressBar3 = new System.Windows.Forms.ProgressBar();
            this.progressBar2 = new System.Windows.Forms.ProgressBar();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.totalCharacteres = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label33 = new System.Windows.Forms.Label();
            this.totalBackSpace = new System.Windows.Forms.Label();
            this.pctBackspace = new System.Windows.Forms.Label();
            this.progressBackspace = new System.Windows.Forms.ProgressBar();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.sidepanel.SuspendLayout();
            this.titlepanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.headerpanel.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // sidepanel
            // 
            this.sidepanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(43)))), ((int)(((byte)(55)))));
            this.sidepanel.Controls.Add(this.BackButton);
            this.sidepanel.Controls.Add(this.SaveButton);
            this.sidepanel.Controls.Add(this.WordsAnalysisButton);
            this.sidepanel.Controls.Add(this.DigraphEventsButton);
            this.sidepanel.Controls.Add(this.KeyStrokeEventsButton);
            this.sidepanel.Controls.Add(this.titlepanel);
            this.sidepanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.sidepanel.Location = new System.Drawing.Point(0, 0);
            this.sidepanel.Name = "sidepanel";
            this.sidepanel.Size = new System.Drawing.Size(340, 614);
            this.sidepanel.TabIndex = 0;
            // 
            // BackButton
            // 
            this.BackButton.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.BackButton.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray;
            this.BackButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BackButton.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BackButton.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.BackButton.Location = new System.Drawing.Point(0, 564);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(340, 50);
            this.BackButton.TabIndex = 5;
            this.BackButton.Text = "Back";
            this.BackButton.UseVisualStyleBackColor = true;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // SaveButton
            // 
            this.SaveButton.Dock = System.Windows.Forms.DockStyle.Top;
            this.SaveButton.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray;
            this.SaveButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SaveButton.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SaveButton.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.SaveButton.Location = new System.Drawing.Point(0, 247);
            this.SaveButton.Name = "SaveButton";
            this.SaveButton.Size = new System.Drawing.Size(340, 50);
            this.SaveButton.TabIndex = 4;
            this.SaveButton.Text = "Save";
            this.SaveButton.UseVisualStyleBackColor = true;
            this.SaveButton.Click += new System.EventHandler(this.SaveButton_Click);
            // 
            // WordsAnalysisButton
            // 
            this.WordsAnalysisButton.Dock = System.Windows.Forms.DockStyle.Top;
            this.WordsAnalysisButton.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray;
            this.WordsAnalysisButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.WordsAnalysisButton.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WordsAnalysisButton.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.WordsAnalysisButton.Location = new System.Drawing.Point(0, 197);
            this.WordsAnalysisButton.Name = "WordsAnalysisButton";
            this.WordsAnalysisButton.Size = new System.Drawing.Size(340, 50);
            this.WordsAnalysisButton.TabIndex = 3;
            this.WordsAnalysisButton.Text = "Words Analysis";
            this.WordsAnalysisButton.UseVisualStyleBackColor = true;
            this.WordsAnalysisButton.Click += new System.EventHandler(this.WordsAnalysisButton_Click);
            // 
            // DigraphEventsButton
            // 
            this.DigraphEventsButton.Dock = System.Windows.Forms.DockStyle.Top;
            this.DigraphEventsButton.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray;
            this.DigraphEventsButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DigraphEventsButton.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DigraphEventsButton.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.DigraphEventsButton.Location = new System.Drawing.Point(0, 147);
            this.DigraphEventsButton.Name = "DigraphEventsButton";
            this.DigraphEventsButton.Size = new System.Drawing.Size(340, 50);
            this.DigraphEventsButton.TabIndex = 2;
            this.DigraphEventsButton.Text = "Digraph Events";
            this.DigraphEventsButton.UseVisualStyleBackColor = true;
            this.DigraphEventsButton.Click += new System.EventHandler(this.DigraphEventsButton_Click);
            // 
            // KeyStrokeEventsButton
            // 
            this.KeyStrokeEventsButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(65)))));
            this.KeyStrokeEventsButton.Dock = System.Windows.Forms.DockStyle.Top;
            this.KeyStrokeEventsButton.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.KeyStrokeEventsButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.KeyStrokeEventsButton.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.KeyStrokeEventsButton.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.KeyStrokeEventsButton.Location = new System.Drawing.Point(0, 97);
            this.KeyStrokeEventsButton.Name = "KeyStrokeEventsButton";
            this.KeyStrokeEventsButton.Size = new System.Drawing.Size(340, 50);
            this.KeyStrokeEventsButton.TabIndex = 1;
            this.KeyStrokeEventsButton.Text = "KeyStroke Events";
            this.KeyStrokeEventsButton.UseVisualStyleBackColor = false;
            // 
            // titlepanel
            // 
            this.titlepanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(126)))), ((int)(((byte)(49)))));
            this.titlepanel.Controls.Add(this.pictureBox1);
            this.titlepanel.Controls.Add(this.title);
            this.titlepanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.titlepanel.Location = new System.Drawing.Point(0, 0);
            this.titlepanel.Name = "titlepanel";
            this.titlepanel.Size = new System.Drawing.Size(340, 97);
            this.titlepanel.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(40, 33);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(70, 37);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // title
            // 
            this.title.AutoSize = true;
            this.title.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.title.ForeColor = System.Drawing.Color.White;
            this.title.Location = new System.Drawing.Point(129, 42);
            this.title.Name = "title";
            this.title.Size = new System.Drawing.Size(148, 28);
            this.title.TabIndex = 0;
            this.title.Text = "IAmTA - TP1";
            // 
            // headerpanel
            // 
            this.headerpanel.BackColor = System.Drawing.Color.Snow;
            this.headerpanel.Controls.Add(this.label1);
            this.headerpanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.headerpanel.Location = new System.Drawing.Point(340, 0);
            this.headerpanel.Name = "headerpanel";
            this.headerpanel.Size = new System.Drawing.Size(750, 97);
            this.headerpanel.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(29, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(309, 30);
            this.label1.TabIndex = 2;
            this.label1.Text = "Keystroke Events Analysis";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.pct10);
            this.panel1.Controls.Add(this.pct9);
            this.panel1.Controls.Add(this.pct8);
            this.panel1.Controls.Add(this.pct7);
            this.panel1.Controls.Add(this.pct6);
            this.panel1.Controls.Add(this.pct5);
            this.panel1.Controls.Add(this.pct4);
            this.panel1.Controls.Add(this.pct3);
            this.panel1.Controls.Add(this.pct2);
            this.panel1.Controls.Add(this.totalCh10);
            this.panel1.Controls.Add(this.totalCh9);
            this.panel1.Controls.Add(this.totalCh8);
            this.panel1.Controls.Add(this.totalCh7);
            this.panel1.Controls.Add(this.totalCh6);
            this.panel1.Controls.Add(this.totalCh5);
            this.panel1.Controls.Add(this.totalCh4);
            this.panel1.Controls.Add(this.totalCh3);
            this.panel1.Controls.Add(this.totalCh2);
            this.panel1.Controls.Add(this.char10);
            this.panel1.Controls.Add(this.char9);
            this.panel1.Controls.Add(this.char8);
            this.panel1.Controls.Add(this.char7);
            this.panel1.Controls.Add(this.char6);
            this.panel1.Controls.Add(this.char5);
            this.panel1.Controls.Add(this.char4);
            this.panel1.Controls.Add(this.char3);
            this.panel1.Controls.Add(this.char2);
            this.panel1.Controls.Add(this.totalCh1);
            this.panel1.Controls.Add(this.label25);
            this.panel1.Controls.Add(this.char1);
            this.panel1.Controls.Add(this.pct1);
            this.panel1.Controls.Add(this.progressBar10);
            this.panel1.Controls.Add(this.progressBar9);
            this.panel1.Controls.Add(this.progressBar8);
            this.panel1.Controls.Add(this.progressBar7);
            this.panel1.Controls.Add(this.progressBar6);
            this.panel1.Controls.Add(this.progressBar5);
            this.panel1.Controls.Add(this.progressBar4);
            this.panel1.Controls.Add(this.progressBar3);
            this.panel1.Controls.Add(this.progressBar2);
            this.panel1.Controls.Add(this.progressBar1);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(445, 247);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(556, 345);
            this.panel1.TabIndex = 2;
            // 
            // pct10
            // 
            this.pct10.AutoSize = true;
            this.pct10.Location = new System.Drawing.Point(443, 315);
            this.pct10.Name = "pct10";
            this.pct10.Size = new System.Drawing.Size(24, 17);
            this.pct10.TabIndex = 56;
            this.pct10.Text = "25";
            // 
            // pct9
            // 
            this.pct9.AutoSize = true;
            this.pct9.Location = new System.Drawing.Point(443, 288);
            this.pct9.Name = "pct9";
            this.pct9.Size = new System.Drawing.Size(24, 17);
            this.pct9.TabIndex = 55;
            this.pct9.Text = "25";
            // 
            // pct8
            // 
            this.pct8.AutoSize = true;
            this.pct8.Location = new System.Drawing.Point(443, 262);
            this.pct8.Name = "pct8";
            this.pct8.Size = new System.Drawing.Size(24, 17);
            this.pct8.TabIndex = 54;
            this.pct8.Text = "25";
            // 
            // pct7
            // 
            this.pct7.AutoSize = true;
            this.pct7.Location = new System.Drawing.Point(443, 235);
            this.pct7.Name = "pct7";
            this.pct7.Size = new System.Drawing.Size(24, 17);
            this.pct7.TabIndex = 53;
            this.pct7.Text = "25";
            // 
            // pct6
            // 
            this.pct6.AutoSize = true;
            this.pct6.Location = new System.Drawing.Point(443, 209);
            this.pct6.Name = "pct6";
            this.pct6.Size = new System.Drawing.Size(24, 17);
            this.pct6.TabIndex = 52;
            this.pct6.Text = "25";
            // 
            // pct5
            // 
            this.pct5.AutoSize = true;
            this.pct5.Location = new System.Drawing.Point(443, 182);
            this.pct5.Name = "pct5";
            this.pct5.Size = new System.Drawing.Size(24, 17);
            this.pct5.TabIndex = 51;
            this.pct5.Text = "25";
            // 
            // pct4
            // 
            this.pct4.AutoSize = true;
            this.pct4.Location = new System.Drawing.Point(443, 156);
            this.pct4.Name = "pct4";
            this.pct4.Size = new System.Drawing.Size(24, 17);
            this.pct4.TabIndex = 50;
            this.pct4.Text = "25";
            // 
            // pct3
            // 
            this.pct3.AutoSize = true;
            this.pct3.Location = new System.Drawing.Point(443, 130);
            this.pct3.Name = "pct3";
            this.pct3.Size = new System.Drawing.Size(24, 17);
            this.pct3.TabIndex = 49;
            this.pct3.Text = "25";
            // 
            // pct2
            // 
            this.pct2.AutoSize = true;
            this.pct2.Location = new System.Drawing.Point(443, 104);
            this.pct2.Name = "pct2";
            this.pct2.Size = new System.Drawing.Size(24, 17);
            this.pct2.TabIndex = 48;
            this.pct2.Text = "25";
            // 
            // totalCh10
            // 
            this.totalCh10.AutoSize = true;
            this.totalCh10.Location = new System.Drawing.Point(191, 315);
            this.totalCh10.Name = "totalCh10";
            this.totalCh10.Size = new System.Drawing.Size(32, 17);
            this.totalCh10.TabIndex = 47;
            this.totalCh10.Text = "100";
            // 
            // totalCh9
            // 
            this.totalCh9.AutoSize = true;
            this.totalCh9.Location = new System.Drawing.Point(191, 288);
            this.totalCh9.Name = "totalCh9";
            this.totalCh9.Size = new System.Drawing.Size(32, 17);
            this.totalCh9.TabIndex = 46;
            this.totalCh9.Text = "100";
            // 
            // totalCh8
            // 
            this.totalCh8.AutoSize = true;
            this.totalCh8.Location = new System.Drawing.Point(191, 262);
            this.totalCh8.Name = "totalCh8";
            this.totalCh8.Size = new System.Drawing.Size(32, 17);
            this.totalCh8.TabIndex = 45;
            this.totalCh8.Text = "100";
            // 
            // totalCh7
            // 
            this.totalCh7.AutoSize = true;
            this.totalCh7.Location = new System.Drawing.Point(191, 235);
            this.totalCh7.Name = "totalCh7";
            this.totalCh7.Size = new System.Drawing.Size(32, 17);
            this.totalCh7.TabIndex = 44;
            this.totalCh7.Text = "100";
            // 
            // totalCh6
            // 
            this.totalCh6.AutoSize = true;
            this.totalCh6.Location = new System.Drawing.Point(191, 209);
            this.totalCh6.Name = "totalCh6";
            this.totalCh6.Size = new System.Drawing.Size(32, 17);
            this.totalCh6.TabIndex = 43;
            this.totalCh6.Text = "100";
            // 
            // totalCh5
            // 
            this.totalCh5.AutoSize = true;
            this.totalCh5.Location = new System.Drawing.Point(191, 182);
            this.totalCh5.Name = "totalCh5";
            this.totalCh5.Size = new System.Drawing.Size(32, 17);
            this.totalCh5.TabIndex = 42;
            this.totalCh5.Text = "100";
            // 
            // totalCh4
            // 
            this.totalCh4.AutoSize = true;
            this.totalCh4.Location = new System.Drawing.Point(191, 156);
            this.totalCh4.Name = "totalCh4";
            this.totalCh4.Size = new System.Drawing.Size(32, 17);
            this.totalCh4.TabIndex = 41;
            this.totalCh4.Text = "100";
            // 
            // totalCh3
            // 
            this.totalCh3.AutoSize = true;
            this.totalCh3.Location = new System.Drawing.Point(191, 130);
            this.totalCh3.Name = "totalCh3";
            this.totalCh3.Size = new System.Drawing.Size(32, 17);
            this.totalCh3.TabIndex = 40;
            this.totalCh3.Text = "100";
            // 
            // totalCh2
            // 
            this.totalCh2.AutoSize = true;
            this.totalCh2.Location = new System.Drawing.Point(191, 104);
            this.totalCh2.Name = "totalCh2";
            this.totalCh2.Size = new System.Drawing.Size(32, 17);
            this.totalCh2.TabIndex = 39;
            this.totalCh2.Text = "100";
            // 
            // char10
            // 
            this.char10.AutoSize = true;
            this.char10.Location = new System.Drawing.Point(75, 315);
            this.char10.Name = "char10";
            this.char10.Size = new System.Drawing.Size(23, 17);
            this.char10.TabIndex = 38;
            this.char10.Text = "\'C\'";
            // 
            // char9
            // 
            this.char9.AutoSize = true;
            this.char9.Location = new System.Drawing.Point(75, 288);
            this.char9.Name = "char9";
            this.char9.Size = new System.Drawing.Size(23, 17);
            this.char9.TabIndex = 37;
            this.char9.Text = "\'C\'";
            // 
            // char8
            // 
            this.char8.AutoSize = true;
            this.char8.Location = new System.Drawing.Point(75, 262);
            this.char8.Name = "char8";
            this.char8.Size = new System.Drawing.Size(23, 17);
            this.char8.TabIndex = 36;
            this.char8.Text = "\'C\'";
            // 
            // char7
            // 
            this.char7.AutoSize = true;
            this.char7.Location = new System.Drawing.Point(75, 235);
            this.char7.Name = "char7";
            this.char7.Size = new System.Drawing.Size(23, 17);
            this.char7.TabIndex = 35;
            this.char7.Text = "\'C\'";
            // 
            // char6
            // 
            this.char6.AutoSize = true;
            this.char6.Location = new System.Drawing.Point(75, 209);
            this.char6.Name = "char6";
            this.char6.Size = new System.Drawing.Size(23, 17);
            this.char6.TabIndex = 34;
            this.char6.Text = "\'C\'";
            // 
            // char5
            // 
            this.char5.AutoSize = true;
            this.char5.Location = new System.Drawing.Point(75, 182);
            this.char5.Name = "char5";
            this.char5.Size = new System.Drawing.Size(23, 17);
            this.char5.TabIndex = 33;
            this.char5.Text = "\'C\'";
            // 
            // char4
            // 
            this.char4.AutoSize = true;
            this.char4.Location = new System.Drawing.Point(75, 156);
            this.char4.Name = "char4";
            this.char4.Size = new System.Drawing.Size(23, 17);
            this.char4.TabIndex = 32;
            this.char4.Text = "\'C\'";
            // 
            // char3
            // 
            this.char3.AutoSize = true;
            this.char3.Location = new System.Drawing.Point(75, 130);
            this.char3.Name = "char3";
            this.char3.Size = new System.Drawing.Size(23, 17);
            this.char3.TabIndex = 31;
            this.char3.Text = "\'C\'";
            // 
            // char2
            // 
            this.char2.AutoSize = true;
            this.char2.Location = new System.Drawing.Point(75, 104);
            this.char2.Name = "char2";
            this.char2.Size = new System.Drawing.Size(23, 17);
            this.char2.TabIndex = 30;
            this.char2.Text = "\'C\'";
            // 
            // totalCh1
            // 
            this.totalCh1.AutoSize = true;
            this.totalCh1.Location = new System.Drawing.Point(191, 79);
            this.totalCh1.Name = "totalCh1";
            this.totalCh1.Size = new System.Drawing.Size(32, 17);
            this.totalCh1.TabIndex = 29;
            this.totalCh1.Text = "100";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(191, 50);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(42, 18);
            this.label25.TabIndex = 28;
            this.label25.Text = "Total";
            // 
            // char1
            // 
            this.char1.AutoSize = true;
            this.char1.Location = new System.Drawing.Point(75, 78);
            this.char1.Name = "char1";
            this.char1.Size = new System.Drawing.Size(23, 17);
            this.char1.TabIndex = 27;
            this.char1.Text = "\'C\'";
            // 
            // pct1
            // 
            this.pct1.AutoSize = true;
            this.pct1.Location = new System.Drawing.Point(443, 78);
            this.pct1.Name = "pct1";
            this.pct1.Size = new System.Drawing.Size(24, 17);
            this.pct1.TabIndex = 26;
            this.pct1.Text = "25";
            // 
            // progressBar10
            // 
            this.progressBar10.Location = new System.Drawing.Point(305, 317);
            this.progressBar10.Name = "progressBar10";
            this.progressBar10.Size = new System.Drawing.Size(100, 16);
            this.progressBar10.TabIndex = 25;
            // 
            // progressBar9
            // 
            this.progressBar9.Location = new System.Drawing.Point(305, 290);
            this.progressBar9.Name = "progressBar9";
            this.progressBar9.Size = new System.Drawing.Size(100, 16);
            this.progressBar9.TabIndex = 24;
            // 
            // progressBar8
            // 
            this.progressBar8.Location = new System.Drawing.Point(305, 264);
            this.progressBar8.Name = "progressBar8";
            this.progressBar8.Size = new System.Drawing.Size(100, 16);
            this.progressBar8.TabIndex = 23;
            // 
            // progressBar7
            // 
            this.progressBar7.Location = new System.Drawing.Point(305, 237);
            this.progressBar7.Name = "progressBar7";
            this.progressBar7.Size = new System.Drawing.Size(100, 16);
            this.progressBar7.TabIndex = 22;
            // 
            // progressBar6
            // 
            this.progressBar6.Location = new System.Drawing.Point(305, 211);
            this.progressBar6.Name = "progressBar6";
            this.progressBar6.Size = new System.Drawing.Size(100, 16);
            this.progressBar6.TabIndex = 21;
            // 
            // progressBar5
            // 
            this.progressBar5.Location = new System.Drawing.Point(305, 184);
            this.progressBar5.Name = "progressBar5";
            this.progressBar5.Size = new System.Drawing.Size(100, 16);
            this.progressBar5.TabIndex = 20;
            // 
            // progressBar4
            // 
            this.progressBar4.Location = new System.Drawing.Point(305, 158);
            this.progressBar4.Name = "progressBar4";
            this.progressBar4.Size = new System.Drawing.Size(100, 16);
            this.progressBar4.TabIndex = 19;
            // 
            // progressBar3
            // 
            this.progressBar3.Location = new System.Drawing.Point(305, 132);
            this.progressBar3.Name = "progressBar3";
            this.progressBar3.Size = new System.Drawing.Size(100, 16);
            this.progressBar3.TabIndex = 18;
            // 
            // progressBar2
            // 
            this.progressBar2.Location = new System.Drawing.Point(305, 106);
            this.progressBar2.Name = "progressBar2";
            this.progressBar2.Size = new System.Drawing.Size(100, 16);
            this.progressBar2.TabIndex = 17;
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(305, 79);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(100, 16);
            this.progressBar1.TabIndex = 16;
            this.progressBar1.Value = 25;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(14, 315);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(24, 17);
            this.label16.TabIndex = 15;
            this.label16.Text = "10";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(22, 288);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(16, 17);
            this.label15.TabIndex = 14;
            this.label15.Text = "9";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(22, 262);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(16, 17);
            this.label14.TabIndex = 13;
            this.label14.Text = "8";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(22, 235);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(16, 17);
            this.label13.TabIndex = 12;
            this.label13.Text = "7";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(22, 209);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(16, 17);
            this.label12.TabIndex = 11;
            this.label12.Text = "6";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(22, 182);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(16, 17);
            this.label11.TabIndex = 10;
            this.label11.Text = "5";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(22, 156);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(16, 17);
            this.label8.TabIndex = 9;
            this.label8.Text = "4";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(22, 130);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(16, 17);
            this.label10.TabIndex = 8;
            this.label10.Text = "3";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(22, 104);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(16, 17);
            this.label9.TabIndex = 7;
            this.label9.Text = "2";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(22, 78);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(16, 17);
            this.label7.TabIndex = 5;
            this.label7.Text = "1";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(443, 50);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(21, 18);
            this.label6.TabIndex = 4;
            this.label6.Text = "%";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(302, 50);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(68, 18);
            this.label5.TabIndex = 3;
            this.label5.Text = "Progress";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(72, 49);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(83, 18);
            this.label4.TabIndex = 2;
            this.label4.Text = "Character";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(21, 49);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(17, 18);
            this.label3.TabIndex = 1;
            this.label3.Text = "#";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label2.Location = new System.Drawing.Point(18, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(215, 19);
            this.label2.TabIndex = 0;
            this.label2.Text = "Top 10 Characters Written";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.totalCharacteres);
            this.panel2.Controls.Add(this.label35);
            this.panel2.Location = new System.Drawing.Point(362, 119);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(297, 113);
            this.panel2.TabIndex = 28;
            // 
            // totalCharacteres
            // 
            this.totalCharacteres.AutoSize = true;
            this.totalCharacteres.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalCharacteres.Location = new System.Drawing.Point(19, 60);
            this.totalCharacteres.Name = "totalCharacteres";
            this.totalCharacteres.Size = new System.Drawing.Size(32, 18);
            this.totalCharacteres.TabIndex = 1;
            this.totalCharacteres.Text = "400";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.BackColor = System.Drawing.Color.White;
            this.label35.Font = new System.Drawing.Font("Century Gothic", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label35.Location = new System.Drawing.Point(18, 17);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(219, 19);
            this.label35.TabIndex = 0;
            this.label35.Text = "Total Count of Characters:";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Controls.Add(this.label33);
            this.panel3.Controls.Add(this.totalBackSpace);
            this.panel3.Controls.Add(this.pctBackspace);
            this.panel3.Controls.Add(this.progressBackspace);
            this.panel3.Controls.Add(this.label21);
            this.panel3.Controls.Add(this.label20);
            this.panel3.Controls.Add(this.label19);
            this.panel3.Location = new System.Drawing.Point(677, 119);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(387, 113);
            this.panel3.TabIndex = 29;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(223, 53);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(21, 18);
            this.label33.TabIndex = 32;
            this.label33.Text = "%";
            // 
            // totalBackSpace
            // 
            this.totalBackSpace.AutoSize = true;
            this.totalBackSpace.Location = new System.Drawing.Point(20, 75);
            this.totalBackSpace.Name = "totalBackSpace";
            this.totalBackSpace.Size = new System.Drawing.Size(24, 17);
            this.totalBackSpace.TabIndex = 28;
            this.totalBackSpace.Text = "20";
            // 
            // pctBackspace
            // 
            this.pctBackspace.AutoSize = true;
            this.pctBackspace.Location = new System.Drawing.Point(223, 74);
            this.pctBackspace.Name = "pctBackspace";
            this.pctBackspace.Size = new System.Drawing.Size(24, 17);
            this.pctBackspace.TabIndex = 31;
            this.pctBackspace.Text = "20";
            // 
            // progressBackspace
            // 
            this.progressBackspace.Location = new System.Drawing.Point(97, 75);
            this.progressBackspace.Name = "progressBackspace";
            this.progressBackspace.Size = new System.Drawing.Size(100, 16);
            this.progressBackspace.TabIndex = 30;
            this.progressBackspace.Value = 20;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(92, 53);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(68, 18);
            this.label21.TabIndex = 29;
            this.label21.Text = "Progress";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(19, 53);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(42, 18);
            this.label20.TabIndex = 28;
            this.label20.Text = "Total";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.White;
            this.label19.Font = new System.Drawing.Font("Century Gothic", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label19.Location = new System.Drawing.Point(18, 17);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(159, 19);
            this.label19.TabIndex = 0;
            this.label19.Text = "Use of BackSpace";
            // 
            // Dashboard1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightGray;
            this.ClientSize = new System.Drawing.Size(1090, 614);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.headerpanel);
            this.Controls.Add(this.sidepanel);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "Dashboard1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "IAmTA - TP1";
            this.sidepanel.ResumeLayout(false);
            this.titlepanel.ResumeLayout(false);
            this.titlepanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.headerpanel.ResumeLayout(false);
            this.headerpanel.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel sidepanel;
        private System.Windows.Forms.Panel titlepanel;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label title;
        private System.Windows.Forms.Panel headerpanel;
        private System.Windows.Forms.Button KeyStrokeEventsButton;
        private System.Windows.Forms.Button SaveButton;
        private System.Windows.Forms.Button WordsAnalysisButton;
        private System.Windows.Forms.Button DigraphEventsButton;
        private System.Windows.Forms.Button BackButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label char1;
        private System.Windows.Forms.Label pct1;
        private System.Windows.Forms.ProgressBar progressBar10;
        private System.Windows.Forms.ProgressBar progressBar9;
        private System.Windows.Forms.ProgressBar progressBar8;
        private System.Windows.Forms.ProgressBar progressBar7;
        private System.Windows.Forms.ProgressBar progressBar6;
        private System.Windows.Forms.ProgressBar progressBar5;
        private System.Windows.Forms.ProgressBar progressBar4;
        private System.Windows.Forms.ProgressBar progressBar3;
        private System.Windows.Forms.ProgressBar progressBar2;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label pctBackspace;
        private System.Windows.Forms.ProgressBar progressBackspace;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label totalCharacteres;
        private System.Windows.Forms.Label totalBackSpace;
        private System.Windows.Forms.Label totalCh1;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label char10;
        private System.Windows.Forms.Label char9;
        private System.Windows.Forms.Label char8;
        private System.Windows.Forms.Label char7;
        private System.Windows.Forms.Label char6;
        private System.Windows.Forms.Label char5;
        private System.Windows.Forms.Label char4;
        private System.Windows.Forms.Label char3;
        private System.Windows.Forms.Label char2;
        private System.Windows.Forms.Label totalCh10;
        private System.Windows.Forms.Label totalCh9;
        private System.Windows.Forms.Label totalCh8;
        private System.Windows.Forms.Label totalCh7;
        private System.Windows.Forms.Label totalCh6;
        private System.Windows.Forms.Label totalCh5;
        private System.Windows.Forms.Label totalCh4;
        private System.Windows.Forms.Label totalCh3;
        private System.Windows.Forms.Label totalCh2;
        private System.Windows.Forms.Label pct10;
        private System.Windows.Forms.Label pct9;
        private System.Windows.Forms.Label pct8;
        private System.Windows.Forms.Label pct7;
        private System.Windows.Forms.Label pct6;
        private System.Windows.Forms.Label pct5;
        private System.Windows.Forms.Label pct4;
        private System.Windows.Forms.Label pct3;
        private System.Windows.Forms.Label pct2;
        private System.Windows.Forms.Label label33;
    }
}