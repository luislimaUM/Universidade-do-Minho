﻿namespace IAmTA___TP1
{
    partial class Dashboard2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dashboard2));
            this.sidepanel = new System.Windows.Forms.Panel();
            this.BackButton = new System.Windows.Forms.Button();
            this.SaveButton = new System.Windows.Forms.Button();
            this.WordsAnalysisButton = new System.Windows.Forms.Button();
            this.DigraphEventsButton = new System.Windows.Forms.Button();
            this.KeyStrokeEventsButton = new System.Windows.Forms.Button();
            this.titlepanel = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.title = new System.Windows.Forms.Label();
            this.headerpanel = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.stdDigraph = new System.Windows.Forms.Label();
            this.meanDigraph = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.stdSS = new System.Windows.Forms.Label();
            this.stdSR = new System.Windows.Forms.Label();
            this.stdSL = new System.Windows.Forms.Label();
            this.stdRS = new System.Windows.Forms.Label();
            this.stdRR = new System.Windows.Forms.Label();
            this.stdRL = new System.Windows.Forms.Label();
            this.stdLS = new System.Windows.Forms.Label();
            this.stdLR = new System.Windows.Forms.Label();
            this.stdLL = new System.Windows.Forms.Label();
            this.meanSS = new System.Windows.Forms.Label();
            this.meanSR = new System.Windows.Forms.Label();
            this.meanSL = new System.Windows.Forms.Label();
            this.meanRS = new System.Windows.Forms.Label();
            this.meanRR = new System.Windows.Forms.Label();
            this.meanRL = new System.Windows.Forms.Label();
            this.meanLS = new System.Windows.Forms.Label();
            this.meanLR = new System.Windows.Forms.Label();
            this.meanLL = new System.Windows.Forms.Label();
            this.pct9 = new System.Windows.Forms.Label();
            this.progressBar9 = new System.Windows.Forms.ProgressBar();
            this.pct8 = new System.Windows.Forms.Label();
            this.progressBar8 = new System.Windows.Forms.ProgressBar();
            this.pct7 = new System.Windows.Forms.Label();
            this.progressBar7 = new System.Windows.Forms.ProgressBar();
            this.pct6 = new System.Windows.Forms.Label();
            this.progressBar6 = new System.Windows.Forms.ProgressBar();
            this.pct5 = new System.Windows.Forms.Label();
            this.progressBar5 = new System.Windows.Forms.ProgressBar();
            this.pct4 = new System.Windows.Forms.Label();
            this.progressBar4 = new System.Windows.Forms.ProgressBar();
            this.pct3 = new System.Windows.Forms.Label();
            this.progressBar3 = new System.Windows.Forms.ProgressBar();
            this.pct2 = new System.Windows.Forms.Label();
            this.progressBar2 = new System.Windows.Forms.ProgressBar();
            this.pct1 = new System.Windows.Forms.Label();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.counterSS = new System.Windows.Forms.Label();
            this.counterSR = new System.Windows.Forms.Label();
            this.counterSL = new System.Windows.Forms.Label();
            this.counterRS = new System.Windows.Forms.Label();
            this.counterRR = new System.Windows.Forms.Label();
            this.counterRL = new System.Windows.Forms.Label();
            this.counterLS = new System.Windows.Forms.Label();
            this.counterLR = new System.Windows.Forms.Label();
            this.counterLL = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.pctT10 = new System.Windows.Forms.Label();
            this.progressT10 = new System.Windows.Forms.ProgressBar();
            this.trio10 = new System.Windows.Forms.Label();
            this.ct10 = new System.Windows.Forms.Label();
            this.pctT9 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.progressT9 = new System.Windows.Forms.ProgressBar();
            this.label40 = new System.Windows.Forms.Label();
            this.pctT8 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.progressT8 = new System.Windows.Forms.ProgressBar();
            this.trio1 = new System.Windows.Forms.Label();
            this.pctT7 = new System.Windows.Forms.Label();
            this.trio2 = new System.Windows.Forms.Label();
            this.progressT7 = new System.Windows.Forms.ProgressBar();
            this.trio3 = new System.Windows.Forms.Label();
            this.pctT6 = new System.Windows.Forms.Label();
            this.trio4 = new System.Windows.Forms.Label();
            this.progressT6 = new System.Windows.Forms.ProgressBar();
            this.trio5 = new System.Windows.Forms.Label();
            this.pctT5 = new System.Windows.Forms.Label();
            this.trio6 = new System.Windows.Forms.Label();
            this.progressT5 = new System.Windows.Forms.ProgressBar();
            this.trio7 = new System.Windows.Forms.Label();
            this.pctT4 = new System.Windows.Forms.Label();
            this.trio8 = new System.Windows.Forms.Label();
            this.progressT4 = new System.Windows.Forms.ProgressBar();
            this.trio9 = new System.Windows.Forms.Label();
            this.pctT3 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.progressT3 = new System.Windows.Forms.ProgressBar();
            this.label39 = new System.Windows.Forms.Label();
            this.pctT2 = new System.Windows.Forms.Label();
            this.ct1 = new System.Windows.Forms.Label();
            this.progressT2 = new System.Windows.Forms.ProgressBar();
            this.ct2 = new System.Windows.Forms.Label();
            this.pctT1 = new System.Windows.Forms.Label();
            this.ct3 = new System.Windows.Forms.Label();
            this.progressT1 = new System.Windows.Forms.ProgressBar();
            this.ct4 = new System.Windows.Forms.Label();
            this.ct9 = new System.Windows.Forms.Label();
            this.ct5 = new System.Windows.Forms.Label();
            this.ct8 = new System.Windows.Forms.Label();
            this.ct6 = new System.Windows.Forms.Label();
            this.ct7 = new System.Windows.Forms.Label();
            this.sidepanel.SuspendLayout();
            this.titlepanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.headerpanel.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // sidepanel
            // 
            this.sidepanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(43)))), ((int)(((byte)(55)))));
            this.sidepanel.Controls.Add(this.BackButton);
            this.sidepanel.Controls.Add(this.SaveButton);
            this.sidepanel.Controls.Add(this.WordsAnalysisButton);
            this.sidepanel.Controls.Add(this.DigraphEventsButton);
            this.sidepanel.Controls.Add(this.KeyStrokeEventsButton);
            this.sidepanel.Controls.Add(this.titlepanel);
            this.sidepanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.sidepanel.Location = new System.Drawing.Point(0, 0);
            this.sidepanel.Name = "sidepanel";
            this.sidepanel.Size = new System.Drawing.Size(340, 657);
            this.sidepanel.TabIndex = 0;
            // 
            // BackButton
            // 
            this.BackButton.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.BackButton.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray;
            this.BackButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BackButton.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BackButton.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.BackButton.Location = new System.Drawing.Point(0, 607);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(340, 50);
            this.BackButton.TabIndex = 5;
            this.BackButton.Text = "Back";
            this.BackButton.UseVisualStyleBackColor = true;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // SaveButton
            // 
            this.SaveButton.Dock = System.Windows.Forms.DockStyle.Top;
            this.SaveButton.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray;
            this.SaveButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SaveButton.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SaveButton.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.SaveButton.Location = new System.Drawing.Point(0, 247);
            this.SaveButton.Name = "SaveButton";
            this.SaveButton.Size = new System.Drawing.Size(340, 50);
            this.SaveButton.TabIndex = 4;
            this.SaveButton.Text = "Save";
            this.SaveButton.UseVisualStyleBackColor = true;
            this.SaveButton.Click += new System.EventHandler(this.SaveButton_Click);
            // 
            // WordsAnalysisButton
            // 
            this.WordsAnalysisButton.Dock = System.Windows.Forms.DockStyle.Top;
            this.WordsAnalysisButton.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray;
            this.WordsAnalysisButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.WordsAnalysisButton.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WordsAnalysisButton.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.WordsAnalysisButton.Location = new System.Drawing.Point(0, 197);
            this.WordsAnalysisButton.Name = "WordsAnalysisButton";
            this.WordsAnalysisButton.Size = new System.Drawing.Size(340, 50);
            this.WordsAnalysisButton.TabIndex = 3;
            this.WordsAnalysisButton.Text = "Words Analysis";
            this.WordsAnalysisButton.UseVisualStyleBackColor = true;
            this.WordsAnalysisButton.Click += new System.EventHandler(this.WordsAnalysisButton_Click);
            // 
            // DigraphEventsButton
            // 
            this.DigraphEventsButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(65)))));
            this.DigraphEventsButton.Dock = System.Windows.Forms.DockStyle.Top;
            this.DigraphEventsButton.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray;
            this.DigraphEventsButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DigraphEventsButton.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DigraphEventsButton.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.DigraphEventsButton.Location = new System.Drawing.Point(0, 147);
            this.DigraphEventsButton.Name = "DigraphEventsButton";
            this.DigraphEventsButton.Size = new System.Drawing.Size(340, 50);
            this.DigraphEventsButton.TabIndex = 2;
            this.DigraphEventsButton.Text = "Digraph Events";
            this.DigraphEventsButton.UseVisualStyleBackColor = false;
            // 
            // KeyStrokeEventsButton
            // 
            this.KeyStrokeEventsButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(43)))), ((int)(((byte)(55)))));
            this.KeyStrokeEventsButton.Dock = System.Windows.Forms.DockStyle.Top;
            this.KeyStrokeEventsButton.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.KeyStrokeEventsButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.KeyStrokeEventsButton.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.KeyStrokeEventsButton.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.KeyStrokeEventsButton.Location = new System.Drawing.Point(0, 97);
            this.KeyStrokeEventsButton.Name = "KeyStrokeEventsButton";
            this.KeyStrokeEventsButton.Size = new System.Drawing.Size(340, 50);
            this.KeyStrokeEventsButton.TabIndex = 1;
            this.KeyStrokeEventsButton.Text = "KeyStroke Events";
            this.KeyStrokeEventsButton.UseVisualStyleBackColor = false;
            this.KeyStrokeEventsButton.Click += new System.EventHandler(this.KeyStrokeEventsButton_Click);
            // 
            // titlepanel
            // 
            this.titlepanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(126)))), ((int)(((byte)(49)))));
            this.titlepanel.Controls.Add(this.pictureBox1);
            this.titlepanel.Controls.Add(this.title);
            this.titlepanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.titlepanel.Location = new System.Drawing.Point(0, 0);
            this.titlepanel.Name = "titlepanel";
            this.titlepanel.Size = new System.Drawing.Size(340, 97);
            this.titlepanel.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(40, 33);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(70, 37);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // title
            // 
            this.title.AutoSize = true;
            this.title.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.title.ForeColor = System.Drawing.Color.White;
            this.title.Location = new System.Drawing.Point(129, 42);
            this.title.Name = "title";
            this.title.Size = new System.Drawing.Size(148, 28);
            this.title.TabIndex = 0;
            this.title.Text = "IAmTA - TP1";
            // 
            // headerpanel
            // 
            this.headerpanel.BackColor = System.Drawing.Color.Snow;
            this.headerpanel.Controls.Add(this.label1);
            this.headerpanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.headerpanel.Location = new System.Drawing.Point(340, 0);
            this.headerpanel.Name = "headerpanel";
            this.headerpanel.Size = new System.Drawing.Size(983, 97);
            this.headerpanel.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(29, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(291, 30);
            this.label1.TabIndex = 2;
            this.label1.Text = "Digraph Events Analysis";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.stdDigraph);
            this.panel2.Controls.Add(this.meanDigraph);
            this.panel2.Controls.Add(this.label24);
            this.panel2.Controls.Add(this.label27);
            this.panel2.Controls.Add(this.label35);
            this.panel2.Location = new System.Drawing.Point(362, 119);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(550, 122);
            this.panel2.TabIndex = 28;
            // 
            // stdDigraph
            // 
            this.stdDigraph.AutoSize = true;
            this.stdDigraph.Location = new System.Drawing.Point(296, 80);
            this.stdDigraph.Name = "stdDigraph";
            this.stdDigraph.Size = new System.Drawing.Size(54, 17);
            this.stdDigraph.TabIndex = 34;
            this.stdDigraph.Text = "label18";
            // 
            // meanDigraph
            // 
            this.meanDigraph.AutoSize = true;
            this.meanDigraph.Location = new System.Drawing.Point(194, 52);
            this.meanDigraph.Name = "meanDigraph";
            this.meanDigraph.Size = new System.Drawing.Size(54, 17);
            this.meanDigraph.TabIndex = 29;
            this.meanDigraph.Text = "label18";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(19, 78);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(271, 18);
            this.label24.TabIndex = 33;
            this.label24.Text = "Standard Derivation of Writting Time:";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(19, 50);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(169, 18);
            this.label27.TabIndex = 32;
            this.label27.Text = "Mean of Writting Time:";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.BackColor = System.Drawing.Color.White;
            this.label35.Font = new System.Drawing.Font("Century Gothic", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label35.Location = new System.Drawing.Point(18, 17);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(278, 19);
            this.label35.TabIndex = 0;
            this.label35.Text = "Analysis Based in all Keys Events";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label2.Location = new System.Drawing.Point(18, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(275, 19);
            this.label2.TabIndex = 0;
            this.label2.Text = "Analysis Based in KeyGroup Pair";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(25, 51);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 18);
            this.label3.TabIndex = 1;
            this.label3.Text = "Group";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(52, 78);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(24, 17);
            this.label7.TabIndex = 5;
            this.label7.Text = "LL";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.stdSS);
            this.panel1.Controls.Add(this.stdSR);
            this.panel1.Controls.Add(this.stdSL);
            this.panel1.Controls.Add(this.stdRS);
            this.panel1.Controls.Add(this.stdRR);
            this.panel1.Controls.Add(this.stdRL);
            this.panel1.Controls.Add(this.stdLS);
            this.panel1.Controls.Add(this.stdLR);
            this.panel1.Controls.Add(this.stdLL);
            this.panel1.Controls.Add(this.meanSS);
            this.panel1.Controls.Add(this.meanSR);
            this.panel1.Controls.Add(this.meanSL);
            this.panel1.Controls.Add(this.meanRS);
            this.panel1.Controls.Add(this.meanRR);
            this.panel1.Controls.Add(this.meanRL);
            this.panel1.Controls.Add(this.meanLS);
            this.panel1.Controls.Add(this.meanLR);
            this.panel1.Controls.Add(this.meanLL);
            this.panel1.Controls.Add(this.pct9);
            this.panel1.Controls.Add(this.progressBar9);
            this.panel1.Controls.Add(this.pct8);
            this.panel1.Controls.Add(this.progressBar8);
            this.panel1.Controls.Add(this.pct7);
            this.panel1.Controls.Add(this.progressBar7);
            this.panel1.Controls.Add(this.pct6);
            this.panel1.Controls.Add(this.progressBar6);
            this.panel1.Controls.Add(this.pct5);
            this.panel1.Controls.Add(this.progressBar5);
            this.panel1.Controls.Add(this.pct4);
            this.panel1.Controls.Add(this.progressBar4);
            this.panel1.Controls.Add(this.pct3);
            this.panel1.Controls.Add(this.progressBar3);
            this.panel1.Controls.Add(this.pct2);
            this.panel1.Controls.Add(this.progressBar2);
            this.panel1.Controls.Add(this.pct1);
            this.panel1.Controls.Add(this.progressBar1);
            this.panel1.Controls.Add(this.counterSS);
            this.panel1.Controls.Add(this.counterSR);
            this.panel1.Controls.Add(this.counterSL);
            this.panel1.Controls.Add(this.counterRS);
            this.panel1.Controls.Add(this.counterRR);
            this.panel1.Controls.Add(this.counterRL);
            this.panel1.Controls.Add(this.counterLS);
            this.panel1.Controls.Add(this.counterLR);
            this.panel1.Controls.Add(this.counterLL);
            this.panel1.Controls.Add(this.label17);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(362, 260);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(550, 355);
            this.panel1.TabIndex = 2;
            // 
            // stdSS
            // 
            this.stdSS.AutoSize = true;
            this.stdSS.Location = new System.Drawing.Point(425, 290);
            this.stdSS.Name = "stdSS";
            this.stdSS.Size = new System.Drawing.Size(24, 17);
            this.stdSS.TabIndex = 82;
            this.stdSS.Text = "25";
            // 
            // stdSR
            // 
            this.stdSR.AutoSize = true;
            this.stdSR.Location = new System.Drawing.Point(425, 264);
            this.stdSR.Name = "stdSR";
            this.stdSR.Size = new System.Drawing.Size(24, 17);
            this.stdSR.TabIndex = 81;
            this.stdSR.Text = "25";
            // 
            // stdSL
            // 
            this.stdSL.AutoSize = true;
            this.stdSL.Location = new System.Drawing.Point(425, 237);
            this.stdSL.Name = "stdSL";
            this.stdSL.Size = new System.Drawing.Size(24, 17);
            this.stdSL.TabIndex = 80;
            this.stdSL.Text = "25";
            // 
            // stdRS
            // 
            this.stdRS.AutoSize = true;
            this.stdRS.Location = new System.Drawing.Point(425, 211);
            this.stdRS.Name = "stdRS";
            this.stdRS.Size = new System.Drawing.Size(24, 17);
            this.stdRS.TabIndex = 79;
            this.stdRS.Text = "25";
            // 
            // stdRR
            // 
            this.stdRR.AutoSize = true;
            this.stdRR.Location = new System.Drawing.Point(425, 184);
            this.stdRR.Name = "stdRR";
            this.stdRR.Size = new System.Drawing.Size(24, 17);
            this.stdRR.TabIndex = 78;
            this.stdRR.Text = "25";
            // 
            // stdRL
            // 
            this.stdRL.AutoSize = true;
            this.stdRL.Location = new System.Drawing.Point(425, 158);
            this.stdRL.Name = "stdRL";
            this.stdRL.Size = new System.Drawing.Size(24, 17);
            this.stdRL.TabIndex = 77;
            this.stdRL.Text = "25";
            // 
            // stdLS
            // 
            this.stdLS.AutoSize = true;
            this.stdLS.Location = new System.Drawing.Point(425, 132);
            this.stdLS.Name = "stdLS";
            this.stdLS.Size = new System.Drawing.Size(24, 17);
            this.stdLS.TabIndex = 76;
            this.stdLS.Text = "25";
            // 
            // stdLR
            // 
            this.stdLR.AutoSize = true;
            this.stdLR.Location = new System.Drawing.Point(425, 106);
            this.stdLR.Name = "stdLR";
            this.stdLR.Size = new System.Drawing.Size(24, 17);
            this.stdLR.TabIndex = 75;
            this.stdLR.Text = "25";
            // 
            // stdLL
            // 
            this.stdLL.AutoSize = true;
            this.stdLL.Location = new System.Drawing.Point(425, 80);
            this.stdLL.Name = "stdLL";
            this.stdLL.Size = new System.Drawing.Size(24, 17);
            this.stdLL.TabIndex = 74;
            this.stdLL.Text = "25";
            // 
            // meanSS
            // 
            this.meanSS.AutoSize = true;
            this.meanSS.Location = new System.Drawing.Point(356, 289);
            this.meanSS.Name = "meanSS";
            this.meanSS.Size = new System.Drawing.Size(24, 17);
            this.meanSS.TabIndex = 73;
            this.meanSS.Text = "25";
            // 
            // meanSR
            // 
            this.meanSR.AutoSize = true;
            this.meanSR.Location = new System.Drawing.Point(356, 263);
            this.meanSR.Name = "meanSR";
            this.meanSR.Size = new System.Drawing.Size(24, 17);
            this.meanSR.TabIndex = 72;
            this.meanSR.Text = "25";
            // 
            // meanSL
            // 
            this.meanSL.AutoSize = true;
            this.meanSL.Location = new System.Drawing.Point(356, 236);
            this.meanSL.Name = "meanSL";
            this.meanSL.Size = new System.Drawing.Size(24, 17);
            this.meanSL.TabIndex = 71;
            this.meanSL.Text = "25";
            // 
            // meanRS
            // 
            this.meanRS.AutoSize = true;
            this.meanRS.Location = new System.Drawing.Point(356, 210);
            this.meanRS.Name = "meanRS";
            this.meanRS.Size = new System.Drawing.Size(24, 17);
            this.meanRS.TabIndex = 70;
            this.meanRS.Text = "25";
            // 
            // meanRR
            // 
            this.meanRR.AutoSize = true;
            this.meanRR.Location = new System.Drawing.Point(356, 183);
            this.meanRR.Name = "meanRR";
            this.meanRR.Size = new System.Drawing.Size(24, 17);
            this.meanRR.TabIndex = 69;
            this.meanRR.Text = "25";
            // 
            // meanRL
            // 
            this.meanRL.AutoSize = true;
            this.meanRL.Location = new System.Drawing.Point(356, 157);
            this.meanRL.Name = "meanRL";
            this.meanRL.Size = new System.Drawing.Size(24, 17);
            this.meanRL.TabIndex = 68;
            this.meanRL.Text = "25";
            // 
            // meanLS
            // 
            this.meanLS.AutoSize = true;
            this.meanLS.Location = new System.Drawing.Point(356, 131);
            this.meanLS.Name = "meanLS";
            this.meanLS.Size = new System.Drawing.Size(24, 17);
            this.meanLS.TabIndex = 67;
            this.meanLS.Text = "25";
            // 
            // meanLR
            // 
            this.meanLR.AutoSize = true;
            this.meanLR.Location = new System.Drawing.Point(356, 105);
            this.meanLR.Name = "meanLR";
            this.meanLR.Size = new System.Drawing.Size(24, 17);
            this.meanLR.TabIndex = 66;
            this.meanLR.Text = "25";
            // 
            // meanLL
            // 
            this.meanLL.AutoSize = true;
            this.meanLL.Location = new System.Drawing.Point(356, 79);
            this.meanLL.Name = "meanLL";
            this.meanLL.Size = new System.Drawing.Size(24, 17);
            this.meanLL.TabIndex = 65;
            this.meanLL.Text = "25";
            // 
            // pct9
            // 
            this.pct9.AutoSize = true;
            this.pct9.Location = new System.Drawing.Point(310, 289);
            this.pct9.Name = "pct9";
            this.pct9.Size = new System.Drawing.Size(24, 17);
            this.pct9.TabIndex = 64;
            this.pct9.Text = "25";
            // 
            // progressBar9
            // 
            this.progressBar9.Location = new System.Drawing.Point(200, 290);
            this.progressBar9.Name = "progressBar9";
            this.progressBar9.Size = new System.Drawing.Size(100, 16);
            this.progressBar9.TabIndex = 36;
            // 
            // pct8
            // 
            this.pct8.AutoSize = true;
            this.pct8.Location = new System.Drawing.Point(310, 263);
            this.pct8.Name = "pct8";
            this.pct8.Size = new System.Drawing.Size(24, 17);
            this.pct8.TabIndex = 63;
            this.pct8.Text = "25";
            // 
            // progressBar8
            // 
            this.progressBar8.Location = new System.Drawing.Point(200, 264);
            this.progressBar8.Name = "progressBar8";
            this.progressBar8.Size = new System.Drawing.Size(100, 16);
            this.progressBar8.TabIndex = 35;
            // 
            // pct7
            // 
            this.pct7.AutoSize = true;
            this.pct7.Location = new System.Drawing.Point(310, 236);
            this.pct7.Name = "pct7";
            this.pct7.Size = new System.Drawing.Size(24, 17);
            this.pct7.TabIndex = 62;
            this.pct7.Text = "25";
            // 
            // progressBar7
            // 
            this.progressBar7.Location = new System.Drawing.Point(200, 237);
            this.progressBar7.Name = "progressBar7";
            this.progressBar7.Size = new System.Drawing.Size(100, 16);
            this.progressBar7.TabIndex = 34;
            // 
            // pct6
            // 
            this.pct6.AutoSize = true;
            this.pct6.Location = new System.Drawing.Point(310, 210);
            this.pct6.Name = "pct6";
            this.pct6.Size = new System.Drawing.Size(24, 17);
            this.pct6.TabIndex = 61;
            this.pct6.Text = "25";
            // 
            // progressBar6
            // 
            this.progressBar6.Location = new System.Drawing.Point(200, 211);
            this.progressBar6.Name = "progressBar6";
            this.progressBar6.Size = new System.Drawing.Size(100, 16);
            this.progressBar6.TabIndex = 33;
            // 
            // pct5
            // 
            this.pct5.AutoSize = true;
            this.pct5.Location = new System.Drawing.Point(310, 183);
            this.pct5.Name = "pct5";
            this.pct5.Size = new System.Drawing.Size(24, 17);
            this.pct5.TabIndex = 60;
            this.pct5.Text = "25";
            // 
            // progressBar5
            // 
            this.progressBar5.Location = new System.Drawing.Point(200, 184);
            this.progressBar5.Name = "progressBar5";
            this.progressBar5.Size = new System.Drawing.Size(100, 16);
            this.progressBar5.TabIndex = 32;
            // 
            // pct4
            // 
            this.pct4.AutoSize = true;
            this.pct4.Location = new System.Drawing.Point(310, 157);
            this.pct4.Name = "pct4";
            this.pct4.Size = new System.Drawing.Size(24, 17);
            this.pct4.TabIndex = 59;
            this.pct4.Text = "25";
            // 
            // progressBar4
            // 
            this.progressBar4.Location = new System.Drawing.Point(200, 158);
            this.progressBar4.Name = "progressBar4";
            this.progressBar4.Size = new System.Drawing.Size(100, 16);
            this.progressBar4.TabIndex = 31;
            // 
            // pct3
            // 
            this.pct3.AutoSize = true;
            this.pct3.Location = new System.Drawing.Point(310, 131);
            this.pct3.Name = "pct3";
            this.pct3.Size = new System.Drawing.Size(24, 17);
            this.pct3.TabIndex = 58;
            this.pct3.Text = "25";
            // 
            // progressBar3
            // 
            this.progressBar3.Location = new System.Drawing.Point(200, 132);
            this.progressBar3.Name = "progressBar3";
            this.progressBar3.Size = new System.Drawing.Size(100, 16);
            this.progressBar3.TabIndex = 30;
            // 
            // pct2
            // 
            this.pct2.AutoSize = true;
            this.pct2.Location = new System.Drawing.Point(310, 105);
            this.pct2.Name = "pct2";
            this.pct2.Size = new System.Drawing.Size(24, 17);
            this.pct2.TabIndex = 57;
            this.pct2.Text = "25";
            // 
            // progressBar2
            // 
            this.progressBar2.Location = new System.Drawing.Point(200, 106);
            this.progressBar2.Name = "progressBar2";
            this.progressBar2.Size = new System.Drawing.Size(100, 16);
            this.progressBar2.TabIndex = 29;
            // 
            // pct1
            // 
            this.pct1.AutoSize = true;
            this.pct1.Location = new System.Drawing.Point(310, 79);
            this.pct1.Name = "pct1";
            this.pct1.Size = new System.Drawing.Size(24, 17);
            this.pct1.TabIndex = 56;
            this.pct1.Text = "25";
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(200, 79);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(100, 16);
            this.progressBar1.TabIndex = 28;
            this.progressBar1.Value = 25;
            // 
            // counterSS
            // 
            this.counterSS.AutoSize = true;
            this.counterSS.Location = new System.Drawing.Point(106, 285);
            this.counterSS.Name = "counterSS";
            this.counterSS.Size = new System.Drawing.Size(54, 17);
            this.counterSS.TabIndex = 27;
            this.counterSS.Text = "label28";
            // 
            // counterSR
            // 
            this.counterSR.AutoSize = true;
            this.counterSR.Location = new System.Drawing.Point(106, 259);
            this.counterSR.Name = "counterSR";
            this.counterSR.Size = new System.Drawing.Size(54, 17);
            this.counterSR.TabIndex = 26;
            this.counterSR.Text = "label26";
            // 
            // counterSL
            // 
            this.counterSL.AutoSize = true;
            this.counterSL.Location = new System.Drawing.Point(106, 233);
            this.counterSL.Name = "counterSL";
            this.counterSL.Size = new System.Drawing.Size(54, 17);
            this.counterSL.TabIndex = 25;
            this.counterSL.Text = "label25";
            // 
            // counterRS
            // 
            this.counterRS.AutoSize = true;
            this.counterRS.Location = new System.Drawing.Point(106, 207);
            this.counterRS.Name = "counterRS";
            this.counterRS.Size = new System.Drawing.Size(54, 17);
            this.counterRS.TabIndex = 24;
            this.counterRS.Text = "label23";
            // 
            // counterRR
            // 
            this.counterRR.AutoSize = true;
            this.counterRR.Location = new System.Drawing.Point(106, 182);
            this.counterRR.Name = "counterRR";
            this.counterRR.Size = new System.Drawing.Size(54, 17);
            this.counterRR.TabIndex = 23;
            this.counterRR.Text = "label22";
            // 
            // counterRL
            // 
            this.counterRL.AutoSize = true;
            this.counterRL.Location = new System.Drawing.Point(106, 156);
            this.counterRL.Name = "counterRL";
            this.counterRL.Size = new System.Drawing.Size(54, 17);
            this.counterRL.TabIndex = 22;
            this.counterRL.Text = "label21";
            // 
            // counterLS
            // 
            this.counterLS.AutoSize = true;
            this.counterLS.Location = new System.Drawing.Point(106, 130);
            this.counterLS.Name = "counterLS";
            this.counterLS.Size = new System.Drawing.Size(54, 17);
            this.counterLS.TabIndex = 21;
            this.counterLS.Text = "label20";
            // 
            // counterLR
            // 
            this.counterLR.AutoSize = true;
            this.counterLR.Location = new System.Drawing.Point(106, 104);
            this.counterLR.Name = "counterLR";
            this.counterLR.Size = new System.Drawing.Size(54, 17);
            this.counterLR.TabIndex = 20;
            this.counterLR.Text = "label19";
            // 
            // counterLL
            // 
            this.counterLL.AutoSize = true;
            this.counterLL.Location = new System.Drawing.Point(106, 78);
            this.counterLL.Name = "counterLL";
            this.counterLL.Size = new System.Drawing.Size(35, 17);
            this.counterLL.TabIndex = 19;
            this.counterLL.Text = "ctLL";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(313, 51);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(21, 18);
            this.label17.TabIndex = 18;
            this.label17.Text = "%";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(425, 51);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(105, 18);
            this.label16.TabIndex = 17;
            this.label16.Text = "StdDerivation";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(356, 51);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(51, 18);
            this.label15.TabIndex = 16;
            this.label15.Text = "Mean";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(198, 51);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(68, 18);
            this.label14.TabIndex = 15;
            this.label14.Text = "Progress";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(102, 51);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(67, 18);
            this.label13.TabIndex = 14;
            this.label13.Text = "Counter";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(50, 285);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(26, 17);
            this.label12.TabIndex = 13;
            this.label12.Text = "SS";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(50, 259);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(27, 17);
            this.label11.TabIndex = 12;
            this.label11.Text = "SR";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(50, 233);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(25, 17);
            this.label10.TabIndex = 11;
            this.label10.Text = "SL";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(51, 207);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(27, 17);
            this.label9.TabIndex = 10;
            this.label9.Text = "RS";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(52, 182);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(28, 17);
            this.label8.TabIndex = 9;
            this.label8.Text = "RR";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(51, 156);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(26, 17);
            this.label6.TabIndex = 8;
            this.label6.Text = "RL";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(51, 130);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(25, 17);
            this.label5.TabIndex = 7;
            this.label5.Text = "LS";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(52, 104);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(26, 17);
            this.label4.TabIndex = 6;
            this.label4.Text = "LR";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Controls.Add(this.pctT10);
            this.panel3.Controls.Add(this.progressT10);
            this.panel3.Controls.Add(this.trio10);
            this.panel3.Controls.Add(this.ct10);
            this.panel3.Controls.Add(this.pctT9);
            this.panel3.Controls.Add(this.label72);
            this.panel3.Controls.Add(this.progressT9);
            this.panel3.Controls.Add(this.label40);
            this.panel3.Controls.Add(this.pctT8);
            this.panel3.Controls.Add(this.label51);
            this.panel3.Controls.Add(this.progressT8);
            this.panel3.Controls.Add(this.trio1);
            this.panel3.Controls.Add(this.pctT7);
            this.panel3.Controls.Add(this.trio2);
            this.panel3.Controls.Add(this.progressT7);
            this.panel3.Controls.Add(this.trio3);
            this.panel3.Controls.Add(this.pctT6);
            this.panel3.Controls.Add(this.trio4);
            this.panel3.Controls.Add(this.progressT6);
            this.panel3.Controls.Add(this.trio5);
            this.panel3.Controls.Add(this.pctT5);
            this.panel3.Controls.Add(this.trio6);
            this.panel3.Controls.Add(this.progressT5);
            this.panel3.Controls.Add(this.trio7);
            this.panel3.Controls.Add(this.pctT4);
            this.panel3.Controls.Add(this.trio8);
            this.panel3.Controls.Add(this.progressT4);
            this.panel3.Controls.Add(this.trio9);
            this.panel3.Controls.Add(this.pctT3);
            this.panel3.Controls.Add(this.label41);
            this.panel3.Controls.Add(this.progressT3);
            this.panel3.Controls.Add(this.label39);
            this.panel3.Controls.Add(this.pctT2);
            this.panel3.Controls.Add(this.ct1);
            this.panel3.Controls.Add(this.progressT2);
            this.panel3.Controls.Add(this.ct2);
            this.panel3.Controls.Add(this.pctT1);
            this.panel3.Controls.Add(this.ct3);
            this.panel3.Controls.Add(this.progressT1);
            this.panel3.Controls.Add(this.ct4);
            this.panel3.Controls.Add(this.ct9);
            this.panel3.Controls.Add(this.ct5);
            this.panel3.Controls.Add(this.ct8);
            this.panel3.Controls.Add(this.ct6);
            this.panel3.Controls.Add(this.ct7);
            this.panel3.Location = new System.Drawing.Point(939, 119);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(372, 496);
            this.panel3.TabIndex = 29;
            // 
            // pctT10
            // 
            this.pctT10.AutoSize = true;
            this.pctT10.Location = new System.Drawing.Point(307, 323);
            this.pctT10.Name = "pctT10";
            this.pctT10.Size = new System.Drawing.Size(24, 17);
            this.pctT10.TabIndex = 126;
            this.pctT10.Text = "25";
            // 
            // progressT10
            // 
            this.progressT10.Location = new System.Drawing.Point(197, 325);
            this.progressT10.Name = "progressT10";
            this.progressT10.Size = new System.Drawing.Size(100, 16);
            this.progressT10.TabIndex = 125;
            // 
            // trio10
            // 
            this.trio10.AutoSize = true;
            this.trio10.Location = new System.Drawing.Point(35, 321);
            this.trio10.Name = "trio10";
            this.trio10.Size = new System.Drawing.Size(49, 17);
            this.trio10.TabIndex = 123;
            this.trio10.Text = "Trio10";
            // 
            // ct10
            // 
            this.ct10.AutoSize = true;
            this.ct10.Location = new System.Drawing.Point(103, 321);
            this.ct10.Name = "ct10";
            this.ct10.Size = new System.Drawing.Size(54, 17);
            this.ct10.TabIndex = 124;
            this.ct10.Text = "label28";
            // 
            // pctT9
            // 
            this.pctT9.AutoSize = true;
            this.pctT9.Location = new System.Drawing.Point(307, 298);
            this.pctT9.Name = "pctT9";
            this.pctT9.Size = new System.Drawing.Size(24, 17);
            this.pctT9.TabIndex = 122;
            this.pctT9.Text = "25";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.BackColor = System.Drawing.Color.White;
            this.label72.Font = new System.Drawing.Font("Century Gothic", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label72.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label72.Location = new System.Drawing.Point(18, 17);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(223, 19);
            this.label72.TabIndex = 0;
            this.label72.Text = "Top10 KeyGroup Trio Used";
            // 
            // progressT9
            // 
            this.progressT9.Location = new System.Drawing.Point(197, 299);
            this.progressT9.Name = "progressT9";
            this.progressT9.Size = new System.Drawing.Size(100, 16);
            this.progressT9.TabIndex = 113;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(195, 60);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(68, 18);
            this.label40.TabIndex = 94;
            this.label40.Text = "Progress";
            // 
            // pctT8
            // 
            this.pctT8.AutoSize = true;
            this.pctT8.Location = new System.Drawing.Point(307, 272);
            this.pctT8.Name = "pctT8";
            this.pctT8.Size = new System.Drawing.Size(24, 17);
            this.pctT8.TabIndex = 121;
            this.pctT8.Text = "25";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.Location = new System.Drawing.Point(22, 60);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(55, 18);
            this.label51.TabIndex = 83;
            this.label51.Text = "Group";
            // 
            // progressT8
            // 
            this.progressT8.Location = new System.Drawing.Point(197, 273);
            this.progressT8.Name = "progressT8";
            this.progressT8.Size = new System.Drawing.Size(100, 16);
            this.progressT8.TabIndex = 112;
            // 
            // trio1
            // 
            this.trio1.AutoSize = true;
            this.trio1.Location = new System.Drawing.Point(36, 87);
            this.trio1.Name = "trio1";
            this.trio1.Size = new System.Drawing.Size(41, 17);
            this.trio1.TabIndex = 84;
            this.trio1.Text = "Trio1";
            // 
            // pctT7
            // 
            this.pctT7.AutoSize = true;
            this.pctT7.Location = new System.Drawing.Point(307, 245);
            this.pctT7.Name = "pctT7";
            this.pctT7.Size = new System.Drawing.Size(24, 17);
            this.pctT7.TabIndex = 120;
            this.pctT7.Text = "25";
            // 
            // trio2
            // 
            this.trio2.AutoSize = true;
            this.trio2.Location = new System.Drawing.Point(36, 113);
            this.trio2.Name = "trio2";
            this.trio2.Size = new System.Drawing.Size(41, 17);
            this.trio2.TabIndex = 85;
            this.trio2.Text = "Trio2";
            // 
            // progressT7
            // 
            this.progressT7.Location = new System.Drawing.Point(197, 246);
            this.progressT7.Name = "progressT7";
            this.progressT7.Size = new System.Drawing.Size(100, 16);
            this.progressT7.TabIndex = 111;
            // 
            // trio3
            // 
            this.trio3.AutoSize = true;
            this.trio3.Location = new System.Drawing.Point(35, 139);
            this.trio3.Name = "trio3";
            this.trio3.Size = new System.Drawing.Size(41, 17);
            this.trio3.TabIndex = 86;
            this.trio3.Text = "Trio3";
            // 
            // pctT6
            // 
            this.pctT6.AutoSize = true;
            this.pctT6.Location = new System.Drawing.Point(307, 219);
            this.pctT6.Name = "pctT6";
            this.pctT6.Size = new System.Drawing.Size(24, 17);
            this.pctT6.TabIndex = 119;
            this.pctT6.Text = "25";
            // 
            // trio4
            // 
            this.trio4.AutoSize = true;
            this.trio4.Location = new System.Drawing.Point(35, 165);
            this.trio4.Name = "trio4";
            this.trio4.Size = new System.Drawing.Size(41, 17);
            this.trio4.TabIndex = 87;
            this.trio4.Text = "Trio4";
            // 
            // progressT6
            // 
            this.progressT6.Location = new System.Drawing.Point(197, 220);
            this.progressT6.Name = "progressT6";
            this.progressT6.Size = new System.Drawing.Size(100, 16);
            this.progressT6.TabIndex = 110;
            // 
            // trio5
            // 
            this.trio5.AutoSize = true;
            this.trio5.Location = new System.Drawing.Point(36, 191);
            this.trio5.Name = "trio5";
            this.trio5.Size = new System.Drawing.Size(41, 17);
            this.trio5.TabIndex = 88;
            this.trio5.Text = "Trio5";
            // 
            // pctT5
            // 
            this.pctT5.AutoSize = true;
            this.pctT5.Location = new System.Drawing.Point(307, 192);
            this.pctT5.Name = "pctT5";
            this.pctT5.Size = new System.Drawing.Size(24, 17);
            this.pctT5.TabIndex = 118;
            this.pctT5.Text = "25";
            // 
            // trio6
            // 
            this.trio6.AutoSize = true;
            this.trio6.Location = new System.Drawing.Point(35, 216);
            this.trio6.Name = "trio6";
            this.trio6.Size = new System.Drawing.Size(41, 17);
            this.trio6.TabIndex = 89;
            this.trio6.Text = "Trio6";
            // 
            // progressT5
            // 
            this.progressT5.Location = new System.Drawing.Point(197, 193);
            this.progressT5.Name = "progressT5";
            this.progressT5.Size = new System.Drawing.Size(100, 16);
            this.progressT5.TabIndex = 109;
            // 
            // trio7
            // 
            this.trio7.AutoSize = true;
            this.trio7.Location = new System.Drawing.Point(34, 242);
            this.trio7.Name = "trio7";
            this.trio7.Size = new System.Drawing.Size(41, 17);
            this.trio7.TabIndex = 90;
            this.trio7.Text = "Trio7";
            // 
            // pctT4
            // 
            this.pctT4.AutoSize = true;
            this.pctT4.Location = new System.Drawing.Point(307, 166);
            this.pctT4.Name = "pctT4";
            this.pctT4.Size = new System.Drawing.Size(24, 17);
            this.pctT4.TabIndex = 117;
            this.pctT4.Text = "25";
            // 
            // trio8
            // 
            this.trio8.AutoSize = true;
            this.trio8.Location = new System.Drawing.Point(34, 268);
            this.trio8.Name = "trio8";
            this.trio8.Size = new System.Drawing.Size(41, 17);
            this.trio8.TabIndex = 91;
            this.trio8.Text = "Trio8";
            // 
            // progressT4
            // 
            this.progressT4.Location = new System.Drawing.Point(197, 167);
            this.progressT4.Name = "progressT4";
            this.progressT4.Size = new System.Drawing.Size(100, 16);
            this.progressT4.TabIndex = 108;
            // 
            // trio9
            // 
            this.trio9.AutoSize = true;
            this.trio9.Location = new System.Drawing.Point(34, 294);
            this.trio9.Name = "trio9";
            this.trio9.Size = new System.Drawing.Size(41, 17);
            this.trio9.TabIndex = 92;
            this.trio9.Text = "Trio9";
            // 
            // pctT3
            // 
            this.pctT3.AutoSize = true;
            this.pctT3.Location = new System.Drawing.Point(307, 140);
            this.pctT3.Name = "pctT3";
            this.pctT3.Size = new System.Drawing.Size(24, 17);
            this.pctT3.TabIndex = 116;
            this.pctT3.Text = "25";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(99, 60);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(67, 18);
            this.label41.TabIndex = 93;
            this.label41.Text = "Counter";
            // 
            // progressT3
            // 
            this.progressT3.Location = new System.Drawing.Point(197, 141);
            this.progressT3.Name = "progressT3";
            this.progressT3.Size = new System.Drawing.Size(100, 16);
            this.progressT3.TabIndex = 107;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(310, 60);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(21, 18);
            this.label39.TabIndex = 95;
            this.label39.Text = "%";
            // 
            // pctT2
            // 
            this.pctT2.AutoSize = true;
            this.pctT2.Location = new System.Drawing.Point(307, 114);
            this.pctT2.Name = "pctT2";
            this.pctT2.Size = new System.Drawing.Size(24, 17);
            this.pctT2.TabIndex = 115;
            this.pctT2.Text = "25";
            // 
            // ct1
            // 
            this.ct1.AutoSize = true;
            this.ct1.Location = new System.Drawing.Point(103, 87);
            this.ct1.Name = "ct1";
            this.ct1.Size = new System.Drawing.Size(35, 17);
            this.ct1.TabIndex = 96;
            this.ct1.Text = "ctLL";
            // 
            // progressT2
            // 
            this.progressT2.Location = new System.Drawing.Point(197, 115);
            this.progressT2.Name = "progressT2";
            this.progressT2.Size = new System.Drawing.Size(100, 16);
            this.progressT2.TabIndex = 106;
            // 
            // ct2
            // 
            this.ct2.AutoSize = true;
            this.ct2.Location = new System.Drawing.Point(103, 113);
            this.ct2.Name = "ct2";
            this.ct2.Size = new System.Drawing.Size(54, 17);
            this.ct2.TabIndex = 97;
            this.ct2.Text = "label19";
            // 
            // pctT1
            // 
            this.pctT1.AutoSize = true;
            this.pctT1.Location = new System.Drawing.Point(307, 88);
            this.pctT1.Name = "pctT1";
            this.pctT1.Size = new System.Drawing.Size(24, 17);
            this.pctT1.TabIndex = 114;
            this.pctT1.Text = "25";
            // 
            // ct3
            // 
            this.ct3.AutoSize = true;
            this.ct3.Location = new System.Drawing.Point(103, 139);
            this.ct3.Name = "ct3";
            this.ct3.Size = new System.Drawing.Size(54, 17);
            this.ct3.TabIndex = 98;
            this.ct3.Text = "label20";
            // 
            // progressT1
            // 
            this.progressT1.Location = new System.Drawing.Point(197, 88);
            this.progressT1.Name = "progressT1";
            this.progressT1.Size = new System.Drawing.Size(100, 16);
            this.progressT1.TabIndex = 105;
            this.progressT1.Value = 25;
            // 
            // ct4
            // 
            this.ct4.AutoSize = true;
            this.ct4.Location = new System.Drawing.Point(103, 165);
            this.ct4.Name = "ct4";
            this.ct4.Size = new System.Drawing.Size(54, 17);
            this.ct4.TabIndex = 99;
            this.ct4.Text = "label21";
            // 
            // ct9
            // 
            this.ct9.AutoSize = true;
            this.ct9.Location = new System.Drawing.Point(103, 294);
            this.ct9.Name = "ct9";
            this.ct9.Size = new System.Drawing.Size(54, 17);
            this.ct9.TabIndex = 104;
            this.ct9.Text = "label28";
            // 
            // ct5
            // 
            this.ct5.AutoSize = true;
            this.ct5.Location = new System.Drawing.Point(103, 191);
            this.ct5.Name = "ct5";
            this.ct5.Size = new System.Drawing.Size(54, 17);
            this.ct5.TabIndex = 100;
            this.ct5.Text = "label22";
            // 
            // ct8
            // 
            this.ct8.AutoSize = true;
            this.ct8.Location = new System.Drawing.Point(103, 268);
            this.ct8.Name = "ct8";
            this.ct8.Size = new System.Drawing.Size(54, 17);
            this.ct8.TabIndex = 103;
            this.ct8.Text = "label26";
            // 
            // ct6
            // 
            this.ct6.AutoSize = true;
            this.ct6.Location = new System.Drawing.Point(103, 216);
            this.ct6.Name = "ct6";
            this.ct6.Size = new System.Drawing.Size(54, 17);
            this.ct6.TabIndex = 101;
            this.ct6.Text = "label23";
            // 
            // ct7
            // 
            this.ct7.AutoSize = true;
            this.ct7.Location = new System.Drawing.Point(103, 242);
            this.ct7.Name = "ct7";
            this.ct7.Size = new System.Drawing.Size(54, 17);
            this.ct7.TabIndex = 102;
            this.ct7.Text = "label25";
            // 
            // Dashboard2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightGray;
            this.ClientSize = new System.Drawing.Size(1323, 657);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.headerpanel);
            this.Controls.Add(this.sidepanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "Dashboard2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "IAmTA - TP1";
            this.sidepanel.ResumeLayout(false);
            this.titlepanel.ResumeLayout(false);
            this.titlepanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.headerpanel.ResumeLayout(false);
            this.headerpanel.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel sidepanel;
        private System.Windows.Forms.Panel titlepanel;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label title;
        private System.Windows.Forms.Panel headerpanel;
        private System.Windows.Forms.Button KeyStrokeEventsButton;
        private System.Windows.Forms.Button SaveButton;
        private System.Windows.Forms.Button WordsAnalysisButton;
        private System.Windows.Forms.Button DigraphEventsButton;
        private System.Windows.Forms.Button BackButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label stdDigraph;
        private System.Windows.Forms.Label meanDigraph;
        private System.Windows.Forms.Label counterSS;
        private System.Windows.Forms.Label counterSR;
        private System.Windows.Forms.Label counterSL;
        private System.Windows.Forms.Label counterRS;
        private System.Windows.Forms.Label counterRR;
        private System.Windows.Forms.Label counterRL;
        private System.Windows.Forms.Label counterLS;
        private System.Windows.Forms.Label counterLR;
        private System.Windows.Forms.Label counterLL;
        private System.Windows.Forms.ProgressBar progressBar9;
        private System.Windows.Forms.ProgressBar progressBar8;
        private System.Windows.Forms.ProgressBar progressBar7;
        private System.Windows.Forms.ProgressBar progressBar6;
        private System.Windows.Forms.ProgressBar progressBar5;
        private System.Windows.Forms.ProgressBar progressBar4;
        private System.Windows.Forms.ProgressBar progressBar3;
        private System.Windows.Forms.ProgressBar progressBar2;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Label stdSS;
        private System.Windows.Forms.Label stdSR;
        private System.Windows.Forms.Label stdSL;
        private System.Windows.Forms.Label stdRS;
        private System.Windows.Forms.Label stdRR;
        private System.Windows.Forms.Label stdRL;
        private System.Windows.Forms.Label stdLS;
        private System.Windows.Forms.Label stdLR;
        private System.Windows.Forms.Label stdLL;
        private System.Windows.Forms.Label meanSS;
        private System.Windows.Forms.Label meanSR;
        private System.Windows.Forms.Label meanSL;
        private System.Windows.Forms.Label meanRS;
        private System.Windows.Forms.Label meanRR;
        private System.Windows.Forms.Label meanRL;
        private System.Windows.Forms.Label meanLS;
        private System.Windows.Forms.Label meanLR;
        private System.Windows.Forms.Label meanLL;
        private System.Windows.Forms.Label pct9;
        private System.Windows.Forms.Label pct8;
        private System.Windows.Forms.Label pct7;
        private System.Windows.Forms.Label pct6;
        private System.Windows.Forms.Label pct5;
        private System.Windows.Forms.Label pct4;
        private System.Windows.Forms.Label pct3;
        private System.Windows.Forms.Label pct2;
        private System.Windows.Forms.Label pct1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label pctT10;
        private System.Windows.Forms.ProgressBar progressT10;
        private System.Windows.Forms.Label trio10;
        private System.Windows.Forms.Label ct10;
        private System.Windows.Forms.Label pctT9;
        private System.Windows.Forms.ProgressBar progressT9;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label pctT8;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.ProgressBar progressT8;
        private System.Windows.Forms.Label trio1;
        private System.Windows.Forms.Label pctT7;
        private System.Windows.Forms.Label trio2;
        private System.Windows.Forms.ProgressBar progressT7;
        private System.Windows.Forms.Label trio3;
        private System.Windows.Forms.Label pctT6;
        private System.Windows.Forms.Label trio4;
        private System.Windows.Forms.ProgressBar progressT6;
        private System.Windows.Forms.Label trio5;
        private System.Windows.Forms.Label pctT5;
        private System.Windows.Forms.Label trio6;
        private System.Windows.Forms.ProgressBar progressT5;
        private System.Windows.Forms.Label trio7;
        private System.Windows.Forms.Label pctT4;
        private System.Windows.Forms.Label trio8;
        private System.Windows.Forms.ProgressBar progressT4;
        private System.Windows.Forms.Label trio9;
        private System.Windows.Forms.Label pctT3;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.ProgressBar progressT3;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label pctT2;
        private System.Windows.Forms.Label ct1;
        private System.Windows.Forms.ProgressBar progressT2;
        private System.Windows.Forms.Label ct2;
        private System.Windows.Forms.Label pctT1;
        private System.Windows.Forms.Label ct3;
        private System.Windows.Forms.ProgressBar progressT1;
        private System.Windows.Forms.Label ct4;
        private System.Windows.Forms.Label ct9;
        private System.Windows.Forms.Label ct5;
        private System.Windows.Forms.Label ct8;
        private System.Windows.Forms.Label ct6;
        private System.Windows.Forms.Label ct7;
    }
}