﻿using IAmTA___TP1.src;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IAmTA___TP1
{
    public partial class Dashboard1 : Form
    {
        private static Class1 programa = null;

        public Dashboard1()
        {
            InitializeComponent();
        }

        public void CarregaDados(Class1 p)
        {
            programa = p;
            int total = programa.getTotalCharacters();
            int backspaces = programa.getNumBackSpaces();
            totalCharacteres.Text = total.ToString();
            totalBackSpace.Text = backspaces.ToString();
            progressBackspace.Value = Convert.ToInt32((backspaces / (double)total) * 100);
            pctBackspace.Text = ((backspaces / (double)total) * 100).ToString("F2");
            Dictionary<string, int> top10 = programa.getTop10Chars();

            
            char1.Text = top10.ElementAt(0).Key; totalCh1.Text = (top10.ElementAt(0).Value).ToString();
            progressBar1.Value = Convert.ToInt32((top10.ElementAt(0).Value / (double)total) * 100);
            pct1.Text = ((top10.ElementAt(0).Value / (double)total) * 100).ToString("F2");

            char2.Text = top10.ElementAt(1).Key; totalCh2.Text = (top10.ElementAt(1).Value).ToString();
            progressBar2.Value = Convert.ToInt32((top10.ElementAt(1).Value / (double)total) * 100);
            pct2.Text = ((top10.ElementAt(1).Value / (double)total) * 100).ToString("F2");

            char3.Text = top10.ElementAt(2).Key; totalCh3.Text = (top10.ElementAt(2).Value).ToString();
            progressBar3.Value = Convert.ToInt32((top10.ElementAt(2).Value / (double)total) * 100);
            pct3.Text = ((top10.ElementAt(2).Value / (double)total) * 100).ToString("F2");

            char4.Text = top10.ElementAt(3).Key; totalCh4.Text = (top10.ElementAt(3).Value).ToString();
            progressBar4.Value = Convert.ToInt32((top10.ElementAt(3).Value / (double)total) * 100);
            pct4.Text = ((top10.ElementAt(3).Value / (double)total) * 100).ToString("F2");

            char5.Text = top10.ElementAt(4).Key; totalCh5.Text = (top10.ElementAt(4).Value).ToString();
            progressBar5.Value = Convert.ToInt32((top10.ElementAt(4).Value / (double)total) * 100);
            pct5.Text = ((top10.ElementAt(4).Value / (double)total) * 100).ToString("F2");

            char6.Text = top10.ElementAt(5).Key; totalCh6.Text = (top10.ElementAt(5).Value).ToString();
            progressBar6.Value = Convert.ToInt32((top10.ElementAt(5).Value / (double)total) * 100);
            pct6.Text = ((top10.ElementAt(5).Value / (double)total) * 100).ToString("F2");

            char7.Text = top10.ElementAt(6).Key; totalCh7.Text = (top10.ElementAt(6).Value).ToString();
            progressBar7.Value = Convert.ToInt32((top10.ElementAt(6).Value / (double)total) * 100);
            pct7.Text = ((top10.ElementAt(6).Value / (double)total) * 100).ToString("F2");

            char8.Text = top10.ElementAt(7).Key; totalCh8.Text = (top10.ElementAt(7).Value).ToString();
            progressBar8.Value = Convert.ToInt32((top10.ElementAt(7).Value / (double)total) * 100);
            pct8.Text = ((top10.ElementAt(7).Value / (double)total) * 100).ToString("F2");

            char9.Text = top10.ElementAt(8).Key; totalCh9.Text = (top10.ElementAt(8).Value).ToString();
            progressBar9.Value = Convert.ToInt32((top10.ElementAt(8).Value / (double)total) * 100);
            pct9.Text = ((top10.ElementAt(8).Value / (double)total) * 100).ToString("F2");

            char10.Text = top10.ElementAt(9).Key; totalCh10.Text = (top10.ElementAt(9).Value).ToString();
            progressBar10.Value = Convert.ToInt32((top10.ElementAt(9).Value / (double)total) * 100);
            pct10.Text = ((top10.ElementAt(9).Value / (double)total) * 100).ToString("F2");

        }


        private void DigraphEventsButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Dashboard2 d2 = new Dashboard2();
            d2.CarregaDados(programa);
            d2.ShowDialog();
        }

        private void WordsAnalysisButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Dashboard3 d3 = new Dashboard3();
            d3.CarregaDados(programa);
            d3.ShowDialog();
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Dashboard0 d0 = new Dashboard0();
            d0.ShowDialog();
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            DashboardSave d = new DashboardSave();
            d.CarregaDados(programa);
            d.ShowDialog();
        }
    }
}
