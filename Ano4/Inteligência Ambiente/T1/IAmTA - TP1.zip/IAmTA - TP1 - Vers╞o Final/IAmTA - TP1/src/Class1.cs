﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;

namespace IAmTA___TP1.src
{

    public class Class1
    {
        /** 
         * Lista com as linhas dos logs lidos
        **/
        private static List<string> logs = null;
        /** 
         * Lista com as linhas dos logs modificadas;
         **/
        private static List<string> mod_logs = null;
        /**
        * Dicionário com a chave o par e o valor total do seu timestamp
        **/
        private static Dictionary<string, double> pair_time = null;
        /**
         * Dicionário com a chave o par e o valor total das suas ocurrências
        **/
        private static Dictionary<string, double> pair_occurrence = null;
        /**
         * Dicionário com a chave a letra e o valor numero de ocurrências;
        **/
        private static Dictionary<string, int> number_characters = null;

        /* pairs */
        private static Dictionary<String, double> mean_for_grouppair = null;
        private static Dictionary<String, double> std_for_grouppair = null;

        /* words */
        private static List<string> listWords = null;
        private static Dictionary<string, double> dictionaryTop10Words = null;
        private static Dictionary<string, double> dictionaryBackSpaceWords = null;
        private static Dictionary<int, string> dictionaryBSWordsByNumChar = null;
        private static Dictionary<string, double> dictionaryWordsTime = null;
        private static Dictionary<int, string> dictionaryWordsTByNumChar = null;
        private static Dictionary<string, double> median_for_Words = null;

        /* trios */
        private static List<string> mod_logs_Trio = null;
        private static Dictionary<string, double> median_for_trio = null;
        private static Dictionary<string, double> trio_time = null;
        private static Dictionary<string, double> trio_occurrence = null;
        private static Dictionary<string, double> std_for_trio = null; 


        private static int number_BackSpaces;

        /* Construtor da classe */
        public Class1(String filepath)
        {
            using (StreamReader reader = new StreamReader(filepath))
            {
                logs = new List<String>();
                number_characters = new Dictionary<string, int>();

                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    logs.Add(line); // Add to logs
                    string aux = line;
                    string[] f = aux.Split(':');


                    if (!number_characters.ContainsKey(f[2]))
                        number_characters.Add(f[2], 1); // Add to Dictionary character-occurence
                    else number_characters[f[2]]++;


                    if (Check_BackSpace(f[2]))
                        number_BackSpaces++;
                }
            }
        }

        /** -- GETS -- **/

        /* Get Logs */
        public List<string> getLogs()
        {
            List<string> list = new List<string>();

            foreach (string st in logs)
            {
                list.Add(st);
            }

            return list;
        }
        /* Get Total Characteres */
        public int getTotalCharacters()
        {
            return logs.Count;
        }
        /* Get Backspaces */
        public int getNumBackSpaces()
        {
            return number_BackSpaces;
        }
        /*Get Counter KeyGroup */
        public double getCounterPair(String s)
        {
            if (pair_occurrence.ContainsKey(s))
            {
                return (pair_occurrence[s]);
            }
            return 0;
        }
        /* Get Counter of pairs */
        public int getTotalPairs()
        {
            return mod_logs.Count;
        }
        /* Get Mean of a pair*/
        public double getMeanOfPair(String s)
        {
            if (mean_for_grouppair.ContainsKey(s))
            {
                return (mean_for_grouppair[s]);
            }
            return 0;
        }
        public double getStdOfPair(String s)
        {
            if (std_for_grouppair.ContainsKey(s))
            {
                return std_for_grouppair[s];
            }
            return 0;
        }

        /** -- Methods -- **/

        /* Get Mean Writting Time based in all Events */
        public double getMeanWrittingTime()
        {
            int total = 0;

            foreach (string s in mod_logs)
            {
                string[] f = s.Split(':');
                int time = Convert.ToInt32(f[0]);

                total += time;
            }

            double mean = total / (double)(logs.Count - 1);

            return mean;
        }
        /* Get STd Writting Time based in all Event */
        public double getStdWritingTime()
        {
            long total = 0;
            double std = 0;

            int mean = Convert.ToInt32(getMeanWrittingTime());

            foreach (string s in mod_logs)
            {
                string[] f = s.Split(':');
                int time = Convert.ToInt32(f[0]);

                total += (time - mean) * (time - mean);
            }

            std = total / (double)(logs.Count - 1);

            return Math.Sqrt(std);
        }
        /* Get Mean Writting Time based in all words */
        public double getWordsMeanWrittingTime()
        {
            double total = 0;

            foreach (KeyValuePair<string, double> word in median_for_Words)
            {
                total += word.Value;
            }

            double mean = total / (double)(median_for_Words.Count - 1);

            return mean;
        }
        /* Get Std Writting Time base in all words */
        public double getWordsStdWrittingTime()
        {
            double total = 0;

            double mean = getWordsMeanWrittingTime();

            foreach (KeyValuePair<string, double> word in median_for_Words)
            {
                total += (word.Value - mean) * (word.Value - mean);
            }

            mean = total / (double)(median_for_Words.Count - 1);

            return Math.Sqrt(mean);
        }
        /* Get top 10 Chars, more used*/
        public Dictionary<string, int> getTop10Chars()
        {
            Dictionary<string, int> ct = new Dictionary<string, int>();

            foreach (KeyValuePair<string, int> item in number_characters.OrderByDescending(key => key.Value).Take(10))
            {
                ct.Add(item.Key, item.Value);
            }

            return ct;
        }
        /* Get std Writting based in all events */
        public double getStdKeyGroup()
        {
            double mean = getMeanWrittingTime();
            double acum = 0;

            foreach (string s in mod_logs)
            {
                string[] f = s.Split(':');
                int time = Convert.ToInt32(f[0]);

                acum += (time - mean)*(time -mean);
            }

            double stdDer = Math.Sqrt(acum / (mod_logs.Count - 1));
            return stdDer;

        }

        /* Check Left */
        static bool CheckLeft(string s)
        {
            bool result = false;

            if (s.Equals("Escape") || s.Equals("Tab") || s.Equals("Oem5") ||
               s.Equals("1") || s.Equals("2") || s.Equals("3") || s.Equals("4") ||
               s.Equals("5") || s.Equals("Q") || s.Equals("W") || s.Equals("E") ||
               s.Equals("R") || s.Equals("T") || s.Equals("A") || s.Equals("S") ||
               s.Equals("D") || s.Equals("F") || s.Equals("G") || s.Equals("Z") ||
               s.Equals("X") || s.Equals("C") || s.Equals("V") || s.Equals("OemBackSlash"))
            {
                result = true;
            }
            return result;
        }
        /* Check Space */
        static bool CheckSpace(string s)
        {
            bool result = false;

            if (s.Equals("Space"))
            {
                result = true;
            }
            return result;
        }
        /* Check BackSpace */
        static bool Check_BackSpace(string s)
        {
            bool r = false;
            if (s == "Anterior")
                r = true;

            return r;
        }
        /* Check Delimiter */
        static bool Check_Delimiter(string s)
        {
            bool r = false;
            if (s == "Oemcomma" || s == "OemPeriod" || s == "Tab" ||
                s == "Enter" || s == "Space")
                r = true;

            return r;
        }
        /* Check CharacterPlus */
        static bool Check_CharacterPlus(string s)
        {
            bool r = false;
            if (Regex.IsMatch(s, @"^[A-Z]$") || s == "OemMinus" || s == "Oemplus"
                || s == "OemOpenBrackets" || s == "Oem7" || s == "Oem6")
                r = true;

            return r;
        }

        /** -- Methods for pairs -- **/
        public void PairAndModLogs()
        {
            int i;

            mod_logs = new List<string>();
            pair_time = new Dictionary<string, double>();
            pair_occurrence = new Dictionary<string, double>();

            string current_timestamp = null;
            string current_letter = null;

            for (i = 1; i < logs.Count; i++)
            {
                string[] f = logs[i - 1].Split(':');
                current_timestamp = f[0]; current_letter = f[2];

                string t1 = current_timestamp;
                string l1 = current_letter;
                string[] g = logs[i].Split(':');

                current_timestamp = g[0]; current_letter = g[2];
                string t2 = current_timestamp;
                string l2 = current_letter;

                double timestamp1 = Double.Parse(t1);
                double timestamp2 = Double.Parse(t2);

                double r = timestamp2 - timestamp1;

                char maol1, maol2;

                //Verifica a qual parte corresponde
                if (CheckLeft(l1) == true)
                {
                    maol1 = 'L';
                }
                else if (CheckSpace(l1) == true)
                {
                    maol1 = 'S';
                }
                else
                {
                    maol1 = 'R';
                }

                if (CheckLeft(l2) == true)
                {
                    maol2 = 'L';
                }
                else if (CheckSpace(l2) == true)
                {
                    maol2 = 'S';
                }
                else
                {
                    maol2 = 'R';
                }

                string timestamp = Convert.ToString(r);
                char[] letters = { maol1, '-', maol2 };
                string pair = new string(letters);
                string result = timestamp + ":" + pair;
                //Adiciona ao log
                mod_logs.Add(result);

                //Adição do tempo
                if (!pair_time.ContainsKey(pair))
                {
                    pair_time.Add(pair, Double.Parse(timestamp));
                    pair_occurrence.Add(pair, 1);
                }
                else
                {
                    pair_time[pair] += Double.Parse(timestamp);
                    pair_occurrence[pair] += 1;
                }
            }

        }
        /* Mean of all pairs */
        public void keyGroupPairMedian()
        {
            mean_for_grouppair = new Dictionary<string, double>();
            foreach (KeyValuePair<string, double> pair in pair_time) // EX: R-L , Tempo
            {
                var keyvalue = new KeyValuePair<string, double>(pair.Key, pair_occurrence[pair.Key]);
                double median = (pair.Value / keyvalue.Value);
                mean_for_grouppair.Add(pair.Key, median);
            }

        }
        /* Get Std Writting Time for all pairs */
        public void StandardDerivationKeyGroupPairEvents()
        {
            int i;

            std_for_grouppair = new Dictionary<String, double>();

            string current_timestamp = null;
            string current_letter = null;

            for (i = 0; i < mod_logs.Count; i++)
            {
                string[] f = mod_logs[i].Split(':');
                current_timestamp = f[0];
                current_letter = f[1];
                double median = mean_for_grouppair[current_letter];
                double time = Double.Parse(current_timestamp);
                double dif = time - median;

                if (!std_for_grouppair.ContainsKey(current_letter))
                    std_for_grouppair.Add(current_letter, dif * dif);
                else
                    std_for_grouppair[current_letter] += dif * dif;

            }
            foreach(KeyValuePair<string,double> pair in pair_occurrence)
            {
                current_letter = pair.Key;
                std_for_grouppair[current_letter] = Math.Sqrt(std_for_grouppair[current_letter]/pair.Value);
            }
        }

        /**--  Methods for words -- **/
        /* Identify and save words */
        public void Words()
        {

            int i;
            /* Lista para os carateres */
            List<string> characters = null;
            /* Lista para os tempos */
            List<string> time = null;
            /* Lista para a flag do backspace */
            List<string> backspaces = null;
            /* Flag backspace(utilizado-1 |não utilizado-0) */
            int backspace = 0;
            /* Lista que regista tudo do log */
            List<string> logger = new List<string>();

            listWords = new List<string>();

            /*----------------Tratamento dos dados vindos do Log --------------- */

            for (i = 0; i < logs.Count; i++)
            {
                string[] f = logs[i].Split(':');

                if ((i + 1) != logs.Count) // se não estamos na ultima posição..
                {
                    string[] f2 = logs[i + 1].Split(':');

                    if (Check_Delimiter(f[2]))
                        logger.Add(f[2]);

                    if (Check_BackSpace(f[2])) // se for para apagar i.e Anterior carater
                    {

                        if (characters.Count != 0 && time.Count != 0) // houver elementos a apagar
                        {
                            if (backspaces.Count != 0)
                            { // apaga 2 vezes pelos terminadores (;)

                                if (!Check_Delimiter(logger[logger.Count - 1]))
                                {
                                    if (characters[characters.Count - 1] == ";")
                                    {
                                        backspaces.RemoveAt(backspaces.Count - 1);
                                        backspaces.RemoveAt(backspaces.Count - 1);
                                        characters.RemoveAt(characters.Count - 1);
                                        characters.RemoveAt(characters.Count - 1);
                                        time.RemoveAt(time.Count - 1);
                                        time.RemoveAt(time.Count - 1);
                                        logger.RemoveAt(logger.Count - 1);
                                    }
                                    else
                                    {
                                        characters.RemoveAt(characters.Count - 1);
                                        time.RemoveAt(time.Count - 1);
                                        logger.RemoveAt(logger.Count - 1);
                                    }
                                }
                                else logger.RemoveAt(logger.Count - 1);
                            }
                            else
                            {
                                logger.RemoveAt(logger.Count - 1);
                                characters.RemoveAt(characters.Count - 1);
                                time.RemoveAt(time.Count - 1);
                            }
                            backspace = 1;

                        }
                    }
                    if (Check_Delimiter(f[2]) && Check_CharacterPlus(f2[2]))
                    {
                        characters.Add(";");
                        backspaces.Add(backspace.ToString());
                        backspaces.Add(";");
                        time.Add(";");

                        // RESET
                        backspace = 0;
                    }
                    if (Check_CharacterPlus(f[2]))
                    {
                        if (backspaces == null)
                            backspaces = new List<string>();
                        if (characters == null)
                            characters = new List<string>();
                        if (time == null)
                            time = new List<string>();

                        time.Add(f[0]);
                        if (f[2].Equals("OemMinus")) characters.Add("-");
                        else characters.Add(f[2]);
                        logger.Add(f[2]);
                    }
                }
                else // se é a ultima posição
                {

                    if (Check_Delimiter(f[2]))
                    {
                        characters.Add(";");
                        backspaces.Add(backspace.ToString());
                        backspaces.Add(";");
                        time.Add(";");

                        // RESET
                        backspace = 0;
                    }
                    if (Check_CharacterPlus(f[2]))
                    {
                        if (backspaces == null)
                            backspaces = new List<string>();
                        if (characters == null)
                            characters = new List<string>();
                        if (time == null)
                            time = new List<string>();

                        time.Add(f[0]);
                        if (f[2].Equals("OemMinus")) characters.Add("-");
                        else characters.Add(f[2]);
                        logger.Add(f[2]);
                    }
                }
            }


            /* -----------------------Preenchimento na lista --------------------- */

            int ind = 0;
            int b = 0;
            string word = null;
            int j;

            for (j = 0; j < time.Count; j++)
            {

                if (time[j] == ";")
                {
                    double first_time = Double.Parse(time[ind]);
                    double second_time = Double.Parse(time[j - 1]);
                    double timestamp = (second_time - first_time);
                    string result = Convert.ToString(timestamp) + ","
                                    + word + "," + Convert.ToString(backspaces[b])
                                    + "," + Convert.ToString(word.Length);
                    listWords.Add(result);
                    //RESET
                    ind = j + 1;
                    word = null;
                    b += 2;
                }
                else word += characters[j];
            }

        }
        public void StoreWordsRelated()
        {
            dictionaryWordsTime = new Dictionary<string, double>();
            dictionaryTop10Words = new Dictionary<string, double>();
            dictionaryBackSpaceWords = new Dictionary<string, double>();
            dictionaryWordsTByNumChar = new Dictionary<int, string>();
            dictionaryBSWordsByNumChar = new Dictionary<int, string>();

            int i;
            for (i = 0; i < listWords.Count; i++)
            {
                string[] f = listWords[i].Split(',');
                if (!dictionaryWordsTime.ContainsKey(f[1]))
                    dictionaryWordsTime.Add(f[1], Double.Parse(f[0]));
                else dictionaryWordsTime[f[1]] += Double.Parse(f[0]);

                if (!dictionaryTop10Words.ContainsKey(f[1]))
                    dictionaryTop10Words.Add(f[1], 1);
                else dictionaryTop10Words[f[1]]++;

                if (f[2] == "1")
                {
                    if (!dictionaryBackSpaceWords.ContainsKey(f[1]))
                        dictionaryBackSpaceWords.Add(f[1], 1);
                    else
                        dictionaryBackSpaceWords[f[1]]++;

                    if ((int)Double.Parse(f[3]) >= 2)
                    {
                        if (!dictionaryWordsTByNumChar.ContainsKey((int)Double.Parse(f[3])))
                        {
                            string result = f[1] + ":" + f[0];
                            dictionaryWordsTByNumChar.Add((int)Double.Parse(f[3]), result);
                        }
                        else
                        {
                            string[] g = dictionaryWordsTByNumChar[(int)Double.Parse(f[3])].Split(':');
                            double num = Double.Parse(g[1]) + Double.Parse(f[0]);
                            string result = g[0] + "," + f[1] + ":" + Convert.ToString(num);
                            dictionaryWordsTByNumChar[(int)Double.Parse(f[3])] = result;
                        }

                        if (!dictionaryBSWordsByNumChar.ContainsKey((int)Double.Parse(f[3])))
                        {
                            string result = f[1] + ":" + "1";
                            dictionaryBSWordsByNumChar.Add((int)Double.Parse(f[3]), result);
                        }
                        else
                        {
                            string[] g = dictionaryBSWordsByNumChar[(int)Double.Parse(f[3])].Split(':');
                            int num = (int)Double.Parse(g[1]) + 1;
                            string result = g[0] + "," + f[1] + ":" + Convert.ToString(num);
                            dictionaryBSWordsByNumChar[(int)Double.Parse(f[3])] = result;
                        }

                    }
                }
            }
        }

        /** Gets for words **/

        /* Top 10 words more used */
        public Dictionary<String, double> getTop10Words()
        {
            Dictionary<String, double> top10 = new Dictionary<string, double>();
            
            foreach (KeyValuePair<string, double> item in dictionaryTop10Words.OrderByDescending(key => key.Value).Take(10))
            {
                top10.Add(item.Key, item.Value);
            }

            return top10;
        }

        public Dictionary<string, double> getDictionaryWords()
        {
            return dictionaryTop10Words;
        }

        public Dictionary<string, double> getDictionaryBackSpaceWords()
        {
            return dictionaryBackSpaceWords;
        }

        public Dictionary<string, double> getDictionaryWordsMedian()
        {
            return median_for_Words;
        }

        public Dictionary<string, double> getDictionaryPairs()
        {
            return pair_occurrence;
        }

        public Dictionary<string, double> getDictionaryPairMean()
        {
            return mean_for_grouppair;
        }

        public Dictionary<string, double> getDictionaryPairStd()
        {
            return std_for_grouppair;
        }

        public int getTotalWords()
        {
            return listWords.Count;
        }

        public int getNumBackSpaceWords()
        {
            return dictionaryBackSpaceWords.Count;
        }
        /* Mean based in all words, and store for all words */
        public double wordsMean()
        {
            double mean = 0;
            median_for_Words = new Dictionary<string, double>();

            foreach (KeyValuePair<string, double> pair in dictionaryWordsTime)
            {
                mean += (pair.Value / (double)listWords.Count);
                median_for_Words.Add(pair.Key, (pair.Value / (double)listWords.Count));
            }

            return mean;

        }
        /* Std based in all words */
        public double StandardDerivationWords()
        {
            double mean = wordsMean();
            double acum = 0;

            foreach (KeyValuePair<string, double> pair in dictionaryWordsTime)
            {
                acum += (pair.Value - mean) * (pair.Value - mean);
            }

            double stdDer = 0;
            if (dictionaryWordsTime.Count > 1) stdDer = Math.Sqrt(acum / (dictionaryWordsTime.Count - 1));
            return stdDer;
        }

        public int getNumWordsXChars(int x)
        {
            int c = 0;

            for (int i = 0; i < listWords.Count; i++)
            {
                string[] f = listWords[i].Split(',');
                if (Convert.ToInt32(f[3]) == x) c++;
            }

            return c;
        }

        public int getNumWordsXCharsBackspace(int x)
        {
            int c = 0;

            for (int i = 0; i < listWords.Count; i++)
            {
                string[] f = listWords[i].Split(',');
                if ((Convert.ToInt32(f[3]) == x) && ((Convert.ToInt32(f[2]))!=0)) c++;
            }

            return c;
        }

        public double WordsMeanWithXChars(int x)
        {
            double acum = 0;
            double c = 0;

            foreach (KeyValuePair<string, double> pair in dictionaryWordsTime)
            {
                if (pair.Key.Length == x) { acum += pair.Value; c++; }
            }

            return acum/c;

        }

        public double StandardDerivationWordsWithXChars(int x)
        {
            double mean = WordsMeanWithXChars(x);
            double acum = 0;

            foreach (KeyValuePair<string, double> pair in dictionaryWordsTime)
            {
                if (pair.Key.Length == x) acum += (pair.Value - mean) * (pair.Value - mean);
            }

            double stdDer = 0;
            if (getNumWordsXChars(x) > 1) stdDer = Math.Sqrt(acum / (getNumWordsXChars(x) - 1));
            return stdDer;
        }

        /*TRIOS*/

        public void TrioAndModLogs()
        {
            int i;

            mod_logs_Trio = new List<string>();
            trio_time = new Dictionary<string, double>();
            trio_occurrence = new Dictionary<string, double>();

            string current_timestamp = null;
            string current_letter = null;

            for (i = 2; i < logs.Count; i++)
            {
                //Dados do log i - 2
                string[] f = logs[i - 2].Split(':');
                current_timestamp = f[0]; current_letter = f[2];

                string t1 = current_timestamp;
                string l1 = current_letter;

                //Dados do log anterior
                string[] g = logs[i - 1].Split(':');
                current_timestamp = g[0]; current_letter = g[2];

                string t2 = current_timestamp; //Conta para o time_stamp???
                string l2 = current_letter;

                //Dados do log actual
                string[] n = logs[i].Split(':');
                current_timestamp = n[0]; current_letter = n[2];

                string t3 = current_timestamp;
                string l3 = current_letter;

                double timestamp1 = Double.Parse(t1);
                double timestamp2 = Double.Parse(t2);
                double timestamp3 = Double.Parse(t3);

                double r = timestamp2 - timestamp1;
                double r2 = timestamp3 - timestamp1;

                char maol1, maol2, maol3;

                //Verefica a qual parte corresponde
                if (CheckLeft(l1) == true)
                {
                    maol1 = 'L';
                }
                else if (CheckSpace(l1) == true)
                {
                    maol1 = 'S';
                }
                else
                {
                    maol1 = 'R';
                }

                if (CheckLeft(l2) == true)
                {
                    maol2 = 'L';
                }
                else if (CheckSpace(l2) == true)
                {
                    maol2 = 'S';
                }
                else
                {
                    maol2 = 'R';
                }

                if (CheckLeft(l3) == true)
                {
                    maol3 = 'L';
                }
                else if (CheckSpace(l3) == true)
                {
                    maol3 = 'S';
                }
                else
                {
                    maol3 = 'R';
                }

                string timestamp = Convert.ToString(r2);
                char[] letters = { maol1, '-', maol2, '-', maol3 };
                string trio = new string(letters);
                string result = timestamp + ":" + trio;
                //Adiciona ao log
                mod_logs_Trio.Add(result);

                //Adição do tempo
                if (!trio_time.ContainsKey(trio))
                {
                    trio_time.Add(trio, Double.Parse(timestamp));
                    trio_occurrence.Add(trio, 1);
                }
                else
                {
                    trio_time[trio] += Double.Parse(timestamp);
                    trio_occurrence[trio] += 1;
                }
            }

        }

        /* Mean of all trios */
        public void keyGroupTriosMedian()
        {
            median_for_trio = new Dictionary<string, double>();
            foreach (KeyValuePair<string, double> trio in trio_time) // EX: R-L-L , Tempo
            {
                var keyvalue = new KeyValuePair<string, double>(trio.Key, trio_occurrence[trio.Key]);
                double median = (trio.Value / keyvalue.Value);
                median_for_trio.Add(trio.Key, median);
            }
        }

        static void StandardDerivationKeyGroupTrioEvents()
        {
            int i;
            std_for_trio = new Dictionary<string, double>();

            string current_timestamp = null;
            string current_letter = null;

            for (i = 0; i < mod_logs_Trio.Count; i++)
            {
                string[] f = mod_logs_Trio[i].Split(':');
                current_timestamp = f[0];
                current_letter = f[1];
                double median = median_for_trio[current_letter];
                double time = Double.Parse(current_timestamp);
                double dif = time - median;

                if (!std_for_trio.ContainsKey(current_letter))
                    std_for_trio.Add(current_letter, dif * dif);
                else
                    std_for_trio[current_letter] += dif * dif;

            }

            foreach(KeyValuePair<string,double> trio in trio_occurrence)
            {
                current_letter = trio.Key;
                std_for_trio[current_letter] = Math.Sqrt(std_for_trio[current_letter]/trio.Value);
            }
        }

        public Dictionary<string, double> getDictionaryTrio()
        {
            return trio_occurrence;
        }

        public Dictionary<string, double> getDictionaryTriosMean()
        {
            return median_for_trio;
        }

        public Dictionary<string, double> getDictionaryTriosStd()
        {
            return std_for_trio;
        }

        public Dictionary<string, double> getTop10Trios()
        {
            Dictionary<string, double> ct = new Dictionary<string, double>();

            foreach (KeyValuePair<string, double> item in trio_occurrence.OrderByDescending(key => key.Value).Take(10))
            {
                ct.Add(item.Key, item.Value);
            }

            return ct;
        }

        public int getTotalTrios()
        {
            return mod_logs_Trio.Count;
        }

        //Guardar os dados na BD
        public void SaveData(string user, string date)
        {
            BD_SQL bd = new BD_SQL(user, date);

            /* Garantir que todas as variáveis foram calculadas */
            if (mod_logs == null)
                PairAndModLogs();
            if (mean_for_grouppair == null)
                keyGroupPairMedian();
            if (std_for_grouppair == null)
                StandardDerivationKeyGroupPairEvents();
            if (listWords == null)
                Words();
            if (dictionaryTop10Words == null)
                StoreWordsRelated();
            if (median_for_Words == null)
                wordsMean();

            double meanWrittingTime = getMeanWrittingTime();
            double stdWrittingTime = getStdWritingTime();
            double WordsMeanWrittingTime = getWordsMeanWrittingTime();
            double WordsStdWrittingTime = getWordsStdWrittingTime();

            bd.LoadVariables(logs.Count, number_BackSpaces, listWords.Count,
                            dictionaryBackSpaceWords.Count, meanWrittingTime,
                            stdWrittingTime, WordsMeanWrittingTime, WordsStdWrittingTime);

            bd.LoadPairs(pair_occurrence.ToDictionary(k => k.Key, k => Convert.ToInt32(k.Value)),
                         mean_for_grouppair, std_for_grouppair);

            if (trio_occurrence == null || trio_occurrence.Count == 0)
                TrioAndModLogs();
            if (median_for_trio == null || median_for_trio.Count == 0)
                keyGroupTriosMedian();
            if (std_for_trio == null || std_for_trio.Count == 0)
                StandardDerivationKeyGroupTrioEvents();

            bd.LoadTrios(trio_occurrence.ToDictionary(k => k.Key, k => Convert.ToInt32(k.Value)),
                         median_for_trio, std_for_trio);

            bd.LoadWords(getTop10Words().ToDictionary(k => k.Key, k => Convert.ToInt32(k.Value)),
                         getDictionaryWords().ToDictionary(k => k.Key, k => Convert.ToInt32(k.Value)),
                         getDictionaryBackSpaceWords().ToDictionary(k => k.Key, k => Convert.ToInt32(k.Value)),
                         getDictionaryWordsMedian());

            bd.Save();
        }
    }
}
