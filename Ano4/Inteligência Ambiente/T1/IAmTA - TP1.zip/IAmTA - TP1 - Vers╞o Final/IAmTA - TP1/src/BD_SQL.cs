﻿using System;
using System.Collections.Generic;
using System.Linq;
using MySql.Data.MySqlClient;
using System.Globalization;

namespace IAmTA___TP1.src
{
    class BD_SQL
    {

        MySqlConnection conDatabase = null;
        MySqlDataReader myReader = null;
        string constring;
        string mydb = "mydb";

        string user, date, idUser, idData;
        int num_chars, num_backsapces, num_words, num_wordsAndbackspaces, num_pairs, num_trios;
        double media_char, desviopadrao_char, media_words, desviopadrao_words;
        //Words
        Dictionary<string, int> topwords; //Top das 10 words que mais se repetiram <word,num_rep>
        Dictionary<string, int> wordsAndNumRep;//Todas as words <word,num_rep>
        Dictionary<string, int> wordsAndBackSpace;//Todas as words <word,num_backspace>
        Dictionary<string, double> wordsAndMedian;//Todas as words <word,media>
        // Not used
        Dictionary<string, double> wordsAndStd;//Todas as words <word,desviopadrão>
        /** Layout */
        //Pares
        Dictionary<string, int> pairAndNumRep;//Todos os pares <pair,num_rep>
        Dictionary<string, double> pairAndMedian;//Todos os pares <pair,media>
        Dictionary<string, double> pairAndStd;//Todos os pares <pair,desviopadrão>
        //Triplos
        Dictionary<string, int> trioAndNumRep;//Todos os trio <trio,num_rep>
        Dictionary<string, double> trioAndMedian;//Todos os trios <trio,media>
        Dictionary<string, double> trioAndStd;//Todos os trios <trio,desviopadrão>


        public BD_SQL(string user, string date)
        {
            constring = "datasource=localhost;port=3306;username=root;password=147258369";
            conDatabase = new MySqlConnection(constring);
            this.user = user;
            this.date = date;
        }

        public void SetNumChars(int num) { num_chars = num; }
        public void SetNumBackSpaces(int num) { num_backsapces = num; }
        public void SetNumWords(int num) { num_words = num; }
        public void SetNumWordsAndBackSpaces(int num) { num_wordsAndbackspaces = num; }
        public void SetMediaChar(int num) { media_char = num; }
        public void SetDesvioPadraoChar(int num) { desviopadrao_char = num; }
        public void SetMediaWords(int num) { media_words = num; }
        public void SetDesvioPadraoWords(int num) { desviopadrao_words = num; }
        public void SetNumPairs(int num) { num_pairs = num; }
        public void SetNumTrios(int num) { num_trios = num; }
        //Words
        public void SetTopWords(Dictionary<string, int> top) { topwords = new Dictionary<string, int>(top); }
        public void SetWordsAndNumRep(Dictionary<string, int> words) { wordsAndNumRep = new Dictionary<string, int>(words); }
        public void SetWordsAndBackSpace(Dictionary<string, int> words) { wordsAndBackSpace = new Dictionary<string, int>(words); }
        public void SetWordsAndMedian(Dictionary<string, double> words) { wordsAndMedian = new Dictionary<string, double>(words); }
        public void SetWordsAndStd(Dictionary<string, double> words) { wordsAndStd = new Dictionary<string, double>(words); }
        //Pairs
        public void SetPairAndNumRep(Dictionary<string, int> pairs) { pairAndNumRep = new Dictionary<string, int>(pairs); }
        public void SetPairAndMedian(Dictionary<string, double> pairs) { pairAndMedian = new Dictionary<string, double>(pairs); }
        public void SetPairAndStd(Dictionary<string, double> pairs) { pairAndStd = new Dictionary<string, double>(pairs); }
        //Trios
        public void SetTrioAndNumRep(Dictionary<string, int> trios) { trioAndNumRep = new Dictionary<string, int>(trios); }
        public void SetTrioAndMedian(Dictionary<string, double> trios) { trioAndMedian = new Dictionary<string, double>(trios); }
        public void SetTrioAndStd(Dictionary<string, double> trios) { trioAndStd = new Dictionary<string, double>(trios); }

        public void LoadVariables(int chars, int backspace, int words, int wordsAndBS, double m_char, double std_char, double m_words, double std_words)
        {
            this.num_chars = chars;
            this.num_backsapces = backspace;
            this.num_words = words;
            this.num_wordsAndbackspaces = wordsAndBS;
            this.media_char = m_char;
            this.desviopadrao_char = std_char;
            this.media_words = m_words;
            this.desviopadrao_words = std_words;
        }

        public void LoadWords(Dictionary<string, int> wTop, Dictionary<string, int> wAndRep, Dictionary<string, int> wAndBS, Dictionary<string, double> wAndMedian)
        {
            SetTopWords(wTop);
            SetWordsAndNumRep(wAndRep);
            SetWordsAndBackSpace(wAndBS);
            SetWordsAndMedian(wAndMedian);
        }

        public void LoadPairs(Dictionary<string, int> pAndRep, Dictionary<string, double> pAndMedian, Dictionary<string, double> pAndStd)
        {
            int sum = 0;
            foreach (KeyValuePair<string, int> pair in pAndRep)
            {
                sum += pair.Value;
            }
            SetNumPairs(sum);
            SetPairAndNumRep(pAndRep);
            SetPairAndMedian(pAndMedian);
            SetPairAndStd(pAndStd);
        }

        public void LoadTrios(Dictionary<string, int> tAndRep, Dictionary<string, double> tAndMedian, Dictionary<string, double> tAndStd)
        {
            int sum = 0;
            foreach (KeyValuePair<string, int> trio in tAndRep)
            {
                sum += trio.Value;
            }
            SetNumTrios(sum);
            SetTrioAndNumRep(tAndRep);
            SetTrioAndMedian(tAndMedian);
            SetTrioAndStd(tAndStd);
        }


        //Usa todos os valores em Class1,
        public void LoadData(Class1 data)
        {
            //Variáveis
            LoadVariables(data.getTotalCharacters(), data.getNumBackSpaces(), data.getTotalWords(),
                          data.getNumBackSpaceWords(), data.getMeanWrittingTime(), data.getStdWritingTime(),
                          data.getWordsMeanWrittingTime(), data.getWordsStdWrittingTime());

            //Top 10 words
            LoadWords(data.getTop10Words().ToDictionary(k => k.Key, k => Convert.ToInt32(k.Value)),
                      data.getDictionaryWords().ToDictionary(k => k.Key, k => Convert.ToInt32(k.Value)),
                      data.getDictionaryBackSpaceWords().ToDictionary(k => k.Key, k => Convert.ToInt32(k.Value)),
                      data.getDictionaryWordsMedian());

            //Pairs
            LoadPairs(data.getDictionaryPairs().ToDictionary(k => k.Key, k => Convert.ToInt32(k.Value)),
                      data.getDictionaryPairMean(), data.getDictionaryPairStd());

            //Trios
            //LoadTrios(data.getDictionaryTrio().ToDictionary(k => k.Key, k=> Convert.ToInt32(k.Value)), data.getDictionaryTriosMean(), data.getDictionaryTriosStd());

        }

        public void ExportQueryToBD(string query)
        {
            MySqlCommand cmdDatabase = new MySqlCommand(query, conDatabase);
            try
            {
                cmdDatabase.ExecuteNonQuery();
                //Console.Write(query);
            }
            catch (Exception ex)
            {
                Console.Write("\n" + query + "\n");
                Console.Write(ex);
            }
        }

        //É necessário que a conecção com a BD já se tenha efectuado
        //Cria os comandos SQL e enivia os dados para a BD
        public void ExportUser()
        {
            string query = "";

            //Verificar se o utilizador já existe, não é necessário, se já existe a query dá erro mas o sistema deve continuar a funcionar
            //Inserção e set do user na BD
            query = query + "insert into " + mydb + ".utilizador (Nome) Values (\"" + user + "\");\n";
            ExportQueryToBD(query);

            MySqlCommand cmd = conDatabase.CreateCommand();
            cmd.CommandText = "Select idUtilizador From " + mydb + ".utilizador Where Nome = \"" + user + "\" LIMIT 1;\n";

            if (myReader != null && !myReader.IsClosed)
                myReader.Close();

            myReader = cmd.ExecuteReader();

            if (myReader.Read())
                idUser = myReader.GetString("idUtilizador");
            myReader.Close();

        }

        //Exporta as variáveis da tabela Data para a BD
        public void ExportVariablesData()
        {
            string query = "";
            //Inserção dos dados
            query = "insert into " + mydb + ".dados (idUtilizador, Data, Num_Chars, Num_Backspace, Num_Words,Num_Palavras_Backspace," +
                    " Media_Char, DesvioPadrao_Char, Media_Words, DesvioPadrao_Words)\n\tValues\n";
            query += "(" + idUser + ", \"" + date + "\"," + num_chars + "," + num_backsapces + "," + num_words + "," + num_wordsAndbackspaces + "," 
                     + DoubleToString(media_char) + "," + DoubleToString(desviopadrao_char) + "," + DoubleToString(media_words) + "," 
                     + DoubleToString(desviopadrao_words) + ");\n";
            ExportQueryToBD(query);

            MySqlCommand cmd = conDatabase.CreateCommand();
            cmd.CommandText = "Select idData from " + mydb + ".dados where idUtilizador = " + idUser + " AND Data = \"" + date + "\" limit 1;\n";

            if (myReader != null && !myReader.IsClosed)
                myReader.Close();

            myReader = cmd.ExecuteReader();

            if (myReader.Read())
                idData = myReader.GetString("idData");
            myReader.Close();
        }

        //Exporta o top10 das palavras para a BD
        public void ExportTop10Words()
        {
            string query = "";
            //Inserção de TopWords
            query = query + "insert into " + mydb + ".topwords (idData, Word, Num_Rep, Uso)\n\tvalues\n";
            int count = 0;
            foreach (KeyValuePair<string, int> topwords in topwords)
            {
                query = query + "("+ idData +",\"" + topwords.Key + "\"," + topwords.Value + "," + DoubleToString((double)((topwords.Value*100) / num_words)) + ")";
                if (++count == 10)
                    query += ";\n";
                else
                    query += ",\n";
            }
            ExportQueryToBD(query);
        }

        //Exporta os dados sobre todos os pares para a BD
        public void ExportPairs()
        {
            string query = "";
            //Inserção das metricas por layout
            //Pares
            query = query + "insert into " + mydb + ".metricas_layout (idData, layout, Media, DesvioPadrao, Num_Utilizacao, Num_Chars)\n\tvalues\n";
            int count = 0;
            foreach (KeyValuePair<string, int> pair in pairAndNumRep)
            {
                query = query + "\t(" + idData + ",\"" + pair.Key + "\"," + DoubleToString(pairAndMedian[pair.Key]) + "," + DoubleToString(pairAndStd[pair.Key]) + "," + DoubleToString((double)((pair.Value*100) / num_pairs)) + "," + 2 + ")";
                if (++count == pairAndNumRep.Count)
                    query += ";\n";
                else
                    query += ",\n";

            }
            ExportQueryToBD(query);
        }

        public void ExportTrios()
        {
            string query = "";
            query = query + "insert into " + mydb + ".metricas_layout (idData, layout, Media, DesvioPadrao, Num_Utilizacao, Num_Chars) values ";
            int count = 0;
            foreach (KeyValuePair<string, int> trio in trioAndNumRep)
            {
                query = query + "\t(" + idData + ",\"" + trio.Key + "\"," + DoubleToString(trioAndMedian[trio.Key]) + "," + DoubleToString(trioAndStd[trio.Key]) + "," + DoubleToString((double)((trio.Value*100) / num_trios)) + "," + 3 + ")";
                if (++count == trioAndNumRep.Count)
                    query += ";\n";
                else
                    query += ",\n";
            }

            ExportQueryToBD(query);
        }

        public void ExportWords()
        {
            string query = "";
            //Inserção das metricas por words
            query = query + "insert into " + mydb + ".metricas_words (idData, Word, Lenght, Num_Rep, BackSpace, Media) \n\tvalues\n";
            int count = 0;
            foreach (KeyValuePair<string, int> words in wordsAndNumRep)
            {
                int backSpace = 0;
                if (wordsAndBackSpace.ContainsKey(words.Key))
                    backSpace = wordsAndBackSpace[words.Key];

                query = query + "\t(" + idData + ",\"" + words.Key + "\"," + words.Key.Length + "," + words.Value + "," + backSpace + "," + DoubleToString(wordsAndMedian[words.Key]) + ")";
                if (++count == wordsAndNumRep.Count)
                    query += ";\n";
                else
                    query += ",\n";
            }
            ExportQueryToBD(query);
        }


        public void Save()
        {
            try
            {
                if (conDatabase.State == System.Data.ConnectionState.Open)
                    conDatabase.Close();
                conDatabase.Open();

                ExportUser();

                ExportVariablesData();

                ExportPairs();

                ExportTop10Words();

                ExportWords();

                ExportTrios();
            }
            catch (Exception ex)
            {
                Console.Write(ex);
            }
            finally
            {
                conDatabase.Close();
            }
        }

        /* Métodos auxiliares */
        // Usado para evitar as virgulas 
        public string DoubleToString(double d)
        {
            return d.ToString(CultureInfo.CreateSpecificCulture("en-GB"));
        }
    }
}
