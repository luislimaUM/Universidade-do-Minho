﻿using IAmTA___TP1.src;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IAmTA___TP1
{
    public partial class DashboardSave : Form
    {
        private static Class1 programa = null;

        public DashboardSave()
        {
            InitializeComponent();
        }
        public void CarregaDados(Class1 p)
        {
            programa = p;
        }

            private void DigraphEventsButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Dashboard2 d2 = new Dashboard2();
            d2.CarregaDados(programa);
            d2.ShowDialog();
        }

        private void WordsAnalysisButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Dashboard3 d3 = new Dashboard3();
            d3.CarregaDados(programa);
            d3.ShowDialog();
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Dashboard0 d0 = new Dashboard0();
            d0.ShowDialog();
        }

        private void KeyStrokeEventsButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Dashboard1 d1 = new Dashboard1();
            d1.CarregaDados(programa);
            d1.ShowDialog();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void okButton_Click(object sender, EventArgs e)
        {
            programa.SaveData(username.Text, date.Text);
        }
    }
}
