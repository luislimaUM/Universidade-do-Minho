﻿using IAmTA___TP1.src;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IAmTA___TP1
{
    public partial class Dashboard2 : Form
    {
        private static Class1 programa = null;

        public Dashboard2()
        {
            InitializeComponent();
        }

        public void CarregaDados(Class1 pr)
        {
            programa = pr;
            programa.PairAndModLogs();

            stdDigraph.Text = programa.getStdKeyGroup().ToString("F2");
            meanDigraph.Text = programa.getMeanWrittingTime().ToString("F2");

            programa.keyGroupPairMedian();
            programa.StandardDerivationKeyGroupPairEvents();

            counterLL.Text = programa.getCounterPair("L-L").ToString();
            progressBar1.Value = Convert.ToInt32((programa.getCounterPair("L-L") / (double)programa.getTotalPairs()) * 100);
            pct1.Text = ((programa.getCounterPair("L-L") / (double)programa.getTotalPairs()) * 100).ToString("F2");
            meanLL.Text = programa.getMeanOfPair("L-L").ToString("F2");
            stdLL.Text = programa.getStdOfPair("L-L").ToString("F2");

            counterLR.Text = programa.getCounterPair("L-R").ToString();
            progressBar2.Value = Convert.ToInt32((programa.getCounterPair("L-R") / (double)programa.getTotalPairs()) * 100);
            pct2.Text = ((programa.getCounterPair("L-R") / (double)programa.getTotalPairs()) * 100).ToString("F2");
            meanLR.Text = programa.getMeanOfPair("L-R").ToString("F2");
            stdLR.Text = programa.getStdOfPair("L-R").ToString("F2");

            counterLS.Text = programa.getCounterPair("L-S").ToString();
            progressBar3.Value = Convert.ToInt32((programa.getCounterPair("L-S") / (double)programa.getTotalPairs()) * 100);
            pct3.Text = ((programa.getCounterPair("L-S") / (double)programa.getTotalPairs()) * 100).ToString("F2");
            meanLS.Text = programa.getMeanOfPair("L-S").ToString("F2");
            stdLS.Text = programa.getStdOfPair("L-S").ToString("F2");

            counterRL.Text = programa.getCounterPair("R-L").ToString();
            progressBar4.Value = Convert.ToInt32((programa.getCounterPair("R-L") / (double)programa.getTotalPairs()) * 100);
            pct4.Text = ((programa.getCounterPair("R-L") / (double)programa.getTotalPairs()) * 100).ToString("F2");
            meanRL.Text = programa.getMeanOfPair("R-L").ToString("F2");
            stdRL.Text = programa.getStdOfPair("R-L").ToString("F2");

            counterRR.Text = programa.getCounterPair("R-R").ToString();
            progressBar5.Value = Convert.ToInt32((programa.getCounterPair("R-R") / (double)programa.getTotalPairs()) * 100);
            pct5.Text = ((programa.getCounterPair("R-R") / (double)programa.getTotalPairs()) * 100).ToString("F2");
            meanRR.Text = programa.getMeanOfPair("R-R").ToString("F2");
            stdRR.Text = programa.getStdOfPair("R-R").ToString("F2");

            counterRS.Text = programa.getCounterPair("R-S").ToString();
            progressBar6.Value = Convert.ToInt32((programa.getCounterPair("R-S") / (double)programa.getTotalPairs()) * 100);
            pct6.Text = ((programa.getCounterPair("R-S") / (double)programa.getTotalPairs()) * 100).ToString("F2");
            meanRS.Text = programa.getMeanOfPair("R-S").ToString("F2");
            stdRS.Text = programa.getStdOfPair("R-S").ToString("F2");

            counterSL.Text = programa.getCounterPair("S-L").ToString();
            progressBar7.Value = Convert.ToInt32((programa.getCounterPair("S-L") / (double)programa.getTotalPairs()) * 100);
            pct7.Text = ((programa.getCounterPair("S-L") / (double)programa.getTotalPairs()) * 100).ToString("F2");
            meanSL.Text = programa.getMeanOfPair("S-L").ToString("F2");
            stdSL.Text = programa.getStdOfPair("S-L").ToString("F2");

            counterSR.Text = programa.getCounterPair("S-R").ToString();
            progressBar8.Value = Convert.ToInt32((programa.getCounterPair("S-R") / (double)programa.getTotalPairs()) * 100);
            pct8.Text = ((programa.getCounterPair("S-R") / (double)programa.getTotalPairs()) * 100).ToString("F2");
            meanSR.Text = programa.getMeanOfPair("S-R").ToString("F2");
            stdSR.Text = programa.getStdOfPair("S-R").ToString("F2");

            counterSS.Text = programa.getCounterPair("S-S").ToString();
            progressBar9.Value = Convert.ToInt32((programa.getCounterPair("S-S") / (double)programa.getTotalPairs()) * 100);
            pct9.Text = ((programa.getCounterPair("S-S") / (double)programa.getTotalPairs()) * 100).ToString("F2");
            meanSS.Text = programa.getMeanOfPair("S-S").ToString("F2");
            stdSS.Text = programa.getStdOfPair("S-S").ToString("F2");

            programa.TrioAndModLogs();

            Dictionary<string, double> top10 = programa.getTop10Trios();
            int total = programa.getTotalTrios();

            trio1.Text = top10.ElementAt(0).Key; ct1.Text = (top10.ElementAt(0).Value).ToString();
            progressT1.Value = Convert.ToInt32((top10.ElementAt(0).Value / (double)total) * 100);
            pctT1.Text = ((top10.ElementAt(0).Value / (double)total) * 100).ToString("F2");

            trio2.Text = top10.ElementAt(1).Key; ct2.Text = (top10.ElementAt(1).Value).ToString();
            progressT2.Value = Convert.ToInt32((top10.ElementAt(1).Value / (double)total) * 100);
            pctT2.Text = ((top10.ElementAt(1).Value / (double)total) * 100).ToString("F2");

            trio3.Text = top10.ElementAt(2).Key; ct3.Text = (top10.ElementAt(2).Value).ToString();
            progressT3.Value = Convert.ToInt32((top10.ElementAt(2).Value / (double)total) * 100);
            pctT3.Text = ((top10.ElementAt(2).Value / (double)total) * 100).ToString("F2");

            trio4.Text = top10.ElementAt(3).Key; ct4.Text = (top10.ElementAt(3).Value).ToString();
            progressT4.Value = Convert.ToInt32((top10.ElementAt(3).Value / (double)total) * 100);
            pctT4.Text = ((top10.ElementAt(3).Value / (double)total) * 100).ToString("F2");

            trio5.Text = top10.ElementAt(4).Key; ct5.Text = (top10.ElementAt(4).Value).ToString();
            progressT5.Value = Convert.ToInt32((top10.ElementAt(4).Value / (double)total) * 100);
            pctT5.Text = ((top10.ElementAt(4).Value / (double)total) * 100).ToString("F2");

            trio6.Text = top10.ElementAt(5).Key; ct6.Text = (top10.ElementAt(5).Value).ToString();
            progressT6.Value = Convert.ToInt32((top10.ElementAt(5).Value / (double)total) * 100);
            pctT6.Text = ((top10.ElementAt(5).Value / (double)total) * 100).ToString("F2");

            trio7.Text = top10.ElementAt(6).Key; ct7.Text = (top10.ElementAt(6).Value).ToString();
            progressT7.Value = Convert.ToInt32((top10.ElementAt(6).Value / (double)total) * 100);
            pctT7.Text = ((top10.ElementAt(6).Value / (double)total) * 100).ToString("F2");

            trio8.Text = top10.ElementAt(7).Key; ct8.Text = (top10.ElementAt(7).Value).ToString();
            progressT8.Value = Convert.ToInt32((top10.ElementAt(7).Value / (double)total) * 100);
            pctT8.Text = ((top10.ElementAt(7).Value / (double)total) * 100).ToString("F2");

            trio9.Text = top10.ElementAt(8).Key; ct9.Text = (top10.ElementAt(8).Value).ToString();
            progressT9.Value = Convert.ToInt32((top10.ElementAt(8).Value / (double)total) * 100);
            pctT9.Text = ((top10.ElementAt(8).Value / (double)total) * 100).ToString("F2");

            trio10.Text = top10.ElementAt(9).Key; ct10.Text = (top10.ElementAt(9).Value).ToString();
            progressT10.Value = Convert.ToInt32((top10.ElementAt(9).Value / (double)total) * 100);
            pctT10.Text = ((top10.ElementAt(9).Value / (double)total) * 100).ToString("F2");




            /*
            for (int i = 1; i <= 10; i++)
            {
                TextBox txtBoxtemp1 = (TextBox)this.Controls.Find("trio" + i, true)[0];
                //TextBox txtBoxtemp2 = (TextBox)this.Controls.Find("ct" + i, true)[0];
                txtBoxtemp1.Text = top10.ElementAt(i-1).Key;
                //txtBoxtemp1.Text = top10.ElementAt(i-1).Value.ToString();
            }*/
        }

        private void KeyStrokeEventsButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Dashboard1 d1 = new Dashboard1();
            d1.CarregaDados(programa);
            d1.ShowDialog();
        }

        private void WordsAnalysisButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Dashboard3 d3 = new Dashboard3();
            d3.CarregaDados(programa);
            d3.ShowDialog();
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Dashboard0 d0 = new Dashboard0();
            d0.ShowDialog();
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            DashboardSave d = new DashboardSave();
            d.CarregaDados(programa);
            d.ShowDialog();
        }
    }
}
