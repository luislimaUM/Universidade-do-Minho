﻿namespace IAmTA___TP1
{
    partial class Dashboard3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dashboard3));
            this.sidepanel = new System.Windows.Forms.Panel();
            this.BackButton = new System.Windows.Forms.Button();
            this.SaveButton = new System.Windows.Forms.Button();
            this.WordsAnalysisButton = new System.Windows.Forms.Button();
            this.DigraphEventsButton = new System.Windows.Forms.Button();
            this.KeyStrokeEventsButton = new System.Windows.Forms.Button();
            this.titlepanel = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.title = new System.Windows.Forms.Label();
            this.headerpanel = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.word10 = new System.Windows.Forms.Label();
            this.word9 = new System.Windows.Forms.Label();
            this.word8 = new System.Windows.Forms.Label();
            this.word7 = new System.Windows.Forms.Label();
            this.word6 = new System.Windows.Forms.Label();
            this.word5 = new System.Windows.Forms.Label();
            this.word4 = new System.Windows.Forms.Label();
            this.word3 = new System.Windows.Forms.Label();
            this.word2 = new System.Windows.Forms.Label();
            this.word1 = new System.Windows.Forms.Label();
            this.pct10 = new System.Windows.Forms.Label();
            this.pct9 = new System.Windows.Forms.Label();
            this.pct8 = new System.Windows.Forms.Label();
            this.pct7 = new System.Windows.Forms.Label();
            this.pct6 = new System.Windows.Forms.Label();
            this.pct5 = new System.Windows.Forms.Label();
            this.pct4 = new System.Windows.Forms.Label();
            this.pct3 = new System.Windows.Forms.Label();
            this.pct2 = new System.Windows.Forms.Label();
            this.pct1 = new System.Windows.Forms.Label();
            this.totalCh10 = new System.Windows.Forms.Label();
            this.totalCh9 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.totalCh8 = new System.Windows.Forms.Label();
            this.totalCh7 = new System.Windows.Forms.Label();
            this.totalCh6 = new System.Windows.Forms.Label();
            this.progressBar10 = new System.Windows.Forms.ProgressBar();
            this.totalCh5 = new System.Windows.Forms.Label();
            this.progressBar9 = new System.Windows.Forms.ProgressBar();
            this.totalCh4 = new System.Windows.Forms.Label();
            this.progressBar8 = new System.Windows.Forms.ProgressBar();
            this.totalCh3 = new System.Windows.Forms.Label();
            this.progressBar7 = new System.Windows.Forms.ProgressBar();
            this.totalCh2 = new System.Windows.Forms.Label();
            this.progressBar6 = new System.Windows.Forms.ProgressBar();
            this.totalCh1 = new System.Windows.Forms.Label();
            this.progressBar5 = new System.Windows.Forms.ProgressBar();
            this.progressBar4 = new System.Windows.Forms.ProgressBar();
            this.progressBar3 = new System.Windows.Forms.ProgressBar();
            this.progressBar2 = new System.Windows.Forms.ProgressBar();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.stdWord = new System.Windows.Forms.Label();
            this.meanWord = new System.Windows.Forms.Label();
            this.wordsBS = new System.Windows.Forms.Label();
            this.totalWords = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.std10 = new System.Windows.Forms.Label();
            this.pctW10 = new System.Windows.Forms.Label();
            this.std9 = new System.Windows.Forms.Label();
            this.pctW9 = new System.Windows.Forms.Label();
            this.std8 = new System.Windows.Forms.Label();
            this.pctW8 = new System.Windows.Forms.Label();
            this.std7 = new System.Windows.Forms.Label();
            this.pctW7 = new System.Windows.Forms.Label();
            this.std6 = new System.Windows.Forms.Label();
            this.pctW6 = new System.Windows.Forms.Label();
            this.std5 = new System.Windows.Forms.Label();
            this.pctW5 = new System.Windows.Forms.Label();
            this.std4 = new System.Windows.Forms.Label();
            this.pctW4 = new System.Windows.Forms.Label();
            this.std3 = new System.Windows.Forms.Label();
            this.pctW3 = new System.Windows.Forms.Label();
            this.std2 = new System.Windows.Forms.Label();
            this.pctW2 = new System.Windows.Forms.Label();
            this.mean10 = new System.Windows.Forms.Label();
            this.mean9 = new System.Windows.Forms.Label();
            this.progress10 = new System.Windows.Forms.ProgressBar();
            this.mean8 = new System.Windows.Forms.Label();
            this.progress9 = new System.Windows.Forms.ProgressBar();
            this.mean7 = new System.Windows.Forms.Label();
            this.progress8 = new System.Windows.Forms.ProgressBar();
            this.mean6 = new System.Windows.Forms.Label();
            this.progress7 = new System.Windows.Forms.ProgressBar();
            this.mean5 = new System.Windows.Forms.Label();
            this.progress6 = new System.Windows.Forms.ProgressBar();
            this.mean4 = new System.Windows.Forms.Label();
            this.progress5 = new System.Windows.Forms.ProgressBar();
            this.mean3 = new System.Windows.Forms.Label();
            this.progress4 = new System.Windows.Forms.ProgressBar();
            this.mean2 = new System.Windows.Forms.Label();
            this.progress3 = new System.Windows.Forms.ProgressBar();
            this.total10 = new System.Windows.Forms.Label();
            this.progress2 = new System.Windows.Forms.ProgressBar();
            this.total9 = new System.Windows.Forms.Label();
            this.total8 = new System.Windows.Forms.Label();
            this.total7 = new System.Windows.Forms.Label();
            this.total6 = new System.Windows.Forms.Label();
            this.total5 = new System.Windows.Forms.Label();
            this.total4 = new System.Windows.Forms.Label();
            this.total3 = new System.Windows.Forms.Label();
            this.total2 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.std15 = new System.Windows.Forms.Label();
            this.pctW15 = new System.Windows.Forms.Label();
            this.std14 = new System.Windows.Forms.Label();
            this.pctW14 = new System.Windows.Forms.Label();
            this.std13 = new System.Windows.Forms.Label();
            this.pctW13 = new System.Windows.Forms.Label();
            this.std12 = new System.Windows.Forms.Label();
            this.pctW12 = new System.Windows.Forms.Label();
            this.std11 = new System.Windows.Forms.Label();
            this.pctW11 = new System.Windows.Forms.Label();
            this.mean15 = new System.Windows.Forms.Label();
            this.mean14 = new System.Windows.Forms.Label();
            this.progress15 = new System.Windows.Forms.ProgressBar();
            this.mean13 = new System.Windows.Forms.Label();
            this.progress14 = new System.Windows.Forms.ProgressBar();
            this.mean12 = new System.Windows.Forms.Label();
            this.progress13 = new System.Windows.Forms.ProgressBar();
            this.mean11 = new System.Windows.Forms.Label();
            this.progress12 = new System.Windows.Forms.ProgressBar();
            this.progress11 = new System.Windows.Forms.ProgressBar();
            this.total15 = new System.Windows.Forms.Label();
            this.total14 = new System.Windows.Forms.Label();
            this.total13 = new System.Windows.Forms.Label();
            this.total12 = new System.Windows.Forms.Label();
            this.total11 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.sidepanel.SuspendLayout();
            this.titlepanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.headerpanel.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // sidepanel
            // 
            this.sidepanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(43)))), ((int)(((byte)(55)))));
            this.sidepanel.Controls.Add(this.BackButton);
            this.sidepanel.Controls.Add(this.SaveButton);
            this.sidepanel.Controls.Add(this.WordsAnalysisButton);
            this.sidepanel.Controls.Add(this.DigraphEventsButton);
            this.sidepanel.Controls.Add(this.KeyStrokeEventsButton);
            this.sidepanel.Controls.Add(this.titlepanel);
            this.sidepanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.sidepanel.Location = new System.Drawing.Point(0, 0);
            this.sidepanel.Name = "sidepanel";
            this.sidepanel.Size = new System.Drawing.Size(340, 779);
            this.sidepanel.TabIndex = 0;
            // 
            // BackButton
            // 
            this.BackButton.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.BackButton.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray;
            this.BackButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BackButton.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BackButton.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.BackButton.Location = new System.Drawing.Point(0, 729);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(340, 50);
            this.BackButton.TabIndex = 5;
            this.BackButton.Text = "Back";
            this.BackButton.UseVisualStyleBackColor = true;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // SaveButton
            // 
            this.SaveButton.Dock = System.Windows.Forms.DockStyle.Top;
            this.SaveButton.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray;
            this.SaveButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SaveButton.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SaveButton.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.SaveButton.Location = new System.Drawing.Point(0, 247);
            this.SaveButton.Name = "SaveButton";
            this.SaveButton.Size = new System.Drawing.Size(340, 50);
            this.SaveButton.TabIndex = 4;
            this.SaveButton.Text = "Save";
            this.SaveButton.UseVisualStyleBackColor = true;
            this.SaveButton.Click += new System.EventHandler(this.SaveButton_Click);
            // 
            // WordsAnalysisButton
            // 
            this.WordsAnalysisButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(65)))));
            this.WordsAnalysisButton.Dock = System.Windows.Forms.DockStyle.Top;
            this.WordsAnalysisButton.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray;
            this.WordsAnalysisButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.WordsAnalysisButton.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WordsAnalysisButton.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.WordsAnalysisButton.Location = new System.Drawing.Point(0, 197);
            this.WordsAnalysisButton.Name = "WordsAnalysisButton";
            this.WordsAnalysisButton.Size = new System.Drawing.Size(340, 50);
            this.WordsAnalysisButton.TabIndex = 3;
            this.WordsAnalysisButton.Text = "Words Analysis";
            this.WordsAnalysisButton.UseVisualStyleBackColor = false;
            // 
            // DigraphEventsButton
            // 
            this.DigraphEventsButton.Dock = System.Windows.Forms.DockStyle.Top;
            this.DigraphEventsButton.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray;
            this.DigraphEventsButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DigraphEventsButton.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DigraphEventsButton.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.DigraphEventsButton.Location = new System.Drawing.Point(0, 147);
            this.DigraphEventsButton.Name = "DigraphEventsButton";
            this.DigraphEventsButton.Size = new System.Drawing.Size(340, 50);
            this.DigraphEventsButton.TabIndex = 2;
            this.DigraphEventsButton.Text = "Digraph Events";
            this.DigraphEventsButton.UseVisualStyleBackColor = true;
            this.DigraphEventsButton.Click += new System.EventHandler(this.DigraphEventsButton_Click);
            // 
            // KeyStrokeEventsButton
            // 
            this.KeyStrokeEventsButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(43)))), ((int)(((byte)(55)))));
            this.KeyStrokeEventsButton.Dock = System.Windows.Forms.DockStyle.Top;
            this.KeyStrokeEventsButton.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.KeyStrokeEventsButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.KeyStrokeEventsButton.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.KeyStrokeEventsButton.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.KeyStrokeEventsButton.Location = new System.Drawing.Point(0, 97);
            this.KeyStrokeEventsButton.Name = "KeyStrokeEventsButton";
            this.KeyStrokeEventsButton.Size = new System.Drawing.Size(340, 50);
            this.KeyStrokeEventsButton.TabIndex = 1;
            this.KeyStrokeEventsButton.Text = "KeyStroke Events";
            this.KeyStrokeEventsButton.UseVisualStyleBackColor = false;
            this.KeyStrokeEventsButton.Click += new System.EventHandler(this.KeyStrokeEventsButton_Click);
            // 
            // titlepanel
            // 
            this.titlepanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(126)))), ((int)(((byte)(49)))));
            this.titlepanel.Controls.Add(this.pictureBox1);
            this.titlepanel.Controls.Add(this.title);
            this.titlepanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.titlepanel.Location = new System.Drawing.Point(0, 0);
            this.titlepanel.Name = "titlepanel";
            this.titlepanel.Size = new System.Drawing.Size(340, 97);
            this.titlepanel.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(40, 33);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(70, 37);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // title
            // 
            this.title.AutoSize = true;
            this.title.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.title.ForeColor = System.Drawing.Color.White;
            this.title.Location = new System.Drawing.Point(129, 42);
            this.title.Name = "title";
            this.title.Size = new System.Drawing.Size(148, 28);
            this.title.TabIndex = 0;
            this.title.Text = "IAmTA - TP1";
            // 
            // headerpanel
            // 
            this.headerpanel.BackColor = System.Drawing.Color.Snow;
            this.headerpanel.Controls.Add(this.label1);
            this.headerpanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.headerpanel.Location = new System.Drawing.Point(340, 0);
            this.headerpanel.Name = "headerpanel";
            this.headerpanel.Size = new System.Drawing.Size(1047, 97);
            this.headerpanel.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(29, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(269, 30);
            this.label1.TabIndex = 2;
            this.label1.Text = "Words Events Analysis";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.word10);
            this.panel1.Controls.Add(this.word9);
            this.panel1.Controls.Add(this.word8);
            this.panel1.Controls.Add(this.word7);
            this.panel1.Controls.Add(this.word6);
            this.panel1.Controls.Add(this.word5);
            this.panel1.Controls.Add(this.word4);
            this.panel1.Controls.Add(this.word3);
            this.panel1.Controls.Add(this.word2);
            this.panel1.Controls.Add(this.word1);
            this.panel1.Controls.Add(this.pct10);
            this.panel1.Controls.Add(this.pct9);
            this.panel1.Controls.Add(this.pct8);
            this.panel1.Controls.Add(this.pct7);
            this.panel1.Controls.Add(this.pct6);
            this.panel1.Controls.Add(this.pct5);
            this.panel1.Controls.Add(this.pct4);
            this.panel1.Controls.Add(this.pct3);
            this.panel1.Controls.Add(this.pct2);
            this.panel1.Controls.Add(this.pct1);
            this.panel1.Controls.Add(this.totalCh10);
            this.panel1.Controls.Add(this.totalCh9);
            this.panel1.Controls.Add(this.label25);
            this.panel1.Controls.Add(this.totalCh8);
            this.panel1.Controls.Add(this.totalCh7);
            this.panel1.Controls.Add(this.totalCh6);
            this.panel1.Controls.Add(this.progressBar10);
            this.panel1.Controls.Add(this.totalCh5);
            this.panel1.Controls.Add(this.progressBar9);
            this.panel1.Controls.Add(this.totalCh4);
            this.panel1.Controls.Add(this.progressBar8);
            this.panel1.Controls.Add(this.totalCh3);
            this.panel1.Controls.Add(this.progressBar7);
            this.panel1.Controls.Add(this.totalCh2);
            this.panel1.Controls.Add(this.progressBar6);
            this.panel1.Controls.Add(this.totalCh1);
            this.panel1.Controls.Add(this.progressBar5);
            this.panel1.Controls.Add(this.progressBar4);
            this.panel1.Controls.Add(this.progressBar3);
            this.panel1.Controls.Add(this.progressBar2);
            this.panel1.Controls.Add(this.progressBar1);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(908, 127);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(467, 353);
            this.panel1.TabIndex = 2;
            // 
            // word10
            // 
            this.word10.AutoSize = true;
            this.word10.Location = new System.Drawing.Point(72, 315);
            this.word10.Name = "word10";
            this.word10.Size = new System.Drawing.Size(23, 17);
            this.word10.TabIndex = 77;
            this.word10.Text = "\'C\'";
            // 
            // word9
            // 
            this.word9.AutoSize = true;
            this.word9.Location = new System.Drawing.Point(72, 288);
            this.word9.Name = "word9";
            this.word9.Size = new System.Drawing.Size(23, 17);
            this.word9.TabIndex = 76;
            this.word9.Text = "\'C\'";
            // 
            // word8
            // 
            this.word8.AutoSize = true;
            this.word8.Location = new System.Drawing.Point(72, 262);
            this.word8.Name = "word8";
            this.word8.Size = new System.Drawing.Size(23, 17);
            this.word8.TabIndex = 75;
            this.word8.Text = "\'C\'";
            // 
            // word7
            // 
            this.word7.AutoSize = true;
            this.word7.Location = new System.Drawing.Point(72, 235);
            this.word7.Name = "word7";
            this.word7.Size = new System.Drawing.Size(23, 17);
            this.word7.TabIndex = 74;
            this.word7.Text = "\'C\'";
            // 
            // word6
            // 
            this.word6.AutoSize = true;
            this.word6.Location = new System.Drawing.Point(72, 209);
            this.word6.Name = "word6";
            this.word6.Size = new System.Drawing.Size(23, 17);
            this.word6.TabIndex = 73;
            this.word6.Text = "\'C\'";
            // 
            // word5
            // 
            this.word5.AutoSize = true;
            this.word5.Location = new System.Drawing.Point(72, 182);
            this.word5.Name = "word5";
            this.word5.Size = new System.Drawing.Size(23, 17);
            this.word5.TabIndex = 72;
            this.word5.Text = "\'C\'";
            // 
            // word4
            // 
            this.word4.AutoSize = true;
            this.word4.Location = new System.Drawing.Point(72, 156);
            this.word4.Name = "word4";
            this.word4.Size = new System.Drawing.Size(23, 17);
            this.word4.TabIndex = 71;
            this.word4.Text = "\'C\'";
            // 
            // word3
            // 
            this.word3.AutoSize = true;
            this.word3.Location = new System.Drawing.Point(72, 130);
            this.word3.Name = "word3";
            this.word3.Size = new System.Drawing.Size(23, 17);
            this.word3.TabIndex = 70;
            this.word3.Text = "\'C\'";
            // 
            // word2
            // 
            this.word2.AutoSize = true;
            this.word2.Location = new System.Drawing.Point(72, 104);
            this.word2.Name = "word2";
            this.word2.Size = new System.Drawing.Size(23, 17);
            this.word2.TabIndex = 69;
            this.word2.Text = "\'C\'";
            // 
            // word1
            // 
            this.word1.AutoSize = true;
            this.word1.Location = new System.Drawing.Point(72, 78);
            this.word1.Name = "word1";
            this.word1.Size = new System.Drawing.Size(23, 17);
            this.word1.TabIndex = 68;
            this.word1.Text = "\'C\'";
            // 
            // pct10
            // 
            this.pct10.AutoSize = true;
            this.pct10.Location = new System.Drawing.Point(394, 314);
            this.pct10.Name = "pct10";
            this.pct10.Size = new System.Drawing.Size(24, 17);
            this.pct10.TabIndex = 67;
            this.pct10.Text = "25";
            // 
            // pct9
            // 
            this.pct9.AutoSize = true;
            this.pct9.Location = new System.Drawing.Point(394, 287);
            this.pct9.Name = "pct9";
            this.pct9.Size = new System.Drawing.Size(24, 17);
            this.pct9.TabIndex = 66;
            this.pct9.Text = "25";
            // 
            // pct8
            // 
            this.pct8.AutoSize = true;
            this.pct8.Location = new System.Drawing.Point(394, 261);
            this.pct8.Name = "pct8";
            this.pct8.Size = new System.Drawing.Size(24, 17);
            this.pct8.TabIndex = 65;
            this.pct8.Text = "25";
            // 
            // pct7
            // 
            this.pct7.AutoSize = true;
            this.pct7.Location = new System.Drawing.Point(394, 234);
            this.pct7.Name = "pct7";
            this.pct7.Size = new System.Drawing.Size(24, 17);
            this.pct7.TabIndex = 64;
            this.pct7.Text = "25";
            // 
            // pct6
            // 
            this.pct6.AutoSize = true;
            this.pct6.Location = new System.Drawing.Point(394, 208);
            this.pct6.Name = "pct6";
            this.pct6.Size = new System.Drawing.Size(24, 17);
            this.pct6.TabIndex = 63;
            this.pct6.Text = "25";
            // 
            // pct5
            // 
            this.pct5.AutoSize = true;
            this.pct5.Location = new System.Drawing.Point(394, 181);
            this.pct5.Name = "pct5";
            this.pct5.Size = new System.Drawing.Size(24, 17);
            this.pct5.TabIndex = 62;
            this.pct5.Text = "25";
            // 
            // pct4
            // 
            this.pct4.AutoSize = true;
            this.pct4.Location = new System.Drawing.Point(394, 155);
            this.pct4.Name = "pct4";
            this.pct4.Size = new System.Drawing.Size(24, 17);
            this.pct4.TabIndex = 61;
            this.pct4.Text = "25";
            // 
            // pct3
            // 
            this.pct3.AutoSize = true;
            this.pct3.Location = new System.Drawing.Point(394, 129);
            this.pct3.Name = "pct3";
            this.pct3.Size = new System.Drawing.Size(24, 17);
            this.pct3.TabIndex = 60;
            this.pct3.Text = "25";
            // 
            // pct2
            // 
            this.pct2.AutoSize = true;
            this.pct2.Location = new System.Drawing.Point(394, 103);
            this.pct2.Name = "pct2";
            this.pct2.Size = new System.Drawing.Size(24, 17);
            this.pct2.TabIndex = 59;
            this.pct2.Text = "25";
            // 
            // pct1
            // 
            this.pct1.AutoSize = true;
            this.pct1.Location = new System.Drawing.Point(394, 77);
            this.pct1.Name = "pct1";
            this.pct1.Size = new System.Drawing.Size(24, 17);
            this.pct1.TabIndex = 58;
            this.pct1.Text = "25";
            // 
            // totalCh10
            // 
            this.totalCh10.AutoSize = true;
            this.totalCh10.Location = new System.Drawing.Point(213, 314);
            this.totalCh10.Name = "totalCh10";
            this.totalCh10.Size = new System.Drawing.Size(32, 17);
            this.totalCh10.TabIndex = 57;
            this.totalCh10.Text = "100";
            // 
            // totalCh9
            // 
            this.totalCh9.AutoSize = true;
            this.totalCh9.Location = new System.Drawing.Point(213, 287);
            this.totalCh9.Name = "totalCh9";
            this.totalCh9.Size = new System.Drawing.Size(32, 17);
            this.totalCh9.TabIndex = 56;
            this.totalCh9.Text = "100";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(208, 49);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(42, 18);
            this.label25.TabIndex = 28;
            this.label25.Text = "Total";
            // 
            // totalCh8
            // 
            this.totalCh8.AutoSize = true;
            this.totalCh8.Location = new System.Drawing.Point(213, 261);
            this.totalCh8.Name = "totalCh8";
            this.totalCh8.Size = new System.Drawing.Size(32, 17);
            this.totalCh8.TabIndex = 55;
            this.totalCh8.Text = "100";
            // 
            // totalCh7
            // 
            this.totalCh7.AutoSize = true;
            this.totalCh7.Location = new System.Drawing.Point(213, 234);
            this.totalCh7.Name = "totalCh7";
            this.totalCh7.Size = new System.Drawing.Size(32, 17);
            this.totalCh7.TabIndex = 54;
            this.totalCh7.Text = "100";
            // 
            // totalCh6
            // 
            this.totalCh6.AutoSize = true;
            this.totalCh6.Location = new System.Drawing.Point(213, 208);
            this.totalCh6.Name = "totalCh6";
            this.totalCh6.Size = new System.Drawing.Size(32, 17);
            this.totalCh6.TabIndex = 53;
            this.totalCh6.Text = "100";
            // 
            // progressBar10
            // 
            this.progressBar10.Location = new System.Drawing.Point(282, 316);
            this.progressBar10.Name = "progressBar10";
            this.progressBar10.Size = new System.Drawing.Size(100, 16);
            this.progressBar10.TabIndex = 25;
            // 
            // totalCh5
            // 
            this.totalCh5.AutoSize = true;
            this.totalCh5.Location = new System.Drawing.Point(213, 181);
            this.totalCh5.Name = "totalCh5";
            this.totalCh5.Size = new System.Drawing.Size(32, 17);
            this.totalCh5.TabIndex = 52;
            this.totalCh5.Text = "100";
            // 
            // progressBar9
            // 
            this.progressBar9.Location = new System.Drawing.Point(282, 289);
            this.progressBar9.Name = "progressBar9";
            this.progressBar9.Size = new System.Drawing.Size(100, 16);
            this.progressBar9.TabIndex = 24;
            // 
            // totalCh4
            // 
            this.totalCh4.AutoSize = true;
            this.totalCh4.Location = new System.Drawing.Point(213, 155);
            this.totalCh4.Name = "totalCh4";
            this.totalCh4.Size = new System.Drawing.Size(32, 17);
            this.totalCh4.TabIndex = 51;
            this.totalCh4.Text = "100";
            // 
            // progressBar8
            // 
            this.progressBar8.Location = new System.Drawing.Point(282, 263);
            this.progressBar8.Name = "progressBar8";
            this.progressBar8.Size = new System.Drawing.Size(100, 16);
            this.progressBar8.TabIndex = 23;
            // 
            // totalCh3
            // 
            this.totalCh3.AutoSize = true;
            this.totalCh3.Location = new System.Drawing.Point(213, 129);
            this.totalCh3.Name = "totalCh3";
            this.totalCh3.Size = new System.Drawing.Size(32, 17);
            this.totalCh3.TabIndex = 50;
            this.totalCh3.Text = "100";
            // 
            // progressBar7
            // 
            this.progressBar7.Location = new System.Drawing.Point(282, 236);
            this.progressBar7.Name = "progressBar7";
            this.progressBar7.Size = new System.Drawing.Size(100, 16);
            this.progressBar7.TabIndex = 22;
            // 
            // totalCh2
            // 
            this.totalCh2.AutoSize = true;
            this.totalCh2.Location = new System.Drawing.Point(213, 103);
            this.totalCh2.Name = "totalCh2";
            this.totalCh2.Size = new System.Drawing.Size(32, 17);
            this.totalCh2.TabIndex = 49;
            this.totalCh2.Text = "100";
            // 
            // progressBar6
            // 
            this.progressBar6.Location = new System.Drawing.Point(282, 210);
            this.progressBar6.Name = "progressBar6";
            this.progressBar6.Size = new System.Drawing.Size(100, 16);
            this.progressBar6.TabIndex = 21;
            // 
            // totalCh1
            // 
            this.totalCh1.AutoSize = true;
            this.totalCh1.Location = new System.Drawing.Point(213, 78);
            this.totalCh1.Name = "totalCh1";
            this.totalCh1.Size = new System.Drawing.Size(32, 17);
            this.totalCh1.TabIndex = 48;
            this.totalCh1.Text = "100";
            // 
            // progressBar5
            // 
            this.progressBar5.Location = new System.Drawing.Point(282, 183);
            this.progressBar5.Name = "progressBar5";
            this.progressBar5.Size = new System.Drawing.Size(100, 16);
            this.progressBar5.TabIndex = 20;
            // 
            // progressBar4
            // 
            this.progressBar4.Location = new System.Drawing.Point(282, 157);
            this.progressBar4.Name = "progressBar4";
            this.progressBar4.Size = new System.Drawing.Size(100, 16);
            this.progressBar4.TabIndex = 19;
            // 
            // progressBar3
            // 
            this.progressBar3.Location = new System.Drawing.Point(282, 131);
            this.progressBar3.Name = "progressBar3";
            this.progressBar3.Size = new System.Drawing.Size(100, 16);
            this.progressBar3.TabIndex = 18;
            // 
            // progressBar2
            // 
            this.progressBar2.Location = new System.Drawing.Point(282, 105);
            this.progressBar2.Name = "progressBar2";
            this.progressBar2.Size = new System.Drawing.Size(100, 16);
            this.progressBar2.TabIndex = 17;
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(282, 78);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(100, 16);
            this.progressBar1.TabIndex = 16;
            this.progressBar1.Value = 25;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(14, 315);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(24, 17);
            this.label16.TabIndex = 15;
            this.label16.Text = "10";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(22, 288);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(16, 17);
            this.label15.TabIndex = 14;
            this.label15.Text = "9";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(22, 262);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(16, 17);
            this.label14.TabIndex = 13;
            this.label14.Text = "8";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(22, 235);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(16, 17);
            this.label13.TabIndex = 12;
            this.label13.Text = "7";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(22, 209);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(16, 17);
            this.label12.TabIndex = 11;
            this.label12.Text = "6";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(22, 182);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(16, 17);
            this.label11.TabIndex = 10;
            this.label11.Text = "5";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(22, 156);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(16, 17);
            this.label8.TabIndex = 9;
            this.label8.Text = "4";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(22, 130);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(16, 17);
            this.label10.TabIndex = 8;
            this.label10.Text = "3";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(22, 104);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(16, 17);
            this.label9.TabIndex = 7;
            this.label9.Text = "2";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(22, 78);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(16, 17);
            this.label7.TabIndex = 5;
            this.label7.Text = "1";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(394, 49);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(21, 18);
            this.label6.TabIndex = 4;
            this.label6.Text = "%";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(279, 49);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(68, 18);
            this.label5.TabIndex = 3;
            this.label5.Text = "Progress";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(72, 49);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(47, 18);
            this.label4.TabIndex = 2;
            this.label4.Text = "Word";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(21, 49);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(17, 18);
            this.label3.TabIndex = 1;
            this.label3.Text = "#";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label2.Location = new System.Drawing.Point(18, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(176, 19);
            this.label2.TabIndex = 0;
            this.label2.Text = "Top 10 Words Written";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.White;
            this.panel5.Controls.Add(this.stdWord);
            this.panel5.Controls.Add(this.meanWord);
            this.panel5.Controls.Add(this.wordsBS);
            this.panel5.Controls.Add(this.totalWords);
            this.panel5.Controls.Add(this.label20);
            this.panel5.Controls.Add(this.label21);
            this.panel5.Controls.Add(this.label24);
            this.panel5.Controls.Add(this.label27);
            this.panel5.Controls.Add(this.label46);
            this.panel5.Location = new System.Drawing.Point(374, 127);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(516, 170);
            this.panel5.TabIndex = 31;
            // 
            // stdWord
            // 
            this.stdWord.AutoSize = true;
            this.stdWord.Location = new System.Drawing.Point(299, 132);
            this.stdWord.Name = "stdWord";
            this.stdWord.Size = new System.Drawing.Size(24, 17);
            this.stdWord.TabIndex = 37;
            this.stdWord.Text = "20";
            // 
            // meanWord
            // 
            this.meanWord.AutoSize = true;
            this.meanWord.Location = new System.Drawing.Point(197, 105);
            this.meanWord.Name = "meanWord";
            this.meanWord.Size = new System.Drawing.Size(24, 17);
            this.meanWord.TabIndex = 36;
            this.meanWord.Text = "20";
            // 
            // wordsBS
            // 
            this.wordsBS.AutoSize = true;
            this.wordsBS.Location = new System.Drawing.Point(206, 78);
            this.wordsBS.Name = "wordsBS";
            this.wordsBS.Size = new System.Drawing.Size(24, 17);
            this.wordsBS.TabIndex = 32;
            this.wordsBS.Text = "20";
            // 
            // totalWords
            // 
            this.totalWords.AutoSize = true;
            this.totalWords.Location = new System.Drawing.Point(189, 49);
            this.totalWords.Name = "totalWords";
            this.totalWords.Size = new System.Drawing.Size(24, 17);
            this.totalWords.TabIndex = 32;
            this.totalWords.Text = "20";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(22, 76);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(178, 18);
            this.label20.TabIndex = 35;
            this.label20.Text = "Words with Backspace:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(22, 48);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(161, 18);
            this.label21.TabIndex = 34;
            this.label21.Text = "Total Count of Words:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(22, 131);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(271, 18);
            this.label24.TabIndex = 33;
            this.label24.Text = "Standard Derivation of Writting Time:";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(22, 103);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(169, 18);
            this.label27.TabIndex = 32;
            this.label27.Text = "Mean of Writting Time:";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.BackColor = System.Drawing.Color.White;
            this.label46.Font = new System.Drawing.Font("Century Gothic", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label46.Location = new System.Drawing.Point(18, 17);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(233, 19);
            this.label46.TabIndex = 0;
            this.label46.Text = "Analysis Based in all Events";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.BackColor = System.Drawing.Color.White;
            this.label45.Font = new System.Drawing.Font("Century Gothic", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label45.Location = new System.Drawing.Point(18, 17);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(121, 19);
            this.label45.TabIndex = 0;
            this.label45.Text = "Words By Size";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(20, 49);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(37, 18);
            this.label44.TabIndex = 1;
            this.label44.Text = "Size";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(133, 49);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(129, 18);
            this.label43.TabIndex = 2;
            this.label43.Text = "BackSpaces (%)";
            this.label43.Click += new System.EventHandler(this.label43_Click);
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(41, 75);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(16, 17);
            this.label39.TabIndex = 7;
            this.label39.Text = "2";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(41, 101);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(16, 17);
            this.label38.TabIndex = 8;
            this.label38.Text = "3";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(41, 127);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(16, 17);
            this.label37.TabIndex = 9;
            this.label37.Text = "4";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(41, 153);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(16, 17);
            this.label36.TabIndex = 10;
            this.label36.Text = "5";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(41, 180);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(16, 17);
            this.label34.TabIndex = 11;
            this.label34.Text = "6";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(41, 206);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(16, 17);
            this.label33.TabIndex = 12;
            this.label33.Text = "7";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(41, 233);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(16, 17);
            this.label32.TabIndex = 13;
            this.label32.Text = "8";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(41, 259);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(16, 17);
            this.label31.TabIndex = 14;
            this.label31.Text = "9";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(33, 286);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(24, 17);
            this.label30.TabIndex = 15;
            this.label30.Text = "10";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.White;
            this.panel4.Controls.Add(this.std15);
            this.panel4.Controls.Add(this.pctW15);
            this.panel4.Controls.Add(this.std14);
            this.panel4.Controls.Add(this.pctW14);
            this.panel4.Controls.Add(this.std13);
            this.panel4.Controls.Add(this.pctW13);
            this.panel4.Controls.Add(this.std12);
            this.panel4.Controls.Add(this.pctW12);
            this.panel4.Controls.Add(this.std11);
            this.panel4.Controls.Add(this.pctW11);
            this.panel4.Controls.Add(this.mean15);
            this.panel4.Controls.Add(this.mean14);
            this.panel4.Controls.Add(this.progress15);
            this.panel4.Controls.Add(this.mean13);
            this.panel4.Controls.Add(this.progress14);
            this.panel4.Controls.Add(this.mean12);
            this.panel4.Controls.Add(this.progress13);
            this.panel4.Controls.Add(this.mean11);
            this.panel4.Controls.Add(this.progress12);
            this.panel4.Controls.Add(this.progress11);
            this.panel4.Controls.Add(this.total15);
            this.panel4.Controls.Add(this.total14);
            this.panel4.Controls.Add(this.total13);
            this.panel4.Controls.Add(this.total12);
            this.panel4.Controls.Add(this.total11);
            this.panel4.Controls.Add(this.label58);
            this.panel4.Controls.Add(this.label59);
            this.panel4.Controls.Add(this.label60);
            this.panel4.Controls.Add(this.label61);
            this.panel4.Controls.Add(this.label62);
            this.panel4.Controls.Add(this.std10);
            this.panel4.Controls.Add(this.pctW10);
            this.panel4.Controls.Add(this.std9);
            this.panel4.Controls.Add(this.pctW9);
            this.panel4.Controls.Add(this.std8);
            this.panel4.Controls.Add(this.pctW8);
            this.panel4.Controls.Add(this.std7);
            this.panel4.Controls.Add(this.pctW7);
            this.panel4.Controls.Add(this.std6);
            this.panel4.Controls.Add(this.pctW6);
            this.panel4.Controls.Add(this.std5);
            this.panel4.Controls.Add(this.pctW5);
            this.panel4.Controls.Add(this.std4);
            this.panel4.Controls.Add(this.pctW4);
            this.panel4.Controls.Add(this.std3);
            this.panel4.Controls.Add(this.pctW3);
            this.panel4.Controls.Add(this.std2);
            this.panel4.Controls.Add(this.pctW2);
            this.panel4.Controls.Add(this.mean10);
            this.panel4.Controls.Add(this.mean9);
            this.panel4.Controls.Add(this.progress10);
            this.panel4.Controls.Add(this.mean8);
            this.panel4.Controls.Add(this.progress9);
            this.panel4.Controls.Add(this.mean7);
            this.panel4.Controls.Add(this.progress8);
            this.panel4.Controls.Add(this.mean6);
            this.panel4.Controls.Add(this.progress7);
            this.panel4.Controls.Add(this.mean5);
            this.panel4.Controls.Add(this.progress6);
            this.panel4.Controls.Add(this.mean4);
            this.panel4.Controls.Add(this.progress5);
            this.panel4.Controls.Add(this.mean3);
            this.panel4.Controls.Add(this.progress4);
            this.panel4.Controls.Add(this.mean2);
            this.panel4.Controls.Add(this.progress3);
            this.panel4.Controls.Add(this.total10);
            this.panel4.Controls.Add(this.progress2);
            this.panel4.Controls.Add(this.total9);
            this.panel4.Controls.Add(this.total8);
            this.panel4.Controls.Add(this.total7);
            this.panel4.Controls.Add(this.total6);
            this.panel4.Controls.Add(this.total5);
            this.panel4.Controls.Add(this.total4);
            this.panel4.Controls.Add(this.total3);
            this.panel4.Controls.Add(this.total2);
            this.panel4.Controls.Add(this.label23);
            this.panel4.Controls.Add(this.label22);
            this.panel4.Controls.Add(this.label19);
            this.panel4.Controls.Add(this.label30);
            this.panel4.Controls.Add(this.label31);
            this.panel4.Controls.Add(this.label32);
            this.panel4.Controls.Add(this.label33);
            this.panel4.Controls.Add(this.label34);
            this.panel4.Controls.Add(this.label36);
            this.panel4.Controls.Add(this.label37);
            this.panel4.Controls.Add(this.label38);
            this.panel4.Controls.Add(this.label39);
            this.panel4.Controls.Add(this.label43);
            this.panel4.Controls.Add(this.label44);
            this.panel4.Controls.Add(this.label45);
            this.panel4.Location = new System.Drawing.Point(376, 309);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(514, 446);
            this.panel4.TabIndex = 30;
            // 
            // std10
            // 
            this.std10.AutoSize = true;
            this.std10.Location = new System.Drawing.Point(407, 286);
            this.std10.Name = "std10";
            this.std10.Size = new System.Drawing.Size(24, 17);
            this.std10.TabIndex = 91;
            this.std10.Text = "25";
            // 
            // pctW10
            // 
            this.pctW10.AutoSize = true;
            this.pctW10.Location = new System.Drawing.Point(242, 286);
            this.pctW10.Name = "pctW10";
            this.pctW10.Size = new System.Drawing.Size(24, 17);
            this.pctW10.TabIndex = 96;
            this.pctW10.Text = "25";
            // 
            // std9
            // 
            this.std9.AutoSize = true;
            this.std9.Location = new System.Drawing.Point(407, 260);
            this.std9.Name = "std9";
            this.std9.Size = new System.Drawing.Size(24, 17);
            this.std9.TabIndex = 90;
            this.std9.Text = "25";
            // 
            // pctW9
            // 
            this.pctW9.AutoSize = true;
            this.pctW9.Location = new System.Drawing.Point(242, 260);
            this.pctW9.Name = "pctW9";
            this.pctW9.Size = new System.Drawing.Size(24, 17);
            this.pctW9.TabIndex = 95;
            this.pctW9.Text = "25";
            // 
            // std8
            // 
            this.std8.AutoSize = true;
            this.std8.Location = new System.Drawing.Point(407, 233);
            this.std8.Name = "std8";
            this.std8.Size = new System.Drawing.Size(24, 17);
            this.std8.TabIndex = 89;
            this.std8.Text = "25";
            // 
            // pctW8
            // 
            this.pctW8.AutoSize = true;
            this.pctW8.Location = new System.Drawing.Point(242, 233);
            this.pctW8.Name = "pctW8";
            this.pctW8.Size = new System.Drawing.Size(24, 17);
            this.pctW8.TabIndex = 94;
            this.pctW8.Text = "25";
            // 
            // std7
            // 
            this.std7.AutoSize = true;
            this.std7.Location = new System.Drawing.Point(407, 207);
            this.std7.Name = "std7";
            this.std7.Size = new System.Drawing.Size(24, 17);
            this.std7.TabIndex = 88;
            this.std7.Text = "25";
            // 
            // pctW7
            // 
            this.pctW7.AutoSize = true;
            this.pctW7.Location = new System.Drawing.Point(242, 207);
            this.pctW7.Name = "pctW7";
            this.pctW7.Size = new System.Drawing.Size(24, 17);
            this.pctW7.TabIndex = 93;
            this.pctW7.Text = "25";
            // 
            // std6
            // 
            this.std6.AutoSize = true;
            this.std6.Location = new System.Drawing.Point(407, 180);
            this.std6.Name = "std6";
            this.std6.Size = new System.Drawing.Size(24, 17);
            this.std6.TabIndex = 87;
            this.std6.Text = "25";
            // 
            // pctW6
            // 
            this.pctW6.AutoSize = true;
            this.pctW6.Location = new System.Drawing.Point(242, 180);
            this.pctW6.Name = "pctW6";
            this.pctW6.Size = new System.Drawing.Size(24, 17);
            this.pctW6.TabIndex = 92;
            this.pctW6.Text = "25";
            // 
            // std5
            // 
            this.std5.AutoSize = true;
            this.std5.Location = new System.Drawing.Point(407, 154);
            this.std5.Name = "std5";
            this.std5.Size = new System.Drawing.Size(24, 17);
            this.std5.TabIndex = 86;
            this.std5.Text = "25";
            // 
            // pctW5
            // 
            this.pctW5.AutoSize = true;
            this.pctW5.Location = new System.Drawing.Point(242, 154);
            this.pctW5.Name = "pctW5";
            this.pctW5.Size = new System.Drawing.Size(24, 17);
            this.pctW5.TabIndex = 91;
            this.pctW5.Text = "25";
            // 
            // std4
            // 
            this.std4.AutoSize = true;
            this.std4.Location = new System.Drawing.Point(407, 128);
            this.std4.Name = "std4";
            this.std4.Size = new System.Drawing.Size(24, 17);
            this.std4.TabIndex = 85;
            this.std4.Text = "25";
            // 
            // pctW4
            // 
            this.pctW4.AutoSize = true;
            this.pctW4.Location = new System.Drawing.Point(242, 128);
            this.pctW4.Name = "pctW4";
            this.pctW4.Size = new System.Drawing.Size(24, 17);
            this.pctW4.TabIndex = 90;
            this.pctW4.Text = "25";
            // 
            // std3
            // 
            this.std3.AutoSize = true;
            this.std3.Location = new System.Drawing.Point(407, 102);
            this.std3.Name = "std3";
            this.std3.Size = new System.Drawing.Size(24, 17);
            this.std3.TabIndex = 84;
            this.std3.Text = "25";
            // 
            // pctW3
            // 
            this.pctW3.AutoSize = true;
            this.pctW3.Location = new System.Drawing.Point(242, 102);
            this.pctW3.Name = "pctW3";
            this.pctW3.Size = new System.Drawing.Size(24, 17);
            this.pctW3.TabIndex = 89;
            this.pctW3.Text = "25";
            // 
            // std2
            // 
            this.std2.AutoSize = true;
            this.std2.Location = new System.Drawing.Point(407, 76);
            this.std2.Name = "std2";
            this.std2.Size = new System.Drawing.Size(24, 17);
            this.std2.TabIndex = 83;
            this.std2.Text = "25";
            // 
            // pctW2
            // 
            this.pctW2.AutoSize = true;
            this.pctW2.Location = new System.Drawing.Point(242, 76);
            this.pctW2.Name = "pctW2";
            this.pctW2.Size = new System.Drawing.Size(24, 17);
            this.pctW2.TabIndex = 88;
            this.pctW2.Text = "25";
            // 
            // mean10
            // 
            this.mean10.AutoSize = true;
            this.mean10.Location = new System.Drawing.Point(297, 286);
            this.mean10.Name = "mean10";
            this.mean10.Size = new System.Drawing.Size(24, 17);
            this.mean10.TabIndex = 82;
            this.mean10.Text = "25";
            // 
            // mean9
            // 
            this.mean9.AutoSize = true;
            this.mean9.Location = new System.Drawing.Point(297, 260);
            this.mean9.Name = "mean9";
            this.mean9.Size = new System.Drawing.Size(24, 17);
            this.mean9.TabIndex = 81;
            this.mean9.Text = "25";
            // 
            // progress10
            // 
            this.progress10.Location = new System.Drawing.Point(136, 287);
            this.progress10.Name = "progress10";
            this.progress10.Size = new System.Drawing.Size(100, 16);
            this.progress10.TabIndex = 86;
            // 
            // mean8
            // 
            this.mean8.AutoSize = true;
            this.mean8.Location = new System.Drawing.Point(297, 233);
            this.mean8.Name = "mean8";
            this.mean8.Size = new System.Drawing.Size(24, 17);
            this.mean8.TabIndex = 80;
            this.mean8.Text = "25";
            // 
            // progress9
            // 
            this.progress9.Location = new System.Drawing.Point(136, 261);
            this.progress9.Name = "progress9";
            this.progress9.Size = new System.Drawing.Size(100, 16);
            this.progress9.TabIndex = 85;
            // 
            // mean7
            // 
            this.mean7.AutoSize = true;
            this.mean7.Location = new System.Drawing.Point(297, 207);
            this.mean7.Name = "mean7";
            this.mean7.Size = new System.Drawing.Size(24, 17);
            this.mean7.TabIndex = 79;
            this.mean7.Text = "25";
            // 
            // progress8
            // 
            this.progress8.Location = new System.Drawing.Point(136, 235);
            this.progress8.Name = "progress8";
            this.progress8.Size = new System.Drawing.Size(100, 16);
            this.progress8.TabIndex = 84;
            // 
            // mean6
            // 
            this.mean6.AutoSize = true;
            this.mean6.Location = new System.Drawing.Point(297, 180);
            this.mean6.Name = "mean6";
            this.mean6.Size = new System.Drawing.Size(24, 17);
            this.mean6.TabIndex = 78;
            this.mean6.Text = "25";
            // 
            // progress7
            // 
            this.progress7.Location = new System.Drawing.Point(136, 208);
            this.progress7.Name = "progress7";
            this.progress7.Size = new System.Drawing.Size(100, 16);
            this.progress7.TabIndex = 83;
            // 
            // mean5
            // 
            this.mean5.AutoSize = true;
            this.mean5.Location = new System.Drawing.Point(297, 154);
            this.mean5.Name = "mean5";
            this.mean5.Size = new System.Drawing.Size(24, 17);
            this.mean5.TabIndex = 77;
            this.mean5.Text = "25";
            // 
            // progress6
            // 
            this.progress6.Location = new System.Drawing.Point(136, 181);
            this.progress6.Name = "progress6";
            this.progress6.Size = new System.Drawing.Size(100, 16);
            this.progress6.TabIndex = 82;
            // 
            // mean4
            // 
            this.mean4.AutoSize = true;
            this.mean4.Location = new System.Drawing.Point(297, 128);
            this.mean4.Name = "mean4";
            this.mean4.Size = new System.Drawing.Size(24, 17);
            this.mean4.TabIndex = 76;
            this.mean4.Text = "25";
            // 
            // progress5
            // 
            this.progress5.Location = new System.Drawing.Point(136, 155);
            this.progress5.Name = "progress5";
            this.progress5.Size = new System.Drawing.Size(100, 16);
            this.progress5.TabIndex = 81;
            // 
            // mean3
            // 
            this.mean3.AutoSize = true;
            this.mean3.Location = new System.Drawing.Point(297, 102);
            this.mean3.Name = "mean3";
            this.mean3.Size = new System.Drawing.Size(24, 17);
            this.mean3.TabIndex = 75;
            this.mean3.Text = "25";
            // 
            // progress4
            // 
            this.progress4.Location = new System.Drawing.Point(136, 130);
            this.progress4.Name = "progress4";
            this.progress4.Size = new System.Drawing.Size(100, 16);
            this.progress4.TabIndex = 80;
            // 
            // mean2
            // 
            this.mean2.AutoSize = true;
            this.mean2.Location = new System.Drawing.Point(297, 76);
            this.mean2.Name = "mean2";
            this.mean2.Size = new System.Drawing.Size(24, 17);
            this.mean2.TabIndex = 74;
            this.mean2.Text = "25";
            // 
            // progress3
            // 
            this.progress3.Location = new System.Drawing.Point(136, 103);
            this.progress3.Name = "progress3";
            this.progress3.Size = new System.Drawing.Size(100, 16);
            this.progress3.TabIndex = 79;
            // 
            // total10
            // 
            this.total10.AutoSize = true;
            this.total10.Location = new System.Drawing.Point(85, 286);
            this.total10.Name = "total10";
            this.total10.Size = new System.Drawing.Size(32, 17);
            this.total10.TabIndex = 66;
            this.total10.Text = "100";
            // 
            // progress2
            // 
            this.progress2.Location = new System.Drawing.Point(136, 77);
            this.progress2.Name = "progress2";
            this.progress2.Size = new System.Drawing.Size(100, 16);
            this.progress2.TabIndex = 78;
            this.progress2.Value = 25;
            // 
            // total9
            // 
            this.total9.AutoSize = true;
            this.total9.Location = new System.Drawing.Point(85, 260);
            this.total9.Name = "total9";
            this.total9.Size = new System.Drawing.Size(32, 17);
            this.total9.TabIndex = 65;
            this.total9.Text = "100";
            // 
            // total8
            // 
            this.total8.AutoSize = true;
            this.total8.Location = new System.Drawing.Point(85, 233);
            this.total8.Name = "total8";
            this.total8.Size = new System.Drawing.Size(32, 17);
            this.total8.TabIndex = 64;
            this.total8.Text = "100";
            // 
            // total7
            // 
            this.total7.AutoSize = true;
            this.total7.Location = new System.Drawing.Point(85, 207);
            this.total7.Name = "total7";
            this.total7.Size = new System.Drawing.Size(32, 17);
            this.total7.TabIndex = 63;
            this.total7.Text = "100";
            // 
            // total6
            // 
            this.total6.AutoSize = true;
            this.total6.Location = new System.Drawing.Point(85, 180);
            this.total6.Name = "total6";
            this.total6.Size = new System.Drawing.Size(32, 17);
            this.total6.TabIndex = 62;
            this.total6.Text = "100";
            // 
            // total5
            // 
            this.total5.AutoSize = true;
            this.total5.Location = new System.Drawing.Point(85, 154);
            this.total5.Name = "total5";
            this.total5.Size = new System.Drawing.Size(32, 17);
            this.total5.TabIndex = 61;
            this.total5.Text = "100";
            // 
            // total4
            // 
            this.total4.AutoSize = true;
            this.total4.Location = new System.Drawing.Point(85, 128);
            this.total4.Name = "total4";
            this.total4.Size = new System.Drawing.Size(32, 17);
            this.total4.TabIndex = 60;
            this.total4.Text = "100";
            // 
            // total3
            // 
            this.total3.AutoSize = true;
            this.total3.Location = new System.Drawing.Point(85, 102);
            this.total3.Name = "total3";
            this.total3.Size = new System.Drawing.Size(32, 17);
            this.total3.TabIndex = 59;
            this.total3.Text = "100";
            // 
            // total2
            // 
            this.total2.AutoSize = true;
            this.total2.Location = new System.Drawing.Point(85, 77);
            this.total2.Name = "total2";
            this.total2.Size = new System.Drawing.Size(32, 17);
            this.total2.TabIndex = 58;
            this.total2.Text = "100";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(75, 49);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(42, 18);
            this.label23.TabIndex = 30;
            this.label23.Text = "Total";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(407, 49);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(71, 18);
            this.label22.TabIndex = 31;
            this.label22.Text = "Std. Dev.";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(297, 49);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(51, 18);
            this.label19.TabIndex = 30;
            this.label19.Text = "Mean";
            // 
            // std15
            // 
            this.std15.AutoSize = true;
            this.std15.Location = new System.Drawing.Point(407, 416);
            this.std15.Name = "std15";
            this.std15.Size = new System.Drawing.Size(24, 17);
            this.std15.TabIndex = 121;
            this.std15.Text = "25";
            // 
            // pctW15
            // 
            this.pctW15.AutoSize = true;
            this.pctW15.Location = new System.Drawing.Point(242, 416);
            this.pctW15.Name = "pctW15";
            this.pctW15.Size = new System.Drawing.Size(24, 17);
            this.pctW15.TabIndex = 126;
            this.pctW15.Text = "25";
            // 
            // std14
            // 
            this.std14.AutoSize = true;
            this.std14.Location = new System.Drawing.Point(407, 390);
            this.std14.Name = "std14";
            this.std14.Size = new System.Drawing.Size(24, 17);
            this.std14.TabIndex = 120;
            this.std14.Text = "25";
            // 
            // pctW14
            // 
            this.pctW14.AutoSize = true;
            this.pctW14.Location = new System.Drawing.Point(242, 390);
            this.pctW14.Name = "pctW14";
            this.pctW14.Size = new System.Drawing.Size(24, 17);
            this.pctW14.TabIndex = 125;
            this.pctW14.Text = "25";
            // 
            // std13
            // 
            this.std13.AutoSize = true;
            this.std13.Location = new System.Drawing.Point(407, 363);
            this.std13.Name = "std13";
            this.std13.Size = new System.Drawing.Size(24, 17);
            this.std13.TabIndex = 119;
            this.std13.Text = "25";
            // 
            // pctW13
            // 
            this.pctW13.AutoSize = true;
            this.pctW13.Location = new System.Drawing.Point(242, 363);
            this.pctW13.Name = "pctW13";
            this.pctW13.Size = new System.Drawing.Size(24, 17);
            this.pctW13.TabIndex = 124;
            this.pctW13.Text = "25";
            // 
            // std12
            // 
            this.std12.AutoSize = true;
            this.std12.Location = new System.Drawing.Point(407, 337);
            this.std12.Name = "std12";
            this.std12.Size = new System.Drawing.Size(24, 17);
            this.std12.TabIndex = 118;
            this.std12.Text = "25";
            // 
            // pctW12
            // 
            this.pctW12.AutoSize = true;
            this.pctW12.Location = new System.Drawing.Point(242, 337);
            this.pctW12.Name = "pctW12";
            this.pctW12.Size = new System.Drawing.Size(24, 17);
            this.pctW12.TabIndex = 123;
            this.pctW12.Text = "25";
            // 
            // std11
            // 
            this.std11.AutoSize = true;
            this.std11.Location = new System.Drawing.Point(407, 310);
            this.std11.Name = "std11";
            this.std11.Size = new System.Drawing.Size(24, 17);
            this.std11.TabIndex = 117;
            this.std11.Text = "25";
            // 
            // pctW11
            // 
            this.pctW11.AutoSize = true;
            this.pctW11.Location = new System.Drawing.Point(242, 310);
            this.pctW11.Name = "pctW11";
            this.pctW11.Size = new System.Drawing.Size(24, 17);
            this.pctW11.TabIndex = 122;
            this.pctW11.Text = "25";
            // 
            // mean15
            // 
            this.mean15.AutoSize = true;
            this.mean15.Location = new System.Drawing.Point(297, 416);
            this.mean15.Name = "mean15";
            this.mean15.Size = new System.Drawing.Size(24, 17);
            this.mean15.TabIndex = 111;
            this.mean15.Text = "25";
            // 
            // mean14
            // 
            this.mean14.AutoSize = true;
            this.mean14.Location = new System.Drawing.Point(297, 390);
            this.mean14.Name = "mean14";
            this.mean14.Size = new System.Drawing.Size(24, 17);
            this.mean14.TabIndex = 110;
            this.mean14.Text = "25";
            // 
            // progress15
            // 
            this.progress15.Location = new System.Drawing.Point(136, 417);
            this.progress15.Name = "progress15";
            this.progress15.Size = new System.Drawing.Size(100, 16);
            this.progress15.TabIndex = 116;
            // 
            // mean13
            // 
            this.mean13.AutoSize = true;
            this.mean13.Location = new System.Drawing.Point(297, 363);
            this.mean13.Name = "mean13";
            this.mean13.Size = new System.Drawing.Size(24, 17);
            this.mean13.TabIndex = 109;
            this.mean13.Text = "25";
            // 
            // progress14
            // 
            this.progress14.Location = new System.Drawing.Point(136, 391);
            this.progress14.Name = "progress14";
            this.progress14.Size = new System.Drawing.Size(100, 16);
            this.progress14.TabIndex = 115;
            // 
            // mean12
            // 
            this.mean12.AutoSize = true;
            this.mean12.Location = new System.Drawing.Point(297, 337);
            this.mean12.Name = "mean12";
            this.mean12.Size = new System.Drawing.Size(24, 17);
            this.mean12.TabIndex = 108;
            this.mean12.Text = "25";
            // 
            // progress13
            // 
            this.progress13.Location = new System.Drawing.Point(136, 365);
            this.progress13.Name = "progress13";
            this.progress13.Size = new System.Drawing.Size(100, 16);
            this.progress13.TabIndex = 114;
            // 
            // mean11
            // 
            this.mean11.AutoSize = true;
            this.mean11.Location = new System.Drawing.Point(297, 310);
            this.mean11.Name = "mean11";
            this.mean11.Size = new System.Drawing.Size(24, 17);
            this.mean11.TabIndex = 107;
            this.mean11.Text = "25";
            // 
            // progress12
            // 
            this.progress12.Location = new System.Drawing.Point(136, 338);
            this.progress12.Name = "progress12";
            this.progress12.Size = new System.Drawing.Size(100, 16);
            this.progress12.TabIndex = 113;
            // 
            // progress11
            // 
            this.progress11.Location = new System.Drawing.Point(136, 311);
            this.progress11.Name = "progress11";
            this.progress11.Size = new System.Drawing.Size(100, 16);
            this.progress11.TabIndex = 112;
            // 
            // total15
            // 
            this.total15.AutoSize = true;
            this.total15.Location = new System.Drawing.Point(85, 416);
            this.total15.Name = "total15";
            this.total15.Size = new System.Drawing.Size(32, 17);
            this.total15.TabIndex = 106;
            this.total15.Text = "100";
            // 
            // total14
            // 
            this.total14.AutoSize = true;
            this.total14.Location = new System.Drawing.Point(85, 390);
            this.total14.Name = "total14";
            this.total14.Size = new System.Drawing.Size(32, 17);
            this.total14.TabIndex = 105;
            this.total14.Text = "100";
            // 
            // total13
            // 
            this.total13.AutoSize = true;
            this.total13.Location = new System.Drawing.Point(85, 363);
            this.total13.Name = "total13";
            this.total13.Size = new System.Drawing.Size(32, 17);
            this.total13.TabIndex = 104;
            this.total13.Text = "100";
            // 
            // total12
            // 
            this.total12.AutoSize = true;
            this.total12.Location = new System.Drawing.Point(85, 337);
            this.total12.Name = "total12";
            this.total12.Size = new System.Drawing.Size(32, 17);
            this.total12.TabIndex = 103;
            this.total12.Text = "100";
            // 
            // total11
            // 
            this.total11.AutoSize = true;
            this.total11.Location = new System.Drawing.Point(85, 310);
            this.total11.Name = "total11";
            this.total11.Size = new System.Drawing.Size(32, 17);
            this.total11.TabIndex = 102;
            this.total11.Text = "100";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(33, 416);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(24, 17);
            this.label58.TabIndex = 101;
            this.label58.Text = "15";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(33, 390);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(24, 17);
            this.label59.TabIndex = 100;
            this.label59.Text = "14";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(33, 364);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(24, 17);
            this.label60.TabIndex = 99;
            this.label60.Text = "13";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(33, 337);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(24, 17);
            this.label61.TabIndex = 98;
            this.label61.Text = "12";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(33, 311);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(24, 17);
            this.label62.TabIndex = 97;
            this.label62.Text = "11";
            // 
            // Dashboard3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightGray;
            this.ClientSize = new System.Drawing.Size(1387, 779);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.headerpanel);
            this.Controls.Add(this.sidepanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "Dashboard3";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "IAmTA - TP1";
            this.sidepanel.ResumeLayout(false);
            this.titlepanel.ResumeLayout(false);
            this.titlepanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.headerpanel.ResumeLayout(false);
            this.headerpanel.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel sidepanel;
        private System.Windows.Forms.Panel titlepanel;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label title;
        private System.Windows.Forms.Panel headerpanel;
        private System.Windows.Forms.Button KeyStrokeEventsButton;
        private System.Windows.Forms.Button SaveButton;
        private System.Windows.Forms.Button WordsAnalysisButton;
        private System.Windows.Forms.Button DigraphEventsButton;
        private System.Windows.Forms.Button BackButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ProgressBar progressBar10;
        private System.Windows.Forms.ProgressBar progressBar9;
        private System.Windows.Forms.ProgressBar progressBar8;
        private System.Windows.Forms.ProgressBar progressBar7;
        private System.Windows.Forms.ProgressBar progressBar6;
        private System.Windows.Forms.ProgressBar progressBar5;
        private System.Windows.Forms.ProgressBar progressBar4;
        private System.Windows.Forms.ProgressBar progressBar3;
        private System.Windows.Forms.ProgressBar progressBar2;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label stdWord;
        private System.Windows.Forms.Label meanWord;
        private System.Windows.Forms.Label wordsBS;
        private System.Windows.Forms.Label totalWords;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label totalCh10;
        private System.Windows.Forms.Label totalCh9;
        private System.Windows.Forms.Label totalCh8;
        private System.Windows.Forms.Label totalCh7;
        private System.Windows.Forms.Label totalCh6;
        private System.Windows.Forms.Label totalCh5;
        private System.Windows.Forms.Label totalCh4;
        private System.Windows.Forms.Label totalCh3;
        private System.Windows.Forms.Label totalCh2;
        private System.Windows.Forms.Label totalCh1;
        private System.Windows.Forms.Label pct10;
        private System.Windows.Forms.Label pct9;
        private System.Windows.Forms.Label pct8;
        private System.Windows.Forms.Label pct7;
        private System.Windows.Forms.Label pct6;
        private System.Windows.Forms.Label pct5;
        private System.Windows.Forms.Label pct4;
        private System.Windows.Forms.Label pct3;
        private System.Windows.Forms.Label pct2;
        private System.Windows.Forms.Label pct1;
        private System.Windows.Forms.Label word10;
        private System.Windows.Forms.Label word9;
        private System.Windows.Forms.Label word8;
        private System.Windows.Forms.Label word7;
        private System.Windows.Forms.Label word6;
        private System.Windows.Forms.Label word5;
        private System.Windows.Forms.Label word4;
        private System.Windows.Forms.Label word3;
        private System.Windows.Forms.Label word2;
        private System.Windows.Forms.Label word1;
        private System.Windows.Forms.Label total10;
        private System.Windows.Forms.Label total9;
        private System.Windows.Forms.Label total8;
        private System.Windows.Forms.Label total7;
        private System.Windows.Forms.Label total6;
        private System.Windows.Forms.Label total5;
        private System.Windows.Forms.Label total4;
        private System.Windows.Forms.Label total3;
        private System.Windows.Forms.Label total2;
        private System.Windows.Forms.Label mean10;
        private System.Windows.Forms.Label mean9;
        private System.Windows.Forms.Label mean8;
        private System.Windows.Forms.Label mean7;
        private System.Windows.Forms.Label mean6;
        private System.Windows.Forms.Label mean5;
        private System.Windows.Forms.Label mean4;
        private System.Windows.Forms.Label mean3;
        private System.Windows.Forms.Label mean2;
        private System.Windows.Forms.Label std10;
        private System.Windows.Forms.Label pctW10;
        private System.Windows.Forms.Label std9;
        private System.Windows.Forms.Label pctW9;
        private System.Windows.Forms.Label std8;
        private System.Windows.Forms.Label pctW8;
        private System.Windows.Forms.Label std7;
        private System.Windows.Forms.Label pctW7;
        private System.Windows.Forms.Label std6;
        private System.Windows.Forms.Label pctW6;
        private System.Windows.Forms.Label std5;
        private System.Windows.Forms.Label pctW5;
        private System.Windows.Forms.Label std4;
        private System.Windows.Forms.Label pctW4;
        private System.Windows.Forms.Label std3;
        private System.Windows.Forms.Label pctW3;
        private System.Windows.Forms.Label std2;
        private System.Windows.Forms.Label pctW2;
        private System.Windows.Forms.ProgressBar progress10;
        private System.Windows.Forms.ProgressBar progress9;
        private System.Windows.Forms.ProgressBar progress8;
        private System.Windows.Forms.ProgressBar progress7;
        private System.Windows.Forms.ProgressBar progress6;
        private System.Windows.Forms.ProgressBar progress5;
        private System.Windows.Forms.ProgressBar progress4;
        private System.Windows.Forms.ProgressBar progress3;
        private System.Windows.Forms.ProgressBar progress2;
        private System.Windows.Forms.Label std15;
        private System.Windows.Forms.Label pctW15;
        private System.Windows.Forms.Label std14;
        private System.Windows.Forms.Label pctW14;
        private System.Windows.Forms.Label std13;
        private System.Windows.Forms.Label pctW13;
        private System.Windows.Forms.Label std12;
        private System.Windows.Forms.Label pctW12;
        private System.Windows.Forms.Label std11;
        private System.Windows.Forms.Label pctW11;
        private System.Windows.Forms.Label mean15;
        private System.Windows.Forms.Label mean14;
        private System.Windows.Forms.ProgressBar progress15;
        private System.Windows.Forms.Label mean13;
        private System.Windows.Forms.ProgressBar progress14;
        private System.Windows.Forms.Label mean12;
        private System.Windows.Forms.ProgressBar progress13;
        private System.Windows.Forms.Label mean11;
        private System.Windows.Forms.ProgressBar progress12;
        private System.Windows.Forms.ProgressBar progress11;
        private System.Windows.Forms.Label total15;
        private System.Windows.Forms.Label total14;
        private System.Windows.Forms.Label total13;
        private System.Windows.Forms.Label total12;
        private System.Windows.Forms.Label total11;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label62;
    }
}