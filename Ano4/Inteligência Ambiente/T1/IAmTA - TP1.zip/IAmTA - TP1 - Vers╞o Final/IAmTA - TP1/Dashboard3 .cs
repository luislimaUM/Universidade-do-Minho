﻿using IAmTA___TP1.src;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IAmTA___TP1
{
    public partial class Dashboard3 : Form
    {
        private static Class1 programa = null;


        public Dashboard3()
        {
            InitializeComponent();
        }
        

        public void CarregaDados(Class1 pr)
        {
            programa = pr;

            programa.Words();
            programa.StoreWordsRelated();
            Dictionary<string, double> top10 = programa.getTop10Words();

            int total = programa.getTotalWords();
            totalWords.Text = total.ToString();
            wordsBS.Text = programa.getNumBackSpaceWords().ToString();

            word1.Text = top10.ElementAt(0).Key; totalCh1.Text = (top10.ElementAt(0).Value).ToString();
            progressBar1.Value = Convert.ToInt32((top10.ElementAt(0).Value / (double)total) * 100);
            pct1.Text = ((top10.ElementAt(0).Value / (double)total) * 100).ToString("F2");

            word2.Text = top10.ElementAt(1).Key; totalCh2.Text = (top10.ElementAt(1).Value).ToString();
            progressBar2.Value = Convert.ToInt32((top10.ElementAt(1).Value / (double)total) * 100);
            pct2.Text = ((top10.ElementAt(1).Value / (double)total) * 100).ToString("F2");

            word3.Text = top10.ElementAt(2).Key; totalCh3.Text = (top10.ElementAt(2).Value).ToString();
            progressBar3.Value = Convert.ToInt32((top10.ElementAt(2).Value / (double)total) * 100);
            pct3.Text = ((top10.ElementAt(2).Value / (double)total) * 100).ToString("F2");

            word4.Text = top10.ElementAt(3).Key; totalCh4.Text = (top10.ElementAt(3).Value).ToString();
            progressBar4.Value = Convert.ToInt32((top10.ElementAt(3).Value / (double)total) * 100);
            pct4.Text = ((top10.ElementAt(3).Value / (double)total) * 100).ToString("F2");

            word5.Text = top10.ElementAt(4).Key; totalCh5.Text = (top10.ElementAt(4).Value).ToString();
            progressBar5.Value = Convert.ToInt32((top10.ElementAt(4).Value / (double)total) * 100);
            pct5.Text = ((top10.ElementAt(4).Value / (double)total) * 100).ToString("F2");

            word6.Text = top10.ElementAt(5).Key; totalCh6.Text = (top10.ElementAt(5).Value).ToString();
            progressBar6.Value = Convert.ToInt32((top10.ElementAt(5).Value / (double)total) * 100);
            pct6.Text = ((top10.ElementAt(5).Value / (double)total) * 100).ToString("F2");

            word7.Text = top10.ElementAt(6).Key; totalCh7.Text = (top10.ElementAt(6).Value).ToString();
            progressBar7.Value = Convert.ToInt32((top10.ElementAt(6).Value / (double)total) * 100);
            pct7.Text = ((top10.ElementAt(6).Value / (double)total) * 100).ToString("F2");

            word8.Text = top10.ElementAt(7).Key; totalCh8.Text = (top10.ElementAt(7).Value).ToString();
            progressBar8.Value = Convert.ToInt32((top10.ElementAt(7).Value / (double)total) * 100);
            pct8.Text = ((top10.ElementAt(7).Value / (double)total) * 100).ToString("F2");

            word9.Text = top10.ElementAt(8).Key; totalCh9.Text = (top10.ElementAt(8).Value).ToString();
            progressBar9.Value = Convert.ToInt32((top10.ElementAt(8).Value / (double)total) * 100);
            pct9.Text = ((top10.ElementAt(8).Value / (double)total) * 100).ToString("F2");

            word10.Text = top10.ElementAt(9).Key; totalCh10.Text = (top10.ElementAt(9).Value).ToString();
            progressBar10.Value = Convert.ToInt32((top10.ElementAt(9).Value / (double)total) * 100);
            pct10.Text = ((top10.ElementAt(9).Value / (double)total) * 100).ToString("F2");

            meanWord.Text = programa.wordsMean().ToString("F2");
            stdWord.Text = programa.StandardDerivationWords().ToString("F2");
            

            total2.Text = programa.getNumWordsXChars(2).ToString();

            if (programa.getNumWordsXChars(2) != 0)
            {
                progress2.Value = Convert.ToInt32((programa.getNumWordsXCharsBackspace(2) / (double)programa.getNumWordsXChars(2)) * 100);
                pctW2.Text = ((programa.getNumWordsXCharsBackspace(2) / (double)programa.getNumWordsXChars(2)) * 100).ToString("F2");
                mean2.Text = programa.WordsMeanWithXChars(2).ToString("F2");
                std2.Text = programa.StandardDerivationWordsWithXChars(2).ToString("F2");
            } else
            {
                progress2.Value = 0; pctW2.Text = "0"; mean2.Text = "0"; std2.Text = "0";
            }

            total3.Text = programa.getNumWordsXChars(3).ToString();
            if (programa.getNumWordsXChars(3) != 0)
            {
                progress3.Value = Convert.ToInt32((programa.getNumWordsXCharsBackspace(3) / (double)programa.getNumWordsXChars(3)) * 100);
                pctW3.Text = ((programa.getNumWordsXCharsBackspace(3) / (double)programa.getNumWordsXChars(3)) * 100).ToString("F2");
                mean3.Text = programa.WordsMeanWithXChars(3).ToString("F2");
                std3.Text = programa.StandardDerivationWordsWithXChars(3).ToString("F2");
            }
            else
            {
                progress3.Value = 0; pctW3.Text = "0"; mean3.Text = "0"; std3.Text = "0";
            }

            total4.Text = programa.getNumWordsXChars(4).ToString();
            if (programa.getNumWordsXChars(4) != 0)
            {
                progress4.Value = Convert.ToInt32((programa.getNumWordsXCharsBackspace(4) / (double)programa.getNumWordsXChars(4)) * 100);
                pctW4.Text = ((programa.getNumWordsXCharsBackspace(4) / (double)programa.getNumWordsXChars(4)) * 100).ToString("F2");
                mean4.Text = programa.WordsMeanWithXChars(4).ToString("F2");
                std4.Text = programa.StandardDerivationWordsWithXChars(4).ToString("F2");
            }
            else
            {
                progress4.Value = 0; pctW4.Text = "0"; mean4.Text = "0"; std4.Text = "0";
            }

           
            total5.Text = programa.getNumWordsXChars(5).ToString();
            if (programa.getNumWordsXChars(5) != 0)
            {
                progress5.Value = Convert.ToInt32((programa.getNumWordsXCharsBackspace(5) / (double)programa.getNumWordsXChars(5)) * 100);
                pctW5.Text = ((programa.getNumWordsXCharsBackspace(5) / (double)programa.getNumWordsXChars(5)) * 100).ToString("F2");
                mean5.Text = programa.WordsMeanWithXChars(5).ToString("F2");
                std5.Text = programa.StandardDerivationWordsWithXChars(5).ToString("F2");
            }
            else
            {
                progress5.Value = 0; pctW5.Text = "0"; mean5.Text = "0"; std5.Text = "0";
            }

            

            total6.Text = programa.getNumWordsXChars(6).ToString();
            if (programa.getNumWordsXChars(6) != 0)
            {
                progress6.Value = Convert.ToInt32((programa.getNumWordsXCharsBackspace(6) / (double)programa.getNumWordsXChars(6)) * 100);
                pctW6.Text = ((programa.getNumWordsXCharsBackspace(6) / (double)programa.getNumWordsXChars(6)) * 100).ToString("F2");
                mean6.Text = programa.WordsMeanWithXChars(6).ToString("F2");
                std6.Text = programa.StandardDerivationWordsWithXChars(6).ToString("F2");
            }
            else
            {
                progress6.Value = 0; pctW6.Text = "0"; mean6.Text = "0"; std6.Text = "0";
            }
            

            total7.Text = programa.getNumWordsXChars(7).ToString();
            if (programa.getNumWordsXChars(7) != 0)
            {
                progress7.Value = Convert.ToInt32((programa.getNumWordsXCharsBackspace(7) / (double)programa.getNumWordsXChars(7)) * 100);
                pctW7.Text = ((programa.getNumWordsXCharsBackspace(7) / (double)programa.getNumWordsXChars(7)) * 100).ToString("F2");
                mean7.Text = programa.WordsMeanWithXChars(7).ToString("F2");
                std7.Text = programa.StandardDerivationWordsWithXChars(7).ToString("F2");
            }
            else
            {
                progress7.Value = 0; pctW7.Text = "0"; mean7.Text = "0"; std7.Text = "0";
            }

            
            total8.Text = programa.getNumWordsXChars(8).ToString();
            if (programa.getNumWordsXChars(8) != 0)
            {
                progress8.Value = Convert.ToInt32((programa.getNumWordsXCharsBackspace(8) / (double)programa.getNumWordsXChars(8)) * 100);
                pctW8.Text = ((programa.getNumWordsXCharsBackspace(8) / (double)programa.getNumWordsXChars(8)) * 100).ToString("F2");
                mean8.Text = programa.WordsMeanWithXChars(8).ToString("F2");
                std8.Text = programa.StandardDerivationWordsWithXChars(8).ToString("F2");
            }
            else
            {
                progress8.Value = 0; pctW8.Text = "0"; mean8.Text = "0"; std8.Text = "0";
            }

            
            total9.Text = programa.getNumWordsXChars(9).ToString();
            if (programa.getNumWordsXChars(9) != 0)
            {
                progress9.Value = Convert.ToInt32((programa.getNumWordsXCharsBackspace(9) / (double)programa.getNumWordsXChars(9)) * 100);
                pctW9.Text = ((programa.getNumWordsXCharsBackspace(9) / (double)programa.getNumWordsXChars(9)) * 100).ToString("F2");
                mean9.Text = programa.WordsMeanWithXChars(9).ToString("F2");
                std9.Text = programa.StandardDerivationWordsWithXChars(9).ToString("F2");
            }
            else
            {
                progress9.Value = 0; pctW9.Text = "0"; mean9.Text = "0"; std9.Text = "0";
            }

            total10.Text = programa.getNumWordsXChars(10).ToString();
            if (programa.getNumWordsXChars(10) != 0)
            {
                progress10.Value = Convert.ToInt32((programa.getNumWordsXCharsBackspace(10) / (double)programa.getNumWordsXChars(10)) * 100);
                pctW10.Text = ((programa.getNumWordsXCharsBackspace(10) / (double)programa.getNumWordsXChars(10)) * 100).ToString("F2");
                mean10.Text = programa.WordsMeanWithXChars(10).ToString("F2");
                std10.Text = programa.StandardDerivationWordsWithXChars(10).ToString("F2");
            }
            else
            {
                progress10.Value = 0; pctW10.Text = "0"; mean10.Text = "0"; std10.Text = "0";
            }

            

            total11.Text = programa.getNumWordsXChars(11).ToString();
            if (programa.getNumWordsXChars(11) != 0)
            {
                progress11.Value = Convert.ToInt32((programa.getNumWordsXCharsBackspace(11) / (double)programa.getNumWordsXChars(11)) * 100);
                pctW11.Text = ((programa.getNumWordsXCharsBackspace(11) / (double)programa.getNumWordsXChars(11)) * 100).ToString("F2");
                mean11.Text = programa.WordsMeanWithXChars(11).ToString("F2");
                std11.Text = programa.StandardDerivationWordsWithXChars(11).ToString("F2");
            }
            else
            {
                progress11.Value = 0; pctW11.Text = "0"; mean11.Text = "0"; std11.Text = "0";
            }
            

            total12.Text = programa.getNumWordsXChars(12).ToString();
            if (programa.getNumWordsXChars(12) != 0)
            {
                progress12.Value = Convert.ToInt32((programa.getNumWordsXCharsBackspace(12) / (double)programa.getNumWordsXChars(12)) * 100);
                pctW12.Text = ((programa.getNumWordsXCharsBackspace(12) / (double)programa.getNumWordsXChars(12)) * 100).ToString("F2");
                mean12.Text = programa.WordsMeanWithXChars(12).ToString("F2");
                std12.Text = programa.StandardDerivationWordsWithXChars(12).ToString("F2");
            }
            else
            {
                progress12.Value = 0; pctW12.Text = "0"; mean12.Text = "0"; std12.Text = "0";
            }

            

            total13.Text = programa.getNumWordsXChars(13).ToString();
            if (programa.getNumWordsXChars(13) != 0)
            {
                progress13.Value = Convert.ToInt32((programa.getNumWordsXCharsBackspace(13) / (double)programa.getNumWordsXChars(13)) * 100);
                pctW13.Text = ((programa.getNumWordsXCharsBackspace(13) / (double)programa.getNumWordsXChars(13)) * 100).ToString("F2");
                mean13.Text = programa.WordsMeanWithXChars(13).ToString("F2");
                std13.Text = programa.StandardDerivationWordsWithXChars(13).ToString("F2");
            }
            else
            {
                progress13.Value = 0; pctW13.Text = "0"; mean13.Text = "0"; std13.Text = "0";
            }


            total14.Text = programa.getNumWordsXChars(14).ToString();
            if (programa.getNumWordsXChars(14) != 0)
            {
                progress14.Value = Convert.ToInt32((programa.getNumWordsXCharsBackspace(14) / (double)programa.getNumWordsXChars(14)) * 100);
                pctW14.Text = ((programa.getNumWordsXCharsBackspace(14) / (double)programa.getNumWordsXChars(14)) * 100).ToString("F2");
                mean14.Text = programa.WordsMeanWithXChars(14).ToString("F2");
                std14.Text = programa.StandardDerivationWordsWithXChars(14).ToString("F2");
            }
            else
            {
                progress14.Value = 0; pctW14.Text = "0"; mean14.Text = "0"; std14.Text = "0";
            }

            

            total15.Text = programa.getNumWordsXChars(15).ToString();
            if (programa.getNumWordsXChars(15) != 0)
            {
                progress15.Value = Convert.ToInt32((programa.getNumWordsXCharsBackspace(15) / (double)programa.getNumWordsXChars(15)) * 100);
                pctW15.Text = ((programa.getNumWordsXCharsBackspace(15) / (double)programa.getNumWordsXChars(15)) * 100).ToString("F2");
                mean15.Text = programa.WordsMeanWithXChars(15).ToString("F2");
                std15.Text = programa.StandardDerivationWordsWithXChars(15).ToString("F2");
                Console.WriteLine(programa.StandardDerivationWordsWithXChars(15));
            }
            else
            {
                progress15.Value = 0; pctW15.Text = "0"; mean15.Text = "0"; std15.Text = "0";
            }

            
           
        }

        private void label43_Click(object sender, EventArgs e)
        {

        }

        private void KeyStrokeEventsButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Dashboard1 d1 = new Dashboard1();
            d1.CarregaDados(programa);
            d1.ShowDialog();
        }

        private void DigraphEventsButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Dashboard2 d2 = new Dashboard2();
            d2.CarregaDados(programa);
            d2.ShowDialog();
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            DashboardSave d = new DashboardSave();
            d.CarregaDados(programa);
            d.ShowDialog();
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Dashboard0 d0 = new Dashboard0();

            d0.ShowDialog();
        }
    }
}
