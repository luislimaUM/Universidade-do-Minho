﻿namespace IAmTA___TP1
{
    partial class DashboardSave
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DashboardSave));
            this.sidepanel = new System.Windows.Forms.Panel();
            this.BackButton = new System.Windows.Forms.Button();
            this.SaveButton = new System.Windows.Forms.Button();
            this.WordsAnalysisButton = new System.Windows.Forms.Button();
            this.DigraphEventsButton = new System.Windows.Forms.Button();
            this.KeyStrokeEventsButton = new System.Windows.Forms.Button();
            this.titlepanel = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.title = new System.Windows.Forms.Label();
            this.headerpanel = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.date = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.okButton = new System.Windows.Forms.Button();
            this.username = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.sidepanel.SuspendLayout();
            this.titlepanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.headerpanel.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // sidepanel
            // 
            this.sidepanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(43)))), ((int)(((byte)(55)))));
            this.sidepanel.Controls.Add(this.BackButton);
            this.sidepanel.Controls.Add(this.SaveButton);
            this.sidepanel.Controls.Add(this.WordsAnalysisButton);
            this.sidepanel.Controls.Add(this.DigraphEventsButton);
            this.sidepanel.Controls.Add(this.KeyStrokeEventsButton);
            this.sidepanel.Controls.Add(this.titlepanel);
            this.sidepanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.sidepanel.Location = new System.Drawing.Point(0, 0);
            this.sidepanel.Name = "sidepanel";
            this.sidepanel.Size = new System.Drawing.Size(340, 455);
            this.sidepanel.TabIndex = 0;
            // 
            // BackButton
            // 
            this.BackButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(43)))), ((int)(((byte)(55)))));
            this.BackButton.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.BackButton.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray;
            this.BackButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BackButton.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BackButton.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.BackButton.Location = new System.Drawing.Point(0, 405);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(340, 50);
            this.BackButton.TabIndex = 5;
            this.BackButton.Text = "Back";
            this.BackButton.UseVisualStyleBackColor = false;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // SaveButton
            // 
            this.SaveButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(53)))), ((int)(((byte)(65)))));
            this.SaveButton.Dock = System.Windows.Forms.DockStyle.Top;
            this.SaveButton.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray;
            this.SaveButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SaveButton.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SaveButton.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.SaveButton.Location = new System.Drawing.Point(0, 247);
            this.SaveButton.Name = "SaveButton";
            this.SaveButton.Size = new System.Drawing.Size(340, 50);
            this.SaveButton.TabIndex = 4;
            this.SaveButton.Text = "Save";
            this.SaveButton.UseVisualStyleBackColor = false;
            // 
            // WordsAnalysisButton
            // 
            this.WordsAnalysisButton.Dock = System.Windows.Forms.DockStyle.Top;
            this.WordsAnalysisButton.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray;
            this.WordsAnalysisButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.WordsAnalysisButton.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WordsAnalysisButton.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.WordsAnalysisButton.Location = new System.Drawing.Point(0, 197);
            this.WordsAnalysisButton.Name = "WordsAnalysisButton";
            this.WordsAnalysisButton.Size = new System.Drawing.Size(340, 50);
            this.WordsAnalysisButton.TabIndex = 3;
            this.WordsAnalysisButton.Text = "Words Analysis";
            this.WordsAnalysisButton.UseVisualStyleBackColor = true;
            this.WordsAnalysisButton.Click += new System.EventHandler(this.WordsAnalysisButton_Click);
            // 
            // DigraphEventsButton
            // 
            this.DigraphEventsButton.Dock = System.Windows.Forms.DockStyle.Top;
            this.DigraphEventsButton.FlatAppearance.BorderColor = System.Drawing.Color.DarkGray;
            this.DigraphEventsButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DigraphEventsButton.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DigraphEventsButton.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.DigraphEventsButton.Location = new System.Drawing.Point(0, 147);
            this.DigraphEventsButton.Name = "DigraphEventsButton";
            this.DigraphEventsButton.Size = new System.Drawing.Size(340, 50);
            this.DigraphEventsButton.TabIndex = 2;
            this.DigraphEventsButton.Text = "Digraph Events";
            this.DigraphEventsButton.UseVisualStyleBackColor = true;
            this.DigraphEventsButton.Click += new System.EventHandler(this.DigraphEventsButton_Click);
            // 
            // KeyStrokeEventsButton
            // 
            this.KeyStrokeEventsButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(43)))), ((int)(((byte)(55)))));
            this.KeyStrokeEventsButton.Dock = System.Windows.Forms.DockStyle.Top;
            this.KeyStrokeEventsButton.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.KeyStrokeEventsButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.KeyStrokeEventsButton.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.KeyStrokeEventsButton.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.KeyStrokeEventsButton.Location = new System.Drawing.Point(0, 97);
            this.KeyStrokeEventsButton.Name = "KeyStrokeEventsButton";
            this.KeyStrokeEventsButton.Size = new System.Drawing.Size(340, 50);
            this.KeyStrokeEventsButton.TabIndex = 1;
            this.KeyStrokeEventsButton.Text = "KeyStroke Events";
            this.KeyStrokeEventsButton.UseVisualStyleBackColor = false;
            this.KeyStrokeEventsButton.Click += new System.EventHandler(this.KeyStrokeEventsButton_Click);
            // 
            // titlepanel
            // 
            this.titlepanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(126)))), ((int)(((byte)(49)))));
            this.titlepanel.Controls.Add(this.pictureBox1);
            this.titlepanel.Controls.Add(this.title);
            this.titlepanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.titlepanel.Location = new System.Drawing.Point(0, 0);
            this.titlepanel.Name = "titlepanel";
            this.titlepanel.Size = new System.Drawing.Size(340, 97);
            this.titlepanel.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(40, 33);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(70, 37);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // title
            // 
            this.title.AutoSize = true;
            this.title.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.title.ForeColor = System.Drawing.Color.White;
            this.title.Location = new System.Drawing.Point(129, 42);
            this.title.Name = "title";
            this.title.Size = new System.Drawing.Size(148, 28);
            this.title.TabIndex = 0;
            this.title.Text = "IAmTA - TP1";
            // 
            // headerpanel
            // 
            this.headerpanel.BackColor = System.Drawing.Color.Snow;
            this.headerpanel.Controls.Add(this.label1);
            this.headerpanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.headerpanel.Location = new System.Drawing.Point(340, 0);
            this.headerpanel.Name = "headerpanel";
            this.headerpanel.Size = new System.Drawing.Size(750, 97);
            this.headerpanel.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(29, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(223, 30);
            this.label1.TabIndex = 2;
            this.label1.Text = "Save in Database";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.date);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.okButton);
            this.panel2.Controls.Add(this.username);
            this.panel2.Controls.Add(this.label35);
            this.panel2.Location = new System.Drawing.Point(362, 145);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(702, 223);
            this.panel2.TabIndex = 29;
            // 
            // date
            // 
            this.date.Location = new System.Drawing.Point(22, 124);
            this.date.Multiline = true;
            this.date.Name = "date";
            this.date.Size = new System.Drawing.Size(508, 28);
            this.date.TabIndex = 8;
            this.date.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label2.Location = new System.Drawing.Point(18, 90);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(181, 19);
            this.label2.TabIndex = 7;
            this.label2.Text = "Date (YYYY-MM-DD):";
            // 
            // okButton
            // 
            this.okButton.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.okButton.Location = new System.Drawing.Point(22, 175);
            this.okButton.Name = "okButton";
            this.okButton.Size = new System.Drawing.Size(48, 29);
            this.okButton.TabIndex = 6;
            this.okButton.Text = "Save";
            this.okButton.UseVisualStyleBackColor = true;
            this.okButton.Click += new System.EventHandler(this.okButton_Click);
            // 
            // username
            // 
            this.username.Location = new System.Drawing.Point(22, 51);
            this.username.Multiline = true;
            this.username.Name = "username";
            this.username.Size = new System.Drawing.Size(508, 28);
            this.username.TabIndex = 4;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.BackColor = System.Drawing.Color.White;
            this.label35.Font = new System.Drawing.Font("Century Gothic", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label35.Location = new System.Drawing.Point(18, 17);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(96, 19);
            this.label35.TabIndex = 0;
            this.label35.Text = "Username:";
            // 
            // DashboardSave
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightGray;
            this.ClientSize = new System.Drawing.Size(1090, 455);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.headerpanel);
            this.Controls.Add(this.sidepanel);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "DashboardSave";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "IAmTA - TP1";
            this.sidepanel.ResumeLayout(false);
            this.titlepanel.ResumeLayout(false);
            this.titlepanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.headerpanel.ResumeLayout(false);
            this.headerpanel.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel sidepanel;
        private System.Windows.Forms.Panel titlepanel;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label title;
        private System.Windows.Forms.Panel headerpanel;
        private System.Windows.Forms.Button KeyStrokeEventsButton;
        private System.Windows.Forms.Button SaveButton;
        private System.Windows.Forms.Button WordsAnalysisButton;
        private System.Windows.Forms.Button DigraphEventsButton;
        private System.Windows.Forms.Button BackButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox date;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button okButton;
        private System.Windows.Forms.TextBox username;
        private System.Windows.Forms.Label label35;
    }
}