﻿using IAmTA___TP1.src;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IAmTA___TP1
{
    public partial class Dashboard0 : Form
    {
        public Dashboard0()
        {
            InitializeComponent();
        }

        OpenFileDialog ofd = new OpenFileDialog();

        private void searchFile_Click(object sender, EventArgs e)
        {
            ofd.Filter = "Text|*.txt";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                filePath.Text = ofd.FileName;
            }
        }

        private void okButton_Click(object sender, EventArgs e)
        {
            if (filePath.Text != "")
            {
                this.Hide();
                Dashboard1 d1 = new Dashboard1();
                Class1 programa = new Class1(filePath.Text);
                d1.CarregaDados(programa);
                
                d1.ShowDialog();
            }
        }
    }
}
