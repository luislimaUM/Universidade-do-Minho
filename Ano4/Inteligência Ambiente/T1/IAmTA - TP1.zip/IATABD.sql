-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `mydb` DEFAULT CHARACTER SET utf8 ;
USE `mydb` ;

-- -----------------------------------------------------
-- Table `mydb`.`utilizador`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`utilizador` (
  `idUtilizador` INT(11) NOT NULL AUTO_INCREMENT,
  `Nome` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`idUtilizador`),
  UNIQUE INDEX `Nome_UNIQUE` (`Nome` ASC))
ENGINE = InnoDB
AUTO_INCREMENT = 50
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `mydb`.`dados`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`dados` (
  `idData` INT(11) NOT NULL AUTO_INCREMENT,
  `idUtilizador` INT(11) NOT NULL,
  `Data` VARCHAR(45) NOT NULL,
  `Num_Chars` INT(11) NOT NULL,
  `Num_Backspace` INT(11) NOT NULL,
  `Num_Words` INT(11) NOT NULL,
  `Num_Palavras_Backspace` INT(11) NOT NULL,
  `Media_Char` DOUBLE NOT NULL,
  `DesvioPadrao_Char` DOUBLE NOT NULL,
  `Media_Words` DOUBLE NOT NULL,
  `DesvioPadrao_Words` DOUBLE NOT NULL,
  PRIMARY KEY (`idData`, `idUtilizador`),
  INDEX `idUtilizador_idx` (`idUtilizador` ASC),
  CONSTRAINT `idUtilizador`
    FOREIGN KEY (`idUtilizador`)
    REFERENCES `mydb`.`utilizador` (`idUtilizador`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 19
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `mydb`.`metricas_layout`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`metricas_layout` (
  `idData` INT(11) NOT NULL,
  `Num_Chars` INT(11) NOT NULL,
  `Num_Utilizacao` INT(11) NOT NULL,
  `layout` VARCHAR(45) NOT NULL,
  `Media` DOUBLE NOT NULL,
  `DesvioPadrao` DOUBLE NOT NULL,
  PRIMARY KEY (`idData`, `layout`),
  INDEX `idData_idx` (`idData` ASC),
  CONSTRAINT `idData_Layout`
    FOREIGN KEY (`idData`)
    REFERENCES `mydb`.`dados` (`idData`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `mydb`.`metricas_words`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`metricas_words` (
  `idData` INT(11) NOT NULL,
  `Word` VARCHAR(45) NOT NULL,
  `Lenght` INT(11) NOT NULL,
  `Num_Rep` INT(11) NOT NULL,
  `BackSpace` INT(11) NOT NULL,
  `Media` DOUBLE NOT NULL,
  PRIMARY KEY (`Word`, `idData`),
  INDEX `idData_Words` (`idData` ASC),
  CONSTRAINT `idData_Words`
    FOREIGN KEY (`idData`)
    REFERENCES `mydb`.`dados` (`idData`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `mydb`.`topwords`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`topwords` (
  `idData` INT(11) NOT NULL,
  `Word` VARCHAR(45) NOT NULL,
  `Num_Rep` INT(11) NOT NULL,
  `Uso` INT(11) NOT NULL,
  PRIMARY KEY (`Word`, `idData`),
  INDEX `idData` (`idData` ASC),
  CONSTRAINT `idData`
    FOREIGN KEY (`idData`)
    REFERENCES `mydb`.`dados` (`idData`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
