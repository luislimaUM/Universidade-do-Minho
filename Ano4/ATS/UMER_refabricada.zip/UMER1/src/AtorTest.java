import java.lang.reflect.*;
import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import java.util.GregorianCalendar;
import java.util.*;


public class AtorTest {
	
	// Instâncias
	Ator c1, c2;
	Viagem v1, v2, v3, v4;
	Set<Viagem> histc1 = new TreeSet<Viagem>();
	Set<Viagem> histc2 = new TreeSet<Viagem>();
	
	// Antes de cada @Test executa o setUp para construir as intâncias
	@Before
	public void setUp() {
	c1 = new Cliente("bruno_1_dantas@hotmail.com","Bruno","123456","Ponte de Lima","15-10-1996", histc1, 60);
	c2 = new Cliente("luis.soccer5@gmail.com","Luis","123456","Arcos de Valdevez","23-07-1997", histc2, 60);
	v1 = new Viagem(new Coordenada(1,1),new Coordenada(17,6),60,"bruno_1_dantas@hotmail.com",new GregorianCalendar(2017,12,17),57,10);
	v2 = new Viagem(new Coordenada(152,151),new Coordenada(153,15),69,"luis.soccer5@gmail.com",new GregorianCalendar(2017,9,15),59,15);
	v3 = new Viagem(new Coordenada(169,169),new Coordenada(145,1023),100,"pedrofonseca@gmail.com",new GregorianCalendar(2017,12,23),100,20);
	v4 = new Viagem(new Coordenada(123,153),new Coordenada(14,314),200,"pedrofonseca@gmail.com",new GregorianCalendar(2017,12,01),500,50);
	}
	
	// Teste ao método registaViagem
	@Test
	public void registaViagemTest() {
		Set<Viagem> aux = new TreeSet<Viagem>();
		c1.registaViagem(v1);
		aux.add(v1);
    	assertEquals(aux,c1.getHistorico());
    	c1.registaViagem(v2); c1.registaViagem(v4);
    	aux.add(v2); aux.add(v4);
    	assertEquals(aux,c1.getHistorico());
	}
	
	// Teste ao método viagemEntreDatas
	@Test
	public void viagemEntreDatasTest() throws InvalidIntervalException {
		List<Viagem> aux = new ArrayList<Viagem>();
		c1.registaViagem(v3);
		c1.registaViagem(v2);
		aux.add(v3);
		GregorianCalendar data1 = new GregorianCalendar(2017,11,10);
		GregorianCalendar data2 = new GregorianCalendar(2018,01,01);
		assertNotNull(c1.viagensEntreDatas(data1, data2));
		assertEquals(aux,c1.viagensEntreDatas(data1,data2));
	}
	
	// Teste ao método maiorDesvio
	@Test
	public void maiorDesvioTest() throws NenhumaViagemException {
		c1.registaViagem(v1);
		c1.registaViagem(v3);
		assertEquals(v3,c1.maiorDesvio());
	}
	
}
