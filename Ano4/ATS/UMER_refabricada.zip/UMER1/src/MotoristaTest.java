import static org.junit.Assert.*;
import junit.framework.Assert;


import java.util.HashSet;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;

public class MotoristaTest {
	
	Motorista m1,m2,m3,m4;
	Veiculo auxv;
	
	
	@Before
	public void setUp() {
		Set<Viagem> aux = new HashSet<Viagem>();
		m1 = new Motorista(); 
		m2 = new Motorista("email@hotmail.com","nome","12345","UM","1-1-2000",aux,0,10,1,0,false,new Carro());
		m3 = new Motorista("email@hotmail.com","nome","12345","UM","1-1-2000",aux,0,50,1,0,false,new Carro(10,1,10,"AA",new Coordenada(),false));
		m4 = new Motorista("email@hotmail.com","nome","12345","UM","1-1-2000",aux,0,20,1,0,false,new Carro(10,1,10,"AA",new Coordenada(10,10),false));
	}
	
	@Test
	public void test() {
	}
	
	@Test
	public void atualizaClassificacaoTest() throws ValueOutOfBoundsException {
		int classi = 10;
		m1.atualizaClassificacao(classi);
		assertEquals(10, m1.getClassificacao());
		m2.atualizaClassificacao(classi);
		assertEquals(10, m2.getClassificacao());
		try{
			m3.atualizaClassificacao(150);
		}catch(ValueOutOfBoundsException e) {}
		assertEquals(50, m3.getClassificacao());
		
	}
	
	@Test
	public void tempoViagemTest() {
		double aux = 0;
		double delta = 1e-15;//o delta m�ximo entre o esperado e o real para o qual ambos os n�meros ainda s�o considerados iguais.
		aux = m3.tempoViagem(20);
		assertEquals(2,aux,delta);
		try{
			aux = m1.tempoViagem(10);
			assertEquals(0,aux,delta);
		}catch(java.lang.NullPointerException e) {}
		
	}
	
	@Test
	public void precoViagemTest() {
		double aux = 0;
		double delta = 1e-15;
		
		try {
		assertEquals(0,m1.precoViagem(10),delta);
		}catch(java.lang.NullPointerException e) {}
		assertEquals(10,m3.precoViagem(10),delta);
	}
	
	@Test
	public void atualizaDadostest() {
		double delta = 1e-15;
		m4.atualizaDados(new Coordenada(5,6), 15, 10, 5);
		assertEquals(5,m4.getVeiculo().getCoordenadas().getX());
		assertEquals(6,m4.getVeiculo().getCoordenadas().getY());
		assertEquals(15,m4.getKmsTotais(),delta);
		assertEquals(true,m4.getDisponibilidade());
		//assertEquals(0,m4.getGrau());
		
	}
	

}
