
/**
 * Escreva a descrição da classe InvalidIntervalException aqui.
 *
 * @author (seu nome)
 * @version (número de versão ou data)
 */
public class InvalidIntervalException extends Exception {
	public InvalidIntervalException() {
		super();
	}

	public InvalidIntervalException(String msg) {
		super(msg);
	}
}
