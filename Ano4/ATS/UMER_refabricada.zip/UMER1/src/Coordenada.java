/**
 * Escreva a descrição da classe Coordenada aqui.
 *
 * @author (seu nome)
 * @version v1(02052017)
 */
import java.io.Serializable;

public class Coordenada implements Serializable {
	// variáveis de instância
	private int coorX;
	private int coorY;

	/**
	 * Construtor Vazio
	 */
	public Coordenada() {
		coorX = 0;
		coorY = 0;
	}

	/**
	 * Construtor por cópia
	 * 
	 * @param Coordenada
	 *            a
	 */
	public Coordenada(Coordenada a) {
		coorX = a.getX();
		coorY = a.getY();
	}

	/**
	 * Construtor paramétrico
	 * 
	 * @param int
	 *            x
	 * @param int
	 *            y
	 */
	public Coordenada(int x, int y) {
		coorX = x;
		coorY = y;
	}

	/**
	 * Método clone.
	 */
	@Override
	public Coordenada clone() {
		return new Coordenada(this);
	}

	/**
	 * Metodo Compare
	 */
	public int compareTo(Coordenada b) {
		if (coorX == b.getX()) {
			if (coorY == b.getY())
				return 0;
			if (coorY < b.getY())
				return 1;
			else
				return -1;
		}
		if (coorX < b.getX())
			return 1;
		else
			return -1;
	}

	public double distancia(Coordenada b) {
		return Math.sqrt(Math.pow(coorX - b.getX(), 2) + Math.pow(coorY - b.getY(), 2));
	}

	/**
	 * Comparação com outro Objeto o
	 * 
	 * @param Object
	 *            o
	 * @return boolean a indicar se é igual ao não a 'o'.
	 */
	@Override
	public boolean equals(Object o) {
		if (o == this)
			return true;
		if (o == null || o.getClass() != this.getClass())
			return false;
		Coordenada v = (Coordenada) o;
		return v.getX() == coorX && v.getY() == coorY;
	}

	/**
	 * @return variavel coorX
	 */
	public int getX() {
		return coorX;
	}

	/**
	 * @return variavel coorY
	 */
	public int getY() {
		return coorY;
	}

	/**
	 * Detetermina o código de hash
	 * 
	 * @return int
	 */
	@Override
	public int hashCode() {
		int hash = 6;

		hash = 37 * hash + coorX;
		hash = 37 * hash + coorY;

		return hash;
	}

	/**
	 * Representação textual.
	 * 
	 * @return Informaçao da Coordenada em String
	 */
	@Override
	public String toString() {
		StringBuilder s = new StringBuilder();
		s.append("Coordenada X: " + coorX + " Coordenada Y: " + coorY);
		return s.toString();
	}
}
