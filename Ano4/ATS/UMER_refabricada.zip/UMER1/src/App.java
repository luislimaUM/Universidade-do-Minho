
/**
 * Exemplo de aplicação com menu em modo texto.

 *
 * @author José Creissac Campos
 * @version 1.0
 */
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.io.Serializable;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class App implements Serializable {
	/**
	 * O método main cria a aplicação e invoca o método run()
	 */
	public static void main(String[] args) {
		long tempoInicio = System.currentTimeMillis();
		new App().run();
		System.out.println("Tempo Total: "+(System.currentTimeMillis()-tempoInicio));
	}

	private Utilizadores utilizadores;
	private HashMap<String, Veiculo> veiculos;
	// Menus da aplicação
	private Menu menuPrincipal;
	private Login menuLogin;
	private Registo menuRegisto;

	/**
	 * Construtor.
	 *
	 * Cria os menus e a camada de negócio.
	 */
	private App() {
		
		utilizadores = new Utilizadores();
		veiculos = new HashMap<>();
		
		String[] opcoes = { "Login", "Registar", "Extra" };
		menuPrincipal = new Menu(opcoes);
		menuLogin = new Login();
		menuRegisto = new Registo();
		
	}

	public void carregaEstado(String nome) throws FileNotFoundException, IOException, ClassNotFoundException {
		
		FileInputStream f = new FileInputStream(nome);
		ObjectInputStream o = new ObjectInputStream(f);
		utilizadores = (Utilizadores) o.readObject();
		veiculos = (HashMap<String, Veiculo>) o.readObject();
		o.close();
	}

	private void casesHandler() {
		
		int i=0;
		
		switch (menuPrincipal.getOpcao()) {
		case 1:
			menuLogin.executa(utilizadores, veiculos);
			break;
		case 2:
			/*
			//adicionar clientes
			while(i<1000000) {
				Ator a;
				try {
				if(i%2==1) {
					a = new Cliente("email"+i,"nome"+i,""+i,"morada","data"+i);
				}else a = new Motorista("email"+i,"nome"+i,""+i,"morada","data"+i,new Carro());
				utilizadores.adiciona(a);
				i++;
				}catch (EmailAlreadyInUseException e) {
				}
			}
			
			
			i=0;
			//adicionar veiculos
			while(i<1000000) {
				Veiculo v;
					if(i%2==1) {
						v = new Carro(1,1,1,"AA-"+i+"-AA",new Coordenada(), false);
					}else v = new Mota(1,1,1,"AA-"+i+"-AA",new Coordenada(), false);
					veiculos.put(v.getMatricula(),v);
					i++;
					
			}
			*/
			
			Registo r = menuRegisto;
			i = 0;
			Scanner scin = r.registDisplay();
			try {
				i = scin.nextInt();
			} catch (InputMismatchException e) {
				i = 0;
			}

			r.optionsHandler(utilizadores, veiculos, i);
			break;
		case 3:
			funcionalidades();
			break;
		}
	}

	private void displayOptions() {
		System.out.println("\n-----------Extra-----------");
		System.out.println("1 - Listar Utilizadores");
		System.out.println("2 - Listar os 10 clientes que mais gastam");
		System.out.println("3 - Listar viaturas");
		System.out.println(
				"4 - Listar os 5 motoristas com maior desvio entre os valores previstos para as viagens e o valor real");
		System.out.print("Opção: ");
	}

	public void escreveEmFicheiroTxt(String nomeFicheiro) throws IOException {
		PrintWriter fich = new PrintWriter(nomeFicheiro);
		fich.println(utilizadores.toString());
		fich.flush();
		fich.close();
	}

	private void executeOption(int op) {
		System.out.println("\n-----------Extra-----------");
		switch (op) {
		case 1:
			trataListarUtilizadores();
			break;
		case 2:
			top10ClientesGastadores();
			break;
		case 3:
			listarVeiculos();
			break;
		case 4:
			top5MotoristasComMaiorDesvio();
			break;
		default:
			System.out.println("Opção Inválida!");
			break;
		}
	}

	public void funcionalidades() {
		Scanner sc = new Scanner(System.in);

		displayOptions();
		int op = sc.nextInt();

		executeOption(op);

	}

	public void guardaEstado(String nome) throws IOException {
		FileOutputStream f = new FileOutputStream(nome);
		ObjectOutputStream o = new ObjectOutputStream(f);
		o.writeObject(utilizadores);
		o.writeObject(veiculos);
		o.flush();
		o.close();
	}

	private void initData() {
		System.out.println("A carregar os dados...");
		try {
			carregaEstado("Appdadosbin");
		} catch (IOException e) {
			System.out.println("Erro no ficheiro.");
		} catch (ClassNotFoundException e) {
			System.out.println("Erro nas classes.");
		}
	}

	private void listarVeiculos() {
		System.out.println("\n Veiculos");
		if (veiculos.isEmpty())
			System.out.println("Não existem veiculos no sistema UMeR.");
		for (Veiculo v : veiculos.values())
			System.out.println(v.toString());
	}

	/**
	 * Executa o menu principal e invoca o método correspondente à opção
	 * seleccionada.
	 */
	private void run() {
		initData();

		do {
			menuPrincipal.executa();
			casesHandler();
		} while (menuPrincipal.getOpcao() != 0);

		saveData();
	}

	private void saveData() {
		System.out.println("A guardar os dados...");
		try {
			guardaEstado("Appdadosbin");
			escreveEmFicheiroTxt("Appdadosbin.txt");
		} catch (IOException e) {
			System.out.println("Erro no ficheiro.");
		}

		System.out.println("Até breve!...");
	}

	public void top10ClientesGastadores() {
		List<Cliente> cs = utilizadores.top10ClientesGastadores();

		if (cs.size() == 0)
			System.out.println("Não existem utilizadores a utilizar o sistema UMeR.");
		else
			cs.forEach(c -> System.out.println("Nome: " + c.getNome() + " e-mail: " + c.getMail() + " Montante: "
					+ String.format("%.2f", c.getMS()) + "€"));
	}

	public void top5MotoristasComMaiorDesvio() {
		List<Motorista> ms = utilizadores.top5MotoristasComMaiorDesvio();

		if (ms.size() == 0)
			System.out.println("Não existem motoristas no sistema UMeR.");
		else
			for (Motorista m : ms)
				try {
					System.out.println("Nome: " + m.getNome() + " e-mail: " + m.getMail() + " Desvio: "
							+ String.format("%.2f", m.maiorDesvio().getDesvio()));
				} catch (NenhumaViagemException e) {
					System.out.println("Objeto corrompido?");
				}
	}

	private void trataListarUtilizadores() {
		System.out.println(utilizadores);
	}
}
