
/**
 * Escreva a descrição da classe Viagens aqui.
 *
 * @author (seu nome)
 * @version (número de versão ou data)
 */
import java.io.Serializable;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class Viagem implements Comparable<Viagem>, Serializable {
	// variáveis de instância
	private Coordenada cinicial;
	private Coordenada cfinal;
	private double tempo; // Tempo que demorou a realizar a viagem.
	private String mail;
	private GregorianCalendar data;
	private double preco; // Preço real da viagem
	private double desvio; // Diferença entre o valor previsto e o preço real faturado

	/**
	 * Construtor Vazio
	 */
	public Viagem() {
		cinicial = new Coordenada();
		cfinal = new Coordenada();
		tempo = preco = desvio = 0;
		mail = "";
		data = new GregorianCalendar();
	}

	/**
	 * Construtor paramétrico
	 * 
	 * @param Coordenada
	 *            cinicial
	 * @param Coordenada
	 *            cfinal
	 * @param double
	 *            tempo
	 * @param String
	 *            mail
	 * @param data
	 * @param preco
	 * @param desvio
	 */
	public Viagem(Coordenada cinicial, Coordenada cfinal, double tempo, String mail, GregorianCalendar data,
			double preco, double desvio) {
		this.cinicial = cinicial.clone();
		this.cfinal = cfinal.clone();
		this.tempo = tempo;
		this.mail = mail;
		this.data = (GregorianCalendar) data.clone();
		this.preco = preco;
		this.desvio = desvio;
	}

	/**
	 * Construtor por cópia
	 * 
	 * @param Viagem
	 *            a
	 */
	public Viagem(Viagem a) {
		cinicial = a.getcinicial();
		cfinal = a.getcfinal();
		tempo = a.getTempo();
		mail = a.getMail();
		data = (GregorianCalendar) a.getData().clone();
		preco = a.getPreco();
		desvio = a.getDesvio();
	}

	/**
	 * Método clone.
	 */
	@Override
	public Viagem clone() {
		return new Viagem(this);
	}

	/**
	 * Metodo Compare
	 */
	@Override
	public int compareTo(Viagem b) {
		int r = 0;
		r = cinicial.compareTo(b.getcinicial());
		if (r == 0)
			r = cfinal.compareTo(b.getcfinal());
		if (r == 0) {
			if (tempo < b.getTempo())
				r = -1;
			if (tempo == b.getTempo())
				r = 0;
			else
				r = 1;
		}
		if (r == 0)
			r = mail.compareTo(b.getMail());
		if (r == 0)
			r = data.compareTo(b.getData());
		if (r == 0) {
			if (preco < b.getPreco())
				r = -1;
			if (preco == b.getPreco())
				r = 0;
			else
				r = 1;
		}
		if (r == 0) {
			if (desvio < b.getDesvio())
				r = -1;
			if (desvio == b.getDesvio())
				r = 0;
			else
				r = 1;
		}

		return r;
	}

	/**
	 * Comparação com outro Objeto o
	 * 
	 * @param Object
	 *            o
	 * @return boolean a indicar se é igual ao não a 'o'.
	 */
	@Override
	public boolean equals(Object o) {
		if (o == this)
			return true;
		if (o == null || o.getClass() != this.getClass())
			return false;
		Viagem v = (Viagem) o;
		return v.getcinicial().equals(cinicial) && v.getcfinal().equals(cfinal) && v.getMail().equals(mail)
				&& v.getTempo() == tempo && data.equals(v.getData()) && v.getPreco() == preco
				&& v.getDesvio() == desvio;
	}

	/**
	 * @return Coordenada final
	 */
	public Coordenada getcfinal() {
		return cfinal.clone();
	}

	/**
	 * @return Coordenada inicial
	 */
	public Coordenada getcinicial() {
		return cinicial.clone();
	}

	/**
	 * Devolve a data da viagem
	 * 
	 * @return
	 */
	public GregorianCalendar getData() {
		return data;
	}

	/**
	 * Devolve o desvio de preços da viagem
	 * 
	 * @return
	 */
	public double getDesvio() {
		return desvio;
	}

	/**
	 * @return Mail do Ator.
	 */
	public String getMail() {
		return mail;
	}

	/**
	 * Devolve o preço da viagem
	 * 
	 * @return
	 */
	public double getPreco() {
		return preco;
	}

	/**
	 * @return Tempo
	 */
	public double getTempo() {
		return tempo;
	}

	/**
	 * Detetermina o código de hash
	 * 
	 * @return int
	 */
	@Override
	public int hashCode() {
		int hash = 5;
		long aux;

		hash = 37 * hash + cinicial.hashCode();
		hash = 37 * hash + cfinal.hashCode();
		aux = Double.doubleToLongBits(tempo);
		hash = 37 * hash + (int) (aux ^ aux >>> 32);
		hash = 37 * hash + mail.hashCode();
		hash = 37 * hash + data.hashCode();
		aux = Double.doubleToLongBits(preco);
		hash = 37 * hash + (int) (aux ^ aux >>> 32);
		aux = Double.doubleToLongBits(desvio);
		hash = 37 * hash + (int) (aux ^ aux >>> 32);

		return hash;
	}

	/**
	 * Altera o valor da coordenada final
	 */
	public void setcfinal(Coordenada i) {
		cfinal = i;
	}

	/**
	 * Altera o valor da coordenada inicial
	 */
	public void setcinicial(Coordenada i) {
		cinicial = i;
	}

	/**
	 * Altera o mail do ator
	 */
	public void setMail(String i) {
		mail = i;
	}

	/**
	 * Altera o valor do tempo
	 */
	public void setTempo(double i) {
		tempo = i;
	}

	/**
	 * Representação textual.
	 * 
	 * @return Informaçao da Viagem em String
	 */
	@Override
	public String toString() {
		StringBuilder s = new StringBuilder();
		s.append("Coordenada inicial: " + cinicial.toString() + "\nCoordenada final: " + cfinal.toString());
		s.append("\nTempo que demorou a viagem: " + String.format("%.2f", tempo));
		s.append("\nMail do ator: " + mail);
		s.append("\nData da viagem: " + data.get(Calendar.DAY_OF_MONTH) + "-" + data.get(Calendar.MONTH) + "-"
				+ data.get(Calendar.YEAR));
		s.append("\nPreço real da viagem: ").append(String.format("%.2f", preco))
				.append("\nDesvio entre o valor previsto e o preço real faturado: ")
				.append(String.format("%.2f", desvio));
		return s.toString();
	}

}
