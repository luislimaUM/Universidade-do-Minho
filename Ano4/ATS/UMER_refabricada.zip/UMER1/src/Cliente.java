
/**
 * Escreva a descrição da classe Cliente aqui.
 *
 * @author (seu nome)
 * @version (número de versão ou data)
 */
import java.io.Serializable;
import java.util.Set;
import java.util.TreeSet;

public class Cliente extends Ator implements Serializable {
	// variáveis de instância
	private double moneySpent; // Quantidade de dinheiro total gasto no servico UMeR

	/**
	 * Construtor Vazio
	 */
	public Cliente() {
		super();
		moneySpent = 0;
	}

	/**
	 * Construtor por cópia
	 * 
	 * @param c
	 */
	public Cliente(Cliente c) {
		super(c);
		moneySpent = c.getMS();
	}

	/**
	 * Construtor paramétrico parcial.
	 * 
	 * @param email
	 * @param nome
	 * @param pw
	 * @param morada
	 * @param dDN
	 */
	public Cliente(String email, String nome, String pw, String morada, String dDN) {
		super(email, nome, pw, morada, dDN, new TreeSet<Viagem>());
		moneySpent = 0;
	}

	/**
	 * Construtor paramétrico
	 * 
	 * @param email
	 * @param nome
	 * @param pw
	 * @param morada
	 * @param dDN
	 * @param historico
	 * @param ms
	 */
	public Cliente(String email, String nome, String pw, String morada, String dDN, Set<Viagem> historico, double ms) {
		super(email, nome, pw, morada, dDN, historico);
		moneySpent = ms;
	}

	/**
	 * Criação de uma cópia
	 * 
	 * @return
	 */
	@Override
	public Cliente clone() {
		return new Cliente(this);
	}

	/**
	 * Implementação da ordem natural entre instâncias de Cliente.
	 * 
	 * @param c
	 */
	public int compareTo(Cliente c) {
		int r = super.compareTo(c);

		if (r == 0)
			r = moneySpent == c.getMS() ? 0 : moneySpent > c.getMS() ? 1 : -1;

		return r;
	}

	// Métodos usuais
	/**
	 * Igualdade com outro objeto.
	 * 
	 * @param o
	 * @return
	 */
	@Override
	public boolean equals(Object o) {
		if (o == this)
			return true;

		if (o == null || o.getClass() != this.getClass())
			return false;

		Cliente c = (Cliente) o;

		return super.equals(c) && moneySpent == c.getMS();
	}

	/**
	 * Devolve a quantidade de dinheiro gasto pelo cliente.
	 * 
	 * @return
	 */
	public double getMS() {
		return moneySpent;
	}

	/**
	 * Determina o código de hash do objeto.
	 * 
	 * @return
	 */
	@Override
	public int hashCode() {
		int hash = 7;

		hash = 37 * hash + super.hashCode();
		long dbTol = Double.doubleToLongBits(moneySpent);
		hash = 37 * hash + (int) (dbTol ^ dbTol >>> 32);

		return hash;
	}

	/**
	 * Define a quantidade de dinheiro gasto pelo cliente.
	 * 
	 * @param ms
	 */
	public void setMS(double ms) {
		moneySpent = ms;
	}

	/**
	 * Representação no formato texto.
	 * 
	 * @return
	 */
	@Override
	public String toString() {
		StringBuilder s = new StringBuilder();

		s.append(super.toString()).append("Montante de dinheiro utilizado no serviço UMeR: ")
				.append(String.format("%.2f", moneySpent)).append("\n");

		return s.toString();
	}
}
