import static org.junit.Assert.fail;

import org.junit.Before;
import org.junit.Test;

public class LoginTest {

	// Clientes

	// Teste ao método registaViagem
	@Test
	public void registaViagemTest() {

	}

	// Antes de cada @Test executa o setUp para criar os clientes e as viagens
	@Before
	public void setUp() {

	}

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
