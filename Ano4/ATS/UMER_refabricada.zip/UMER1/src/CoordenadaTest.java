import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class CoordenadaTest {
	
	@Before
	public void setUp() {
	
	}
	
	@Test
	public void test() {
	}
	
	@Test
	public void getXTest() {
		Coordenada coord1 = new Coordenada(5,7);
		assertEquals(5,coord1.getX());
	}
	
	@Test
	public void getYTest() {
		Coordenada coord2 = new Coordenada(7,5);
		assertEquals(5,coord2.getY());
	}
	
	@Test
	public void distanciaTest() {
		double delta = 1e-15;
		Coordenada coord1 = new Coordenada(0,0);
		assertEquals(0,coord1.distancia(new Coordenada()),delta);
		assertEquals(5,coord1.distancia(new Coordenada(3,4)),delta);
	}

}
