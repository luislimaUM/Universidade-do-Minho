
/**
 * Escreva a descrição da classe ValueOutOfBoundsException aqui.
 *
 * @author (seu nome)
 * @version (número de versão ou data)
 */
public class ValueOutOfBoundsException extends Exception {
	public ValueOutOfBoundsException() {
		super();
	}

	public ValueOutOfBoundsException(String msg) {
		super(msg);
	}
}
