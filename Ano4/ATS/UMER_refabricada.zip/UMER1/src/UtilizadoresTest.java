import java.lang.reflect.*;
import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.*;


public class UtilizadoresTest {
	
	Ator c, m;
	Veiculo v;
	Set<Viagem> histc = new TreeSet<Viagem>();
	Set<Viagem> histm = new TreeSet<Viagem>();
	Map<String,Ator> atores = new HashMap<String,Ator>();
	Utilizadores u;
	
	
	// Antes de cada @Test executa o setUp para criar os clientes e as viagens
	@Before
	public void setUp() {
		c = new Cliente("bruno_1_dantas@hotmail.com","Bruno","123456","Ponte de Lima","15-10-1996", histc, 0);
		v = new Carro(70, 3, 10, "12-AG-54", new Coordenada(135,543), false);
		m = new Motorista("jose@gmail.com","Jose","123456","Lisboa","5-11-1958", histm, 2, 70, 3, 403103, false, v);
		atores.put("bruno_1_dantas@hotmail.com", c);
		atores.put("jose@gmail.com", m);
		u = new Utilizadores(atores);
	}
	
	// Teste ao método adiciona(Ator a)
	@Test
	public void adicionaTest() {
		Utilizadores aux;
		// Não existe
			aux = new Utilizadores();
			assertNotNull(aux);
			try { aux.adiciona(c); aux.adiciona(m); }
			catch (EmailAlreadyInUseException e) {}
			assertEquals(u, aux);
		// Já existe (não deve adicionar)
			aux = new Utilizadores(atores);
			assertNotNull(aux);
			try { u.adiciona(c); }
			catch (EmailAlreadyInUseException e) {}
			assertEquals(u, aux);
	}
	
	// Teste ao método getAtor()
	@Test
	public void getAtorTest() {
		Ator aux;
		// Email não existe
			aux = null;
			try { aux = u.getAtor("bruno_sem_dantas@hotmail.com"); }
			catch (EmailDoesNotExistException e) {}
			assertNull(aux);
		// Email existe
			aux = null;
			try { aux = u.getAtor("bruno_1_dantas@hotmail.com"); 
				  assertEquals(c,aux);
				  aux = u.getAtor("jose@gmail.com");
				  assertEquals(m,aux);
			}
			catch (EmailDoesNotExistException e) {}
	}	
	
	//Teste ao método top10ClientesGastadores
	@Test
	public void top10ClientesGastadoresTest() {
		Utilizadores aux = new Utilizadores();
		List<Cliente> cli = new ArrayList<Cliente>();
		List<Cliente> cliAux = new ArrayList<Cliente>();
		try {
			// Construção do array de teste
			for(int i = 0; i < 21; i+=2) {
				Cliente ci = new Cliente(i+"bruno_1_dantas@hotmail.com","Bruno","123456","Ponte de Lima","15-10-1996", histc, 60+i);
				assertNotNull(ci);
				aux.adiciona(ci);
			}
			// Construção do array de teste
			for(int i = 1; i < 20; i+=2) {
				Cliente ci = new Cliente(i+"bruno_1_dantas@hotmail.com","Bruno","123456","Ponte de Lima","15-10-1996", histc, 60+i);
				assertNotNull(ci);
				aux.adiciona(ci);
			}
			// Resultado da função a testar
			cli = aux.top10ClientesGastadores();
			assertNotNull(cli);
			// Criação do resultado correto
			for(int i = 20; i > 10; i--) {
				Cliente ci = new Cliente(i+"bruno_1_dantas@hotmail.com","Bruno","123456","Ponte de Lima","15-10-1996", histc, 60+i);
				assertNotNull(ci);
				cliAux.add(ci);
			}
			assertEquals(cliAux, cli);
		}
		catch(EmailAlreadyInUseException e) {}
	}
	
	//Teste ao método top5MotoristasComMaiorDesvio
	@Test
	public void top5MotoristasComMaiorDesvioTest() {
		Utilizadores aux = new Utilizadores();
		List<Motorista> mot = new ArrayList<Motorista>();
		List<Motorista> motAux = new ArrayList<Motorista>();
		try {
			// Construção do array de teste
			for(int i = 0; i < 21; i+=2) {
				Motorista mi = new Motorista(i+"jose@gmail.com","Jose","123456","Lisboa","5-11-1958", histm, 2, 70, 3, 403103, false, v);
				assertNotNull(mi);
				Viagem v1 = new Viagem(new Coordenada(0,0),new Coordenada(10+i,10+i),60,"bruno_1_dantas@hotmail.com",new GregorianCalendar(2017,12,17),57,i);
				Viagem v2 = new Viagem(new Coordenada(0,0),new Coordenada(10+i,10+i),69,"luis.soccer5@gmail.com",new GregorianCalendar(2017,9,15),59,i);
				mi.registaViagem(v1);
				mi.registaViagem(v2);
				aux.adiciona(mi);
			}
			//Construção do array de teste
			for(int i = 1; i < 20; i+=2) {
				Motorista mi = new Motorista(i+"jose@gmail.com","Jose","123456","Lisboa","5-11-1958", histm, 2, 70, 3, 403103, false, v);
				assertNotNull(mi);
				Viagem v1 = new Viagem(new Coordenada(0,0),new Coordenada(10+i,10+i),60,"bruno_1_dantas@hotmail.com",new GregorianCalendar(2017,12,17),57,i);
				Viagem v2 = new Viagem(new Coordenada(0,0),new Coordenada(10+i,10+i),69,"luis.soccer5@gmail.com",new GregorianCalendar(2017,9,15),59,i);
				mi.registaViagem(v1);
				mi.registaViagem(v2);
				aux.adiciona(mi);
			}
			// Resultado da função a testar
			mot = aux.top5MotoristasComMaiorDesvio();
			assertNotNull(mot);
			// Criação do resultado correto
			for(int i = 20; i > 15; i--) {
				Motorista mi = new Motorista(i+"jose@gmail.com","Jose","123456","Lisboa","5-11-1958", histm, 2, 70, 3, 403103, false, v);
				assertNotNull(mi);
				Viagem v1 = new Viagem(new Coordenada(0,0),new Coordenada(10+i,10+i),60,"bruno_1_dantas@hotmail.com",new GregorianCalendar(2017,12,17),57,i);
				Viagem v2 = new Viagem(new Coordenada(0,0),new Coordenada(10+i,10+i),69,"luis.soccer5@gmail.com",new GregorianCalendar(2017,9,15),59,i);
				mi.registaViagem(v1);
				mi.registaViagem(v2);
				motAux.add(mi);
			}
			assertEquals(motAux, mot);
		}
		catch(EmailAlreadyInUseException e) {}
	}
	
}






