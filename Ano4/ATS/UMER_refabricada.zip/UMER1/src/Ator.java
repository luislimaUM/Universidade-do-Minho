
/**
 * Escreva a descrição da classe Atores aqui.
 *
 * @author (seu nome)
 * @version (número de versão ou data)
 */
import java.io.Serializable;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

public abstract class Ator implements Comparable<Ator>, Serializable {
	// variáveis da instancia associadas aos atores do sistema
	private String email; // Identificador único(Chave).
	private String nome; // Nome
	private String pw; // Password
	private String morada; // Morada
	private String dataDeNascimento; // Data de nascimento
	private Set<Viagem> historico; // Histórico de viagens realizadas.

	/**
	 * Construtor Vazio
	 */
	public Ator() {
		email = nome = pw = morada = dataDeNascimento = "";
		historico = new TreeSet<>();
	}

	/**
	 * Construtor por cópia
	 * 
	 * @param a
	 */
	public Ator(Ator a) {
		email = a.getMail();
		nome = a.getNome();
		pw = a.getPassword();
		morada = a.getMorada();
		dataDeNascimento = a.getDataDeNascimento();
		historico = a.getHistorico();
	}

	/**
	 * Construtor paramétrico
	 * 
	 * @param email
	 * @param nome
	 * @param pw
	 * @param morada
	 * @param dDN
	 * @param historico
	 */
	public Ator(String email, String nome, String pw, String morada, String dDN, Set<Viagem> hist) {
		this.email = email;
		this.nome = nome;
		this.pw = pw;
		this.morada = morada;
		dataDeNascimento = dDN;
		historico = new TreeSet<>();

		for (Viagem v : hist)
			historico.add(v.clone());
	}

	/**
	 * Cria uma cópia
	 * 
	 * @return Ator
	 */
	@Override
	public abstract Ator clone();

	/**
	 * Define a ordem natural entre atores do sistema.
	 * 
	 * @return int
	 */
	@Override
	public int compareTo(Ator a) {
		int r;
		r = email.compareTo(a.getMail());
		if (r == 0)
			r = nome.compareTo(a.getNome());
		if (r == 0)
			r = pw.compareTo(a.getPassword());
		if (r == 0)
			r = morada.compareTo(a.getMorada());
		if (r == 0)
			r = dataDeNascimento.compareTo(a.getDataDeNascimento());
		if (r == 0) {
			Iterator<Viagem> it1 = historico.iterator();
			Iterator<Viagem> it2 = a.getHistorico().iterator();
			while (r == 0 && it1.hasNext() && it2.hasNext()) {
				Viagem v1 = it1.next();
				Viagem v2 = it2.next();
				r = v1.compareTo(v2);
			}
			if (r == 0 && it1.hasNext())
				r = 1;
			else if (r == 0 && it2.hasNext())
				r = -1;
		}

		return r;
	}

	// Métodos usuais
	/**
	 * Igualdade com outro objeto
	 * 
	 * @param Object
	 *            o
	 * @return boolean indicando se é igual ou não
	 */
	@Override
	public boolean equals(Object o) {
		if (o == this)
			return true;

		if (o == null || o.getClass() != this.getClass())
			return false;

		Ator at = (Ator) o;

		if (historico.size() != at.getHistorico().size())
			return false;

		return hashCode() == at.hashCode() && email.equals(at.getMail()) && nome.equals(at.getNome())
				&& pw.equals(at.getPassword()) && morada.equals(at.getMorada())
				&& dataDeNascimento.equals(at.getDataDeNascimento()) && historico.containsAll(at.getHistorico());
	}

	/**
	 * Devolve a data de nascimento do ator
	 * 
	 * @return String data de nascimento
	 */
	public String getDataDeNascimento() {
		return dataDeNascimento;
	}

	/**
	 * Devolve uma cópia do histórico de viagens do objeto.
	 * 
	 * @return Set<Viagem>
	 */
	public Set<Viagem> getHistorico() {
		Set<Viagem> res = new TreeSet<>();

		historico.forEach(v -> res.add(v.clone()));

		return res;
	}

	/**
	 * Devolve o email do ator
	 * 
	 * @return String email
	 */
	public String getMail() {
		return email;
	}

	/**
	 * Devolve a morada do ator
	 * 
	 * @return String morada
	 */
	public String getMorada() {
		return morada;
	}

	/**
	 * Devolve o nome do ator
	 * 
	 * @return String nome
	 */
	public String getNome() {
		return nome;
	}

	/**
	 * Devolve a password do ator
	 * 
	 * @return String password
	 */
	public String getPassword() {
		return pw;
	}

	/**
	 * Detetermina o código de hash
	 * 
	 * @return int
	 */
	@Override
	public int hashCode() {
		int hash = 7;

		hash = 37 * hash + email.hashCode();
		hash = 37 * hash + nome.hashCode();
		hash = 37 * hash + pw.hashCode();
		hash = 37 * hash + morada.hashCode();
		hash = 37 * hash + dataDeNascimento.hashCode();
		for (Viagem v : historico)
			hash = 37 * hash + v.hashCode();

		return hash;
	}

	/**
	 * Devolve a viagem com o maior desvio de preços no historico de viagens.
	 * 
	 * @return
	 */
	public Viagem maiorDesvio() throws NenhumaViagemException {
		if (historico.size() == 0)
			throw new NenhumaViagemException();
		else
			return historico.stream().max(new ComparadorDesvio()).get().clone();
	}

	/**
	 * Adiciona um novo registo de viagem.
	 * 
	 * @param rv
	 */
	public void registaViagem(Viagem rv) {
		historico.add(rv.clone());
	}

	/**
	 * Representação textual
	 * 
	 * @return String
	 */
	@Override
	public String toString() {
		StringBuilder s = new StringBuilder();
		s.append("E-mail: ").append(email).append("\n").append("Nome: ").append(nome).append("\n").append("Password: ")
				.append(pw).append("\n").append("Morada: ").append(morada).append("\n").append("Data de nascimento: ")
				.append(dataDeNascimento);

		historico.forEach(v -> s.append(v.toString()).append("\n"));

		return s.toString();
	}

	/**
	 * Constroí uma lista das viagens efetuadas numa data pertencente ao intervalo
	 * de tempo definido por quem invoca o método.
	 * 
	 * @param inicio
	 * @param fim
	 * @return
	 */
	public List<Viagem> viagensEntreDatas(GregorianCalendar inicio, GregorianCalendar fim)
			throws InvalidIntervalException {
		if (inicio.compareTo(fim) == 1)
			throw new InvalidIntervalException();
		else
			return historico.stream().filter(v -> v.getData().compareTo(inicio) >= 0 && v.getData().compareTo(fim) <= 0)
					.map(Viagem::clone).collect(Collectors.toList());
	}
}
