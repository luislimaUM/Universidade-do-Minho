
/**
 * Escreva a descrição da classe NenhumaViagemException aqui.
 * 
 * @author (seu nome) 
 * @version (número de versão ou data)
 */
public class NenhumaViagemException extends Exception
{
    public NenhumaViagemException(){
        super();
    }
    
    public NenhumaViagemException(String msg){
        super(msg);
    }
}
