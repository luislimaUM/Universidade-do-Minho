import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.util.GregorianCalendar gregorianCalendar6 = null;
        java.util.GregorianCalendar gregorianCalendar7 = null;
        try {
            java.util.List<Viagem> list_viagem8 = cliente5.viagensEntreDatas(gregorianCalendar6, gregorianCalendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        java.lang.String str10 = cliente5.getNome();
        Viagem viagem11 = null;
        try {
            cliente5.registaViagem(viagem11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        java.lang.String str10 = cliente5.getNome();
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente22 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str23 = cliente22.getMail();
        java.util.Set<Viagem> set_viagem24 = cliente22.getHistorico();
        Cliente cliente25 = cliente22.clone();
        java.lang.String str26 = cliente22.getMail();
        int i27 = cliente16.compareTo(cliente22);
        java.lang.String str28 = cliente22.toString();
        Cliente cliente34 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente40 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str41 = cliente40.getMail();
        java.util.Set<Viagem> set_viagem42 = cliente40.getHistorico();
        Cliente cliente43 = cliente40.clone();
        java.lang.String str44 = cliente40.getMail();
        int i45 = cliente34.compareTo(cliente40);
        int i46 = cliente22.compareTo((Ator) cliente40);
        cliente22.setMS((double) 10L);
        int i49 = cliente5.compareTo((Ator) cliente22);
        try {
            Viagem viagem50 = cliente5.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem24);
        org.junit.Assert.assertNotNull(cliente25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
        org.junit.Assert.assertTrue(i27 == 0);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str28.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "hi!" + "'", str41.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem42);
        org.junit.Assert.assertNotNull(cliente43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "hi!" + "'", str44.equals("hi!"));
        org.junit.Assert.assertTrue(i45 == 0);
        org.junit.Assert.assertTrue(i46 == 0);
        org.junit.Assert.assertTrue(i49 == 0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        Cliente cliente10 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str11 = cliente10.getMail();
        java.util.Set<Viagem> set_viagem12 = cliente10.getHistorico();
        Cliente cliente14 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "hi!", "", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", set_viagem12, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem12);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        java.util.GregorianCalendar gregorianCalendar18 = null;
        java.util.GregorianCalendar gregorianCalendar19 = null;
        try {
            java.util.List<Viagem> list_viagem20 = cliente11.viagensEntreDatas(gregorianCalendar18, gregorianCalendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        cliente5.setMS((double) '4');
        java.lang.String str12 = cliente5.toString();
        Viagem viagem13 = null;
        try {
            cliente5.registaViagem(viagem13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n" + "'", str12.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        cliente5.setMS((double) '4');
        try {
            Viagem viagem12 = cliente5.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        java.util.GregorianCalendar gregorianCalendar8 = null;
        java.util.GregorianCalendar gregorianCalendar9 = null;
        try {
            java.util.List<Viagem> list_viagem10 = cliente5.viagensEntreDatas(gregorianCalendar8, gregorianCalendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        java.util.Set<Viagem> set_viagem18 = cliente11.getHistorico();
        try {
            Viagem viagem19 = cliente11.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem18);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.util.Set<Viagem> set_viagem5 = null;
        try {
            Cliente cliente7 = new Cliente("", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "", "hi!", set_viagem5, 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        Cliente cliente14 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente20 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str21 = cliente20.getMail();
        java.util.Set<Viagem> set_viagem22 = cliente20.getHistorico();
        Cliente cliente23 = cliente20.clone();
        java.lang.String str24 = cliente20.getMail();
        int i25 = cliente14.compareTo(cliente20);
        java.lang.String str26 = cliente20.toString();
        int i27 = cliente5.compareTo(cliente20);
        Viagem viagem28 = null;
        try {
            cliente20.registaViagem(viagem28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem22);
        org.junit.Assert.assertNotNull(cliente23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str26.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue(i27 == 0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMorada();
        Viagem viagem10 = null;
        try {
            cliente5.registaViagem(viagem10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        java.util.Set<Viagem> set_viagem18 = cliente11.getHistorico();
        java.lang.String str19 = cliente11.getDataDeNascimento();
        java.util.GregorianCalendar gregorianCalendar20 = null;
        java.util.GregorianCalendar gregorianCalendar21 = null;
        try {
            java.util.List<Viagem> list_viagem22 = cliente11.viagensEntreDatas(gregorianCalendar20, gregorianCalendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        cliente5.setMS(10.0d);
        java.util.Set<Viagem> set_viagem9 = cliente5.getHistorico();
        java.util.GregorianCalendar gregorianCalendar10 = null;
        java.util.GregorianCalendar gregorianCalendar11 = null;
        try {
            java.util.List<Viagem> list_viagem12 = cliente5.viagensEntreDatas(gregorianCalendar10, gregorianCalendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem9);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente8.getPassword();
        Cliente cliente15 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str16 = cliente15.getMail();
        java.util.Set<Viagem> set_viagem17 = cliente15.getHistorico();
        Cliente cliente18 = cliente15.clone();
        java.lang.String str19 = cliente15.getMail();
        cliente15.setMS((double) '4');
        java.lang.String str22 = cliente15.getPassword();
        int i23 = cliente8.compareTo(cliente15);
        java.util.GregorianCalendar gregorianCalendar24 = null;
        java.util.GregorianCalendar gregorianCalendar25 = null;
        try {
            java.util.List<Viagem> list_viagem26 = cliente8.viagensEntreDatas(gregorianCalendar24, gregorianCalendar25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem17);
        org.junit.Assert.assertNotNull(cliente18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertTrue(i23 == (-1));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente8.getDataDeNascimento();
        java.lang.String str10 = cliente8.toString();
        java.util.GregorianCalendar gregorianCalendar11 = null;
        java.util.GregorianCalendar gregorianCalendar12 = null;
        try {
            java.util.List<Viagem> list_viagem13 = cliente8.viagensEntreDatas(gregorianCalendar11, gregorianCalendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str10.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Viagem viagem8 = null;
        try {
            cliente5.registaViagem(viagem8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        Cliente cliente23 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente29 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str30 = cliente29.getMail();
        java.util.Set<Viagem> set_viagem31 = cliente29.getHistorico();
        Cliente cliente32 = cliente29.clone();
        java.lang.String str33 = cliente29.getMail();
        int i34 = cliente23.compareTo(cliente29);
        int i35 = cliente11.compareTo((Ator) cliente29);
        java.util.GregorianCalendar gregorianCalendar36 = null;
        java.util.GregorianCalendar gregorianCalendar37 = null;
        try {
            java.util.List<Viagem> list_viagem38 = cliente29.viagensEntreDatas(gregorianCalendar36, gregorianCalendar37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem31);
        org.junit.Assert.assertNotNull(cliente32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertTrue(i34 == 0);
        org.junit.Assert.assertTrue(i35 == 0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMorada();
        java.util.GregorianCalendar gregorianCalendar10 = null;
        java.util.GregorianCalendar gregorianCalendar11 = null;
        try {
            java.util.List<Viagem> list_viagem12 = cliente5.viagensEntreDatas(gregorianCalendar10, gregorianCalendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        Cliente cliente23 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente29 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str30 = cliente29.getMail();
        java.util.Set<Viagem> set_viagem31 = cliente29.getHistorico();
        Cliente cliente32 = cliente29.clone();
        java.lang.String str33 = cliente29.getMail();
        int i34 = cliente23.compareTo(cliente29);
        int i35 = cliente11.compareTo((Ator) cliente29);
        cliente11.setMS(0.0d);
        java.util.GregorianCalendar gregorianCalendar38 = null;
        java.util.GregorianCalendar gregorianCalendar39 = null;
        try {
            java.util.List<Viagem> list_viagem40 = cliente11.viagensEntreDatas(gregorianCalendar38, gregorianCalendar39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem31);
        org.junit.Assert.assertNotNull(cliente32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertTrue(i34 == 0);
        org.junit.Assert.assertTrue(i35 == 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.util.GregorianCalendar gregorianCalendar9 = null;
        java.util.GregorianCalendar gregorianCalendar10 = null;
        try {
            java.util.List<Viagem> list_viagem11 = cliente5.viagensEntreDatas(gregorianCalendar9, gregorianCalendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        java.lang.String str10 = cliente5.getNome();
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente22 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str23 = cliente22.getMail();
        java.util.Set<Viagem> set_viagem24 = cliente22.getHistorico();
        Cliente cliente25 = cliente22.clone();
        java.lang.String str26 = cliente22.getMail();
        int i27 = cliente16.compareTo(cliente22);
        java.lang.String str28 = cliente22.toString();
        Cliente cliente34 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente40 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str41 = cliente40.getMail();
        java.util.Set<Viagem> set_viagem42 = cliente40.getHistorico();
        Cliente cliente43 = cliente40.clone();
        java.lang.String str44 = cliente40.getMail();
        int i45 = cliente34.compareTo(cliente40);
        int i46 = cliente22.compareTo((Ator) cliente40);
        cliente22.setMS((double) 10L);
        int i49 = cliente5.compareTo((Ator) cliente22);
        Viagem viagem50 = null;
        try {
            cliente5.registaViagem(viagem50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem24);
        org.junit.Assert.assertNotNull(cliente25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
        org.junit.Assert.assertTrue(i27 == 0);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str28.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "hi!" + "'", str41.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem42);
        org.junit.Assert.assertNotNull(cliente43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "hi!" + "'", str44.equals("hi!"));
        org.junit.Assert.assertTrue(i45 == 0);
        org.junit.Assert.assertTrue(i46 == 0);
        org.junit.Assert.assertTrue(i49 == 0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        try {
            Viagem viagem10 = cliente5.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        Cliente cliente10 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str17 = cliente16.getMail();
        java.util.Set<Viagem> set_viagem18 = cliente16.getHistorico();
        Cliente cliente19 = cliente16.clone();
        java.lang.String str20 = cliente16.getMail();
        int i21 = cliente10.compareTo(cliente16);
        java.lang.String str22 = cliente16.toString();
        java.util.Set<Viagem> set_viagem23 = cliente16.getHistorico();
        Cliente cliente25 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "", "", "", set_viagem23, 10.0d);
        cliente25.setMS((double) 0L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem18);
        org.junit.Assert.assertNotNull(cliente19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertTrue(i21 == 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str22.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem23);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        Cliente cliente14 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente20 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str21 = cliente20.getMail();
        java.util.Set<Viagem> set_viagem22 = cliente20.getHistorico();
        Cliente cliente23 = cliente20.clone();
        java.lang.String str24 = cliente20.getMail();
        int i25 = cliente14.compareTo(cliente20);
        java.lang.String str26 = cliente20.toString();
        int i27 = cliente5.compareTo(cliente20);
        Cliente cliente33 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str34 = cliente33.getMail();
        java.util.Set<Viagem> set_viagem35 = cliente33.getHistorico();
        Cliente cliente36 = cliente33.clone();
        java.lang.String str37 = cliente33.getMail();
        java.lang.String str38 = cliente33.getNome();
        boolean b39 = cliente20.equals((java.lang.Object) str38);
        java.lang.String str40 = cliente20.getMail();
        java.util.Set<Viagem> set_viagem41 = cliente20.getHistorico();
        Cliente cliente42 = new Cliente(cliente20);
        java.lang.String str43 = cliente42.getMail();
        java.util.GregorianCalendar gregorianCalendar44 = null;
        java.util.GregorianCalendar gregorianCalendar45 = null;
        try {
            java.util.List<Viagem> list_viagem46 = cliente42.viagensEntreDatas(gregorianCalendar44, gregorianCalendar45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem22);
        org.junit.Assert.assertNotNull(cliente23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str26.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue(i27 == 0);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem35);
        org.junit.Assert.assertNotNull(cliente36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
        org.junit.Assert.assertTrue(b39 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "hi!" + "'", str40.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem41);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "hi!" + "'", str43.equals("hi!"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        java.lang.String str10 = cliente5.getNome();
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente22 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str23 = cliente22.getMail();
        java.util.Set<Viagem> set_viagem24 = cliente22.getHistorico();
        Cliente cliente25 = cliente22.clone();
        java.lang.String str26 = cliente22.getMail();
        int i27 = cliente16.compareTo(cliente22);
        java.lang.String str28 = cliente22.toString();
        Cliente cliente34 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente40 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str41 = cliente40.getMail();
        java.util.Set<Viagem> set_viagem42 = cliente40.getHistorico();
        Cliente cliente43 = cliente40.clone();
        java.lang.String str44 = cliente40.getMail();
        int i45 = cliente34.compareTo(cliente40);
        int i46 = cliente22.compareTo((Ator) cliente40);
        cliente22.setMS((double) 10L);
        int i49 = cliente5.compareTo((Ator) cliente22);
        java.util.GregorianCalendar gregorianCalendar50 = null;
        java.util.GregorianCalendar gregorianCalendar51 = null;
        try {
            java.util.List<Viagem> list_viagem52 = cliente22.viagensEntreDatas(gregorianCalendar50, gregorianCalendar51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem24);
        org.junit.Assert.assertNotNull(cliente25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
        org.junit.Assert.assertTrue(i27 == 0);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str28.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "hi!" + "'", str41.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem42);
        org.junit.Assert.assertNotNull(cliente43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "hi!" + "'", str44.equals("hi!"));
        org.junit.Assert.assertTrue(i45 == 0);
        org.junit.Assert.assertTrue(i46 == 0);
        org.junit.Assert.assertTrue(i49 == 0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        cliente5.setMS(10.0d);
        java.lang.String str9 = cliente5.getMail();
        java.lang.String str10 = cliente5.getNome();
        try {
            Viagem viagem11 = cliente5.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        cliente5.setMS((double) '4');
        double d12 = cliente5.getMS();
        java.util.Set<Viagem> set_viagem13 = cliente5.getHistorico();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue(d12 == 52.0d);
        org.junit.Assert.assertNotNull(set_viagem13);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        Cliente cliente0 = null;
        try {
            Cliente cliente1 = new Cliente(cliente0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        Cliente cliente5 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "", "hi!", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n");
        Cliente cliente6 = cliente5.clone();
        cliente6.setMS((double) 10);
        org.junit.Assert.assertNotNull(cliente6);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        cliente5.setMS((double) '4');
        java.lang.String str12 = cliente5.toString();
        try {
            Viagem viagem13 = cliente5.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n" + "'", str12.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        Cliente cliente23 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente29 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str30 = cliente29.getMail();
        java.util.Set<Viagem> set_viagem31 = cliente29.getHistorico();
        Cliente cliente32 = cliente29.clone();
        java.lang.String str33 = cliente29.getMail();
        int i34 = cliente23.compareTo(cliente29);
        int i35 = cliente11.compareTo((Ator) cliente29);
        double d36 = cliente29.getMS();
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem31);
        org.junit.Assert.assertNotNull(cliente32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertTrue(i34 == 0);
        org.junit.Assert.assertTrue(i35 == 0);
        org.junit.Assert.assertTrue(d36 == 0.0d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        cliente5.setMS((double) '4');
        java.lang.String str12 = cliente5.getMorada();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        java.util.Set<Viagem> set_viagem18 = cliente11.getHistorico();
        java.util.Set<Viagem> set_viagem19 = cliente11.getHistorico();
        java.lang.String str20 = cliente11.getNome();
        double d21 = cliente11.getMS();
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem18);
        org.junit.Assert.assertNotNull(set_viagem19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue(d21 == 0.0d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        java.lang.String str10 = cliente5.getNome();
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente22 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str23 = cliente22.getMail();
        java.util.Set<Viagem> set_viagem24 = cliente22.getHistorico();
        Cliente cliente25 = cliente22.clone();
        java.lang.String str26 = cliente22.getMail();
        int i27 = cliente16.compareTo(cliente22);
        java.lang.String str28 = cliente22.toString();
        Cliente cliente34 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente40 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str41 = cliente40.getMail();
        java.util.Set<Viagem> set_viagem42 = cliente40.getHistorico();
        Cliente cliente43 = cliente40.clone();
        java.lang.String str44 = cliente40.getMail();
        int i45 = cliente34.compareTo(cliente40);
        int i46 = cliente22.compareTo((Ator) cliente40);
        cliente22.setMS((double) 10L);
        int i49 = cliente5.compareTo((Ator) cliente22);
        java.lang.String str50 = cliente22.getMail();
        double d51 = cliente22.getMS();
        java.lang.String str52 = cliente22.getMail();
        java.lang.String str53 = cliente22.getDataDeNascimento();
        java.lang.String str54 = cliente22.getDataDeNascimento();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem24);
        org.junit.Assert.assertNotNull(cliente25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
        org.junit.Assert.assertTrue(i27 == 0);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str28.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "hi!" + "'", str41.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem42);
        org.junit.Assert.assertNotNull(cliente43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "hi!" + "'", str44.equals("hi!"));
        org.junit.Assert.assertTrue(i45 == 0);
        org.junit.Assert.assertTrue(i46 == 0);
        org.junit.Assert.assertTrue(i49 == 0);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "hi!" + "'", str50.equals("hi!"));
        org.junit.Assert.assertTrue(d51 == 10.0d);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "hi!" + "'", str52.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "" + "'", str53.equals(""));
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "" + "'", str54.equals(""));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        Cliente cliente5 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "", "hi!", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n");
        Cliente cliente6 = cliente5.clone();
        java.lang.String str7 = cliente5.getDataDeNascimento();
        org.junit.Assert.assertNotNull(cliente6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n" + "'", str7.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        Cliente cliente10 = new Cliente("hi!", "", "", "hi!", "");
        java.util.Set<Viagem> set_viagem11 = cliente10.getHistorico();
        Cliente cliente13 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "hi!", "", set_viagem11, (double) 10.0f);
        java.util.GregorianCalendar gregorianCalendar14 = null;
        java.util.GregorianCalendar gregorianCalendar15 = null;
        try {
            java.util.List<Viagem> list_viagem16 = cliente13.viagensEntreDatas(gregorianCalendar14, gregorianCalendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(set_viagem11);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        Cliente cliente5 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "hi!", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n");
        java.util.GregorianCalendar gregorianCalendar6 = null;
        java.util.GregorianCalendar gregorianCalendar7 = null;
        try {
            java.util.List<Viagem> list_viagem8 = cliente5.viagensEntreDatas(gregorianCalendar6, gregorianCalendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        java.util.Set<Viagem> set_viagem18 = cliente11.getHistorico();
        java.lang.String str19 = cliente11.toString();
        java.lang.String str20 = cliente11.getMail();
        Cliente cliente21 = new Cliente(cliente11);
        cliente11.setMS((double) (short) 1);
        java.lang.String str24 = cliente11.getNome();
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str19.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        Cliente cliente23 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente29 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str30 = cliente29.getMail();
        java.util.Set<Viagem> set_viagem31 = cliente29.getHistorico();
        Cliente cliente32 = cliente29.clone();
        java.lang.String str33 = cliente29.getMail();
        int i34 = cliente23.compareTo(cliente29);
        int i35 = cliente11.compareTo((Ator) cliente29);
        cliente11.setMS((double) 10L);
        java.lang.String str38 = cliente11.getDataDeNascimento();
        java.lang.String str39 = cliente11.getDataDeNascimento();
        try {
            Viagem viagem40 = cliente11.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem31);
        org.junit.Assert.assertNotNull(cliente32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertTrue(i34 == 0);
        org.junit.Assert.assertTrue(i35 == 0);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "" + "'", str39.equals(""));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        Cliente cliente10 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str17 = cliente16.getMail();
        java.util.Set<Viagem> set_viagem18 = cliente16.getHistorico();
        Cliente cliente19 = cliente16.clone();
        java.lang.String str20 = cliente16.getMail();
        int i21 = cliente10.compareTo(cliente16);
        java.lang.String str22 = cliente16.toString();
        java.util.Set<Viagem> set_viagem23 = cliente16.getHistorico();
        Cliente cliente25 = new Cliente("", "hi!", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "hi!", "hi!", set_viagem23, (double) 100L);
        java.util.Set<Viagem> set_viagem26 = cliente25.getHistorico();
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem18);
        org.junit.Assert.assertNotNull(cliente19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertTrue(i21 == 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str22.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem23);
        org.junit.Assert.assertNotNull(set_viagem26);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        Cliente cliente14 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente20 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str21 = cliente20.getMail();
        java.util.Set<Viagem> set_viagem22 = cliente20.getHistorico();
        Cliente cliente23 = cliente20.clone();
        java.lang.String str24 = cliente20.getMail();
        int i25 = cliente14.compareTo(cliente20);
        java.lang.String str26 = cliente20.toString();
        int i27 = cliente5.compareTo(cliente20);
        Cliente cliente33 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str34 = cliente33.getMail();
        java.util.Set<Viagem> set_viagem35 = cliente33.getHistorico();
        Cliente cliente36 = cliente33.clone();
        java.lang.String str37 = cliente33.getMail();
        java.lang.String str38 = cliente33.getNome();
        boolean b39 = cliente20.equals((java.lang.Object) str38);
        java.lang.String str40 = cliente20.getPassword();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem22);
        org.junit.Assert.assertNotNull(cliente23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str26.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue(i27 == 0);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem35);
        org.junit.Assert.assertNotNull(cliente36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
        org.junit.Assert.assertTrue(b39 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "" + "'", str40.equals(""));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        Cliente cliente23 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente29 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str30 = cliente29.getMail();
        java.util.Set<Viagem> set_viagem31 = cliente29.getHistorico();
        Cliente cliente32 = cliente29.clone();
        java.lang.String str33 = cliente29.getMail();
        int i34 = cliente23.compareTo(cliente29);
        int i35 = cliente11.compareTo((Ator) cliente29);
        Cliente cliente41 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str42 = cliente41.getMail();
        java.util.Set<Viagem> set_viagem43 = cliente41.getHistorico();
        Cliente cliente44 = cliente41.clone();
        int i45 = cliente11.compareTo(cliente41);
        Viagem viagem46 = null;
        try {
            cliente41.registaViagem(viagem46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem31);
        org.junit.Assert.assertNotNull(cliente32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertTrue(i34 == 0);
        org.junit.Assert.assertTrue(i35 == 0);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "hi!" + "'", str42.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem43);
        org.junit.Assert.assertNotNull(cliente44);
        org.junit.Assert.assertTrue(i45 == 0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        Cliente cliente23 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente29 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str30 = cliente29.getMail();
        java.util.Set<Viagem> set_viagem31 = cliente29.getHistorico();
        Cliente cliente32 = cliente29.clone();
        java.lang.String str33 = cliente29.getMail();
        int i34 = cliente23.compareTo(cliente29);
        int i35 = cliente11.compareTo((Ator) cliente29);
        Cliente cliente41 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str42 = cliente41.getMail();
        java.util.Set<Viagem> set_viagem43 = cliente41.getHistorico();
        Cliente cliente44 = cliente41.clone();
        int i45 = cliente11.compareTo(cliente41);
        java.lang.String str46 = cliente41.getMail();
        double d47 = cliente41.getMS();
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem31);
        org.junit.Assert.assertNotNull(cliente32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertTrue(i34 == 0);
        org.junit.Assert.assertTrue(i35 == 0);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "hi!" + "'", str42.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem43);
        org.junit.Assert.assertNotNull(cliente44);
        org.junit.Assert.assertTrue(i45 == 0);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "hi!" + "'", str46.equals("hi!"));
        org.junit.Assert.assertTrue(d47 == 0.0d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        java.lang.String str10 = cliente5.getNome();
        java.util.GregorianCalendar gregorianCalendar11 = null;
        java.util.GregorianCalendar gregorianCalendar12 = null;
        try {
            java.util.List<Viagem> list_viagem13 = cliente5.viagensEntreDatas(gregorianCalendar11, gregorianCalendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        Cliente cliente10 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str17 = cliente16.getMail();
        java.util.Set<Viagem> set_viagem18 = cliente16.getHistorico();
        Cliente cliente19 = cliente16.clone();
        java.lang.String str20 = cliente16.getMail();
        int i21 = cliente10.compareTo(cliente16);
        java.lang.String str22 = cliente16.toString();
        java.util.Set<Viagem> set_viagem23 = cliente16.getHistorico();
        java.lang.String str24 = cliente16.toString();
        java.lang.String str25 = cliente16.getMail();
        Cliente cliente26 = new Cliente(cliente16);
        Cliente cliente32 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente38 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str39 = cliente38.getMail();
        java.util.Set<Viagem> set_viagem40 = cliente38.getHistorico();
        Cliente cliente41 = cliente38.clone();
        java.lang.String str42 = cliente38.getMail();
        int i43 = cliente32.compareTo(cliente38);
        java.lang.String str44 = cliente38.toString();
        java.util.Set<Viagem> set_viagem45 = cliente38.getHistorico();
        boolean b46 = cliente16.equals((java.lang.Object) set_viagem45);
        Cliente cliente48 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "hi!", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", set_viagem45, (double) 0.0f);
        java.lang.String str49 = cliente48.toString();
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem18);
        org.junit.Assert.assertNotNull(cliente19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertTrue(i21 == 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str22.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str24.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "hi!" + "'", str39.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem40);
        org.junit.Assert.assertNotNull(cliente41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "hi!" + "'", str42.equals("hi!"));
        org.junit.Assert.assertTrue(i43 == 0);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str44.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem45);
        org.junit.Assert.assertTrue(b46 == false);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str49.equals("E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        Cliente cliente0 = new Cliente();
        cliente0.setMS((double) 100);
        java.util.GregorianCalendar gregorianCalendar3 = null;
        java.util.GregorianCalendar gregorianCalendar4 = null;
        try {
            java.util.List<Viagem> list_viagem5 = cliente0.viagensEntreDatas(gregorianCalendar3, gregorianCalendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        cliente5.setMS(10.0d);
        java.util.Set<Viagem> set_viagem9 = cliente5.getHistorico();
        Cliente cliente10 = new Cliente(cliente5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem9);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        Cliente cliente5 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "hi!", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        int i12 = cliente5.compareTo(cliente11);
        java.util.Set<Viagem> set_viagem13 = cliente5.getHistorico();
        java.lang.String str14 = cliente5.getDataDeNascimento();
        java.lang.String str15 = cliente5.toString();
        org.junit.Assert.assertTrue(i12 == (-35));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str14.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str15.equals("E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        java.util.Set<Viagem> set_viagem18 = cliente11.getHistorico();
        java.lang.String str19 = cliente11.toString();
        java.lang.String str20 = cliente11.getMail();
        java.util.GregorianCalendar gregorianCalendar21 = null;
        java.util.GregorianCalendar gregorianCalendar22 = null;
        try {
            java.util.List<Viagem> list_viagem23 = cliente11.viagensEntreDatas(gregorianCalendar21, gregorianCalendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str19.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        Cliente cliente14 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente20 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str21 = cliente20.getMail();
        java.util.Set<Viagem> set_viagem22 = cliente20.getHistorico();
        Cliente cliente23 = cliente20.clone();
        java.lang.String str24 = cliente20.getMail();
        int i25 = cliente14.compareTo(cliente20);
        java.lang.String str26 = cliente20.toString();
        int i27 = cliente5.compareTo(cliente20);
        Cliente cliente33 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str34 = cliente33.getMail();
        java.util.Set<Viagem> set_viagem35 = cliente33.getHistorico();
        Cliente cliente36 = cliente33.clone();
        java.lang.String str37 = cliente33.getMail();
        java.lang.String str38 = cliente33.getNome();
        boolean b39 = cliente20.equals((java.lang.Object) str38);
        java.lang.String str40 = cliente20.getMail();
        java.util.Set<Viagem> set_viagem41 = cliente20.getHistorico();
        Cliente cliente42 = new Cliente(cliente20);
        java.util.GregorianCalendar gregorianCalendar43 = null;
        java.util.GregorianCalendar gregorianCalendar44 = null;
        try {
            java.util.List<Viagem> list_viagem45 = cliente42.viagensEntreDatas(gregorianCalendar43, gregorianCalendar44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem22);
        org.junit.Assert.assertNotNull(cliente23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str26.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue(i27 == 0);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem35);
        org.junit.Assert.assertNotNull(cliente36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
        org.junit.Assert.assertTrue(b39 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "hi!" + "'", str40.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem41);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        java.lang.String str18 = cliente11.getNome();
        Cliente cliente19 = cliente11.clone();
        java.util.GregorianCalendar gregorianCalendar20 = null;
        java.util.GregorianCalendar gregorianCalendar21 = null;
        try {
            java.util.List<Viagem> list_viagem22 = cliente11.viagensEntreDatas(gregorianCalendar20, gregorianCalendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertNotNull(cliente19);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        Cliente cliente14 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente20 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str21 = cliente20.getMail();
        java.util.Set<Viagem> set_viagem22 = cliente20.getHistorico();
        Cliente cliente23 = cliente20.clone();
        java.lang.String str24 = cliente20.getMail();
        int i25 = cliente14.compareTo(cliente20);
        java.lang.String str26 = cliente20.toString();
        int i27 = cliente5.compareTo(cliente20);
        Cliente cliente33 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str34 = cliente33.getMail();
        java.util.Set<Viagem> set_viagem35 = cliente33.getHistorico();
        Cliente cliente36 = cliente33.clone();
        java.lang.String str37 = cliente33.getMail();
        java.lang.String str38 = cliente33.getNome();
        boolean b39 = cliente20.equals((java.lang.Object) str38);
        java.lang.String str40 = cliente20.getMail();
        java.util.Set<Viagem> set_viagem41 = cliente20.getHistorico();
        Cliente cliente42 = new Cliente(cliente20);
        Cliente cliente43 = cliente20.clone();
        double d44 = cliente20.getMS();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem22);
        org.junit.Assert.assertNotNull(cliente23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str26.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue(i27 == 0);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem35);
        org.junit.Assert.assertNotNull(cliente36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
        org.junit.Assert.assertTrue(b39 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "hi!" + "'", str40.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem41);
        org.junit.Assert.assertNotNull(cliente43);
        org.junit.Assert.assertTrue(d44 == 0.0d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        Cliente cliente5 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "hi!", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        int i12 = cliente5.compareTo(cliente11);
        cliente5.setMS((double) (byte) 0);
        try {
            Viagem viagem15 = cliente5.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertTrue(i12 == (-35));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        Cliente cliente5 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "", "", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "hi!");
        Viagem viagem6 = null;
        try {
            cliente5.registaViagem(viagem6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        Cliente cliente10 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str17 = cliente16.getMail();
        java.util.Set<Viagem> set_viagem18 = cliente16.getHistorico();
        Cliente cliente19 = cliente16.clone();
        java.lang.String str20 = cliente16.getMail();
        int i21 = cliente10.compareTo(cliente16);
        java.lang.String str22 = cliente16.toString();
        java.util.Set<Viagem> set_viagem23 = cliente16.getHistorico();
        java.lang.String str24 = cliente16.toString();
        java.lang.String str25 = cliente16.getMail();
        Cliente cliente26 = new Cliente(cliente16);
        Cliente cliente32 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente38 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str39 = cliente38.getMail();
        java.util.Set<Viagem> set_viagem40 = cliente38.getHistorico();
        Cliente cliente41 = cliente38.clone();
        java.lang.String str42 = cliente38.getMail();
        int i43 = cliente32.compareTo(cliente38);
        java.lang.String str44 = cliente38.toString();
        java.util.Set<Viagem> set_viagem45 = cliente38.getHistorico();
        boolean b46 = cliente16.equals((java.lang.Object) set_viagem45);
        Cliente cliente48 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "", set_viagem45, (double) 100);
        Cliente cliente59 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente65 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str66 = cliente65.getMail();
        java.util.Set<Viagem> set_viagem67 = cliente65.getHistorico();
        Cliente cliente68 = cliente65.clone();
        java.lang.String str69 = cliente65.getMail();
        int i70 = cliente59.compareTo(cliente65);
        java.lang.String str71 = cliente65.toString();
        java.util.Set<Viagem> set_viagem72 = cliente65.getHistorico();
        java.lang.String str73 = cliente65.toString();
        java.lang.String str74 = cliente65.getMail();
        Cliente cliente75 = new Cliente(cliente65);
        Cliente cliente81 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente87 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str88 = cliente87.getMail();
        java.util.Set<Viagem> set_viagem89 = cliente87.getHistorico();
        Cliente cliente90 = cliente87.clone();
        java.lang.String str91 = cliente87.getMail();
        int i92 = cliente81.compareTo(cliente87);
        java.lang.String str93 = cliente87.toString();
        java.util.Set<Viagem> set_viagem94 = cliente87.getHistorico();
        boolean b95 = cliente65.equals((java.lang.Object) set_viagem94);
        Cliente cliente97 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "", set_viagem94, (double) 100);
        boolean b98 = cliente48.equals((java.lang.Object) "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n");
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem18);
        org.junit.Assert.assertNotNull(cliente19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertTrue(i21 == 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str22.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str24.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "hi!" + "'", str39.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem40);
        org.junit.Assert.assertNotNull(cliente41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "hi!" + "'", str42.equals("hi!"));
        org.junit.Assert.assertTrue(i43 == 0);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str44.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem45);
        org.junit.Assert.assertTrue(b46 == false);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "hi!" + "'", str66.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem67);
        org.junit.Assert.assertNotNull(cliente68);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "hi!" + "'", str69.equals("hi!"));
        org.junit.Assert.assertTrue(i70 == 0);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str71.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem72);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str73.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "hi!" + "'", str74.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "hi!" + "'", str88.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem89);
        org.junit.Assert.assertNotNull(cliente90);
        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "hi!" + "'", str91.equals("hi!"));
        org.junit.Assert.assertTrue(i92 == 0);
        org.junit.Assert.assertTrue("'" + str93 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str93.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem94);
        org.junit.Assert.assertTrue(b95 == false);
        org.junit.Assert.assertTrue(b98 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        Cliente cliente5 = new Cliente("", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n");
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        Cliente cliente0 = new Cliente();
        cliente0.setMS((double) 100);
        Cliente cliente8 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str9 = cliente8.getMail();
        java.util.Set<Viagem> set_viagem10 = cliente8.getHistorico();
        Cliente cliente11 = cliente8.clone();
        Cliente cliente17 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente23 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str24 = cliente23.getMail();
        java.util.Set<Viagem> set_viagem25 = cliente23.getHistorico();
        Cliente cliente26 = cliente23.clone();
        java.lang.String str27 = cliente23.getMail();
        int i28 = cliente17.compareTo(cliente23);
        java.lang.String str29 = cliente23.toString();
        int i30 = cliente8.compareTo(cliente23);
        int i31 = cliente0.compareTo(cliente8);
        try {
            Viagem viagem32 = cliente0.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem10);
        org.junit.Assert.assertNotNull(cliente11);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem25);
        org.junit.Assert.assertNotNull(cliente26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "hi!" + "'", str27.equals("hi!"));
        org.junit.Assert.assertTrue(i28 == 0);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str29.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue(i30 == 0);
        org.junit.Assert.assertTrue(i31 == (-3));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        Cliente cliente5 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "", "", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "hi!");
        java.lang.String str6 = cliente5.getNome();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        Cliente cliente10 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str17 = cliente16.getMail();
        java.util.Set<Viagem> set_viagem18 = cliente16.getHistorico();
        Cliente cliente19 = cliente16.clone();
        java.lang.String str20 = cliente16.getMail();
        int i21 = cliente10.compareTo(cliente16);
        java.lang.String str22 = cliente16.toString();
        java.util.Set<Viagem> set_viagem23 = cliente16.getHistorico();
        Cliente cliente25 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "", "", "", set_viagem23, 10.0d);
        java.lang.String str26 = cliente25.getPassword();
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem18);
        org.junit.Assert.assertNotNull(cliente19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertTrue(i21 == 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str22.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        Cliente cliente5 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "", "", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n");
        java.util.GregorianCalendar gregorianCalendar6 = null;
        java.util.GregorianCalendar gregorianCalendar7 = null;
        try {
            java.util.List<Viagem> list_viagem8 = cliente5.viagensEntreDatas(gregorianCalendar6, gregorianCalendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        Cliente cliente5 = new Cliente("E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n");
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        Cliente cliente23 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente29 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str30 = cliente29.getMail();
        java.util.Set<Viagem> set_viagem31 = cliente29.getHistorico();
        Cliente cliente32 = cliente29.clone();
        java.lang.String str33 = cliente29.getMail();
        int i34 = cliente23.compareTo(cliente29);
        int i35 = cliente11.compareTo((Ator) cliente29);
        Cliente cliente41 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str42 = cliente41.getMail();
        java.util.Set<Viagem> set_viagem43 = cliente41.getHistorico();
        Cliente cliente44 = cliente41.clone();
        int i45 = cliente11.compareTo(cliente41);
        Cliente cliente51 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente57 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str58 = cliente57.getMail();
        java.util.Set<Viagem> set_viagem59 = cliente57.getHistorico();
        Cliente cliente60 = cliente57.clone();
        java.lang.String str61 = cliente57.getMail();
        int i62 = cliente51.compareTo(cliente57);
        java.lang.String str63 = cliente57.toString();
        Cliente cliente69 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente75 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str76 = cliente75.getMail();
        java.util.Set<Viagem> set_viagem77 = cliente75.getHistorico();
        Cliente cliente78 = cliente75.clone();
        java.lang.String str79 = cliente75.getMail();
        int i80 = cliente69.compareTo(cliente75);
        int i81 = cliente57.compareTo((Ator) cliente75);
        Cliente cliente87 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str88 = cliente87.getMail();
        java.util.Set<Viagem> set_viagem89 = cliente87.getHistorico();
        Cliente cliente90 = cliente87.clone();
        int i91 = cliente57.compareTo(cliente87);
        java.lang.String str92 = cliente87.getMail();
        java.lang.String str93 = cliente87.toString();
        int i94 = cliente41.compareTo(cliente87);
        Viagem viagem95 = null;
        try {
            cliente41.registaViagem(viagem95);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem31);
        org.junit.Assert.assertNotNull(cliente32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertTrue(i34 == 0);
        org.junit.Assert.assertTrue(i35 == 0);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "hi!" + "'", str42.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem43);
        org.junit.Assert.assertNotNull(cliente44);
        org.junit.Assert.assertTrue(i45 == 0);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "hi!" + "'", str58.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem59);
        org.junit.Assert.assertNotNull(cliente60);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "hi!" + "'", str61.equals("hi!"));
        org.junit.Assert.assertTrue(i62 == 0);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str63.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "hi!" + "'", str76.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem77);
        org.junit.Assert.assertNotNull(cliente78);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "hi!" + "'", str79.equals("hi!"));
        org.junit.Assert.assertTrue(i80 == 0);
        org.junit.Assert.assertTrue(i81 == 0);
        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "hi!" + "'", str88.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem89);
        org.junit.Assert.assertNotNull(cliente90);
        org.junit.Assert.assertTrue(i91 == 0);
        org.junit.Assert.assertTrue("'" + str92 + "' != '" + "hi!" + "'", str92.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str93 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str93.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue(i94 == 0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        cliente5.setMS(10.0d);
        java.util.Set<Viagem> set_viagem9 = cliente5.getHistorico();
        java.lang.String str10 = cliente5.toString();
        java.lang.String str11 = cliente5.getPassword();
        double d12 = cliente5.getMS();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n" + "'", str10.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue(d12 == 10.0d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        Cliente cliente23 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente29 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str30 = cliente29.getMail();
        java.util.Set<Viagem> set_viagem31 = cliente29.getHistorico();
        Cliente cliente32 = cliente29.clone();
        java.lang.String str33 = cliente29.getMail();
        int i34 = cliente23.compareTo(cliente29);
        int i35 = cliente11.compareTo((Ator) cliente29);
        Cliente cliente41 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str42 = cliente41.getMail();
        java.util.Set<Viagem> set_viagem43 = cliente41.getHistorico();
        Cliente cliente44 = cliente41.clone();
        int i45 = cliente11.compareTo(cliente41);
        Cliente cliente51 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente57 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str58 = cliente57.getMail();
        java.util.Set<Viagem> set_viagem59 = cliente57.getHistorico();
        Cliente cliente60 = cliente57.clone();
        java.lang.String str61 = cliente57.getMail();
        int i62 = cliente51.compareTo(cliente57);
        java.lang.String str63 = cliente57.toString();
        Cliente cliente69 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente75 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str76 = cliente75.getMail();
        java.util.Set<Viagem> set_viagem77 = cliente75.getHistorico();
        Cliente cliente78 = cliente75.clone();
        java.lang.String str79 = cliente75.getMail();
        int i80 = cliente69.compareTo(cliente75);
        int i81 = cliente57.compareTo((Ator) cliente75);
        Cliente cliente87 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str88 = cliente87.getMail();
        java.util.Set<Viagem> set_viagem89 = cliente87.getHistorico();
        Cliente cliente90 = cliente87.clone();
        int i91 = cliente57.compareTo(cliente87);
        java.lang.String str92 = cliente87.getMail();
        java.lang.String str93 = cliente87.toString();
        int i94 = cliente41.compareTo(cliente87);
        Cliente cliente95 = new Cliente(cliente87);
        try {
            Viagem viagem96 = cliente87.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem31);
        org.junit.Assert.assertNotNull(cliente32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertTrue(i34 == 0);
        org.junit.Assert.assertTrue(i35 == 0);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "hi!" + "'", str42.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem43);
        org.junit.Assert.assertNotNull(cliente44);
        org.junit.Assert.assertTrue(i45 == 0);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "hi!" + "'", str58.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem59);
        org.junit.Assert.assertNotNull(cliente60);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "hi!" + "'", str61.equals("hi!"));
        org.junit.Assert.assertTrue(i62 == 0);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str63.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "hi!" + "'", str76.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem77);
        org.junit.Assert.assertNotNull(cliente78);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "hi!" + "'", str79.equals("hi!"));
        org.junit.Assert.assertTrue(i80 == 0);
        org.junit.Assert.assertTrue(i81 == 0);
        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "hi!" + "'", str88.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem89);
        org.junit.Assert.assertNotNull(cliente90);
        org.junit.Assert.assertTrue(i91 == 0);
        org.junit.Assert.assertTrue("'" + str92 + "' != '" + "hi!" + "'", str92.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str93 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str93.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue(i94 == 0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        Cliente cliente14 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente20 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str21 = cliente20.getMail();
        java.util.Set<Viagem> set_viagem22 = cliente20.getHistorico();
        Cliente cliente23 = cliente20.clone();
        java.lang.String str24 = cliente20.getMail();
        int i25 = cliente14.compareTo(cliente20);
        java.lang.String str26 = cliente20.toString();
        int i27 = cliente5.compareTo(cliente20);
        Cliente cliente33 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str34 = cliente33.getMail();
        java.util.Set<Viagem> set_viagem35 = cliente33.getHistorico();
        Cliente cliente36 = cliente33.clone();
        java.lang.String str37 = cliente33.getMail();
        java.lang.String str38 = cliente33.getNome();
        boolean b39 = cliente20.equals((java.lang.Object) str38);
        java.lang.String str40 = cliente20.getMail();
        java.util.Set<Viagem> set_viagem41 = cliente20.getHistorico();
        try {
            Viagem viagem42 = cliente20.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem22);
        org.junit.Assert.assertNotNull(cliente23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str26.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue(i27 == 0);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem35);
        org.junit.Assert.assertNotNull(cliente36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
        org.junit.Assert.assertTrue(b39 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "hi!" + "'", str40.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem41);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        Cliente cliente15 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "hi!", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n");
        Cliente cliente21 = new Cliente("hi!", "", "", "hi!", "");
        int i22 = cliente15.compareTo(cliente21);
        java.util.Set<Viagem> set_viagem23 = cliente21.getHistorico();
        java.util.Set<Viagem> set_viagem24 = cliente21.getHistorico();
        Cliente cliente26 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "hi!", "hi!", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", set_viagem24, 0.0d);
        Cliente cliente28 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "", set_viagem24, (double) 0L);
        org.junit.Assert.assertTrue(i22 == (-35));
        org.junit.Assert.assertNotNull(set_viagem23);
        org.junit.Assert.assertNotNull(set_viagem24);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        Cliente cliente17 = new Cliente();
        int i18 = cliente5.compareTo(cliente17);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue(i18 == 3);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        java.util.Set<Viagem> set_viagem18 = cliente11.getHistorico();
        java.lang.String str19 = cliente11.toString();
        java.lang.String str20 = cliente11.getMail();
        Cliente cliente21 = new Cliente(cliente11);
        Cliente cliente27 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente33 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str34 = cliente33.getMail();
        java.util.Set<Viagem> set_viagem35 = cliente33.getHistorico();
        Cliente cliente36 = cliente33.clone();
        java.lang.String str37 = cliente33.getMail();
        int i38 = cliente27.compareTo(cliente33);
        java.lang.String str39 = cliente33.toString();
        java.util.Set<Viagem> set_viagem40 = cliente33.getHistorico();
        boolean b41 = cliente11.equals((java.lang.Object) set_viagem40);
        Cliente cliente42 = cliente11.clone();
        try {
            Viagem viagem43 = cliente42.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str19.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem35);
        org.junit.Assert.assertNotNull(cliente36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
        org.junit.Assert.assertTrue(i38 == 0);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str39.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem40);
        org.junit.Assert.assertTrue(b41 == false);
        org.junit.Assert.assertNotNull(cliente42);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        Cliente cliente23 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente29 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str30 = cliente29.getMail();
        java.util.Set<Viagem> set_viagem31 = cliente29.getHistorico();
        Cliente cliente32 = cliente29.clone();
        java.lang.String str33 = cliente29.getMail();
        int i34 = cliente23.compareTo(cliente29);
        int i35 = cliente11.compareTo((Ator) cliente29);
        cliente11.setMS(0.0d);
        java.lang.String str38 = cliente11.getNome();
        java.lang.String str39 = cliente11.toString();
        java.lang.String str40 = cliente11.getMorada();
        try {
            Viagem viagem41 = cliente11.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem31);
        org.junit.Assert.assertNotNull(cliente32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertTrue(i34 == 0);
        org.junit.Assert.assertTrue(i35 == 0);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str39.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "hi!" + "'", str40.equals("hi!"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        Cliente cliente15 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente21 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str22 = cliente21.getMail();
        java.util.Set<Viagem> set_viagem23 = cliente21.getHistorico();
        Cliente cliente24 = cliente21.clone();
        java.lang.String str25 = cliente21.getMail();
        int i26 = cliente15.compareTo(cliente21);
        java.lang.String str27 = cliente21.toString();
        java.util.Set<Viagem> set_viagem28 = cliente21.getHistorico();
        java.lang.String str29 = cliente21.toString();
        java.lang.String str30 = cliente21.getMail();
        Cliente cliente31 = new Cliente(cliente21);
        Cliente cliente37 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente43 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str44 = cliente43.getMail();
        java.util.Set<Viagem> set_viagem45 = cliente43.getHistorico();
        Cliente cliente46 = cliente43.clone();
        java.lang.String str47 = cliente43.getMail();
        int i48 = cliente37.compareTo(cliente43);
        java.lang.String str49 = cliente43.toString();
        java.util.Set<Viagem> set_viagem50 = cliente43.getHistorico();
        boolean b51 = cliente21.equals((java.lang.Object) set_viagem50);
        Cliente cliente53 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "hi!", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", set_viagem50, (double) 0.0f);
        Cliente cliente55 = new Cliente("", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "", "hi!", set_viagem50, (double) (short) 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!" + "'", str22.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem23);
        org.junit.Assert.assertNotNull(cliente24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
        org.junit.Assert.assertTrue(i26 == 0);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str27.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str29.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "hi!" + "'", str44.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem45);
        org.junit.Assert.assertNotNull(cliente46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "hi!" + "'", str47.equals("hi!"));
        org.junit.Assert.assertTrue(i48 == 0);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str49.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem50);
        org.junit.Assert.assertTrue(b51 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        Cliente cliente23 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente29 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str30 = cliente29.getMail();
        java.util.Set<Viagem> set_viagem31 = cliente29.getHistorico();
        Cliente cliente32 = cliente29.clone();
        java.lang.String str33 = cliente29.getMail();
        int i34 = cliente23.compareTo(cliente29);
        int i35 = cliente11.compareTo((Ator) cliente29);
        cliente11.setMS((double) 10L);
        cliente11.setMS(10.0d);
        java.util.GregorianCalendar gregorianCalendar40 = null;
        java.util.GregorianCalendar gregorianCalendar41 = null;
        try {
            java.util.List<Viagem> list_viagem42 = cliente11.viagensEntreDatas(gregorianCalendar40, gregorianCalendar41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem31);
        org.junit.Assert.assertNotNull(cliente32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertTrue(i34 == 0);
        org.junit.Assert.assertTrue(i35 == 0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        Cliente cliente23 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente29 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str30 = cliente29.getMail();
        java.util.Set<Viagem> set_viagem31 = cliente29.getHistorico();
        Cliente cliente32 = cliente29.clone();
        java.lang.String str33 = cliente29.getMail();
        int i34 = cliente23.compareTo(cliente29);
        int i35 = cliente11.compareTo((Ator) cliente29);
        cliente11.setMS((double) 10L);
        cliente11.setMS(10.0d);
        java.lang.String str40 = cliente11.getMorada();
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem31);
        org.junit.Assert.assertNotNull(cliente32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertTrue(i34 == 0);
        org.junit.Assert.assertTrue(i35 == 0);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "hi!" + "'", str40.equals("hi!"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        java.util.Set<Viagem> set_viagem18 = cliente11.getHistorico();
        java.lang.String str19 = cliente11.toString();
        java.lang.String str20 = cliente11.getMail();
        Cliente cliente26 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente32 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str33 = cliente32.getMail();
        java.util.Set<Viagem> set_viagem34 = cliente32.getHistorico();
        Cliente cliente35 = cliente32.clone();
        java.lang.String str36 = cliente32.getMail();
        int i37 = cliente26.compareTo(cliente32);
        int i38 = cliente11.compareTo(cliente32);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str19.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem34);
        org.junit.Assert.assertNotNull(cliente35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertTrue(i37 == 0);
        org.junit.Assert.assertTrue(i38 == 0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        Cliente cliente0 = new Cliente();
        Cliente cliente1 = cliente0.clone();
        java.lang.String str2 = cliente1.getDataDeNascimento();
        org.junit.Assert.assertNotNull(cliente1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        java.util.Set<Viagem> set_viagem18 = cliente11.getHistorico();
        java.util.Set<Viagem> set_viagem19 = cliente11.getHistorico();
        java.lang.String str20 = cliente11.toString();
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem18);
        org.junit.Assert.assertNotNull(set_viagem19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str20.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        Cliente cliente5 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "", "hi!", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n");
        java.util.GregorianCalendar gregorianCalendar6 = null;
        java.util.GregorianCalendar gregorianCalendar7 = null;
        try {
            java.util.List<Viagem> list_viagem8 = cliente5.viagensEntreDatas(gregorianCalendar6, gregorianCalendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        Cliente cliente23 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente29 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str30 = cliente29.getMail();
        java.util.Set<Viagem> set_viagem31 = cliente29.getHistorico();
        Cliente cliente32 = cliente29.clone();
        java.lang.String str33 = cliente29.getMail();
        int i34 = cliente23.compareTo(cliente29);
        int i35 = cliente11.compareTo((Ator) cliente29);
        cliente11.setMS(0.0d);
        Viagem viagem38 = null;
        try {
            cliente11.registaViagem(viagem38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem31);
        org.junit.Assert.assertNotNull(cliente32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertTrue(i34 == 0);
        org.junit.Assert.assertTrue(i35 == 0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        Cliente cliente14 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente20 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str21 = cliente20.getMail();
        java.util.Set<Viagem> set_viagem22 = cliente20.getHistorico();
        Cliente cliente23 = cliente20.clone();
        java.lang.String str24 = cliente20.getMail();
        int i25 = cliente14.compareTo(cliente20);
        java.lang.String str26 = cliente20.toString();
        int i27 = cliente5.compareTo(cliente20);
        Cliente cliente33 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str34 = cliente33.getMail();
        java.util.Set<Viagem> set_viagem35 = cliente33.getHistorico();
        Cliente cliente36 = cliente33.clone();
        java.lang.String str37 = cliente33.getMail();
        java.lang.String str38 = cliente33.getNome();
        boolean b39 = cliente20.equals((java.lang.Object) str38);
        java.lang.String str40 = cliente20.getMail();
        java.util.Set<Viagem> set_viagem41 = cliente20.getHistorico();
        Cliente cliente52 = new Cliente("hi!", "", "", "hi!", "");
        java.util.Set<Viagem> set_viagem53 = cliente52.getHistorico();
        Cliente cliente55 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "hi!", "", set_viagem53, (double) 10.0f);
        Cliente cliente61 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str62 = cliente61.getMail();
        java.util.Set<Viagem> set_viagem63 = cliente61.getHistorico();
        Cliente cliente64 = cliente61.clone();
        java.lang.String str65 = cliente61.getMail();
        java.lang.String str66 = cliente61.getNome();
        int i67 = cliente55.compareTo((Ator) cliente61);
        Cliente cliente68 = new Cliente(cliente55);
        int i69 = cliente20.compareTo((Ator) cliente55);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem22);
        org.junit.Assert.assertNotNull(cliente23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str26.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue(i27 == 0);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem35);
        org.junit.Assert.assertNotNull(cliente36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
        org.junit.Assert.assertTrue(b39 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "hi!" + "'", str40.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem41);
        org.junit.Assert.assertNotNull(set_viagem53);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "hi!" + "'", str62.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem63);
        org.junit.Assert.assertNotNull(cliente64);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "hi!" + "'", str65.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "" + "'", str66.equals(""));
        org.junit.Assert.assertTrue(i67 == (-35));
        org.junit.Assert.assertTrue(i69 == 35);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        Cliente cliente5 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "", "", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "hi!");
        java.lang.String str6 = cliente5.getDataDeNascimento();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        Cliente cliente14 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente20 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str21 = cliente20.getMail();
        java.util.Set<Viagem> set_viagem22 = cliente20.getHistorico();
        Cliente cliente23 = cliente20.clone();
        java.lang.String str24 = cliente20.getMail();
        int i25 = cliente14.compareTo(cliente20);
        java.lang.String str26 = cliente20.toString();
        int i27 = cliente5.compareTo(cliente20);
        Cliente cliente33 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str34 = cliente33.getMail();
        java.util.Set<Viagem> set_viagem35 = cliente33.getHistorico();
        Cliente cliente36 = cliente33.clone();
        java.lang.String str37 = cliente33.getMail();
        java.lang.String str38 = cliente33.getNome();
        boolean b39 = cliente20.equals((java.lang.Object) str38);
        java.lang.String str40 = cliente20.getMail();
        java.util.Set<Viagem> set_viagem41 = cliente20.getHistorico();
        Cliente cliente42 = new Cliente(cliente20);
        Cliente cliente43 = cliente20.clone();
        java.lang.String str44 = cliente20.getDataDeNascimento();
        java.util.GregorianCalendar gregorianCalendar45 = null;
        java.util.GregorianCalendar gregorianCalendar46 = null;
        try {
            java.util.List<Viagem> list_viagem47 = cliente20.viagensEntreDatas(gregorianCalendar45, gregorianCalendar46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem22);
        org.junit.Assert.assertNotNull(cliente23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str26.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue(i27 == 0);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem35);
        org.junit.Assert.assertNotNull(cliente36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
        org.junit.Assert.assertTrue(b39 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "hi!" + "'", str40.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem41);
        org.junit.Assert.assertNotNull(cliente43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "" + "'", str44.equals(""));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        Cliente cliente5 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "hi!", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        int i12 = cliente5.compareTo(cliente11);
        boolean b14 = cliente5.equals((java.lang.Object) (byte) 1);
        java.lang.String str15 = cliente5.getNome();
        Cliente cliente16 = new Cliente(cliente5);
        try {
            Viagem viagem17 = cliente16.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertTrue(i12 == (-35));
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        cliente5.setMS(10.0d);
        java.lang.String str9 = cliente5.getMail();
        java.lang.String str10 = cliente5.getMorada();
        java.lang.String str11 = cliente5.getNome();
        double d12 = cliente5.getMS();
        cliente5.setMS((double) 1L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue(d12 == 10.0d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        Cliente cliente5 = new Cliente("E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "");
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        Cliente cliente23 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente29 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str30 = cliente29.getMail();
        java.util.Set<Viagem> set_viagem31 = cliente29.getHistorico();
        Cliente cliente32 = cliente29.clone();
        java.lang.String str33 = cliente29.getMail();
        int i34 = cliente23.compareTo(cliente29);
        int i35 = cliente11.compareTo((Ator) cliente29);
        cliente11.setMS((double) 10L);
        cliente11.setMS(10.0d);
        java.lang.String str40 = cliente11.getNome();
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem31);
        org.junit.Assert.assertNotNull(cliente32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertTrue(i34 == 0);
        org.junit.Assert.assertTrue(i35 == 0);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "" + "'", str40.equals(""));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        java.util.Set<Viagem> set_viagem18 = cliente11.getHistorico();
        java.lang.String str19 = cliente11.getDataDeNascimento();
        boolean b21 = cliente11.equals((java.lang.Object) "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n");
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue(b21 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        java.util.Set<Viagem> set_viagem18 = cliente11.getHistorico();
        java.lang.String str19 = cliente11.toString();
        java.lang.String str20 = cliente11.getMail();
        Cliente cliente21 = new Cliente(cliente11);
        Cliente cliente27 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente33 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str34 = cliente33.getMail();
        java.util.Set<Viagem> set_viagem35 = cliente33.getHistorico();
        Cliente cliente36 = cliente33.clone();
        java.lang.String str37 = cliente33.getMail();
        int i38 = cliente27.compareTo(cliente33);
        java.lang.String str39 = cliente33.toString();
        java.util.Set<Viagem> set_viagem40 = cliente33.getHistorico();
        boolean b41 = cliente11.equals((java.lang.Object) set_viagem40);
        Cliente cliente42 = cliente11.clone();
        boolean b44 = cliente11.equals((java.lang.Object) 10);
        java.util.GregorianCalendar gregorianCalendar45 = null;
        java.util.GregorianCalendar gregorianCalendar46 = null;
        try {
            java.util.List<Viagem> list_viagem47 = cliente11.viagensEntreDatas(gregorianCalendar45, gregorianCalendar46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str19.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem35);
        org.junit.Assert.assertNotNull(cliente36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
        org.junit.Assert.assertTrue(i38 == 0);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str39.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem40);
        org.junit.Assert.assertTrue(b41 == false);
        org.junit.Assert.assertNotNull(cliente42);
        org.junit.Assert.assertTrue(b44 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        Cliente cliente10 = new Cliente("hi!", "", "", "hi!", "");
        java.util.Set<Viagem> set_viagem11 = cliente10.getHistorico();
        Cliente cliente13 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "hi!", "", set_viagem11, (double) 10.0f);
        Cliente cliente19 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str20 = cliente19.getMail();
        java.util.Set<Viagem> set_viagem21 = cliente19.getHistorico();
        Cliente cliente22 = cliente19.clone();
        java.lang.String str23 = cliente19.getMail();
        java.lang.String str24 = cliente19.getNome();
        int i25 = cliente13.compareTo((Ator) cliente19);
        cliente13.setMS((double) (-1.0f));
        Cliente cliente33 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente39 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str40 = cliente39.getMail();
        java.util.Set<Viagem> set_viagem41 = cliente39.getHistorico();
        Cliente cliente42 = cliente39.clone();
        java.lang.String str43 = cliente39.getMail();
        int i44 = cliente33.compareTo(cliente39);
        java.lang.String str45 = cliente39.toString();
        java.util.Set<Viagem> set_viagem46 = cliente39.getHistorico();
        java.lang.String str47 = cliente39.toString();
        java.lang.String str48 = cliente39.getMail();
        Cliente cliente49 = new Cliente(cliente39);
        cliente39.setMS((double) (short) 1);
        int i52 = cliente13.compareTo(cliente39);
        org.junit.Assert.assertNotNull(set_viagem11);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem21);
        org.junit.Assert.assertNotNull(cliente22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertTrue(i25 == (-35));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "hi!" + "'", str40.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem41);
        org.junit.Assert.assertNotNull(cliente42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "hi!" + "'", str43.equals("hi!"));
        org.junit.Assert.assertTrue(i44 == 0);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str45.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str47.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "hi!" + "'", str48.equals("hi!"));
        org.junit.Assert.assertTrue(i52 == (-35));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        Cliente cliente5 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "hi!", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        int i12 = cliente5.compareTo(cliente11);
        java.util.Set<Viagem> set_viagem13 = cliente5.getHistorico();
        java.lang.String str14 = cliente5.getDataDeNascimento();
        java.lang.String str15 = cliente5.getDataDeNascimento();
        org.junit.Assert.assertTrue(i12 == (-35));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str14.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str15.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        java.util.Set<Viagem> set_viagem18 = cliente11.getHistorico();
        java.lang.String str19 = cliente11.getDataDeNascimento();
        double d20 = cliente11.getMS();
        double d21 = cliente11.getMS();
        java.lang.String str22 = cliente11.getPassword();
        java.lang.String str23 = cliente11.getPassword();
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue(d20 == 0.0d);
        org.junit.Assert.assertTrue(d21 == 0.0d);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        cliente5.setMS((double) '4');
        double d12 = cliente5.getMS();
        java.lang.String str13 = cliente5.toString();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue(d12 == 52.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n" + "'", str13.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        java.util.Set<Viagem> set_viagem18 = cliente11.getHistorico();
        java.lang.String str19 = cliente11.getDataDeNascimento();
        double d20 = cliente11.getMS();
        double d21 = cliente11.getMS();
        java.lang.String str22 = cliente11.getPassword();
        Cliente cliente23 = cliente11.clone();
        Viagem viagem24 = null;
        try {
            cliente23.registaViagem(viagem24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue(d20 == 0.0d);
        org.junit.Assert.assertTrue(d21 == 0.0d);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNotNull(cliente23);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        Cliente cliente14 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente20 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str21 = cliente20.getMail();
        java.util.Set<Viagem> set_viagem22 = cliente20.getHistorico();
        Cliente cliente23 = cliente20.clone();
        java.lang.String str24 = cliente20.getMail();
        int i25 = cliente14.compareTo(cliente20);
        java.lang.String str26 = cliente20.toString();
        int i27 = cliente5.compareTo(cliente20);
        Cliente cliente28 = new Cliente(cliente20);
        java.lang.String str29 = cliente28.getMorada();
        boolean b31 = cliente28.equals((java.lang.Object) "");
        java.lang.Object obj32 = new java.lang.Object();
        boolean b33 = cliente28.equals(obj32);
        java.lang.String str34 = cliente28.getDataDeNascimento();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem22);
        org.junit.Assert.assertNotNull(cliente23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str26.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue(i27 == 0);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
        org.junit.Assert.assertTrue(b31 == false);
        org.junit.Assert.assertTrue(b33 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "" + "'", str34.equals(""));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        java.util.Set<Viagem> set_viagem18 = cliente11.getHistorico();
        java.lang.String str19 = cliente11.getDataDeNascimento();
        double d20 = cliente11.getMS();
        double d21 = cliente11.getMS();
        java.lang.String str22 = cliente11.getPassword();
        Cliente cliente23 = new Cliente(cliente11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue(d20 == 0.0d);
        org.junit.Assert.assertTrue(d21 == 0.0d);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        java.util.Set<Viagem> set_viagem18 = cliente11.getHistorico();
        java.lang.String str19 = cliente11.toString();
        java.lang.String str20 = cliente11.getMorada();
        java.lang.String str21 = cliente11.getNome();
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str19.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        Cliente cliente23 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente29 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str30 = cliente29.getMail();
        java.util.Set<Viagem> set_viagem31 = cliente29.getHistorico();
        Cliente cliente32 = cliente29.clone();
        java.lang.String str33 = cliente29.getMail();
        int i34 = cliente23.compareTo(cliente29);
        int i35 = cliente11.compareTo((Ator) cliente29);
        cliente11.setMS(0.0d);
        java.lang.String str38 = cliente11.getNome();
        java.lang.String str39 = cliente11.toString();
        java.lang.String str40 = cliente11.getMorada();
        Cliente cliente46 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str47 = cliente46.getMail();
        cliente46.setMS(10.0d);
        java.util.Set<Viagem> set_viagem50 = cliente46.getHistorico();
        int i51 = cliente11.compareTo(cliente46);
        try {
            Viagem viagem52 = cliente46.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem31);
        org.junit.Assert.assertNotNull(cliente32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertTrue(i34 == 0);
        org.junit.Assert.assertTrue(i35 == 0);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str39.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "hi!" + "'", str40.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "hi!" + "'", str47.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem50);
        org.junit.Assert.assertTrue(i51 == (-1));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        Cliente cliente23 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente29 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str30 = cliente29.getMail();
        java.util.Set<Viagem> set_viagem31 = cliente29.getHistorico();
        Cliente cliente32 = cliente29.clone();
        java.lang.String str33 = cliente29.getMail();
        int i34 = cliente23.compareTo(cliente29);
        int i35 = cliente11.compareTo((Ator) cliente29);
        cliente11.setMS(0.0d);
        cliente11.setMS((double) (byte) 10);
        Viagem viagem40 = null;
        try {
            cliente11.registaViagem(viagem40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem31);
        org.junit.Assert.assertNotNull(cliente32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertTrue(i34 == 0);
        org.junit.Assert.assertTrue(i35 == 0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        Cliente cliente5 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "hi!", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n");
        Viagem viagem6 = null;
        try {
            cliente5.registaViagem(viagem6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        java.lang.String str10 = cliente5.getNome();
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente22 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str23 = cliente22.getMail();
        java.util.Set<Viagem> set_viagem24 = cliente22.getHistorico();
        Cliente cliente25 = cliente22.clone();
        java.lang.String str26 = cliente22.getMail();
        int i27 = cliente16.compareTo(cliente22);
        java.lang.String str28 = cliente22.toString();
        Cliente cliente34 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente40 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str41 = cliente40.getMail();
        java.util.Set<Viagem> set_viagem42 = cliente40.getHistorico();
        Cliente cliente43 = cliente40.clone();
        java.lang.String str44 = cliente40.getMail();
        int i45 = cliente34.compareTo(cliente40);
        int i46 = cliente22.compareTo((Ator) cliente40);
        cliente22.setMS((double) 10L);
        int i49 = cliente5.compareTo((Ator) cliente22);
        java.lang.String str50 = cliente22.getMail();
        Cliente cliente51 = cliente22.clone();
        try {
            Viagem viagem52 = cliente22.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem24);
        org.junit.Assert.assertNotNull(cliente25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
        org.junit.Assert.assertTrue(i27 == 0);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str28.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "hi!" + "'", str41.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem42);
        org.junit.Assert.assertNotNull(cliente43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "hi!" + "'", str44.equals("hi!"));
        org.junit.Assert.assertTrue(i45 == 0);
        org.junit.Assert.assertTrue(i46 == 0);
        org.junit.Assert.assertTrue(i49 == 0);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "hi!" + "'", str50.equals("hi!"));
        org.junit.Assert.assertNotNull(cliente51);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        Cliente cliente5 = new Cliente("", "", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "");
        java.util.GregorianCalendar gregorianCalendar6 = null;
        java.util.GregorianCalendar gregorianCalendar7 = null;
        try {
            java.util.List<Viagem> list_viagem8 = cliente5.viagensEntreDatas(gregorianCalendar6, gregorianCalendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        java.lang.String str18 = cliente11.getNome();
        try {
            Viagem viagem19 = cliente11.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        Cliente cliente14 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente20 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str21 = cliente20.getMail();
        java.util.Set<Viagem> set_viagem22 = cliente20.getHistorico();
        Cliente cliente23 = cliente20.clone();
        java.lang.String str24 = cliente20.getMail();
        int i25 = cliente14.compareTo(cliente20);
        java.lang.String str26 = cliente20.toString();
        int i27 = cliente5.compareTo(cliente20);
        Cliente cliente33 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str34 = cliente33.getMail();
        java.util.Set<Viagem> set_viagem35 = cliente33.getHistorico();
        Cliente cliente36 = cliente33.clone();
        java.lang.String str37 = cliente33.getMail();
        java.lang.String str38 = cliente33.getNome();
        boolean b39 = cliente20.equals((java.lang.Object) str38);
        java.lang.String str40 = cliente20.getMail();
        java.util.Set<Viagem> set_viagem41 = cliente20.getHistorico();
        Cliente cliente42 = new Cliente(cliente20);
        Cliente cliente43 = cliente20.clone();
        java.lang.String str44 = cliente43.toString();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem22);
        org.junit.Assert.assertNotNull(cliente23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str26.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue(i27 == 0);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem35);
        org.junit.Assert.assertNotNull(cliente36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
        org.junit.Assert.assertTrue(b39 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "hi!" + "'", str40.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem41);
        org.junit.Assert.assertNotNull(cliente43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str44.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        Cliente cliente5 = new Cliente("E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: \nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: \nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: \nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n");
        java.lang.String str6 = cliente5.getPassword();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: \nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str6.equals("E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: \nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        Cliente cliente5 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "hi!", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        int i12 = cliente5.compareTo(cliente11);
        java.util.Set<Viagem> set_viagem13 = cliente5.getHistorico();
        java.lang.String str14 = cliente5.getDataDeNascimento();
        Cliente cliente20 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente26 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str27 = cliente26.getMail();
        java.util.Set<Viagem> set_viagem28 = cliente26.getHistorico();
        Cliente cliente29 = cliente26.clone();
        java.lang.String str30 = cliente26.getMail();
        int i31 = cliente20.compareTo(cliente26);
        java.lang.String str32 = cliente26.toString();
        Cliente cliente38 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente44 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str45 = cliente44.getMail();
        java.util.Set<Viagem> set_viagem46 = cliente44.getHistorico();
        Cliente cliente47 = cliente44.clone();
        java.lang.String str48 = cliente44.getMail();
        int i49 = cliente38.compareTo(cliente44);
        int i50 = cliente26.compareTo((Ator) cliente44);
        cliente26.setMS(0.0d);
        int i53 = cliente5.compareTo((Ator) cliente26);
        org.junit.Assert.assertTrue(i12 == (-35));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str14.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "hi!" + "'", str27.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem28);
        org.junit.Assert.assertNotNull(cliente29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertTrue(i31 == 0);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str32.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "hi!" + "'", str45.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem46);
        org.junit.Assert.assertNotNull(cliente47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "hi!" + "'", str48.equals("hi!"));
        org.junit.Assert.assertTrue(i49 == 0);
        org.junit.Assert.assertTrue(i50 == 0);
        org.junit.Assert.assertTrue(i53 == (-35));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        Cliente cliente0 = new Cliente();
        java.lang.String str1 = cliente0.getPassword();
        Cliente cliente7 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str8 = cliente7.getMail();
        java.util.Set<Viagem> set_viagem9 = cliente7.getHistorico();
        Cliente cliente10 = cliente7.clone();
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente22 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str23 = cliente22.getMail();
        java.util.Set<Viagem> set_viagem24 = cliente22.getHistorico();
        Cliente cliente25 = cliente22.clone();
        java.lang.String str26 = cliente22.getMail();
        int i27 = cliente16.compareTo(cliente22);
        java.lang.String str28 = cliente22.toString();
        int i29 = cliente7.compareTo(cliente22);
        double d30 = cliente22.getMS();
        double d31 = cliente22.getMS();
        int i32 = cliente0.compareTo((Ator) cliente22);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem9);
        org.junit.Assert.assertNotNull(cliente10);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem24);
        org.junit.Assert.assertNotNull(cliente25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
        org.junit.Assert.assertTrue(i27 == 0);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str28.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue(i29 == 0);
        org.junit.Assert.assertTrue(d30 == 0.0d);
        org.junit.Assert.assertTrue(d31 == 0.0d);
        org.junit.Assert.assertTrue(i32 == (-3));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente8.toString();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str9.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        cliente5.setMS(10.0d);
        java.lang.String str9 = cliente5.getMail();
        java.lang.String str10 = cliente5.getNome();
        java.lang.String str11 = cliente5.getPassword();
        java.lang.String str12 = cliente5.getDataDeNascimento();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        Cliente cliente5 = new Cliente("", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "hi!");
        java.util.GregorianCalendar gregorianCalendar6 = null;
        java.util.GregorianCalendar gregorianCalendar7 = null;
        try {
            java.util.List<Viagem> list_viagem8 = cliente5.viagensEntreDatas(gregorianCalendar6, gregorianCalendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        try {
            Viagem viagem8 = cliente5.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        java.lang.String str10 = cliente5.getNome();
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente22 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str23 = cliente22.getMail();
        java.util.Set<Viagem> set_viagem24 = cliente22.getHistorico();
        Cliente cliente25 = cliente22.clone();
        java.lang.String str26 = cliente22.getMail();
        int i27 = cliente16.compareTo(cliente22);
        java.lang.String str28 = cliente22.toString();
        Cliente cliente34 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente40 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str41 = cliente40.getMail();
        java.util.Set<Viagem> set_viagem42 = cliente40.getHistorico();
        Cliente cliente43 = cliente40.clone();
        java.lang.String str44 = cliente40.getMail();
        int i45 = cliente34.compareTo(cliente40);
        int i46 = cliente22.compareTo((Ator) cliente40);
        cliente22.setMS((double) 10L);
        int i49 = cliente5.compareTo((Ator) cliente22);
        java.lang.String str50 = cliente22.getNome();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem24);
        org.junit.Assert.assertNotNull(cliente25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
        org.junit.Assert.assertTrue(i27 == 0);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str28.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "hi!" + "'", str41.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem42);
        org.junit.Assert.assertNotNull(cliente43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "hi!" + "'", str44.equals("hi!"));
        org.junit.Assert.assertTrue(i45 == 0);
        org.junit.Assert.assertTrue(i46 == 0);
        org.junit.Assert.assertTrue(i49 == 0);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "" + "'", str50.equals(""));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        java.util.Set<Viagem> set_viagem18 = cliente11.getHistorico();
        java.util.Set<Viagem> set_viagem19 = cliente11.getHistorico();
        java.lang.String str20 = cliente11.getNome();
        java.lang.String str21 = cliente11.getDataDeNascimento();
        java.util.Set<Viagem> set_viagem22 = cliente11.getHistorico();
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem18);
        org.junit.Assert.assertNotNull(set_viagem19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertNotNull(set_viagem22);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        Cliente cliente5 = new Cliente("", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "hi!", "");
        Cliente cliente6 = cliente5.clone();
        org.junit.Assert.assertNotNull(cliente6);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        java.util.Set<Viagem> set_viagem18 = cliente11.getHistorico();
        java.lang.String str19 = cliente11.getDataDeNascimento();
        double d20 = cliente11.getMS();
        try {
            Viagem viagem21 = cliente11.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue(d20 == 0.0d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        Cliente cliente5 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "hi!", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "hi!");
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        Cliente cliente5 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "hi!", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        int i12 = cliente5.compareTo(cliente11);
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        java.util.Set<Viagem> set_viagem14 = cliente11.getHistorico();
        java.lang.String str15 = cliente11.getDataDeNascimento();
        org.junit.Assert.assertTrue(i12 == (-35));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(set_viagem14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        Cliente cliente5 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "", "hi!", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n");
        java.lang.String str6 = cliente5.getDataDeNascimento();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str6.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        Cliente cliente0 = new Cliente();
        java.lang.String str1 = cliente0.getPassword();
        cliente0.setMS((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        Cliente cliente14 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente20 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str21 = cliente20.getMail();
        java.util.Set<Viagem> set_viagem22 = cliente20.getHistorico();
        Cliente cliente23 = cliente20.clone();
        java.lang.String str24 = cliente20.getMail();
        int i25 = cliente14.compareTo(cliente20);
        java.lang.String str26 = cliente20.toString();
        int i27 = cliente5.compareTo(cliente20);
        Cliente cliente33 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str34 = cliente33.getMail();
        java.util.Set<Viagem> set_viagem35 = cliente33.getHistorico();
        Cliente cliente36 = cliente33.clone();
        java.lang.String str37 = cliente33.getMail();
        java.lang.String str38 = cliente33.getNome();
        boolean b39 = cliente20.equals((java.lang.Object) str38);
        java.lang.String str40 = cliente20.getMail();
        cliente20.setMS(52.0d);
        java.lang.String str43 = cliente20.getNome();
        java.lang.String str44 = cliente20.getMail();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem22);
        org.junit.Assert.assertNotNull(cliente23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str26.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue(i27 == 0);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem35);
        org.junit.Assert.assertNotNull(cliente36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
        org.junit.Assert.assertTrue(b39 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "hi!" + "'", str40.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "" + "'", str43.equals(""));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "hi!" + "'", str44.equals("hi!"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        Cliente cliente5 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "hi!", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        int i12 = cliente5.compareTo(cliente11);
        boolean b14 = cliente5.equals((java.lang.Object) (byte) 1);
        java.lang.String str15 = cliente5.getNome();
        Cliente cliente16 = new Cliente(cliente5);
        double d17 = cliente5.getMS();
        org.junit.Assert.assertTrue(i12 == (-35));
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(d17 == 0.0d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        java.util.Set<Viagem> set_viagem18 = cliente11.getHistorico();
        java.lang.String str19 = cliente11.getDataDeNascimento();
        double d20 = cliente11.getMS();
        Cliente cliente26 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente32 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str33 = cliente32.getMail();
        java.util.Set<Viagem> set_viagem34 = cliente32.getHistorico();
        Cliente cliente35 = cliente32.clone();
        java.lang.String str36 = cliente32.getMail();
        int i37 = cliente26.compareTo(cliente32);
        java.lang.String str38 = cliente32.toString();
        Cliente cliente44 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente50 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str51 = cliente50.getMail();
        java.util.Set<Viagem> set_viagem52 = cliente50.getHistorico();
        Cliente cliente53 = cliente50.clone();
        java.lang.String str54 = cliente50.getMail();
        int i55 = cliente44.compareTo(cliente50);
        int i56 = cliente32.compareTo((Ator) cliente50);
        cliente32.setMS(0.0d);
        java.lang.String str59 = cliente32.getNome();
        int i60 = cliente11.compareTo((Ator) cliente32);
        Cliente cliente61 = cliente11.clone();
        java.lang.String str62 = cliente61.getMorada();
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue(d20 == 0.0d);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem34);
        org.junit.Assert.assertNotNull(cliente35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertTrue(i37 == 0);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str38.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "hi!" + "'", str51.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem52);
        org.junit.Assert.assertNotNull(cliente53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "hi!" + "'", str54.equals("hi!"));
        org.junit.Assert.assertTrue(i55 == 0);
        org.junit.Assert.assertTrue(i56 == 0);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "" + "'", str59.equals(""));
        org.junit.Assert.assertTrue(i60 == 0);
        org.junit.Assert.assertNotNull(cliente61);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "hi!" + "'", str62.equals("hi!"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        Cliente cliente10 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str17 = cliente16.getMail();
        java.util.Set<Viagem> set_viagem18 = cliente16.getHistorico();
        Cliente cliente19 = cliente16.clone();
        java.lang.String str20 = cliente16.getMail();
        int i21 = cliente10.compareTo(cliente16);
        java.lang.String str22 = cliente16.toString();
        java.util.Set<Viagem> set_viagem23 = cliente16.getHistorico();
        java.util.Set<Viagem> set_viagem24 = cliente16.getHistorico();
        Cliente cliente26 = new Cliente("", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: \nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: \nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", set_viagem24, (double) 10.0f);
        java.lang.String str27 = cliente26.getDataDeNascimento();
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem18);
        org.junit.Assert.assertNotNull(cliente19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertTrue(i21 == 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str22.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem23);
        org.junit.Assert.assertNotNull(set_viagem24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str27.equals("E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        Cliente cliente5 = new Cliente("", "", "E-mail: \nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: \nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n");
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        cliente5.setMS(10.0d);
        java.lang.String str9 = cliente5.getMail();
        java.lang.String str10 = cliente5.getNome();
        java.lang.String str11 = cliente5.getPassword();
        java.lang.Object obj12 = null;
        boolean b13 = cliente5.equals(obj12);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue(b13 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        Cliente cliente14 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente20 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str21 = cliente20.getMail();
        java.util.Set<Viagem> set_viagem22 = cliente20.getHistorico();
        Cliente cliente23 = cliente20.clone();
        java.lang.String str24 = cliente20.getMail();
        int i25 = cliente14.compareTo(cliente20);
        java.lang.String str26 = cliente20.toString();
        int i27 = cliente5.compareTo(cliente20);
        Cliente cliente28 = new Cliente(cliente20);
        Cliente cliente29 = new Cliente(cliente28);
        java.lang.String str30 = cliente29.getDataDeNascimento();
        double d31 = cliente29.getMS();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem22);
        org.junit.Assert.assertNotNull(cliente23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str26.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue(i27 == 0);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "" + "'", str30.equals(""));
        org.junit.Assert.assertTrue(d31 == 0.0d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        Cliente cliente23 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente29 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str30 = cliente29.getMail();
        java.util.Set<Viagem> set_viagem31 = cliente29.getHistorico();
        Cliente cliente32 = cliente29.clone();
        java.lang.String str33 = cliente29.getMail();
        int i34 = cliente23.compareTo(cliente29);
        int i35 = cliente11.compareTo((Ator) cliente29);
        Cliente cliente41 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str42 = cliente41.getMail();
        java.util.Set<Viagem> set_viagem43 = cliente41.getHistorico();
        Cliente cliente44 = cliente41.clone();
        int i45 = cliente11.compareTo(cliente41);
        java.lang.String str46 = cliente41.getMail();
        java.util.GregorianCalendar gregorianCalendar47 = null;
        java.util.GregorianCalendar gregorianCalendar48 = null;
        try {
            java.util.List<Viagem> list_viagem49 = cliente41.viagensEntreDatas(gregorianCalendar47, gregorianCalendar48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem31);
        org.junit.Assert.assertNotNull(cliente32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertTrue(i34 == 0);
        org.junit.Assert.assertTrue(i35 == 0);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "hi!" + "'", str42.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem43);
        org.junit.Assert.assertNotNull(cliente44);
        org.junit.Assert.assertTrue(i45 == 0);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "hi!" + "'", str46.equals("hi!"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        Cliente cliente5 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "", "hi!", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n");
        double d6 = cliente5.getMS();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertNotNull(set_viagem7);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        cliente5.setMS(10.0d);
        java.lang.String str9 = cliente5.getMail();
        java.lang.String str10 = cliente5.getMorada();
        java.lang.String str11 = cliente5.getNome();
        double d12 = cliente5.getMS();
        java.util.Set<Viagem> set_viagem13 = cliente5.getHistorico();
        try {
            Viagem viagem14 = cliente5.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue(d12 == 10.0d);
        org.junit.Assert.assertNotNull(set_viagem13);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        Cliente cliente23 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente29 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str30 = cliente29.getMail();
        java.util.Set<Viagem> set_viagem31 = cliente29.getHistorico();
        Cliente cliente32 = cliente29.clone();
        java.lang.String str33 = cliente29.getMail();
        int i34 = cliente23.compareTo(cliente29);
        int i35 = cliente11.compareTo((Ator) cliente29);
        cliente11.setMS((double) 10L);
        java.lang.String str38 = cliente11.getDataDeNascimento();
        java.util.Set<Viagem> set_viagem39 = cliente11.getHistorico();
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem31);
        org.junit.Assert.assertNotNull(cliente32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertTrue(i34 == 0);
        org.junit.Assert.assertTrue(i35 == 0);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
        org.junit.Assert.assertNotNull(set_viagem39);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        java.util.Set<Viagem> set_viagem18 = cliente11.getHistorico();
        java.lang.String str19 = cliente11.toString();
        java.lang.String str20 = cliente11.getMail();
        Cliente cliente21 = new Cliente(cliente11);
        Cliente cliente27 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente33 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str34 = cliente33.getMail();
        java.util.Set<Viagem> set_viagem35 = cliente33.getHistorico();
        Cliente cliente36 = cliente33.clone();
        java.lang.String str37 = cliente33.getMail();
        int i38 = cliente27.compareTo(cliente33);
        java.lang.String str39 = cliente33.toString();
        java.util.Set<Viagem> set_viagem40 = cliente33.getHistorico();
        boolean b41 = cliente11.equals((java.lang.Object) set_viagem40);
        Cliente cliente42 = cliente11.clone();
        java.lang.String str43 = cliente11.getNome();
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str19.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem35);
        org.junit.Assert.assertNotNull(cliente36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
        org.junit.Assert.assertTrue(i38 == 0);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str39.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem40);
        org.junit.Assert.assertTrue(b41 == false);
        org.junit.Assert.assertNotNull(cliente42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "" + "'", str43.equals(""));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        Cliente cliente5 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "hi!", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        int i12 = cliente5.compareTo(cliente11);
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        cliente11.setMS((double) (-1.0f));
        org.junit.Assert.assertTrue(i12 == (-35));
        org.junit.Assert.assertNotNull(set_viagem13);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        java.util.Set<Viagem> set_viagem18 = cliente11.getHistorico();
        java.lang.String str19 = cliente11.getDataDeNascimento();
        double d20 = cliente11.getMS();
        Cliente cliente26 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente32 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str33 = cliente32.getMail();
        java.util.Set<Viagem> set_viagem34 = cliente32.getHistorico();
        Cliente cliente35 = cliente32.clone();
        java.lang.String str36 = cliente32.getMail();
        int i37 = cliente26.compareTo(cliente32);
        java.lang.String str38 = cliente32.toString();
        Cliente cliente44 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente50 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str51 = cliente50.getMail();
        java.util.Set<Viagem> set_viagem52 = cliente50.getHistorico();
        Cliente cliente53 = cliente50.clone();
        java.lang.String str54 = cliente50.getMail();
        int i55 = cliente44.compareTo(cliente50);
        int i56 = cliente32.compareTo((Ator) cliente50);
        cliente32.setMS(0.0d);
        java.lang.String str59 = cliente32.getNome();
        int i60 = cliente11.compareTo((Ator) cliente32);
        Cliente cliente61 = cliente11.clone();
        Cliente cliente62 = cliente61.clone();
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue(d20 == 0.0d);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem34);
        org.junit.Assert.assertNotNull(cliente35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertTrue(i37 == 0);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str38.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "hi!" + "'", str51.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem52);
        org.junit.Assert.assertNotNull(cliente53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "hi!" + "'", str54.equals("hi!"));
        org.junit.Assert.assertTrue(i55 == 0);
        org.junit.Assert.assertTrue(i56 == 0);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "" + "'", str59.equals(""));
        org.junit.Assert.assertTrue(i60 == 0);
        org.junit.Assert.assertNotNull(cliente61);
        org.junit.Assert.assertNotNull(cliente62);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        Cliente cliente5 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "hi!", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        int i12 = cliente5.compareTo(cliente11);
        Cliente cliente18 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente24 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str25 = cliente24.getMail();
        java.util.Set<Viagem> set_viagem26 = cliente24.getHistorico();
        Cliente cliente27 = cliente24.clone();
        java.lang.String str28 = cliente24.getMail();
        int i29 = cliente18.compareTo(cliente24);
        java.lang.String str30 = cliente24.toString();
        Cliente cliente36 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente42 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str43 = cliente42.getMail();
        java.util.Set<Viagem> set_viagem44 = cliente42.getHistorico();
        Cliente cliente45 = cliente42.clone();
        java.lang.String str46 = cliente42.getMail();
        int i47 = cliente36.compareTo(cliente42);
        int i48 = cliente24.compareTo((Ator) cliente42);
        cliente24.setMS(0.0d);
        cliente24.setMS((double) (byte) 10);
        java.lang.String str53 = cliente24.getNome();
        int i54 = cliente5.compareTo(cliente24);
        java.lang.Object obj55 = null;
        boolean b56 = cliente24.equals(obj55);
        org.junit.Assert.assertTrue(i12 == (-35));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem26);
        org.junit.Assert.assertNotNull(cliente27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "hi!" + "'", str28.equals("hi!"));
        org.junit.Assert.assertTrue(i29 == 0);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str30.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "hi!" + "'", str43.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem44);
        org.junit.Assert.assertNotNull(cliente45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "hi!" + "'", str46.equals("hi!"));
        org.junit.Assert.assertTrue(i47 == 0);
        org.junit.Assert.assertTrue(i48 == 0);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "" + "'", str53.equals(""));
        org.junit.Assert.assertTrue(i54 == (-35));
        org.junit.Assert.assertTrue(b56 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        Cliente cliente23 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente29 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str30 = cliente29.getMail();
        java.util.Set<Viagem> set_viagem31 = cliente29.getHistorico();
        Cliente cliente32 = cliente29.clone();
        java.lang.String str33 = cliente29.getMail();
        int i34 = cliente23.compareTo(cliente29);
        int i35 = cliente11.compareTo((Ator) cliente29);
        Cliente cliente36 = cliente11.clone();
        Cliente cliente37 = null;
        try {
            int i38 = cliente11.compareTo(cliente37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem31);
        org.junit.Assert.assertNotNull(cliente32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertTrue(i34 == 0);
        org.junit.Assert.assertTrue(i35 == 0);
        org.junit.Assert.assertNotNull(cliente36);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        Cliente cliente5 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "hi!", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        int i12 = cliente5.compareTo(cliente11);
        java.lang.String str13 = cliente5.getMorada();
        Cliente cliente19 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "", "", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "hi!");
        double d20 = cliente19.getMS();
        int i21 = cliente5.compareTo((Ator) cliente19);
        java.lang.String str22 = cliente19.getNome();
        java.util.Set<Viagem> set_viagem23 = cliente19.getHistorico();
        org.junit.Assert.assertTrue(i12 == (-35));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n" + "'", str13.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n"));
        org.junit.Assert.assertTrue(d20 == 0.0d);
        org.junit.Assert.assertTrue(i21 == (-5));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNotNull(set_viagem23);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        Cliente cliente10 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str17 = cliente16.getMail();
        java.util.Set<Viagem> set_viagem18 = cliente16.getHistorico();
        Cliente cliente19 = cliente16.clone();
        java.lang.String str20 = cliente16.getMail();
        int i21 = cliente10.compareTo(cliente16);
        java.lang.String str22 = cliente16.toString();
        java.util.Set<Viagem> set_viagem23 = cliente16.getHistorico();
        java.util.Set<Viagem> set_viagem24 = cliente16.getHistorico();
        Cliente cliente26 = new Cliente("", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: \nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: \nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", set_viagem24, (double) 10.0f);
        Cliente cliente32 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente38 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str39 = cliente38.getMail();
        java.util.Set<Viagem> set_viagem40 = cliente38.getHistorico();
        Cliente cliente41 = cliente38.clone();
        java.lang.String str42 = cliente38.getMail();
        int i43 = cliente32.compareTo(cliente38);
        java.lang.String str44 = cliente38.toString();
        Cliente cliente50 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente56 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str57 = cliente56.getMail();
        java.util.Set<Viagem> set_viagem58 = cliente56.getHistorico();
        Cliente cliente59 = cliente56.clone();
        java.lang.String str60 = cliente56.getMail();
        int i61 = cliente50.compareTo(cliente56);
        int i62 = cliente38.compareTo((Ator) cliente56);
        cliente38.setMS(0.0d);
        cliente38.setMS((double) (byte) 10);
        int i67 = cliente26.compareTo(cliente38);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem18);
        org.junit.Assert.assertNotNull(cliente19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertTrue(i21 == 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str22.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem23);
        org.junit.Assert.assertNotNull(set_viagem24);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "hi!" + "'", str39.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem40);
        org.junit.Assert.assertNotNull(cliente41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "hi!" + "'", str42.equals("hi!"));
        org.junit.Assert.assertTrue(i43 == 0);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str44.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "hi!" + "'", str57.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem58);
        org.junit.Assert.assertNotNull(cliente59);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "hi!" + "'", str60.equals("hi!"));
        org.junit.Assert.assertTrue(i61 == 0);
        org.junit.Assert.assertTrue(i62 == 0);
        org.junit.Assert.assertTrue(i67 == (-3));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        Cliente cliente10 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str17 = cliente16.getMail();
        java.util.Set<Viagem> set_viagem18 = cliente16.getHistorico();
        Cliente cliente19 = cliente16.clone();
        java.lang.String str20 = cliente16.getMail();
        int i21 = cliente10.compareTo(cliente16);
        java.lang.String str22 = cliente16.toString();
        Cliente cliente28 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente34 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str35 = cliente34.getMail();
        java.util.Set<Viagem> set_viagem36 = cliente34.getHistorico();
        Cliente cliente37 = cliente34.clone();
        java.lang.String str38 = cliente34.getMail();
        int i39 = cliente28.compareTo(cliente34);
        int i40 = cliente16.compareTo((Ator) cliente34);
        cliente16.setMS(0.0d);
        java.lang.String str43 = cliente16.getNome();
        java.lang.String str44 = cliente16.getPassword();
        java.util.Set<Viagem> set_viagem45 = cliente16.getHistorico();
        Cliente cliente47 = new Cliente("E-mail: \nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: \nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: \nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: \nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", set_viagem45, (-1.0d));
        Viagem viagem48 = null;
        try {
            cliente47.registaViagem(viagem48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem18);
        org.junit.Assert.assertNotNull(cliente19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertTrue(i21 == 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str22.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!" + "'", str35.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem36);
        org.junit.Assert.assertNotNull(cliente37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "hi!" + "'", str38.equals("hi!"));
        org.junit.Assert.assertTrue(i39 == 0);
        org.junit.Assert.assertTrue(i40 == 0);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "" + "'", str43.equals(""));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "" + "'", str44.equals(""));
        org.junit.Assert.assertNotNull(set_viagem45);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        Cliente cliente23 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente29 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str30 = cliente29.getMail();
        java.util.Set<Viagem> set_viagem31 = cliente29.getHistorico();
        Cliente cliente32 = cliente29.clone();
        java.lang.String str33 = cliente29.getMail();
        int i34 = cliente23.compareTo(cliente29);
        int i35 = cliente11.compareTo((Ator) cliente29);
        cliente11.setMS(0.0d);
        java.lang.String str38 = cliente11.getNome();
        java.lang.String str39 = cliente11.toString();
        java.lang.String str40 = cliente11.getMorada();
        java.util.GregorianCalendar gregorianCalendar41 = null;
        java.util.GregorianCalendar gregorianCalendar42 = null;
        try {
            java.util.List<Viagem> list_viagem43 = cliente11.viagensEntreDatas(gregorianCalendar41, gregorianCalendar42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem31);
        org.junit.Assert.assertNotNull(cliente32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertTrue(i34 == 0);
        org.junit.Assert.assertTrue(i35 == 0);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str39.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "hi!" + "'", str40.equals("hi!"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        java.util.Set<Viagem> set_viagem18 = cliente11.getHistorico();
        java.lang.String str19 = cliente11.getDataDeNascimento();
        double d20 = cliente11.getMS();
        Cliente cliente26 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente32 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str33 = cliente32.getMail();
        java.util.Set<Viagem> set_viagem34 = cliente32.getHistorico();
        Cliente cliente35 = cliente32.clone();
        java.lang.String str36 = cliente32.getMail();
        int i37 = cliente26.compareTo(cliente32);
        java.lang.String str38 = cliente32.toString();
        Cliente cliente44 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente50 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str51 = cliente50.getMail();
        java.util.Set<Viagem> set_viagem52 = cliente50.getHistorico();
        Cliente cliente53 = cliente50.clone();
        java.lang.String str54 = cliente50.getMail();
        int i55 = cliente44.compareTo(cliente50);
        int i56 = cliente32.compareTo((Ator) cliente50);
        cliente32.setMS(0.0d);
        java.lang.String str59 = cliente32.getNome();
        int i60 = cliente11.compareTo((Ator) cliente32);
        java.lang.String str61 = cliente11.getPassword();
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue(d20 == 0.0d);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem34);
        org.junit.Assert.assertNotNull(cliente35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertTrue(i37 == 0);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str38.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "hi!" + "'", str51.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem52);
        org.junit.Assert.assertNotNull(cliente53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "hi!" + "'", str54.equals("hi!"));
        org.junit.Assert.assertTrue(i55 == 0);
        org.junit.Assert.assertTrue(i56 == 0);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "" + "'", str59.equals(""));
        org.junit.Assert.assertTrue(i60 == 0);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "" + "'", str61.equals(""));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        Cliente cliente5 = new Cliente("E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "hi!", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n");
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        java.util.Set<Viagem> set_viagem18 = cliente11.getHistorico();
        java.util.Set<Viagem> set_viagem19 = cliente11.getHistorico();
        java.util.GregorianCalendar gregorianCalendar20 = null;
        java.util.GregorianCalendar gregorianCalendar21 = null;
        try {
            java.util.List<Viagem> list_viagem22 = cliente11.viagensEntreDatas(gregorianCalendar20, gregorianCalendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem18);
        org.junit.Assert.assertNotNull(set_viagem19);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        Cliente cliente0 = new Cliente();
        Cliente cliente1 = cliente0.clone();
        Cliente cliente7 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente13 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str14 = cliente13.getMail();
        java.util.Set<Viagem> set_viagem15 = cliente13.getHistorico();
        Cliente cliente16 = cliente13.clone();
        java.lang.String str17 = cliente13.getMail();
        int i18 = cliente7.compareTo(cliente13);
        java.lang.String str19 = cliente13.toString();
        Cliente cliente25 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente31 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str32 = cliente31.getMail();
        java.util.Set<Viagem> set_viagem33 = cliente31.getHistorico();
        Cliente cliente34 = cliente31.clone();
        java.lang.String str35 = cliente31.getMail();
        int i36 = cliente25.compareTo(cliente31);
        int i37 = cliente13.compareTo((Ator) cliente31);
        Cliente cliente43 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str44 = cliente43.getMail();
        java.util.Set<Viagem> set_viagem45 = cliente43.getHistorico();
        Cliente cliente46 = cliente43.clone();
        int i47 = cliente13.compareTo(cliente43);
        Cliente cliente53 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente59 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str60 = cliente59.getMail();
        java.util.Set<Viagem> set_viagem61 = cliente59.getHistorico();
        Cliente cliente62 = cliente59.clone();
        java.lang.String str63 = cliente59.getMail();
        int i64 = cliente53.compareTo(cliente59);
        java.lang.String str65 = cliente59.toString();
        Cliente cliente71 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente77 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str78 = cliente77.getMail();
        java.util.Set<Viagem> set_viagem79 = cliente77.getHistorico();
        Cliente cliente80 = cliente77.clone();
        java.lang.String str81 = cliente77.getMail();
        int i82 = cliente71.compareTo(cliente77);
        int i83 = cliente59.compareTo((Ator) cliente77);
        Cliente cliente89 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str90 = cliente89.getMail();
        java.util.Set<Viagem> set_viagem91 = cliente89.getHistorico();
        Cliente cliente92 = cliente89.clone();
        int i93 = cliente59.compareTo(cliente89);
        java.lang.String str94 = cliente89.getMail();
        java.lang.String str95 = cliente89.toString();
        int i96 = cliente43.compareTo(cliente89);
        Cliente cliente97 = new Cliente(cliente89);
        java.lang.String str98 = cliente97.getMail();
        int i99 = cliente1.compareTo((Ator) cliente97);
        org.junit.Assert.assertNotNull(cliente1);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem15);
        org.junit.Assert.assertNotNull(cliente16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertTrue(i18 == 0);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str19.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "hi!" + "'", str32.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem33);
        org.junit.Assert.assertNotNull(cliente34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!" + "'", str35.equals("hi!"));
        org.junit.Assert.assertTrue(i36 == 0);
        org.junit.Assert.assertTrue(i37 == 0);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "hi!" + "'", str44.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem45);
        org.junit.Assert.assertNotNull(cliente46);
        org.junit.Assert.assertTrue(i47 == 0);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "hi!" + "'", str60.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem61);
        org.junit.Assert.assertNotNull(cliente62);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "hi!" + "'", str63.equals("hi!"));
        org.junit.Assert.assertTrue(i64 == 0);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str65.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "hi!" + "'", str78.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem79);
        org.junit.Assert.assertNotNull(cliente80);
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "hi!" + "'", str81.equals("hi!"));
        org.junit.Assert.assertTrue(i82 == 0);
        org.junit.Assert.assertTrue(i83 == 0);
        org.junit.Assert.assertTrue("'" + str90 + "' != '" + "hi!" + "'", str90.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem91);
        org.junit.Assert.assertNotNull(cliente92);
        org.junit.Assert.assertTrue(i93 == 0);
        org.junit.Assert.assertTrue("'" + str94 + "' != '" + "hi!" + "'", str94.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str95 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str95.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue(i96 == 0);
        org.junit.Assert.assertTrue("'" + str98 + "' != '" + "hi!" + "'", str98.equals("hi!"));
        org.junit.Assert.assertTrue(i99 == (-3));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        Cliente cliente10 = new Cliente("hi!", "", "", "hi!", "");
        java.util.Set<Viagem> set_viagem11 = cliente10.getHistorico();
        Cliente cliente13 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "hi!", "", set_viagem11, (double) 10.0f);
        Cliente cliente19 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str20 = cliente19.getMail();
        java.util.Set<Viagem> set_viagem21 = cliente19.getHistorico();
        Cliente cliente22 = cliente19.clone();
        java.lang.String str23 = cliente19.getMail();
        java.lang.String str24 = cliente19.getNome();
        int i25 = cliente13.compareTo((Ator) cliente19);
        java.lang.String str26 = cliente13.getNome();
        Cliente cliente27 = new Cliente(cliente13);
        org.junit.Assert.assertNotNull(set_viagem11);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem21);
        org.junit.Assert.assertNotNull(cliente22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertTrue(i25 == (-35));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n" + "'", str26.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        cliente5.setMS(10.0d);
        Cliente cliente14 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str15 = cliente14.getMail();
        java.util.Set<Viagem> set_viagem16 = cliente14.getHistorico();
        Cliente cliente17 = cliente14.clone();
        java.lang.String str18 = cliente14.getMail();
        cliente14.setMS((double) '4');
        java.lang.String str21 = cliente14.getPassword();
        int i22 = cliente5.compareTo(cliente14);
        try {
            Viagem viagem23 = cliente14.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem16);
        org.junit.Assert.assertNotNull(cliente17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertTrue(i22 == (-1));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        Cliente cliente10 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str17 = cliente16.getMail();
        java.util.Set<Viagem> set_viagem18 = cliente16.getHistorico();
        Cliente cliente19 = cliente16.clone();
        java.lang.String str20 = cliente16.getMail();
        int i21 = cliente10.compareTo(cliente16);
        java.lang.String str22 = cliente16.toString();
        java.util.Set<Viagem> set_viagem23 = cliente16.getHistorico();
        java.lang.String str24 = cliente16.toString();
        java.lang.String str25 = cliente16.getMail();
        Cliente cliente26 = new Cliente(cliente16);
        Cliente cliente32 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente38 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str39 = cliente38.getMail();
        java.util.Set<Viagem> set_viagem40 = cliente38.getHistorico();
        Cliente cliente41 = cliente38.clone();
        java.lang.String str42 = cliente38.getMail();
        int i43 = cliente32.compareTo(cliente38);
        java.lang.String str44 = cliente38.toString();
        java.util.Set<Viagem> set_viagem45 = cliente38.getHistorico();
        boolean b46 = cliente16.equals((java.lang.Object) set_viagem45);
        Cliente cliente48 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "", set_viagem45, (double) 100);
        java.lang.String str49 = cliente48.getNome();
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem18);
        org.junit.Assert.assertNotNull(cliente19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertTrue(i21 == 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str22.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str24.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "hi!" + "'", str39.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem40);
        org.junit.Assert.assertNotNull(cliente41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "hi!" + "'", str42.equals("hi!"));
        org.junit.Assert.assertTrue(i43 == 0);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str44.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem45);
        org.junit.Assert.assertTrue(b46 == false);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str49.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        Cliente cliente10 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "hi!", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n");
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        int i17 = cliente10.compareTo(cliente16);
        java.util.Set<Viagem> set_viagem18 = cliente16.getHistorico();
        java.util.Set<Viagem> set_viagem19 = cliente16.getHistorico();
        Cliente cliente21 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", set_viagem19, 0.0d);
        java.lang.String str22 = cliente21.getMail();
        Cliente cliente23 = null;
        try {
            int i24 = cliente21.compareTo(cliente23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i17 == (-35));
        org.junit.Assert.assertNotNull(set_viagem18);
        org.junit.Assert.assertNotNull(set_viagem19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n" + "'", str22.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        Cliente cliente10 = new Cliente("hi!", "", "", "hi!", "");
        java.util.Set<Viagem> set_viagem11 = cliente10.getHistorico();
        Cliente cliente13 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "hi!", "", set_viagem11, (double) 10.0f);
        Cliente cliente19 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str20 = cliente19.getMail();
        java.util.Set<Viagem> set_viagem21 = cliente19.getHistorico();
        Cliente cliente22 = cliente19.clone();
        java.lang.String str23 = cliente19.getMail();
        java.lang.String str24 = cliente19.getNome();
        int i25 = cliente13.compareTo((Ator) cliente19);
        Cliente cliente31 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str32 = cliente31.getMail();
        java.util.Set<Viagem> set_viagem33 = cliente31.getHistorico();
        Cliente cliente34 = cliente31.clone();
        Cliente cliente40 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente46 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str47 = cliente46.getMail();
        java.util.Set<Viagem> set_viagem48 = cliente46.getHistorico();
        Cliente cliente49 = cliente46.clone();
        java.lang.String str50 = cliente46.getMail();
        int i51 = cliente40.compareTo(cliente46);
        java.lang.String str52 = cliente46.toString();
        int i53 = cliente31.compareTo(cliente46);
        Cliente cliente59 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str60 = cliente59.getMail();
        java.util.Set<Viagem> set_viagem61 = cliente59.getHistorico();
        Cliente cliente62 = cliente59.clone();
        java.lang.String str63 = cliente59.getMail();
        java.lang.String str64 = cliente59.getNome();
        boolean b65 = cliente46.equals((java.lang.Object) str64);
        java.lang.String str66 = cliente46.getMail();
        java.util.Set<Viagem> set_viagem67 = cliente46.getHistorico();
        Cliente cliente68 = new Cliente(cliente46);
        int i69 = cliente13.compareTo((Ator) cliente68);
        org.junit.Assert.assertNotNull(set_viagem11);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem21);
        org.junit.Assert.assertNotNull(cliente22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertTrue(i25 == (-35));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "hi!" + "'", str32.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem33);
        org.junit.Assert.assertNotNull(cliente34);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "hi!" + "'", str47.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem48);
        org.junit.Assert.assertNotNull(cliente49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "hi!" + "'", str50.equals("hi!"));
        org.junit.Assert.assertTrue(i51 == 0);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str52.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue(i53 == 0);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "hi!" + "'", str60.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem61);
        org.junit.Assert.assertNotNull(cliente62);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "hi!" + "'", str63.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "" + "'", str64.equals(""));
        org.junit.Assert.assertTrue(b65 == false);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "hi!" + "'", str66.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem67);
        org.junit.Assert.assertTrue(i69 == (-35));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        Cliente cliente14 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente20 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str21 = cliente20.getMail();
        java.util.Set<Viagem> set_viagem22 = cliente20.getHistorico();
        Cliente cliente23 = cliente20.clone();
        java.lang.String str24 = cliente20.getMail();
        int i25 = cliente14.compareTo(cliente20);
        java.lang.String str26 = cliente20.toString();
        int i27 = cliente5.compareTo(cliente20);
        Cliente cliente28 = new Cliente(cliente5);
        Cliente cliente29 = cliente5.clone();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem22);
        org.junit.Assert.assertNotNull(cliente23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str26.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue(i27 == 0);
        org.junit.Assert.assertNotNull(cliente29);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        Cliente cliente0 = new Cliente();
        cliente0.setMS((double) 100);
        java.lang.String str3 = cliente0.getMorada();
        java.lang.String str4 = cliente0.getNome();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        Cliente cliente14 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente20 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str21 = cliente20.getMail();
        java.util.Set<Viagem> set_viagem22 = cliente20.getHistorico();
        Cliente cliente23 = cliente20.clone();
        java.lang.String str24 = cliente20.getMail();
        int i25 = cliente14.compareTo(cliente20);
        java.lang.String str26 = cliente20.toString();
        int i27 = cliente5.compareTo(cliente20);
        Cliente cliente33 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str34 = cliente33.getMail();
        java.util.Set<Viagem> set_viagem35 = cliente33.getHistorico();
        Cliente cliente36 = cliente33.clone();
        java.lang.String str37 = cliente33.getMail();
        java.lang.String str38 = cliente33.getNome();
        boolean b39 = cliente20.equals((java.lang.Object) str38);
        java.lang.String str40 = cliente20.getMail();
        java.util.Set<Viagem> set_viagem41 = cliente20.getHistorico();
        java.lang.String str42 = cliente20.getDataDeNascimento();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem22);
        org.junit.Assert.assertNotNull(cliente23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str26.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue(i27 == 0);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem35);
        org.junit.Assert.assertNotNull(cliente36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
        org.junit.Assert.assertTrue(b39 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "hi!" + "'", str40.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "" + "'", str42.equals(""));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.util.Set<Viagem> set_viagem6 = cliente5.getHistorico();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        java.lang.String str8 = cliente5.getNome();
        org.junit.Assert.assertNotNull(set_viagem6);
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente8.getPassword();
        Cliente cliente15 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str16 = cliente15.getMail();
        java.util.Set<Viagem> set_viagem17 = cliente15.getHistorico();
        Cliente cliente18 = cliente15.clone();
        java.lang.String str19 = cliente15.getMail();
        cliente15.setMS((double) '4');
        java.lang.String str22 = cliente15.getPassword();
        int i23 = cliente8.compareTo(cliente15);
        java.lang.String str24 = cliente15.toString();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem17);
        org.junit.Assert.assertNotNull(cliente18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertTrue(i23 == (-1));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n" + "'", str24.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        java.util.Set<Viagem> set_viagem18 = cliente11.getHistorico();
        java.lang.String str19 = cliente11.toString();
        java.lang.String str20 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem21 = cliente11.getHistorico();
        java.lang.String str22 = cliente11.getMail();
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str19.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!" + "'", str22.equals("hi!"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        Cliente cliente23 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente29 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str30 = cliente29.getMail();
        java.util.Set<Viagem> set_viagem31 = cliente29.getHistorico();
        Cliente cliente32 = cliente29.clone();
        java.lang.String str33 = cliente29.getMail();
        int i34 = cliente23.compareTo(cliente29);
        int i35 = cliente11.compareTo((Ator) cliente29);
        Cliente cliente41 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str42 = cliente41.getMail();
        java.util.Set<Viagem> set_viagem43 = cliente41.getHistorico();
        Cliente cliente44 = cliente41.clone();
        int i45 = cliente11.compareTo(cliente41);
        double d46 = cliente11.getMS();
        java.lang.String str47 = cliente11.getPassword();
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem31);
        org.junit.Assert.assertNotNull(cliente32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertTrue(i34 == 0);
        org.junit.Assert.assertTrue(i35 == 0);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "hi!" + "'", str42.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem43);
        org.junit.Assert.assertNotNull(cliente44);
        org.junit.Assert.assertTrue(i45 == 0);
        org.junit.Assert.assertTrue(d46 == 0.0d);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "" + "'", str47.equals(""));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        Cliente cliente5 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "", "", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n");
        Viagem viagem6 = null;
        try {
            cliente5.registaViagem(viagem6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        Cliente cliente5 = new Cliente("", "", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "");
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        java.util.Set<Viagem> set_viagem17 = cliente16.getHistorico();
        Cliente cliente19 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "hi!", "", set_viagem17, (double) 10.0f);
        int i20 = cliente5.compareTo(cliente19);
        java.util.GregorianCalendar gregorianCalendar21 = null;
        java.util.GregorianCalendar gregorianCalendar22 = null;
        try {
            java.util.List<Viagem> list_viagem23 = cliente19.viagensEntreDatas(gregorianCalendar21, gregorianCalendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(set_viagem17);
        org.junit.Assert.assertTrue(i20 == (-116));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        java.util.Set<Viagem> set_viagem18 = cliente11.getHistorico();
        java.lang.String str19 = cliente11.toString();
        java.lang.String str20 = cliente11.getMail();
        Cliente cliente21 = new Cliente(cliente11);
        cliente11.setMS((double) (short) 1);
        java.lang.String str24 = cliente11.getDataDeNascimento();
        Viagem viagem25 = null;
        try {
            cliente11.registaViagem(viagem25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str19.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        Cliente cliente5 = new Cliente("", "", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "");
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        java.util.Set<Viagem> set_viagem17 = cliente16.getHistorico();
        Cliente cliente19 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "hi!", "", set_viagem17, (double) 10.0f);
        int i20 = cliente5.compareTo(cliente19);
        double d21 = cliente5.getMS();
        org.junit.Assert.assertNotNull(set_viagem17);
        org.junit.Assert.assertTrue(i20 == (-116));
        org.junit.Assert.assertTrue(d21 == 0.0d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        double d10 = cliente5.getMS();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue(d10 == 0.0d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        Cliente cliente10 = new Cliente("hi!", "", "", "hi!", "");
        java.util.Set<Viagem> set_viagem11 = cliente10.getHistorico();
        java.util.Set<Viagem> set_viagem12 = cliente10.getHistorico();
        Cliente cliente14 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: \nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "", set_viagem12, 10.0d);
        org.junit.Assert.assertNotNull(set_viagem11);
        org.junit.Assert.assertNotNull(set_viagem12);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        Cliente cliente23 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente29 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str30 = cliente29.getMail();
        java.util.Set<Viagem> set_viagem31 = cliente29.getHistorico();
        Cliente cliente32 = cliente29.clone();
        java.lang.String str33 = cliente29.getMail();
        int i34 = cliente23.compareTo(cliente29);
        int i35 = cliente11.compareTo((Ator) cliente29);
        java.lang.String str36 = cliente11.getPassword();
        Cliente cliente37 = cliente11.clone();
        double d38 = cliente11.getMS();
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem31);
        org.junit.Assert.assertNotNull(cliente32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertTrue(i34 == 0);
        org.junit.Assert.assertTrue(i35 == 0);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
        org.junit.Assert.assertNotNull(cliente37);
        org.junit.Assert.assertTrue(d38 == 0.0d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        Cliente cliente5 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "", "hi!", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n");
        Cliente cliente6 = cliente5.clone();
        Viagem viagem7 = null;
        try {
            cliente6.registaViagem(viagem7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(cliente6);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        java.lang.String str10 = cliente5.getNome();
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente22 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str23 = cliente22.getMail();
        java.util.Set<Viagem> set_viagem24 = cliente22.getHistorico();
        Cliente cliente25 = cliente22.clone();
        java.lang.String str26 = cliente22.getMail();
        int i27 = cliente16.compareTo(cliente22);
        java.lang.String str28 = cliente22.toString();
        Cliente cliente34 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente40 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str41 = cliente40.getMail();
        java.util.Set<Viagem> set_viagem42 = cliente40.getHistorico();
        Cliente cliente43 = cliente40.clone();
        java.lang.String str44 = cliente40.getMail();
        int i45 = cliente34.compareTo(cliente40);
        int i46 = cliente22.compareTo((Ator) cliente40);
        cliente22.setMS((double) 10L);
        int i49 = cliente5.compareTo((Ator) cliente22);
        java.lang.String str50 = cliente22.getMorada();
        Cliente cliente56 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str57 = cliente56.getMail();
        java.util.Set<Viagem> set_viagem58 = cliente56.getHistorico();
        Cliente cliente59 = cliente56.clone();
        Cliente cliente65 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente71 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str72 = cliente71.getMail();
        java.util.Set<Viagem> set_viagem73 = cliente71.getHistorico();
        Cliente cliente74 = cliente71.clone();
        java.lang.String str75 = cliente71.getMail();
        int i76 = cliente65.compareTo(cliente71);
        java.lang.String str77 = cliente71.toString();
        int i78 = cliente56.compareTo(cliente71);
        Cliente cliente84 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str85 = cliente84.getMail();
        java.util.Set<Viagem> set_viagem86 = cliente84.getHistorico();
        Cliente cliente87 = cliente84.clone();
        java.lang.String str88 = cliente84.getMail();
        java.lang.String str89 = cliente84.getNome();
        boolean b90 = cliente71.equals((java.lang.Object) str89);
        java.lang.String str91 = cliente71.getMail();
        java.util.Set<Viagem> set_viagem92 = cliente71.getHistorico();
        Cliente cliente93 = new Cliente(cliente71);
        Cliente cliente94 = cliente71.clone();
        int i95 = cliente22.compareTo((Ator) cliente94);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem24);
        org.junit.Assert.assertNotNull(cliente25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
        org.junit.Assert.assertTrue(i27 == 0);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str28.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "hi!" + "'", str41.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem42);
        org.junit.Assert.assertNotNull(cliente43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "hi!" + "'", str44.equals("hi!"));
        org.junit.Assert.assertTrue(i45 == 0);
        org.junit.Assert.assertTrue(i46 == 0);
        org.junit.Assert.assertTrue(i49 == 0);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "hi!" + "'", str50.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "hi!" + "'", str57.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem58);
        org.junit.Assert.assertNotNull(cliente59);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "hi!" + "'", str72.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem73);
        org.junit.Assert.assertNotNull(cliente74);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "hi!" + "'", str75.equals("hi!"));
        org.junit.Assert.assertTrue(i76 == 0);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str77.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue(i78 == 0);
        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "hi!" + "'", str85.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem86);
        org.junit.Assert.assertNotNull(cliente87);
        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "hi!" + "'", str88.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "" + "'", str89.equals(""));
        org.junit.Assert.assertTrue(b90 == false);
        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "hi!" + "'", str91.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem92);
        org.junit.Assert.assertNotNull(cliente94);
        org.junit.Assert.assertTrue(i95 == 0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente8.getPassword();
        Cliente cliente15 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str16 = cliente15.getMail();
        java.util.Set<Viagem> set_viagem17 = cliente15.getHistorico();
        Cliente cliente18 = cliente15.clone();
        java.lang.String str19 = cliente15.getMail();
        cliente15.setMS((double) '4');
        java.lang.String str22 = cliente15.getPassword();
        int i23 = cliente8.compareTo(cliente15);
        double d24 = cliente15.getMS();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem17);
        org.junit.Assert.assertNotNull(cliente18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertTrue(i23 == (-1));
        org.junit.Assert.assertTrue(d24 == 52.0d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        java.lang.String str18 = cliente11.getNome();
        Cliente cliente19 = cliente11.clone();
        try {
            Viagem viagem20 = cliente11.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertNotNull(cliente19);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        Cliente cliente14 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente20 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str21 = cliente20.getMail();
        java.util.Set<Viagem> set_viagem22 = cliente20.getHistorico();
        Cliente cliente23 = cliente20.clone();
        java.lang.String str24 = cliente20.getMail();
        int i25 = cliente14.compareTo(cliente20);
        java.lang.String str26 = cliente20.toString();
        int i27 = cliente5.compareTo(cliente20);
        Cliente cliente33 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str34 = cliente33.getMail();
        java.util.Set<Viagem> set_viagem35 = cliente33.getHistorico();
        Cliente cliente36 = cliente33.clone();
        java.lang.String str37 = cliente33.getMail();
        java.lang.String str38 = cliente33.getNome();
        boolean b39 = cliente20.equals((java.lang.Object) str38);
        java.lang.String str40 = cliente20.getMail();
        Cliente cliente41 = cliente20.clone();
        Cliente cliente42 = new Cliente(cliente20);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem22);
        org.junit.Assert.assertNotNull(cliente23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str26.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue(i27 == 0);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem35);
        org.junit.Assert.assertNotNull(cliente36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
        org.junit.Assert.assertTrue(b39 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "hi!" + "'", str40.equals("hi!"));
        org.junit.Assert.assertNotNull(cliente41);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        Cliente cliente23 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente29 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str30 = cliente29.getMail();
        java.util.Set<Viagem> set_viagem31 = cliente29.getHistorico();
        Cliente cliente32 = cliente29.clone();
        java.lang.String str33 = cliente29.getMail();
        int i34 = cliente23.compareTo(cliente29);
        int i35 = cliente11.compareTo((Ator) cliente29);
        cliente11.setMS(0.0d);
        java.lang.String str38 = cliente11.getNome();
        java.util.Set<Viagem> set_viagem39 = cliente11.getHistorico();
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem31);
        org.junit.Assert.assertNotNull(cliente32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertTrue(i34 == 0);
        org.junit.Assert.assertTrue(i35 == 0);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
        org.junit.Assert.assertNotNull(set_viagem39);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        Cliente cliente23 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente29 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str30 = cliente29.getMail();
        java.util.Set<Viagem> set_viagem31 = cliente29.getHistorico();
        Cliente cliente32 = cliente29.clone();
        java.lang.String str33 = cliente29.getMail();
        int i34 = cliente23.compareTo(cliente29);
        int i35 = cliente11.compareTo((Ator) cliente29);
        java.lang.String str36 = cliente11.getPassword();
        double d37 = cliente11.getMS();
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem31);
        org.junit.Assert.assertNotNull(cliente32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertTrue(i34 == 0);
        org.junit.Assert.assertTrue(i35 == 0);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
        org.junit.Assert.assertTrue(d37 == 0.0d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        java.util.Set<Viagem> set_viagem18 = cliente11.getHistorico();
        java.lang.String str19 = cliente11.getDataDeNascimento();
        double d20 = cliente11.getMS();
        java.lang.String str21 = cliente11.getNome();
        cliente11.setMS((double) (short) -1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue(d20 == 0.0d);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        Cliente cliente5 = new Cliente("E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n");
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        Cliente cliente23 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente29 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str30 = cliente29.getMail();
        java.util.Set<Viagem> set_viagem31 = cliente29.getHistorico();
        Cliente cliente32 = cliente29.clone();
        java.lang.String str33 = cliente29.getMail();
        int i34 = cliente23.compareTo(cliente29);
        int i35 = cliente11.compareTo((Ator) cliente29);
        Cliente cliente41 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str42 = cliente41.getMail();
        java.util.Set<Viagem> set_viagem43 = cliente41.getHistorico();
        Cliente cliente44 = cliente41.clone();
        int i45 = cliente11.compareTo(cliente41);
        Cliente cliente51 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente57 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str58 = cliente57.getMail();
        java.util.Set<Viagem> set_viagem59 = cliente57.getHistorico();
        Cliente cliente60 = cliente57.clone();
        java.lang.String str61 = cliente57.getMail();
        int i62 = cliente51.compareTo(cliente57);
        java.lang.String str63 = cliente57.toString();
        Cliente cliente69 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente75 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str76 = cliente75.getMail();
        java.util.Set<Viagem> set_viagem77 = cliente75.getHistorico();
        Cliente cliente78 = cliente75.clone();
        java.lang.String str79 = cliente75.getMail();
        int i80 = cliente69.compareTo(cliente75);
        int i81 = cliente57.compareTo((Ator) cliente75);
        Cliente cliente87 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str88 = cliente87.getMail();
        java.util.Set<Viagem> set_viagem89 = cliente87.getHistorico();
        Cliente cliente90 = cliente87.clone();
        int i91 = cliente57.compareTo(cliente87);
        java.lang.String str92 = cliente87.getMail();
        java.lang.String str93 = cliente87.toString();
        int i94 = cliente41.compareTo(cliente87);
        Cliente cliente95 = new Cliente(cliente87);
        java.lang.String str96 = cliente95.toString();
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem31);
        org.junit.Assert.assertNotNull(cliente32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertTrue(i34 == 0);
        org.junit.Assert.assertTrue(i35 == 0);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "hi!" + "'", str42.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem43);
        org.junit.Assert.assertNotNull(cliente44);
        org.junit.Assert.assertTrue(i45 == 0);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "hi!" + "'", str58.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem59);
        org.junit.Assert.assertNotNull(cliente60);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "hi!" + "'", str61.equals("hi!"));
        org.junit.Assert.assertTrue(i62 == 0);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str63.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "hi!" + "'", str76.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem77);
        org.junit.Assert.assertNotNull(cliente78);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "hi!" + "'", str79.equals("hi!"));
        org.junit.Assert.assertTrue(i80 == 0);
        org.junit.Assert.assertTrue(i81 == 0);
        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "hi!" + "'", str88.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem89);
        org.junit.Assert.assertNotNull(cliente90);
        org.junit.Assert.assertTrue(i91 == 0);
        org.junit.Assert.assertTrue("'" + str92 + "' != '" + "hi!" + "'", str92.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str93 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str93.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue(i94 == 0);
        org.junit.Assert.assertTrue("'" + str96 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str96.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        Cliente cliente23 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente29 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str30 = cliente29.getMail();
        java.util.Set<Viagem> set_viagem31 = cliente29.getHistorico();
        Cliente cliente32 = cliente29.clone();
        java.lang.String str33 = cliente29.getMail();
        int i34 = cliente23.compareTo(cliente29);
        int i35 = cliente11.compareTo((Ator) cliente29);
        cliente11.setMS(0.0d);
        boolean b39 = cliente11.equals((java.lang.Object) false);
        java.lang.String str40 = cliente11.getDataDeNascimento();
        java.util.Set<Viagem> set_viagem41 = cliente11.getHistorico();
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem31);
        org.junit.Assert.assertNotNull(cliente32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertTrue(i34 == 0);
        org.junit.Assert.assertTrue(i35 == 0);
        org.junit.Assert.assertTrue(b39 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "" + "'", str40.equals(""));
        org.junit.Assert.assertNotNull(set_viagem41);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        Cliente cliente23 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente29 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str30 = cliente29.getMail();
        java.util.Set<Viagem> set_viagem31 = cliente29.getHistorico();
        Cliente cliente32 = cliente29.clone();
        java.lang.String str33 = cliente29.getMail();
        int i34 = cliente23.compareTo(cliente29);
        int i35 = cliente11.compareTo((Ator) cliente29);
        cliente11.setMS(0.0d);
        boolean b39 = cliente11.equals((java.lang.Object) 0);
        java.lang.String str40 = cliente11.toString();
        Cliente cliente41 = cliente11.clone();
        cliente41.setMS((double) (-116));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem31);
        org.junit.Assert.assertNotNull(cliente32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertTrue(i34 == 0);
        org.junit.Assert.assertTrue(i35 == 0);
        org.junit.Assert.assertTrue(b39 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str40.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(cliente41);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        Cliente cliente5 = new Cliente("", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: \nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: \nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        Cliente cliente20 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente26 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str27 = cliente26.getMail();
        java.util.Set<Viagem> set_viagem28 = cliente26.getHistorico();
        Cliente cliente29 = cliente26.clone();
        java.lang.String str30 = cliente26.getMail();
        int i31 = cliente20.compareTo(cliente26);
        java.lang.String str32 = cliente26.toString();
        int i33 = cliente11.compareTo(cliente26);
        Cliente cliente34 = new Cliente(cliente26);
        Cliente cliente45 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente51 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str52 = cliente51.getMail();
        java.util.Set<Viagem> set_viagem53 = cliente51.getHistorico();
        Cliente cliente54 = cliente51.clone();
        java.lang.String str55 = cliente51.getMail();
        int i56 = cliente45.compareTo(cliente51);
        java.lang.String str57 = cliente51.toString();
        java.util.Set<Viagem> set_viagem58 = cliente51.getHistorico();
        java.lang.String str59 = cliente51.toString();
        java.lang.String str60 = cliente51.getMail();
        Cliente cliente61 = new Cliente(cliente51);
        Cliente cliente67 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente73 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str74 = cliente73.getMail();
        java.util.Set<Viagem> set_viagem75 = cliente73.getHistorico();
        Cliente cliente76 = cliente73.clone();
        java.lang.String str77 = cliente73.getMail();
        int i78 = cliente67.compareTo(cliente73);
        java.lang.String str79 = cliente73.toString();
        java.util.Set<Viagem> set_viagem80 = cliente73.getHistorico();
        boolean b81 = cliente51.equals((java.lang.Object) set_viagem80);
        Cliente cliente83 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", set_viagem80, 0.0d);
        java.lang.String str84 = cliente83.toString();
        int i85 = cliente34.compareTo((Ator) cliente83);
        int i86 = cliente5.compareTo((Ator) cliente83);
        java.lang.String str87 = cliente5.getMail();
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "hi!" + "'", str27.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem28);
        org.junit.Assert.assertNotNull(cliente29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertTrue(i31 == 0);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str32.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue(i33 == 0);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "hi!" + "'", str52.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem53);
        org.junit.Assert.assertNotNull(cliente54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "hi!" + "'", str55.equals("hi!"));
        org.junit.Assert.assertTrue(i56 == 0);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str57.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str59.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "hi!" + "'", str60.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "hi!" + "'", str74.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem75);
        org.junit.Assert.assertNotNull(cliente76);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "hi!" + "'", str77.equals("hi!"));
        org.junit.Assert.assertTrue(i78 == 0);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str79.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem80);
        org.junit.Assert.assertTrue(b81 == false);
        org.junit.Assert.assertTrue("'" + str84 + "' != '" + "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: \nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str84.equals("E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: \nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue(i85 == 35);
        org.junit.Assert.assertTrue(i86 == (-116));
        org.junit.Assert.assertTrue("'" + str87 + "' != '" + "" + "'", str87.equals(""));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        Cliente cliente14 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente20 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str21 = cliente20.getMail();
        java.util.Set<Viagem> set_viagem22 = cliente20.getHistorico();
        Cliente cliente23 = cliente20.clone();
        java.lang.String str24 = cliente20.getMail();
        int i25 = cliente14.compareTo(cliente20);
        java.lang.String str26 = cliente20.toString();
        int i27 = cliente5.compareTo(cliente20);
        Cliente cliente33 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str34 = cliente33.getMail();
        java.util.Set<Viagem> set_viagem35 = cliente33.getHistorico();
        Cliente cliente36 = cliente33.clone();
        java.lang.String str37 = cliente33.getMail();
        java.lang.String str38 = cliente33.getNome();
        boolean b39 = cliente20.equals((java.lang.Object) str38);
        java.lang.String str40 = cliente20.getMail();
        Cliente cliente41 = cliente20.clone();
        java.lang.String str42 = cliente41.toString();
        Cliente cliente48 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str49 = cliente48.getMail();
        java.util.Set<Viagem> set_viagem50 = cliente48.getHistorico();
        Cliente cliente51 = cliente48.clone();
        Cliente cliente57 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente63 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str64 = cliente63.getMail();
        java.util.Set<Viagem> set_viagem65 = cliente63.getHistorico();
        Cliente cliente66 = cliente63.clone();
        java.lang.String str67 = cliente63.getMail();
        int i68 = cliente57.compareTo(cliente63);
        java.lang.String str69 = cliente63.toString();
        int i70 = cliente48.compareTo(cliente63);
        Cliente cliente71 = new Cliente(cliente63);
        cliente71.setMS((double) (-3));
        int i74 = cliente41.compareTo(cliente71);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem22);
        org.junit.Assert.assertNotNull(cliente23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str26.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue(i27 == 0);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem35);
        org.junit.Assert.assertNotNull(cliente36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
        org.junit.Assert.assertTrue(b39 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "hi!" + "'", str40.equals("hi!"));
        org.junit.Assert.assertNotNull(cliente41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str42.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "hi!" + "'", str49.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem50);
        org.junit.Assert.assertNotNull(cliente51);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "hi!" + "'", str64.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem65);
        org.junit.Assert.assertNotNull(cliente66);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "hi!" + "'", str67.equals("hi!"));
        org.junit.Assert.assertTrue(i68 == 0);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str69.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue(i70 == 0);
        org.junit.Assert.assertTrue(i74 == 1);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        Cliente cliente23 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente29 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str30 = cliente29.getMail();
        java.util.Set<Viagem> set_viagem31 = cliente29.getHistorico();
        Cliente cliente32 = cliente29.clone();
        java.lang.String str33 = cliente29.getMail();
        int i34 = cliente23.compareTo(cliente29);
        int i35 = cliente11.compareTo((Ator) cliente29);
        Cliente cliente41 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente47 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str48 = cliente47.getMail();
        java.util.Set<Viagem> set_viagem49 = cliente47.getHistorico();
        Cliente cliente50 = cliente47.clone();
        java.lang.String str51 = cliente47.getMail();
        int i52 = cliente41.compareTo(cliente47);
        java.lang.String str53 = cliente47.toString();
        java.util.Set<Viagem> set_viagem54 = cliente47.getHistorico();
        java.lang.String str55 = cliente47.toString();
        Cliente cliente56 = new Cliente(cliente47);
        int i57 = cliente11.compareTo((Ator) cliente47);
        try {
            Viagem viagem58 = cliente11.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem31);
        org.junit.Assert.assertNotNull(cliente32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertTrue(i34 == 0);
        org.junit.Assert.assertTrue(i35 == 0);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "hi!" + "'", str48.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem49);
        org.junit.Assert.assertNotNull(cliente50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "hi!" + "'", str51.equals("hi!"));
        org.junit.Assert.assertTrue(i52 == 0);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str53.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str55.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue(i57 == 0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        cliente5.setMS((double) '4');
        java.lang.String str12 = cliente5.getNome();
        Viagem viagem13 = null;
        try {
            cliente5.registaViagem(viagem13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        Cliente cliente23 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente29 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str30 = cliente29.getMail();
        java.util.Set<Viagem> set_viagem31 = cliente29.getHistorico();
        Cliente cliente32 = cliente29.clone();
        java.lang.String str33 = cliente29.getMail();
        int i34 = cliente23.compareTo(cliente29);
        int i35 = cliente11.compareTo((Ator) cliente29);
        Cliente cliente41 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str42 = cliente41.getMail();
        java.util.Set<Viagem> set_viagem43 = cliente41.getHistorico();
        Cliente cliente44 = cliente41.clone();
        int i45 = cliente11.compareTo(cliente41);
        java.lang.String str46 = cliente41.getMorada();
        Cliente cliente47 = cliente41.clone();
        Cliente cliente48 = cliente41.clone();
        cliente48.setMS((double) 0.0f);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem31);
        org.junit.Assert.assertNotNull(cliente32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertTrue(i34 == 0);
        org.junit.Assert.assertTrue(i35 == 0);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "hi!" + "'", str42.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem43);
        org.junit.Assert.assertNotNull(cliente44);
        org.junit.Assert.assertTrue(i45 == 0);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "hi!" + "'", str46.equals("hi!"));
        org.junit.Assert.assertNotNull(cliente47);
        org.junit.Assert.assertNotNull(cliente48);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        java.util.Set<Viagem> set_viagem18 = cliente11.getHistorico();
        java.lang.String str19 = cliente11.toString();
        java.lang.String str20 = cliente11.getMorada();
        Cliente cliente21 = cliente11.clone();
        try {
            Viagem viagem22 = cliente21.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str19.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertNotNull(cliente21);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        Cliente cliente23 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente29 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str30 = cliente29.getMail();
        java.util.Set<Viagem> set_viagem31 = cliente29.getHistorico();
        Cliente cliente32 = cliente29.clone();
        java.lang.String str33 = cliente29.getMail();
        int i34 = cliente23.compareTo(cliente29);
        int i35 = cliente11.compareTo((Ator) cliente29);
        Cliente cliente41 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str42 = cliente41.getMail();
        java.util.Set<Viagem> set_viagem43 = cliente41.getHistorico();
        Cliente cliente44 = cliente41.clone();
        int i45 = cliente11.compareTo(cliente41);
        Cliente cliente51 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente57 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str58 = cliente57.getMail();
        java.util.Set<Viagem> set_viagem59 = cliente57.getHistorico();
        Cliente cliente60 = cliente57.clone();
        java.lang.String str61 = cliente57.getMail();
        int i62 = cliente51.compareTo(cliente57);
        java.lang.String str63 = cliente57.toString();
        Cliente cliente69 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente75 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str76 = cliente75.getMail();
        java.util.Set<Viagem> set_viagem77 = cliente75.getHistorico();
        Cliente cliente78 = cliente75.clone();
        java.lang.String str79 = cliente75.getMail();
        int i80 = cliente69.compareTo(cliente75);
        int i81 = cliente57.compareTo((Ator) cliente75);
        Cliente cliente87 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str88 = cliente87.getMail();
        java.util.Set<Viagem> set_viagem89 = cliente87.getHistorico();
        Cliente cliente90 = cliente87.clone();
        int i91 = cliente57.compareTo(cliente87);
        java.lang.String str92 = cliente87.getMail();
        java.lang.String str93 = cliente87.toString();
        int i94 = cliente41.compareTo(cliente87);
        java.lang.String str95 = cliente87.getMorada();
        Cliente cliente96 = cliente87.clone();
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem31);
        org.junit.Assert.assertNotNull(cliente32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertTrue(i34 == 0);
        org.junit.Assert.assertTrue(i35 == 0);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "hi!" + "'", str42.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem43);
        org.junit.Assert.assertNotNull(cliente44);
        org.junit.Assert.assertTrue(i45 == 0);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "hi!" + "'", str58.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem59);
        org.junit.Assert.assertNotNull(cliente60);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "hi!" + "'", str61.equals("hi!"));
        org.junit.Assert.assertTrue(i62 == 0);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str63.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "hi!" + "'", str76.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem77);
        org.junit.Assert.assertNotNull(cliente78);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "hi!" + "'", str79.equals("hi!"));
        org.junit.Assert.assertTrue(i80 == 0);
        org.junit.Assert.assertTrue(i81 == 0);
        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "hi!" + "'", str88.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem89);
        org.junit.Assert.assertNotNull(cliente90);
        org.junit.Assert.assertTrue(i91 == 0);
        org.junit.Assert.assertTrue("'" + str92 + "' != '" + "hi!" + "'", str92.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str93 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str93.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue(i94 == 0);
        org.junit.Assert.assertTrue("'" + str95 + "' != '" + "hi!" + "'", str95.equals("hi!"));
        org.junit.Assert.assertNotNull(cliente96);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        Cliente cliente14 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente20 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str21 = cliente20.getMail();
        java.util.Set<Viagem> set_viagem22 = cliente20.getHistorico();
        Cliente cliente23 = cliente20.clone();
        java.lang.String str24 = cliente20.getMail();
        int i25 = cliente14.compareTo(cliente20);
        java.lang.String str26 = cliente20.toString();
        int i27 = cliente5.compareTo(cliente20);
        double d28 = cliente20.getMS();
        double d29 = cliente20.getMS();
        cliente20.setMS(0.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem22);
        org.junit.Assert.assertNotNull(cliente23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str26.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue(i27 == 0);
        org.junit.Assert.assertTrue(d28 == 0.0d);
        org.junit.Assert.assertTrue(d29 == 0.0d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        Cliente cliente0 = new Cliente();
        cliente0.setMS((double) 100);
        Cliente cliente8 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str9 = cliente8.getMail();
        java.util.Set<Viagem> set_viagem10 = cliente8.getHistorico();
        Cliente cliente11 = cliente8.clone();
        Cliente cliente17 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente23 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str24 = cliente23.getMail();
        java.util.Set<Viagem> set_viagem25 = cliente23.getHistorico();
        Cliente cliente26 = cliente23.clone();
        java.lang.String str27 = cliente23.getMail();
        int i28 = cliente17.compareTo(cliente23);
        java.lang.String str29 = cliente23.toString();
        int i30 = cliente8.compareTo(cliente23);
        int i31 = cliente0.compareTo(cliente8);
        java.lang.String str32 = cliente0.getNome();
        java.lang.String str33 = cliente0.getDataDeNascimento();
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem10);
        org.junit.Assert.assertNotNull(cliente11);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem25);
        org.junit.Assert.assertNotNull(cliente26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "hi!" + "'", str27.equals("hi!"));
        org.junit.Assert.assertTrue(i28 == 0);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str29.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue(i30 == 0);
        org.junit.Assert.assertTrue(i31 == (-3));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "" + "'", str32.equals(""));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        Cliente cliente5 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "hi!", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        int i12 = cliente5.compareTo(cliente11);
        java.lang.String str13 = cliente5.getMorada();
        Cliente cliente19 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "", "", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "hi!");
        double d20 = cliente19.getMS();
        int i21 = cliente5.compareTo((Ator) cliente19);
        cliente19.setMS(0.0d);
        org.junit.Assert.assertTrue(i12 == (-35));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n" + "'", str13.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n"));
        org.junit.Assert.assertTrue(d20 == 0.0d);
        org.junit.Assert.assertTrue(i21 == (-5));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        Cliente cliente23 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente29 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str30 = cliente29.getMail();
        java.util.Set<Viagem> set_viagem31 = cliente29.getHistorico();
        Cliente cliente32 = cliente29.clone();
        java.lang.String str33 = cliente29.getMail();
        int i34 = cliente23.compareTo(cliente29);
        int i35 = cliente11.compareTo((Ator) cliente29);
        cliente11.setMS((double) 10L);
        cliente11.setMS(10.0d);
        java.lang.String str40 = cliente11.toString();
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem31);
        org.junit.Assert.assertNotNull(cliente32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertTrue(i34 == 0);
        org.junit.Assert.assertTrue(i35 == 0);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n" + "'", str40.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        cliente5.setMS(10.0d);
        Cliente cliente9 = new Cliente(cliente5);
        java.lang.String str10 = cliente9.getMail();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        java.lang.String str10 = cliente5.getNome();
        java.lang.String str11 = cliente5.getPassword();
        try {
            Viagem viagem12 = cliente5.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        cliente5.setMS((double) '4');
        java.lang.String str12 = cliente5.toString();
        java.lang.Object obj13 = new java.lang.Object();
        boolean b14 = cliente5.equals(obj13);
        java.util.GregorianCalendar gregorianCalendar15 = null;
        java.util.GregorianCalendar gregorianCalendar16 = null;
        try {
            java.util.List<Viagem> list_viagem17 = cliente5.viagensEntreDatas(gregorianCalendar15, gregorianCalendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n" + "'", str12.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n"));
        org.junit.Assert.assertTrue(b14 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        Cliente cliente23 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente29 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str30 = cliente29.getMail();
        java.util.Set<Viagem> set_viagem31 = cliente29.getHistorico();
        Cliente cliente32 = cliente29.clone();
        java.lang.String str33 = cliente29.getMail();
        int i34 = cliente23.compareTo(cliente29);
        int i35 = cliente11.compareTo((Ator) cliente29);
        cliente11.setMS(0.0d);
        boolean b39 = cliente11.equals((java.lang.Object) false);
        java.util.Set<Viagem> set_viagem40 = cliente11.getHistorico();
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem31);
        org.junit.Assert.assertNotNull(cliente32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertTrue(i34 == 0);
        org.junit.Assert.assertTrue(i35 == 0);
        org.junit.Assert.assertTrue(b39 == false);
        org.junit.Assert.assertNotNull(set_viagem40);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        Cliente cliente10 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "hi!", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n");
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        int i17 = cliente10.compareTo(cliente16);
        java.util.Set<Viagem> set_viagem18 = cliente10.getHistorico();
        Cliente cliente20 = new Cliente("", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: \nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", set_viagem18, (double) 'a');
        org.junit.Assert.assertTrue(i17 == (-35));
        org.junit.Assert.assertNotNull(set_viagem18);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        Cliente cliente14 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente20 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str21 = cliente20.getMail();
        java.util.Set<Viagem> set_viagem22 = cliente20.getHistorico();
        Cliente cliente23 = cliente20.clone();
        java.lang.String str24 = cliente20.getMail();
        int i25 = cliente14.compareTo(cliente20);
        java.lang.String str26 = cliente20.toString();
        int i27 = cliente5.compareTo(cliente20);
        Cliente cliente33 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str34 = cliente33.getMail();
        java.util.Set<Viagem> set_viagem35 = cliente33.getHistorico();
        Cliente cliente36 = cliente33.clone();
        java.lang.String str37 = cliente33.getMail();
        java.lang.String str38 = cliente33.getNome();
        boolean b39 = cliente20.equals((java.lang.Object) str38);
        java.lang.String str40 = cliente20.getDataDeNascimento();
        java.lang.String str41 = cliente20.getDataDeNascimento();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem22);
        org.junit.Assert.assertNotNull(cliente23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str26.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue(i27 == 0);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem35);
        org.junit.Assert.assertNotNull(cliente36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
        org.junit.Assert.assertTrue(b39 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "" + "'", str40.equals(""));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "" + "'", str41.equals(""));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        Cliente cliente14 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente20 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str21 = cliente20.getMail();
        java.util.Set<Viagem> set_viagem22 = cliente20.getHistorico();
        Cliente cliente23 = cliente20.clone();
        java.lang.String str24 = cliente20.getMail();
        int i25 = cliente14.compareTo(cliente20);
        java.lang.String str26 = cliente20.toString();
        int i27 = cliente5.compareTo(cliente20);
        Cliente cliente28 = new Cliente(cliente5);
        Cliente cliente29 = cliente28.clone();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem22);
        org.junit.Assert.assertNotNull(cliente23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str26.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue(i27 == 0);
        org.junit.Assert.assertNotNull(cliente29);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        Cliente cliente5 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "", "", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "hi!");
        double d6 = cliente5.getMS();
        java.lang.String str7 = cliente5.getMail();
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n" + "'", str7.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        Cliente cliente10 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str17 = cliente16.getMail();
        java.util.Set<Viagem> set_viagem18 = cliente16.getHistorico();
        Cliente cliente19 = cliente16.clone();
        java.lang.String str20 = cliente16.getMail();
        int i21 = cliente10.compareTo(cliente16);
        java.lang.String str22 = cliente16.toString();
        Cliente cliente28 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente34 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str35 = cliente34.getMail();
        java.util.Set<Viagem> set_viagem36 = cliente34.getHistorico();
        Cliente cliente37 = cliente34.clone();
        java.lang.String str38 = cliente34.getMail();
        int i39 = cliente28.compareTo(cliente34);
        int i40 = cliente16.compareTo((Ator) cliente34);
        cliente16.setMS(0.0d);
        java.lang.String str43 = cliente16.getNome();
        java.lang.String str44 = cliente16.getPassword();
        java.util.Set<Viagem> set_viagem45 = cliente16.getHistorico();
        Cliente cliente47 = new Cliente("E-mail: \nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: \nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: \nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: \nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", set_viagem45, (-1.0d));
        java.lang.String str48 = cliente47.getPassword();
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem18);
        org.junit.Assert.assertNotNull(cliente19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertTrue(i21 == 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str22.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!" + "'", str35.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem36);
        org.junit.Assert.assertNotNull(cliente37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "hi!" + "'", str38.equals("hi!"));
        org.junit.Assert.assertTrue(i39 == 0);
        org.junit.Assert.assertTrue(i40 == 0);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "" + "'", str43.equals(""));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "" + "'", str44.equals(""));
        org.junit.Assert.assertNotNull(set_viagem45);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "E-mail: \nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str48.equals("E-mail: \nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        Cliente cliente23 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente29 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str30 = cliente29.getMail();
        java.util.Set<Viagem> set_viagem31 = cliente29.getHistorico();
        Cliente cliente32 = cliente29.clone();
        java.lang.String str33 = cliente29.getMail();
        int i34 = cliente23.compareTo(cliente29);
        int i35 = cliente11.compareTo((Ator) cliente29);
        cliente11.setMS(0.0d);
        java.lang.String str38 = cliente11.getNome();
        java.lang.String str39 = cliente11.toString();
        java.util.GregorianCalendar gregorianCalendar40 = null;
        java.util.GregorianCalendar gregorianCalendar41 = null;
        try {
            java.util.List<Viagem> list_viagem42 = cliente11.viagensEntreDatas(gregorianCalendar40, gregorianCalendar41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem31);
        org.junit.Assert.assertNotNull(cliente32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertTrue(i34 == 0);
        org.junit.Assert.assertTrue(i35 == 0);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str39.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        Cliente cliente23 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente29 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str30 = cliente29.getMail();
        java.util.Set<Viagem> set_viagem31 = cliente29.getHistorico();
        Cliente cliente32 = cliente29.clone();
        java.lang.String str33 = cliente29.getMail();
        int i34 = cliente23.compareTo(cliente29);
        int i35 = cliente11.compareTo((Ator) cliente29);
        Cliente cliente41 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str42 = cliente41.getMail();
        java.util.Set<Viagem> set_viagem43 = cliente41.getHistorico();
        Cliente cliente44 = cliente41.clone();
        int i45 = cliente11.compareTo(cliente41);
        Cliente cliente51 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente57 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str58 = cliente57.getMail();
        java.util.Set<Viagem> set_viagem59 = cliente57.getHistorico();
        Cliente cliente60 = cliente57.clone();
        java.lang.String str61 = cliente57.getMail();
        int i62 = cliente51.compareTo(cliente57);
        java.lang.String str63 = cliente57.toString();
        Cliente cliente69 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente75 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str76 = cliente75.getMail();
        java.util.Set<Viagem> set_viagem77 = cliente75.getHistorico();
        Cliente cliente78 = cliente75.clone();
        java.lang.String str79 = cliente75.getMail();
        int i80 = cliente69.compareTo(cliente75);
        int i81 = cliente57.compareTo((Ator) cliente75);
        Cliente cliente87 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str88 = cliente87.getMail();
        java.util.Set<Viagem> set_viagem89 = cliente87.getHistorico();
        Cliente cliente90 = cliente87.clone();
        int i91 = cliente57.compareTo(cliente87);
        java.lang.String str92 = cliente87.getMail();
        java.lang.String str93 = cliente87.toString();
        int i94 = cliente41.compareTo(cliente87);
        cliente87.setMS((double) 1L);
        cliente87.setMS((double) 1.0f);
        java.lang.String str99 = cliente87.toString();
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem31);
        org.junit.Assert.assertNotNull(cliente32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertTrue(i34 == 0);
        org.junit.Assert.assertTrue(i35 == 0);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "hi!" + "'", str42.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem43);
        org.junit.Assert.assertNotNull(cliente44);
        org.junit.Assert.assertTrue(i45 == 0);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "hi!" + "'", str58.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem59);
        org.junit.Assert.assertNotNull(cliente60);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "hi!" + "'", str61.equals("hi!"));
        org.junit.Assert.assertTrue(i62 == 0);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str63.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "hi!" + "'", str76.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem77);
        org.junit.Assert.assertNotNull(cliente78);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "hi!" + "'", str79.equals("hi!"));
        org.junit.Assert.assertTrue(i80 == 0);
        org.junit.Assert.assertTrue(i81 == 0);
        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "hi!" + "'", str88.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem89);
        org.junit.Assert.assertNotNull(cliente90);
        org.junit.Assert.assertTrue(i91 == 0);
        org.junit.Assert.assertTrue("'" + str92 + "' != '" + "hi!" + "'", str92.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str93 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str93.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue(i94 == 0);
        org.junit.Assert.assertTrue("'" + str99 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 1.00\n" + "'", str99.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 1.00\n"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        Cliente cliente23 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente29 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str30 = cliente29.getMail();
        java.util.Set<Viagem> set_viagem31 = cliente29.getHistorico();
        Cliente cliente32 = cliente29.clone();
        java.lang.String str33 = cliente29.getMail();
        int i34 = cliente23.compareTo(cliente29);
        int i35 = cliente11.compareTo((Ator) cliente29);
        cliente11.setMS((double) 10L);
        java.lang.String str38 = cliente11.getDataDeNascimento();
        double d39 = cliente11.getMS();
        Cliente cliente40 = cliente11.clone();
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem31);
        org.junit.Assert.assertNotNull(cliente32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertTrue(i34 == 0);
        org.junit.Assert.assertTrue(i35 == 0);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
        org.junit.Assert.assertTrue(d39 == 10.0d);
        org.junit.Assert.assertNotNull(cliente40);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        cliente5.setMS(10.0d);
        java.lang.String str9 = cliente5.getMail();
        java.lang.String str10 = cliente5.getMorada();
        java.lang.String str11 = cliente5.getMorada();
        java.lang.String str12 = cliente5.getMail();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        Cliente cliente5 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "", "", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n");
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        java.util.Set<Viagem> set_viagem17 = cliente16.getHistorico();
        Cliente cliente19 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "hi!", "", set_viagem17, (double) 10.0f);
        Cliente cliente25 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str26 = cliente25.getMail();
        java.util.Set<Viagem> set_viagem27 = cliente25.getHistorico();
        Cliente cliente28 = cliente25.clone();
        java.lang.String str29 = cliente25.getMail();
        java.lang.String str30 = cliente25.getNome();
        int i31 = cliente19.compareTo((Ator) cliente25);
        int i32 = cliente5.compareTo((Ator) cliente25);
        double d33 = cliente25.getMS();
        org.junit.Assert.assertNotNull(set_viagem17);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem27);
        org.junit.Assert.assertNotNull(cliente28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "" + "'", str30.equals(""));
        org.junit.Assert.assertTrue(i31 == (-35));
        org.junit.Assert.assertTrue(i32 == (-35));
        org.junit.Assert.assertTrue(d33 == 0.0d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        cliente5.setMS(10.0d);
        java.lang.String str9 = cliente5.getMail();
        java.lang.String str10 = cliente5.getMorada();
        java.lang.String str11 = cliente5.getNome();
        Cliente cliente12 = cliente5.clone();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(cliente12);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        Cliente cliente5 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 1.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: \nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "E-mail: \nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n");
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        Cliente cliente15 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente21 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str22 = cliente21.getMail();
        java.util.Set<Viagem> set_viagem23 = cliente21.getHistorico();
        Cliente cliente24 = cliente21.clone();
        java.lang.String str25 = cliente21.getMail();
        int i26 = cliente15.compareTo(cliente21);
        java.lang.String str27 = cliente21.toString();
        java.util.Set<Viagem> set_viagem28 = cliente21.getHistorico();
        Cliente cliente30 = new Cliente("", "hi!", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "hi!", "hi!", set_viagem28, (double) 100L);
        Cliente cliente32 = new Cliente("E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: \nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 1.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 1.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", set_viagem28, 0.0d);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!" + "'", str22.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem23);
        org.junit.Assert.assertNotNull(cliente24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
        org.junit.Assert.assertTrue(i26 == 0);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str27.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem28);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        Cliente cliente10 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str11 = cliente10.getMail();
        cliente10.setMS(10.0d);
        java.lang.String str14 = cliente10.getMail();
        java.lang.String str15 = cliente10.getMorada();
        java.lang.String str16 = cliente10.getNome();
        double d17 = cliente10.getMS();
        java.util.Set<Viagem> set_viagem18 = cliente10.getHistorico();
        Cliente cliente20 = new Cliente("E-mail: \nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: \nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 1.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: \nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "", set_viagem18, (double) 1L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue(d17 == 10.0d);
        org.junit.Assert.assertNotNull(set_viagem18);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente8.getPassword();
        Cliente cliente15 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str16 = cliente15.getMail();
        java.util.Set<Viagem> set_viagem17 = cliente15.getHistorico();
        Cliente cliente18 = cliente15.clone();
        java.lang.String str19 = cliente15.getMail();
        cliente15.setMS((double) '4');
        java.lang.String str22 = cliente15.getPassword();
        int i23 = cliente8.compareTo(cliente15);
        java.lang.String str24 = cliente15.getNome();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem17);
        org.junit.Assert.assertNotNull(cliente18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertTrue(i23 == (-1));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        Cliente cliente14 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente20 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str21 = cliente20.getMail();
        java.util.Set<Viagem> set_viagem22 = cliente20.getHistorico();
        Cliente cliente23 = cliente20.clone();
        java.lang.String str24 = cliente20.getMail();
        int i25 = cliente14.compareTo(cliente20);
        java.lang.String str26 = cliente20.toString();
        int i27 = cliente5.compareTo(cliente20);
        Cliente cliente33 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str34 = cliente33.getMail();
        java.util.Set<Viagem> set_viagem35 = cliente33.getHistorico();
        Cliente cliente36 = cliente33.clone();
        java.lang.String str37 = cliente33.getMail();
        java.lang.String str38 = cliente33.getNome();
        boolean b39 = cliente20.equals((java.lang.Object) str38);
        java.lang.String str40 = cliente20.getMail();
        cliente20.setMS(52.0d);
        java.lang.String str43 = cliente20.getNome();
        double d44 = cliente20.getMS();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem22);
        org.junit.Assert.assertNotNull(cliente23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str26.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue(i27 == 0);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem35);
        org.junit.Assert.assertNotNull(cliente36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
        org.junit.Assert.assertTrue(b39 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "hi!" + "'", str40.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "" + "'", str43.equals(""));
        org.junit.Assert.assertTrue(d44 == 52.0d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        Cliente cliente5 = new Cliente("", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: \nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: \nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n");
        java.lang.String str6 = cliente5.getMail();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        Cliente cliente5 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: -1.00\n", "hi!", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 1.00\n");
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        java.util.Set<Viagem> set_viagem18 = cliente11.getHistorico();
        java.lang.String str19 = cliente11.toString();
        java.lang.String str20 = cliente11.getNome();
        java.lang.String str21 = cliente11.getMail();
        Cliente cliente22 = new Cliente(cliente11);
        Cliente cliente28 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente34 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str35 = cliente34.getMail();
        java.util.Set<Viagem> set_viagem36 = cliente34.getHistorico();
        Cliente cliente37 = cliente34.clone();
        java.lang.String str38 = cliente34.getMail();
        int i39 = cliente28.compareTo(cliente34);
        java.lang.String str40 = cliente34.toString();
        java.lang.String str41 = cliente34.getNome();
        Cliente cliente42 = cliente34.clone();
        int i43 = cliente22.compareTo((Ator) cliente42);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str19.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!" + "'", str35.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem36);
        org.junit.Assert.assertNotNull(cliente37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "hi!" + "'", str38.equals("hi!"));
        org.junit.Assert.assertTrue(i39 == 0);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str40.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "" + "'", str41.equals(""));
        org.junit.Assert.assertNotNull(cliente42);
        org.junit.Assert.assertTrue(i43 == 0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        Cliente cliente23 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente29 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str30 = cliente29.getMail();
        java.util.Set<Viagem> set_viagem31 = cliente29.getHistorico();
        Cliente cliente32 = cliente29.clone();
        java.lang.String str33 = cliente29.getMail();
        int i34 = cliente23.compareTo(cliente29);
        int i35 = cliente11.compareTo((Ator) cliente29);
        Cliente cliente41 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente47 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str48 = cliente47.getMail();
        java.util.Set<Viagem> set_viagem49 = cliente47.getHistorico();
        Cliente cliente50 = cliente47.clone();
        java.lang.String str51 = cliente47.getMail();
        int i52 = cliente41.compareTo(cliente47);
        java.lang.String str53 = cliente47.toString();
        java.util.Set<Viagem> set_viagem54 = cliente47.getHistorico();
        java.lang.String str55 = cliente47.toString();
        Cliente cliente56 = new Cliente(cliente47);
        int i57 = cliente11.compareTo((Ator) cliente47);
        Viagem viagem58 = null;
        try {
            cliente47.registaViagem(viagem58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem31);
        org.junit.Assert.assertNotNull(cliente32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertTrue(i34 == 0);
        org.junit.Assert.assertTrue(i35 == 0);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "hi!" + "'", str48.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem49);
        org.junit.Assert.assertNotNull(cliente50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "hi!" + "'", str51.equals("hi!"));
        org.junit.Assert.assertTrue(i52 == 0);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str53.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str55.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue(i57 == 0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        cliente5.setMS(10.0d);
        java.lang.String str9 = cliente5.getMail();
        java.lang.String str10 = cliente5.getMorada();
        java.util.GregorianCalendar gregorianCalendar11 = null;
        java.util.GregorianCalendar gregorianCalendar12 = null;
        try {
            java.util.List<Viagem> list_viagem13 = cliente5.viagensEntreDatas(gregorianCalendar11, gregorianCalendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        Cliente cliente20 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "hi!", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n");
        Cliente cliente26 = new Cliente("hi!", "", "", "hi!", "");
        int i27 = cliente20.compareTo(cliente26);
        java.util.Set<Viagem> set_viagem28 = cliente26.getHistorico();
        java.util.Set<Viagem> set_viagem29 = cliente26.getHistorico();
        Cliente cliente31 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "hi!", "hi!", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", set_viagem29, 0.0d);
        Cliente cliente33 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "hi!", set_viagem29, 0.0d);
        Cliente cliente35 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 1.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: -1.00\n", set_viagem29, (double) 10.0f);
        org.junit.Assert.assertTrue(i27 == (-35));
        org.junit.Assert.assertNotNull(set_viagem28);
        org.junit.Assert.assertNotNull(set_viagem29);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        Cliente cliente5 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "hi!", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        int i12 = cliente5.compareTo(cliente11);
        java.lang.String str13 = cliente5.getDataDeNascimento();
        org.junit.Assert.assertTrue(i12 == (-35));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str13.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        Cliente cliente5 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "hi!", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        int i12 = cliente5.compareTo(cliente11);
        cliente5.setMS((double) (byte) 0);
        java.lang.String str15 = cliente5.getMorada();
        org.junit.Assert.assertTrue(i12 == (-35));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n" + "'", str15.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        Cliente cliente10 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str17 = cliente16.getMail();
        java.util.Set<Viagem> set_viagem18 = cliente16.getHistorico();
        Cliente cliente19 = cliente16.clone();
        java.lang.String str20 = cliente16.getMail();
        int i21 = cliente10.compareTo(cliente16);
        java.lang.String str22 = cliente16.toString();
        Cliente cliente28 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente34 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str35 = cliente34.getMail();
        java.util.Set<Viagem> set_viagem36 = cliente34.getHistorico();
        Cliente cliente37 = cliente34.clone();
        java.lang.String str38 = cliente34.getMail();
        int i39 = cliente28.compareTo(cliente34);
        int i40 = cliente16.compareTo((Ator) cliente34);
        cliente16.setMS(0.0d);
        java.lang.String str43 = cliente16.getNome();
        java.lang.String str44 = cliente16.getPassword();
        Cliente cliente50 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str51 = cliente50.getMail();
        java.util.Set<Viagem> set_viagem52 = cliente50.getHistorico();
        Cliente cliente53 = cliente50.clone();
        java.lang.String str54 = cliente50.getMail();
        int i55 = cliente16.compareTo((Ator) cliente50);
        java.util.Set<Viagem> set_viagem56 = cliente16.getHistorico();
        Cliente cliente58 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: -1.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: -1.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", set_viagem56, (double) 1L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem18);
        org.junit.Assert.assertNotNull(cliente19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertTrue(i21 == 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str22.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!" + "'", str35.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem36);
        org.junit.Assert.assertNotNull(cliente37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "hi!" + "'", str38.equals("hi!"));
        org.junit.Assert.assertTrue(i39 == 0);
        org.junit.Assert.assertTrue(i40 == 0);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "" + "'", str43.equals(""));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "" + "'", str44.equals(""));
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "hi!" + "'", str51.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem52);
        org.junit.Assert.assertNotNull(cliente53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "hi!" + "'", str54.equals("hi!"));
        org.junit.Assert.assertTrue(i55 == 0);
        org.junit.Assert.assertNotNull(set_viagem56);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        cliente5.setMS(10.0d);
        Cliente cliente9 = new Cliente(cliente5);
        Viagem viagem10 = null;
        try {
            cliente5.registaViagem(viagem10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        java.lang.String str10 = cliente5.getNome();
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente22 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str23 = cliente22.getMail();
        java.util.Set<Viagem> set_viagem24 = cliente22.getHistorico();
        Cliente cliente25 = cliente22.clone();
        java.lang.String str26 = cliente22.getMail();
        int i27 = cliente16.compareTo(cliente22);
        java.lang.String str28 = cliente22.toString();
        Cliente cliente34 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente40 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str41 = cliente40.getMail();
        java.util.Set<Viagem> set_viagem42 = cliente40.getHistorico();
        Cliente cliente43 = cliente40.clone();
        java.lang.String str44 = cliente40.getMail();
        int i45 = cliente34.compareTo(cliente40);
        int i46 = cliente22.compareTo((Ator) cliente40);
        cliente22.setMS((double) 10L);
        int i49 = cliente5.compareTo((Ator) cliente22);
        java.lang.String str50 = cliente22.getMail();
        double d51 = cliente22.getMS();
        Cliente cliente57 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str58 = cliente57.getMail();
        java.util.Set<Viagem> set_viagem59 = cliente57.getHistorico();
        Cliente cliente60 = cliente57.clone();
        Cliente cliente66 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente72 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str73 = cliente72.getMail();
        java.util.Set<Viagem> set_viagem74 = cliente72.getHistorico();
        Cliente cliente75 = cliente72.clone();
        java.lang.String str76 = cliente72.getMail();
        int i77 = cliente66.compareTo(cliente72);
        java.lang.String str78 = cliente72.toString();
        int i79 = cliente57.compareTo(cliente72);
        Cliente cliente80 = new Cliente(cliente72);
        int i81 = cliente22.compareTo((Ator) cliente80);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem24);
        org.junit.Assert.assertNotNull(cliente25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
        org.junit.Assert.assertTrue(i27 == 0);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str28.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "hi!" + "'", str41.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem42);
        org.junit.Assert.assertNotNull(cliente43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "hi!" + "'", str44.equals("hi!"));
        org.junit.Assert.assertTrue(i45 == 0);
        org.junit.Assert.assertTrue(i46 == 0);
        org.junit.Assert.assertTrue(i49 == 0);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "hi!" + "'", str50.equals("hi!"));
        org.junit.Assert.assertTrue(d51 == 10.0d);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "hi!" + "'", str58.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem59);
        org.junit.Assert.assertNotNull(cliente60);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "hi!" + "'", str73.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem74);
        org.junit.Assert.assertNotNull(cliente75);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "hi!" + "'", str76.equals("hi!"));
        org.junit.Assert.assertTrue(i77 == 0);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str78.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue(i79 == 0);
        org.junit.Assert.assertTrue(i81 == 0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        cliente5.setMS(10.0d);
        java.lang.String str9 = cliente5.getMail();
        java.lang.String str10 = cliente5.getMorada();
        java.lang.String str11 = cliente5.getMorada();
        cliente5.setMS((double) 'a');
        java.util.Set<Viagem> set_viagem14 = cliente5.getHistorico();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem14);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        Cliente cliente5 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: \nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n");
        double d6 = cliente5.getMS();
        org.junit.Assert.assertTrue(d6 == 0.0d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        Cliente cliente5 = new Cliente("", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "hi!");
        cliente5.setMS((double) (-3));
        Viagem viagem8 = null;
        try {
            cliente5.registaViagem(viagem8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        java.lang.String str10 = cliente5.getNome();
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente22 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str23 = cliente22.getMail();
        java.util.Set<Viagem> set_viagem24 = cliente22.getHistorico();
        Cliente cliente25 = cliente22.clone();
        java.lang.String str26 = cliente22.getMail();
        int i27 = cliente16.compareTo(cliente22);
        java.lang.String str28 = cliente22.toString();
        Cliente cliente34 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente40 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str41 = cliente40.getMail();
        java.util.Set<Viagem> set_viagem42 = cliente40.getHistorico();
        Cliente cliente43 = cliente40.clone();
        java.lang.String str44 = cliente40.getMail();
        int i45 = cliente34.compareTo(cliente40);
        int i46 = cliente22.compareTo((Ator) cliente40);
        cliente22.setMS((double) 10L);
        int i49 = cliente5.compareTo((Ator) cliente22);
        Cliente cliente55 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str56 = cliente55.getMail();
        java.util.Set<Viagem> set_viagem57 = cliente55.getHistorico();
        Cliente cliente58 = cliente55.clone();
        java.lang.String str59 = cliente58.getPassword();
        int i60 = cliente22.compareTo((Ator) cliente58);
        double d61 = cliente22.getMS();
        Viagem viagem62 = null;
        try {
            cliente22.registaViagem(viagem62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem24);
        org.junit.Assert.assertNotNull(cliente25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
        org.junit.Assert.assertTrue(i27 == 0);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str28.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "hi!" + "'", str41.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem42);
        org.junit.Assert.assertNotNull(cliente43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "hi!" + "'", str44.equals("hi!"));
        org.junit.Assert.assertTrue(i45 == 0);
        org.junit.Assert.assertTrue(i46 == 0);
        org.junit.Assert.assertTrue(i49 == 0);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "hi!" + "'", str56.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem57);
        org.junit.Assert.assertNotNull(cliente58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "" + "'", str59.equals(""));
        org.junit.Assert.assertTrue(i60 == 0);
        org.junit.Assert.assertTrue(d61 == 10.0d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        double d18 = cliente11.getMS();
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue(d18 == 0.0d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        Cliente cliente10 = new Cliente("hi!", "", "", "hi!", "");
        java.util.Set<Viagem> set_viagem11 = cliente10.getHistorico();
        Cliente cliente13 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "hi!", "", set_viagem11, (double) 10.0f);
        Cliente cliente19 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str20 = cliente19.getMail();
        java.util.Set<Viagem> set_viagem21 = cliente19.getHistorico();
        Cliente cliente22 = cliente19.clone();
        java.lang.String str23 = cliente19.getMail();
        java.lang.String str24 = cliente19.getNome();
        int i25 = cliente13.compareTo((Ator) cliente19);
        Cliente cliente26 = new Cliente(cliente13);
        Cliente cliente37 = new Cliente("hi!", "", "", "hi!", "");
        java.util.Set<Viagem> set_viagem38 = cliente37.getHistorico();
        Cliente cliente40 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "hi!", "", set_viagem38, (double) 10.0f);
        Cliente cliente46 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str47 = cliente46.getMail();
        java.util.Set<Viagem> set_viagem48 = cliente46.getHistorico();
        Cliente cliente49 = cliente46.clone();
        java.lang.String str50 = cliente46.getMail();
        java.lang.String str51 = cliente46.getNome();
        int i52 = cliente40.compareTo((Ator) cliente46);
        cliente46.setMS((double) (short) 0);
        boolean b55 = cliente26.equals((java.lang.Object) (short) 0);
        double d56 = cliente26.getMS();
        org.junit.Assert.assertNotNull(set_viagem11);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem21);
        org.junit.Assert.assertNotNull(cliente22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertTrue(i25 == (-35));
        org.junit.Assert.assertNotNull(set_viagem38);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "hi!" + "'", str47.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem48);
        org.junit.Assert.assertNotNull(cliente49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "hi!" + "'", str50.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "" + "'", str51.equals(""));
        org.junit.Assert.assertTrue(i52 == (-35));
        org.junit.Assert.assertTrue(b55 == false);
        org.junit.Assert.assertTrue(d56 == 10.0d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        Cliente cliente5 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "hi!", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        int i12 = cliente5.compareTo(cliente11);
        boolean b14 = cliente5.equals((java.lang.Object) (byte) 1);
        java.lang.String str15 = cliente5.getNome();
        Cliente cliente16 = new Cliente(cliente5);
        Cliente cliente17 = new Cliente(cliente5);
        java.lang.String str18 = cliente17.getDataDeNascimento();
        org.junit.Assert.assertTrue(i12 == (-35));
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str18.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        cliente5.setMS((double) '4');
        java.lang.String str12 = cliente5.getPassword();
        java.util.Set<Viagem> set_viagem13 = cliente5.getHistorico();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNotNull(set_viagem13);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        java.util.Set<Viagem> set_viagem18 = cliente11.getHistorico();
        java.lang.String str19 = cliente11.toString();
        java.lang.String str20 = cliente11.getMail();
        Cliente cliente21 = new Cliente(cliente11);
        cliente11.setMS((double) (short) 1);
        java.lang.String str24 = cliente11.getDataDeNascimento();
        Cliente cliente30 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "", "hi!", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n");
        Cliente cliente31 = cliente30.clone();
        int i32 = cliente11.compareTo((Ator) cliente30);
        Cliente cliente38 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str39 = cliente38.getMail();
        java.util.Set<Viagem> set_viagem40 = cliente38.getHistorico();
        Cliente cliente41 = cliente38.clone();
        Cliente cliente47 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente53 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str54 = cliente53.getMail();
        java.util.Set<Viagem> set_viagem55 = cliente53.getHistorico();
        Cliente cliente56 = cliente53.clone();
        java.lang.String str57 = cliente53.getMail();
        int i58 = cliente47.compareTo(cliente53);
        java.lang.String str59 = cliente53.toString();
        int i60 = cliente38.compareTo(cliente53);
        Cliente cliente66 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str67 = cliente66.getMail();
        java.util.Set<Viagem> set_viagem68 = cliente66.getHistorico();
        Cliente cliente69 = cliente66.clone();
        java.lang.String str70 = cliente66.getMail();
        java.lang.String str71 = cliente66.getNome();
        boolean b72 = cliente53.equals((java.lang.Object) str71);
        int i73 = cliente11.compareTo((Ator) cliente53);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str19.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertNotNull(cliente31);
        org.junit.Assert.assertTrue(i32 == 35);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "hi!" + "'", str39.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem40);
        org.junit.Assert.assertNotNull(cliente41);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "hi!" + "'", str54.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem55);
        org.junit.Assert.assertNotNull(cliente56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "hi!" + "'", str57.equals("hi!"));
        org.junit.Assert.assertTrue(i58 == 0);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str59.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue(i60 == 0);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "hi!" + "'", str67.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem68);
        org.junit.Assert.assertNotNull(cliente69);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "hi!" + "'", str70.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "" + "'", str71.equals(""));
        org.junit.Assert.assertTrue(b72 == false);
        org.junit.Assert.assertTrue(i73 == 0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        Cliente cliente10 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str17 = cliente16.getMail();
        java.util.Set<Viagem> set_viagem18 = cliente16.getHistorico();
        Cliente cliente19 = cliente16.clone();
        java.lang.String str20 = cliente16.getMail();
        int i21 = cliente10.compareTo(cliente16);
        java.lang.String str22 = cliente16.toString();
        java.util.Set<Viagem> set_viagem23 = cliente16.getHistorico();
        Cliente cliente25 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "", "", "", set_viagem23, 10.0d);
        java.util.Set<Viagem> set_viagem26 = cliente25.getHistorico();
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem18);
        org.junit.Assert.assertNotNull(cliente19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertTrue(i21 == 0);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str22.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem23);
        org.junit.Assert.assertNotNull(set_viagem26);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        Cliente cliente5 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 1.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: -1.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: -1.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n");
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        Cliente cliente0 = new Cliente();
        cliente0.setMS((double) 100);
        java.lang.String str3 = cliente0.getMorada();
        java.util.GregorianCalendar gregorianCalendar4 = null;
        java.util.GregorianCalendar gregorianCalendar5 = null;
        try {
            java.util.List<Viagem> list_viagem6 = cliente0.viagensEntreDatas(gregorianCalendar4, gregorianCalendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        Cliente cliente14 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente20 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str21 = cliente20.getMail();
        java.util.Set<Viagem> set_viagem22 = cliente20.getHistorico();
        Cliente cliente23 = cliente20.clone();
        java.lang.String str24 = cliente20.getMail();
        int i25 = cliente14.compareTo(cliente20);
        java.lang.String str26 = cliente20.toString();
        int i27 = cliente5.compareTo(cliente20);
        Cliente cliente28 = new Cliente(cliente5);
        Cliente cliente29 = new Cliente(cliente5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem22);
        org.junit.Assert.assertNotNull(cliente23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str26.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue(i27 == 0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        Cliente cliente23 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente29 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str30 = cliente29.getMail();
        java.util.Set<Viagem> set_viagem31 = cliente29.getHistorico();
        Cliente cliente32 = cliente29.clone();
        java.lang.String str33 = cliente29.getMail();
        int i34 = cliente23.compareTo(cliente29);
        int i35 = cliente11.compareTo((Ator) cliente29);
        cliente11.setMS(0.0d);
        java.lang.String str38 = cliente11.getNome();
        java.lang.String str39 = cliente11.toString();
        java.lang.String str40 = cliente11.getMail();
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem31);
        org.junit.Assert.assertNotNull(cliente32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertTrue(i34 == 0);
        org.junit.Assert.assertTrue(i35 == 0);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str39.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "hi!" + "'", str40.equals("hi!"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        Cliente cliente0 = new Cliente();
        java.lang.String str1 = cliente0.getPassword();
        java.lang.String str2 = cliente0.getNome();
        cliente0.setMS((double) 35);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        java.util.Set<Viagem> set_viagem18 = cliente11.getHistorico();
        java.util.Set<Viagem> set_viagem19 = cliente11.getHistorico();
        java.lang.String str20 = cliente11.getPassword();
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem18);
        org.junit.Assert.assertNotNull(set_viagem19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        cliente5.setMS(10.0d);
        java.util.Set<Viagem> set_viagem9 = cliente5.getHistorico();
        cliente5.setMS((double) 1L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem9);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        Cliente cliente10 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "hi!", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n");
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        int i17 = cliente10.compareTo(cliente16);
        java.util.Set<Viagem> set_viagem18 = cliente16.getHistorico();
        java.util.Set<Viagem> set_viagem19 = cliente16.getHistorico();
        Cliente cliente21 = new Cliente("E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: \nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: \nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", set_viagem19, 0.0d);
        java.lang.String str22 = cliente21.getMorada();
        Cliente cliente28 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str29 = cliente28.getMail();
        java.util.Set<Viagem> set_viagem30 = cliente28.getHistorico();
        Cliente cliente31 = cliente28.clone();
        Cliente cliente37 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente43 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str44 = cliente43.getMail();
        java.util.Set<Viagem> set_viagem45 = cliente43.getHistorico();
        Cliente cliente46 = cliente43.clone();
        java.lang.String str47 = cliente43.getMail();
        int i48 = cliente37.compareTo(cliente43);
        java.lang.String str49 = cliente43.toString();
        int i50 = cliente28.compareTo(cliente43);
        double d51 = cliente43.getMS();
        double d52 = cliente43.getMS();
        boolean b53 = cliente21.equals((java.lang.Object) cliente43);
        Cliente cliente59 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str60 = cliente59.getMail();
        java.util.Set<Viagem> set_viagem61 = cliente59.getHistorico();
        Cliente cliente62 = cliente59.clone();
        Cliente cliente68 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente74 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str75 = cliente74.getMail();
        java.util.Set<Viagem> set_viagem76 = cliente74.getHistorico();
        Cliente cliente77 = cliente74.clone();
        java.lang.String str78 = cliente74.getMail();
        int i79 = cliente68.compareTo(cliente74);
        java.lang.String str80 = cliente74.toString();
        int i81 = cliente59.compareTo(cliente74);
        double d82 = cliente74.getMS();
        java.lang.String str83 = cliente74.getDataDeNascimento();
        int i84 = cliente21.compareTo((Ator) cliente74);
        Cliente cliente85 = cliente74.clone();
        org.junit.Assert.assertTrue(i17 == (-35));
        org.junit.Assert.assertNotNull(set_viagem18);
        org.junit.Assert.assertNotNull(set_viagem19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem30);
        org.junit.Assert.assertNotNull(cliente31);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "hi!" + "'", str44.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem45);
        org.junit.Assert.assertNotNull(cliente46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "hi!" + "'", str47.equals("hi!"));
        org.junit.Assert.assertTrue(i48 == 0);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str49.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue(i50 == 0);
        org.junit.Assert.assertTrue(d51 == 0.0d);
        org.junit.Assert.assertTrue(d52 == 0.0d);
        org.junit.Assert.assertTrue(b53 == false);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "hi!" + "'", str60.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem61);
        org.junit.Assert.assertNotNull(cliente62);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "hi!" + "'", str75.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem76);
        org.junit.Assert.assertNotNull(cliente77);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "hi!" + "'", str78.equals("hi!"));
        org.junit.Assert.assertTrue(i79 == 0);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str80.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue(i81 == 0);
        org.junit.Assert.assertTrue(d82 == 0.0d);
        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "" + "'", str83.equals(""));
        org.junit.Assert.assertTrue(i84 == (-35));
        org.junit.Assert.assertNotNull(cliente85);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        Cliente cliente10 = new Cliente("hi!", "", "", "hi!", "");
        java.util.Set<Viagem> set_viagem11 = cliente10.getHistorico();
        Cliente cliente13 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "hi!", "", set_viagem11, (double) 10.0f);
        Cliente cliente19 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str20 = cliente19.getMail();
        java.util.Set<Viagem> set_viagem21 = cliente19.getHistorico();
        Cliente cliente22 = cliente19.clone();
        java.lang.String str23 = cliente19.getMail();
        java.lang.String str24 = cliente19.getNome();
        int i25 = cliente13.compareTo((Ator) cliente19);
        cliente13.setMS((double) (-1L));
        java.lang.String str28 = cliente13.getPassword();
        java.lang.String str29 = cliente13.toString();
        double d30 = cliente13.getMS();
        org.junit.Assert.assertNotNull(set_viagem11);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem21);
        org.junit.Assert.assertNotNull(cliente22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertTrue(i25 == (-35));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str28.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: -1.00\n" + "'", str29.equals("E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: -1.00\n"));
        org.junit.Assert.assertTrue(d30 == (-1.0d));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        Cliente cliente0 = new Cliente();
        java.lang.String str1 = cliente0.getPassword();
        java.lang.String str2 = cliente0.getNome();
        Cliente cliente3 = cliente0.clone();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(cliente3);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        Cliente cliente5 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "", "hi!", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n");
        Cliente cliente6 = cliente5.clone();
        cliente5.setMS((double) 3);
        java.lang.String str9 = cliente5.toString();
        org.junit.Assert.assertNotNull(cliente6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nPassword: \nMorada: hi!\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\nMontante de dinheiro utilizado no serviço UMeR: 3.00\n" + "'", str9.equals("E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nPassword: \nMorada: hi!\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\nMontante de dinheiro utilizado no serviço UMeR: 3.00\n"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        Cliente cliente15 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "hi!", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n");
        Cliente cliente21 = new Cliente("hi!", "", "", "hi!", "");
        int i22 = cliente15.compareTo(cliente21);
        java.util.Set<Viagem> set_viagem23 = cliente21.getHistorico();
        java.util.Set<Viagem> set_viagem24 = cliente21.getHistorico();
        Cliente cliente26 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", set_viagem24, 0.0d);
        Cliente cliente28 = new Cliente("E-mail: \nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nPassword: \nMorada: hi!\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\nMontante de dinheiro utilizado no serviço UMeR: 3.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", set_viagem24, (double) 100);
        org.junit.Assert.assertTrue(i22 == (-35));
        org.junit.Assert.assertNotNull(set_viagem23);
        org.junit.Assert.assertNotNull(set_viagem24);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        Cliente cliente5 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "", "hi!", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n");
        Cliente cliente11 = new Cliente("", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "hi!", "");
        int i12 = cliente5.compareTo((Ator) cliente11);
        java.lang.String str13 = cliente5.getMail();
        org.junit.Assert.assertTrue(i12 == 116);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n" + "'", str13.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        Cliente cliente14 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente20 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str21 = cliente20.getMail();
        java.util.Set<Viagem> set_viagem22 = cliente20.getHistorico();
        Cliente cliente23 = cliente20.clone();
        java.lang.String str24 = cliente20.getMail();
        int i25 = cliente14.compareTo(cliente20);
        java.lang.String str26 = cliente20.toString();
        int i27 = cliente5.compareTo(cliente20);
        java.lang.String str28 = cliente5.toString();
        cliente5.setMS((double) (short) 1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem22);
        org.junit.Assert.assertNotNull(cliente23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str26.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue(i27 == 0);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str28.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        Cliente cliente5 = new Cliente("E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: \nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "hi!", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nPassword: \nMorada: hi!\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\nMontante de dinheiro utilizado no serviço UMeR: 3.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n");
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        Cliente cliente23 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente29 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str30 = cliente29.getMail();
        java.util.Set<Viagem> set_viagem31 = cliente29.getHistorico();
        Cliente cliente32 = cliente29.clone();
        java.lang.String str33 = cliente29.getMail();
        int i34 = cliente23.compareTo(cliente29);
        int i35 = cliente11.compareTo((Ator) cliente29);
        Cliente cliente41 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str42 = cliente41.getMail();
        java.util.Set<Viagem> set_viagem43 = cliente41.getHistorico();
        Cliente cliente44 = cliente41.clone();
        int i45 = cliente11.compareTo(cliente41);
        java.lang.String str46 = cliente41.getMorada();
        Cliente cliente47 = cliente41.clone();
        Cliente cliente48 = cliente41.clone();
        java.lang.String str49 = cliente41.getPassword();
        Cliente cliente50 = cliente41.clone();
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem31);
        org.junit.Assert.assertNotNull(cliente32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertTrue(i34 == 0);
        org.junit.Assert.assertTrue(i35 == 0);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "hi!" + "'", str42.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem43);
        org.junit.Assert.assertNotNull(cliente44);
        org.junit.Assert.assertTrue(i45 == 0);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "hi!" + "'", str46.equals("hi!"));
        org.junit.Assert.assertNotNull(cliente47);
        org.junit.Assert.assertNotNull(cliente48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "" + "'", str49.equals(""));
        org.junit.Assert.assertNotNull(cliente50);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        Cliente cliente5 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "", "E-mail: \nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: \nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n");
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        Cliente cliente23 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente29 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str30 = cliente29.getMail();
        java.util.Set<Viagem> set_viagem31 = cliente29.getHistorico();
        Cliente cliente32 = cliente29.clone();
        java.lang.String str33 = cliente29.getMail();
        int i34 = cliente23.compareTo(cliente29);
        int i35 = cliente11.compareTo((Ator) cliente29);
        Cliente cliente36 = cliente11.clone();
        Cliente cliente37 = new Cliente(cliente36);
        Cliente cliente48 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "hi!", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n");
        Cliente cliente54 = new Cliente("hi!", "", "", "hi!", "");
        int i55 = cliente48.compareTo(cliente54);
        java.util.Set<Viagem> set_viagem56 = cliente54.getHistorico();
        java.util.Set<Viagem> set_viagem57 = cliente54.getHistorico();
        Cliente cliente59 = new Cliente("E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: \nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: \nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", set_viagem57, 0.0d);
        java.lang.String str60 = cliente59.getMorada();
        Cliente cliente66 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str67 = cliente66.getMail();
        java.util.Set<Viagem> set_viagem68 = cliente66.getHistorico();
        Cliente cliente69 = cliente66.clone();
        Cliente cliente75 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente81 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str82 = cliente81.getMail();
        java.util.Set<Viagem> set_viagem83 = cliente81.getHistorico();
        Cliente cliente84 = cliente81.clone();
        java.lang.String str85 = cliente81.getMail();
        int i86 = cliente75.compareTo(cliente81);
        java.lang.String str87 = cliente81.toString();
        int i88 = cliente66.compareTo(cliente81);
        double d89 = cliente81.getMS();
        double d90 = cliente81.getMS();
        boolean b91 = cliente59.equals((java.lang.Object) cliente81);
        int i92 = cliente36.compareTo(cliente81);
        java.lang.String str93 = cliente36.getPassword();
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem31);
        org.junit.Assert.assertNotNull(cliente32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertTrue(i34 == 0);
        org.junit.Assert.assertTrue(i35 == 0);
        org.junit.Assert.assertNotNull(cliente36);
        org.junit.Assert.assertTrue(i55 == (-35));
        org.junit.Assert.assertNotNull(set_viagem56);
        org.junit.Assert.assertNotNull(set_viagem57);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "" + "'", str60.equals(""));
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "hi!" + "'", str67.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem68);
        org.junit.Assert.assertNotNull(cliente69);
        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "hi!" + "'", str82.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem83);
        org.junit.Assert.assertNotNull(cliente84);
        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "hi!" + "'", str85.equals("hi!"));
        org.junit.Assert.assertTrue(i86 == 0);
        org.junit.Assert.assertTrue("'" + str87 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str87.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue(i88 == 0);
        org.junit.Assert.assertTrue(d89 == 0.0d);
        org.junit.Assert.assertTrue(d90 == 0.0d);
        org.junit.Assert.assertTrue(b91 == false);
        org.junit.Assert.assertTrue(i92 == 0);
        org.junit.Assert.assertTrue("'" + str93 + "' != '" + "" + "'", str93.equals(""));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        cliente5.setMS((double) '4');
        java.lang.String str12 = cliente5.getNome();
        java.util.Set<Viagem> set_viagem13 = cliente5.getHistorico();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNotNull(set_viagem13);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        Cliente cliente5 = new Cliente("E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: \nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 1.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 1.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: -1.00\n");
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        Cliente cliente15 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "hi!", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n");
        Cliente cliente21 = new Cliente("hi!", "", "", "hi!", "");
        int i22 = cliente15.compareTo(cliente21);
        java.util.Set<Viagem> set_viagem23 = cliente21.getHistorico();
        java.util.Set<Viagem> set_viagem24 = cliente21.getHistorico();
        Cliente cliente26 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "hi!", "hi!", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", set_viagem24, 0.0d);
        Cliente cliente28 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "hi!", set_viagem24, 0.0d);
        java.lang.String str29 = cliente28.getPassword();
        org.junit.Assert.assertTrue(i22 == (-35));
        org.junit.Assert.assertNotNull(set_viagem23);
        org.junit.Assert.assertNotNull(set_viagem24);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str29.equals("E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        java.util.Set<Viagem> set_viagem5 = null;
        try {
            Cliente cliente7 = new Cliente("", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nPassword: \nMorada: hi!\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\nMontante de dinheiro utilizado no serviço UMeR: 3.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nPassword: \nMorada: hi!\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\nMontante de dinheiro utilizado no serviço UMeR: 3.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", set_viagem5, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        Cliente cliente23 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente29 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str30 = cliente29.getMail();
        java.util.Set<Viagem> set_viagem31 = cliente29.getHistorico();
        Cliente cliente32 = cliente29.clone();
        java.lang.String str33 = cliente29.getMail();
        int i34 = cliente23.compareTo(cliente29);
        int i35 = cliente11.compareTo((Ator) cliente29);
        Cliente cliente41 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str42 = cliente41.getMail();
        java.util.Set<Viagem> set_viagem43 = cliente41.getHistorico();
        Cliente cliente44 = cliente41.clone();
        int i45 = cliente11.compareTo(cliente41);
        java.lang.String str46 = cliente41.getMorada();
        java.lang.String str47 = cliente41.getDataDeNascimento();
        java.lang.String str48 = cliente41.getMorada();
        java.util.Set<Viagem> set_viagem49 = cliente41.getHistorico();
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem31);
        org.junit.Assert.assertNotNull(cliente32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertTrue(i34 == 0);
        org.junit.Assert.assertTrue(i35 == 0);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "hi!" + "'", str42.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem43);
        org.junit.Assert.assertNotNull(cliente44);
        org.junit.Assert.assertTrue(i45 == 0);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "hi!" + "'", str46.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "" + "'", str47.equals(""));
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "hi!" + "'", str48.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem49);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        Cliente cliente5 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 1.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nPassword: \nMorada: hi!\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\nMontante de dinheiro utilizado no serviço UMeR: 3.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 1.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: -1.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: -1.00\n");
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        Cliente cliente0 = new Cliente();
        Cliente cliente1 = cliente0.clone();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        try {
            java.util.List<Viagem> list_viagem4 = cliente0.viagensEntreDatas(gregorianCalendar2, gregorianCalendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(cliente1);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        Cliente cliente10 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "hi!", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n");
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        int i17 = cliente10.compareTo(cliente16);
        java.util.Set<Viagem> set_viagem18 = cliente16.getHistorico();
        java.util.Set<Viagem> set_viagem19 = cliente16.getHistorico();
        Cliente cliente21 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", set_viagem19, 0.0d);
        try {
            Viagem viagem22 = cliente21.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertTrue(i17 == (-35));
        org.junit.Assert.assertNotNull(set_viagem18);
        org.junit.Assert.assertNotNull(set_viagem19);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        java.util.Set<Viagem> set_viagem18 = cliente11.getHistorico();
        java.lang.String str19 = cliente11.getDataDeNascimento();
        double d20 = cliente11.getMS();
        Cliente cliente26 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente32 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str33 = cliente32.getMail();
        java.util.Set<Viagem> set_viagem34 = cliente32.getHistorico();
        Cliente cliente35 = cliente32.clone();
        java.lang.String str36 = cliente32.getMail();
        int i37 = cliente26.compareTo(cliente32);
        java.lang.String str38 = cliente32.toString();
        Cliente cliente44 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente50 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str51 = cliente50.getMail();
        java.util.Set<Viagem> set_viagem52 = cliente50.getHistorico();
        Cliente cliente53 = cliente50.clone();
        java.lang.String str54 = cliente50.getMail();
        int i55 = cliente44.compareTo(cliente50);
        int i56 = cliente32.compareTo((Ator) cliente50);
        cliente32.setMS(0.0d);
        java.lang.String str59 = cliente32.getNome();
        int i60 = cliente11.compareTo((Ator) cliente32);
        try {
            Viagem viagem61 = cliente32.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue(d20 == 0.0d);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem34);
        org.junit.Assert.assertNotNull(cliente35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertTrue(i37 == 0);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str38.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "hi!" + "'", str51.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem52);
        org.junit.Assert.assertNotNull(cliente53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "hi!" + "'", str54.equals("hi!"));
        org.junit.Assert.assertTrue(i55 == 0);
        org.junit.Assert.assertTrue(i56 == 0);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "" + "'", str59.equals(""));
        org.junit.Assert.assertTrue(i60 == 0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        java.lang.String str10 = cliente5.getNome();
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente22 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str23 = cliente22.getMail();
        java.util.Set<Viagem> set_viagem24 = cliente22.getHistorico();
        Cliente cliente25 = cliente22.clone();
        java.lang.String str26 = cliente22.getMail();
        int i27 = cliente16.compareTo(cliente22);
        java.lang.String str28 = cliente22.toString();
        Cliente cliente34 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente40 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str41 = cliente40.getMail();
        java.util.Set<Viagem> set_viagem42 = cliente40.getHistorico();
        Cliente cliente43 = cliente40.clone();
        java.lang.String str44 = cliente40.getMail();
        int i45 = cliente34.compareTo(cliente40);
        int i46 = cliente22.compareTo((Ator) cliente40);
        cliente22.setMS((double) 10L);
        int i49 = cliente5.compareTo((Ator) cliente22);
        java.lang.String str50 = cliente22.getMorada();
        Cliente cliente51 = new Cliente();
        cliente51.setMS((double) 100);
        boolean b54 = cliente22.equals((java.lang.Object) 100);
        java.lang.String str55 = cliente22.toString();
        try {
            Viagem viagem56 = cliente22.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem24);
        org.junit.Assert.assertNotNull(cliente25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
        org.junit.Assert.assertTrue(i27 == 0);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str28.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "hi!" + "'", str41.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem42);
        org.junit.Assert.assertNotNull(cliente43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "hi!" + "'", str44.equals("hi!"));
        org.junit.Assert.assertTrue(i45 == 0);
        org.junit.Assert.assertTrue(i46 == 0);
        org.junit.Assert.assertTrue(i49 == 0);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "hi!" + "'", str50.equals("hi!"));
        org.junit.Assert.assertTrue(b54 == false);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n" + "'", str55.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        cliente5.setMS((double) '4');
        java.lang.String str12 = cliente5.toString();
        java.lang.Object obj13 = new java.lang.Object();
        boolean b14 = cliente5.equals(obj13);
        Cliente cliente25 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente31 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str32 = cliente31.getMail();
        java.util.Set<Viagem> set_viagem33 = cliente31.getHistorico();
        Cliente cliente34 = cliente31.clone();
        java.lang.String str35 = cliente31.getMail();
        int i36 = cliente25.compareTo(cliente31);
        java.lang.String str37 = cliente31.toString();
        java.util.Set<Viagem> set_viagem38 = cliente31.getHistorico();
        java.lang.String str39 = cliente31.toString();
        java.lang.String str40 = cliente31.getMail();
        Cliente cliente41 = new Cliente(cliente31);
        Cliente cliente47 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente53 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str54 = cliente53.getMail();
        java.util.Set<Viagem> set_viagem55 = cliente53.getHistorico();
        Cliente cliente56 = cliente53.clone();
        java.lang.String str57 = cliente53.getMail();
        int i58 = cliente47.compareTo(cliente53);
        java.lang.String str59 = cliente53.toString();
        java.util.Set<Viagem> set_viagem60 = cliente53.getHistorico();
        boolean b61 = cliente31.equals((java.lang.Object) set_viagem60);
        Cliente cliente63 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "", set_viagem60, (double) 100);
        int i64 = cliente5.compareTo(cliente63);
        try {
            Viagem viagem65 = cliente5.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n" + "'", str12.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n"));
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "hi!" + "'", str32.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem33);
        org.junit.Assert.assertNotNull(cliente34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!" + "'", str35.equals("hi!"));
        org.junit.Assert.assertTrue(i36 == 0);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str37.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str39.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "hi!" + "'", str40.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "hi!" + "'", str54.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem55);
        org.junit.Assert.assertNotNull(cliente56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "hi!" + "'", str57.equals("hi!"));
        org.junit.Assert.assertTrue(i58 == 0);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str59.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem60);
        org.junit.Assert.assertTrue(b61 == false);
        org.junit.Assert.assertTrue(i64 == 35);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        Cliente cliente10 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "hi!", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n");
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        int i17 = cliente10.compareTo(cliente16);
        java.util.Set<Viagem> set_viagem18 = cliente10.getHistorico();
        Cliente cliente20 = new Cliente("E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nPassword: \nMorada: hi!\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\nMontante de dinheiro utilizado no serviço UMeR: 3.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nPassword: \nMorada: hi!\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\nMontante de dinheiro utilizado no serviço UMeR: 3.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: \nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", set_viagem18, (double) ' ');
        org.junit.Assert.assertTrue(i17 == (-35));
        org.junit.Assert.assertNotNull(set_viagem18);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        Cliente cliente14 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente20 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str21 = cliente20.getMail();
        java.util.Set<Viagem> set_viagem22 = cliente20.getHistorico();
        Cliente cliente23 = cliente20.clone();
        java.lang.String str24 = cliente20.getMail();
        int i25 = cliente14.compareTo(cliente20);
        java.lang.String str26 = cliente20.toString();
        int i27 = cliente5.compareTo(cliente20);
        java.util.Set<Viagem> set_viagem28 = cliente5.getHistorico();
        java.util.GregorianCalendar gregorianCalendar29 = null;
        java.util.GregorianCalendar gregorianCalendar30 = null;
        try {
            java.util.List<Viagem> list_viagem31 = cliente5.viagensEntreDatas(gregorianCalendar29, gregorianCalendar30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem22);
        org.junit.Assert.assertNotNull(cliente23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str26.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue(i27 == 0);
        org.junit.Assert.assertNotNull(set_viagem28);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        Cliente cliente14 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente20 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str21 = cliente20.getMail();
        java.util.Set<Viagem> set_viagem22 = cliente20.getHistorico();
        Cliente cliente23 = cliente20.clone();
        java.lang.String str24 = cliente20.getMail();
        int i25 = cliente14.compareTo(cliente20);
        java.lang.String str26 = cliente20.toString();
        int i27 = cliente5.compareTo(cliente20);
        Cliente cliente28 = new Cliente(cliente20);
        Cliente cliente34 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str35 = cliente34.getMail();
        cliente34.setMS(10.0d);
        java.lang.String str38 = cliente34.getMail();
        java.lang.String str39 = cliente34.getMorada();
        java.lang.String str40 = cliente34.getNome();
        int i41 = cliente20.compareTo((Ator) cliente34);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem22);
        org.junit.Assert.assertNotNull(cliente23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str26.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue(i27 == 0);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!" + "'", str35.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "hi!" + "'", str38.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "hi!" + "'", str39.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "" + "'", str40.equals(""));
        org.junit.Assert.assertTrue(i41 == 0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        cliente5.setMS(10.0d);
        java.util.Set<Viagem> set_viagem9 = cliente5.getHistorico();
        double d10 = cliente5.getMS();
        Cliente cliente11 = null;
        try {
            int i12 = cliente5.compareTo(cliente11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem9);
        org.junit.Assert.assertTrue(d10 == 10.0d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        Cliente cliente0 = new Cliente();
        cliente0.setMS((double) 100);
        Cliente cliente3 = new Cliente(cliente0);
        Cliente cliente4 = new Cliente(cliente0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        Cliente cliente5 = new Cliente("", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "hi!", "");
        java.lang.String str6 = cliente5.toString();
        cliente5.setMS((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "E-mail: \nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str6.equals("E-mail: \nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        java.lang.String str18 = cliente11.getNome();
        Cliente cliente19 = cliente11.clone();
        Cliente cliente20 = cliente19.clone();
        Cliente cliente21 = cliente19.clone();
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertNotNull(cliente19);
        org.junit.Assert.assertNotNull(cliente20);
        org.junit.Assert.assertNotNull(cliente21);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        java.lang.String str10 = cliente5.getNome();
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente22 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str23 = cliente22.getMail();
        java.util.Set<Viagem> set_viagem24 = cliente22.getHistorico();
        Cliente cliente25 = cliente22.clone();
        java.lang.String str26 = cliente22.getMail();
        int i27 = cliente16.compareTo(cliente22);
        java.lang.String str28 = cliente22.toString();
        Cliente cliente34 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente40 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str41 = cliente40.getMail();
        java.util.Set<Viagem> set_viagem42 = cliente40.getHistorico();
        Cliente cliente43 = cliente40.clone();
        java.lang.String str44 = cliente40.getMail();
        int i45 = cliente34.compareTo(cliente40);
        int i46 = cliente22.compareTo((Ator) cliente40);
        cliente22.setMS((double) 10L);
        int i49 = cliente5.compareTo((Ator) cliente22);
        java.lang.String str50 = cliente22.getMail();
        double d51 = cliente22.getMS();
        double d52 = cliente22.getMS();
        Viagem viagem53 = null;
        try {
            cliente22.registaViagem(viagem53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem24);
        org.junit.Assert.assertNotNull(cliente25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
        org.junit.Assert.assertTrue(i27 == 0);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str28.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "hi!" + "'", str41.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem42);
        org.junit.Assert.assertNotNull(cliente43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "hi!" + "'", str44.equals("hi!"));
        org.junit.Assert.assertTrue(i45 == 0);
        org.junit.Assert.assertTrue(i46 == 0);
        org.junit.Assert.assertTrue(i49 == 0);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "hi!" + "'", str50.equals("hi!"));
        org.junit.Assert.assertTrue(d51 == 10.0d);
        org.junit.Assert.assertTrue(d52 == 10.0d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        Cliente cliente15 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente21 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str22 = cliente21.getMail();
        java.util.Set<Viagem> set_viagem23 = cliente21.getHistorico();
        Cliente cliente24 = cliente21.clone();
        java.lang.String str25 = cliente21.getMail();
        int i26 = cliente15.compareTo(cliente21);
        java.lang.String str27 = cliente21.toString();
        Cliente cliente33 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente39 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str40 = cliente39.getMail();
        java.util.Set<Viagem> set_viagem41 = cliente39.getHistorico();
        Cliente cliente42 = cliente39.clone();
        java.lang.String str43 = cliente39.getMail();
        int i44 = cliente33.compareTo(cliente39);
        int i45 = cliente21.compareTo((Ator) cliente39);
        cliente21.setMS(0.0d);
        java.lang.String str48 = cliente21.getNome();
        java.lang.String str49 = cliente21.getPassword();
        Cliente cliente55 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str56 = cliente55.getMail();
        java.util.Set<Viagem> set_viagem57 = cliente55.getHistorico();
        Cliente cliente58 = cliente55.clone();
        java.lang.String str59 = cliente55.getMail();
        int i60 = cliente21.compareTo((Ator) cliente55);
        java.util.Set<Viagem> set_viagem61 = cliente21.getHistorico();
        Cliente cliente63 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: -1.00\n", "hi!", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 1.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", set_viagem61, (double) (-1.0f));
        Cliente cliente65 = new Cliente("hi!", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: \nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nPassword: \nMorada: hi!\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\nMontante de dinheiro utilizado no serviço UMeR: 3.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nPassword: \nMorada: hi!\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\nMontante de dinheiro utilizado no serviço UMeR: 3.00\n", "", set_viagem61, (double) (-1L));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!" + "'", str22.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem23);
        org.junit.Assert.assertNotNull(cliente24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
        org.junit.Assert.assertTrue(i26 == 0);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str27.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "hi!" + "'", str40.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem41);
        org.junit.Assert.assertNotNull(cliente42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "hi!" + "'", str43.equals("hi!"));
        org.junit.Assert.assertTrue(i44 == 0);
        org.junit.Assert.assertTrue(i45 == 0);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "" + "'", str48.equals(""));
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "" + "'", str49.equals(""));
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "hi!" + "'", str56.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem57);
        org.junit.Assert.assertNotNull(cliente58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "hi!" + "'", str59.equals("hi!"));
        org.junit.Assert.assertTrue(i60 == 0);
        org.junit.Assert.assertNotNull(set_viagem61);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        Cliente cliente5 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "", "hi!", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n");
        Cliente cliente6 = cliente5.clone();
        cliente5.setMS((double) 3);
        Cliente cliente9 = null;
        try {
            int i10 = cliente5.compareTo(cliente9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(cliente6);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        java.util.Set<Viagem> set_viagem18 = cliente11.getHistorico();
        java.lang.String str19 = cliente11.toString();
        java.lang.String str20 = cliente11.getMail();
        Cliente cliente21 = new Cliente(cliente11);
        Cliente cliente27 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente33 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str34 = cliente33.getMail();
        java.util.Set<Viagem> set_viagem35 = cliente33.getHistorico();
        Cliente cliente36 = cliente33.clone();
        java.lang.String str37 = cliente33.getMail();
        int i38 = cliente27.compareTo(cliente33);
        java.lang.String str39 = cliente33.toString();
        java.util.Set<Viagem> set_viagem40 = cliente33.getHistorico();
        boolean b41 = cliente11.equals((java.lang.Object) set_viagem40);
        Cliente cliente42 = cliente11.clone();
        boolean b44 = cliente11.equals((java.lang.Object) 10);
        java.lang.String str45 = cliente11.getMorada();
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str19.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem35);
        org.junit.Assert.assertNotNull(cliente36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
        org.junit.Assert.assertTrue(i38 == 0);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str39.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertNotNull(set_viagem40);
        org.junit.Assert.assertTrue(b41 == false);
        org.junit.Assert.assertNotNull(cliente42);
        org.junit.Assert.assertTrue(b44 == false);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "hi!" + "'", str45.equals("hi!"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        Cliente cliente5 = new Cliente("E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: -1.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nPassword: \nMorada: hi!\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\nMontante de dinheiro utilizado no serviço UMeR: 3.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n");
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        Cliente cliente5 = new Cliente("E-mail: \nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: \nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n");
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        cliente5.setMS(10.0d);
        java.lang.String str9 = cliente5.getMail();
        java.lang.String str10 = cliente5.getMorada();
        try {
            Viagem viagem11 = cliente5.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        Cliente cliente14 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente20 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str21 = cliente20.getMail();
        java.util.Set<Viagem> set_viagem22 = cliente20.getHistorico();
        Cliente cliente23 = cliente20.clone();
        java.lang.String str24 = cliente20.getMail();
        int i25 = cliente14.compareTo(cliente20);
        java.lang.String str26 = cliente20.toString();
        int i27 = cliente5.compareTo(cliente20);
        Cliente cliente33 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str34 = cliente33.getMail();
        java.util.Set<Viagem> set_viagem35 = cliente33.getHistorico();
        Cliente cliente36 = cliente33.clone();
        java.lang.String str37 = cliente33.getMail();
        java.lang.String str38 = cliente33.getNome();
        boolean b39 = cliente20.equals((java.lang.Object) str38);
        java.lang.String str40 = cliente20.getMail();
        java.util.Set<Viagem> set_viagem41 = cliente20.getHistorico();
        Cliente cliente42 = new Cliente(cliente20);
        Cliente cliente43 = cliente20.clone();
        Cliente cliente49 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente55 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str56 = cliente55.getMail();
        java.util.Set<Viagem> set_viagem57 = cliente55.getHistorico();
        Cliente cliente58 = cliente55.clone();
        java.lang.String str59 = cliente55.getMail();
        int i60 = cliente49.compareTo(cliente55);
        java.lang.String str61 = cliente55.toString();
        Cliente cliente67 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente73 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str74 = cliente73.getMail();
        java.util.Set<Viagem> set_viagem75 = cliente73.getHistorico();
        Cliente cliente76 = cliente73.clone();
        java.lang.String str77 = cliente73.getMail();
        int i78 = cliente67.compareTo(cliente73);
        int i79 = cliente55.compareTo((Ator) cliente73);
        Cliente cliente85 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str86 = cliente85.getMail();
        java.util.Set<Viagem> set_viagem87 = cliente85.getHistorico();
        Cliente cliente88 = cliente85.clone();
        int i89 = cliente55.compareTo(cliente85);
        java.lang.String str90 = cliente85.getMorada();
        Cliente cliente91 = cliente85.clone();
        Cliente cliente92 = cliente85.clone();
        int i93 = cliente20.compareTo((Ator) cliente85);
        java.lang.String str94 = cliente85.toString();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem22);
        org.junit.Assert.assertNotNull(cliente23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str26.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue(i27 == 0);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem35);
        org.junit.Assert.assertNotNull(cliente36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
        org.junit.Assert.assertTrue(b39 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "hi!" + "'", str40.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem41);
        org.junit.Assert.assertNotNull(cliente43);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "hi!" + "'", str56.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem57);
        org.junit.Assert.assertNotNull(cliente58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "hi!" + "'", str59.equals("hi!"));
        org.junit.Assert.assertTrue(i60 == 0);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str61.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "hi!" + "'", str74.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem75);
        org.junit.Assert.assertNotNull(cliente76);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "hi!" + "'", str77.equals("hi!"));
        org.junit.Assert.assertTrue(i78 == 0);
        org.junit.Assert.assertTrue(i79 == 0);
        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "hi!" + "'", str86.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem87);
        org.junit.Assert.assertNotNull(cliente88);
        org.junit.Assert.assertTrue(i89 == 0);
        org.junit.Assert.assertTrue("'" + str90 + "' != '" + "hi!" + "'", str90.equals("hi!"));
        org.junit.Assert.assertNotNull(cliente91);
        org.junit.Assert.assertNotNull(cliente92);
        org.junit.Assert.assertTrue(i93 == 0);
        org.junit.Assert.assertTrue("'" + str94 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str94.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        Cliente cliente0 = new Cliente();
        cliente0.setMS((double) 100);
        Cliente cliente8 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str9 = cliente8.getMail();
        java.util.Set<Viagem> set_viagem10 = cliente8.getHistorico();
        Cliente cliente11 = cliente8.clone();
        Cliente cliente17 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente23 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str24 = cliente23.getMail();
        java.util.Set<Viagem> set_viagem25 = cliente23.getHistorico();
        Cliente cliente26 = cliente23.clone();
        java.lang.String str27 = cliente23.getMail();
        int i28 = cliente17.compareTo(cliente23);
        java.lang.String str29 = cliente23.toString();
        int i30 = cliente8.compareTo(cliente23);
        int i31 = cliente0.compareTo(cliente8);
        Cliente cliente37 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str38 = cliente37.getMail();
        java.util.Set<Viagem> set_viagem39 = cliente37.getHistorico();
        Cliente cliente40 = cliente37.clone();
        Cliente cliente46 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente52 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str53 = cliente52.getMail();
        java.util.Set<Viagem> set_viagem54 = cliente52.getHistorico();
        Cliente cliente55 = cliente52.clone();
        java.lang.String str56 = cliente52.getMail();
        int i57 = cliente46.compareTo(cliente52);
        java.lang.String str58 = cliente52.toString();
        int i59 = cliente37.compareTo(cliente52);
        Cliente cliente60 = new Cliente(cliente52);
        Cliente cliente61 = new Cliente(cliente60);
        int i62 = cliente0.compareTo((Ator) cliente60);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem10);
        org.junit.Assert.assertNotNull(cliente11);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem25);
        org.junit.Assert.assertNotNull(cliente26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "hi!" + "'", str27.equals("hi!"));
        org.junit.Assert.assertTrue(i28 == 0);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str29.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue(i30 == 0);
        org.junit.Assert.assertTrue(i31 == (-3));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "hi!" + "'", str38.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem39);
        org.junit.Assert.assertNotNull(cliente40);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "hi!" + "'", str53.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem54);
        org.junit.Assert.assertNotNull(cliente55);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "hi!" + "'", str56.equals("hi!"));
        org.junit.Assert.assertTrue(i57 == 0);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str58.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue(i59 == 0);
        org.junit.Assert.assertTrue(i62 == (-3));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        Cliente cliente23 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente29 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str30 = cliente29.getMail();
        java.util.Set<Viagem> set_viagem31 = cliente29.getHistorico();
        Cliente cliente32 = cliente29.clone();
        java.lang.String str33 = cliente29.getMail();
        int i34 = cliente23.compareTo(cliente29);
        int i35 = cliente11.compareTo((Ator) cliente29);
        Cliente cliente36 = cliente11.clone();
        Cliente cliente37 = new Cliente(cliente36);
        Cliente cliente48 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "hi!", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n");
        Cliente cliente54 = new Cliente("hi!", "", "", "hi!", "");
        int i55 = cliente48.compareTo(cliente54);
        java.util.Set<Viagem> set_viagem56 = cliente54.getHistorico();
        java.util.Set<Viagem> set_viagem57 = cliente54.getHistorico();
        Cliente cliente59 = new Cliente("E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: \nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: \nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", set_viagem57, 0.0d);
        java.lang.String str60 = cliente59.getMorada();
        Cliente cliente66 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str67 = cliente66.getMail();
        java.util.Set<Viagem> set_viagem68 = cliente66.getHistorico();
        Cliente cliente69 = cliente66.clone();
        Cliente cliente75 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente81 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str82 = cliente81.getMail();
        java.util.Set<Viagem> set_viagem83 = cliente81.getHistorico();
        Cliente cliente84 = cliente81.clone();
        java.lang.String str85 = cliente81.getMail();
        int i86 = cliente75.compareTo(cliente81);
        java.lang.String str87 = cliente81.toString();
        int i88 = cliente66.compareTo(cliente81);
        double d89 = cliente81.getMS();
        double d90 = cliente81.getMS();
        boolean b91 = cliente59.equals((java.lang.Object) cliente81);
        int i92 = cliente36.compareTo(cliente81);
        java.lang.String str93 = cliente36.getMail();
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem31);
        org.junit.Assert.assertNotNull(cliente32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertTrue(i34 == 0);
        org.junit.Assert.assertTrue(i35 == 0);
        org.junit.Assert.assertNotNull(cliente36);
        org.junit.Assert.assertTrue(i55 == (-35));
        org.junit.Assert.assertNotNull(set_viagem56);
        org.junit.Assert.assertNotNull(set_viagem57);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "" + "'", str60.equals(""));
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "hi!" + "'", str67.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem68);
        org.junit.Assert.assertNotNull(cliente69);
        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "hi!" + "'", str82.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem83);
        org.junit.Assert.assertNotNull(cliente84);
        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "hi!" + "'", str85.equals("hi!"));
        org.junit.Assert.assertTrue(i86 == 0);
        org.junit.Assert.assertTrue("'" + str87 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str87.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue(i88 == 0);
        org.junit.Assert.assertTrue(d89 == 0.0d);
        org.junit.Assert.assertTrue(d90 == 0.0d);
        org.junit.Assert.assertTrue(b91 == false);
        org.junit.Assert.assertTrue(i92 == 0);
        org.junit.Assert.assertTrue("'" + str93 + "' != '" + "hi!" + "'", str93.equals("hi!"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        java.lang.String str10 = cliente5.getNome();
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente22 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str23 = cliente22.getMail();
        java.util.Set<Viagem> set_viagem24 = cliente22.getHistorico();
        Cliente cliente25 = cliente22.clone();
        java.lang.String str26 = cliente22.getMail();
        int i27 = cliente16.compareTo(cliente22);
        java.lang.String str28 = cliente22.toString();
        Cliente cliente34 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente40 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str41 = cliente40.getMail();
        java.util.Set<Viagem> set_viagem42 = cliente40.getHistorico();
        Cliente cliente43 = cliente40.clone();
        java.lang.String str44 = cliente40.getMail();
        int i45 = cliente34.compareTo(cliente40);
        int i46 = cliente22.compareTo((Ator) cliente40);
        cliente22.setMS((double) 10L);
        int i49 = cliente5.compareTo((Ator) cliente22);
        java.lang.String str50 = cliente22.getMail();
        double d51 = cliente22.getMS();
        double d52 = cliente22.getMS();
        cliente22.setMS((double) (short) 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem24);
        org.junit.Assert.assertNotNull(cliente25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
        org.junit.Assert.assertTrue(i27 == 0);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str28.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "hi!" + "'", str41.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem42);
        org.junit.Assert.assertNotNull(cliente43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "hi!" + "'", str44.equals("hi!"));
        org.junit.Assert.assertTrue(i45 == 0);
        org.junit.Assert.assertTrue(i46 == 0);
        org.junit.Assert.assertTrue(i49 == 0);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "hi!" + "'", str50.equals("hi!"));
        org.junit.Assert.assertTrue(d51 == 10.0d);
        org.junit.Assert.assertTrue(d52 == 10.0d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        Cliente cliente23 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente29 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str30 = cliente29.getMail();
        java.util.Set<Viagem> set_viagem31 = cliente29.getHistorico();
        Cliente cliente32 = cliente29.clone();
        java.lang.String str33 = cliente29.getMail();
        int i34 = cliente23.compareTo(cliente29);
        int i35 = cliente11.compareTo((Ator) cliente29);
        cliente11.setMS(0.0d);
        cliente11.setMS((double) (byte) 10);
        java.lang.String str40 = cliente11.getNome();
        Cliente cliente46 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str47 = cliente46.getMail();
        java.util.Set<Viagem> set_viagem48 = cliente46.getHistorico();
        Cliente cliente49 = cliente46.clone();
        Cliente cliente55 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente61 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str62 = cliente61.getMail();
        java.util.Set<Viagem> set_viagem63 = cliente61.getHistorico();
        Cliente cliente64 = cliente61.clone();
        java.lang.String str65 = cliente61.getMail();
        int i66 = cliente55.compareTo(cliente61);
        java.lang.String str67 = cliente61.toString();
        int i68 = cliente46.compareTo(cliente61);
        Cliente cliente74 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str75 = cliente74.getMail();
        java.util.Set<Viagem> set_viagem76 = cliente74.getHistorico();
        Cliente cliente77 = cliente74.clone();
        java.lang.String str78 = cliente74.getMail();
        java.lang.String str79 = cliente74.getNome();
        boolean b80 = cliente61.equals((java.lang.Object) str79);
        java.lang.String str81 = cliente61.getMail();
        int i82 = cliente11.compareTo((Ator) cliente61);
        Cliente cliente83 = new Cliente(cliente11);
        try {
            Viagem viagem84 = cliente83.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem31);
        org.junit.Assert.assertNotNull(cliente32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertTrue(i34 == 0);
        org.junit.Assert.assertTrue(i35 == 0);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "" + "'", str40.equals(""));
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "hi!" + "'", str47.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem48);
        org.junit.Assert.assertNotNull(cliente49);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "hi!" + "'", str62.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem63);
        org.junit.Assert.assertNotNull(cliente64);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "hi!" + "'", str65.equals("hi!"));
        org.junit.Assert.assertTrue(i66 == 0);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str67.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue(i68 == 0);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "hi!" + "'", str75.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem76);
        org.junit.Assert.assertNotNull(cliente77);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "hi!" + "'", str78.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "" + "'", str79.equals(""));
        org.junit.Assert.assertTrue(b80 == false);
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "hi!" + "'", str81.equals("hi!"));
        org.junit.Assert.assertTrue(i82 == 0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        cliente5.setMS((double) '4');
        java.lang.String str12 = cliente5.toString();
        java.lang.Object obj13 = new java.lang.Object();
        boolean b14 = cliente5.equals(obj13);
        java.util.Set<Viagem> set_viagem15 = cliente5.getHistorico();
        java.lang.String str16 = cliente5.getMail();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n" + "'", str12.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n"));
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertNotNull(set_viagem15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        cliente5.setMS(10.0d);
        java.lang.String str9 = cliente5.getMail();
        java.lang.String str10 = cliente5.getNome();
        java.util.GregorianCalendar gregorianCalendar11 = null;
        java.util.GregorianCalendar gregorianCalendar12 = null;
        try {
            java.util.List<Viagem> list_viagem13 = cliente5.viagensEntreDatas(gregorianCalendar11, gregorianCalendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        Cliente cliente23 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente29 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str30 = cliente29.getMail();
        java.util.Set<Viagem> set_viagem31 = cliente29.getHistorico();
        Cliente cliente32 = cliente29.clone();
        java.lang.String str33 = cliente29.getMail();
        int i34 = cliente23.compareTo(cliente29);
        int i35 = cliente11.compareTo((Ator) cliente29);
        cliente11.setMS(0.0d);
        cliente11.setMS((double) (byte) 10);
        java.lang.String str40 = cliente11.getNome();
        java.lang.String str41 = cliente11.getDataDeNascimento();
        java.lang.String str42 = cliente11.getNome();
        Viagem viagem43 = null;
        try {
            cliente11.registaViagem(viagem43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem31);
        org.junit.Assert.assertNotNull(cliente32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertTrue(i34 == 0);
        org.junit.Assert.assertTrue(i35 == 0);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "" + "'", str40.equals(""));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "" + "'", str41.equals(""));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "" + "'", str42.equals(""));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        Cliente cliente14 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente20 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str21 = cliente20.getMail();
        java.util.Set<Viagem> set_viagem22 = cliente20.getHistorico();
        Cliente cliente23 = cliente20.clone();
        java.lang.String str24 = cliente20.getMail();
        int i25 = cliente14.compareTo(cliente20);
        java.lang.String str26 = cliente20.toString();
        int i27 = cliente5.compareTo(cliente20);
        Cliente cliente33 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str34 = cliente33.getMail();
        java.util.Set<Viagem> set_viagem35 = cliente33.getHistorico();
        Cliente cliente36 = cliente33.clone();
        java.lang.String str37 = cliente33.getMail();
        java.lang.String str38 = cliente33.getNome();
        boolean b39 = cliente20.equals((java.lang.Object) str38);
        java.lang.String str40 = cliente20.getMail();
        java.util.Set<Viagem> set_viagem41 = cliente20.getHistorico();
        Cliente cliente42 = new Cliente(cliente20);
        Cliente cliente43 = cliente20.clone();
        try {
            Viagem viagem44 = cliente20.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem22);
        org.junit.Assert.assertNotNull(cliente23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str26.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue(i27 == 0);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "hi!" + "'", str34.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem35);
        org.junit.Assert.assertNotNull(cliente36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
        org.junit.Assert.assertTrue(b39 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "hi!" + "'", str40.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem41);
        org.junit.Assert.assertNotNull(cliente43);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        Cliente cliente14 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente20 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str21 = cliente20.getMail();
        java.util.Set<Viagem> set_viagem22 = cliente20.getHistorico();
        Cliente cliente23 = cliente20.clone();
        java.lang.String str24 = cliente20.getMail();
        int i25 = cliente14.compareTo(cliente20);
        java.lang.String str26 = cliente20.toString();
        int i27 = cliente5.compareTo(cliente20);
        java.lang.String str28 = cliente5.toString();
        Cliente cliente29 = new Cliente(cliente5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem22);
        org.junit.Assert.assertNotNull(cliente23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str26.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue(i27 == 0);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str28.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.toString();
        java.lang.String str7 = cliente5.toString();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str6.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str7.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        cliente5.setMS(10.0d);
        java.lang.String str9 = cliente5.getMail();
        java.lang.String str10 = cliente5.getMorada();
        java.lang.String str11 = cliente5.getNome();
        double d12 = cliente5.getMS();
        java.util.GregorianCalendar gregorianCalendar13 = null;
        java.util.GregorianCalendar gregorianCalendar14 = null;
        try {
            java.util.List<Viagem> list_viagem15 = cliente5.viagensEntreDatas(gregorianCalendar13, gregorianCalendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue(d12 == 10.0d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        java.lang.String str10 = cliente5.getNome();
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente22 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str23 = cliente22.getMail();
        java.util.Set<Viagem> set_viagem24 = cliente22.getHistorico();
        Cliente cliente25 = cliente22.clone();
        java.lang.String str26 = cliente22.getMail();
        int i27 = cliente16.compareTo(cliente22);
        java.lang.String str28 = cliente22.toString();
        Cliente cliente34 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente40 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str41 = cliente40.getMail();
        java.util.Set<Viagem> set_viagem42 = cliente40.getHistorico();
        Cliente cliente43 = cliente40.clone();
        java.lang.String str44 = cliente40.getMail();
        int i45 = cliente34.compareTo(cliente40);
        int i46 = cliente22.compareTo((Ator) cliente40);
        cliente22.setMS((double) 10L);
        int i49 = cliente5.compareTo((Ator) cliente22);
        java.lang.String str50 = cliente22.getMail();
        java.lang.String str51 = cliente22.getNome();
        java.lang.String str52 = cliente22.getMorada();
        java.lang.String str53 = cliente22.getPassword();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem24);
        org.junit.Assert.assertNotNull(cliente25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "hi!" + "'", str26.equals("hi!"));
        org.junit.Assert.assertTrue(i27 == 0);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str28.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "hi!" + "'", str41.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem42);
        org.junit.Assert.assertNotNull(cliente43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "hi!" + "'", str44.equals("hi!"));
        org.junit.Assert.assertTrue(i45 == 0);
        org.junit.Assert.assertTrue(i46 == 0);
        org.junit.Assert.assertTrue(i49 == 0);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "hi!" + "'", str50.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "" + "'", str51.equals(""));
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "hi!" + "'", str52.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "" + "'", str53.equals(""));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        cliente5.setMS((double) '4');
        java.lang.String str12 = cliente5.getPassword();
        java.lang.String str13 = cliente5.toString();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertNotNull(cliente8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n" + "'", str13.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        Cliente cliente23 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente29 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str30 = cliente29.getMail();
        java.util.Set<Viagem> set_viagem31 = cliente29.getHistorico();
        Cliente cliente32 = cliente29.clone();
        java.lang.String str33 = cliente29.getMail();
        int i34 = cliente23.compareTo(cliente29);
        int i35 = cliente11.compareTo((Ator) cliente29);
        cliente11.setMS(0.0d);
        boolean b39 = cliente11.equals((java.lang.Object) 0);
        java.lang.String str40 = cliente11.getDataDeNascimento();
        java.lang.String str41 = cliente11.toString();
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertNotNull(cliente14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str17.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertNotNull(set_viagem31);
        org.junit.Assert.assertNotNull(cliente32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "hi!" + "'", str33.equals("hi!"));
        org.junit.Assert.assertTrue(i34 == 0);
        org.junit.Assert.assertTrue(i35 == 0);
        org.junit.Assert.assertTrue(b39 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "" + "'", str40.equals(""));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n" + "'", str41.equals("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n"));
    }
}

