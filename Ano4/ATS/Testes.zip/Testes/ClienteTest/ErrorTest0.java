import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ErrorTest0 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test01");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        java.lang.String str10 = cliente5.getNome();
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente22 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str23 = cliente22.getMail();
        java.util.Set<Viagem> set_viagem24 = cliente22.getHistorico();
        Cliente cliente25 = cliente22.clone();
        java.lang.String str26 = cliente22.getMail();
        int i27 = cliente16.compareTo(cliente22);
        java.lang.String str28 = cliente22.toString();
        Cliente cliente34 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente40 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str41 = cliente40.getMail();
        java.util.Set<Viagem> set_viagem42 = cliente40.getHistorico();
        Cliente cliente43 = cliente40.clone();
        java.lang.String str44 = cliente40.getMail();
        int i45 = cliente34.compareTo(cliente40);
        int i46 = cliente22.compareTo((Ator) cliente40);
        cliente22.setMS((double) 10L);
        int i49 = cliente5.compareTo((Ator) cliente22);
        java.lang.String str50 = cliente5.getDataDeNascimento();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on cliente8 and cliente22", (cliente8.compareTo(cliente22) == 0) == cliente8.equals(cliente22));
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test02");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        java.lang.String str10 = cliente5.getNome();
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente22 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str23 = cliente22.getMail();
        java.util.Set<Viagem> set_viagem24 = cliente22.getHistorico();
        Cliente cliente25 = cliente22.clone();
        java.lang.String str26 = cliente22.getMail();
        int i27 = cliente16.compareTo(cliente22);
        java.lang.String str28 = cliente22.toString();
        Cliente cliente34 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente40 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str41 = cliente40.getMail();
        java.util.Set<Viagem> set_viagem42 = cliente40.getHistorico();
        Cliente cliente43 = cliente40.clone();
        java.lang.String str44 = cliente40.getMail();
        int i45 = cliente34.compareTo(cliente40);
        int i46 = cliente22.compareTo((Ator) cliente40);
        cliente22.setMS((double) 10L);
        int i49 = cliente5.compareTo((Ator) cliente22);
        java.lang.String str50 = cliente5.getNome();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on cliente40 and cliente22", (cliente40.compareTo(cliente22) == 0) == cliente40.equals(cliente22));
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test03");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        Cliente cliente14 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente20 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str21 = cliente20.getMail();
        java.util.Set<Viagem> set_viagem22 = cliente20.getHistorico();
        Cliente cliente23 = cliente20.clone();
        java.lang.String str24 = cliente20.getMail();
        int i25 = cliente14.compareTo(cliente20);
        java.lang.String str26 = cliente20.toString();
        int i27 = cliente5.compareTo(cliente20);
        Cliente cliente28 = new Cliente(cliente20);
        Cliente cliente34 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str35 = cliente34.getMail();
        java.util.Set<Viagem> set_viagem36 = cliente34.getHistorico();
        Cliente cliente37 = cliente34.clone();
        java.lang.String str38 = cliente34.getMail();
        java.lang.String str39 = cliente34.getNome();
        Cliente cliente45 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente51 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str52 = cliente51.getMail();
        java.util.Set<Viagem> set_viagem53 = cliente51.getHistorico();
        Cliente cliente54 = cliente51.clone();
        java.lang.String str55 = cliente51.getMail();
        int i56 = cliente45.compareTo(cliente51);
        java.lang.String str57 = cliente51.toString();
        Cliente cliente63 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente69 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str70 = cliente69.getMail();
        java.util.Set<Viagem> set_viagem71 = cliente69.getHistorico();
        Cliente cliente72 = cliente69.clone();
        java.lang.String str73 = cliente69.getMail();
        int i74 = cliente63.compareTo(cliente69);
        int i75 = cliente51.compareTo((Ator) cliente69);
        cliente51.setMS((double) 10L);
        int i78 = cliente34.compareTo((Ator) cliente51);
        int i79 = cliente28.compareTo(cliente34);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on cliente63 and cliente51", (cliente63.compareTo(cliente51) == 0) == cliente63.equals(cliente51));
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test04");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        java.lang.String str10 = cliente5.getNome();
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente22 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str23 = cliente22.getMail();
        java.util.Set<Viagem> set_viagem24 = cliente22.getHistorico();
        Cliente cliente25 = cliente22.clone();
        java.lang.String str26 = cliente22.getMail();
        int i27 = cliente16.compareTo(cliente22);
        java.lang.String str28 = cliente22.toString();
        Cliente cliente34 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente40 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str41 = cliente40.getMail();
        java.util.Set<Viagem> set_viagem42 = cliente40.getHistorico();
        Cliente cliente43 = cliente40.clone();
        java.lang.String str44 = cliente40.getMail();
        int i45 = cliente34.compareTo(cliente40);
        int i46 = cliente22.compareTo((Ator) cliente40);
        cliente22.setMS((double) 10L);
        int i49 = cliente5.compareTo((Ator) cliente22);
        java.lang.String str50 = cliente22.getMail();
        double d51 = cliente22.getMS();
        Cliente cliente52 = cliente22.clone();
        java.lang.String str53 = cliente22.getPassword();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on cliente8 and cliente52", (cliente8.compareTo(cliente52) == 0) == cliente8.equals(cliente52));
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test05");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        java.lang.String str10 = cliente5.getNome();
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente22 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str23 = cliente22.getMail();
        java.util.Set<Viagem> set_viagem24 = cliente22.getHistorico();
        Cliente cliente25 = cliente22.clone();
        java.lang.String str26 = cliente22.getMail();
        int i27 = cliente16.compareTo(cliente22);
        java.lang.String str28 = cliente22.toString();
        Cliente cliente34 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente40 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str41 = cliente40.getMail();
        java.util.Set<Viagem> set_viagem42 = cliente40.getHistorico();
        Cliente cliente43 = cliente40.clone();
        java.lang.String str44 = cliente40.getMail();
        int i45 = cliente34.compareTo(cliente40);
        int i46 = cliente22.compareTo((Ator) cliente40);
        cliente22.setMS((double) 10L);
        int i49 = cliente5.compareTo((Ator) cliente22);
        java.lang.String str50 = cliente22.getMail();
        Cliente cliente51 = cliente22.clone();
        Cliente cliente57 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str58 = cliente57.getMail();
        java.util.Set<Viagem> set_viagem59 = cliente57.getHistorico();
        Cliente cliente60 = cliente57.clone();
        Cliente cliente66 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente72 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str73 = cliente72.getMail();
        java.util.Set<Viagem> set_viagem74 = cliente72.getHistorico();
        Cliente cliente75 = cliente72.clone();
        java.lang.String str76 = cliente72.getMail();
        int i77 = cliente66.compareTo(cliente72);
        java.lang.String str78 = cliente72.toString();
        int i79 = cliente57.compareTo(cliente72);
        Cliente cliente80 = new Cliente(cliente72);
        java.lang.String str81 = cliente80.getMorada();
        int i82 = cliente51.compareTo((Ator) cliente80);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on cliente66 and cliente22", (cliente66.compareTo(cliente22) == 0) == cliente66.equals(cliente22));
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test06");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        cliente5.setMS(10.0d);
        Cliente cliente14 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str15 = cliente14.getMail();
        java.util.Set<Viagem> set_viagem16 = cliente14.getHistorico();
        Cliente cliente17 = cliente14.clone();
        java.lang.String str18 = cliente14.getMail();
        cliente14.setMS((double) '4');
        java.lang.String str21 = cliente14.getPassword();
        int i22 = cliente5.compareTo(cliente14);
        java.util.Set<Viagem> set_viagem23 = cliente5.getHistorico();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on cliente17 and cliente14", (cliente17.compareTo(cliente14) == 0) == cliente17.equals(cliente14));
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test07");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.toString();
        Cliente cliente12 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str13 = cliente12.getMail();
        java.util.Set<Viagem> set_viagem14 = cliente12.getHistorico();
        Cliente cliente15 = cliente12.clone();
        java.lang.String str16 = cliente12.getMail();
        java.lang.String str17 = cliente12.getNome();
        Cliente cliente23 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente29 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str30 = cliente29.getMail();
        java.util.Set<Viagem> set_viagem31 = cliente29.getHistorico();
        Cliente cliente32 = cliente29.clone();
        java.lang.String str33 = cliente29.getMail();
        int i34 = cliente23.compareTo(cliente29);
        java.lang.String str35 = cliente29.toString();
        Cliente cliente41 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente47 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str48 = cliente47.getMail();
        java.util.Set<Viagem> set_viagem49 = cliente47.getHistorico();
        Cliente cliente50 = cliente47.clone();
        java.lang.String str51 = cliente47.getMail();
        int i52 = cliente41.compareTo(cliente47);
        int i53 = cliente29.compareTo((Ator) cliente47);
        cliente29.setMS((double) 10L);
        int i56 = cliente12.compareTo((Ator) cliente29);
        int i57 = cliente5.compareTo(cliente12);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on cliente29 and cliente50", (cliente29.compareTo(cliente50) == 0) == cliente29.equals(cliente50));
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test08");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        java.lang.String str10 = cliente5.getNome();
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente22 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str23 = cliente22.getMail();
        java.util.Set<Viagem> set_viagem24 = cliente22.getHistorico();
        Cliente cliente25 = cliente22.clone();
        java.lang.String str26 = cliente22.getMail();
        int i27 = cliente16.compareTo(cliente22);
        java.lang.String str28 = cliente22.toString();
        Cliente cliente34 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente40 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str41 = cliente40.getMail();
        java.util.Set<Viagem> set_viagem42 = cliente40.getHistorico();
        Cliente cliente43 = cliente40.clone();
        java.lang.String str44 = cliente40.getMail();
        int i45 = cliente34.compareTo(cliente40);
        int i46 = cliente22.compareTo((Ator) cliente40);
        cliente22.setMS((double) 10L);
        int i49 = cliente5.compareTo((Ator) cliente22);
        java.lang.String str50 = cliente22.getMail();
        double d51 = cliente22.getMS();
        Cliente cliente52 = cliente22.clone();
        cliente22.setMS((double) (byte) 10);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on cliente52 and cliente25", (cliente52.compareTo(cliente25) == 0) == cliente52.equals(cliente25));
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test09");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        java.lang.String str10 = cliente5.getNome();
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente22 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str23 = cliente22.getMail();
        java.util.Set<Viagem> set_viagem24 = cliente22.getHistorico();
        Cliente cliente25 = cliente22.clone();
        java.lang.String str26 = cliente22.getMail();
        int i27 = cliente16.compareTo(cliente22);
        java.lang.String str28 = cliente22.toString();
        Cliente cliente34 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente40 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str41 = cliente40.getMail();
        java.util.Set<Viagem> set_viagem42 = cliente40.getHistorico();
        Cliente cliente43 = cliente40.clone();
        java.lang.String str44 = cliente40.getMail();
        int i45 = cliente34.compareTo(cliente40);
        int i46 = cliente22.compareTo((Ator) cliente40);
        cliente22.setMS((double) 10L);
        int i49 = cliente5.compareTo((Ator) cliente22);
        java.lang.String str50 = cliente22.getMail();
        Cliente cliente51 = cliente22.clone();
        Cliente cliente52 = new Cliente(cliente22);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on cliente8 and cliente51", (cliente8.compareTo(cliente51) == 0) == cliente8.equals(cliente51));
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test10");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        cliente5.setMS(10.0d);
        Cliente cliente14 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str15 = cliente14.getMail();
        java.util.Set<Viagem> set_viagem16 = cliente14.getHistorico();
        Cliente cliente17 = cliente14.clone();
        java.lang.String str18 = cliente14.getMail();
        cliente14.setMS((double) '4');
        java.lang.String str21 = cliente14.getPassword();
        int i22 = cliente5.compareTo(cliente14);
        Cliente cliente23 = new Cliente();
        cliente23.setMS((double) 100);
        int i26 = cliente5.compareTo(cliente23);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on cliente14 and cliente17", (cliente14.compareTo(cliente17) == 0) == cliente14.equals(cliente17));
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test11");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        java.lang.String str10 = cliente5.getNome();
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente22 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str23 = cliente22.getMail();
        java.util.Set<Viagem> set_viagem24 = cliente22.getHistorico();
        Cliente cliente25 = cliente22.clone();
        java.lang.String str26 = cliente22.getMail();
        int i27 = cliente16.compareTo(cliente22);
        java.lang.String str28 = cliente22.toString();
        Cliente cliente34 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente40 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str41 = cliente40.getMail();
        java.util.Set<Viagem> set_viagem42 = cliente40.getHistorico();
        Cliente cliente43 = cliente40.clone();
        java.lang.String str44 = cliente40.getMail();
        int i45 = cliente34.compareTo(cliente40);
        int i46 = cliente22.compareTo((Ator) cliente40);
        cliente22.setMS((double) 10L);
        int i49 = cliente5.compareTo((Ator) cliente22);
        java.lang.String str50 = cliente22.getMail();
        double d51 = cliente22.getMS();
        Cliente cliente52 = cliente22.clone();
        java.util.Set<Viagem> set_viagem53 = cliente22.getHistorico();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on cliente40 and cliente52", (cliente40.compareTo(cliente52) == 0) == cliente40.equals(cliente52));
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test12");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        java.lang.String str10 = cliente5.getNome();
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente22 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str23 = cliente22.getMail();
        java.util.Set<Viagem> set_viagem24 = cliente22.getHistorico();
        Cliente cliente25 = cliente22.clone();
        java.lang.String str26 = cliente22.getMail();
        int i27 = cliente16.compareTo(cliente22);
        java.lang.String str28 = cliente22.toString();
        Cliente cliente34 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente40 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str41 = cliente40.getMail();
        java.util.Set<Viagem> set_viagem42 = cliente40.getHistorico();
        Cliente cliente43 = cliente40.clone();
        java.lang.String str44 = cliente40.getMail();
        int i45 = cliente34.compareTo(cliente40);
        int i46 = cliente22.compareTo((Ator) cliente40);
        cliente22.setMS((double) 10L);
        int i49 = cliente5.compareTo((Ator) cliente22);
        Cliente cliente50 = new Cliente(cliente22);
        java.lang.String str51 = cliente22.toString();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on cliente34 and cliente50", (cliente34.compareTo(cliente50) == 0) == cliente34.equals(cliente50));
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test13");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        java.lang.String str10 = cliente5.getNome();
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente22 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str23 = cliente22.getMail();
        java.util.Set<Viagem> set_viagem24 = cliente22.getHistorico();
        Cliente cliente25 = cliente22.clone();
        java.lang.String str26 = cliente22.getMail();
        int i27 = cliente16.compareTo(cliente22);
        java.lang.String str28 = cliente22.toString();
        Cliente cliente34 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente40 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str41 = cliente40.getMail();
        java.util.Set<Viagem> set_viagem42 = cliente40.getHistorico();
        Cliente cliente43 = cliente40.clone();
        java.lang.String str44 = cliente40.getMail();
        int i45 = cliente34.compareTo(cliente40);
        int i46 = cliente22.compareTo((Ator) cliente40);
        cliente22.setMS((double) 10L);
        int i49 = cliente5.compareTo((Ator) cliente22);
        java.lang.String str50 = cliente22.getMail();
        double d51 = cliente22.getMS();
        Cliente cliente62 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente68 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str69 = cliente68.getMail();
        java.util.Set<Viagem> set_viagem70 = cliente68.getHistorico();
        Cliente cliente71 = cliente68.clone();
        java.lang.String str72 = cliente68.getMail();
        int i73 = cliente62.compareTo(cliente68);
        java.lang.String str74 = cliente68.toString();
        java.util.Set<Viagem> set_viagem75 = cliente68.getHistorico();
        Cliente cliente77 = new Cliente("", "hi!", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "hi!", "hi!", set_viagem75, (double) 100L);
        int i78 = cliente22.compareTo(cliente77);
        java.lang.String str79 = cliente77.getPassword();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on cliente8 and cliente22", (cliente8.compareTo(cliente22) == 0) == cliente8.equals(cliente22));
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test14");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        java.lang.String str10 = cliente5.getNome();
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente22 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str23 = cliente22.getMail();
        java.util.Set<Viagem> set_viagem24 = cliente22.getHistorico();
        Cliente cliente25 = cliente22.clone();
        java.lang.String str26 = cliente22.getMail();
        int i27 = cliente16.compareTo(cliente22);
        java.lang.String str28 = cliente22.toString();
        Cliente cliente34 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente40 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str41 = cliente40.getMail();
        java.util.Set<Viagem> set_viagem42 = cliente40.getHistorico();
        Cliente cliente43 = cliente40.clone();
        java.lang.String str44 = cliente40.getMail();
        int i45 = cliente34.compareTo(cliente40);
        int i46 = cliente22.compareTo((Ator) cliente40);
        cliente22.setMS((double) 10L);
        int i49 = cliente5.compareTo((Ator) cliente22);
        java.lang.String str50 = cliente22.getMail();
        Cliente cliente51 = cliente22.clone();
        Cliente cliente52 = new Cliente(cliente51);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on cliente25 and cliente22", (cliente25.compareTo(cliente22) == 0) == cliente25.equals(cliente22));
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test15");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente8.getDataDeNascimento();
        java.lang.String str10 = cliente8.toString();
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str17 = cliente16.getMail();
        java.util.Set<Viagem> set_viagem18 = cliente16.getHistorico();
        Cliente cliente19 = cliente16.clone();
        java.lang.String str20 = cliente16.getMail();
        java.lang.String str21 = cliente16.getNome();
        Cliente cliente27 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente33 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str34 = cliente33.getMail();
        java.util.Set<Viagem> set_viagem35 = cliente33.getHistorico();
        Cliente cliente36 = cliente33.clone();
        java.lang.String str37 = cliente33.getMail();
        int i38 = cliente27.compareTo(cliente33);
        java.lang.String str39 = cliente33.toString();
        Cliente cliente45 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente51 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str52 = cliente51.getMail();
        java.util.Set<Viagem> set_viagem53 = cliente51.getHistorico();
        Cliente cliente54 = cliente51.clone();
        java.lang.String str55 = cliente51.getMail();
        int i56 = cliente45.compareTo(cliente51);
        int i57 = cliente33.compareTo((Ator) cliente51);
        cliente33.setMS((double) 10L);
        int i60 = cliente16.compareTo((Ator) cliente33);
        java.lang.String str61 = cliente33.getMorada();
        boolean b62 = cliente8.equals((java.lang.Object) str61);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on cliente5 and cliente33", (cliente5.compareTo(cliente33) == 0) == cliente5.equals(cliente33));
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test16");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        java.lang.String str10 = cliente5.getNome();
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente22 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str23 = cliente22.getMail();
        java.util.Set<Viagem> set_viagem24 = cliente22.getHistorico();
        Cliente cliente25 = cliente22.clone();
        java.lang.String str26 = cliente22.getMail();
        int i27 = cliente16.compareTo(cliente22);
        java.lang.String str28 = cliente22.toString();
        Cliente cliente34 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente40 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str41 = cliente40.getMail();
        java.util.Set<Viagem> set_viagem42 = cliente40.getHistorico();
        Cliente cliente43 = cliente40.clone();
        java.lang.String str44 = cliente40.getMail();
        int i45 = cliente34.compareTo(cliente40);
        int i46 = cliente22.compareTo((Ator) cliente40);
        cliente22.setMS((double) 10L);
        int i49 = cliente5.compareTo((Ator) cliente22);
        java.lang.String str50 = cliente22.getMail();
        double d51 = cliente22.getMS();
        java.lang.String str52 = cliente22.getMail();
        java.lang.String str53 = cliente22.getDataDeNascimento();
        Cliente cliente54 = cliente22.clone();
        java.lang.String str55 = cliente22.toString();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on cliente5 and cliente54", (cliente5.compareTo(cliente54) == 0) == cliente5.equals(cliente54));
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test17");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        java.lang.String str10 = cliente5.getNome();
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente22 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str23 = cliente22.getMail();
        java.util.Set<Viagem> set_viagem24 = cliente22.getHistorico();
        Cliente cliente25 = cliente22.clone();
        java.lang.String str26 = cliente22.getMail();
        int i27 = cliente16.compareTo(cliente22);
        java.lang.String str28 = cliente22.toString();
        Cliente cliente34 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente40 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str41 = cliente40.getMail();
        java.util.Set<Viagem> set_viagem42 = cliente40.getHistorico();
        Cliente cliente43 = cliente40.clone();
        java.lang.String str44 = cliente40.getMail();
        int i45 = cliente34.compareTo(cliente40);
        int i46 = cliente22.compareTo((Ator) cliente40);
        cliente22.setMS((double) 10L);
        int i49 = cliente5.compareTo((Ator) cliente22);
        java.lang.String str50 = cliente22.getMail();
        Cliente cliente51 = cliente22.clone();
        double d52 = cliente51.getMS();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on cliente5 and cliente22", (cliente5.compareTo(cliente22) == 0) == cliente5.equals(cliente22));
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test18");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente8.getPassword();
        cliente8.setMS((double) '4');
        Cliente cliente12 = cliente8.clone();
        java.lang.String str13 = cliente12.getPassword();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on cliente5 and cliente8", (cliente5.compareTo(cliente8) == 0) == cliente5.equals(cliente8));
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test19");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        java.lang.String str10 = cliente5.getNome();
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente22 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str23 = cliente22.getMail();
        java.util.Set<Viagem> set_viagem24 = cliente22.getHistorico();
        Cliente cliente25 = cliente22.clone();
        java.lang.String str26 = cliente22.getMail();
        int i27 = cliente16.compareTo(cliente22);
        java.lang.String str28 = cliente22.toString();
        Cliente cliente34 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente40 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str41 = cliente40.getMail();
        java.util.Set<Viagem> set_viagem42 = cliente40.getHistorico();
        Cliente cliente43 = cliente40.clone();
        java.lang.String str44 = cliente40.getMail();
        int i45 = cliente34.compareTo(cliente40);
        int i46 = cliente22.compareTo((Ator) cliente40);
        cliente22.setMS((double) 10L);
        int i49 = cliente5.compareTo((Ator) cliente22);
        java.lang.String str50 = cliente22.getMail();
        double d51 = cliente22.getMS();
        Cliente cliente52 = cliente22.clone();
        java.lang.String str53 = cliente52.getPassword();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on cliente5 and cliente22", (cliente5.compareTo(cliente22) == 0) == cliente5.equals(cliente22));
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test20");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        java.lang.String str10 = cliente5.getNome();
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente22 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str23 = cliente22.getMail();
        java.util.Set<Viagem> set_viagem24 = cliente22.getHistorico();
        Cliente cliente25 = cliente22.clone();
        java.lang.String str26 = cliente22.getMail();
        int i27 = cliente16.compareTo(cliente22);
        java.lang.String str28 = cliente22.toString();
        Cliente cliente34 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente40 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str41 = cliente40.getMail();
        java.util.Set<Viagem> set_viagem42 = cliente40.getHistorico();
        Cliente cliente43 = cliente40.clone();
        java.lang.String str44 = cliente40.getMail();
        int i45 = cliente34.compareTo(cliente40);
        int i46 = cliente22.compareTo((Ator) cliente40);
        cliente22.setMS((double) 10L);
        int i49 = cliente5.compareTo((Ator) cliente22);
        java.lang.String str50 = cliente22.getMail();
        double d51 = cliente22.getMS();
        Cliente cliente52 = cliente22.clone();
        Cliente cliente53 = new Cliente(cliente22);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on cliente16 and cliente52", (cliente16.compareTo(cliente52) == 0) == cliente16.equals(cliente52));
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test21");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        cliente5.setMS(10.0d);
        Cliente cliente14 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str15 = cliente14.getMail();
        java.util.Set<Viagem> set_viagem16 = cliente14.getHistorico();
        Cliente cliente17 = cliente14.clone();
        java.lang.String str18 = cliente14.getMail();
        cliente14.setMS((double) '4');
        java.lang.String str21 = cliente14.getPassword();
        int i22 = cliente5.compareTo(cliente14);
        java.lang.String str23 = cliente14.getNome();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on cliente5 and cliente17", (cliente5.compareTo(cliente17) == 0) == cliente5.equals(cliente17));
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test22");
        Cliente cliente5 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "", "hi!", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n");
        Cliente cliente6 = cliente5.clone();
        Cliente cliente7 = new Cliente(cliente6);
        Cliente cliente13 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str14 = cliente13.getMail();
        java.util.Set<Viagem> set_viagem15 = cliente13.getHistorico();
        Cliente cliente16 = cliente13.clone();
        java.lang.String str17 = cliente13.getMail();
        java.lang.String str18 = cliente13.getNome();
        Cliente cliente24 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente30 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str31 = cliente30.getMail();
        java.util.Set<Viagem> set_viagem32 = cliente30.getHistorico();
        Cliente cliente33 = cliente30.clone();
        java.lang.String str34 = cliente30.getMail();
        int i35 = cliente24.compareTo(cliente30);
        java.lang.String str36 = cliente30.toString();
        Cliente cliente42 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente48 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str49 = cliente48.getMail();
        java.util.Set<Viagem> set_viagem50 = cliente48.getHistorico();
        Cliente cliente51 = cliente48.clone();
        java.lang.String str52 = cliente48.getMail();
        int i53 = cliente42.compareTo(cliente48);
        int i54 = cliente30.compareTo((Ator) cliente48);
        cliente30.setMS((double) 10L);
        int i57 = cliente13.compareTo((Ator) cliente30);
        java.lang.String str58 = cliente30.getMorada();
        int i59 = cliente7.compareTo(cliente30);
        java.lang.String str60 = cliente7.getMail();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on cliente30 and cliente16", (cliente30.compareTo(cliente16) == 0) == cliente30.equals(cliente16));
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test23");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        Cliente cliente14 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente20 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str21 = cliente20.getMail();
        java.util.Set<Viagem> set_viagem22 = cliente20.getHistorico();
        Cliente cliente23 = cliente20.clone();
        java.lang.String str24 = cliente20.getMail();
        int i25 = cliente14.compareTo(cliente20);
        java.lang.String str26 = cliente20.toString();
        int i27 = cliente5.compareTo(cliente20);
        Cliente cliente33 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str34 = cliente33.getMail();
        java.util.Set<Viagem> set_viagem35 = cliente33.getHistorico();
        Cliente cliente36 = cliente33.clone();
        java.lang.String str37 = cliente33.getMail();
        java.lang.String str38 = cliente33.getNome();
        boolean b39 = cliente20.equals((java.lang.Object) str38);
        java.lang.String str40 = cliente20.getMail();
        cliente20.setMS(52.0d);
        java.util.Set<Viagem> set_viagem43 = cliente20.getHistorico();
        Cliente cliente49 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str50 = cliente49.getMail();
        java.util.Set<Viagem> set_viagem51 = cliente49.getHistorico();
        Cliente cliente52 = cliente49.clone();
        java.lang.String str53 = cliente49.getMail();
        java.lang.String str54 = cliente49.getNome();
        Cliente cliente60 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente66 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str67 = cliente66.getMail();
        java.util.Set<Viagem> set_viagem68 = cliente66.getHistorico();
        Cliente cliente69 = cliente66.clone();
        java.lang.String str70 = cliente66.getMail();
        int i71 = cliente60.compareTo(cliente66);
        java.lang.String str72 = cliente66.toString();
        Cliente cliente78 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente84 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str85 = cliente84.getMail();
        java.util.Set<Viagem> set_viagem86 = cliente84.getHistorico();
        Cliente cliente87 = cliente84.clone();
        java.lang.String str88 = cliente84.getMail();
        int i89 = cliente78.compareTo(cliente84);
        int i90 = cliente66.compareTo((Ator) cliente84);
        cliente66.setMS((double) 10L);
        int i93 = cliente49.compareTo((Ator) cliente66);
        Cliente cliente94 = new Cliente(cliente66);
        int i95 = cliente20.compareTo(cliente66);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on cliente23 and cliente94", (cliente23.compareTo(cliente94) == 0) == cliente23.equals(cliente94));
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test24");
        Cliente cliente10 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str11 = cliente10.getMail();
        java.util.Set<Viagem> set_viagem12 = cliente10.getHistorico();
        Cliente cliente13 = cliente10.clone();
        Cliente cliente19 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente25 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str26 = cliente25.getMail();
        java.util.Set<Viagem> set_viagem27 = cliente25.getHistorico();
        Cliente cliente28 = cliente25.clone();
        java.lang.String str29 = cliente25.getMail();
        int i30 = cliente19.compareTo(cliente25);
        java.lang.String str31 = cliente25.toString();
        int i32 = cliente10.compareTo(cliente25);
        Cliente cliente38 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str39 = cliente38.getMail();
        java.util.Set<Viagem> set_viagem40 = cliente38.getHistorico();
        Cliente cliente41 = cliente38.clone();
        java.lang.String str42 = cliente38.getMail();
        java.lang.String str43 = cliente38.getNome();
        boolean b44 = cliente25.equals((java.lang.Object) str43);
        java.lang.String str45 = cliente25.getMail();
        cliente25.setMS(52.0d);
        java.util.Set<Viagem> set_viagem48 = cliente25.getHistorico();
        Cliente cliente50 = new Cliente("E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: \nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "hi!", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", set_viagem48, (double) (short) 100);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on cliente13 and cliente25", (cliente13.compareTo(cliente25) == 0) == cliente13.equals(cliente25));
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test25");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente8.getPassword();
        cliente8.setMS((double) '4');
        Cliente cliente12 = cliente8.clone();
        Cliente cliente13 = cliente8.clone();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on cliente12 and cliente5", (cliente12.compareTo(cliente5) == 0) == cliente12.equals(cliente5));
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test26");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        java.lang.String str10 = cliente5.getNome();
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente22 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str23 = cliente22.getMail();
        java.util.Set<Viagem> set_viagem24 = cliente22.getHistorico();
        Cliente cliente25 = cliente22.clone();
        java.lang.String str26 = cliente22.getMail();
        int i27 = cliente16.compareTo(cliente22);
        java.lang.String str28 = cliente22.toString();
        Cliente cliente34 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente40 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str41 = cliente40.getMail();
        java.util.Set<Viagem> set_viagem42 = cliente40.getHistorico();
        Cliente cliente43 = cliente40.clone();
        java.lang.String str44 = cliente40.getMail();
        int i45 = cliente34.compareTo(cliente40);
        int i46 = cliente22.compareTo((Ator) cliente40);
        cliente22.setMS((double) 10L);
        int i49 = cliente5.compareTo((Ator) cliente22);
        java.lang.String str50 = cliente22.getMail();
        double d51 = cliente22.getMS();
        java.lang.String str52 = cliente22.getMail();
        java.lang.String str53 = cliente22.getDataDeNascimento();
        Cliente cliente54 = cliente22.clone();
        java.util.Set<Viagem> set_viagem55 = cliente54.getHistorico();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on cliente40 and cliente22", (cliente40.compareTo(cliente22) == 0) == cliente40.equals(cliente22));
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test27");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        java.lang.String str10 = cliente5.getNome();
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente22 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str23 = cliente22.getMail();
        java.util.Set<Viagem> set_viagem24 = cliente22.getHistorico();
        Cliente cliente25 = cliente22.clone();
        java.lang.String str26 = cliente22.getMail();
        int i27 = cliente16.compareTo(cliente22);
        java.lang.String str28 = cliente22.toString();
        Cliente cliente34 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente40 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str41 = cliente40.getMail();
        java.util.Set<Viagem> set_viagem42 = cliente40.getHistorico();
        Cliente cliente43 = cliente40.clone();
        java.lang.String str44 = cliente40.getMail();
        int i45 = cliente34.compareTo(cliente40);
        int i46 = cliente22.compareTo((Ator) cliente40);
        cliente22.setMS((double) 10L);
        int i49 = cliente5.compareTo((Ator) cliente22);
        java.lang.String str50 = cliente22.getMail();
        Cliente cliente51 = cliente22.clone();
        java.lang.String str52 = cliente51.getMail();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on cliente22 and cliente5", (cliente22.compareTo(cliente5) == 0) == cliente22.equals(cliente5));
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test28");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        java.lang.String str10 = cliente5.getNome();
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente22 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str23 = cliente22.getMail();
        java.util.Set<Viagem> set_viagem24 = cliente22.getHistorico();
        Cliente cliente25 = cliente22.clone();
        java.lang.String str26 = cliente22.getMail();
        int i27 = cliente16.compareTo(cliente22);
        java.lang.String str28 = cliente22.toString();
        Cliente cliente34 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente40 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str41 = cliente40.getMail();
        java.util.Set<Viagem> set_viagem42 = cliente40.getHistorico();
        Cliente cliente43 = cliente40.clone();
        java.lang.String str44 = cliente40.getMail();
        int i45 = cliente34.compareTo(cliente40);
        int i46 = cliente22.compareTo((Ator) cliente40);
        cliente22.setMS((double) 10L);
        int i49 = cliente5.compareTo((Ator) cliente22);
        Cliente cliente55 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str56 = cliente55.getMail();
        java.util.Set<Viagem> set_viagem57 = cliente55.getHistorico();
        Cliente cliente58 = cliente55.clone();
        java.lang.String str59 = cliente58.getPassword();
        int i60 = cliente22.compareTo((Ator) cliente58);
        cliente58.setMS(0.0d);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on cliente40 and cliente22", (cliente40.compareTo(cliente22) == 0) == cliente40.equals(cliente22));
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test29");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        java.lang.String str10 = cliente5.getNome();
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente22 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str23 = cliente22.getMail();
        java.util.Set<Viagem> set_viagem24 = cliente22.getHistorico();
        Cliente cliente25 = cliente22.clone();
        java.lang.String str26 = cliente22.getMail();
        int i27 = cliente16.compareTo(cliente22);
        java.lang.String str28 = cliente22.toString();
        Cliente cliente34 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente40 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str41 = cliente40.getMail();
        java.util.Set<Viagem> set_viagem42 = cliente40.getHistorico();
        Cliente cliente43 = cliente40.clone();
        java.lang.String str44 = cliente40.getMail();
        int i45 = cliente34.compareTo(cliente40);
        int i46 = cliente22.compareTo((Ator) cliente40);
        cliente22.setMS((double) 10L);
        int i49 = cliente5.compareTo((Ator) cliente22);
        Cliente cliente50 = cliente22.clone();
        Cliente cliente56 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "", "hi!", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n");
        Cliente cliente57 = cliente56.clone();
        cliente57.setMS((double) (-1.0f));
        int i60 = cliente22.compareTo((Ator) cliente57);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on cliente16 and cliente50", (cliente16.compareTo(cliente50) == 0) == cliente16.equals(cliente50));
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test30");
        Cliente cliente10 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str11 = cliente10.getMail();
        java.util.Set<Viagem> set_viagem12 = cliente10.getHistorico();
        Cliente cliente13 = cliente10.clone();
        Cliente cliente19 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente25 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str26 = cliente25.getMail();
        java.util.Set<Viagem> set_viagem27 = cliente25.getHistorico();
        Cliente cliente28 = cliente25.clone();
        java.lang.String str29 = cliente25.getMail();
        int i30 = cliente19.compareTo(cliente25);
        java.lang.String str31 = cliente25.toString();
        int i32 = cliente10.compareTo(cliente25);
        Cliente cliente38 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str39 = cliente38.getMail();
        java.util.Set<Viagem> set_viagem40 = cliente38.getHistorico();
        Cliente cliente41 = cliente38.clone();
        java.lang.String str42 = cliente38.getMail();
        java.lang.String str43 = cliente38.getNome();
        boolean b44 = cliente25.equals((java.lang.Object) str43);
        java.lang.String str45 = cliente25.getMail();
        cliente25.setMS(52.0d);
        java.util.Set<Viagem> set_viagem48 = cliente25.getHistorico();
        Cliente cliente50 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: \nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "", set_viagem48, 1.0d);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on cliente38 and cliente25", (cliente38.compareTo(cliente25) == 0) == cliente38.equals(cliente25));
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test31");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        java.lang.String str10 = cliente5.getNome();
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente22 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str23 = cliente22.getMail();
        java.util.Set<Viagem> set_viagem24 = cliente22.getHistorico();
        Cliente cliente25 = cliente22.clone();
        java.lang.String str26 = cliente22.getMail();
        int i27 = cliente16.compareTo(cliente22);
        java.lang.String str28 = cliente22.toString();
        Cliente cliente34 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente40 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str41 = cliente40.getMail();
        java.util.Set<Viagem> set_viagem42 = cliente40.getHistorico();
        Cliente cliente43 = cliente40.clone();
        java.lang.String str44 = cliente40.getMail();
        int i45 = cliente34.compareTo(cliente40);
        int i46 = cliente22.compareTo((Ator) cliente40);
        cliente22.setMS((double) 10L);
        int i49 = cliente5.compareTo((Ator) cliente22);
        Cliente cliente50 = cliente22.clone();
        java.lang.String str51 = cliente50.getDataDeNascimento();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on cliente40 and cliente22", (cliente40.compareTo(cliente22) == 0) == cliente40.equals(cliente22));
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test32");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        java.lang.String str10 = cliente5.getNome();
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente22 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str23 = cliente22.getMail();
        java.util.Set<Viagem> set_viagem24 = cliente22.getHistorico();
        Cliente cliente25 = cliente22.clone();
        java.lang.String str26 = cliente22.getMail();
        int i27 = cliente16.compareTo(cliente22);
        java.lang.String str28 = cliente22.toString();
        Cliente cliente34 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente40 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str41 = cliente40.getMail();
        java.util.Set<Viagem> set_viagem42 = cliente40.getHistorico();
        Cliente cliente43 = cliente40.clone();
        java.lang.String str44 = cliente40.getMail();
        int i45 = cliente34.compareTo(cliente40);
        int i46 = cliente22.compareTo((Ator) cliente40);
        cliente22.setMS((double) 10L);
        int i49 = cliente5.compareTo((Ator) cliente22);
        Cliente cliente50 = new Cliente(cliente22);
        double d51 = cliente50.getMS();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on cliente43 and cliente22", (cliente43.compareTo(cliente22) == 0) == cliente43.equals(cliente22));
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test33");
        Cliente cliente0 = new Cliente();
        cliente0.setMS((double) 100);
        Cliente cliente8 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str9 = cliente8.getMail();
        java.util.Set<Viagem> set_viagem10 = cliente8.getHistorico();
        Cliente cliente11 = cliente8.clone();
        Cliente cliente17 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente23 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str24 = cliente23.getMail();
        java.util.Set<Viagem> set_viagem25 = cliente23.getHistorico();
        Cliente cliente26 = cliente23.clone();
        java.lang.String str27 = cliente23.getMail();
        int i28 = cliente17.compareTo(cliente23);
        java.lang.String str29 = cliente23.toString();
        int i30 = cliente8.compareTo(cliente23);
        int i31 = cliente0.compareTo(cliente8);
        Cliente cliente37 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str38 = cliente37.getMail();
        java.util.Set<Viagem> set_viagem39 = cliente37.getHistorico();
        Cliente cliente40 = cliente37.clone();
        java.lang.String str41 = cliente40.getPassword();
        cliente40.setMS((double) '4');
        Cliente cliente44 = cliente40.clone();
        int i45 = cliente0.compareTo((Ator) cliente40);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on cliente17 and cliente44", (cliente17.compareTo(cliente44) == 0) == cliente17.equals(cliente44));
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test34");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        java.lang.String str10 = cliente5.getNome();
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente22 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str23 = cliente22.getMail();
        java.util.Set<Viagem> set_viagem24 = cliente22.getHistorico();
        Cliente cliente25 = cliente22.clone();
        java.lang.String str26 = cliente22.getMail();
        int i27 = cliente16.compareTo(cliente22);
        java.lang.String str28 = cliente22.toString();
        Cliente cliente34 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente40 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str41 = cliente40.getMail();
        java.util.Set<Viagem> set_viagem42 = cliente40.getHistorico();
        Cliente cliente43 = cliente40.clone();
        java.lang.String str44 = cliente40.getMail();
        int i45 = cliente34.compareTo(cliente40);
        int i46 = cliente22.compareTo((Ator) cliente40);
        cliente22.setMS((double) 10L);
        int i49 = cliente5.compareTo((Ator) cliente22);
        Cliente cliente50 = cliente22.clone();
        Cliente cliente51 = cliente22.clone();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on cliente34 and cliente50", (cliente34.compareTo(cliente50) == 0) == cliente34.equals(cliente50));
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test35");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        Cliente cliente14 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente20 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str21 = cliente20.getMail();
        java.util.Set<Viagem> set_viagem22 = cliente20.getHistorico();
        Cliente cliente23 = cliente20.clone();
        java.lang.String str24 = cliente20.getMail();
        int i25 = cliente14.compareTo(cliente20);
        java.lang.String str26 = cliente20.toString();
        int i27 = cliente5.compareTo(cliente20);
        Cliente cliente33 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str34 = cliente33.getMail();
        java.util.Set<Viagem> set_viagem35 = cliente33.getHistorico();
        Cliente cliente36 = cliente33.clone();
        java.lang.String str37 = cliente33.getMail();
        java.lang.String str38 = cliente33.getNome();
        boolean b39 = cliente20.equals((java.lang.Object) str38);
        java.lang.String str40 = cliente20.getMail();
        java.util.Set<Viagem> set_viagem41 = cliente20.getHistorico();
        Cliente cliente42 = new Cliente(cliente20);
        java.lang.String str43 = cliente20.getMorada();
        Cliente cliente49 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str50 = cliente49.getMail();
        java.util.Set<Viagem> set_viagem51 = cliente49.getHistorico();
        Cliente cliente52 = cliente49.clone();
        java.lang.String str53 = cliente49.getMail();
        cliente49.setMS((double) '4');
        java.lang.String str56 = cliente49.getPassword();
        int i57 = cliente20.compareTo(cliente49);
        java.util.Set<Viagem> set_viagem58 = cliente20.getHistorico();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on cliente49 and cliente36", (cliente49.compareTo(cliente36) == 0) == cliente49.equals(cliente36));
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test36");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente8.getPassword();
        cliente8.setMS((double) '4');
        Cliente cliente12 = cliente8.clone();
        java.lang.String str13 = cliente12.getNome();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on cliente8 and cliente5", (cliente8.compareTo(cliente5) == 0) == cliente8.equals(cliente5));
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test37");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        java.lang.String str10 = cliente5.getNome();
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente22 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str23 = cliente22.getMail();
        java.util.Set<Viagem> set_viagem24 = cliente22.getHistorico();
        Cliente cliente25 = cliente22.clone();
        java.lang.String str26 = cliente22.getMail();
        int i27 = cliente16.compareTo(cliente22);
        java.lang.String str28 = cliente22.toString();
        Cliente cliente34 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente40 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str41 = cliente40.getMail();
        java.util.Set<Viagem> set_viagem42 = cliente40.getHistorico();
        Cliente cliente43 = cliente40.clone();
        java.lang.String str44 = cliente40.getMail();
        int i45 = cliente34.compareTo(cliente40);
        int i46 = cliente22.compareTo((Ator) cliente40);
        cliente22.setMS((double) 10L);
        int i49 = cliente5.compareTo((Ator) cliente22);
        Cliente cliente50 = cliente22.clone();
        Cliente cliente56 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente62 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str63 = cliente62.getMail();
        java.util.Set<Viagem> set_viagem64 = cliente62.getHistorico();
        Cliente cliente65 = cliente62.clone();
        java.lang.String str66 = cliente62.getMail();
        int i67 = cliente56.compareTo(cliente62);
        java.lang.String str68 = cliente62.toString();
        Cliente cliente74 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente80 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str81 = cliente80.getMail();
        java.util.Set<Viagem> set_viagem82 = cliente80.getHistorico();
        Cliente cliente83 = cliente80.clone();
        java.lang.String str84 = cliente80.getMail();
        int i85 = cliente74.compareTo(cliente80);
        int i86 = cliente62.compareTo((Ator) cliente80);
        cliente62.setMS(0.0d);
        cliente62.setMS((double) (byte) 10);
        java.lang.String str91 = cliente62.getNome();
        java.lang.String str92 = cliente62.getDataDeNascimento();
        java.lang.String str93 = cliente62.getNome();
        int i94 = cliente22.compareTo(cliente62);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on cliente5 and cliente50", (cliente5.compareTo(cliente50) == 0) == cliente5.equals(cliente50));
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test38");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        java.lang.String str10 = cliente5.getNome();
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente22 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str23 = cliente22.getMail();
        java.util.Set<Viagem> set_viagem24 = cliente22.getHistorico();
        Cliente cliente25 = cliente22.clone();
        java.lang.String str26 = cliente22.getMail();
        int i27 = cliente16.compareTo(cliente22);
        java.lang.String str28 = cliente22.toString();
        Cliente cliente34 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente40 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str41 = cliente40.getMail();
        java.util.Set<Viagem> set_viagem42 = cliente40.getHistorico();
        Cliente cliente43 = cliente40.clone();
        java.lang.String str44 = cliente40.getMail();
        int i45 = cliente34.compareTo(cliente40);
        int i46 = cliente22.compareTo((Ator) cliente40);
        cliente22.setMS((double) 10L);
        int i49 = cliente5.compareTo((Ator) cliente22);
        java.lang.String str50 = cliente22.getMail();
        double d51 = cliente22.getMS();
        java.lang.String str52 = cliente22.getMail();
        java.lang.String str53 = cliente22.getDataDeNascimento();
        Cliente cliente54 = cliente22.clone();
        double d55 = cliente54.getMS();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on cliente25 and cliente22", (cliente25.compareTo(cliente22) == 0) == cliente25.equals(cliente22));
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test39");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        Cliente cliente23 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente29 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str30 = cliente29.getMail();
        java.util.Set<Viagem> set_viagem31 = cliente29.getHistorico();
        Cliente cliente32 = cliente29.clone();
        java.lang.String str33 = cliente29.getMail();
        int i34 = cliente23.compareTo(cliente29);
        int i35 = cliente11.compareTo((Ator) cliente29);
        cliente11.setMS(0.0d);
        cliente11.setMS((double) (byte) 10);
        java.lang.String str40 = cliente11.getNome();
        Cliente cliente46 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str47 = cliente46.getMail();
        java.util.Set<Viagem> set_viagem48 = cliente46.getHistorico();
        Cliente cliente49 = cliente46.clone();
        Cliente cliente55 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente61 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str62 = cliente61.getMail();
        java.util.Set<Viagem> set_viagem63 = cliente61.getHistorico();
        Cliente cliente64 = cliente61.clone();
        java.lang.String str65 = cliente61.getMail();
        int i66 = cliente55.compareTo(cliente61);
        java.lang.String str67 = cliente61.toString();
        int i68 = cliente46.compareTo(cliente61);
        Cliente cliente74 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str75 = cliente74.getMail();
        java.util.Set<Viagem> set_viagem76 = cliente74.getHistorico();
        Cliente cliente77 = cliente74.clone();
        java.lang.String str78 = cliente74.getMail();
        java.lang.String str79 = cliente74.getNome();
        boolean b80 = cliente61.equals((java.lang.Object) str79);
        java.lang.String str81 = cliente61.getMail();
        int i82 = cliente11.compareTo((Ator) cliente61);
        double d83 = cliente61.getMS();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on cliente11 and cliente46", (cliente11.compareTo(cliente46) == 0) == cliente11.equals(cliente46));
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test40");
        Cliente cliente5 = new Cliente("E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "hi!", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        int i12 = cliente5.compareTo(cliente11);
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente19 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str20 = cliente19.getMail();
        java.util.Set<Viagem> set_viagem21 = cliente19.getHistorico();
        Cliente cliente22 = cliente19.clone();
        Cliente cliente28 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente34 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str35 = cliente34.getMail();
        java.util.Set<Viagem> set_viagem36 = cliente34.getHistorico();
        Cliente cliente37 = cliente34.clone();
        java.lang.String str38 = cliente34.getMail();
        int i39 = cliente28.compareTo(cliente34);
        java.lang.String str40 = cliente34.toString();
        int i41 = cliente19.compareTo(cliente34);
        Cliente cliente47 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str48 = cliente47.getMail();
        java.util.Set<Viagem> set_viagem49 = cliente47.getHistorico();
        Cliente cliente50 = cliente47.clone();
        java.lang.String str51 = cliente47.getMail();
        java.lang.String str52 = cliente47.getNome();
        boolean b53 = cliente34.equals((java.lang.Object) str52);
        java.lang.String str54 = cliente34.getMail();
        cliente34.setMS(52.0d);
        java.util.Set<Viagem> set_viagem57 = cliente34.getHistorico();
        int i58 = cliente11.compareTo((Ator) cliente34);
        java.lang.String str59 = cliente11.getMail();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on cliente37 and cliente34", (cliente37.compareTo(cliente34) == 0) == cliente37.equals(cliente34));
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test41");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        java.lang.String str10 = cliente5.getNome();
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente22 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str23 = cliente22.getMail();
        java.util.Set<Viagem> set_viagem24 = cliente22.getHistorico();
        Cliente cliente25 = cliente22.clone();
        java.lang.String str26 = cliente22.getMail();
        int i27 = cliente16.compareTo(cliente22);
        java.lang.String str28 = cliente22.toString();
        Cliente cliente34 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente40 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str41 = cliente40.getMail();
        java.util.Set<Viagem> set_viagem42 = cliente40.getHistorico();
        Cliente cliente43 = cliente40.clone();
        java.lang.String str44 = cliente40.getMail();
        int i45 = cliente34.compareTo(cliente40);
        int i46 = cliente22.compareTo((Ator) cliente40);
        cliente22.setMS((double) 10L);
        int i49 = cliente5.compareTo((Ator) cliente22);
        cliente5.setMS((double) 10L);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on cliente8 and cliente22", (cliente8.compareTo(cliente22) == 0) == cliente8.equals(cliente22));
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test42");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        Cliente cliente14 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente20 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str21 = cliente20.getMail();
        java.util.Set<Viagem> set_viagem22 = cliente20.getHistorico();
        Cliente cliente23 = cliente20.clone();
        java.lang.String str24 = cliente20.getMail();
        int i25 = cliente14.compareTo(cliente20);
        java.lang.String str26 = cliente20.toString();
        int i27 = cliente5.compareTo(cliente20);
        Cliente cliente33 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str34 = cliente33.getMail();
        java.util.Set<Viagem> set_viagem35 = cliente33.getHistorico();
        Cliente cliente36 = cliente33.clone();
        java.lang.String str37 = cliente33.getMail();
        java.lang.String str38 = cliente33.getNome();
        boolean b39 = cliente20.equals((java.lang.Object) str38);
        java.lang.String str40 = cliente20.getMail();
        java.util.Set<Viagem> set_viagem41 = cliente20.getHistorico();
        Cliente cliente42 = new Cliente(cliente20);
        java.lang.String str43 = cliente20.getMorada();
        Cliente cliente49 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str50 = cliente49.getMail();
        java.util.Set<Viagem> set_viagem51 = cliente49.getHistorico();
        Cliente cliente52 = cliente49.clone();
        java.lang.String str53 = cliente49.getMail();
        cliente49.setMS((double) '4');
        java.lang.String str56 = cliente49.getPassword();
        int i57 = cliente20.compareTo(cliente49);
        java.lang.String str58 = cliente20.getNome();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on cliente14 and cliente49", (cliente14.compareTo(cliente49) == 0) == cliente14.equals(cliente49));
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test43");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getPassword();
        Cliente cliente15 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str16 = cliente15.getMail();
        java.util.Set<Viagem> set_viagem17 = cliente15.getHistorico();
        Cliente cliente18 = cliente15.clone();
        java.lang.String str19 = cliente15.getMail();
        cliente15.setMS((double) '4');
        java.lang.String str22 = cliente15.getPassword();
        Cliente cliente28 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str29 = cliente28.getMail();
        java.util.Set<Viagem> set_viagem30 = cliente28.getHistorico();
        Cliente cliente31 = cliente28.clone();
        Cliente cliente37 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente43 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str44 = cliente43.getMail();
        java.util.Set<Viagem> set_viagem45 = cliente43.getHistorico();
        Cliente cliente46 = cliente43.clone();
        java.lang.String str47 = cliente43.getMail();
        int i48 = cliente37.compareTo(cliente43);
        java.lang.String str49 = cliente43.toString();
        int i50 = cliente28.compareTo(cliente43);
        Cliente cliente56 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str57 = cliente56.getMail();
        java.util.Set<Viagem> set_viagem58 = cliente56.getHistorico();
        Cliente cliente59 = cliente56.clone();
        java.lang.String str60 = cliente56.getMail();
        java.lang.String str61 = cliente56.getNome();
        boolean b62 = cliente43.equals((java.lang.Object) str61);
        java.lang.String str63 = cliente43.getMail();
        java.util.Set<Viagem> set_viagem64 = cliente43.getHistorico();
        Cliente cliente65 = new Cliente(cliente43);
        Cliente cliente66 = cliente43.clone();
        int i67 = cliente15.compareTo((Ator) cliente43);
        int i68 = cliente5.compareTo(cliente43);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on cliente8 and cliente15", (cliente8.compareTo(cliente15) == 0) == cliente8.equals(cliente15));
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test44");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        cliente5.setMS((double) '4');
        java.lang.String str12 = cliente5.getPassword();
        Cliente cliente18 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str19 = cliente18.getMail();
        java.util.Set<Viagem> set_viagem20 = cliente18.getHistorico();
        Cliente cliente21 = cliente18.clone();
        Cliente cliente27 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente33 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str34 = cliente33.getMail();
        java.util.Set<Viagem> set_viagem35 = cliente33.getHistorico();
        Cliente cliente36 = cliente33.clone();
        java.lang.String str37 = cliente33.getMail();
        int i38 = cliente27.compareTo(cliente33);
        java.lang.String str39 = cliente33.toString();
        int i40 = cliente18.compareTo(cliente33);
        Cliente cliente46 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str47 = cliente46.getMail();
        java.util.Set<Viagem> set_viagem48 = cliente46.getHistorico();
        Cliente cliente49 = cliente46.clone();
        java.lang.String str50 = cliente46.getMail();
        java.lang.String str51 = cliente46.getNome();
        boolean b52 = cliente33.equals((java.lang.Object) str51);
        java.lang.String str53 = cliente33.getMail();
        java.util.Set<Viagem> set_viagem54 = cliente33.getHistorico();
        Cliente cliente55 = new Cliente(cliente33);
        Cliente cliente56 = cliente33.clone();
        int i57 = cliente5.compareTo((Ator) cliente33);
        java.lang.String str58 = cliente33.getDataDeNascimento();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on cliente5 and cliente36", (cliente5.compareTo(cliente36) == 0) == cliente5.equals(cliente36));
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test45");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        Cliente cliente23 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente29 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str30 = cliente29.getMail();
        java.util.Set<Viagem> set_viagem31 = cliente29.getHistorico();
        Cliente cliente32 = cliente29.clone();
        java.lang.String str33 = cliente29.getMail();
        int i34 = cliente23.compareTo(cliente29);
        int i35 = cliente11.compareTo((Ator) cliente29);
        cliente11.setMS(0.0d);
        cliente11.setMS((double) (byte) 10);
        java.lang.String str40 = cliente11.getNome();
        Cliente cliente46 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str47 = cliente46.getMail();
        java.util.Set<Viagem> set_viagem48 = cliente46.getHistorico();
        Cliente cliente49 = cliente46.clone();
        Cliente cliente55 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente61 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str62 = cliente61.getMail();
        java.util.Set<Viagem> set_viagem63 = cliente61.getHistorico();
        Cliente cliente64 = cliente61.clone();
        java.lang.String str65 = cliente61.getMail();
        int i66 = cliente55.compareTo(cliente61);
        java.lang.String str67 = cliente61.toString();
        int i68 = cliente46.compareTo(cliente61);
        Cliente cliente74 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str75 = cliente74.getMail();
        java.util.Set<Viagem> set_viagem76 = cliente74.getHistorico();
        Cliente cliente77 = cliente74.clone();
        java.lang.String str78 = cliente74.getMail();
        java.lang.String str79 = cliente74.getNome();
        boolean b80 = cliente61.equals((java.lang.Object) str79);
        java.lang.String str81 = cliente61.getMail();
        int i82 = cliente11.compareTo((Ator) cliente61);
        cliente61.setMS((double) 35);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on cliente11 and cliente55", (cliente11.compareTo(cliente55) == 0) == cliente11.equals(cliente55));
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test46");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        java.lang.String str10 = cliente5.getNome();
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente22 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str23 = cliente22.getMail();
        java.util.Set<Viagem> set_viagem24 = cliente22.getHistorico();
        Cliente cliente25 = cliente22.clone();
        java.lang.String str26 = cliente22.getMail();
        int i27 = cliente16.compareTo(cliente22);
        java.lang.String str28 = cliente22.toString();
        Cliente cliente34 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente40 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str41 = cliente40.getMail();
        java.util.Set<Viagem> set_viagem42 = cliente40.getHistorico();
        Cliente cliente43 = cliente40.clone();
        java.lang.String str44 = cliente40.getMail();
        int i45 = cliente34.compareTo(cliente40);
        int i46 = cliente22.compareTo((Ator) cliente40);
        cliente22.setMS((double) 10L);
        int i49 = cliente5.compareTo((Ator) cliente22);
        java.lang.String str50 = cliente22.getMail();
        java.lang.String str51 = cliente22.getNome();
        Cliente cliente57 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str58 = cliente57.getMail();
        cliente57.setMS(10.0d);
        Cliente cliente66 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str67 = cliente66.getMail();
        java.util.Set<Viagem> set_viagem68 = cliente66.getHistorico();
        Cliente cliente69 = cliente66.clone();
        java.lang.String str70 = cliente66.getMail();
        cliente66.setMS((double) '4');
        java.lang.String str73 = cliente66.getPassword();
        int i74 = cliente57.compareTo(cliente66);
        boolean b75 = cliente22.equals((java.lang.Object) i74);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on cliente5 and cliente57", (cliente5.compareTo(cliente57) == 0) == cliente5.equals(cliente57));
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test47");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente11 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str12 = cliente11.getMail();
        java.util.Set<Viagem> set_viagem13 = cliente11.getHistorico();
        Cliente cliente14 = cliente11.clone();
        java.lang.String str15 = cliente11.getMail();
        int i16 = cliente5.compareTo(cliente11);
        java.lang.String str17 = cliente11.toString();
        Cliente cliente23 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente29 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str30 = cliente29.getMail();
        java.util.Set<Viagem> set_viagem31 = cliente29.getHistorico();
        Cliente cliente32 = cliente29.clone();
        java.lang.String str33 = cliente29.getMail();
        int i34 = cliente23.compareTo(cliente29);
        int i35 = cliente11.compareTo((Ator) cliente29);
        Cliente cliente41 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str42 = cliente41.getMail();
        java.util.Set<Viagem> set_viagem43 = cliente41.getHistorico();
        Cliente cliente44 = cliente41.clone();
        int i45 = cliente11.compareTo(cliente41);
        Cliente cliente51 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente57 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str58 = cliente57.getMail();
        java.util.Set<Viagem> set_viagem59 = cliente57.getHistorico();
        Cliente cliente60 = cliente57.clone();
        java.lang.String str61 = cliente57.getMail();
        int i62 = cliente51.compareTo(cliente57);
        java.lang.String str63 = cliente57.toString();
        Cliente cliente69 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente75 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str76 = cliente75.getMail();
        java.util.Set<Viagem> set_viagem77 = cliente75.getHistorico();
        Cliente cliente78 = cliente75.clone();
        java.lang.String str79 = cliente75.getMail();
        int i80 = cliente69.compareTo(cliente75);
        int i81 = cliente57.compareTo((Ator) cliente75);
        Cliente cliente87 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str88 = cliente87.getMail();
        java.util.Set<Viagem> set_viagem89 = cliente87.getHistorico();
        Cliente cliente90 = cliente87.clone();
        int i91 = cliente57.compareTo(cliente87);
        java.lang.String str92 = cliente87.getMail();
        java.lang.String str93 = cliente87.toString();
        int i94 = cliente41.compareTo(cliente87);
        cliente87.setMS((double) 1L);
        Cliente cliente97 = cliente87.clone();
        Cliente cliente98 = cliente97.clone();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on cliente60 and cliente87", (cliente60.compareTo(cliente87) == 0) == cliente60.equals(cliente87));
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test48");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        java.lang.String str10 = cliente5.getNome();
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente22 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str23 = cliente22.getMail();
        java.util.Set<Viagem> set_viagem24 = cliente22.getHistorico();
        Cliente cliente25 = cliente22.clone();
        java.lang.String str26 = cliente22.getMail();
        int i27 = cliente16.compareTo(cliente22);
        java.lang.String str28 = cliente22.toString();
        Cliente cliente34 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente40 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str41 = cliente40.getMail();
        java.util.Set<Viagem> set_viagem42 = cliente40.getHistorico();
        Cliente cliente43 = cliente40.clone();
        java.lang.String str44 = cliente40.getMail();
        int i45 = cliente34.compareTo(cliente40);
        int i46 = cliente22.compareTo((Ator) cliente40);
        cliente22.setMS((double) 10L);
        int i49 = cliente5.compareTo((Ator) cliente22);
        java.lang.String str50 = cliente22.getMail();
        Cliente cliente51 = cliente22.clone();
        java.lang.String str52 = cliente51.toString();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on cliente34 and cliente22", (cliente34.compareTo(cliente22) == 0) == cliente34.equals(cliente22));
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test49");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        java.lang.String str10 = cliente5.getNome();
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente22 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str23 = cliente22.getMail();
        java.util.Set<Viagem> set_viagem24 = cliente22.getHistorico();
        Cliente cliente25 = cliente22.clone();
        java.lang.String str26 = cliente22.getMail();
        int i27 = cliente16.compareTo(cliente22);
        java.lang.String str28 = cliente22.toString();
        Cliente cliente34 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente40 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str41 = cliente40.getMail();
        java.util.Set<Viagem> set_viagem42 = cliente40.getHistorico();
        Cliente cliente43 = cliente40.clone();
        java.lang.String str44 = cliente40.getMail();
        int i45 = cliente34.compareTo(cliente40);
        int i46 = cliente22.compareTo((Ator) cliente40);
        cliente22.setMS((double) 10L);
        int i49 = cliente5.compareTo((Ator) cliente22);
        java.lang.String str50 = cliente22.getMail();
        Cliente cliente51 = new Cliente(cliente22);
        Cliente cliente52 = cliente51.clone();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on cliente25 and cliente22", (cliente25.compareTo(cliente22) == 0) == cliente25.equals(cliente22));
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test50");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        Cliente cliente14 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente20 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str21 = cliente20.getMail();
        java.util.Set<Viagem> set_viagem22 = cliente20.getHistorico();
        Cliente cliente23 = cliente20.clone();
        java.lang.String str24 = cliente20.getMail();
        int i25 = cliente14.compareTo(cliente20);
        java.lang.String str26 = cliente20.toString();
        int i27 = cliente5.compareTo(cliente20);
        Cliente cliente33 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str34 = cliente33.getMail();
        java.util.Set<Viagem> set_viagem35 = cliente33.getHistorico();
        Cliente cliente36 = cliente33.clone();
        java.lang.String str37 = cliente33.getMail();
        java.lang.String str38 = cliente33.getNome();
        boolean b39 = cliente20.equals((java.lang.Object) str38);
        java.lang.String str40 = cliente20.getMail();
        cliente20.setMS(52.0d);
        java.lang.String str43 = cliente20.getNome();
        java.lang.String str44 = cliente20.getPassword();
        java.lang.String str45 = cliente20.getNome();
        Cliente cliente46 = new Cliente(cliente20);
        java.lang.String str47 = cliente20.getDataDeNascimento();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on cliente8 and cliente46", (cliente8.compareTo(cliente46) == 0) == cliente8.equals(cliente46));
    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test51");
        Cliente cliente10 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str11 = cliente10.getMail();
        java.util.Set<Viagem> set_viagem12 = cliente10.getHistorico();
        Cliente cliente13 = cliente10.clone();
        java.lang.String str14 = cliente10.getMail();
        java.lang.String str15 = cliente10.getNome();
        Cliente cliente21 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente27 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str28 = cliente27.getMail();
        java.util.Set<Viagem> set_viagem29 = cliente27.getHistorico();
        Cliente cliente30 = cliente27.clone();
        java.lang.String str31 = cliente27.getMail();
        int i32 = cliente21.compareTo(cliente27);
        java.lang.String str33 = cliente27.toString();
        Cliente cliente39 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente45 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str46 = cliente45.getMail();
        java.util.Set<Viagem> set_viagem47 = cliente45.getHistorico();
        Cliente cliente48 = cliente45.clone();
        java.lang.String str49 = cliente45.getMail();
        int i50 = cliente39.compareTo(cliente45);
        int i51 = cliente27.compareTo((Ator) cliente45);
        cliente27.setMS((double) 10L);
        int i54 = cliente10.compareTo((Ator) cliente27);
        java.lang.String str55 = cliente27.getMail();
        double d56 = cliente27.getMS();
        java.util.Set<Viagem> set_viagem57 = cliente27.getHistorico();
        Cliente cliente59 = new Cliente("E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nNome: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nPassword: \nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "hi!", "hi!", "E-mail: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 10.00\n\nNome: hi!\nPassword: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\n\nMorada: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nData de nascimento: E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 52.00\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n", "E-mail: hi!\nNome: \nPassword: \nMorada: hi!\nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 1.00\n", set_viagem57, (double) (-3));
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on cliente10 and cliente27", (cliente10.compareTo(cliente27) == 0) == cliente10.equals(cliente27));
    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test52");
        Cliente cliente5 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str6 = cliente5.getMail();
        java.util.Set<Viagem> set_viagem7 = cliente5.getHistorico();
        Cliente cliente8 = cliente5.clone();
        java.lang.String str9 = cliente5.getMail();
        java.lang.String str10 = cliente5.getNome();
        Cliente cliente16 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente22 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str23 = cliente22.getMail();
        java.util.Set<Viagem> set_viagem24 = cliente22.getHistorico();
        Cliente cliente25 = cliente22.clone();
        java.lang.String str26 = cliente22.getMail();
        int i27 = cliente16.compareTo(cliente22);
        java.lang.String str28 = cliente22.toString();
        Cliente cliente34 = new Cliente("hi!", "", "", "hi!", "");
        Cliente cliente40 = new Cliente("hi!", "", "", "hi!", "");
        java.lang.String str41 = cliente40.getMail();
        java.util.Set<Viagem> set_viagem42 = cliente40.getHistorico();
        Cliente cliente43 = cliente40.clone();
        java.lang.String str44 = cliente40.getMail();
        int i45 = cliente34.compareTo(cliente40);
        int i46 = cliente22.compareTo((Ator) cliente40);
        cliente22.setMS((double) 10L);
        int i49 = cliente5.compareTo((Ator) cliente22);
        java.lang.String str50 = cliente22.getMail();
        double d51 = cliente22.getMS();
        java.lang.String str52 = cliente22.getMail();
        java.lang.String str53 = cliente22.getDataDeNascimento();
        Cliente cliente54 = cliente22.clone();
        java.lang.String str55 = cliente54.getDataDeNascimento();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on cliente22 and cliente25", (cliente22.compareTo(cliente25) == 0) == cliente22.equals(cliente25));
    }
}

