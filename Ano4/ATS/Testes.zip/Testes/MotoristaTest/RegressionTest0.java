import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        Motorista motorista0 = null;
        try {
            Motorista motorista1 = new Motorista(motorista0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        boolean b3 = motorista0.equals((java.lang.Object) (byte) 10);
        Motorista motorista4 = new Motorista();
        int i5 = motorista4.getGrau();
        boolean b7 = motorista4.equals((java.lang.Object) (byte) 10);
        int i8 = motorista0.compareTo((Ator) motorista4);
        Coordenada coordenada9 = null;
        try {
            motorista4.atualizaDados(coordenada9, (-1.0d), (double) (short) -1, (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(b7 == false);
        org.junit.Assert.assertTrue(i8 == 0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.getPassword();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        try {
            java.util.List<Viagem> list_viagem4 = motorista0.viagensEntreDatas(gregorianCalendar2, gregorianCalendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        boolean b3 = motorista0.equals((java.lang.Object) (byte) 10);
        Motorista motorista4 = new Motorista();
        int i5 = motorista4.getGrau();
        boolean b7 = motorista4.equals((java.lang.Object) (byte) 10);
        int i8 = motorista0.compareTo((Ator) motorista4);
        Coordenada coordenada9 = null;
        try {
            motorista4.atualizaDados(coordenada9, (double) 100, (double) 100L, (double) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(b7 == false);
        org.junit.Assert.assertTrue(i8 == 0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        Viagem[] viagem_array5 = new Viagem[] {};
        java.util.LinkedHashSet<Viagem> linkedhashset_viagem6 = new java.util.LinkedHashSet<Viagem>();
        boolean b7 = java.util.Collections.addAll((java.util.Collection<Viagem>) linkedhashset_viagem6, viagem_array5);
        Veiculo veiculo13 = null;
        try {
            Motorista motorista14 = new Motorista("", "", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", (java.util.Set<Viagem>) linkedhashset_viagem6, 10, (int) (byte) 1, 0, (double) (-1L), true, veiculo13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(viagem_array5);
        org.junit.Assert.assertTrue(b7 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        Viagem viagem2 = null;
        try {
            motorista0.registaViagem(viagem2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        boolean b3 = motorista0.equals((java.lang.Object) (byte) 10);
        Motorista motorista4 = new Motorista();
        int i5 = motorista4.getGrau();
        boolean b7 = motorista4.equals((java.lang.Object) (byte) 10);
        int i8 = motorista0.compareTo((Ator) motorista4);
        Coordenada coordenada9 = null;
        try {
            motorista4.atualizaDados(coordenada9, (double) 100, (double) 0.0f, (double) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(b7 == false);
        org.junit.Assert.assertTrue(i8 == 0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        Viagem[] viagem_array5 = new Viagem[] {};
        java.util.LinkedHashSet<Viagem> linkedhashset_viagem6 = new java.util.LinkedHashSet<Viagem>();
        boolean b7 = java.util.Collections.addAll((java.util.Collection<Viagem>) linkedhashset_viagem6, viagem_array5);
        Veiculo veiculo13 = null;
        try {
            Motorista motorista14 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "", "", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", (java.util.Set<Viagem>) linkedhashset_viagem6, (int) (short) 1, (int) (short) 10, (int) ' ', (double) ' ', true, veiculo13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(viagem_array5);
        org.junit.Assert.assertTrue(b7 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.getPassword();
        java.lang.String str2 = motorista0.getMorada();
        java.util.GregorianCalendar gregorianCalendar3 = null;
        java.util.GregorianCalendar gregorianCalendar4 = null;
        try {
            java.util.List<Viagem> list_viagem5 = motorista0.viagensEntreDatas(gregorianCalendar3, gregorianCalendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        motorista0.atualizaClassificacao(0);
        double d8 = motorista0.getKmsTotais();
        Viagem viagem9 = null;
        try {
            motorista0.registaViagem(viagem9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(d8 == 0.0d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        boolean b3 = motorista0.getDisponibilidade();
        java.util.GregorianCalendar gregorianCalendar4 = null;
        java.util.GregorianCalendar gregorianCalendar5 = null;
        try {
            java.util.List<Viagem> list_viagem6 = motorista0.viagensEntreDatas(gregorianCalendar4, gregorianCalendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(b3 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        Viagem[] viagem_array5 = new Viagem[] {};
        java.util.LinkedHashSet<Viagem> linkedhashset_viagem6 = new java.util.LinkedHashSet<Viagem>();
        boolean b7 = java.util.Collections.addAll((java.util.Collection<Viagem>) linkedhashset_viagem6, viagem_array5);
        Veiculo veiculo13 = null;
        try {
            Motorista motorista14 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", (java.util.Set<Viagem>) linkedhashset_viagem6, 0, (int) '4', (int) (byte) 1, (double) (-1L), false, veiculo13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(viagem_array5);
        org.junit.Assert.assertTrue(b7 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        double d4 = motorista0.totalFaturado(gregorianCalendar2, gregorianCalendar3);
        java.lang.Object obj5 = null;
        boolean b6 = motorista0.equals(obj5);
        java.util.GregorianCalendar gregorianCalendar7 = null;
        java.util.GregorianCalendar gregorianCalendar8 = null;
        try {
            java.util.List<Viagem> list_viagem9 = motorista0.viagensEntreDatas(gregorianCalendar7, gregorianCalendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(d4 == 0.0d);
        org.junit.Assert.assertTrue(b6 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        Veiculo veiculo2 = motorista0.getVeiculo();
        double d3 = motorista0.getKmsTotais();
        java.util.GregorianCalendar gregorianCalendar4 = null;
        java.util.GregorianCalendar gregorianCalendar5 = null;
        try {
            java.util.List<Viagem> list_viagem6 = motorista0.viagensEntreDatas(gregorianCalendar4, gregorianCalendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNull(veiculo2);
        org.junit.Assert.assertTrue(d3 == 0.0d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.lang.String str2 = motorista0.getMail();
        Viagem viagem3 = null;
        try {
            motorista0.registaViagem(viagem3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        try {
            Viagem viagem8 = motorista0.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        try {
            Viagem viagem2 = motorista0.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        motorista0.atualizaClassificacao(0);
        double d8 = motorista0.getKmsTotais();
        Motorista motorista9 = new Motorista();
        int i10 = motorista9.getGrau();
        boolean b12 = motorista9.equals((java.lang.Object) (byte) 10);
        int i13 = motorista0.compareTo((Ator) motorista9);
        java.util.GregorianCalendar gregorianCalendar14 = null;
        java.util.GregorianCalendar gregorianCalendar15 = null;
        try {
            java.util.List<Viagem> list_viagem16 = motorista0.viagensEntreDatas(gregorianCalendar14, gregorianCalendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(d8 == 0.0d);
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertTrue(i13 == 0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        Motorista motorista5 = new Motorista();
        Veiculo veiculo6 = motorista5.getVeiculo();
        java.lang.String str7 = motorista5.getMail();
        java.lang.String str8 = motorista5.getDataDeNascimento();
        java.util.Set<Viagem> set_viagem9 = motorista5.getHistorico();
        Veiculo veiculo15 = null;
        try {
            Motorista motorista16 = new Motorista("hi!", "", "", "", "hi!", set_viagem9, (int) (short) 10, (int) ' ', 0, (double) (byte) 1, false, veiculo15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(set_viagem9);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        boolean b3 = motorista0.equals((java.lang.Object) (byte) 10);
        Viagem viagem4 = null;
        try {
            motorista0.registaViagem(viagem4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(b3 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("hi!", "hi!", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", veiculo5);
        int i7 = motorista6.getNumClassi();
        Coordenada coordenada8 = null;
        try {
            motorista6.atualizaDados(coordenada8, (double) (byte) 0, (double) (-1.0f), (double) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i7 == 0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        Motorista motorista0 = new Motorista();
        try {
            Viagem viagem1 = motorista0.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        boolean b3 = motorista0.equals((java.lang.Object) (byte) 10);
        Motorista motorista4 = new Motorista();
        int i5 = motorista4.getGrau();
        boolean b7 = motorista4.equals((java.lang.Object) (byte) 10);
        int i8 = motorista0.compareTo((Ator) motorista4);
        Coordenada coordenada9 = null;
        try {
            motorista0.atualizaDados(coordenada9, 100.0d, (double) (-1.0f), 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(b7 == false);
        org.junit.Assert.assertTrue(i8 == 0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        int i2 = motorista0.getNumClassi();
        java.lang.String str3 = motorista0.getNome();
        java.util.GregorianCalendar gregorianCalendar4 = null;
        java.util.GregorianCalendar gregorianCalendar5 = null;
        try {
            java.util.List<Viagem> list_viagem6 = motorista0.viagensEntreDatas(gregorianCalendar4, gregorianCalendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(i2 == 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        try {
            Viagem viagem6 = motorista0.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        java.lang.String str3 = motorista0.getDataDeNascimento();
        java.util.Set<Viagem> set_viagem4 = motorista0.getHistorico();
        Viagem viagem5 = null;
        try {
            motorista0.registaViagem(viagem5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNotNull(set_viagem4);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.setDisponibilidade(false);
        Motorista motorista6 = null;
        try {
            int i7 = motorista0.compareTo(motorista6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.getPassword();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        double d4 = motorista0.totalFaturado(gregorianCalendar2, gregorianCalendar3);
        double d5 = motorista0.getKmsTotais();
        try {
            Motorista motorista6 = motorista0.clone();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertTrue(d4 == 0.0d);
        org.junit.Assert.assertTrue(d5 == 0.0d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        double d4 = motorista0.totalFaturado(gregorianCalendar2, gregorianCalendar3);
        java.lang.Object obj5 = null;
        boolean b6 = motorista0.equals(obj5);
        try {
            Viagem viagem7 = motorista0.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(d4 == 0.0d);
        org.junit.Assert.assertTrue(b6 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "", veiculo5);
        try {
            motorista6.atualizaClassificacao((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type ValueOutOfBoundsException");
        } catch (ValueOutOfBoundsException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.lang.String str2 = motorista0.getMail();
        java.lang.String str3 = motorista0.getMail();
        Coordenada coordenada4 = null;
        try {
            motorista0.atualizaDados(coordenada4, (double) (byte) 0, (double) 10.0f, (double) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        motorista0.atualizaClassificacao(0);
        double d8 = motorista0.getKmsTotais();
        double d9 = motorista0.totalFaturado();
        try {
            Viagem viagem10 = motorista0.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(d8 == 0.0d);
        org.junit.Assert.assertTrue(d9 == 0.0d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        Veiculo veiculo2 = motorista0.getVeiculo();
        java.lang.String str3 = motorista0.getDataDeNascimento();
        double d4 = motorista0.getKmsTotais();
        Viagem viagem5 = null;
        try {
            motorista0.registaViagem(viagem5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNull(veiculo2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue(d4 == 0.0d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        Viagem[] viagem_array5 = new Viagem[] {};
        java.util.LinkedHashSet<Viagem> linkedhashset_viagem6 = new java.util.LinkedHashSet<Viagem>();
        boolean b7 = java.util.Collections.addAll((java.util.Collection<Viagem>) linkedhashset_viagem6, viagem_array5);
        Veiculo veiculo13 = null;
        try {
            Motorista motorista14 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", (java.util.Set<Viagem>) linkedhashset_viagem6, 10, 100, 100, (double) 1, true, veiculo13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(viagem_array5);
        org.junit.Assert.assertTrue(b7 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        java.util.GregorianCalendar gregorianCalendar9 = null;
        java.util.GregorianCalendar gregorianCalendar10 = null;
        double d11 = motorista0.totalFaturado(gregorianCalendar9, gregorianCalendar10);
        try {
            Motorista motorista12 = motorista0.clone();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 10);
        org.junit.Assert.assertTrue(d11 == 0.0d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        Motorista motorista5 = new Motorista();
        Veiculo veiculo6 = motorista5.getVeiculo();
        java.lang.String str7 = motorista5.getMail();
        java.lang.String str8 = motorista5.getDataDeNascimento();
        java.util.Set<Viagem> set_viagem9 = motorista5.getHistorico();
        Veiculo veiculo15 = null;
        try {
            Motorista motorista16 = new Motorista("hi!", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", set_viagem9, (int) '4', (int) (byte) 1, (int) ' ', (double) 1L, false, veiculo15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(set_viagem9);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("hi!", "hi!", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", veiculo5);
        Viagem viagem7 = null;
        try {
            motorista6.registaViagem(viagem7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        Veiculo veiculo2 = motorista0.getVeiculo();
        try {
            Viagem viagem3 = motorista0.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNull(veiculo2);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        java.util.GregorianCalendar gregorianCalendar9 = null;
        java.util.GregorianCalendar gregorianCalendar10 = null;
        double d11 = motorista0.totalFaturado(gregorianCalendar9, gregorianCalendar10);
        java.lang.String str12 = motorista0.toString();
        try {
            Motorista motorista13 = new Motorista(motorista0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 10);
        org.junit.Assert.assertTrue(d11 == 0.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str12.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.getPassword();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        double d4 = motorista0.totalFaturado(gregorianCalendar2, gregorianCalendar3);
        try {
            Motorista motorista5 = motorista0.clone();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertTrue(d4 == 0.0d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        double d4 = motorista0.totalFaturado(gregorianCalendar2, gregorianCalendar3);
        try {
            double d6 = motorista0.tempoViagem(0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(d4 == 0.0d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        int i2 = motorista0.getNumClassi();
        java.lang.String str3 = motorista0.getDataDeNascimento();
        java.util.GregorianCalendar gregorianCalendar4 = null;
        java.util.GregorianCalendar gregorianCalendar5 = null;
        try {
            java.util.List<Viagem> list_viagem6 = motorista0.viagensEntreDatas(gregorianCalendar4, gregorianCalendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(i2 == 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        Motorista motorista3 = new Motorista();
        java.lang.String str4 = motorista3.toString();
        java.lang.String str5 = motorista3.getMail();
        int i6 = motorista0.compareTo((Ator) motorista3);
        java.util.GregorianCalendar gregorianCalendar7 = null;
        java.util.GregorianCalendar gregorianCalendar8 = null;
        try {
            java.util.List<Viagem> list_viagem9 = motorista0.viagensEntreDatas(gregorianCalendar7, gregorianCalendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str4.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue(i6 == 0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        Motorista motorista5 = new Motorista();
        Veiculo veiculo6 = motorista5.getVeiculo();
        java.lang.String str7 = motorista5.getMail();
        java.lang.String str8 = motorista5.getDataDeNascimento();
        java.util.Set<Viagem> set_viagem9 = motorista5.getHistorico();
        Veiculo veiculo15 = null;
        try {
            Motorista motorista16 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", set_viagem9, (int) '4', (int) (byte) 100, (-230), 0.0d, true, veiculo15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(set_viagem9);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.getPassword();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        double d4 = motorista0.totalFaturado(gregorianCalendar2, gregorianCalendar3);
        java.lang.String str5 = motorista0.getPassword();
        try {
            Motorista motorista6 = new Motorista(motorista0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertTrue(d4 == 0.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.lang.String str2 = motorista0.toString();
        java.util.GregorianCalendar gregorianCalendar3 = null;
        java.util.GregorianCalendar gregorianCalendar4 = null;
        try {
            java.util.List<Viagem> list_viagem5 = motorista0.viagensEntreDatas(gregorianCalendar3, gregorianCalendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str2.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        Veiculo veiculo7 = motorista0.getVeiculo();
        double d8 = motorista0.getKmsTotais();
        Motorista motorista9 = new Motorista();
        java.lang.String str10 = motorista9.toString();
        java.lang.String str11 = motorista9.getMail();
        int i12 = motorista0.compareTo((Ator) motorista9);
        try {
            Viagem viagem13 = motorista0.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertNull(veiculo7);
        org.junit.Assert.assertTrue(d8 == 0.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str10.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue(i12 == 0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        Viagem[] viagem_array5 = new Viagem[] {};
        java.util.LinkedHashSet<Viagem> linkedhashset_viagem6 = new java.util.LinkedHashSet<Viagem>();
        boolean b7 = java.util.Collections.addAll((java.util.Collection<Viagem>) linkedhashset_viagem6, viagem_array5);
        Veiculo veiculo13 = null;
        try {
            Motorista motorista14 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", (java.util.Set<Viagem>) linkedhashset_viagem6, 1, (int) (byte) -1, (int) (short) -1, 0.0d, true, veiculo13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(viagem_array5);
        org.junit.Assert.assertTrue(b7 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        Viagem[] viagem_array5 = new Viagem[] {};
        java.util.LinkedHashSet<Viagem> linkedhashset_viagem6 = new java.util.LinkedHashSet<Viagem>();
        boolean b7 = java.util.Collections.addAll((java.util.Collection<Viagem>) linkedhashset_viagem6, viagem_array5);
        Veiculo veiculo13 = null;
        try {
            Motorista motorista14 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", (java.util.Set<Viagem>) linkedhashset_viagem6, (int) (byte) 100, 0, 10, (double) (short) 10, false, veiculo13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(viagem_array5);
        org.junit.Assert.assertTrue(b7 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
        try {
            double d8 = motorista6.precoViagem((double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        Motorista motorista5 = new Motorista();
        java.lang.String str6 = motorista5.toString();
        java.util.GregorianCalendar gregorianCalendar7 = null;
        java.util.GregorianCalendar gregorianCalendar8 = null;
        double d9 = motorista5.totalFaturado(gregorianCalendar7, gregorianCalendar8);
        java.util.Set<Viagem> set_viagem10 = motorista5.getHistorico();
        Veiculo veiculo16 = null;
        try {
            Motorista motorista17 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", set_viagem10, (int) (byte) 0, (int) (byte) -1, (int) (byte) -1, (double) 0.0f, true, veiculo16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str6.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertNotNull(set_viagem10);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        boolean b3 = motorista0.getDisponibilidade();
        boolean b4 = motorista0.getDisponibilidade();
        java.lang.String str5 = motorista0.getDataDeNascimento();
        try {
            motorista0.atualizaClassificacao((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type ValueOutOfBoundsException");
        } catch (ValueOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        java.util.GregorianCalendar gregorianCalendar9 = null;
        java.util.GregorianCalendar gregorianCalendar10 = null;
        double d11 = motorista0.totalFaturado(gregorianCalendar9, gregorianCalendar10);
        try {
            double d13 = motorista0.tempoViagem((-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 10);
        org.junit.Assert.assertTrue(d11 == 0.0d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        Veiculo veiculo11 = null;
        Motorista motorista12 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo11);
        int i13 = motorista0.compareTo(motorista12);
        Viagem viagem14 = null;
        try {
            motorista12.registaViagem(viagem14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i13 == (-230));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        Veiculo veiculo2 = motorista0.getVeiculo();
        java.lang.String str3 = motorista0.getDataDeNascimento();
        java.lang.String str4 = motorista0.getNome();
        Viagem viagem5 = null;
        try {
            motorista0.registaViagem(viagem5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNull(veiculo2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        Motorista motorista9 = new Motorista();
        java.lang.String str10 = motorista9.getPassword();
        java.util.GregorianCalendar gregorianCalendar11 = null;
        java.util.GregorianCalendar gregorianCalendar12 = null;
        double d13 = motorista9.totalFaturado(gregorianCalendar11, gregorianCalendar12);
        double d14 = motorista9.getKmsTotais();
        try {
            boolean b15 = motorista0.equals((java.lang.Object) motorista9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 10);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue(d13 == 0.0d);
        org.junit.Assert.assertTrue(d14 == 0.0d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.util.Set<Viagem> set_viagem5 = null;
        Veiculo veiculo11 = null;
        try {
            Motorista motorista12 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: true\n", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: true\n", set_viagem5, (int) '4', (int) (short) -1, (int) 'a', (double) (short) -1, true, veiculo11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        double d9 = motorista0.totalFaturado();
        java.lang.String str10 = motorista0.toString();
        Motorista motorista11 = new Motorista();
        Veiculo veiculo12 = motorista11.getVeiculo();
        java.lang.String str13 = motorista11.getMail();
        int i14 = motorista11.getNumClassi();
        motorista11.setDisponibilidade(false);
        java.lang.String str17 = motorista11.getMorada();
        int i18 = motorista0.compareTo((Ator) motorista11);
        Viagem viagem19 = null;
        try {
            motorista11.registaViagem(viagem19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 10);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str10.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertNull(veiculo12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue(i18 == 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
        try {
            Motorista motorista7 = new Motorista(motorista6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "", veiculo5);
        int i7 = motorista6.getGrau();
        Coordenada coordenada8 = null;
        try {
            motorista6.atualizaDados(coordenada8, (double) (short) -1, (double) (byte) 0, (double) (-3));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i7 == 100);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        int i2 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao(0);
        java.lang.String str5 = motorista0.getDataDeNascimento();
        Veiculo veiculo6 = null;
        motorista0.setVeiculo(veiculo6);
        Coordenada coordenada8 = null;
        try {
            motorista0.atualizaDados(coordenada8, (double) 1, 1.0d, (double) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(i2 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.getPassword();
        Coordenada coordenada2 = null;
        try {
            motorista0.atualizaDados(coordenada2, 10.0d, (double) (byte) 100, 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        try {
            Viagem viagem2 = motorista0.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        Motorista motorista5 = new Motorista();
        Veiculo veiculo6 = motorista5.getVeiculo();
        java.lang.String str7 = motorista5.getMail();
        int i8 = motorista5.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar9 = null;
        java.util.GregorianCalendar gregorianCalendar10 = null;
        double d11 = motorista5.totalFaturado(gregorianCalendar9, gregorianCalendar10);
        java.lang.String str12 = motorista5.getMorada();
        int i13 = motorista5.getGrau();
        java.util.Set<Viagem> set_viagem14 = motorista5.getHistorico();
        Veiculo veiculo20 = null;
        try {
            Motorista motorista21 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: true\n", "hi!", set_viagem14, (-3), 100, (int) '#', (double) 'a', false, veiculo20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue(d11 == 0.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertNotNull(set_viagem14);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        Motorista motorista0 = new Motorista();
        double d1 = motorista0.totalFaturado();
        boolean b2 = motorista0.getDisponibilidade();
        java.lang.String str3 = motorista0.getNome();
        org.junit.Assert.assertTrue(d1 == 0.0d);
        org.junit.Assert.assertTrue(b2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.lang.String str2 = motorista0.getMail();
        java.lang.String str3 = motorista0.getMail();
        motorista0.atualizaClassificacao((int) (byte) 1);
        Motorista motorista6 = new Motorista();
        Veiculo veiculo7 = motorista6.getVeiculo();
        java.lang.String str8 = motorista6.getMail();
        int i9 = motorista6.getNumClassi();
        motorista6.atualizaClassificacao((int) (byte) 10);
        motorista6.atualizaClassificacao(0);
        java.lang.String str14 = motorista6.getMorada();
        int i15 = motorista0.compareTo(motorista6);
        Viagem viagem16 = null;
        try {
            motorista0.registaViagem(viagem16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNull(veiculo7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue(i15 == (-1));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        java.util.GregorianCalendar gregorianCalendar9 = null;
        java.util.GregorianCalendar gregorianCalendar10 = null;
        double d11 = motorista0.totalFaturado(gregorianCalendar9, gregorianCalendar10);
        java.util.GregorianCalendar gregorianCalendar12 = null;
        java.util.GregorianCalendar gregorianCalendar13 = null;
        double d14 = motorista0.totalFaturado(gregorianCalendar12, gregorianCalendar13);
        Veiculo veiculo15 = null;
        motorista0.setVeiculo(veiculo15);
        try {
            Viagem viagem17 = motorista0.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 10);
        org.junit.Assert.assertTrue(d11 == 0.0d);
        org.junit.Assert.assertTrue(d14 == 0.0d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "", veiculo5);
        Coordenada coordenada7 = null;
        try {
            motorista6.atualizaDados(coordenada7, (double) '#', (double) 100.0f, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "hi!", "hi!", veiculo5);
        motorista6.atualizaClassificacao(100);
        double d9 = motorista6.totalFaturado();
        Viagem viagem10 = null;
        try {
            motorista6.registaViagem(viagem10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(d9 == 0.0d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        boolean b3 = motorista0.equals((java.lang.Object) (byte) 10);
        int i4 = motorista0.getGrau();
        java.lang.String str5 = motorista0.getNome();
        java.util.GregorianCalendar gregorianCalendar6 = null;
        java.util.GregorianCalendar gregorianCalendar7 = null;
        try {
            java.util.List<Viagem> list_viagem8 = motorista0.viagensEntreDatas(gregorianCalendar6, gregorianCalendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        double d9 = motorista0.totalFaturado();
        java.lang.String str10 = motorista0.toString();
        Motorista motorista11 = new Motorista();
        Veiculo veiculo12 = motorista11.getVeiculo();
        java.lang.String str13 = motorista11.getMail();
        int i14 = motorista11.getNumClassi();
        motorista11.setDisponibilidade(false);
        java.lang.String str17 = motorista11.getMorada();
        int i18 = motorista0.compareTo((Ator) motorista11);
        try {
            motorista0.atualizaClassificacao((-3));
            org.junit.Assert.fail("Expected exception of type ValueOutOfBoundsException");
        } catch (ValueOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 10);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str10.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertNull(veiculo12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue(i18 == 0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        Veiculo veiculo2 = motorista0.getVeiculo();
        double d3 = motorista0.getKmsTotais();
        motorista0.setDisponibilidade(true);
        try {
            Viagem viagem6 = motorista0.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNull(veiculo2);
        org.junit.Assert.assertTrue(d3 == 0.0d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", veiculo5);
        Viagem viagem7 = null;
        try {
            motorista6.registaViagem(viagem7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        try {
            java.util.List<Viagem> list_viagem4 = motorista0.viagensEntreDatas(gregorianCalendar2, gregorianCalendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        java.lang.String str3 = motorista0.getDataDeNascimento();
        java.util.Set<Viagem> set_viagem4 = motorista0.getHistorico();
        try {
            Viagem viagem5 = motorista0.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNotNull(set_viagem4);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar4 = null;
        java.util.GregorianCalendar gregorianCalendar5 = null;
        double d6 = motorista0.totalFaturado(gregorianCalendar4, gregorianCalendar5);
        java.lang.String str7 = motorista0.getMorada();
        int i8 = motorista0.getGrau();
        try {
            double d10 = motorista0.precoViagem((double) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        double d4 = motorista0.totalFaturado(gregorianCalendar2, gregorianCalendar3);
        motorista0.setDisponibilidade(false);
        java.lang.String str7 = motorista0.getMorada();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(d4 == 0.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        double d4 = motorista0.totalFaturado(gregorianCalendar2, gregorianCalendar3);
        java.lang.Object obj5 = null;
        boolean b6 = motorista0.equals(obj5);
        motorista0.setDisponibilidade(true);
        java.util.GregorianCalendar gregorianCalendar9 = null;
        java.util.GregorianCalendar gregorianCalendar10 = null;
        try {
            java.util.List<Viagem> list_viagem11 = motorista0.viagensEntreDatas(gregorianCalendar9, gregorianCalendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(d4 == 0.0d);
        org.junit.Assert.assertTrue(b6 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", veiculo5);
        java.util.GregorianCalendar gregorianCalendar7 = null;
        java.util.GregorianCalendar gregorianCalendar8 = null;
        double d9 = motorista6.totalFaturado(gregorianCalendar7, gregorianCalendar8);
        try {
            Motorista motorista10 = new Motorista(motorista6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(d9 == 0.0d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        double d4 = motorista0.totalFaturado(gregorianCalendar2, gregorianCalendar3);
        java.util.Set<Viagem> set_viagem5 = motorista0.getHistorico();
        try {
            double d7 = motorista0.tempoViagem((double) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(d4 == 0.0d);
        org.junit.Assert.assertNotNull(set_viagem5);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        Veiculo veiculo6 = null;
        motorista0.setVeiculo(veiculo6);
        Viagem viagem8 = null;
        try {
            motorista0.registaViagem(viagem8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.getPassword();
        motorista0.atualizaClassificacao(100);
        try {
            Viagem viagem4 = motorista0.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        Veiculo veiculo7 = motorista0.getVeiculo();
        Motorista motorista8 = new Motorista();
        Veiculo veiculo9 = motorista8.getVeiculo();
        java.lang.String str10 = motorista8.getMail();
        int i11 = motorista0.compareTo((Ator) motorista8);
        try {
            Viagem viagem12 = motorista0.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertNull(veiculo7);
        org.junit.Assert.assertNull(veiculo9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue(i11 == 0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar4 = null;
        java.util.GregorianCalendar gregorianCalendar5 = null;
        double d6 = motorista0.totalFaturado(gregorianCalendar4, gregorianCalendar5);
        java.lang.String str7 = motorista0.getMorada();
        try {
            Motorista motorista8 = motorista0.clone();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.lang.String str2 = motorista0.getMail();
        java.lang.String str3 = motorista0.getMail();
        boolean b4 = motorista0.getDisponibilidade();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue(b4 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
        try {
            Motorista motorista7 = motorista6.clone();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        Viagem[] viagem_array5 = new Viagem[] {};
        java.util.LinkedHashSet<Viagem> linkedhashset_viagem6 = new java.util.LinkedHashSet<Viagem>();
        boolean b7 = java.util.Collections.addAll((java.util.Collection<Viagem>) linkedhashset_viagem6, viagem_array5);
        Veiculo veiculo13 = null;
        try {
            Motorista motorista14 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", "", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", (java.util.Set<Viagem>) linkedhashset_viagem6, (int) '#', (int) '4', (int) 'a', (double) '4', false, veiculo13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(viagem_array5);
        org.junit.Assert.assertTrue(b7 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar4 = null;
        java.util.GregorianCalendar gregorianCalendar5 = null;
        double d6 = motorista0.totalFaturado(gregorianCalendar4, gregorianCalendar5);
        boolean b7 = motorista0.getDisponibilidade();
        java.util.GregorianCalendar gregorianCalendar8 = null;
        java.util.GregorianCalendar gregorianCalendar9 = null;
        try {
            java.util.List<Viagem> list_viagem10 = motorista0.viagensEntreDatas(gregorianCalendar8, gregorianCalendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(b7 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        try {
            Viagem viagem4 = motorista0.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        double d9 = motorista0.totalFaturado();
        java.util.GregorianCalendar gregorianCalendar10 = null;
        java.util.GregorianCalendar gregorianCalendar11 = null;
        double d12 = motorista0.totalFaturado(gregorianCalendar10, gregorianCalendar11);
        java.util.Set<Viagem> set_viagem13 = motorista0.getHistorico();
        java.lang.String str14 = motorista0.getPassword();
        try {
            Motorista motorista15 = motorista0.clone();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 10);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue(d12 == 0.0d);
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        Motorista motorista5 = new Motorista();
        double d6 = motorista5.totalFaturado();
        boolean b7 = motorista5.getDisponibilidade();
        java.util.Set<Viagem> set_viagem8 = motorista5.getHistorico();
        Veiculo veiculo14 = null;
        try {
            Motorista motorista15 = new Motorista("hi!", "", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", "hi!", set_viagem8, 0, 0, (-3), (double) ' ', false, veiculo14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(b7 == false);
        org.junit.Assert.assertNotNull(set_viagem8);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        Veiculo veiculo7 = motorista0.getVeiculo();
        Coordenada coordenada8 = null;
        try {
            motorista0.atualizaDados(coordenada8, (double) 100L, (double) (short) 1, (double) 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertNull(veiculo7);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        Coordenada coordenada4 = null;
        try {
            motorista0.atualizaDados(coordenada4, (double) (-1), 10.0d, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "hi!", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", veiculo5);
        Motorista motorista7 = new Motorista();
        int i8 = motorista7.getGrau();
        Veiculo veiculo9 = motorista7.getVeiculo();
        java.lang.String str10 = motorista7.getDataDeNascimento();
        java.lang.String str11 = motorista7.getNome();
        java.util.GregorianCalendar gregorianCalendar12 = null;
        java.util.GregorianCalendar gregorianCalendar13 = null;
        double d14 = motorista7.totalFaturado(gregorianCalendar12, gregorianCalendar13);
        try {
            boolean b15 = motorista6.equals((java.lang.Object) motorista7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertNull(veiculo9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue(d14 == 0.0d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        motorista0.atualizaClassificacao(0);
        java.lang.String str8 = motorista0.getMorada();
        java.lang.String str9 = motorista0.toString();
        Viagem viagem10 = null;
        try {
            motorista0.registaViagem(viagem10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str9.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar4 = null;
        java.util.GregorianCalendar gregorianCalendar5 = null;
        double d6 = motorista0.totalFaturado(gregorianCalendar4, gregorianCalendar5);
        boolean b7 = motorista0.getDisponibilidade();
        try {
            double d9 = motorista0.tempoViagem((double) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(b7 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        Motorista motorista0 = new Motorista();
        double d1 = motorista0.totalFaturado();
        motorista0.setDisponibilidade(false);
        java.util.GregorianCalendar gregorianCalendar4 = null;
        java.util.GregorianCalendar gregorianCalendar5 = null;
        try {
            java.util.List<Viagem> list_viagem6 = motorista0.viagensEntreDatas(gregorianCalendar4, gregorianCalendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(d1 == 0.0d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.lang.String str2 = motorista0.getMail();
        java.lang.String str3 = motorista0.getMail();
        motorista0.atualizaClassificacao((int) (byte) 1);
        Motorista motorista6 = new Motorista();
        Veiculo veiculo7 = motorista6.getVeiculo();
        java.lang.String str8 = motorista6.getMail();
        int i9 = motorista6.getNumClassi();
        motorista6.atualizaClassificacao((int) (byte) 10);
        motorista6.atualizaClassificacao(0);
        java.lang.String str14 = motorista6.getMorada();
        int i15 = motorista0.compareTo(motorista6);
        java.util.GregorianCalendar gregorianCalendar16 = null;
        java.util.GregorianCalendar gregorianCalendar17 = null;
        try {
            java.util.List<Viagem> list_viagem18 = motorista6.viagensEntreDatas(gregorianCalendar16, gregorianCalendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNull(veiculo7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue(i15 == (-1));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        java.lang.String str4 = motorista0.getPassword();
        java.util.GregorianCalendar gregorianCalendar5 = null;
        java.util.GregorianCalendar gregorianCalendar6 = null;
        try {
            java.util.List<Viagem> list_viagem7 = motorista0.viagensEntreDatas(gregorianCalendar5, gregorianCalendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        java.lang.String str4 = motorista0.getDataDeNascimento();
        java.util.Set<Viagem> set_viagem5 = motorista0.getHistorico();
        Viagem viagem6 = null;
        try {
            motorista0.registaViagem(viagem6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(set_viagem5);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        Motorista motorista5 = new Motorista();
        Veiculo veiculo6 = motorista5.getVeiculo();
        java.lang.String str7 = motorista5.getMail();
        int i8 = motorista5.getNumClassi();
        motorista5.atualizaClassificacao((int) (byte) 10);
        int i11 = motorista5.getNumClassi();
        java.lang.String str12 = motorista5.getNome();
        int i13 = motorista5.getClassificacao();
        double d14 = motorista5.totalFaturado();
        java.util.GregorianCalendar gregorianCalendar15 = null;
        java.util.GregorianCalendar gregorianCalendar16 = null;
        double d17 = motorista5.totalFaturado(gregorianCalendar15, gregorianCalendar16);
        java.util.Set<Viagem> set_viagem18 = motorista5.getHistorico();
        java.lang.String str19 = motorista5.getPassword();
        java.util.Set<Viagem> set_viagem20 = motorista5.getHistorico();
        Veiculo veiculo26 = null;
        try {
            Motorista motorista27 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "", set_viagem20, (int) (short) 0, 100, (-3), (-1.0d), true, veiculo26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue(i11 == 1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue(i13 == 10);
        org.junit.Assert.assertTrue(d14 == 0.0d);
        org.junit.Assert.assertTrue(d17 == 0.0d);
        org.junit.Assert.assertNotNull(set_viagem18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNotNull(set_viagem20);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        boolean b3 = motorista0.equals((java.lang.Object) (byte) 10);
        int i4 = motorista0.getGrau();
        java.lang.String str5 = motorista0.getNome();
        int i6 = motorista0.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar7 = null;
        java.util.GregorianCalendar gregorianCalendar8 = null;
        double d9 = motorista0.totalFaturado(gregorianCalendar7, gregorianCalendar8);
        java.lang.String str10 = motorista0.getMorada();
        java.util.GregorianCalendar gregorianCalendar11 = null;
        java.util.GregorianCalendar gregorianCalendar12 = null;
        try {
            java.util.List<Viagem> list_viagem13 = motorista0.viagensEntreDatas(gregorianCalendar11, gregorianCalendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", veiculo5);
        try {
            double d8 = motorista6.precoViagem((double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        Veiculo veiculo2 = motorista0.getVeiculo();
        java.lang.String str3 = motorista0.toString();
        Coordenada coordenada4 = null;
        try {
            motorista0.atualizaDados(coordenada4, (double) (-1.0f), (double) (-1), (double) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNull(veiculo2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str3.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.getPassword();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        double d4 = motorista0.totalFaturado(gregorianCalendar2, gregorianCalendar3);
        java.lang.String str5 = motorista0.getPassword();
        try {
            Motorista motorista6 = motorista0.clone();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertTrue(d4 == 0.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        Motorista motorista5 = new Motorista();
        int i6 = motorista5.getGrau();
        boolean b8 = motorista5.equals((java.lang.Object) (byte) 10);
        java.util.Set<Viagem> set_viagem9 = motorista5.getHistorico();
        Veiculo veiculo15 = null;
        try {
            Motorista motorista16 = new Motorista("E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", set_viagem9, 0, (int) (byte) 1, (int) (byte) 0, (double) '#', true, veiculo15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertTrue(b8 == false);
        org.junit.Assert.assertNotNull(set_viagem9);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        Motorista motorista5 = new Motorista();
        Veiculo veiculo6 = motorista5.getVeiculo();
        java.lang.String str7 = motorista5.getMail();
        int i8 = motorista5.getNumClassi();
        motorista5.atualizaClassificacao((int) (byte) 10);
        int i11 = motorista5.getNumClassi();
        java.lang.String str12 = motorista5.getNome();
        int i13 = motorista5.getClassificacao();
        double d14 = motorista5.totalFaturado();
        java.util.GregorianCalendar gregorianCalendar15 = null;
        java.util.GregorianCalendar gregorianCalendar16 = null;
        double d17 = motorista5.totalFaturado(gregorianCalendar15, gregorianCalendar16);
        java.util.Set<Viagem> set_viagem18 = motorista5.getHistorico();
        Veiculo veiculo24 = null;
        try {
            Motorista motorista25 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: true\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", set_viagem18, (int) (short) 1, (int) ' ', (int) (short) 100, 100.0d, true, veiculo24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue(i11 == 1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue(i13 == 10);
        org.junit.Assert.assertTrue(d14 == 0.0d);
        org.junit.Assert.assertTrue(d17 == 0.0d);
        org.junit.Assert.assertNotNull(set_viagem18);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar4 = null;
        java.util.GregorianCalendar gregorianCalendar5 = null;
        double d6 = motorista0.totalFaturado(gregorianCalendar4, gregorianCalendar5);
        java.lang.String str7 = motorista0.getMorada();
        int i8 = motorista0.getGrau();
        try {
            double d10 = motorista0.tempoViagem((double) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.getPassword();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        double d4 = motorista0.totalFaturado(gregorianCalendar2, gregorianCalendar3);
        double d5 = motorista0.getKmsTotais();
        java.util.GregorianCalendar gregorianCalendar6 = null;
        java.util.GregorianCalendar gregorianCalendar7 = null;
        double d8 = motorista0.totalFaturado(gregorianCalendar6, gregorianCalendar7);
        java.lang.String str9 = motorista0.getNome();
        Viagem viagem10 = null;
        try {
            motorista0.registaViagem(viagem10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertTrue(d4 == 0.0d);
        org.junit.Assert.assertTrue(d5 == 0.0d);
        org.junit.Assert.assertTrue(d8 == 0.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.lang.String str2 = motorista0.getMail();
        java.lang.String str3 = motorista0.getMail();
        Veiculo veiculo4 = motorista0.getVeiculo();
        try {
            Viagem viagem5 = motorista0.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNull(veiculo4);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        Veiculo veiculo11 = null;
        Motorista motorista12 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo11);
        int i13 = motorista0.compareTo(motorista12);
        Coordenada coordenada14 = null;
        try {
            motorista12.atualizaDados(coordenada14, (double) (short) 0, 0.0d, (double) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i13 == (-230));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        java.util.GregorianCalendar gregorianCalendar9 = null;
        java.util.GregorianCalendar gregorianCalendar10 = null;
        double d11 = motorista0.totalFaturado(gregorianCalendar9, gregorianCalendar10);
        Veiculo veiculo12 = motorista0.getVeiculo();
        java.util.GregorianCalendar gregorianCalendar13 = null;
        java.util.GregorianCalendar gregorianCalendar14 = null;
        try {
            java.util.List<Viagem> list_viagem15 = motorista0.viagensEntreDatas(gregorianCalendar13, gregorianCalendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 10);
        org.junit.Assert.assertTrue(d11 == 0.0d);
        org.junit.Assert.assertNull(veiculo12);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        Motorista motorista5 = new Motorista();
        Veiculo veiculo6 = motorista5.getVeiculo();
        java.lang.String str7 = motorista5.getMail();
        java.lang.String str8 = motorista5.getDataDeNascimento();
        java.util.Set<Viagem> set_viagem9 = motorista5.getHistorico();
        Veiculo veiculo15 = null;
        try {
            Motorista motorista16 = new Motorista("hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", set_viagem9, (int) 'a', (int) (byte) 100, 0, 0.0d, false, veiculo15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(set_viagem9);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        Motorista motorista0 = new Motorista();
        double d1 = motorista0.totalFaturado();
        boolean b2 = motorista0.getDisponibilidade();
        java.util.Set<Viagem> set_viagem3 = motorista0.getHistorico();
        Veiculo veiculo9 = null;
        Motorista motorista10 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo9);
        java.lang.String str11 = motorista10.getPassword();
        try {
            boolean b12 = motorista0.equals((java.lang.Object) motorista10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(d1 == 0.0d);
        org.junit.Assert.assertTrue(b2 == false);
        org.junit.Assert.assertNotNull(set_viagem3);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        Veiculo veiculo6 = motorista0.getVeiculo();
        motorista0.atualizaClassificacao(100);
        Veiculo veiculo9 = motorista0.getVeiculo();
        Veiculo veiculo15 = null;
        Motorista motorista16 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "", veiculo15);
        int i17 = motorista16.getGrau();
        int i18 = motorista0.compareTo((Ator) motorista16);
        try {
            Motorista motorista19 = new Motorista(motorista0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertNull(veiculo6);
        org.junit.Assert.assertNull(veiculo9);
        org.junit.Assert.assertTrue(i17 == 100);
        org.junit.Assert.assertTrue(i18 == (-230));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        Motorista motorista5 = new Motorista();
        java.lang.String str6 = motorista5.toString();
        java.util.GregorianCalendar gregorianCalendar7 = null;
        java.util.GregorianCalendar gregorianCalendar8 = null;
        double d9 = motorista5.totalFaturado(gregorianCalendar7, gregorianCalendar8);
        java.util.Set<Viagem> set_viagem10 = motorista5.getHistorico();
        Veiculo veiculo16 = null;
        try {
            Motorista motorista17 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: true\n", "E-mail: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nNome: hi!\nPassword: hi!\nMorada: hi!\nData de nascimento: hi!\nGrau de cumprimento de horário: 100\nClassificação do motorista: 50\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: true\n", set_viagem10, (int) 'a', (-230), (-230), (double) 0.0f, true, veiculo16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str6.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertNotNull(set_viagem10);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar4 = null;
        java.util.GregorianCalendar gregorianCalendar5 = null;
        double d6 = motorista0.totalFaturado(gregorianCalendar4, gregorianCalendar5);
        boolean b7 = motorista0.getDisponibilidade();
        motorista0.setDisponibilidade(false);
        int i10 = motorista0.getNumClassi();
        try {
            Motorista motorista11 = motorista0.clone();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(b7 == false);
        org.junit.Assert.assertTrue(i10 == 0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        Motorista motorista0 = new Motorista();
        double d1 = motorista0.totalFaturado();
        int i2 = motorista0.getGrau();
        boolean b3 = motorista0.getDisponibilidade();
        int i4 = motorista0.getClassificacao();
        motorista0.atualizaClassificacao((int) '#');
        java.util.GregorianCalendar gregorianCalendar7 = null;
        java.util.GregorianCalendar gregorianCalendar8 = null;
        try {
            java.util.List<Viagem> list_viagem9 = motorista0.viagensEntreDatas(gregorianCalendar7, gregorianCalendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(d1 == 0.0d);
        org.junit.Assert.assertTrue(i2 == 0);
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertTrue(i4 == 0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        Veiculo veiculo6 = null;
        motorista0.setVeiculo(veiculo6);
        java.lang.String str8 = motorista0.getDataDeNascimento();
        motorista0.setDisponibilidade(true);
        double d11 = motorista0.totalFaturado();
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue(d11 == 0.0d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.getPassword();
        java.lang.String str2 = motorista0.getDataDeNascimento();
        boolean b4 = motorista0.equals((java.lang.Object) 100L);
        int i5 = motorista0.getClassificacao();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(i5 == 0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        boolean b3 = motorista0.equals((java.lang.Object) (byte) 10);
        java.util.GregorianCalendar gregorianCalendar4 = null;
        java.util.GregorianCalendar gregorianCalendar5 = null;
        double d6 = motorista0.totalFaturado(gregorianCalendar4, gregorianCalendar5);
        int i7 = motorista0.getClassificacao();
        Coordenada coordenada8 = null;
        try {
            motorista0.atualizaDados(coordenada8, (double) 0, 0.0d, (double) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(i7 == 0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("hi!", "hi!", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", veiculo5);
        int i7 = motorista6.getNumClassi();
        java.lang.String str8 = motorista6.toString();
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "E-mail: hi!\nNome: hi!\nPassword: hi!\nMorada: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str8.equals("E-mail: hi!\nNome: hi!\nPassword: hi!\nMorada: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar4 = null;
        java.util.GregorianCalendar gregorianCalendar5 = null;
        double d6 = motorista0.totalFaturado(gregorianCalendar4, gregorianCalendar5);
        boolean b7 = motorista0.getDisponibilidade();
        motorista0.setDisponibilidade(false);
        int i10 = motorista0.getNumClassi();
        try {
            double d12 = motorista0.precoViagem((double) (-35));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(b7 == false);
        org.junit.Assert.assertTrue(i10 == 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        double d4 = motorista0.totalFaturado(gregorianCalendar2, gregorianCalendar3);
        java.lang.Object obj5 = null;
        boolean b6 = motorista0.equals(obj5);
        try {
            motorista0.atualizaClassificacao((-1));
            org.junit.Assert.fail("Expected exception of type ValueOutOfBoundsException");
        } catch (ValueOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(d4 == 0.0d);
        org.junit.Assert.assertTrue(b6 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        Viagem[] viagem_array5 = new Viagem[] {};
        java.util.LinkedHashSet<Viagem> linkedhashset_viagem6 = new java.util.LinkedHashSet<Viagem>();
        boolean b7 = java.util.Collections.addAll((java.util.Collection<Viagem>) linkedhashset_viagem6, viagem_array5);
        Veiculo veiculo13 = null;
        try {
            Motorista motorista14 = new Motorista("E-mail: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nNome: hi!\nPassword: hi!\nMorada: hi!\nData de nascimento: hi!\nGrau de cumprimento de horário: 100\nClassificação do motorista: 50\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: true\n", (java.util.Set<Viagem>) linkedhashset_viagem6, (int) (byte) 10, (int) (short) 0, (int) (byte) 10, (double) (byte) 1, false, veiculo13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(viagem_array5);
        org.junit.Assert.assertTrue(b7 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "hi!", "hi!", veiculo5);
        java.util.GregorianCalendar gregorianCalendar7 = null;
        java.util.GregorianCalendar gregorianCalendar8 = null;
        double d9 = motorista6.totalFaturado(gregorianCalendar7, gregorianCalendar8);
        java.lang.String str10 = motorista6.getNome();
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", "", veiculo5);
        try {
            double d8 = motorista6.tempoViagem(100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.getPassword();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        double d4 = motorista0.totalFaturado(gregorianCalendar2, gregorianCalendar3);
        double d5 = motorista0.getKmsTotais();
        try {
            double d7 = motorista0.tempoViagem((double) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertTrue(d4 == 0.0d);
        org.junit.Assert.assertTrue(d5 == 0.0d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        Viagem[] viagem_array5 = new Viagem[] {};
        java.util.LinkedHashSet<Viagem> linkedhashset_viagem6 = new java.util.LinkedHashSet<Viagem>();
        boolean b7 = java.util.Collections.addAll((java.util.Collection<Viagem>) linkedhashset_viagem6, viagem_array5);
        Veiculo veiculo13 = null;
        try {
            Motorista motorista14 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nNome: hi!\nPassword: hi!\nMorada: hi!\nData de nascimento: hi!\nGrau de cumprimento de horário: 100\nClassificação do motorista: 50\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", "E-mail: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nNome: hi!\nPassword: hi!\nMorada: hi!\nData de nascimento: hi!\nGrau de cumprimento de horário: 100\nClassificação do motorista: 50\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", (java.util.Set<Viagem>) linkedhashset_viagem6, 10, (int) '#', (-1), (double) 100, false, veiculo13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(viagem_array5);
        org.junit.Assert.assertTrue(b7 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: true\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", veiculo5);
        Viagem viagem7 = null;
        try {
            motorista6.registaViagem(viagem7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "", "", veiculo5);
        int i7 = motorista6.getNumClassi();
        try {
            double d9 = motorista6.tempoViagem((double) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i7 == 0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
        java.lang.String str7 = motorista6.getPassword();
        java.lang.String str8 = motorista6.getMail();
        try {
            Viagem viagem9 = motorista6.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        java.lang.String str4 = motorista0.getPassword();
        java.lang.String str5 = motorista0.getMail();
        try {
            Viagem viagem6 = motorista0.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "", veiculo5);
        boolean b7 = motorista6.getDisponibilidade();
        java.util.GregorianCalendar gregorianCalendar8 = null;
        java.util.GregorianCalendar gregorianCalendar9 = null;
        try {
            java.util.List<Viagem> list_viagem10 = motorista6.viagensEntreDatas(gregorianCalendar8, gregorianCalendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(b7 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        java.lang.String str4 = motorista0.getDataDeNascimento();
        Motorista motorista5 = null;
        try {
            int i6 = motorista0.compareTo(motorista5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        Veiculo veiculo6 = motorista0.getVeiculo();
        motorista0.atualizaClassificacao(100);
        java.util.GregorianCalendar gregorianCalendar9 = null;
        java.util.GregorianCalendar gregorianCalendar10 = null;
        try {
            java.util.List<Viagem> list_viagem11 = motorista0.viagensEntreDatas(gregorianCalendar9, gregorianCalendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertNull(veiculo6);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        Veiculo veiculo3 = motorista0.getVeiculo();
        boolean b4 = motorista0.getDisponibilidade();
        try {
            motorista0.atualizaClassificacao((-230));
            org.junit.Assert.fail("Expected exception of type ValueOutOfBoundsException");
        } catch (ValueOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNull(veiculo3);
        org.junit.Assert.assertTrue(b4 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        java.lang.String str4 = motorista0.getPassword();
        java.lang.String str5 = motorista0.toString();
        try {
            motorista0.atualizaClassificacao((-3));
            org.junit.Assert.fail("Expected exception of type ValueOutOfBoundsException");
        } catch (ValueOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str5.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        motorista0.atualizaClassificacao(0);
        Veiculo veiculo8 = motorista0.getVeiculo();
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertNull(veiculo8);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
        Viagem viagem7 = null;
        try {
            motorista6.registaViagem(viagem7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: true\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: true\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: true\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: true\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
        int i7 = motorista6.getClassificacao();
        java.util.GregorianCalendar gregorianCalendar8 = null;
        java.util.GregorianCalendar gregorianCalendar9 = null;
        try {
            java.util.List<Viagem> list_viagem10 = motorista6.viagensEntreDatas(gregorianCalendar8, gregorianCalendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i7 == 100);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.lang.String str2 = motorista0.toString();
        java.lang.String str3 = motorista0.getDataDeNascimento();
        try {
            Viagem viagem4 = motorista0.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str2.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        double d9 = motorista0.totalFaturado();
        java.lang.String str10 = motorista0.toString();
        java.util.GregorianCalendar gregorianCalendar11 = null;
        java.util.GregorianCalendar gregorianCalendar12 = null;
        try {
            java.util.List<Viagem> list_viagem13 = motorista0.viagensEntreDatas(gregorianCalendar11, gregorianCalendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 10);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str10.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        Motorista motorista5 = new Motorista();
        java.lang.String str6 = motorista5.toString();
        java.util.GregorianCalendar gregorianCalendar7 = null;
        java.util.GregorianCalendar gregorianCalendar8 = null;
        double d9 = motorista5.totalFaturado(gregorianCalendar7, gregorianCalendar8);
        java.util.Set<Viagem> set_viagem10 = motorista5.getHistorico();
        Veiculo veiculo16 = null;
        try {
            Motorista motorista17 = new Motorista("hi!", "E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: true\n", "E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", set_viagem10, (int) (byte) 10, (int) (byte) 100, (int) (short) 0, (double) '4', false, veiculo16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str6.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertNotNull(set_viagem10);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        double d4 = motorista0.totalFaturado(gregorianCalendar2, gregorianCalendar3);
        try {
            motorista0.atualizaClassificacao((-3));
            org.junit.Assert.fail("Expected exception of type ValueOutOfBoundsException");
        } catch (ValueOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(d4 == 0.0d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("hi!", "hi!", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", veiculo5);
        int i7 = motorista6.getNumClassi();
        Coordenada coordenada8 = null;
        try {
            motorista6.atualizaDados(coordenada8, (double) (short) 1, (double) (byte) 1, (double) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i7 == 0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        java.util.GregorianCalendar gregorianCalendar9 = null;
        java.util.GregorianCalendar gregorianCalendar10 = null;
        double d11 = motorista0.totalFaturado(gregorianCalendar9, gregorianCalendar10);
        Veiculo veiculo12 = null;
        motorista0.setVeiculo(veiculo12);
        motorista0.setDisponibilidade(false);
        try {
            double d17 = motorista0.tempoViagem((double) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 10);
        org.junit.Assert.assertTrue(d11 == 0.0d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "hi!", "hi!", veiculo5);
        motorista6.atualizaClassificacao(100);
        double d9 = motorista6.totalFaturado();
        try {
            Viagem viagem10 = motorista6.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertTrue(d9 == 0.0d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        boolean b3 = motorista0.getDisponibilidade();
        int i4 = motorista0.getClassificacao();
        java.lang.String str5 = motorista0.getDataDeNascimento();
        java.lang.String str6 = motorista0.getDataDeNascimento();
        Viagem viagem7 = null;
        try {
            motorista0.registaViagem(viagem7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        boolean b3 = motorista0.getDisponibilidade();
        int i4 = motorista0.getClassificacao();
        java.lang.String str5 = motorista0.getDataDeNascimento();
        Coordenada coordenada6 = null;
        try {
            motorista0.atualizaDados(coordenada6, (double) (-1), 0.0d, (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.getPassword();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        double d4 = motorista0.totalFaturado(gregorianCalendar2, gregorianCalendar3);
        double d5 = motorista0.getKmsTotais();
        java.util.GregorianCalendar gregorianCalendar6 = null;
        java.util.GregorianCalendar gregorianCalendar7 = null;
        double d8 = motorista0.totalFaturado(gregorianCalendar6, gregorianCalendar7);
        java.lang.String str9 = motorista0.getNome();
        Veiculo veiculo10 = motorista0.getVeiculo();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertTrue(d4 == 0.0d);
        org.junit.Assert.assertTrue(d5 == 0.0d);
        org.junit.Assert.assertTrue(d8 == 0.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNull(veiculo10);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        boolean b3 = motorista0.equals((java.lang.Object) (byte) 10);
        java.util.GregorianCalendar gregorianCalendar4 = null;
        java.util.GregorianCalendar gregorianCalendar5 = null;
        double d6 = motorista0.totalFaturado(gregorianCalendar4, gregorianCalendar5);
        motorista0.atualizaClassificacao((int) (short) 100);
        try {
            double d10 = motorista0.precoViagem((double) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("hi!", "E-mail: hi!\nNome: hi!\nPassword: hi!\nMorada: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
        motorista6.setDisponibilidade(false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        Viagem viagem2 = null;
        try {
            motorista0.registaViagem(viagem2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        boolean b3 = motorista0.getDisponibilidade();
        boolean b4 = motorista0.getDisponibilidade();
        java.lang.String str5 = motorista0.getDataDeNascimento();
        Veiculo veiculo6 = motorista0.getVeiculo();
        Viagem viagem7 = null;
        try {
            motorista0.registaViagem(viagem7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNull(veiculo6);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "hi!", "hi!", veiculo5);
        motorista6.atualizaClassificacao(100);
        motorista6.atualizaClassificacao((int) (short) 1);
        try {
            motorista6.atualizaClassificacao((-35));
            org.junit.Assert.fail("Expected exception of type ValueOutOfBoundsException");
        } catch (ValueOutOfBoundsException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        double d9 = motorista0.totalFaturado();
        java.lang.String str10 = motorista0.toString();
        try {
            motorista0.atualizaClassificacao((-35));
            org.junit.Assert.fail("Expected exception of type ValueOutOfBoundsException");
        } catch (ValueOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 10);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str10.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", veiculo5);
        double d7 = motorista6.totalFaturado();
        java.util.GregorianCalendar gregorianCalendar8 = null;
        java.util.GregorianCalendar gregorianCalendar9 = null;
        try {
            java.util.List<Viagem> list_viagem10 = motorista6.viagensEntreDatas(gregorianCalendar8, gregorianCalendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(d7 == 0.0d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        boolean b3 = motorista0.equals((java.lang.Object) (byte) 10);
        Veiculo veiculo4 = motorista0.getVeiculo();
        java.lang.String str5 = motorista0.getMorada();
        try {
            Viagem viagem6 = motorista0.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertNull(veiculo4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.lang.String str2 = motorista0.getMail();
        java.lang.String str3 = motorista0.getMail();
        java.lang.String str4 = motorista0.toString();
        double d5 = motorista0.totalFaturado();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str4.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(d5 == 0.0d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        Veiculo veiculo2 = motorista0.getVeiculo();
        java.lang.String str3 = motorista0.getDataDeNascimento();
        java.util.GregorianCalendar gregorianCalendar4 = null;
        java.util.GregorianCalendar gregorianCalendar5 = null;
        double d6 = motorista0.totalFaturado(gregorianCalendar4, gregorianCalendar5);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNull(veiculo2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue(d6 == 0.0d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        double d4 = motorista0.totalFaturado(gregorianCalendar2, gregorianCalendar3);
        java.lang.Object obj5 = null;
        boolean b6 = motorista0.equals(obj5);
        Motorista motorista7 = new Motorista();
        Veiculo veiculo8 = motorista7.getVeiculo();
        java.lang.String str9 = motorista7.getMail();
        boolean b10 = motorista7.getDisponibilidade();
        boolean b11 = motorista7.getDisponibilidade();
        java.lang.String str12 = motorista7.getDataDeNascimento();
        int i13 = motorista0.compareTo((Ator) motorista7);
        try {
            Motorista motorista14 = motorista7.clone();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(d4 == 0.0d);
        org.junit.Assert.assertTrue(b6 == false);
        org.junit.Assert.assertNull(veiculo8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue(i13 == 0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
        try {
            Motorista motorista7 = motorista6.clone();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        double d9 = motorista0.totalFaturado();
        java.util.GregorianCalendar gregorianCalendar10 = null;
        java.util.GregorianCalendar gregorianCalendar11 = null;
        double d12 = motorista0.totalFaturado(gregorianCalendar10, gregorianCalendar11);
        int i13 = motorista0.getGrau();
        try {
            motorista0.atualizaClassificacao((-3));
            org.junit.Assert.fail("Expected exception of type ValueOutOfBoundsException");
        } catch (ValueOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 10);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue(d12 == 0.0d);
        org.junit.Assert.assertTrue(i13 == 0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: hi!\nNome: hi!\nPassword: hi!\nMorada: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: true\n", veiculo5);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        motorista0.atualizaClassificacao(0);
        java.lang.String str8 = motorista0.getMorada();
        java.lang.String str9 = motorista0.getNome();
        motorista0.atualizaClassificacao((int) (byte) 1);
        Coordenada coordenada12 = null;
        try {
            motorista0.atualizaDados(coordenada12, (double) ' ', (double) '#', (double) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", "", veiculo5);
        int i7 = motorista6.getClassificacao();
        java.lang.String str8 = motorista6.getDataDeNascimento();
        org.junit.Assert.assertTrue(i7 == 100);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.lang.String str2 = motorista0.getMail();
        java.lang.String str3 = motorista0.getMail();
        try {
            Viagem viagem4 = motorista0.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        Motorista motorista0 = new Motorista();
        double d1 = motorista0.totalFaturado();
        motorista0.setDisponibilidade(false);
        Veiculo veiculo4 = null;
        motorista0.setVeiculo(veiculo4);
        try {
            double d7 = motorista0.tempoViagem((double) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(d1 == 0.0d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        boolean b3 = motorista0.equals((java.lang.Object) (byte) 10);
        java.util.GregorianCalendar gregorianCalendar4 = null;
        java.util.GregorianCalendar gregorianCalendar5 = null;
        double d6 = motorista0.totalFaturado(gregorianCalendar4, gregorianCalendar5);
        motorista0.atualizaClassificacao((int) (short) 100);
        try {
            Motorista motorista9 = new Motorista(motorista0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        try {
            java.util.List<Viagem> list_viagem4 = motorista0.viagensEntreDatas(gregorianCalendar2, gregorianCalendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        double d4 = motorista0.totalFaturado(gregorianCalendar2, gregorianCalendar3);
        java.util.Set<Viagem> set_viagem5 = motorista0.getHistorico();
        int i6 = motorista0.getGrau();
        try {
            Motorista motorista7 = new Motorista(motorista0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(d4 == 0.0d);
        org.junit.Assert.assertNotNull(set_viagem5);
        org.junit.Assert.assertTrue(i6 == 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        Motorista motorista3 = new Motorista();
        java.lang.String str4 = motorista3.toString();
        java.lang.String str5 = motorista3.getMail();
        int i6 = motorista0.compareTo((Ator) motorista3);
        Viagem viagem7 = null;
        try {
            motorista3.registaViagem(viagem7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str4.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue(i6 == 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        double d4 = motorista0.totalFaturado(gregorianCalendar2, gregorianCalendar3);
        java.lang.Object obj5 = null;
        boolean b6 = motorista0.equals(obj5);
        try {
            Motorista motorista7 = motorista0.clone();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(d4 == 0.0d);
        org.junit.Assert.assertTrue(b6 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        double d9 = motorista0.totalFaturado();
        java.util.GregorianCalendar gregorianCalendar10 = null;
        java.util.GregorianCalendar gregorianCalendar11 = null;
        double d12 = motorista0.totalFaturado(gregorianCalendar10, gregorianCalendar11);
        double d13 = motorista0.totalFaturado();
        int i14 = motorista0.getNumClassi();
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 10);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue(d12 == 0.0d);
        org.junit.Assert.assertTrue(d13 == 0.0d);
        org.junit.Assert.assertTrue(i14 == 1);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        Veiculo veiculo6 = motorista0.getVeiculo();
        motorista0.atualizaClassificacao(100);
        Veiculo veiculo9 = motorista0.getVeiculo();
        Veiculo veiculo15 = null;
        Motorista motorista16 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "", veiculo15);
        int i17 = motorista16.getGrau();
        int i18 = motorista0.compareTo((Ator) motorista16);
        try {
            Viagem viagem19 = motorista16.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertNull(veiculo6);
        org.junit.Assert.assertNull(veiculo9);
        org.junit.Assert.assertTrue(i17 == 100);
        org.junit.Assert.assertTrue(i18 == (-230));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "hi!", "hi!", veiculo5);
        motorista6.atualizaClassificacao(100);
        motorista6.setDisponibilidade(true);
        java.lang.String str11 = motorista6.getDataDeNascimento();
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        int i2 = motorista0.getNumClassi();
        java.lang.String str3 = motorista0.getNome();
        java.lang.String str4 = motorista0.toString();
        double d5 = motorista0.getKmsTotais();
        Veiculo veiculo6 = null;
        motorista0.setVeiculo(veiculo6);
        java.lang.String str8 = motorista0.getMorada();
        Motorista motorista9 = new Motorista();
        Veiculo veiculo10 = motorista9.getVeiculo();
        java.lang.String str11 = motorista9.getMail();
        int i12 = motorista9.getNumClassi();
        motorista9.atualizaClassificacao((int) (byte) 10);
        motorista9.atualizaClassificacao(0);
        double d17 = motorista9.getKmsTotais();
        double d18 = motorista9.totalFaturado();
        try {
            boolean b19 = motorista0.equals((java.lang.Object) motorista9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(i2 == 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str4.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(d5 == 0.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNull(veiculo10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertTrue(d17 == 0.0d);
        org.junit.Assert.assertTrue(d18 == 0.0d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        java.lang.String str4 = motorista0.getDataDeNascimento();
        double d5 = motorista0.totalFaturado();
        try {
            Viagem viagem6 = motorista0.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue(d5 == 0.0d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        Veiculo veiculo2 = motorista0.getVeiculo();
        java.lang.String str3 = motorista0.toString();
        int i4 = motorista0.getGrau();
        java.util.GregorianCalendar gregorianCalendar5 = null;
        java.util.GregorianCalendar gregorianCalendar6 = null;
        double d7 = motorista0.totalFaturado(gregorianCalendar5, gregorianCalendar6);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNull(veiculo2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str3.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue(d7 == 0.0d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("hi!", "hi!", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", veiculo5);
        int i7 = motorista6.getNumClassi();
        motorista6.atualizaClassificacao(0);
        java.lang.String str10 = motorista6.getPassword();
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
        Veiculo veiculo12 = null;
        Motorista motorista13 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "hi!", "hi!", veiculo12);
        motorista13.atualizaClassificacao(100);
        int i16 = motorista6.compareTo(motorista13);
        Coordenada coordenada17 = null;
        try {
            motorista13.atualizaDados(coordenada17, (double) (short) -1, (double) (short) 0, (double) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i16 == (-230));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        int i2 = motorista0.getNumClassi();
        java.lang.String str3 = motorista0.getNome();
        java.lang.String str4 = motorista0.toString();
        double d5 = motorista0.getKmsTotais();
        Veiculo veiculo6 = null;
        motorista0.setVeiculo(veiculo6);
        java.lang.String str8 = motorista0.getMorada();
        motorista0.atualizaClassificacao((int) (short) 100);
        try {
            double d12 = motorista0.tempoViagem((double) (-229));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(i2 == 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str4.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(d5 == 0.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        boolean b3 = motorista0.equals((java.lang.Object) (byte) 10);
        int i4 = motorista0.getGrau();
        java.lang.String str5 = motorista0.getNome();
        int i6 = motorista0.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar7 = null;
        java.util.GregorianCalendar gregorianCalendar8 = null;
        double d9 = motorista0.totalFaturado(gregorianCalendar7, gregorianCalendar8);
        java.lang.String str10 = motorista0.getMorada();
        try {
            motorista0.atualizaClassificacao((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type ValueOutOfBoundsException");
        } catch (ValueOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        Veiculo veiculo7 = motorista0.getVeiculo();
        double d8 = motorista0.getKmsTotais();
        Motorista motorista9 = new Motorista();
        java.lang.String str10 = motorista9.toString();
        java.lang.String str11 = motorista9.getMail();
        int i12 = motorista0.compareTo((Ator) motorista9);
        java.util.GregorianCalendar gregorianCalendar13 = null;
        java.util.GregorianCalendar gregorianCalendar14 = null;
        try {
            java.util.List<Viagem> list_viagem15 = motorista9.viagensEntreDatas(gregorianCalendar13, gregorianCalendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertNull(veiculo7);
        org.junit.Assert.assertTrue(d8 == 0.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str10.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue(i12 == 0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: hi!\nNome: hi!\nPassword: hi!\nMorada: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "", veiculo5);
        java.util.GregorianCalendar gregorianCalendar7 = null;
        java.util.GregorianCalendar gregorianCalendar8 = null;
        double d9 = motorista6.totalFaturado(gregorianCalendar7, gregorianCalendar8);
        int i10 = motorista6.getClassificacao();
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue(i10 == 100);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        boolean b3 = motorista0.equals((java.lang.Object) (byte) 10);
        int i4 = motorista0.getGrau();
        java.lang.String str5 = motorista0.getNome();
        int i6 = motorista0.getNumClassi();
        Viagem viagem7 = null;
        try {
            motorista0.registaViagem(viagem7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue(i6 == 0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        Viagem viagem2 = null;
        try {
            motorista0.registaViagem(viagem2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        double d9 = motorista0.totalFaturado();
        java.util.GregorianCalendar gregorianCalendar10 = null;
        java.util.GregorianCalendar gregorianCalendar11 = null;
        double d12 = motorista0.totalFaturado(gregorianCalendar10, gregorianCalendar11);
        java.util.Set<Viagem> set_viagem13 = motorista0.getHistorico();
        java.lang.String str14 = motorista0.getPassword();
        int i15 = motorista0.getGrau();
        java.util.GregorianCalendar gregorianCalendar16 = null;
        java.util.GregorianCalendar gregorianCalendar17 = null;
        try {
            java.util.List<Viagem> list_viagem18 = motorista0.viagensEntreDatas(gregorianCalendar16, gregorianCalendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 10);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue(d12 == 0.0d);
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue(i15 == 0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.getPassword();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        double d4 = motorista0.totalFaturado(gregorianCalendar2, gregorianCalendar3);
        java.lang.String str5 = motorista0.getPassword();
        java.lang.String str6 = motorista0.getPassword();
        java.lang.String str7 = motorista0.toString();
        java.lang.String str8 = motorista0.getDataDeNascimento();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertTrue(d4 == 0.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str7.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        double d9 = motorista0.totalFaturado();
        java.lang.String str10 = motorista0.toString();
        double d11 = motorista0.totalFaturado();
        motorista0.setDisponibilidade(false);
        java.util.GregorianCalendar gregorianCalendar14 = null;
        java.util.GregorianCalendar gregorianCalendar15 = null;
        try {
            java.util.List<Viagem> list_viagem16 = motorista0.viagensEntreDatas(gregorianCalendar14, gregorianCalendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 10);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str10.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(d11 == 0.0d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        boolean b8 = motorista0.equals((java.lang.Object) (byte) 0);
        Veiculo veiculo9 = motorista0.getVeiculo();
        java.util.GregorianCalendar gregorianCalendar10 = null;
        java.util.GregorianCalendar gregorianCalendar11 = null;
        try {
            java.util.List<Viagem> list_viagem12 = motorista0.viagensEntreDatas(gregorianCalendar10, gregorianCalendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertTrue(b8 == false);
        org.junit.Assert.assertNull(veiculo9);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        Motorista motorista5 = new Motorista();
        int i6 = motorista5.getGrau();
        boolean b8 = motorista5.equals((java.lang.Object) (byte) 10);
        java.util.Set<Viagem> set_viagem9 = motorista5.getHistorico();
        Veiculo veiculo15 = null;
        try {
            Motorista motorista16 = new Motorista("E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", set_viagem9, (-35), (-35), (-35), (double) 0L, true, veiculo15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertTrue(b8 == false);
        org.junit.Assert.assertNotNull(set_viagem9);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        Motorista motorista5 = new Motorista();
        int i6 = motorista5.getGrau();
        boolean b8 = motorista5.equals((java.lang.Object) (byte) 10);
        int i9 = motorista5.getGrau();
        java.lang.String str10 = motorista5.getNome();
        int i11 = motorista5.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar12 = null;
        java.util.GregorianCalendar gregorianCalendar13 = null;
        double d14 = motorista5.totalFaturado(gregorianCalendar12, gregorianCalendar13);
        java.lang.String str15 = motorista5.getMorada();
        java.util.Set<Viagem> set_viagem16 = motorista5.getHistorico();
        Veiculo veiculo22 = null;
        try {
            Motorista motorista23 = new Motorista("E-mail: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nNome: hi!\nPassword: hi!\nMorada: hi!\nData de nascimento: hi!\nGrau de cumprimento de horário: 100\nClassificação do motorista: 50\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: hi!\nNome: hi!\nPassword: hi!\nMorada: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", set_viagem16, (int) '#', (int) ' ', (int) (byte) 1, (double) (byte) -1, false, veiculo22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertTrue(b8 == false);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(d14 == 0.0d);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(set_viagem16);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "hi!", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", veiculo5);
        try {
            double d8 = motorista6.tempoViagem((double) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "hi!", "hi!", veiculo5);
        java.util.GregorianCalendar gregorianCalendar7 = null;
        java.util.GregorianCalendar gregorianCalendar8 = null;
        double d9 = motorista6.totalFaturado(gregorianCalendar7, gregorianCalendar8);
        Veiculo veiculo15 = null;
        Motorista motorista16 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "hi!", "hi!", veiculo15);
        motorista16.atualizaClassificacao(100);
        int i19 = motorista16.getClassificacao();
        try {
            int i20 = motorista6.compareTo(motorista16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue(i19 == 100);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: true\n", "E-mail: hi!\nNome: hi!\nPassword: hi!\nMorada: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: hi!\nNome: hi!\nPassword: hi!\nMorada: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nNome: hi!\nPassword: hi!\nMorada: hi!\nData de nascimento: hi!\nGrau de cumprimento de horário: 100\nClassificação do motorista: 50\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.getPassword();
        motorista0.atualizaClassificacao(100);
        Motorista motorista4 = new Motorista();
        int i5 = motorista4.getGrau();
        boolean b7 = motorista4.equals((java.lang.Object) (byte) 10);
        int i8 = motorista4.getGrau();
        java.lang.String str9 = motorista4.getNome();
        int i10 = motorista4.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar11 = null;
        java.util.GregorianCalendar gregorianCalendar12 = null;
        double d13 = motorista4.totalFaturado(gregorianCalendar11, gregorianCalendar12);
        int i14 = motorista0.compareTo((Ator) motorista4);
        Motorista motorista15 = null;
        try {
            int i16 = motorista0.compareTo(motorista15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(b7 == false);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(d13 == 0.0d);
        org.junit.Assert.assertTrue(i14 == 0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", "", veiculo5);
        int i7 = motorista6.getClassificacao();
        try {
            double d9 = motorista6.tempoViagem((double) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i7 == 100);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        motorista0.atualizaClassificacao(0);
        double d8 = motorista0.getKmsTotais();
        double d9 = motorista0.getKmsTotais();
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(d8 == 0.0d);
        org.junit.Assert.assertTrue(d9 == 0.0d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        double d9 = motorista0.totalFaturado();
        java.util.GregorianCalendar gregorianCalendar10 = null;
        java.util.GregorianCalendar gregorianCalendar11 = null;
        double d12 = motorista0.totalFaturado(gregorianCalendar10, gregorianCalendar11);
        double d13 = motorista0.totalFaturado();
        int i14 = motorista0.getClassificacao();
        try {
            double d16 = motorista0.tempoViagem((double) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 10);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue(d12 == 0.0d);
        org.junit.Assert.assertTrue(d13 == 0.0d);
        org.junit.Assert.assertTrue(i14 == 10);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "hi!", "hi!", veiculo5);
        motorista6.atualizaClassificacao(100);
        double d9 = motorista6.totalFaturado();
        java.lang.String str10 = motorista6.getNome();
        try {
            Viagem viagem11 = motorista6.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        int i2 = motorista0.getNumClassi();
        java.lang.String str3 = motorista0.getNome();
        java.lang.String str4 = motorista0.toString();
        double d5 = motorista0.getKmsTotais();
        Veiculo veiculo6 = null;
        motorista0.setVeiculo(veiculo6);
        try {
            double d9 = motorista0.tempoViagem((double) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(i2 == 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str4.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(d5 == 0.0d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "", veiculo5);
        java.util.GregorianCalendar gregorianCalendar7 = null;
        java.util.GregorianCalendar gregorianCalendar8 = null;
        double d9 = motorista6.totalFaturado(gregorianCalendar7, gregorianCalendar8);
        Viagem viagem10 = null;
        try {
            motorista6.registaViagem(viagem10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(d9 == 0.0d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        Veiculo veiculo6 = motorista0.getVeiculo();
        motorista0.atualizaClassificacao(100);
        Veiculo veiculo9 = motorista0.getVeiculo();
        Veiculo veiculo15 = null;
        Motorista motorista16 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "", veiculo15);
        int i17 = motorista16.getGrau();
        int i18 = motorista0.compareTo((Ator) motorista16);
        Motorista motorista19 = new Motorista();
        Veiculo veiculo20 = motorista19.getVeiculo();
        java.lang.String str21 = motorista19.getMail();
        int i22 = motorista19.getNumClassi();
        motorista19.atualizaClassificacao((int) (byte) 10);
        int i25 = motorista19.getNumClassi();
        java.lang.String str26 = motorista19.getNome();
        int i27 = motorista19.getClassificacao();
        java.lang.String str28 = motorista19.getMail();
        java.lang.String str29 = motorista19.toString();
        double d30 = motorista19.getKmsTotais();
        try {
            boolean b31 = motorista16.equals((java.lang.Object) motorista19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertNull(veiculo6);
        org.junit.Assert.assertNull(veiculo9);
        org.junit.Assert.assertTrue(i17 == 100);
        org.junit.Assert.assertTrue(i18 == (-230));
        org.junit.Assert.assertNull(veiculo20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertTrue(i22 == 0);
        org.junit.Assert.assertTrue(i25 == 1);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertTrue(i27 == 10);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "" + "'", str28.equals(""));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str29.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(d30 == 0.0d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        boolean b3 = motorista0.getDisponibilidade();
        int i4 = motorista0.getClassificacao();
        java.util.GregorianCalendar gregorianCalendar5 = null;
        java.util.GregorianCalendar gregorianCalendar6 = null;
        double d7 = motorista0.totalFaturado(gregorianCalendar5, gregorianCalendar6);
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue(d7 == 0.0d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        java.lang.String str3 = motorista0.getDataDeNascimento();
        java.util.Set<Viagem> set_viagem4 = motorista0.getHistorico();
        java.util.Set<Viagem> set_viagem5 = motorista0.getHistorico();
        try {
            Viagem viagem6 = motorista0.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNotNull(set_viagem4);
        org.junit.Assert.assertNotNull(set_viagem5);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "hi!", "hi!", veiculo5);
        boolean b7 = motorista6.getDisponibilidade();
        org.junit.Assert.assertTrue(b7 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", veiculo5);
        java.util.GregorianCalendar gregorianCalendar7 = null;
        java.util.GregorianCalendar gregorianCalendar8 = null;
        double d9 = motorista6.totalFaturado(gregorianCalendar7, gregorianCalendar8);
        int i10 = motorista6.getNumClassi();
        java.lang.String str11 = motorista6.getMorada();
        Viagem viagem12 = null;
        try {
            motorista6.registaViagem(viagem12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        Veiculo veiculo2 = motorista0.getVeiculo();
        java.lang.String str3 = motorista0.getDataDeNascimento();
        java.lang.String str4 = motorista0.toString();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNull(veiculo2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str4.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "", veiculo5);
        int i7 = motorista6.getGrau();
        Viagem viagem8 = null;
        try {
            motorista6.registaViagem(viagem8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i7 == 100);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        boolean b3 = motorista0.getDisponibilidade();
        boolean b4 = motorista0.getDisponibilidade();
        Veiculo veiculo5 = motorista0.getVeiculo();
        Coordenada coordenada6 = null;
        try {
            motorista0.atualizaDados(coordenada6, (double) (-3), (double) (-1L), (double) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNull(veiculo5);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        java.util.GregorianCalendar gregorianCalendar9 = null;
        java.util.GregorianCalendar gregorianCalendar10 = null;
        double d11 = motorista0.totalFaturado(gregorianCalendar9, gregorianCalendar10);
        Veiculo veiculo12 = null;
        motorista0.setVeiculo(veiculo12);
        try {
            double d15 = motorista0.tempoViagem((double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 10);
        org.junit.Assert.assertTrue(d11 == 0.0d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", veiculo5);
        java.lang.String str7 = motorista6.getPassword();
        motorista6.atualizaClassificacao((int) '#');
        motorista6.atualizaClassificacao((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str7.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", veiculo5);
        Motorista motorista7 = new Motorista();
        int i8 = motorista7.getGrau();
        boolean b10 = motorista7.equals((java.lang.Object) (byte) 10);
        java.util.Set<Viagem> set_viagem11 = motorista7.getHistorico();
        Veiculo veiculo12 = null;
        motorista7.setVeiculo(veiculo12);
        int i14 = motorista6.compareTo((Ator) motorista7);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertNotNull(set_viagem11);
        org.junit.Assert.assertTrue(i14 == 3);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        Motorista motorista5 = new Motorista();
        Veiculo veiculo6 = motorista5.getVeiculo();
        java.lang.String str7 = motorista5.getMail();
        java.lang.String str8 = motorista5.getDataDeNascimento();
        java.util.Set<Viagem> set_viagem9 = motorista5.getHistorico();
        java.util.Set<Viagem> set_viagem10 = motorista5.getHistorico();
        Veiculo veiculo16 = null;
        try {
            Motorista motorista17 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: true\n", "E-mail: hi!\nNome: hi!\nPassword: hi!\nMorada: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", set_viagem10, (-230), (int) (byte) 100, (int) (short) 1, (double) 0.0f, false, veiculo16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(set_viagem9);
        org.junit.Assert.assertNotNull(set_viagem10);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        Veiculo veiculo6 = motorista0.getVeiculo();
        motorista0.atualizaClassificacao(100);
        java.lang.String str9 = motorista0.getMorada();
        Coordenada coordenada10 = null;
        try {
            motorista0.atualizaDados(coordenada10, (double) 1L, 10.0d, (double) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertNull(veiculo6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
        Veiculo veiculo12 = null;
        Motorista motorista13 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "hi!", "hi!", veiculo12);
        motorista13.atualizaClassificacao(100);
        int i16 = motorista6.compareTo(motorista13);
        try {
            double d18 = motorista6.tempoViagem((double) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i16 == (-230));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        double d9 = motorista0.totalFaturado();
        java.lang.String str10 = motorista0.toString();
        boolean b12 = motorista0.equals((java.lang.Object) 1.0d);
        Viagem viagem13 = null;
        try {
            motorista0.registaViagem(viagem13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 10);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str10.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(b12 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        java.lang.String str3 = motorista0.getDataDeNascimento();
        double d4 = motorista0.getKmsTotais();
        motorista0.setDisponibilidade(false);
        Viagem viagem7 = null;
        try {
            motorista0.registaViagem(viagem7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue(d4 == 0.0d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "", "E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.lang.String str2 = motorista0.toString();
        java.lang.String str3 = motorista0.getDataDeNascimento();
        java.lang.String str4 = motorista0.getPassword();
        java.lang.String str5 = motorista0.toString();
        motorista0.setDisponibilidade(false);
        try {
            Viagem viagem8 = motorista0.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str2.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str5.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        boolean b3 = motorista0.equals((java.lang.Object) (byte) 10);
        int i4 = motorista0.getGrau();
        java.lang.String str5 = motorista0.getNome();
        int i6 = motorista0.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar7 = null;
        java.util.GregorianCalendar gregorianCalendar8 = null;
        double d9 = motorista0.totalFaturado(gregorianCalendar7, gregorianCalendar8);
        boolean b10 = motorista0.getDisponibilidade();
        motorista0.setDisponibilidade(true);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue(b10 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        Motorista motorista0 = new Motorista();
        double d1 = motorista0.totalFaturado();
        motorista0.setDisponibilidade(false);
        int i4 = motorista0.getNumClassi();
        java.lang.String str5 = motorista0.getMail();
        Motorista motorista6 = new Motorista();
        java.lang.String str7 = motorista6.toString();
        java.util.GregorianCalendar gregorianCalendar8 = null;
        java.util.GregorianCalendar gregorianCalendar9 = null;
        double d10 = motorista6.totalFaturado(gregorianCalendar8, gregorianCalendar9);
        java.lang.Object obj11 = null;
        boolean b12 = motorista6.equals(obj11);
        motorista6.setDisponibilidade(true);
        Veiculo veiculo15 = motorista6.getVeiculo();
        try {
            boolean b16 = motorista0.equals((java.lang.Object) motorista6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(d1 == 0.0d);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str7.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(d10 == 0.0d);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertNull(veiculo15);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "hi!", "hi!", veiculo5);
        motorista6.atualizaClassificacao(100);
        try {
            double d10 = motorista6.tempoViagem((double) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        int i2 = motorista0.getNumClassi();
        java.lang.String str3 = motorista0.getNome();
        java.lang.String str4 = motorista0.toString();
        double d5 = motorista0.getKmsTotais();
        Veiculo veiculo6 = null;
        motorista0.setVeiculo(veiculo6);
        try {
            motorista0.atualizaClassificacao((-35));
            org.junit.Assert.fail("Expected exception of type ValueOutOfBoundsException");
        } catch (ValueOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(i2 == 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str4.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(d5 == 0.0d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.setDisponibilidade(false);
        java.lang.String str6 = motorista0.getMorada();
        Veiculo veiculo7 = motorista0.getVeiculo();
        java.lang.String str8 = motorista0.getNome();
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(veiculo7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.setDisponibilidade(false);
        java.lang.String str6 = motorista0.getMorada();
        double d7 = motorista0.totalFaturado();
        try {
            Viagem viagem8 = motorista0.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue(d7 == 0.0d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nNome: hi!\nPassword: hi!\nMorada: hi!\nData de nascimento: hi!\nGrau de cumprimento de horário: 100\nClassificação do motorista: 50\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: true\n", "E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
        java.lang.String str7 = motorista6.getMail();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str7.equals("E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        Viagem viagem6 = null;
        try {
            motorista0.registaViagem(viagem6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        Veiculo veiculo2 = motorista0.getVeiculo();
        double d3 = motorista0.getKmsTotais();
        motorista0.setDisponibilidade(true);
        int i6 = motorista0.getGrau();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNull(veiculo2);
        org.junit.Assert.assertTrue(d3 == 0.0d);
        org.junit.Assert.assertTrue(i6 == 0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        boolean b3 = motorista0.getDisponibilidade();
        boolean b4 = motorista0.getDisponibilidade();
        java.lang.String str5 = motorista0.getDataDeNascimento();
        Viagem viagem6 = null;
        try {
            motorista0.registaViagem(viagem6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        java.util.GregorianCalendar gregorianCalendar9 = null;
        java.util.GregorianCalendar gregorianCalendar10 = null;
        double d11 = motorista0.totalFaturado(gregorianCalendar9, gregorianCalendar10);
        Veiculo veiculo12 = null;
        motorista0.setVeiculo(veiculo12);
        motorista0.setDisponibilidade(false);
        java.util.GregorianCalendar gregorianCalendar16 = null;
        java.util.GregorianCalendar gregorianCalendar17 = null;
        try {
            java.util.List<Viagem> list_viagem18 = motorista0.viagensEntreDatas(gregorianCalendar16, gregorianCalendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 10);
        org.junit.Assert.assertTrue(d11 == 0.0d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        Motorista motorista0 = new Motorista();
        double d1 = motorista0.totalFaturado();
        motorista0.setDisponibilidade(false);
        int i4 = motorista0.getNumClassi();
        java.lang.String str5 = motorista0.getMail();
        double d6 = motorista0.getKmsTotais();
        org.junit.Assert.assertTrue(d1 == 0.0d);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue(d6 == 0.0d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        Motorista motorista5 = new Motorista();
        Veiculo veiculo6 = motorista5.getVeiculo();
        java.lang.String str7 = motorista5.getMail();
        int i8 = motorista5.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar9 = null;
        java.util.GregorianCalendar gregorianCalendar10 = null;
        double d11 = motorista5.totalFaturado(gregorianCalendar9, gregorianCalendar10);
        java.lang.String str12 = motorista5.getMorada();
        int i13 = motorista5.getGrau();
        java.util.Set<Viagem> set_viagem14 = motorista5.getHistorico();
        Veiculo veiculo20 = null;
        try {
            Motorista motorista21 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: true\n", "hi!", "", "", set_viagem14, (int) (short) 100, (int) '#', (-1), (double) (short) 1, true, veiculo20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue(d11 == 0.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertNotNull(set_viagem14);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        Veiculo veiculo11 = null;
        Motorista motorista12 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo11);
        int i13 = motorista0.compareTo(motorista12);
        Viagem viagem14 = null;
        try {
            motorista0.registaViagem(viagem14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i13 == (-230));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        Motorista motorista0 = new Motorista();
        double d1 = motorista0.totalFaturado();
        motorista0.setDisponibilidade(false);
        motorista0.setDisponibilidade(false);
        int i6 = motorista0.getNumClassi();
        int i7 = motorista0.getClassificacao();
        org.junit.Assert.assertTrue(d1 == 0.0d);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertTrue(i7 == 0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        double d9 = motorista0.totalFaturado();
        java.lang.String str10 = motorista0.toString();
        double d11 = motorista0.totalFaturado();
        java.util.GregorianCalendar gregorianCalendar12 = null;
        java.util.GregorianCalendar gregorianCalendar13 = null;
        try {
            java.util.List<Viagem> list_viagem14 = motorista0.viagensEntreDatas(gregorianCalendar12, gregorianCalendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 10);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str10.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(d11 == 0.0d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        boolean b3 = motorista0.equals((java.lang.Object) (byte) 10);
        java.util.GregorianCalendar gregorianCalendar4 = null;
        java.util.GregorianCalendar gregorianCalendar5 = null;
        double d6 = motorista0.totalFaturado(gregorianCalendar4, gregorianCalendar5);
        java.util.Set<Viagem> set_viagem7 = motorista0.getHistorico();
        java.util.GregorianCalendar gregorianCalendar8 = null;
        java.util.GregorianCalendar gregorianCalendar9 = null;
        try {
            java.util.List<Viagem> list_viagem10 = motorista0.viagensEntreDatas(gregorianCalendar8, gregorianCalendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertNotNull(set_viagem7);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        java.util.GregorianCalendar gregorianCalendar9 = null;
        java.util.GregorianCalendar gregorianCalendar10 = null;
        double d11 = motorista0.totalFaturado(gregorianCalendar9, gregorianCalendar10);
        Veiculo veiculo12 = motorista0.getVeiculo();
        java.util.GregorianCalendar gregorianCalendar13 = null;
        java.util.GregorianCalendar gregorianCalendar14 = null;
        double d15 = motorista0.totalFaturado(gregorianCalendar13, gregorianCalendar14);
        Veiculo veiculo16 = motorista0.getVeiculo();
        Motorista motorista17 = new Motorista();
        java.lang.String str18 = motorista17.toString();
        java.util.GregorianCalendar gregorianCalendar19 = null;
        java.util.GregorianCalendar gregorianCalendar20 = null;
        double d21 = motorista17.totalFaturado(gregorianCalendar19, gregorianCalendar20);
        motorista17.setDisponibilidade(false);
        java.lang.String str24 = motorista17.getPassword();
        try {
            boolean b25 = motorista0.equals((java.lang.Object) motorista17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 10);
        org.junit.Assert.assertTrue(d11 == 0.0d);
        org.junit.Assert.assertNull(veiculo12);
        org.junit.Assert.assertTrue(d15 == 0.0d);
        org.junit.Assert.assertNull(veiculo16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str18.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(d21 == 0.0d);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        motorista0.atualizaClassificacao(0);
        double d8 = motorista0.getKmsTotais();
        double d9 = motorista0.totalFaturado();
        double d10 = motorista0.totalFaturado();
        try {
            motorista0.atualizaClassificacao((-35));
            org.junit.Assert.fail("Expected exception of type ValueOutOfBoundsException");
        } catch (ValueOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(d8 == 0.0d);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue(d10 == 0.0d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.getPassword();
        motorista0.atualizaClassificacao(100);
        Viagem viagem4 = null;
        try {
            motorista0.registaViagem(viagem4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "", veiculo5);
        int i7 = motorista6.getGrau();
        boolean b8 = motorista6.getDisponibilidade();
        Viagem viagem9 = null;
        try {
            motorista6.registaViagem(viagem9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i7 == 100);
        org.junit.Assert.assertTrue(b8 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
        java.lang.String str7 = motorista6.getMail();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str7.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "", "", veiculo5);
        int i7 = motorista6.getGrau();
        java.lang.String str8 = motorista6.getMorada();
        org.junit.Assert.assertTrue(i7 == 100);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        boolean b3 = motorista0.getDisponibilidade();
        int i4 = motorista0.getClassificacao();
        java.lang.String str5 = motorista0.getDataDeNascimento();
        Veiculo veiculo6 = motorista0.getVeiculo();
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNull(veiculo6);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", "", veiculo5);
        java.lang.String str7 = motorista6.getMail();
        java.lang.String str8 = motorista6.getPassword();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str7.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str8.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getClassificacao();
        motorista0.setDisponibilidade(true);
        java.lang.String str9 = motorista0.getPassword();
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 10);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        boolean b3 = motorista0.getDisponibilidade();
        boolean b4 = motorista0.getDisponibilidade();
        java.util.GregorianCalendar gregorianCalendar5 = null;
        java.util.GregorianCalendar gregorianCalendar6 = null;
        double d7 = motorista0.totalFaturado(gregorianCalendar5, gregorianCalendar6);
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d7 == 0.0d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", veiculo5);
        double d7 = motorista6.totalFaturado();
        motorista6.setDisponibilidade(false);
        Motorista motorista10 = new Motorista();
        int i11 = motorista10.getGrau();
        boolean b13 = motorista10.equals((java.lang.Object) (byte) 10);
        int i14 = motorista10.getGrau();
        java.lang.String str15 = motorista10.getNome();
        int i16 = motorista10.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar17 = null;
        java.util.GregorianCalendar gregorianCalendar18 = null;
        double d19 = motorista10.totalFaturado(gregorianCalendar17, gregorianCalendar18);
        boolean b20 = motorista10.getDisponibilidade();
        int i21 = motorista6.compareTo(motorista10);
        try {
            double d23 = motorista6.precoViagem((double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(d7 == 0.0d);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(b13 == false);
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue(d19 == 0.0d);
        org.junit.Assert.assertTrue(b20 == false);
        org.junit.Assert.assertTrue(i21 == 3);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: true\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: true\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: true\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: true\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
        try {
            Viagem viagem7 = motorista6.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        Veiculo veiculo2 = motorista0.getVeiculo();
        double d3 = motorista0.getKmsTotais();
        motorista0.setDisponibilidade(true);
        java.lang.String str6 = motorista0.getPassword();
        java.lang.String str7 = motorista0.getNome();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNull(veiculo2);
        org.junit.Assert.assertTrue(d3 == 0.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        java.util.Set<Viagem> set_viagem5 = null;
        Veiculo veiculo11 = null;
        try {
            Motorista motorista12 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: true\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: true\n", "E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", set_viagem5, (int) (short) 1, (int) 'a', 100, (double) (byte) 100, true, veiculo11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        motorista0.atualizaClassificacao(0);
        double d8 = motorista0.getKmsTotais();
        java.lang.String str9 = motorista0.getDataDeNascimento();
        java.util.Set<Viagem> set_viagem10 = motorista0.getHistorico();
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(d8 == 0.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(set_viagem10);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        int i2 = motorista0.getNumClassi();
        java.lang.String str3 = motorista0.getNome();
        java.lang.String str4 = motorista0.toString();
        Veiculo veiculo5 = motorista0.getVeiculo();
        java.util.GregorianCalendar gregorianCalendar6 = null;
        java.util.GregorianCalendar gregorianCalendar7 = null;
        try {
            java.util.List<Viagem> list_viagem8 = motorista0.viagensEntreDatas(gregorianCalendar6, gregorianCalendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(i2 == 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str4.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertNull(veiculo5);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        java.util.Set<Viagem> set_viagem5 = null;
        Veiculo veiculo11 = null;
        try {
            Motorista motorista12 = new Motorista("E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", set_viagem5, (int) ' ', (int) '#', (int) ' ', (double) (-1.0f), true, veiculo11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        Motorista motorista0 = new Motorista();
        double d1 = motorista0.totalFaturado();
        int i2 = motorista0.getGrau();
        boolean b3 = motorista0.getDisponibilidade();
        Motorista motorista4 = new Motorista();
        Veiculo veiculo5 = motorista4.getVeiculo();
        java.lang.String str6 = motorista4.getMail();
        int i7 = motorista4.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar8 = null;
        java.util.GregorianCalendar gregorianCalendar9 = null;
        double d10 = motorista4.totalFaturado(gregorianCalendar8, gregorianCalendar9);
        java.lang.String str11 = motorista4.getMorada();
        try {
            boolean b12 = motorista0.equals((java.lang.Object) motorista4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(d1 == 0.0d);
        org.junit.Assert.assertTrue(i2 == 0);
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertNull(veiculo5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(d10 == 0.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", veiculo5);
        java.util.GregorianCalendar gregorianCalendar7 = null;
        java.util.GregorianCalendar gregorianCalendar8 = null;
        double d9 = motorista6.totalFaturado(gregorianCalendar7, gregorianCalendar8);
        int i10 = motorista6.getNumClassi();
        java.lang.String str11 = motorista6.getMorada();
        java.util.GregorianCalendar gregorianCalendar12 = null;
        java.util.GregorianCalendar gregorianCalendar13 = null;
        try {
            java.util.List<Viagem> list_viagem14 = motorista6.viagensEntreDatas(gregorianCalendar12, gregorianCalendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        double d9 = motorista0.totalFaturado();
        java.util.GregorianCalendar gregorianCalendar10 = null;
        java.util.GregorianCalendar gregorianCalendar11 = null;
        double d12 = motorista0.totalFaturado(gregorianCalendar10, gregorianCalendar11);
        int i13 = motorista0.getGrau();
        boolean b14 = motorista0.getDisponibilidade();
        try {
            double d16 = motorista0.tempoViagem((double) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 10);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue(d12 == 0.0d);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(b14 == false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nNome: hi!\nPassword: hi!\nMorada: hi!\nData de nascimento: hi!\nGrau de cumprimento de horário: 100\nClassificação do motorista: 50\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: true\n", "E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
        try {
            motorista6.atualizaClassificacao((-35));
            org.junit.Assert.fail("Expected exception of type ValueOutOfBoundsException");
        } catch (ValueOutOfBoundsException e) {
        }
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        boolean b8 = motorista0.equals((java.lang.Object) (byte) 0);
        Veiculo veiculo14 = null;
        Motorista motorista15 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo14);
        double d16 = motorista15.getKmsTotais();
        Veiculo veiculo17 = motorista15.getVeiculo();
        int i18 = motorista0.compareTo(motorista15);
        try {
            double d20 = motorista0.tempoViagem(0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertTrue(b8 == false);
        org.junit.Assert.assertTrue(d16 == 0.0d);
        org.junit.Assert.assertNull(veiculo17);
        org.junit.Assert.assertTrue(i18 == (-230));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "hi!", "hi!", veiculo5);
        int i7 = motorista6.getNumClassi();
        org.junit.Assert.assertTrue(i7 == 0);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        Veiculo veiculo10 = null;
        Motorista motorista11 = new Motorista("E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nNome: hi!\nPassword: hi!\nMorada: hi!\nData de nascimento: hi!\nGrau de cumprimento de horário: 100\nClassificação do motorista: 50\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", veiculo10);
        double d12 = motorista11.totalFaturado();
        java.util.Set<Viagem> set_viagem13 = motorista11.getHistorico();
        Veiculo veiculo19 = null;
        try {
            Motorista motorista20 = new Motorista("E-mail: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nNome: hi!\nPassword: hi!\nMorada: hi!\nData de nascimento: hi!\nGrau de cumprimento de horário: 100\nClassificação do motorista: 50\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "", set_viagem13, 10, (-229), (int) (byte) 1, (double) 0, true, veiculo19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(d12 == 0.0d);
        org.junit.Assert.assertNotNull(set_viagem13);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "hi!", "", "E-mail: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nNome: hi!\nPassword: hi!\nMorada: hi!\nData de nascimento: hi!\nGrau de cumprimento de horário: 100\nClassificação do motorista: 50\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
        try {
            double d8 = motorista6.tempoViagem((double) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        boolean b3 = motorista0.equals((java.lang.Object) (byte) 10);
        java.util.GregorianCalendar gregorianCalendar4 = null;
        java.util.GregorianCalendar gregorianCalendar5 = null;
        double d6 = motorista0.totalFaturado(gregorianCalendar4, gregorianCalendar5);
        motorista0.atualizaClassificacao((int) (short) 100);
        double d9 = motorista0.totalFaturado();
        try {
            double d11 = motorista0.precoViagem((double) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(d9 == 0.0d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar4 = null;
        java.util.GregorianCalendar gregorianCalendar5 = null;
        double d6 = motorista0.totalFaturado(gregorianCalendar4, gregorianCalendar5);
        try {
            Motorista motorista7 = motorista0.clone();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(d6 == 0.0d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        java.lang.String str4 = motorista0.getDataDeNascimento();
        int i5 = motorista0.getGrau();
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue(i5 == 0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.getPassword();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        double d4 = motorista0.totalFaturado(gregorianCalendar2, gregorianCalendar3);
        double d5 = motorista0.getKmsTotais();
        java.util.GregorianCalendar gregorianCalendar6 = null;
        java.util.GregorianCalendar gregorianCalendar7 = null;
        double d8 = motorista0.totalFaturado(gregorianCalendar6, gregorianCalendar7);
        java.lang.String str9 = motorista0.getNome();
        java.lang.String str10 = motorista0.getMorada();
        Veiculo veiculo16 = null;
        Motorista motorista17 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "hi!", "hi!", veiculo16);
        motorista17.atualizaClassificacao(100);
        motorista17.setDisponibilidade(true);
        try {
            boolean b22 = motorista0.equals((java.lang.Object) motorista17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertTrue(d4 == 0.0d);
        org.junit.Assert.assertTrue(d5 == 0.0d);
        org.junit.Assert.assertTrue(d8 == 0.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.lang.String str2 = motorista0.getMail();
        java.lang.String str3 = motorista0.getMail();
        try {
            motorista0.atualizaClassificacao((-229));
            org.junit.Assert.fail("Expected exception of type ValueOutOfBoundsException");
        } catch (ValueOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        java.lang.String str3 = motorista0.getDataDeNascimento();
        java.util.Set<Viagem> set_viagem4 = motorista0.getHistorico();
        java.util.Set<Viagem> set_viagem5 = motorista0.getHistorico();
        java.lang.String str6 = motorista0.getPassword();
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNotNull(set_viagem4);
        org.junit.Assert.assertNotNull(set_viagem5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.lang.String str2 = motorista0.toString();
        java.lang.String str3 = motorista0.getDataDeNascimento();
        java.lang.String str4 = motorista0.getPassword();
        Veiculo veiculo5 = null;
        motorista0.setVeiculo(veiculo5);
        Veiculo veiculo7 = null;
        motorista0.setVeiculo(veiculo7);
        Veiculo veiculo9 = motorista0.getVeiculo();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str2.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNull(veiculo9);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        boolean b3 = motorista0.getDisponibilidade();
        boolean b4 = motorista0.getDisponibilidade();
        int i5 = motorista0.getGrau();
        java.util.GregorianCalendar gregorianCalendar6 = null;
        java.util.GregorianCalendar gregorianCalendar7 = null;
        double d8 = motorista0.totalFaturado(gregorianCalendar6, gregorianCalendar7);
        int i9 = motorista0.getNumClassi();
        try {
            Motorista motorista10 = new Motorista(motorista0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(d8 == 0.0d);
        org.junit.Assert.assertTrue(i9 == 0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        Motorista motorista4 = new Motorista();
        java.lang.String str5 = motorista4.getPassword();
        java.util.GregorianCalendar gregorianCalendar6 = null;
        java.util.GregorianCalendar gregorianCalendar7 = null;
        double d8 = motorista4.totalFaturado(gregorianCalendar6, gregorianCalendar7);
        double d9 = motorista4.getKmsTotais();
        java.util.GregorianCalendar gregorianCalendar10 = null;
        java.util.GregorianCalendar gregorianCalendar11 = null;
        double d12 = motorista4.totalFaturado(gregorianCalendar10, gregorianCalendar11);
        java.lang.String str13 = motorista4.getNome();
        java.lang.String str14 = motorista4.getMorada();
        try {
            int i15 = motorista0.compareTo(motorista4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue(d8 == 0.0d);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue(d12 == 0.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: true\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: true\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: true\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: true\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
        int i7 = motorista6.getClassificacao();
        java.util.Set<Viagem> set_viagem8 = motorista6.getHistorico();
        org.junit.Assert.assertTrue(i7 == 100);
        org.junit.Assert.assertNotNull(set_viagem8);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "", "E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nNome: hi!\nPassword: hi!\nMorada: hi!\nData de nascimento: hi!\nGrau de cumprimento de horário: 100\nClassificação do motorista: 50\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        boolean b3 = motorista0.equals((java.lang.Object) (byte) 10);
        java.util.GregorianCalendar gregorianCalendar4 = null;
        java.util.GregorianCalendar gregorianCalendar5 = null;
        double d6 = motorista0.totalFaturado(gregorianCalendar4, gregorianCalendar5);
        motorista0.atualizaClassificacao((int) (short) 100);
        double d9 = motorista0.totalFaturado();
        java.lang.String str10 = motorista0.toString();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str10.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        java.lang.String str8 = motorista0.getMorada();
        Veiculo veiculo14 = null;
        Motorista motorista15 = new Motorista("", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", veiculo14);
        java.lang.String str16 = motorista15.getPassword();
        Veiculo veiculo22 = null;
        Motorista motorista23 = new Motorista("hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "", veiculo22);
        int i24 = motorista15.compareTo((Ator) motorista23);
        try {
            boolean b25 = motorista0.equals((java.lang.Object) motorista15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str16.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(i24 == (-3));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        double d4 = motorista0.totalFaturado(gregorianCalendar2, gregorianCalendar3);
        java.util.Set<Viagem> set_viagem5 = motorista0.getHistorico();
        int i6 = motorista0.getGrau();
        Motorista motorista7 = new Motorista();
        java.lang.String str8 = motorista7.toString();
        java.util.GregorianCalendar gregorianCalendar9 = null;
        java.util.GregorianCalendar gregorianCalendar10 = null;
        double d11 = motorista7.totalFaturado(gregorianCalendar9, gregorianCalendar10);
        java.lang.Object obj12 = null;
        boolean b13 = motorista7.equals(obj12);
        motorista7.setDisponibilidade(true);
        int i16 = motorista0.compareTo((Ator) motorista7);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(d4 == 0.0d);
        org.junit.Assert.assertNotNull(set_viagem5);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str8.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(d11 == 0.0d);
        org.junit.Assert.assertTrue(b13 == false);
        org.junit.Assert.assertTrue(i16 == 0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.setDisponibilidade(false);
        java.lang.String str6 = motorista0.getMorada();
        double d7 = motorista0.totalFaturado();
        java.util.GregorianCalendar gregorianCalendar8 = null;
        java.util.GregorianCalendar gregorianCalendar9 = null;
        double d10 = motorista0.totalFaturado(gregorianCalendar8, gregorianCalendar9);
        int i11 = motorista0.getNumClassi();
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue(d7 == 0.0d);
        org.junit.Assert.assertTrue(d10 == 0.0d);
        org.junit.Assert.assertTrue(i11 == 0);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", "E-mail: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nNome: hi!\nPassword: hi!\nMorada: hi!\nData de nascimento: hi!\nGrau de cumprimento de horário: 100\nClassificação do motorista: 50\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", veiculo5);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "hi!", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", veiculo5);
        Motorista motorista7 = new Motorista();
        Veiculo veiculo8 = motorista7.getVeiculo();
        java.lang.String str9 = motorista7.getMail();
        int i10 = motorista7.getNumClassi();
        java.lang.String str11 = motorista7.getDataDeNascimento();
        int i12 = motorista6.compareTo((Ator) motorista7);
        try {
            double d14 = motorista7.tempoViagem((double) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue(i12 == 3);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        java.util.GregorianCalendar gregorianCalendar9 = null;
        java.util.GregorianCalendar gregorianCalendar10 = null;
        double d11 = motorista0.totalFaturado(gregorianCalendar9, gregorianCalendar10);
        Veiculo veiculo12 = motorista0.getVeiculo();
        java.lang.String str13 = motorista0.getMail();
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 10);
        org.junit.Assert.assertTrue(d11 == 0.0d);
        org.junit.Assert.assertNull(veiculo12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.lang.String str2 = motorista0.toString();
        int i3 = motorista0.getNumClassi();
        Viagem viagem4 = null;
        try {
            motorista0.registaViagem(viagem4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str2.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(i3 == 0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
        Veiculo veiculo7 = null;
        motorista6.setVeiculo(veiculo7);
        try {
            double d10 = motorista6.precoViagem((double) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        Motorista motorista0 = new Motorista();
        double d1 = motorista0.totalFaturado();
        motorista0.setDisponibilidade(false);
        double d4 = motorista0.totalFaturado();
        motorista0.setDisponibilidade(true);
        org.junit.Assert.assertTrue(d1 == 0.0d);
        org.junit.Assert.assertTrue(d4 == 0.0d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        double d9 = motorista0.totalFaturado();
        java.util.GregorianCalendar gregorianCalendar10 = null;
        java.util.GregorianCalendar gregorianCalendar11 = null;
        double d12 = motorista0.totalFaturado(gregorianCalendar10, gregorianCalendar11);
        java.util.Set<Viagem> set_viagem13 = motorista0.getHistorico();
        java.lang.String str14 = motorista0.getPassword();
        int i15 = motorista0.getGrau();
        try {
            double d17 = motorista0.precoViagem((double) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 10);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue(d12 == 0.0d);
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue(i15 == 0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.lang.String str2 = motorista0.toString();
        java.lang.String str3 = motorista0.getDataDeNascimento();
        java.lang.String str4 = motorista0.getPassword();
        java.lang.String str5 = motorista0.toString();
        motorista0.setDisponibilidade(false);
        java.lang.String str8 = motorista0.getMail();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str2.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str5.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "", "", veiculo5);
        motorista6.atualizaClassificacao(3);
        Coordenada coordenada9 = null;
        try {
            motorista6.atualizaDados(coordenada9, (double) ' ', 1.0d, (double) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: true\n", "hi!", "", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", veiculo5);
        Viagem viagem7 = null;
        try {
            motorista6.registaViagem(viagem7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        java.util.Set<Viagem> set_viagem5 = null;
        Veiculo veiculo11 = null;
        try {
            Motorista motorista12 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nNome: hi!\nPassword: hi!\nMorada: hi!\nData de nascimento: hi!\nGrau de cumprimento de horário: 100\nClassificação do motorista: 50\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", set_viagem5, (int) (short) -1, 0, (int) (short) 1, (double) 0.0f, true, veiculo11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        double d4 = motorista0.totalFaturado(gregorianCalendar2, gregorianCalendar3);
        motorista0.setDisponibilidade(false);
        int i7 = motorista0.getClassificacao();
        try {
            Motorista motorista8 = new Motorista(motorista0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(d4 == 0.0d);
        org.junit.Assert.assertTrue(i7 == 0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar4 = null;
        java.util.GregorianCalendar gregorianCalendar5 = null;
        double d6 = motorista0.totalFaturado(gregorianCalendar4, gregorianCalendar5);
        java.lang.String str7 = motorista0.getMorada();
        java.lang.String str8 = motorista0.toString();
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str8.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        boolean b3 = motorista0.getDisponibilidade();
        boolean b4 = motorista0.getDisponibilidade();
        int i5 = motorista0.getGrau();
        java.util.GregorianCalendar gregorianCalendar6 = null;
        java.util.GregorianCalendar gregorianCalendar7 = null;
        double d8 = motorista0.totalFaturado(gregorianCalendar6, gregorianCalendar7);
        try {
            double d10 = motorista0.precoViagem((double) (-35));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(d8 == 0.0d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        double d9 = motorista0.totalFaturado();
        java.lang.String str10 = motorista0.toString();
        boolean b12 = motorista0.equals((java.lang.Object) 1.0d);
        java.lang.String str13 = motorista0.getMorada();
        double d14 = motorista0.getKmsTotais();
        java.util.Set<Viagem> set_viagem15 = motorista0.getHistorico();
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 10);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str10.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue(d14 == 0.0d);
        org.junit.Assert.assertNotNull(set_viagem15);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.getPassword();
        motorista0.atualizaClassificacao(100);
        java.util.GregorianCalendar gregorianCalendar4 = null;
        java.util.GregorianCalendar gregorianCalendar5 = null;
        double d6 = motorista0.totalFaturado(gregorianCalendar4, gregorianCalendar5);
        boolean b7 = motorista0.getDisponibilidade();
        Veiculo veiculo8 = motorista0.getVeiculo();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(b7 == false);
        org.junit.Assert.assertNull(veiculo8);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
        java.lang.String str7 = motorista6.getPassword();
        boolean b8 = motorista6.getDisponibilidade();
        try {
            Motorista motorista9 = new Motorista(motorista6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(b8 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.lang.String str2 = motorista0.toString();
        java.lang.String str3 = motorista0.getDataDeNascimento();
        java.lang.String str4 = motorista0.getPassword();
        Veiculo veiculo5 = motorista0.getVeiculo();
        java.lang.String str6 = motorista0.getPassword();
        java.lang.String str7 = motorista0.getMorada();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str2.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNull(veiculo5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        double d9 = motorista0.totalFaturado();
        java.util.GregorianCalendar gregorianCalendar10 = null;
        java.util.GregorianCalendar gregorianCalendar11 = null;
        double d12 = motorista0.totalFaturado(gregorianCalendar10, gregorianCalendar11);
        java.util.Set<Viagem> set_viagem13 = motorista0.getHistorico();
        java.lang.String str14 = motorista0.getPassword();
        int i15 = motorista0.getGrau();
        try {
            double d17 = motorista0.precoViagem((double) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 10);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue(d12 == 0.0d);
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue(i15 == 0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.lang.String str2 = motorista0.toString();
        java.lang.String str3 = motorista0.getDataDeNascimento();
        java.lang.String str4 = motorista0.getPassword();
        Veiculo veiculo5 = motorista0.getVeiculo();
        motorista0.setDisponibilidade(false);
        java.lang.String str8 = motorista0.getPassword();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str2.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNull(veiculo5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", veiculo5);
        java.lang.String str7 = motorista6.getPassword();
        motorista6.atualizaClassificacao((int) '#');
        motorista6.atualizaClassificacao(3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str7.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nNome: hi!\nPassword: hi!\nMorada: hi!\nData de nascimento: hi!\nGrau de cumprimento de horário: 100\nClassificação do motorista: 50\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
        double d7 = motorista6.getKmsTotais();
        org.junit.Assert.assertTrue(d7 == 0.0d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.setDisponibilidade(false);
        Viagem viagem6 = null;
        try {
            motorista0.registaViagem(viagem6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", "", veiculo5);
        java.lang.String str7 = motorista6.getMorada();
        Coordenada coordenada8 = null;
        try {
            motorista6.atualizaDados(coordenada8, (double) '#', 0.0d, (double) 229);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        double d4 = motorista0.totalFaturado(gregorianCalendar2, gregorianCalendar3);
        motorista0.setDisponibilidade(false);
        java.lang.String str7 = motorista0.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(d4 == 0.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str7.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        boolean b3 = motorista0.equals((java.lang.Object) (byte) 10);
        java.util.GregorianCalendar gregorianCalendar4 = null;
        java.util.GregorianCalendar gregorianCalendar5 = null;
        double d6 = motorista0.totalFaturado(gregorianCalendar4, gregorianCalendar5);
        int i7 = motorista0.getClassificacao();
        try {
            Motorista motorista8 = motorista0.clone();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(i7 == 0);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.lang.String str2 = motorista0.getMail();
        java.lang.String str3 = motorista0.getMail();
        int i4 = motorista0.getGrau();
        java.lang.String str5 = motorista0.getPassword();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        boolean b3 = motorista0.getDisponibilidade();
        boolean b4 = motorista0.getDisponibilidade();
        try {
            motorista0.atualizaClassificacao((-1));
            org.junit.Assert.fail("Expected exception of type ValueOutOfBoundsException");
        } catch (ValueOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertTrue(b4 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getClassificacao();
        java.util.GregorianCalendar gregorianCalendar7 = null;
        java.util.GregorianCalendar gregorianCalendar8 = null;
        try {
            java.util.List<Viagem> list_viagem9 = motorista0.viagensEntreDatas(gregorianCalendar7, gregorianCalendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 10);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        double d4 = motorista0.totalFaturado(gregorianCalendar2, gregorianCalendar3);
        java.lang.Object obj5 = null;
        boolean b6 = motorista0.equals(obj5);
        int i7 = motorista0.getGrau();
        Veiculo veiculo8 = motorista0.getVeiculo();
        try {
            Motorista motorista9 = motorista0.clone();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(d4 == 0.0d);
        org.junit.Assert.assertTrue(b6 == false);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertNull(veiculo8);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        Veiculo veiculo2 = motorista0.getVeiculo();
        Veiculo veiculo8 = null;
        Motorista motorista9 = new Motorista("hi!", "hi!", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", veiculo8);
        int i10 = motorista9.getNumClassi();
        java.lang.String str11 = motorista9.getMail();
        Veiculo veiculo12 = motorista9.getVeiculo();
        try {
            boolean b13 = motorista0.equals((java.lang.Object) motorista9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNull(veiculo2);
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
        org.junit.Assert.assertNull(veiculo12);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        Motorista motorista0 = new Motorista();
        double d1 = motorista0.totalFaturado();
        motorista0.setDisponibilidade(false);
        motorista0.setDisponibilidade(false);
        java.util.GregorianCalendar gregorianCalendar6 = null;
        java.util.GregorianCalendar gregorianCalendar7 = null;
        double d8 = motorista0.totalFaturado(gregorianCalendar6, gregorianCalendar7);
        org.junit.Assert.assertTrue(d1 == 0.0d);
        org.junit.Assert.assertTrue(d8 == 0.0d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "", "", veiculo5);
        int i7 = motorista6.getNumClassi();
        java.lang.String str8 = motorista6.getNome();
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str8.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
        double d7 = motorista6.getKmsTotais();
        Coordenada coordenada8 = null;
        try {
            motorista6.atualizaDados(coordenada8, (double) (byte) 1, (double) ' ', (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(d7 == 0.0d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nNome: hi!\nPassword: hi!\nMorada: hi!\nData de nascimento: hi!\nGrau de cumprimento de horário: 100\nClassificação do motorista: 50\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", veiculo5);
        java.lang.String str7 = motorista6.getMail();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str7.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.getPassword();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        double d4 = motorista0.totalFaturado(gregorianCalendar2, gregorianCalendar3);
        boolean b5 = motorista0.getDisponibilidade();
        try {
            double d7 = motorista0.precoViagem((double) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertTrue(d4 == 0.0d);
        org.junit.Assert.assertTrue(b5 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        double d4 = motorista0.totalFaturado(gregorianCalendar2, gregorianCalendar3);
        java.lang.Object obj5 = null;
        boolean b6 = motorista0.equals(obj5);
        motorista0.setDisponibilidade(true);
        Veiculo veiculo9 = motorista0.getVeiculo();
        try {
            double d11 = motorista0.precoViagem((double) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(d4 == 0.0d);
        org.junit.Assert.assertTrue(b6 == false);
        org.junit.Assert.assertNull(veiculo9);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar4 = null;
        java.util.GregorianCalendar gregorianCalendar5 = null;
        double d6 = motorista0.totalFaturado(gregorianCalendar4, gregorianCalendar5);
        java.lang.String str7 = motorista0.getMorada();
        int i8 = motorista0.getGrau();
        Motorista motorista9 = new Motorista();
        double d10 = motorista9.totalFaturado();
        int i11 = motorista9.getGrau();
        boolean b12 = motorista9.getDisponibilidade();
        int i13 = motorista9.getClassificacao();
        motorista9.atualizaClassificacao((int) '#');
        int i16 = motorista0.compareTo(motorista9);
        try {
            double d18 = motorista9.tempoViagem((double) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue(d10 == 0.0d);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(i16 == (-1));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
        motorista6.setDisponibilidade(true);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
        java.lang.String str7 = motorista6.getPassword();
        java.lang.String str8 = motorista6.toString();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "E-mail: \nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: \nMorada: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nData de nascimento: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str8.equals("E-mail: \nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: \nMorada: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nData de nascimento: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        java.lang.String str2 = motorista0.getPassword();
        motorista0.atualizaClassificacao(0);
        motorista0.setDisponibilidade(true);
        Motorista motorista7 = new Motorista();
        Veiculo veiculo8 = motorista7.getVeiculo();
        java.lang.String str9 = motorista7.getMail();
        int i10 = motorista7.getNumClassi();
        motorista7.atualizaClassificacao((int) (byte) 10);
        int i13 = motorista7.getNumClassi();
        java.lang.String str14 = motorista7.getNome();
        int i15 = motorista7.getClassificacao();
        java.util.GregorianCalendar gregorianCalendar16 = null;
        java.util.GregorianCalendar gregorianCalendar17 = null;
        double d18 = motorista7.totalFaturado(gregorianCalendar16, gregorianCalendar17);
        java.util.GregorianCalendar gregorianCalendar19 = null;
        java.util.GregorianCalendar gregorianCalendar20 = null;
        double d21 = motorista7.totalFaturado(gregorianCalendar19, gregorianCalendar20);
        Veiculo veiculo22 = null;
        motorista7.setVeiculo(veiculo22);
        int i24 = motorista0.compareTo((Ator) motorista7);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNull(veiculo8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i13 == 1);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue(i15 == 10);
        org.junit.Assert.assertTrue(d18 == 0.0d);
        org.junit.Assert.assertTrue(d21 == 0.0d);
        org.junit.Assert.assertTrue(i24 == 0);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        int i2 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao(0);
        java.lang.String str5 = motorista0.getDataDeNascimento();
        Veiculo veiculo6 = null;
        motorista0.setVeiculo(veiculo6);
        java.util.GregorianCalendar gregorianCalendar8 = null;
        java.util.GregorianCalendar gregorianCalendar9 = null;
        double d10 = motorista0.totalFaturado(gregorianCalendar8, gregorianCalendar9);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(i2 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue(d10 == 0.0d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        double d9 = motorista0.totalFaturado();
        java.lang.String str10 = motorista0.toString();
        java.lang.String str11 = motorista0.getMorada();
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 10);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str10.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.util.Set<Viagem> set_viagem2 = motorista0.getHistorico();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertNotNull(set_viagem2);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        boolean b3 = motorista0.equals((java.lang.Object) (byte) 10);
        java.util.GregorianCalendar gregorianCalendar4 = null;
        java.util.GregorianCalendar gregorianCalendar5 = null;
        double d6 = motorista0.totalFaturado(gregorianCalendar4, gregorianCalendar5);
        boolean b7 = motorista0.getDisponibilidade();
        motorista0.atualizaClassificacao((int) (short) 0);
        Viagem viagem10 = null;
        try {
            motorista0.registaViagem(viagem10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(b7 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
        java.util.GregorianCalendar gregorianCalendar7 = null;
        java.util.GregorianCalendar gregorianCalendar8 = null;
        try {
            java.util.List<Viagem> list_viagem9 = motorista6.viagensEntreDatas(gregorianCalendar7, gregorianCalendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        double d4 = motorista0.totalFaturado(gregorianCalendar2, gregorianCalendar3);
        java.lang.Object obj5 = null;
        boolean b6 = motorista0.equals(obj5);
        int i7 = motorista0.getGrau();
        Veiculo veiculo8 = motorista0.getVeiculo();
        double d9 = motorista0.getKmsTotais();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(d4 == 0.0d);
        org.junit.Assert.assertTrue(b6 == false);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertNull(veiculo8);
        org.junit.Assert.assertTrue(d9 == 0.0d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        motorista0.atualizaClassificacao(0);
        double d8 = motorista0.getKmsTotais();
        int i9 = motorista0.getClassificacao();
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(d8 == 0.0d);
        org.junit.Assert.assertTrue(i9 == 5);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        int i2 = motorista0.getNumClassi();
        java.lang.String str3 = motorista0.getNome();
        java.lang.String str4 = motorista0.toString();
        Veiculo veiculo5 = null;
        motorista0.setVeiculo(veiculo5);
        double d7 = motorista0.getKmsTotais();
        try {
            double d9 = motorista0.precoViagem((double) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(i2 == 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str4.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(d7 == 0.0d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", veiculo5);
        double d7 = motorista6.totalFaturado();
        motorista6.setDisponibilidade(false);
        Motorista motorista10 = new Motorista();
        int i11 = motorista10.getGrau();
        boolean b13 = motorista10.equals((java.lang.Object) (byte) 10);
        int i14 = motorista10.getGrau();
        java.lang.String str15 = motorista10.getNome();
        int i16 = motorista10.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar17 = null;
        java.util.GregorianCalendar gregorianCalendar18 = null;
        double d19 = motorista10.totalFaturado(gregorianCalendar17, gregorianCalendar18);
        boolean b20 = motorista10.getDisponibilidade();
        int i21 = motorista6.compareTo(motorista10);
        java.util.GregorianCalendar gregorianCalendar22 = null;
        java.util.GregorianCalendar gregorianCalendar23 = null;
        try {
            java.util.List<Viagem> list_viagem24 = motorista10.viagensEntreDatas(gregorianCalendar22, gregorianCalendar23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(d7 == 0.0d);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(b13 == false);
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue(d19 == 0.0d);
        org.junit.Assert.assertTrue(b20 == false);
        org.junit.Assert.assertTrue(i21 == 3);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("hi!", "E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: true\n", veiculo5);
        try {
            Motorista motorista7 = motorista6.clone();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        double d4 = motorista0.totalFaturado(gregorianCalendar2, gregorianCalendar3);
        java.lang.Object obj5 = null;
        boolean b6 = motorista0.equals(obj5);
        double d7 = motorista0.getKmsTotais();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(d4 == 0.0d);
        org.junit.Assert.assertTrue(b6 == false);
        org.junit.Assert.assertTrue(d7 == 0.0d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.getPassword();
        java.lang.String str2 = motorista0.getDataDeNascimento();
        boolean b4 = motorista0.equals((java.lang.Object) 100L);
        Viagem viagem5 = null;
        try {
            motorista0.registaViagem(viagem5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(b4 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nData de nascimento: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nData de nascimento: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        double d4 = motorista0.totalFaturado(gregorianCalendar2, gregorianCalendar3);
        java.lang.Object obj5 = null;
        boolean b6 = motorista0.equals(obj5);
        motorista0.setDisponibilidade(true);
        java.lang.String str9 = motorista0.toString();
        int i10 = motorista0.getClassificacao();
        java.util.GregorianCalendar gregorianCalendar11 = null;
        java.util.GregorianCalendar gregorianCalendar12 = null;
        try {
            java.util.List<Viagem> list_viagem13 = motorista0.viagensEntreDatas(gregorianCalendar11, gregorianCalendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(d4 == 0.0d);
        org.junit.Assert.assertTrue(b6 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: true\n" + "'", str9.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: true\n"));
        org.junit.Assert.assertTrue(i10 == 0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        java.lang.String str9 = motorista0.getMail();
        java.lang.String str10 = motorista0.getPassword();
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 10);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        java.util.Set<Viagem> set_viagem5 = null;
        Veiculo veiculo11 = null;
        try {
            Motorista motorista12 = new Motorista("E-mail: \nNome: \nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nData de nascimento: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", "E-mail: \nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: \nMorada: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nData de nascimento: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", set_viagem5, (int) (short) 10, (int) '4', (int) (short) 100, (double) 100L, false, veiculo11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        boolean b3 = motorista0.equals((java.lang.Object) (byte) 10);
        int i4 = motorista0.getGrau();
        java.lang.String str5 = motorista0.getNome();
        int i6 = motorista0.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar7 = null;
        java.util.GregorianCalendar gregorianCalendar8 = null;
        double d9 = motorista0.totalFaturado(gregorianCalendar7, gregorianCalendar8);
        java.util.GregorianCalendar gregorianCalendar10 = null;
        java.util.GregorianCalendar gregorianCalendar11 = null;
        double d12 = motorista0.totalFaturado(gregorianCalendar10, gregorianCalendar11);
        java.util.Set<Viagem> set_viagem13 = motorista0.getHistorico();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue(d12 == 0.0d);
        org.junit.Assert.assertNotNull(set_viagem13);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        int i2 = motorista0.getNumClassi();
        java.lang.String str3 = motorista0.getNome();
        java.lang.String str4 = motorista0.toString();
        Veiculo veiculo5 = null;
        motorista0.setVeiculo(veiculo5);
        Motorista motorista7 = null;
        try {
            int i8 = motorista0.compareTo(motorista7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(i2 == 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str4.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", veiculo5);
        java.util.GregorianCalendar gregorianCalendar7 = null;
        java.util.GregorianCalendar gregorianCalendar8 = null;
        double d9 = motorista6.totalFaturado(gregorianCalendar7, gregorianCalendar8);
        int i10 = motorista6.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar11 = null;
        java.util.GregorianCalendar gregorianCalendar12 = null;
        try {
            java.util.List<Viagem> list_viagem13 = motorista6.viagensEntreDatas(gregorianCalendar11, gregorianCalendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue(i10 == 0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.getPassword();
        motorista0.atualizaClassificacao(100);
        Motorista motorista4 = new Motorista();
        int i5 = motorista4.getGrau();
        boolean b7 = motorista4.equals((java.lang.Object) (byte) 10);
        int i8 = motorista4.getGrau();
        java.lang.String str9 = motorista4.getNome();
        int i10 = motorista4.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar11 = null;
        java.util.GregorianCalendar gregorianCalendar12 = null;
        double d13 = motorista4.totalFaturado(gregorianCalendar11, gregorianCalendar12);
        int i14 = motorista0.compareTo((Ator) motorista4);
        try {
            Motorista motorista15 = new Motorista(motorista4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(b7 == false);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(d13 == 0.0d);
        org.junit.Assert.assertTrue(i14 == 0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        motorista0.atualizaClassificacao(0);
        java.lang.String str8 = motorista0.getMorada();
        java.lang.String str9 = motorista0.getNome();
        java.lang.String str10 = motorista0.getDataDeNascimento();
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        Motorista motorista0 = new Motorista();
        double d1 = motorista0.totalFaturado();
        motorista0.setDisponibilidade(false);
        int i4 = motorista0.getNumClassi();
        java.lang.String str5 = motorista0.getMorada();
        motorista0.atualizaClassificacao((int) (short) 100);
        boolean b8 = motorista0.getDisponibilidade();
        java.util.GregorianCalendar gregorianCalendar9 = null;
        java.util.GregorianCalendar gregorianCalendar10 = null;
        try {
            java.util.List<Viagem> list_viagem11 = motorista0.viagensEntreDatas(gregorianCalendar9, gregorianCalendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(d1 == 0.0d);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue(b8 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        motorista0.setDisponibilidade(true);
        double d11 = motorista0.getKmsTotais();
        int i12 = motorista0.getNumClassi();
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 10);
        org.junit.Assert.assertTrue(d11 == 0.0d);
        org.junit.Assert.assertTrue(i12 == 1);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "hi!", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", veiculo5);
        motorista6.setDisponibilidade(true);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("hi!", "hi!", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", veiculo5);
        int i7 = motorista6.getNumClassi();
        java.lang.String str8 = motorista6.getMail();
        Veiculo veiculo9 = motorista6.getVeiculo();
        try {
            Motorista motorista10 = motorista6.clone();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertNull(veiculo9);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        java.lang.String str4 = motorista0.getDataDeNascimento();
        java.util.Set<Viagem> set_viagem5 = motorista0.getHistorico();
        java.lang.String str6 = motorista0.getNome();
        Veiculo veiculo12 = null;
        Motorista motorista13 = new Motorista("", "", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo12);
        int i14 = motorista0.compareTo(motorista13);
        try {
            Motorista motorista15 = new Motorista(motorista0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(set_viagem5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue(i14 == (-229));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        double d9 = motorista0.totalFaturado();
        java.lang.String str10 = motorista0.toString();
        boolean b12 = motorista0.equals((java.lang.Object) 1.0d);
        java.lang.String str13 = motorista0.getMorada();
        double d14 = motorista0.getKmsTotais();
        java.lang.String str15 = motorista0.getNome();
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 10);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str10.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue(d14 == 0.0d);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        Veiculo veiculo7 = motorista0.getVeiculo();
        double d8 = motorista0.getKmsTotais();
        int i9 = motorista0.getGrau();
        java.lang.String str10 = motorista0.getDataDeNascimento();
        java.util.Set<Viagem> set_viagem11 = motorista0.getHistorico();
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertNull(veiculo7);
        org.junit.Assert.assertTrue(d8 == 0.0d);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(set_viagem11);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        java.lang.String str2 = motorista0.getPassword();
        motorista0.atualizaClassificacao(0);
        motorista0.setDisponibilidade(true);
        int i7 = motorista0.getGrau();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i7 == 0);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        java.lang.String str2 = motorista0.getPassword();
        motorista0.atualizaClassificacao(0);
        java.lang.String str5 = motorista0.getMail();
        Veiculo veiculo6 = null;
        motorista0.setVeiculo(veiculo6);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        boolean b3 = motorista0.getDisponibilidade();
        boolean b4 = motorista0.getDisponibilidade();
        Veiculo veiculo5 = motorista0.getVeiculo();
        java.lang.String str6 = motorista0.toString();
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNull(veiculo5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str6.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar4 = null;
        java.util.GregorianCalendar gregorianCalendar5 = null;
        double d6 = motorista0.totalFaturado(gregorianCalendar4, gregorianCalendar5);
        java.lang.String str7 = motorista0.getMorada();
        Veiculo veiculo8 = null;
        motorista0.setVeiculo(veiculo8);
        java.util.Set<Viagem> set_viagem10 = motorista0.getHistorico();
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(set_viagem10);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        Motorista motorista0 = new Motorista();
        double d1 = motorista0.totalFaturado();
        motorista0.setDisponibilidade(false);
        int i4 = motorista0.getNumClassi();
        java.lang.String str5 = motorista0.getMorada();
        try {
            Viagem viagem6 = motorista0.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertTrue(d1 == 0.0d);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar4 = null;
        java.util.GregorianCalendar gregorianCalendar5 = null;
        double d6 = motorista0.totalFaturado(gregorianCalendar4, gregorianCalendar5);
        boolean b7 = motorista0.getDisponibilidade();
        Veiculo veiculo8 = motorista0.getVeiculo();
        int i9 = motorista0.getNumClassi();
        java.util.Set<Viagem> set_viagem10 = motorista0.getHistorico();
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(b7 == false);
        org.junit.Assert.assertNull(veiculo8);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertNotNull(set_viagem10);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: true\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: true\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: true\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: true\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
        int i7 = motorista6.getClassificacao();
        Veiculo veiculo8 = null;
        motorista6.setVeiculo(veiculo8);
        try {
            Motorista motorista10 = new Motorista(motorista6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i7 == 100);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", veiculo5);
        java.lang.String str7 = motorista6.getPassword();
        Motorista motorista8 = new Motorista();
        double d9 = motorista8.totalFaturado();
        int i10 = motorista8.getGrau();
        boolean b11 = motorista8.getDisponibilidade();
        int i12 = motorista8.getClassificacao();
        java.util.GregorianCalendar gregorianCalendar13 = null;
        java.util.GregorianCalendar gregorianCalendar14 = null;
        double d15 = motorista8.totalFaturado(gregorianCalendar13, gregorianCalendar14);
        int i16 = motorista6.compareTo(motorista8);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str7.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertTrue(d15 == 0.0d);
        org.junit.Assert.assertTrue(i16 == 3);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        java.util.GregorianCalendar gregorianCalendar9 = null;
        java.util.GregorianCalendar gregorianCalendar10 = null;
        double d11 = motorista0.totalFaturado(gregorianCalendar9, gregorianCalendar10);
        java.lang.String str12 = motorista0.toString();
        motorista0.setDisponibilidade(true);
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 10);
        org.junit.Assert.assertTrue(d11 == 0.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str12.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        double d2 = motorista0.getKmsTotais();
        Coordenada coordenada3 = null;
        try {
            motorista0.atualizaDados(coordenada3, 1.0d, (double) (byte) 0, (double) 5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue(d2 == 0.0d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        Motorista motorista0 = new Motorista();
        double d1 = motorista0.totalFaturado();
        motorista0.setDisponibilidade(false);
        Veiculo veiculo4 = null;
        motorista0.setVeiculo(veiculo4);
        int i6 = motorista0.getClassificacao();
        motorista0.atualizaClassificacao((int) '#');
        org.junit.Assert.assertTrue(d1 == 0.0d);
        org.junit.Assert.assertTrue(i6 == 0);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("hi!", "hi!", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", veiculo5);
        int i7 = motorista6.getNumClassi();
        java.lang.String str8 = motorista6.getMail();
        Veiculo veiculo9 = motorista6.getVeiculo();
        Coordenada coordenada10 = null;
        try {
            motorista6.atualizaDados(coordenada10, (double) (-230), (double) 1, (double) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertNull(veiculo9);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        Veiculo veiculo2 = motorista0.getVeiculo();
        java.lang.String str3 = motorista0.getDataDeNascimento();
        java.lang.String str4 = motorista0.getNome();
        Veiculo veiculo5 = motorista0.getVeiculo();
        Veiculo veiculo6 = null;
        motorista0.setVeiculo(veiculo6);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNull(veiculo2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNull(veiculo5);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.getPassword();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        double d4 = motorista0.totalFaturado(gregorianCalendar2, gregorianCalendar3);
        double d5 = motorista0.getKmsTotais();
        java.util.GregorianCalendar gregorianCalendar6 = null;
        java.util.GregorianCalendar gregorianCalendar7 = null;
        double d8 = motorista0.totalFaturado(gregorianCalendar6, gregorianCalendar7);
        java.lang.String str9 = motorista0.getNome();
        Coordenada coordenada10 = null;
        try {
            motorista0.atualizaDados(coordenada10, (-1.0d), (double) 1.0f, (double) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertTrue(d4 == 0.0d);
        org.junit.Assert.assertTrue(d5 == 0.0d);
        org.junit.Assert.assertTrue(d8 == 0.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "E-mail: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nNome: hi!\nPassword: hi!\nMorada: hi!\nData de nascimento: hi!\nGrau de cumprimento de horário: 100\nClassificação do motorista: 50\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
        Ator ator7 = null;
        try {
            int i8 = motorista6.compareTo(ator7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        motorista0.atualizaClassificacao(0);
        double d8 = motorista0.getKmsTotais();
        java.lang.String str9 = motorista0.getDataDeNascimento();
        boolean b11 = motorista0.equals((java.lang.Object) (short) 1);
        Veiculo veiculo12 = null;
        motorista0.setVeiculo(veiculo12);
        try {
            Motorista motorista14 = new Motorista(motorista0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(d8 == 0.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue(b11 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        java.lang.String str4 = motorista0.getPassword();
        java.lang.String str5 = motorista0.getMail();
        java.lang.String str6 = motorista0.toString();
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str6.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        double d4 = motorista0.totalFaturado(gregorianCalendar2, gregorianCalendar3);
        java.lang.Object obj5 = null;
        boolean b6 = motorista0.equals(obj5);
        java.lang.String str7 = motorista0.getDataDeNascimento();
        java.lang.String str8 = motorista0.getMorada();
        try {
            Viagem viagem9 = motorista0.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(d4 == 0.0d);
        org.junit.Assert.assertTrue(b6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "hi!", "hi!", veiculo5);
        motorista6.atualizaClassificacao(100);
        motorista6.atualizaClassificacao((int) (short) 1);
        java.lang.String str11 = motorista6.toString();
        double d12 = motorista6.totalFaturado();
        java.lang.String str13 = motorista6.getNome();
        boolean b14 = motorista6.getDisponibilidade();
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "E-mail: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nNome: hi!\nPassword: hi!\nMorada: hi!\nData de nascimento: hi!\nGrau de cumprimento de horário: 100\nClassificação do motorista: 50\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str11.equals("E-mail: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nNome: hi!\nPassword: hi!\nMorada: hi!\nData de nascimento: hi!\nGrau de cumprimento de horário: 100\nClassificação do motorista: 50\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(d12 == 0.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertTrue(b14 == false);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        boolean b3 = motorista0.getDisponibilidade();
        boolean b4 = motorista0.getDisponibilidade();
        int i5 = motorista0.getGrau();
        java.util.GregorianCalendar gregorianCalendar6 = null;
        java.util.GregorianCalendar gregorianCalendar7 = null;
        double d8 = motorista0.totalFaturado(gregorianCalendar6, gregorianCalendar7);
        try {
            Motorista motorista9 = new Motorista(motorista0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(d8 == 0.0d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        int i2 = motorista0.getNumClassi();
        java.lang.String str3 = motorista0.getNome();
        double d4 = motorista0.getKmsTotais();
        try {
            Viagem viagem5 = motorista0.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(i2 == 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue(d4 == 0.0d);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "hi!", "hi!", veiculo5);
        motorista6.atualizaClassificacao(100);
        motorista6.atualizaClassificacao((int) (short) 1);
        Veiculo veiculo11 = motorista6.getVeiculo();
        Viagem viagem12 = null;
        try {
            motorista6.registaViagem(viagem12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo11);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        boolean b3 = motorista0.getDisponibilidade();
        int i4 = motorista0.getNumClassi();
        java.lang.String str5 = motorista0.getPassword();
        Motorista motorista6 = new Motorista();
        Veiculo veiculo7 = motorista6.getVeiculo();
        java.lang.String str8 = motorista6.getMail();
        boolean b9 = motorista6.getDisponibilidade();
        boolean b10 = motorista6.getDisponibilidade();
        int i11 = motorista6.getGrau();
        java.util.GregorianCalendar gregorianCalendar12 = null;
        java.util.GregorianCalendar gregorianCalendar13 = null;
        double d14 = motorista6.totalFaturado(gregorianCalendar12, gregorianCalendar13);
        try {
            int i15 = motorista0.compareTo(motorista6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNull(veiculo7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue(b9 == false);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(d14 == 0.0d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        boolean b3 = motorista0.equals((java.lang.Object) (byte) 10);
        int i4 = motorista0.getGrau();
        java.lang.String str5 = motorista0.getNome();
        int i6 = motorista0.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar7 = null;
        java.util.GregorianCalendar gregorianCalendar8 = null;
        double d9 = motorista0.totalFaturado(gregorianCalendar7, gregorianCalendar8);
        java.lang.String str10 = motorista0.getDataDeNascimento();
        try {
            Motorista motorista11 = new Motorista(motorista0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        motorista0.setDisponibilidade(true);
        java.util.GregorianCalendar gregorianCalendar11 = null;
        java.util.GregorianCalendar gregorianCalendar12 = null;
        double d13 = motorista0.totalFaturado(gregorianCalendar11, gregorianCalendar12);
        try {
            double d15 = motorista0.tempoViagem((double) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 10);
        org.junit.Assert.assertTrue(d13 == 0.0d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("hi!", "E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: true\n", veiculo5);
        try {
            double d8 = motorista6.tempoViagem((double) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        java.util.GregorianCalendar gregorianCalendar9 = null;
        java.util.GregorianCalendar gregorianCalendar10 = null;
        double d11 = motorista0.totalFaturado(gregorianCalendar9, gregorianCalendar10);
        java.lang.String str12 = motorista0.toString();
        java.lang.String str13 = motorista0.getMorada();
        Motorista motorista14 = new Motorista();
        java.lang.String str15 = motorista14.toString();
        java.util.GregorianCalendar gregorianCalendar16 = null;
        java.util.GregorianCalendar gregorianCalendar17 = null;
        double d18 = motorista14.totalFaturado(gregorianCalendar16, gregorianCalendar17);
        double d19 = motorista14.getKmsTotais();
        motorista14.setDisponibilidade(true);
        int i22 = motorista0.compareTo(motorista14);
        try {
            double d24 = motorista14.precoViagem((double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 10);
        org.junit.Assert.assertTrue(d11 == 0.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str12.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str15.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(d18 == 0.0d);
        org.junit.Assert.assertTrue(d19 == 0.0d);
        org.junit.Assert.assertTrue(i22 == 1);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        int i2 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao(0);
        motorista0.atualizaClassificacao(100);
        Veiculo veiculo7 = motorista0.getVeiculo();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(i2 == 0);
        org.junit.Assert.assertNull(veiculo7);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        Motorista motorista0 = new Motorista();
        double d1 = motorista0.totalFaturado();
        int i2 = motorista0.getGrau();
        boolean b3 = motorista0.getDisponibilidade();
        int i4 = motorista0.getClassificacao();
        java.util.GregorianCalendar gregorianCalendar5 = null;
        java.util.GregorianCalendar gregorianCalendar6 = null;
        double d7 = motorista0.totalFaturado(gregorianCalendar5, gregorianCalendar6);
        try {
            double d9 = motorista0.tempoViagem(10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(d1 == 0.0d);
        org.junit.Assert.assertTrue(i2 == 0);
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue(d7 == 0.0d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nNome: hi!\nPassword: hi!\nMorada: hi!\nData de nascimento: hi!\nGrau de cumprimento de horário: 100\nClassificação do motorista: 50\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        boolean b3 = motorista0.getDisponibilidade();
        java.util.GregorianCalendar gregorianCalendar4 = null;
        java.util.GregorianCalendar gregorianCalendar5 = null;
        double d6 = motorista0.totalFaturado(gregorianCalendar4, gregorianCalendar5);
        int i7 = motorista0.getClassificacao();
        Motorista motorista8 = new Motorista();
        java.lang.String str9 = motorista8.toString();
        java.util.GregorianCalendar gregorianCalendar10 = null;
        java.util.GregorianCalendar gregorianCalendar11 = null;
        double d12 = motorista8.totalFaturado(gregorianCalendar10, gregorianCalendar11);
        java.lang.Object obj13 = null;
        boolean b14 = motorista8.equals(obj13);
        int i15 = motorista8.getGrau();
        try {
            boolean b16 = motorista0.equals((java.lang.Object) motorista8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str9.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(d12 == 0.0d);
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertTrue(i15 == 0);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "", "E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: true\n", veiculo5);
        try {
            double d8 = motorista6.precoViagem((double) (-230));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        java.lang.String str4 = motorista0.getDataDeNascimento();
        java.util.Set<Viagem> set_viagem5 = motorista0.getHistorico();
        motorista0.setDisponibilidade(true);
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(set_viagem5);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        double d4 = motorista0.totalFaturado(gregorianCalendar2, gregorianCalendar3);
        java.lang.Object obj5 = null;
        boolean b6 = motorista0.equals(obj5);
        java.lang.String str7 = motorista0.getDataDeNascimento();
        java.lang.String str8 = motorista0.getMorada();
        java.lang.String str9 = motorista0.getNome();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(d4 == 0.0d);
        org.junit.Assert.assertTrue(b6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        Veiculo veiculo2 = motorista0.getVeiculo();
        java.lang.String str3 = motorista0.getDataDeNascimento();
        java.lang.String str4 = motorista0.getPassword();
        int i5 = motorista0.getClassificacao();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNull(veiculo2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue(i5 == 0);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", veiculo5);
        java.lang.String str7 = motorista6.getPassword();
        motorista6.atualizaClassificacao((int) '#');
        Motorista motorista10 = new Motorista();
        int i11 = motorista10.getGrau();
        boolean b13 = motorista10.equals((java.lang.Object) (byte) 10);
        Veiculo veiculo14 = motorista10.getVeiculo();
        int i15 = motorista6.compareTo((Ator) motorista10);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str7.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(b13 == false);
        org.junit.Assert.assertNull(veiculo14);
        org.junit.Assert.assertTrue(i15 == 3);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.lang.String str2 = motorista0.getMail();
        java.lang.String str3 = motorista0.getMail();
        java.lang.String str4 = motorista0.toString();
        java.lang.String str5 = motorista0.getMail();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str4.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nNome: hi!\nPassword: hi!\nMorada: hi!\nData de nascimento: hi!\nGrau de cumprimento de horário: 100\nClassificação do motorista: 50\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", veiculo5);
        try {
            Motorista motorista7 = new Motorista(motorista6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        java.util.GregorianCalendar gregorianCalendar9 = null;
        java.util.GregorianCalendar gregorianCalendar10 = null;
        double d11 = motorista0.totalFaturado(gregorianCalendar9, gregorianCalendar10);
        java.lang.String str12 = motorista0.toString();
        java.lang.String str13 = motorista0.getMorada();
        Motorista motorista14 = new Motorista();
        java.lang.String str15 = motorista14.toString();
        java.util.GregorianCalendar gregorianCalendar16 = null;
        java.util.GregorianCalendar gregorianCalendar17 = null;
        double d18 = motorista14.totalFaturado(gregorianCalendar16, gregorianCalendar17);
        double d19 = motorista14.getKmsTotais();
        motorista14.setDisponibilidade(true);
        int i22 = motorista0.compareTo(motorista14);
        try {
            double d24 = motorista14.precoViagem((double) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 10);
        org.junit.Assert.assertTrue(d11 == 0.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str12.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str15.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(d18 == 0.0d);
        org.junit.Assert.assertTrue(d19 == 0.0d);
        org.junit.Assert.assertTrue(i22 == 1);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        Motorista motorista0 = new Motorista();
        double d1 = motorista0.totalFaturado();
        int i2 = motorista0.getGrau();
        boolean b3 = motorista0.getDisponibilidade();
        int i4 = motorista0.getClassificacao();
        java.util.GregorianCalendar gregorianCalendar5 = null;
        java.util.GregorianCalendar gregorianCalendar6 = null;
        double d7 = motorista0.totalFaturado(gregorianCalendar5, gregorianCalendar6);
        motorista0.setDisponibilidade(false);
        org.junit.Assert.assertTrue(d1 == 0.0d);
        org.junit.Assert.assertTrue(i2 == 0);
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue(d7 == 0.0d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", veiculo5);
        java.lang.String str7 = motorista6.getPassword();
        try {
            Motorista motorista8 = new Motorista(motorista6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str7.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        java.util.GregorianCalendar gregorianCalendar9 = null;
        java.util.GregorianCalendar gregorianCalendar10 = null;
        double d11 = motorista0.totalFaturado(gregorianCalendar9, gregorianCalendar10);
        java.lang.String str12 = motorista0.toString();
        java.lang.String str13 = motorista0.getMorada();
        Motorista motorista14 = new Motorista();
        java.lang.String str15 = motorista14.toString();
        java.util.GregorianCalendar gregorianCalendar16 = null;
        java.util.GregorianCalendar gregorianCalendar17 = null;
        double d18 = motorista14.totalFaturado(gregorianCalendar16, gregorianCalendar17);
        double d19 = motorista14.getKmsTotais();
        motorista14.setDisponibilidade(true);
        int i22 = motorista0.compareTo(motorista14);
        Viagem viagem23 = null;
        try {
            motorista0.registaViagem(viagem23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 10);
        org.junit.Assert.assertTrue(d11 == 0.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str12.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str15.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(d18 == 0.0d);
        org.junit.Assert.assertTrue(d19 == 0.0d);
        org.junit.Assert.assertTrue(i22 == 1);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.lang.String str2 = motorista0.toString();
        java.lang.String str3 = motorista0.getDataDeNascimento();
        java.lang.String str4 = motorista0.getPassword();
        Veiculo veiculo5 = motorista0.getVeiculo();
        motorista0.setDisponibilidade(false);
        Viagem viagem8 = null;
        try {
            motorista0.registaViagem(viagem8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str2.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNull(veiculo5);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        Veiculo veiculo6 = motorista0.getVeiculo();
        motorista0.atualizaClassificacao(100);
        int i9 = motorista0.getNumClassi();
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertNull(veiculo6);
        org.junit.Assert.assertTrue(i9 == 2);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        double d9 = motorista0.totalFaturado();
        java.lang.String str10 = motorista0.toString();
        boolean b12 = motorista0.equals((java.lang.Object) 1.0d);
        java.lang.String str13 = motorista0.getMorada();
        java.lang.String str14 = motorista0.toString();
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 10);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str10.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str14.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
        java.util.Set<Viagem> set_viagem7 = motorista6.getHistorico();
        java.lang.String str8 = motorista6.toString();
        double d9 = motorista6.totalFaturado();
        double d10 = motorista6.totalFaturado();
        Motorista motorista11 = null;
        try {
            int i12 = motorista6.compareTo(motorista11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "E-mail: \nNome: \nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nData de nascimento: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str8.equals("E-mail: \nNome: \nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nData de nascimento: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue(d10 == 0.0d);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.lang.String str2 = motorista0.getMail();
        Coordenada coordenada3 = null;
        try {
            motorista0.atualizaDados(coordenada3, (double) 0L, (double) (-35), (double) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        boolean b3 = motorista0.equals((java.lang.Object) (byte) 10);
        java.util.GregorianCalendar gregorianCalendar4 = null;
        java.util.GregorianCalendar gregorianCalendar5 = null;
        double d6 = motorista0.totalFaturado(gregorianCalendar4, gregorianCalendar5);
        int i7 = motorista0.getClassificacao();
        motorista0.setDisponibilidade(false);
        java.util.GregorianCalendar gregorianCalendar10 = null;
        java.util.GregorianCalendar gregorianCalendar11 = null;
        try {
            java.util.List<Viagem> list_viagem12 = motorista0.viagensEntreDatas(gregorianCalendar10, gregorianCalendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(i7 == 0);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar4 = null;
        java.util.GregorianCalendar gregorianCalendar5 = null;
        double d6 = motorista0.totalFaturado(gregorianCalendar4, gregorianCalendar5);
        boolean b7 = motorista0.getDisponibilidade();
        java.lang.String str8 = motorista0.toString();
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(b7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str8.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        double d4 = motorista0.totalFaturado(gregorianCalendar2, gregorianCalendar3);
        java.lang.Object obj5 = null;
        boolean b6 = motorista0.equals(obj5);
        motorista0.setDisponibilidade(true);
        java.lang.String str9 = motorista0.toString();
        int i10 = motorista0.getClassificacao();
        Veiculo veiculo16 = null;
        Motorista motorista17 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", "", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: true\n", "E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo16);
        int i18 = motorista17.getClassificacao();
        try {
            boolean b19 = motorista0.equals((java.lang.Object) motorista17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(d4 == 0.0d);
        org.junit.Assert.assertTrue(b6 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: true\n" + "'", str9.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: true\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i18 == 100);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("hi!", "E-mail: hi!\nNome: hi!\nPassword: hi!\nMorada: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: hi!\nNome: hi!\nPassword: hi!\nMorada: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
        try {
            double d8 = motorista6.tempoViagem((double) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        boolean b3 = motorista0.equals((java.lang.Object) (byte) 10);
        Veiculo veiculo4 = motorista0.getVeiculo();
        java.lang.String str5 = motorista0.getMorada();
        java.lang.String str6 = motorista0.getNome();
        Motorista motorista7 = new Motorista();
        Veiculo veiculo8 = motorista7.getVeiculo();
        java.lang.String str9 = motorista7.getMail();
        int i10 = motorista7.getNumClassi();
        java.lang.String str11 = motorista7.getDataDeNascimento();
        boolean b12 = motorista7.getDisponibilidade();
        int i13 = motorista0.compareTo((Ator) motorista7);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertNull(veiculo4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNull(veiculo8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertTrue(i13 == 0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        double d4 = motorista0.totalFaturado(gregorianCalendar2, gregorianCalendar3);
        java.lang.Object obj5 = null;
        boolean b6 = motorista0.equals(obj5);
        motorista0.setDisponibilidade(true);
        int i9 = motorista0.getGrau();
        int i10 = motorista0.getClassificacao();
        double d11 = motorista0.totalFaturado();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(d4 == 0.0d);
        org.junit.Assert.assertTrue(b6 == false);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(d11 == 0.0d);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        double d9 = motorista0.totalFaturado();
        java.util.GregorianCalendar gregorianCalendar10 = null;
        java.util.GregorianCalendar gregorianCalendar11 = null;
        double d12 = motorista0.totalFaturado(gregorianCalendar10, gregorianCalendar11);
        java.util.Set<Viagem> set_viagem13 = motorista0.getHistorico();
        java.lang.String str14 = motorista0.getPassword();
        java.util.GregorianCalendar gregorianCalendar15 = null;
        java.util.GregorianCalendar gregorianCalendar16 = null;
        double d17 = motorista0.totalFaturado(gregorianCalendar15, gregorianCalendar16);
        int i18 = motorista0.getNumClassi();
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 10);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue(d12 == 0.0d);
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue(d17 == 0.0d);
        org.junit.Assert.assertTrue(i18 == 1);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        Veiculo veiculo6 = null;
        motorista0.setVeiculo(veiculo6);
        java.lang.String str8 = motorista0.getDataDeNascimento();
        try {
            Motorista motorista9 = new Motorista(motorista0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        boolean b3 = motorista0.equals((java.lang.Object) (byte) 10);
        java.util.Set<Viagem> set_viagem4 = motorista0.getHistorico();
        Veiculo veiculo5 = null;
        motorista0.setVeiculo(veiculo5);
        java.lang.String str7 = motorista0.toString();
        double d8 = motorista0.totalFaturado();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertNotNull(set_viagem4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str7.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(d8 == 0.0d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", veiculo5);
        double d7 = motorista6.getKmsTotais();
        try {
            double d9 = motorista6.precoViagem(0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(d7 == 0.0d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        boolean b3 = motorista0.equals((java.lang.Object) (byte) 10);
        int i4 = motorista0.getGrau();
        java.lang.String str5 = motorista0.getNome();
        int i6 = motorista0.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar7 = null;
        java.util.GregorianCalendar gregorianCalendar8 = null;
        double d9 = motorista0.totalFaturado(gregorianCalendar7, gregorianCalendar8);
        java.lang.String str10 = motorista0.getMorada();
        double d11 = motorista0.getKmsTotais();
        try {
            Motorista motorista12 = new Motorista(motorista0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue(d11 == 0.0d);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "hi!", "hi!", veiculo5);
        motorista6.atualizaClassificacao(100);
        motorista6.atualizaClassificacao((int) (short) 1);
        java.lang.String str11 = motorista6.toString();
        motorista6.setDisponibilidade(false);
        Veiculo veiculo14 = motorista6.getVeiculo();
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "E-mail: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nNome: hi!\nPassword: hi!\nMorada: hi!\nData de nascimento: hi!\nGrau de cumprimento de horário: 100\nClassificação do motorista: 50\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str11.equals("E-mail: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nNome: hi!\nPassword: hi!\nMorada: hi!\nData de nascimento: hi!\nGrau de cumprimento de horário: 100\nClassificação do motorista: 50\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertNull(veiculo14);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.getPassword();
        java.lang.String str2 = motorista0.getDataDeNascimento();
        boolean b4 = motorista0.equals((java.lang.Object) 100L);
        motorista0.atualizaClassificacao(100);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(b4 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        motorista0.atualizaClassificacao(0);
        java.lang.String str8 = motorista0.getMorada();
        java.lang.String str9 = motorista0.toString();
        Veiculo veiculo10 = motorista0.getVeiculo();
        Motorista motorista11 = new Motorista();
        Veiculo veiculo12 = motorista11.getVeiculo();
        java.lang.String str13 = motorista11.getMail();
        int i14 = motorista11.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar15 = null;
        java.util.GregorianCalendar gregorianCalendar16 = null;
        double d17 = motorista11.totalFaturado(gregorianCalendar15, gregorianCalendar16);
        boolean b18 = motorista11.getDisponibilidade();
        int i19 = motorista0.compareTo(motorista11);
        java.util.GregorianCalendar gregorianCalendar20 = null;
        java.util.GregorianCalendar gregorianCalendar21 = null;
        try {
            java.util.List<Viagem> list_viagem22 = motorista11.viagensEntreDatas(gregorianCalendar20, gregorianCalendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str9.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertNull(veiculo10);
        org.junit.Assert.assertNull(veiculo12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(d17 == 0.0d);
        org.junit.Assert.assertTrue(b18 == false);
        org.junit.Assert.assertTrue(i19 == 1);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        motorista0.setDisponibilidade(true);
        int i11 = motorista0.getClassificacao();
        motorista0.atualizaClassificacao(5);
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 10);
        org.junit.Assert.assertTrue(i11 == 10);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        double d9 = motorista0.totalFaturado();
        java.util.GregorianCalendar gregorianCalendar10 = null;
        java.util.GregorianCalendar gregorianCalendar11 = null;
        double d12 = motorista0.totalFaturado(gregorianCalendar10, gregorianCalendar11);
        java.util.Set<Viagem> set_viagem13 = motorista0.getHistorico();
        java.lang.String str14 = motorista0.getPassword();
        int i15 = motorista0.getGrau();
        try {
            Viagem viagem16 = motorista0.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 10);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue(d12 == 0.0d);
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue(i15 == 0);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
        double d7 = motorista6.getKmsTotais();
        int i8 = motorista6.getGrau();
        org.junit.Assert.assertTrue(d7 == 0.0d);
        org.junit.Assert.assertTrue(i8 == 100);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "hi!", "hi!", veiculo5);
        motorista6.atualizaClassificacao(100);
        motorista6.atualizaClassificacao((int) (short) 1);
        java.lang.String str11 = motorista6.toString();
        motorista6.setDisponibilidade(false);
        double d14 = motorista6.getKmsTotais();
        Motorista motorista15 = new Motorista();
        int i16 = motorista15.getGrau();
        boolean b18 = motorista15.equals((java.lang.Object) (byte) 10);
        int i19 = motorista15.getGrau();
        try {
            boolean b20 = motorista6.equals((java.lang.Object) motorista15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "E-mail: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nNome: hi!\nPassword: hi!\nMorada: hi!\nData de nascimento: hi!\nGrau de cumprimento de horário: 100\nClassificação do motorista: 50\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str11.equals("E-mail: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nNome: hi!\nPassword: hi!\nMorada: hi!\nData de nascimento: hi!\nGrau de cumprimento de horário: 100\nClassificação do motorista: 50\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(d14 == 0.0d);
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue(b18 == false);
        org.junit.Assert.assertTrue(i19 == 0);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "hi!", "hi!", veiculo5);
        java.util.GregorianCalendar gregorianCalendar7 = null;
        java.util.GregorianCalendar gregorianCalendar8 = null;
        double d9 = motorista6.totalFaturado(gregorianCalendar7, gregorianCalendar8);
        int i10 = motorista6.getNumClassi();
        java.lang.String str11 = motorista6.getMail();
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str11.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "", veiculo5);
        boolean b7 = motorista6.getDisponibilidade();
        java.lang.String str8 = motorista6.toString();
        java.util.GregorianCalendar gregorianCalendar9 = null;
        java.util.GregorianCalendar gregorianCalendar10 = null;
        try {
            java.util.List<Viagem> list_viagem11 = motorista6.viagensEntreDatas(gregorianCalendar9, gregorianCalendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(b7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str8.equals("E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        java.util.GregorianCalendar gregorianCalendar9 = null;
        java.util.GregorianCalendar gregorianCalendar10 = null;
        double d11 = motorista0.totalFaturado(gregorianCalendar9, gregorianCalendar10);
        Veiculo veiculo12 = motorista0.getVeiculo();
        int i13 = motorista0.getGrau();
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 10);
        org.junit.Assert.assertTrue(d11 == 0.0d);
        org.junit.Assert.assertNull(veiculo12);
        org.junit.Assert.assertTrue(i13 == 0);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.getPassword();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        double d4 = motorista0.totalFaturado(gregorianCalendar2, gregorianCalendar3);
        double d5 = motorista0.getKmsTotais();
        Veiculo veiculo6 = motorista0.getVeiculo();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertTrue(d4 == 0.0d);
        org.junit.Assert.assertTrue(d5 == 0.0d);
        org.junit.Assert.assertNull(veiculo6);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "hi!", "hi!", veiculo5);
        motorista6.atualizaClassificacao(100);
        motorista6.atualizaClassificacao((int) (short) 1);
        Veiculo veiculo11 = motorista6.getVeiculo();
        boolean b12 = motorista6.getDisponibilidade();
        java.lang.String str13 = motorista6.getMail();
        org.junit.Assert.assertNull(veiculo11);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str13.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar4 = null;
        java.util.GregorianCalendar gregorianCalendar5 = null;
        double d6 = motorista0.totalFaturado(gregorianCalendar4, gregorianCalendar5);
        boolean b7 = motorista0.getDisponibilidade();
        motorista0.setDisponibilidade(false);
        Motorista motorista10 = new Motorista();
        int i11 = motorista10.getGrau();
        Veiculo veiculo12 = motorista10.getVeiculo();
        java.lang.String str13 = motorista10.getDataDeNascimento();
        java.lang.String str14 = motorista10.getNome();
        java.util.GregorianCalendar gregorianCalendar15 = null;
        java.util.GregorianCalendar gregorianCalendar16 = null;
        double d17 = motorista10.totalFaturado(gregorianCalendar15, gregorianCalendar16);
        int i18 = motorista10.getClassificacao();
        Veiculo veiculo19 = null;
        motorista10.setVeiculo(veiculo19);
        try {
            boolean b21 = motorista0.equals((java.lang.Object) motorista10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(b7 == false);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertNull(veiculo12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue(d17 == 0.0d);
        org.junit.Assert.assertTrue(i18 == 0);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        double d9 = motorista0.totalFaturado();
        java.util.GregorianCalendar gregorianCalendar10 = null;
        java.util.GregorianCalendar gregorianCalendar11 = null;
        double d12 = motorista0.totalFaturado(gregorianCalendar10, gregorianCalendar11);
        int i13 = motorista0.getGrau();
        try {
            double d15 = motorista0.precoViagem((double) (-229));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 10);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue(d12 == 0.0d);
        org.junit.Assert.assertTrue(i13 == 0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        java.util.GregorianCalendar gregorianCalendar9 = null;
        java.util.GregorianCalendar gregorianCalendar10 = null;
        double d11 = motorista0.totalFaturado(gregorianCalendar9, gregorianCalendar10);
        java.lang.String str12 = motorista0.toString();
        java.lang.String str13 = motorista0.getMorada();
        java.lang.String str14 = motorista0.getMail();
        java.lang.String str15 = motorista0.toString();
        Coordenada coordenada16 = null;
        try {
            motorista0.atualizaDados(coordenada16, 10.0d, 0.0d, 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 10);
        org.junit.Assert.assertTrue(d11 == 0.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str12.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str15.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        Veiculo veiculo7 = motorista0.getVeiculo();
        double d8 = motorista0.getKmsTotais();
        int i9 = motorista0.getGrau();
        java.lang.String str10 = motorista0.getDataDeNascimento();
        java.util.GregorianCalendar gregorianCalendar11 = null;
        java.util.GregorianCalendar gregorianCalendar12 = null;
        double d13 = motorista0.totalFaturado(gregorianCalendar11, gregorianCalendar12);
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertNull(veiculo7);
        org.junit.Assert.assertTrue(d8 == 0.0d);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue(d13 == 0.0d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
        motorista6.setDisponibilidade(false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "", "", veiculo5);
        int i7 = motorista6.getGrau();
        try {
            double d9 = motorista6.tempoViagem((double) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i7 == 100);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.setDisponibilidade(false);
        boolean b7 = motorista0.equals((java.lang.Object) (byte) 0);
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(b7 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        int i2 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao(0);
        Coordenada coordenada5 = null;
        try {
            motorista0.atualizaDados(coordenada5, (double) 230, (double) 10.0f, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
        double d7 = motorista6.getKmsTotais();
        Veiculo veiculo8 = motorista6.getVeiculo();
        Viagem viagem9 = null;
        try {
            motorista6.registaViagem(viagem9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(d7 == 0.0d);
        org.junit.Assert.assertNull(veiculo8);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nNome: E-mail: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nNome: hi!\nPassword: hi!\nMorada: hi!\nData de nascimento: hi!\nGrau de cumprimento de horário: 100\nClassificação do motorista: 50\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nData de nascimento: E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nData de nascimento: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nNome: E-mail: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nNome: hi!\nPassword: hi!\nMorada: hi!\nData de nascimento: hi!\nGrau de cumprimento de horário: 100\nClassificação do motorista: 50\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nData de nascimento: E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nNome: hi!\nPassword: hi!\nMorada: hi!\nData de nascimento: hi!\nGrau de cumprimento de horário: 100\nClassificação do motorista: 50\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        Veiculo veiculo6 = motorista0.getVeiculo();
        double d7 = motorista0.getKmsTotais();
        java.lang.String str8 = motorista0.getDataDeNascimento();
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertNull(veiculo6);
        org.junit.Assert.assertTrue(d7 == 0.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        Veiculo veiculo2 = motorista0.getVeiculo();
        java.lang.String str3 = motorista0.toString();
        Veiculo veiculo4 = null;
        motorista0.setVeiculo(veiculo4);
        Motorista motorista6 = new Motorista();
        int i7 = motorista6.getGrau();
        Veiculo veiculo8 = null;
        motorista6.setVeiculo(veiculo8);
        try {
            int i10 = motorista0.compareTo(motorista6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNull(veiculo2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str3.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(i7 == 0);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        Motorista motorista0 = new Motorista();
        double d1 = motorista0.totalFaturado();
        motorista0.setDisponibilidade(false);
        motorista0.setDisponibilidade(false);
        Motorista motorista6 = new Motorista();
        Veiculo veiculo7 = motorista6.getVeiculo();
        double d8 = motorista6.getKmsTotais();
        int i9 = motorista6.getClassificacao();
        Motorista motorista10 = new Motorista();
        Veiculo veiculo11 = motorista10.getVeiculo();
        java.lang.String str12 = motorista10.getMail();
        int i13 = motorista10.getNumClassi();
        motorista10.atualizaClassificacao((int) (byte) 10);
        int i16 = motorista10.getNumClassi();
        java.lang.String str17 = motorista10.getNome();
        int i18 = motorista10.getClassificacao();
        java.util.GregorianCalendar gregorianCalendar19 = null;
        java.util.GregorianCalendar gregorianCalendar20 = null;
        double d21 = motorista10.totalFaturado(gregorianCalendar19, gregorianCalendar20);
        Veiculo veiculo22 = null;
        motorista10.setVeiculo(veiculo22);
        motorista10.setDisponibilidade(false);
        int i26 = motorista6.compareTo((Ator) motorista10);
        try {
            boolean b27 = motorista0.equals((java.lang.Object) motorista6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(d1 == 0.0d);
        org.junit.Assert.assertNull(veiculo7);
        org.junit.Assert.assertTrue(d8 == 0.0d);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertNull(veiculo11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(i16 == 1);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue(i18 == 10);
        org.junit.Assert.assertTrue(d21 == 0.0d);
        org.junit.Assert.assertTrue(i26 == 0);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.getPassword();
        java.lang.String str2 = motorista0.getMorada();
        double d3 = motorista0.getKmsTotais();
        Coordenada coordenada4 = null;
        try {
            motorista0.atualizaDados(coordenada4, (double) 10, (double) (byte) 10, (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(d3 == 0.0d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getClassificacao();
        java.lang.String str7 = motorista0.getNome();
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 10);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        double d4 = motorista0.totalFaturado(gregorianCalendar2, gregorianCalendar3);
        java.lang.Object obj5 = null;
        boolean b6 = motorista0.equals(obj5);
        int i7 = motorista0.getGrau();
        try {
            Motorista motorista8 = motorista0.clone();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(d4 == 0.0d);
        org.junit.Assert.assertTrue(b6 == false);
        org.junit.Assert.assertTrue(i7 == 0);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "", "E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
        Coordenada coordenada7 = null;
        try {
            motorista6.atualizaDados(coordenada7, (double) (byte) -1, (double) (-230), (double) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        java.lang.String str4 = motorista0.getDataDeNascimento();
        java.util.Set<Viagem> set_viagem5 = motorista0.getHistorico();
        java.lang.String str6 = motorista0.getNome();
        Veiculo veiculo12 = null;
        Motorista motorista13 = new Motorista("", "", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo12);
        int i14 = motorista0.compareTo(motorista13);
        try {
            double d16 = motorista0.tempoViagem((double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(set_viagem5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue(i14 == (-229));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        boolean b3 = motorista0.equals((java.lang.Object) (byte) 10);
        int i4 = motorista0.getGrau();
        java.lang.String str5 = motorista0.getNome();
        int i6 = motorista0.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar7 = null;
        java.util.GregorianCalendar gregorianCalendar8 = null;
        double d9 = motorista0.totalFaturado(gregorianCalendar7, gregorianCalendar8);
        java.lang.String str10 = motorista0.getMorada();
        boolean b12 = motorista0.equals((java.lang.Object) 100.0f);
        try {
            double d14 = motorista0.tempoViagem((double) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue(b12 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "hi!", "hi!", veiculo5);
        motorista6.atualizaClassificacao(100);
        motorista6.atualizaClassificacao((int) (short) 1);
        java.lang.String str11 = motorista6.toString();
        motorista6.setDisponibilidade(false);
        java.util.GregorianCalendar gregorianCalendar14 = null;
        java.util.GregorianCalendar gregorianCalendar15 = null;
        try {
            java.util.List<Viagem> list_viagem16 = motorista6.viagensEntreDatas(gregorianCalendar14, gregorianCalendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "E-mail: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nNome: hi!\nPassword: hi!\nMorada: hi!\nData de nascimento: hi!\nGrau de cumprimento de horário: 100\nClassificação do motorista: 50\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str11.equals("E-mail: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nNome: hi!\nPassword: hi!\nMorada: hi!\nData de nascimento: hi!\nGrau de cumprimento de horário: 100\nClassificação do motorista: 50\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nNome: hi!\nPassword: hi!\nMorada: hi!\nData de nascimento: hi!\nGrau de cumprimento de horário: 100\nClassificação do motorista: 50\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", veiculo5);
        motorista6.atualizaClassificacao(0);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
        java.util.Set<Viagem> set_viagem7 = motorista6.getHistorico();
        java.lang.String str8 = motorista6.toString();
        double d9 = motorista6.totalFaturado();
        double d10 = motorista6.totalFaturado();
        try {
            Motorista motorista11 = motorista6.clone();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(set_viagem7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "E-mail: \nNome: \nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nData de nascimento: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str8.equals("E-mail: \nNome: \nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nData de nascimento: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue(d10 == 0.0d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("hi!", "hi!", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", veiculo5);
        int i7 = motorista6.getNumClassi();
        java.lang.String str8 = motorista6.getMail();
        Motorista motorista9 = new Motorista();
        Veiculo veiculo10 = motorista9.getVeiculo();
        java.lang.String str11 = motorista9.getMail();
        int i12 = motorista9.getNumClassi();
        motorista9.atualizaClassificacao((int) (byte) 10);
        int i15 = motorista9.getNumClassi();
        int i16 = motorista6.compareTo((Ator) motorista9);
        try {
            double d18 = motorista9.tempoViagem((double) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertNull(veiculo10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertTrue(i15 == 1);
        org.junit.Assert.assertTrue(i16 == 3);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        Motorista motorista0 = new Motorista();
        double d1 = motorista0.totalFaturado();
        int i2 = motorista0.getGrau();
        boolean b3 = motorista0.getDisponibilidade();
        int i4 = motorista0.getClassificacao();
        java.lang.String str5 = motorista0.getPassword();
        org.junit.Assert.assertTrue(d1 == 0.0d);
        org.junit.Assert.assertTrue(i2 == 0);
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        java.lang.String str9 = motorista0.getMail();
        Coordenada coordenada10 = null;
        try {
            motorista0.atualizaDados(coordenada10, (double) 0.0f, (double) (-229), (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 10);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        Motorista motorista5 = new Motorista();
        double d6 = motorista5.totalFaturado();
        boolean b7 = motorista5.getDisponibilidade();
        java.util.Set<Viagem> set_viagem8 = motorista5.getHistorico();
        Veiculo veiculo14 = null;
        try {
            Motorista motorista15 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: \nMorada: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nData de nascimento: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", set_viagem8, 100, (int) (short) 10, (int) 'a', (double) 230, false, veiculo14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(b7 == false);
        org.junit.Assert.assertNotNull(set_viagem8);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        boolean b3 = motorista0.equals((java.lang.Object) (byte) 10);
        java.util.GregorianCalendar gregorianCalendar4 = null;
        java.util.GregorianCalendar gregorianCalendar5 = null;
        double d6 = motorista0.totalFaturado(gregorianCalendar4, gregorianCalendar5);
        motorista0.atualizaClassificacao((int) (short) 100);
        motorista0.atualizaClassificacao(3);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.getPassword();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        double d4 = motorista0.totalFaturado(gregorianCalendar2, gregorianCalendar3);
        double d5 = motorista0.getKmsTotais();
        java.util.GregorianCalendar gregorianCalendar6 = null;
        java.util.GregorianCalendar gregorianCalendar7 = null;
        double d8 = motorista0.totalFaturado(gregorianCalendar6, gregorianCalendar7);
        java.lang.String str9 = motorista0.getNome();
        double d10 = motorista0.getKmsTotais();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertTrue(d4 == 0.0d);
        org.junit.Assert.assertTrue(d5 == 0.0d);
        org.junit.Assert.assertTrue(d8 == 0.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue(d10 == 0.0d);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        Veiculo veiculo2 = motorista0.getVeiculo();
        java.lang.String str3 = motorista0.toString();
        int i4 = motorista0.getGrau();
        Viagem viagem5 = null;
        try {
            motorista0.registaViagem(viagem5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNull(veiculo2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str3.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(i4 == 0);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        Veiculo veiculo2 = motorista0.getVeiculo();
        java.lang.String str3 = motorista0.getPassword();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNull(veiculo2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.setDisponibilidade(false);
        java.lang.String str6 = motorista0.getMorada();
        double d7 = motorista0.totalFaturado();
        java.util.GregorianCalendar gregorianCalendar8 = null;
        java.util.GregorianCalendar gregorianCalendar9 = null;
        double d10 = motorista0.totalFaturado(gregorianCalendar8, gregorianCalendar9);
        Viagem viagem11 = null;
        try {
            motorista0.registaViagem(viagem11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue(d7 == 0.0d);
        org.junit.Assert.assertTrue(d10 == 0.0d);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        java.lang.String str4 = motorista0.getDataDeNascimento();
        java.util.Set<Viagem> set_viagem5 = motorista0.getHistorico();
        java.lang.String str6 = motorista0.getPassword();
        Veiculo veiculo7 = null;
        motorista0.setVeiculo(veiculo7);
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(set_viagem5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        boolean b3 = motorista0.equals((java.lang.Object) (byte) 10);
        java.util.GregorianCalendar gregorianCalendar4 = null;
        java.util.GregorianCalendar gregorianCalendar5 = null;
        double d6 = motorista0.totalFaturado(gregorianCalendar4, gregorianCalendar5);
        int i7 = motorista0.getClassificacao();
        motorista0.setDisponibilidade(false);
        try {
            double d11 = motorista0.tempoViagem((double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(i7 == 0);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", veiculo5);
        double d7 = motorista6.totalFaturado();
        Veiculo veiculo8 = motorista6.getVeiculo();
        Motorista motorista9 = new Motorista();
        int i10 = motorista9.getGrau();
        boolean b12 = motorista9.equals((java.lang.Object) (byte) 10);
        java.util.Set<Viagem> set_viagem13 = motorista9.getHistorico();
        Veiculo veiculo14 = null;
        motorista9.setVeiculo(veiculo14);
        int i16 = motorista6.compareTo(motorista9);
        try {
            double d18 = motorista6.precoViagem(0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(d7 == 0.0d);
        org.junit.Assert.assertNull(veiculo8);
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertTrue(i16 == 3);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
        java.lang.String str7 = motorista6.getPassword();
        java.util.Set<Viagem> set_viagem8 = motorista6.getHistorico();
        double d9 = motorista6.totalFaturado();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(set_viagem8);
        org.junit.Assert.assertTrue(d9 == 0.0d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        motorista0.atualizaClassificacao(0);
        java.lang.String str8 = motorista0.getMorada();
        java.lang.String str9 = motorista0.toString();
        Coordenada coordenada10 = null;
        try {
            motorista0.atualizaDados(coordenada10, 10.0d, (double) (-3), 100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str9.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "hi!", "", "", "", veiculo5);
        java.lang.String str7 = motorista6.getMorada();
        int i8 = motorista6.getGrau();
        Coordenada coordenada9 = null;
        try {
            motorista6.atualizaDados(coordenada9, (double) (-230), (double) (short) 100, (double) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 100);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        boolean b3 = motorista0.getDisponibilidade();
        int i4 = motorista0.getNumClassi();
        java.lang.String str5 = motorista0.getPassword();
        Veiculo veiculo6 = null;
        motorista0.setVeiculo(veiculo6);
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        boolean b3 = motorista0.getDisponibilidade();
        boolean b4 = motorista0.getDisponibilidade();
        int i5 = motorista0.getGrau();
        Viagem viagem6 = null;
        try {
            motorista0.registaViagem(viagem6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(i5 == 0);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        Motorista motorista0 = new Motorista();
        double d1 = motorista0.totalFaturado();
        motorista0.setDisponibilidade(false);
        int i4 = motorista0.getNumClassi();
        java.lang.String str5 = motorista0.getMorada();
        motorista0.atualizaClassificacao((int) (short) 100);
        boolean b8 = motorista0.getDisponibilidade();
        Veiculo veiculo9 = null;
        motorista0.setVeiculo(veiculo9);
        org.junit.Assert.assertTrue(d1 == 0.0d);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue(b8 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        Veiculo veiculo2 = motorista0.getVeiculo();
        java.lang.String str3 = motorista0.toString();
        int i4 = motorista0.getGrau();
        java.lang.String str5 = motorista0.getMail();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNull(veiculo2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str3.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
        java.lang.String str7 = motorista6.getPassword();
        boolean b8 = motorista6.getDisponibilidade();
        try {
            motorista6.atualizaClassificacao((-3));
            org.junit.Assert.fail("Expected exception of type ValueOutOfBoundsException");
        } catch (ValueOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(b8 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", veiculo5);
        java.util.GregorianCalendar gregorianCalendar7 = null;
        java.util.GregorianCalendar gregorianCalendar8 = null;
        double d9 = motorista6.totalFaturado(gregorianCalendar7, gregorianCalendar8);
        int i10 = motorista6.getNumClassi();
        int i11 = motorista6.getGrau();
        java.lang.String str12 = motorista6.getDataDeNascimento();
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i11 == 100);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        int i2 = motorista0.getNumClassi();
        java.lang.String str3 = motorista0.getNome();
        java.lang.String str4 = motorista0.toString();
        double d5 = motorista0.getKmsTotais();
        Veiculo veiculo6 = null;
        motorista0.setVeiculo(veiculo6);
        java.lang.String str8 = motorista0.getMorada();
        Motorista motorista9 = new Motorista();
        double d10 = motorista9.totalFaturado();
        try {
            boolean b11 = motorista0.equals((java.lang.Object) motorista9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(i2 == 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str4.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(d5 == 0.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue(d10 == 0.0d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        int i2 = motorista0.getNumClassi();
        java.lang.String str3 = motorista0.getNome();
        java.lang.String str4 = motorista0.toString();
        double d5 = motorista0.getKmsTotais();
        try {
            Viagem viagem6 = motorista0.maiorDesvio();
            org.junit.Assert.fail("Expected exception of type NenhumaViagemException");
        } catch (NenhumaViagemException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(i2 == 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str4.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(d5 == 0.0d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        int i2 = motorista0.getNumClassi();
        java.lang.String str3 = motorista0.getDataDeNascimento();
        Veiculo veiculo4 = null;
        motorista0.setVeiculo(veiculo4);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(i2 == 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nNome: hi!\nPassword: hi!\nMorada: hi!\nData de nascimento: hi!\nGrau de cumprimento de horário: 100\nClassificação do motorista: 50\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", "E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: true\n", veiculo5);
        Viagem viagem7 = null;
        try {
            motorista6.registaViagem(viagem7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.lang.String str2 = motorista0.getMail();
        java.lang.String str3 = motorista0.getMail();
        Veiculo veiculo4 = motorista0.getVeiculo();
        Veiculo veiculo5 = null;
        motorista0.setVeiculo(veiculo5);
        Veiculo veiculo7 = null;
        motorista0.setVeiculo(veiculo7);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNull(veiculo4);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        double d9 = motorista0.totalFaturado();
        java.util.GregorianCalendar gregorianCalendar10 = null;
        java.util.GregorianCalendar gregorianCalendar11 = null;
        double d12 = motorista0.totalFaturado(gregorianCalendar10, gregorianCalendar11);
        java.util.Set<Viagem> set_viagem13 = motorista0.getHistorico();
        java.lang.String str14 = motorista0.getPassword();
        int i15 = motorista0.getGrau();
        Veiculo veiculo16 = null;
        motorista0.setVeiculo(veiculo16);
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 10);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue(d12 == 0.0d);
        org.junit.Assert.assertNotNull(set_viagem13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue(i15 == 0);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", "", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: true\n", "E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
        int i7 = motorista6.getClassificacao();
        java.util.GregorianCalendar gregorianCalendar8 = null;
        java.util.GregorianCalendar gregorianCalendar9 = null;
        try {
            java.util.List<Viagem> list_viagem10 = motorista6.viagensEntreDatas(gregorianCalendar8, gregorianCalendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i7 == 100);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "hi!", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", veiculo5);
        Motorista motorista7 = new Motorista();
        Veiculo veiculo8 = motorista7.getVeiculo();
        java.lang.String str9 = motorista7.getMail();
        int i10 = motorista7.getNumClassi();
        java.lang.String str11 = motorista7.getDataDeNascimento();
        int i12 = motorista6.compareTo((Ator) motorista7);
        try {
            Motorista motorista13 = new Motorista(motorista7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue(i12 == 3);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: true\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", veiculo5);
        motorista6.setDisponibilidade(false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        Veiculo veiculo6 = motorista0.getVeiculo();
        java.lang.String str7 = motorista0.getMorada();
        double d8 = motorista0.totalFaturado();
        java.lang.String str9 = motorista0.getMail();
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertNull(veiculo6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(d8 == 0.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        Veiculo veiculo2 = motorista0.getVeiculo();
        java.lang.String str3 = motorista0.toString();
        int i4 = motorista0.getNumClassi();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNull(veiculo2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str3.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(i4 == 0);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", veiculo5);
        double d7 = motorista6.totalFaturado();
        Motorista motorista8 = new Motorista();
        int i9 = motorista8.getGrau();
        Veiculo veiculo10 = motorista8.getVeiculo();
        double d11 = motorista8.getKmsTotais();
        motorista8.setDisponibilidade(true);
        java.lang.String str14 = motorista8.getPassword();
        boolean b15 = motorista8.getDisponibilidade();
        int i16 = motorista6.compareTo((Ator) motorista8);
        java.util.GregorianCalendar gregorianCalendar17 = null;
        java.util.GregorianCalendar gregorianCalendar18 = null;
        try {
            java.util.List<Viagem> list_viagem19 = motorista8.viagensEntreDatas(gregorianCalendar17, gregorianCalendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(d7 == 0.0d);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertNull(veiculo10);
        org.junit.Assert.assertTrue(d11 == 0.0d);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue(b15 == true);
        org.junit.Assert.assertTrue(i16 == 3);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        double d4 = motorista0.totalFaturado(gregorianCalendar2, gregorianCalendar3);
        double d5 = motorista0.getKmsTotais();
        motorista0.setDisponibilidade(true);
        int i8 = motorista0.getClassificacao();
        try {
            Motorista motorista9 = motorista0.clone();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(d4 == 0.0d);
        org.junit.Assert.assertTrue(d5 == 0.0d);
        org.junit.Assert.assertTrue(i8 == 0);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        motorista0.setDisponibilidade(true);
        java.util.GregorianCalendar gregorianCalendar11 = null;
        java.util.GregorianCalendar gregorianCalendar12 = null;
        double d13 = motorista0.totalFaturado(gregorianCalendar11, gregorianCalendar12);
        java.util.GregorianCalendar gregorianCalendar14 = null;
        java.util.GregorianCalendar gregorianCalendar15 = null;
        try {
            java.util.List<Viagem> list_viagem16 = motorista0.viagensEntreDatas(gregorianCalendar14, gregorianCalendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 10);
        org.junit.Assert.assertTrue(d13 == 0.0d);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        Veiculo veiculo7 = motorista0.getVeiculo();
        Motorista motorista8 = new Motorista();
        Veiculo veiculo9 = motorista8.getVeiculo();
        java.lang.String str10 = motorista8.getMail();
        int i11 = motorista0.compareTo((Ator) motorista8);
        Motorista motorista12 = new Motorista();
        Veiculo veiculo13 = motorista12.getVeiculo();
        java.lang.String str14 = motorista12.getMail();
        int i15 = motorista12.getNumClassi();
        motorista12.atualizaClassificacao((int) (byte) 10);
        int i18 = motorista12.getNumClassi();
        java.lang.String str19 = motorista12.getNome();
        int i20 = motorista12.getClassificacao();
        java.util.GregorianCalendar gregorianCalendar21 = null;
        java.util.GregorianCalendar gregorianCalendar22 = null;
        double d23 = motorista12.totalFaturado(gregorianCalendar21, gregorianCalendar22);
        Veiculo veiculo29 = null;
        Motorista motorista30 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "", veiculo29);
        int i31 = motorista30.getGrau();
        int i32 = motorista12.compareTo((Ator) motorista30);
        try {
            boolean b33 = motorista8.equals((java.lang.Object) motorista12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertNull(veiculo7);
        org.junit.Assert.assertNull(veiculo9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertNull(veiculo13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue(i15 == 0);
        org.junit.Assert.assertTrue(i18 == 1);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue(i20 == 10);
        org.junit.Assert.assertTrue(d23 == 0.0d);
        org.junit.Assert.assertTrue(i31 == 100);
        org.junit.Assert.assertTrue(i32 == (-230));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
        java.lang.String str7 = motorista6.getPassword();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str7.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nNome: hi!\nPassword: hi!\nMorada: hi!\nData de nascimento: hi!\nGrau de cumprimento de horário: 100\nClassificação do motorista: 50\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", veiculo5);
        Motorista motorista7 = null;
        try {
            int i8 = motorista6.compareTo(motorista7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.getPassword();
        Veiculo veiculo2 = null;
        motorista0.setVeiculo(veiculo2);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: true\n", "hi!", "", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", veiculo5);
        int i7 = motorista6.getNumClassi();
        org.junit.Assert.assertTrue(i7 == 0);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "hi!", "hi!", veiculo5);
        motorista6.atualizaClassificacao(100);
        motorista6.atualizaClassificacao((int) (short) 1);
        java.lang.String str11 = motorista6.toString();
        double d12 = motorista6.totalFaturado();
        java.lang.String str13 = motorista6.getNome();
        Motorista motorista14 = new Motorista();
        Veiculo veiculo15 = motorista14.getVeiculo();
        java.lang.String str16 = motorista14.getMail();
        int i17 = motorista14.getNumClassi();
        motorista14.atualizaClassificacao((int) (byte) 10);
        motorista14.atualizaClassificacao(0);
        double d22 = motorista14.getKmsTotais();
        int i23 = motorista6.compareTo((Ator) motorista14);
        Motorista motorista24 = new Motorista();
        Veiculo veiculo25 = motorista24.getVeiculo();
        java.lang.String str26 = motorista24.getMail();
        int i27 = motorista24.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar28 = null;
        java.util.GregorianCalendar gregorianCalendar29 = null;
        double d30 = motorista24.totalFaturado(gregorianCalendar28, gregorianCalendar29);
        java.lang.Object obj31 = null;
        boolean b32 = motorista24.equals(obj31);
        java.lang.String str33 = motorista24.getMail();
        java.util.Set<Viagem> set_viagem34 = motorista24.getHistorico();
        try {
            boolean b35 = motorista14.equals((java.lang.Object) motorista24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "E-mail: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nNome: hi!\nPassword: hi!\nMorada: hi!\nData de nascimento: hi!\nGrau de cumprimento de horário: 100\nClassificação do motorista: 50\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str11.equals("E-mail: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nNome: hi!\nPassword: hi!\nMorada: hi!\nData de nascimento: hi!\nGrau de cumprimento de horário: 100\nClassificação do motorista: 50\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(d12 == 0.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertNull(veiculo15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue(i17 == 0);
        org.junit.Assert.assertTrue(d22 == 0.0d);
        org.junit.Assert.assertTrue(i23 == 230);
        org.junit.Assert.assertNull(veiculo25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertTrue(i27 == 0);
        org.junit.Assert.assertTrue(d30 == 0.0d);
        org.junit.Assert.assertTrue(b32 == false);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
        org.junit.Assert.assertNotNull(set_viagem34);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        motorista0.setDisponibilidade(true);
        Veiculo veiculo11 = null;
        motorista0.setVeiculo(veiculo11);
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 10);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.getPassword();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        double d4 = motorista0.totalFaturado(gregorianCalendar2, gregorianCalendar3);
        java.lang.String str5 = motorista0.getPassword();
        java.lang.String str6 = motorista0.getPassword();
        int i7 = motorista0.getClassificacao();
        try {
            Motorista motorista8 = motorista0.clone();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertTrue(d4 == 0.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue(i7 == 0);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", veiculo5);
        java.lang.String str7 = motorista6.getPassword();
        motorista6.atualizaClassificacao((int) '#');
        try {
            double d11 = motorista6.tempoViagem((double) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str7.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        Motorista motorista0 = new Motorista();
        double d1 = motorista0.totalFaturado();
        motorista0.setDisponibilidade(false);
        double d4 = motorista0.totalFaturado();
        motorista0.atualizaClassificacao((int) '4');
        Veiculo veiculo7 = null;
        motorista0.setVeiculo(veiculo7);
        org.junit.Assert.assertTrue(d1 == 0.0d);
        org.junit.Assert.assertTrue(d4 == 0.0d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        Motorista motorista5 = new Motorista();
        Veiculo veiculo6 = motorista5.getVeiculo();
        java.lang.String str7 = motorista5.getMail();
        java.lang.String str8 = motorista5.getDataDeNascimento();
        java.util.Set<Viagem> set_viagem9 = motorista5.getHistorico();
        java.util.Set<Viagem> set_viagem10 = motorista5.getHistorico();
        Veiculo veiculo16 = null;
        try {
            Motorista motorista17 = new Motorista("E-mail: hi!\nNome: hi!\nPassword: hi!\nMorada: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nNome: hi!\nPassword: hi!\nMorada: hi!\nData de nascimento: hi!\nGrau de cumprimento de horário: 100\nClassificação do motorista: 50\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "E-mail: hi!\nNome: hi!\nPassword: hi!\nMorada: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", set_viagem10, (int) '#', (int) (byte) 1, (int) (byte) -1, (double) 229, false, veiculo16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(set_viagem9);
        org.junit.Assert.assertNotNull(set_viagem10);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        java.lang.String str4 = motorista0.getDataDeNascimento();
        java.util.Set<Viagem> set_viagem5 = motorista0.getHistorico();
        java.lang.String str6 = motorista0.getPassword();
        boolean b7 = motorista0.getDisponibilidade();
        Veiculo veiculo13 = null;
        Motorista motorista14 = new Motorista("hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "", veiculo13);
        int i15 = motorista14.getGrau();
        int i16 = motorista0.compareTo((Ator) motorista14);
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(set_viagem5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue(b7 == false);
        org.junit.Assert.assertTrue(i15 == 100);
        org.junit.Assert.assertTrue(i16 == (-3));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: hi!\nNome: hi!\nPassword: hi!\nMorada: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nNome: hi!\nPassword: hi!\nMorada: hi!\nData de nascimento: hi!\nGrau de cumprimento de horário: 100\nClassificação do motorista: 50\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nNome: hi!\nPassword: hi!\nMorada: hi!\nData de nascimento: hi!\nGrau de cumprimento de horário: 100\nClassificação do motorista: 50\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
        Veiculo veiculo7 = null;
        motorista6.setVeiculo(veiculo7);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "", "E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
        java.lang.String str7 = motorista6.toString();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "E-mail: E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nNome: hi!\nPassword: \nMorada: E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nData de nascimento: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str7.equals("E-mail: E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nNome: hi!\nPassword: \nMorada: E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nData de nascimento: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        Motorista motorista0 = new Motorista();
        double d1 = motorista0.totalFaturado();
        boolean b2 = motorista0.getDisponibilidade();
        java.util.Set<Viagem> set_viagem3 = motorista0.getHistorico();
        java.util.Set<Viagem> set_viagem4 = motorista0.getHistorico();
        java.lang.String str5 = motorista0.getMail();
        java.util.GregorianCalendar gregorianCalendar6 = null;
        java.util.GregorianCalendar gregorianCalendar7 = null;
        try {
            java.util.List<Viagem> list_viagem8 = motorista0.viagensEntreDatas(gregorianCalendar6, gregorianCalendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(d1 == 0.0d);
        org.junit.Assert.assertTrue(b2 == false);
        org.junit.Assert.assertNotNull(set_viagem3);
        org.junit.Assert.assertNotNull(set_viagem4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "", "", veiculo5);
        int i7 = motorista6.getNumClassi();
        java.util.Set<Viagem> set_viagem8 = motorista6.getHistorico();
        java.lang.String str9 = motorista6.getPassword();
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertNotNull(set_viagem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        java.util.GregorianCalendar gregorianCalendar9 = null;
        java.util.GregorianCalendar gregorianCalendar10 = null;
        double d11 = motorista0.totalFaturado(gregorianCalendar9, gregorianCalendar10);
        java.lang.String str12 = motorista0.toString();
        java.lang.String str13 = motorista0.getMorada();
        java.lang.String str14 = motorista0.getMail();
        java.lang.String str15 = motorista0.toString();
        motorista0.setDisponibilidade(false);
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 10);
        org.junit.Assert.assertTrue(d11 == 0.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str12.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str15.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        double d4 = motorista0.totalFaturado(gregorianCalendar2, gregorianCalendar3);
        double d5 = motorista0.getKmsTotais();
        motorista0.setDisponibilidade(true);
        java.lang.String str8 = motorista0.getMorada();
        int i9 = motorista0.getGrau();
        Coordenada coordenada10 = null;
        try {
            motorista0.atualizaDados(coordenada10, (double) 10, (double) 0L, (double) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n" + "'", str1.equals("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n"));
        org.junit.Assert.assertTrue(d4 == 0.0d);
        org.junit.Assert.assertTrue(d5 == 0.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue(i9 == 0);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.getPassword();
        motorista0.atualizaClassificacao(100);
        java.util.GregorianCalendar gregorianCalendar4 = null;
        java.util.GregorianCalendar gregorianCalendar5 = null;
        double d6 = motorista0.totalFaturado(gregorianCalendar4, gregorianCalendar5);
        Coordenada coordenada7 = null;
        try {
            motorista0.atualizaDados(coordenada7, (double) 3, (double) 1, (double) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertTrue(d6 == 0.0d);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        motorista0.setDisponibilidade(true);
        int i11 = motorista0.getClassificacao();
        Veiculo veiculo17 = null;
        Motorista motorista18 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: true\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", veiculo17);
        int i19 = motorista0.compareTo((Ator) motorista18);
        try {
            Motorista motorista20 = new Motorista(motorista0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(veiculo1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i6 == 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 10);
        org.junit.Assert.assertTrue(i11 == 10);
        org.junit.Assert.assertTrue(i19 == (-229));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", veiculo5);
        java.util.GregorianCalendar gregorianCalendar7 = null;
        java.util.GregorianCalendar gregorianCalendar8 = null;
        double d9 = motorista6.totalFaturado(gregorianCalendar7, gregorianCalendar8);
        int i10 = motorista6.getNumClassi();
        java.lang.String str11 = motorista6.getMorada();
        try {
            double d13 = motorista6.precoViagem(10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nNome: hi!\nPassword: \nMorada: E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nData de nascimento: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: true\n", "E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.getPassword();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        double d4 = motorista0.totalFaturado(gregorianCalendar2, gregorianCalendar3);
        java.lang.String str5 = motorista0.getMail();
        java.util.GregorianCalendar gregorianCalendar6 = null;
        java.util.GregorianCalendar gregorianCalendar7 = null;
        double d8 = motorista0.totalFaturado(gregorianCalendar6, gregorianCalendar7);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
        org.junit.Assert.assertTrue(d4 == 0.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue(d8 == 0.0d);
    }
}

