import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ErrorTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test001");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        Motorista motorista2 = motorista0.clone();
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test002");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        boolean b3 = motorista0.equals((java.lang.Object) (byte) 10);
        Motorista motorista4 = new Motorista();
        int i5 = motorista4.getGrau();
        boolean b7 = motorista4.equals((java.lang.Object) (byte) 10);
        int i8 = motorista0.compareTo((Ator) motorista4);
        Veiculo veiculo9 = null;
        motorista4.setVeiculo(veiculo9);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test003");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        double d3 = motorista0.tempoViagem((double) 10);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test004");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        boolean b3 = motorista0.equals((java.lang.Object) (byte) 10);
        Motorista motorista4 = motorista0.clone();
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test005");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        Motorista motorista2 = new Motorista();
        Veiculo veiculo3 = motorista2.getVeiculo();
        java.lang.String str4 = motorista2.getMail();
        int i5 = motorista0.compareTo((Ator) motorista2);
        java.util.GregorianCalendar gregorianCalendar6 = null;
        java.util.GregorianCalendar gregorianCalendar7 = null;
        double d8 = motorista2.totalFaturado(gregorianCalendar6, gregorianCalendar7);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test006");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        boolean b3 = motorista0.equals((java.lang.Object) (byte) 10);
        Motorista motorista4 = new Motorista();
        int i5 = motorista4.getGrau();
        boolean b7 = motorista4.equals((java.lang.Object) (byte) 10);
        int i8 = motorista0.compareTo((Ator) motorista4);
        int i9 = motorista4.getNumClassi();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test007");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        Motorista motorista2 = new Motorista();
        Veiculo veiculo3 = motorista2.getVeiculo();
        java.lang.String str4 = motorista2.getMail();
        int i5 = motorista0.compareTo((Ator) motorista2);
        double d7 = motorista0.precoViagem((double) (byte) 1);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test008");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        Motorista motorista2 = new Motorista();
        int i3 = motorista2.getGrau();
        boolean b5 = motorista2.equals((java.lang.Object) (byte) 10);
        Motorista motorista6 = new Motorista();
        int i7 = motorista6.getGrau();
        boolean b9 = motorista6.equals((java.lang.Object) (byte) 10);
        int i10 = motorista2.compareTo((Ator) motorista6);
        int i11 = motorista0.compareTo((Ator) motorista6);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista2 and motorista2", motorista2.equals(motorista2) ? motorista2.hashCode() == motorista2.hashCode() : true);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test009");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        boolean b3 = motorista0.equals((java.lang.Object) (byte) 10);
        Motorista motorista4 = new Motorista();
        int i5 = motorista4.getGrau();
        boolean b7 = motorista4.equals((java.lang.Object) (byte) 10);
        int i8 = motorista0.compareTo((Ator) motorista4);
        int i9 = motorista0.getGrau();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista4 and motorista4", motorista4.equals(motorista4) ? motorista4.hashCode() == motorista4.hashCode() : true);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test010");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        boolean b3 = motorista0.equals((java.lang.Object) (byte) 10);
        Motorista motorista4 = new Motorista();
        int i5 = motorista4.getGrau();
        boolean b7 = motorista4.equals((java.lang.Object) (byte) 10);
        int i8 = motorista0.compareTo((Ator) motorista4);
        double d10 = motorista0.tempoViagem(100.0d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test011");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        Motorista motorista4 = new Motorista();
        int i5 = motorista0.compareTo(motorista4);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test012");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        Motorista motorista2 = new Motorista();
        Veiculo veiculo3 = motorista2.getVeiculo();
        int i4 = motorista0.compareTo(motorista2);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test013");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        boolean b3 = motorista0.equals((java.lang.Object) (byte) 10);
        Motorista motorista4 = new Motorista();
        int i5 = motorista4.getGrau();
        boolean b7 = motorista4.equals((java.lang.Object) (byte) 10);
        int i8 = motorista0.compareTo((Ator) motorista4);
        Motorista motorista9 = motorista4.clone();
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test014");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        Motorista motorista2 = new Motorista();
        Veiculo veiculo3 = motorista2.getVeiculo();
        java.lang.String str4 = motorista2.getMail();
        int i5 = motorista0.compareTo((Ator) motorista2);
        double d7 = motorista2.precoViagem((double) (short) 1);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test015");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        Motorista motorista2 = new Motorista();
        Veiculo veiculo3 = motorista2.getVeiculo();
        java.lang.String str4 = motorista2.getMail();
        int i5 = motorista0.compareTo((Ator) motorista2);
        Veiculo veiculo6 = motorista2.getVeiculo();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test016");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        Motorista motorista2 = new Motorista();
        Veiculo veiculo3 = motorista2.getVeiculo();
        java.lang.String str4 = motorista2.getMail();
        int i5 = motorista2.getNumClassi();
        boolean b6 = motorista0.equals((java.lang.Object) i5);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista2 and motorista2", motorista2.equals(motorista2) ? motorista2.hashCode() == motorista2.hashCode() : true);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test017");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        Motorista motorista2 = new Motorista(motorista0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test018");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.getPassword();
        Motorista motorista2 = motorista0.clone();
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test019");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        boolean b3 = motorista0.equals((java.lang.Object) (byte) 10);
        Motorista motorista4 = new Motorista();
        int i5 = motorista4.getGrau();
        boolean b7 = motorista4.equals((java.lang.Object) (byte) 10);
        int i8 = motorista0.compareTo((Ator) motorista4);
        boolean b10 = motorista4.equals((java.lang.Object) "hi!");
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test020");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        motorista0.atualizaClassificacao(0);
        double d9 = motorista0.tempoViagem((double) 100.0f);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test021");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        motorista0.atualizaClassificacao(0);
        double d8 = motorista0.getKmsTotais();
        Motorista motorista9 = motorista0.clone();
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test022");
        Motorista motorista0 = new Motorista();
        double d1 = motorista0.totalFaturado();
        Motorista motorista2 = new Motorista(motorista0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test023");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        java.lang.String str3 = motorista0.getDataDeNascimento();
        double d5 = motorista0.precoViagem((double) 1);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test024");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        boolean b3 = motorista0.getDisponibilidade();
        Motorista motorista4 = new Motorista();
        int i5 = motorista4.getGrau();
        int i6 = motorista0.compareTo(motorista4);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test025");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        Motorista motorista2 = new Motorista();
        Veiculo veiculo3 = motorista2.getVeiculo();
        java.lang.String str4 = motorista2.getMail();
        int i5 = motorista0.compareTo((Ator) motorista2);
        double d6 = motorista0.totalFaturado();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista2 and motorista2", motorista2.equals(motorista2) ? motorista2.hashCode() == motorista2.hashCode() : true);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test026");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        Motorista motorista7 = new Motorista(motorista0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test027");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        double d5 = motorista0.tempoViagem((double) 1);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test028");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        Motorista motorista2 = new Motorista();
        Veiculo veiculo3 = motorista2.getVeiculo();
        java.lang.String str4 = motorista2.getMail();
        int i5 = motorista0.compareTo((Ator) motorista2);
        int i6 = motorista2.getGrau();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test029");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        boolean b3 = motorista0.equals((java.lang.Object) (byte) 10);
        Motorista motorista4 = new Motorista();
        int i5 = motorista4.getGrau();
        boolean b7 = motorista4.equals((java.lang.Object) (byte) 10);
        int i8 = motorista0.compareTo((Ator) motorista4);
        java.lang.String str9 = motorista4.toString();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test030");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        Motorista motorista3 = new Motorista();
        java.lang.String str4 = motorista3.toString();
        java.lang.String str5 = motorista3.getMail();
        int i6 = motorista0.compareTo((Ator) motorista3);
        Veiculo veiculo7 = null;
        motorista0.setVeiculo(veiculo7);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista3 and motorista3", motorista3.equals(motorista3) ? motorista3.hashCode() == motorista3.hashCode() : true);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test031");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        Motorista motorista3 = new Motorista();
        java.lang.String str4 = motorista3.toString();
        java.lang.String str5 = motorista3.getMail();
        int i6 = motorista0.compareTo((Ator) motorista3);
        Motorista motorista7 = new Motorista();
        int i8 = motorista7.getGrau();
        Veiculo veiculo9 = motorista7.getVeiculo();
        java.lang.String str10 = motorista7.getDataDeNascimento();
        int i11 = motorista3.compareTo((Ator) motorista7);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test032");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        Motorista motorista2 = new Motorista();
        Veiculo veiculo3 = motorista2.getVeiculo();
        java.lang.String str4 = motorista2.getMail();
        int i5 = motorista0.compareTo((Ator) motorista2);
        java.lang.String str6 = motorista2.getMail();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test033");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        Motorista motorista2 = new Motorista();
        Veiculo veiculo3 = motorista2.getVeiculo();
        java.lang.String str4 = motorista2.getMail();
        int i5 = motorista0.compareTo((Ator) motorista2);
        Veiculo veiculo6 = null;
        motorista0.setVeiculo(veiculo6);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista2 and motorista2", motorista2.equals(motorista2) ? motorista2.hashCode() == motorista2.hashCode() : true);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test034");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        boolean b3 = motorista0.equals((java.lang.Object) (byte) 10);
        Motorista motorista4 = new Motorista();
        int i5 = motorista4.getGrau();
        boolean b7 = motorista4.equals((java.lang.Object) (byte) 10);
        int i8 = motorista0.compareTo((Ator) motorista4);
        double d10 = motorista0.precoViagem((double) (short) 100);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test035");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        double d9 = motorista0.tempoViagem((double) '#');
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test036");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        Veiculo veiculo2 = motorista0.getVeiculo();
        java.lang.String str3 = motorista0.getDataDeNascimento();
        double d5 = motorista0.tempoViagem((double) (-1));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test037");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        boolean b3 = motorista0.equals((java.lang.Object) (byte) 10);
        Motorista motorista4 = new Motorista();
        int i5 = motorista4.getGrau();
        boolean b7 = motorista4.equals((java.lang.Object) (byte) 10);
        int i8 = motorista0.compareTo((Ator) motorista4);
        java.lang.String str9 = motorista4.getMail();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test038");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        java.lang.String str3 = motorista0.getDataDeNascimento();
        Motorista motorista4 = new Motorista();
        int i5 = motorista4.getGrau();
        boolean b7 = motorista4.equals((java.lang.Object) (byte) 10);
        Motorista motorista8 = new Motorista();
        int i9 = motorista8.getGrau();
        boolean b11 = motorista8.equals((java.lang.Object) (byte) 10);
        int i12 = motorista4.compareTo((Ator) motorista8);
        int i13 = motorista0.compareTo((Ator) motorista8);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista4 and motorista4", motorista4.equals(motorista4) ? motorista4.hashCode() == motorista4.hashCode() : true);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test039");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        boolean b3 = motorista0.equals((java.lang.Object) (byte) 10);
        Motorista motorista4 = new Motorista();
        int i5 = motorista4.getGrau();
        boolean b7 = motorista4.equals((java.lang.Object) (byte) 10);
        int i8 = motorista0.compareTo((Ator) motorista4);
        Veiculo veiculo9 = motorista0.getVeiculo();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista4 and motorista4", motorista4.equals(motorista4) ? motorista4.hashCode() == motorista4.hashCode() : true);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test040");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        Veiculo veiculo7 = motorista0.getVeiculo();
        Motorista motorista8 = new Motorista();
        Veiculo veiculo9 = motorista8.getVeiculo();
        java.lang.String str10 = motorista8.getMail();
        int i11 = motorista0.compareTo((Ator) motorista8);
        java.lang.String str12 = motorista8.getMail();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test041");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        Motorista motorista2 = new Motorista();
        Veiculo veiculo3 = motorista2.getVeiculo();
        java.lang.String str4 = motorista2.getMail();
        java.lang.String str5 = motorista2.getDataDeNascimento();
        java.util.Set<Viagem> set_viagem6 = motorista2.getHistorico();
        boolean b7 = motorista0.equals((java.lang.Object) motorista2);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test042");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        int i2 = motorista0.getNumClassi();
        Motorista motorista3 = new Motorista();
        Veiculo veiculo4 = motorista3.getVeiculo();
        java.lang.String str5 = motorista3.getMail();
        int i6 = motorista3.getNumClassi();
        motorista3.atualizaClassificacao((int) (byte) 10);
        int i9 = motorista3.getNumClassi();
        java.lang.String str10 = motorista3.getNome();
        int i11 = motorista3.getClassificacao();
        java.util.GregorianCalendar gregorianCalendar12 = null;
        java.util.GregorianCalendar gregorianCalendar13 = null;
        double d14 = motorista3.totalFaturado(gregorianCalendar12, gregorianCalendar13);
        boolean b15 = motorista0.equals((java.lang.Object) gregorianCalendar12);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista3 and motorista3", motorista3.equals(motorista3) ? motorista3.hashCode() == motorista3.hashCode() : true);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test043");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        motorista0.atualizaClassificacao(0);
        double d8 = motorista0.getKmsTotais();
        Motorista motorista9 = new Motorista();
        int i10 = motorista9.getGrau();
        boolean b12 = motorista9.equals((java.lang.Object) (byte) 10);
        int i13 = motorista0.compareTo((Ator) motorista9);
        java.util.Set<Viagem> set_viagem14 = motorista0.getHistorico();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista9 and motorista9", motorista9.equals(motorista9) ? motorista9.hashCode() == motorista9.hashCode() : true);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test044");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        double d9 = motorista0.totalFaturado();
        Motorista motorista10 = new Motorista(motorista0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test045");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.setDisponibilidade(false);
        Motorista motorista6 = motorista0.clone();
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test046");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        Motorista motorista2 = new Motorista();
        Veiculo veiculo3 = motorista2.getVeiculo();
        java.lang.String str4 = motorista2.getMail();
        int i5 = motorista0.compareTo((Ator) motorista2);
        double d6 = motorista0.getKmsTotais();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista2 and motorista2", motorista2.equals(motorista2) ? motorista2.hashCode() == motorista2.hashCode() : true);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test047");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        boolean b3 = motorista0.equals((java.lang.Object) (byte) 10);
        java.util.GregorianCalendar gregorianCalendar4 = null;
        java.util.GregorianCalendar gregorianCalendar5 = null;
        double d6 = motorista0.totalFaturado(gregorianCalendar4, gregorianCalendar5);
        Motorista motorista7 = new Motorista();
        Veiculo veiculo8 = motorista7.getVeiculo();
        java.lang.String str9 = motorista7.getMail();
        int i10 = motorista7.getNumClassi();
        motorista7.atualizaClassificacao((int) (byte) 10);
        motorista7.atualizaClassificacao(0);
        double d15 = motorista7.getKmsTotais();
        Motorista motorista16 = new Motorista();
        int i17 = motorista16.getGrau();
        boolean b19 = motorista16.equals((java.lang.Object) (byte) 10);
        int i20 = motorista7.compareTo((Ator) motorista16);
        int i21 = motorista0.compareTo((Ator) motorista16);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista7 and motorista7", motorista7.equals(motorista7) ? motorista7.hashCode() == motorista7.hashCode() : true);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test048");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        Veiculo veiculo2 = motorista0.getVeiculo();
        double d3 = motorista0.getKmsTotais();
        Motorista motorista4 = new Motorista();
        Veiculo veiculo5 = motorista4.getVeiculo();
        Motorista motorista6 = new Motorista();
        Veiculo veiculo7 = motorista6.getVeiculo();
        java.lang.String str8 = motorista6.getMail();
        int i9 = motorista4.compareTo((Ator) motorista6);
        boolean b10 = motorista0.equals((java.lang.Object) i9);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista4 and motorista4", motorista4.equals(motorista4) ? motorista4.hashCode() == motorista4.hashCode() : true);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test049");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        Veiculo veiculo7 = motorista0.getVeiculo();
        Motorista motorista8 = new Motorista();
        Veiculo veiculo9 = motorista8.getVeiculo();
        java.lang.String str10 = motorista8.getMail();
        int i11 = motorista0.compareTo((Ator) motorista8);
        Veiculo veiculo12 = null;
        motorista0.setVeiculo(veiculo12);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista8 and motorista8", motorista8.equals(motorista8) ? motorista8.hashCode() == motorista8.hashCode() : true);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test050");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        Motorista motorista3 = new Motorista();
        java.lang.String str4 = motorista3.toString();
        java.lang.String str5 = motorista3.getMail();
        int i6 = motorista0.compareTo((Ator) motorista3);
        Motorista motorista7 = new Motorista();
        java.lang.String str8 = motorista7.toString();
        java.lang.String str9 = motorista7.getMail();
        java.lang.String str10 = motorista7.getMail();
        motorista7.atualizaClassificacao((int) (byte) 1);
        int i13 = motorista0.compareTo((Ator) motorista7);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista3 and motorista3", motorista3.equals(motorista3) ? motorista3.hashCode() == motorista3.hashCode() : true);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test051");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        Veiculo veiculo2 = motorista0.getVeiculo();
        java.lang.String str3 = motorista0.toString();
        Motorista motorista4 = motorista0.clone();
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test052");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        Motorista motorista2 = new Motorista(motorista0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test053");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        boolean b3 = motorista0.equals((java.lang.Object) (byte) 10);
        Motorista motorista4 = new Motorista();
        int i5 = motorista4.getGrau();
        boolean b7 = motorista4.equals((java.lang.Object) (byte) 10);
        int i8 = motorista0.compareTo((Ator) motorista4);
        int i9 = motorista0.getClassificacao();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista4 and motorista4", motorista4.equals(motorista4) ? motorista4.hashCode() == motorista4.hashCode() : true);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test054");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        boolean b3 = motorista0.equals((java.lang.Object) (byte) 10);
        Motorista motorista4 = new Motorista();
        int i5 = motorista4.getGrau();
        boolean b7 = motorista4.equals((java.lang.Object) (byte) 10);
        int i8 = motorista0.compareTo((Ator) motorista4);
        double d10 = motorista4.tempoViagem((double) 10.0f);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test055");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        boolean b3 = motorista0.equals((java.lang.Object) (byte) 10);
        int i4 = motorista0.getGrau();
        Motorista motorista5 = new Motorista();
        java.lang.String str6 = motorista5.toString();
        java.util.GregorianCalendar gregorianCalendar7 = null;
        java.util.GregorianCalendar gregorianCalendar8 = null;
        double d9 = motorista5.totalFaturado(gregorianCalendar7, gregorianCalendar8);
        java.util.Set<Viagem> set_viagem10 = motorista5.getHistorico();
        boolean b11 = motorista0.equals((java.lang.Object) set_viagem10);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista5 and motorista5", motorista5.equals(motorista5) ? motorista5.hashCode() == motorista5.hashCode() : true);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test056");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        double d9 = motorista0.totalFaturado();
        java.lang.String str10 = motorista0.toString();
        Motorista motorista11 = new Motorista();
        Veiculo veiculo12 = motorista11.getVeiculo();
        java.lang.String str13 = motorista11.getMail();
        int i14 = motorista11.getNumClassi();
        motorista11.setDisponibilidade(false);
        java.lang.String str17 = motorista11.getMorada();
        int i18 = motorista0.compareTo((Ator) motorista11);
        int i19 = motorista0.getClassificacao();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista11 and motorista11", motorista11.equals(motorista11) ? motorista11.hashCode() == motorista11.hashCode() : true);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test057");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        motorista0.atualizaClassificacao(0);
        double d8 = motorista0.getKmsTotais();
        Motorista motorista9 = new Motorista();
        int i10 = motorista9.getGrau();
        boolean b12 = motorista9.equals((java.lang.Object) (byte) 10);
        int i13 = motorista0.compareTo((Ator) motorista9);
        double d15 = motorista9.tempoViagem((double) ' ');
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test058");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        int i2 = motorista0.getNumClassi();
        Motorista motorista3 = new Motorista();
        Veiculo veiculo4 = motorista3.getVeiculo();
        java.lang.String str5 = motorista3.getMail();
        int i6 = motorista3.getNumClassi();
        motorista3.atualizaClassificacao((int) (byte) 10);
        int i9 = motorista3.getNumClassi();
        java.lang.String str10 = motorista3.getNome();
        int i11 = motorista3.getClassificacao();
        double d12 = motorista3.totalFaturado();
        java.lang.String str13 = motorista3.toString();
        Motorista motorista14 = new Motorista();
        Veiculo veiculo15 = motorista14.getVeiculo();
        java.lang.String str16 = motorista14.getMail();
        int i17 = motorista14.getNumClassi();
        motorista14.setDisponibilidade(false);
        java.lang.String str20 = motorista14.getMorada();
        int i21 = motorista3.compareTo((Ator) motorista14);
        int i22 = motorista0.compareTo(motorista14);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test059");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
        Veiculo veiculo12 = null;
        Motorista motorista13 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "hi!", "hi!", veiculo12);
        motorista13.atualizaClassificacao(100);
        int i16 = motorista6.compareTo(motorista13);
        int i17 = motorista13.getNumClassi();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista6 and motorista6", motorista6.equals(motorista6) ? motorista6.hashCode() == motorista6.hashCode() : true);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test060");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        double d9 = motorista0.totalFaturado();
        java.lang.String str10 = motorista0.toString();
        Motorista motorista11 = new Motorista();
        Veiculo veiculo12 = motorista11.getVeiculo();
        java.lang.String str13 = motorista11.getMail();
        int i14 = motorista11.getNumClassi();
        motorista11.setDisponibilidade(false);
        java.lang.String str17 = motorista11.getMorada();
        int i18 = motorista0.compareTo((Ator) motorista11);
        java.util.GregorianCalendar gregorianCalendar19 = null;
        java.util.GregorianCalendar gregorianCalendar20 = null;
        double d21 = motorista0.totalFaturado(gregorianCalendar19, gregorianCalendar20);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista11 and motorista11", motorista11.equals(motorista11) ? motorista11.hashCode() == motorista11.hashCode() : true);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test061");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        Motorista motorista2 = new Motorista();
        Veiculo veiculo3 = motorista2.getVeiculo();
        java.lang.String str4 = motorista2.getMail();
        int i5 = motorista0.compareTo((Ator) motorista2);
        java.util.Set<Viagem> set_viagem6 = motorista2.getHistorico();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test062");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
        Veiculo veiculo12 = null;
        Motorista motorista13 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "hi!", "hi!", veiculo12);
        motorista13.atualizaClassificacao(100);
        int i16 = motorista6.compareTo(motorista13);
        java.lang.String str17 = motorista13.getMail();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista6 and motorista6", motorista6.equals(motorista6) ? motorista6.hashCode() == motorista6.hashCode() : true);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test063");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        Veiculo veiculo2 = motorista0.getVeiculo();
        double d3 = motorista0.getKmsTotais();
        Motorista motorista4 = motorista0.clone();
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test064");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
        Veiculo veiculo12 = null;
        Motorista motorista13 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "hi!", "hi!", veiculo12);
        motorista13.atualizaClassificacao(100);
        int i16 = motorista6.compareTo(motorista13);
        boolean b17 = motorista6.getDisponibilidade();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista13 and motorista13", motorista13.equals(motorista13) ? motorista13.hashCode() == motorista13.hashCode() : true);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test065");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.lang.String str2 = motorista0.getMail();
        java.lang.String str3 = motorista0.getMail();
        motorista0.atualizaClassificacao((int) (byte) 1);
        Motorista motorista6 = new Motorista();
        Veiculo veiculo7 = motorista6.getVeiculo();
        java.lang.String str8 = motorista6.getMail();
        int i9 = motorista6.getNumClassi();
        motorista6.atualizaClassificacao((int) (byte) 10);
        motorista6.atualizaClassificacao(0);
        java.lang.String str14 = motorista6.getMorada();
        int i15 = motorista0.compareTo(motorista6);
        double d16 = motorista6.getKmsTotais();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test066");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        Motorista motorista2 = new Motorista();
        Veiculo veiculo3 = motorista2.getVeiculo();
        java.lang.String str4 = motorista2.getMail();
        int i5 = motorista0.compareTo((Ator) motorista2);
        java.lang.String str6 = motorista2.getDataDeNascimento();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test067");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        Motorista motorista2 = new Motorista();
        Veiculo veiculo3 = motorista2.getVeiculo();
        java.lang.String str4 = motorista2.getMail();
        int i5 = motorista0.compareTo((Ator) motorista2);
        double d7 = motorista2.tempoViagem((double) 1.0f);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test068");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        Motorista motorista7 = new Motorista();
        Veiculo veiculo8 = motorista7.getVeiculo();
        java.lang.String str9 = motorista7.getMail();
        int i10 = motorista7.getNumClassi();
        motorista7.atualizaClassificacao((int) (byte) 10);
        int i13 = motorista7.getNumClassi();
        Veiculo veiculo14 = motorista7.getVeiculo();
        double d15 = motorista7.getKmsTotais();
        boolean b16 = motorista0.equals((java.lang.Object) motorista7);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test069");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        Veiculo veiculo7 = motorista0.getVeiculo();
        Motorista motorista8 = new Motorista();
        Veiculo veiculo9 = motorista8.getVeiculo();
        java.lang.String str10 = motorista8.getMail();
        int i11 = motorista0.compareTo((Ator) motorista8);
        java.lang.String str12 = motorista0.getMorada();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista8 and motorista8", motorista8.equals(motorista8) ? motorista8.hashCode() == motorista8.hashCode() : true);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test070");
        Motorista motorista0 = new Motorista();
        double d1 = motorista0.totalFaturado();
        Motorista motorista2 = new Motorista();
        Veiculo veiculo3 = motorista2.getVeiculo();
        java.lang.String str4 = motorista2.getMail();
        int i5 = motorista2.getNumClassi();
        motorista2.atualizaClassificacao((int) (byte) 10);
        int i8 = motorista2.getNumClassi();
        Veiculo veiculo9 = motorista2.getVeiculo();
        Motorista motorista10 = new Motorista();
        Veiculo veiculo11 = motorista10.getVeiculo();
        java.lang.String str12 = motorista10.getMail();
        int i13 = motorista2.compareTo((Ator) motorista10);
        boolean b14 = motorista0.equals((java.lang.Object) motorista10);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test071");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        Veiculo veiculo2 = motorista0.getVeiculo();
        java.util.Set<Viagem> set_viagem3 = motorista0.getHistorico();
        Motorista motorista4 = new Motorista();
        int i5 = motorista4.getGrau();
        Veiculo veiculo6 = motorista4.getVeiculo();
        java.lang.String str7 = motorista4.getDataDeNascimento();
        double d8 = motorista4.getKmsTotais();
        int i9 = motorista0.compareTo(motorista4);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test072");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        Veiculo veiculo7 = motorista0.getVeiculo();
        Motorista motorista8 = new Motorista();
        Veiculo veiculo9 = motorista8.getVeiculo();
        java.lang.String str10 = motorista8.getMail();
        int i11 = motorista0.compareTo((Ator) motorista8);
        int i12 = motorista0.getClassificacao();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista8 and motorista8", motorista8.equals(motorista8) ? motorista8.hashCode() == motorista8.hashCode() : true);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test073");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        Motorista motorista3 = new Motorista();
        java.lang.String str4 = motorista3.toString();
        java.lang.String str5 = motorista3.getMail();
        int i6 = motorista0.compareTo((Ator) motorista3);
        motorista0.setDisponibilidade(false);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista3 and motorista3", motorista3.equals(motorista3) ? motorista3.hashCode() == motorista3.hashCode() : true);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test074");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.lang.String str2 = motorista0.getMail();
        java.lang.String str3 = motorista0.getMail();
        motorista0.atualizaClassificacao((int) (byte) 1);
        Motorista motorista6 = new Motorista();
        Veiculo veiculo7 = motorista6.getVeiculo();
        java.lang.String str8 = motorista6.getMail();
        int i9 = motorista6.getNumClassi();
        motorista6.atualizaClassificacao((int) (byte) 10);
        motorista6.atualizaClassificacao(0);
        java.lang.String str14 = motorista6.getMorada();
        int i15 = motorista0.compareTo(motorista6);
        java.lang.String str16 = motorista6.getMail();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test075");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        motorista0.atualizaClassificacao(0);
        double d8 = motorista0.getKmsTotais();
        Motorista motorista9 = new Motorista();
        int i10 = motorista9.getGrau();
        boolean b12 = motorista9.equals((java.lang.Object) (byte) 10);
        int i13 = motorista0.compareTo((Ator) motorista9);
        Veiculo veiculo14 = motorista0.getVeiculo();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista9 and motorista9", motorista9.equals(motorista9) ? motorista9.hashCode() == motorista9.hashCode() : true);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test076");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        boolean b3 = motorista0.equals((java.lang.Object) (byte) 10);
        Motorista motorista4 = new Motorista();
        int i5 = motorista4.getGrau();
        boolean b7 = motorista4.equals((java.lang.Object) (byte) 10);
        int i8 = motorista0.compareTo((Ator) motorista4);
        int i9 = motorista4.getGrau();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test077");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", veiculo5);
        java.lang.String str7 = motorista6.getPassword();
        Veiculo veiculo13 = null;
        Motorista motorista14 = new Motorista("hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "", veiculo13);
        int i15 = motorista6.compareTo((Ator) motorista14);
        int i16 = motorista14.getClassificacao();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista6 and motorista6", motorista6.equals(motorista6) ? motorista6.hashCode() == motorista6.hashCode() : true);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test078");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        Veiculo veiculo2 = motorista0.getVeiculo();
        java.lang.String str3 = motorista0.getDataDeNascimento();
        Veiculo veiculo9 = null;
        Motorista motorista10 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "", "", veiculo9);
        boolean b11 = motorista0.equals((java.lang.Object) "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n");
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista10 and motorista10", motorista10.equals(motorista10) ? motorista10.hashCode() == motorista10.hashCode() : true);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test079");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        Veiculo veiculo7 = motorista0.getVeiculo();
        double d9 = motorista0.tempoViagem((double) 1L);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test080");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        Motorista motorista2 = new Motorista();
        Veiculo veiculo3 = motorista2.getVeiculo();
        java.lang.String str4 = motorista2.getMail();
        int i5 = motorista0.compareTo((Ator) motorista2);
        java.lang.String str6 = motorista0.getPassword();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista2 and motorista2", motorista2.equals(motorista2) ? motorista2.hashCode() == motorista2.hashCode() : true);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test081");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", veiculo5);
        java.lang.String str7 = motorista6.getPassword();
        Veiculo veiculo13 = null;
        Motorista motorista14 = new Motorista("hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "", veiculo13);
        int i15 = motorista6.compareTo((Ator) motorista14);
        Motorista motorista16 = new Motorista();
        Veiculo veiculo17 = motorista16.getVeiculo();
        Motorista motorista18 = new Motorista();
        Veiculo veiculo19 = motorista18.getVeiculo();
        java.lang.String str20 = motorista18.getMail();
        int i21 = motorista16.compareTo((Ator) motorista18);
        int i22 = motorista14.compareTo((Ator) motorista18);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista16 and motorista16", motorista16.equals(motorista16) ? motorista16.hashCode() == motorista16.hashCode() : true);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test082");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        motorista0.setDisponibilidade(true);
        double d12 = motorista0.tempoViagem((double) 0.0f);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test083");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        motorista0.atualizaClassificacao(0);
        double d8 = motorista0.getKmsTotais();
        Motorista motorista9 = new Motorista();
        java.lang.String str10 = motorista9.toString();
        java.lang.String str11 = motorista9.getMail();
        boolean b12 = motorista0.equals((java.lang.Object) motorista9);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test084");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        java.lang.String str2 = motorista0.getPassword();
        Motorista motorista3 = motorista0.clone();
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test085");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        double d9 = motorista0.totalFaturado();
        java.lang.String str10 = motorista0.toString();
        double d11 = motorista0.totalFaturado();
        Motorista motorista12 = new Motorista();
        Veiculo veiculo13 = motorista12.getVeiculo();
        java.lang.String str14 = motorista12.getMail();
        int i15 = motorista12.getNumClassi();
        motorista12.atualizaClassificacao((int) (byte) 10);
        int i18 = motorista12.getNumClassi();
        boolean b20 = motorista12.equals((java.lang.Object) (byte) 0);
        int i21 = motorista0.compareTo(motorista12);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test086");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.lang.String str2 = motorista0.getMail();
        java.lang.String str3 = motorista0.getMail();
        motorista0.atualizaClassificacao((int) (byte) 1);
        Motorista motorista6 = new Motorista();
        Veiculo veiculo7 = motorista6.getVeiculo();
        java.lang.String str8 = motorista6.getMail();
        int i9 = motorista6.getNumClassi();
        motorista6.atualizaClassificacao((int) (byte) 10);
        motorista6.atualizaClassificacao(0);
        java.lang.String str14 = motorista6.getMorada();
        int i15 = motorista0.compareTo(motorista6);
        java.lang.String str16 = motorista0.toString();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista6 and motorista6", motorista6.equals(motorista6) ? motorista6.hashCode() == motorista6.hashCode() : true);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test087");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        Motorista motorista3 = new Motorista();
        java.lang.String str4 = motorista3.toString();
        java.lang.String str5 = motorista3.getMail();
        int i6 = motorista0.compareTo((Ator) motorista3);
        int i7 = motorista0.getClassificacao();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista3 and motorista3", motorista3.equals(motorista3) ? motorista3.hashCode() == motorista3.hashCode() : true);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test088");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        double d4 = motorista0.totalFaturado(gregorianCalendar2, gregorianCalendar3);
        java.lang.Object obj5 = null;
        boolean b6 = motorista0.equals(obj5);
        Motorista motorista7 = new Motorista();
        Veiculo veiculo8 = motorista7.getVeiculo();
        java.lang.String str9 = motorista7.getMail();
        boolean b10 = motorista7.getDisponibilidade();
        boolean b11 = motorista7.getDisponibilidade();
        java.lang.String str12 = motorista7.getDataDeNascimento();
        int i13 = motorista0.compareTo((Ator) motorista7);
        motorista7.setDisponibilidade(false);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test089");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        Motorista motorista9 = motorista0.clone();
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test090");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.setDisponibilidade(false);
        java.lang.String str6 = motorista0.getMorada();
        double d7 = motorista0.totalFaturado();
        double d9 = motorista0.tempoViagem((double) 100);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test091");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        Veiculo veiculo7 = motorista0.getVeiculo();
        double d8 = motorista0.getKmsTotais();
        Motorista motorista9 = new Motorista();
        java.lang.String str10 = motorista9.toString();
        java.lang.String str11 = motorista9.getMail();
        int i12 = motorista0.compareTo((Ator) motorista9);
        Veiculo veiculo13 = null;
        motorista9.setVeiculo(veiculo13);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test092");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        Motorista motorista2 = new Motorista();
        Veiculo veiculo3 = motorista2.getVeiculo();
        java.lang.String str4 = motorista2.getMail();
        int i5 = motorista0.compareTo((Ator) motorista2);
        java.lang.String str6 = motorista2.toString();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test093");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        double d4 = motorista0.totalFaturado(gregorianCalendar2, gregorianCalendar3);
        java.lang.Object obj5 = null;
        boolean b6 = motorista0.equals(obj5);
        Motorista motorista7 = new Motorista();
        Veiculo veiculo8 = motorista7.getVeiculo();
        java.lang.String str9 = motorista7.getMail();
        boolean b10 = motorista7.getDisponibilidade();
        boolean b11 = motorista7.getDisponibilidade();
        java.lang.String str12 = motorista7.getDataDeNascimento();
        int i13 = motorista0.compareTo((Ator) motorista7);
        Motorista motorista14 = new Motorista();
        Veiculo veiculo15 = motorista14.getVeiculo();
        java.lang.String str16 = motorista14.getMail();
        int i17 = motorista14.getNumClassi();
        motorista14.atualizaClassificacao((int) (byte) 10);
        int i20 = motorista14.getNumClassi();
        java.lang.String str21 = motorista14.getNome();
        int i22 = motorista14.getClassificacao();
        java.lang.String str23 = motorista14.getMail();
        int i24 = motorista7.compareTo(motorista14);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test094");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        motorista0.atualizaClassificacao(0);
        double d8 = motorista0.getKmsTotais();
        Motorista motorista9 = new Motorista();
        int i10 = motorista9.getGrau();
        boolean b12 = motorista9.equals((java.lang.Object) (byte) 10);
        int i13 = motorista0.compareTo((Ator) motorista9);
        boolean b15 = motorista9.equals((java.lang.Object) (short) 10);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test095");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        int i2 = motorista0.getNumClassi();
        Motorista motorista3 = new Motorista();
        double d4 = motorista3.totalFaturado();
        int i5 = motorista0.compareTo(motorista3);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test096");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.lang.String str2 = motorista0.getMail();
        java.lang.String str3 = motorista0.getMail();
        Veiculo veiculo4 = motorista0.getVeiculo();
        double d6 = motorista0.precoViagem((double) 1.0f);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test097");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.getPassword();
        java.lang.String str2 = motorista0.getMorada();
        Motorista motorista3 = new Motorista();
        double d4 = motorista3.totalFaturado();
        motorista3.setDisponibilidade(false);
        int i7 = motorista3.getNumClassi();
        int i8 = motorista0.compareTo(motorista3);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test098");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        Veiculo veiculo7 = motorista0.getVeiculo();
        double d8 = motorista0.getKmsTotais();
        Motorista motorista9 = new Motorista();
        java.lang.String str10 = motorista9.toString();
        java.lang.String str11 = motorista9.getMail();
        int i12 = motorista0.compareTo((Ator) motorista9);
        java.util.GregorianCalendar gregorianCalendar13 = null;
        java.util.GregorianCalendar gregorianCalendar14 = null;
        double d15 = motorista0.totalFaturado(gregorianCalendar13, gregorianCalendar14);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista9 and motorista9", motorista9.equals(motorista9) ? motorista9.hashCode() == motorista9.hashCode() : true);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test099");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.lang.String str2 = motorista0.toString();
        java.lang.String str3 = motorista0.getDataDeNascimento();
        java.lang.String str4 = motorista0.getPassword();
        java.lang.String str5 = motorista0.toString();
        double d7 = motorista0.precoViagem((double) 'a');
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test100");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        double d9 = motorista0.totalFaturado();
        java.lang.String str10 = motorista0.toString();
        double d12 = motorista0.tempoViagem((double) 100);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test101");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "", veiculo5);
        boolean b7 = motorista6.getDisponibilidade();
        Motorista motorista8 = new Motorista();
        Veiculo veiculo9 = motorista8.getVeiculo();
        java.lang.String str10 = motorista8.getMail();
        boolean b11 = motorista8.getDisponibilidade();
        int i12 = motorista8.getClassificacao();
        java.lang.String str13 = motorista8.getDataDeNascimento();
        Motorista motorista14 = new Motorista();
        Veiculo veiculo15 = motorista14.getVeiculo();
        java.lang.String str16 = motorista14.getMail();
        int i17 = motorista14.getNumClassi();
        motorista14.atualizaClassificacao((int) (byte) 10);
        motorista14.atualizaClassificacao(0);
        double d22 = motorista14.getKmsTotais();
        java.lang.String str23 = motorista14.getDataDeNascimento();
        int i24 = motorista8.compareTo((Ator) motorista14);
        int i25 = motorista6.compareTo(motorista8);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista14 and motorista14", motorista14.equals(motorista14) ? motorista14.hashCode() == motorista14.hashCode() : true);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test102");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        Veiculo veiculo7 = motorista0.getVeiculo();
        Motorista motorista8 = new Motorista();
        Veiculo veiculo9 = motorista8.getVeiculo();
        java.lang.String str10 = motorista8.getMail();
        int i11 = motorista0.compareTo((Ator) motorista8);
        double d12 = motorista0.totalFaturado();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista8 and motorista8", motorista8.equals(motorista8) ? motorista8.hashCode() == motorista8.hashCode() : true);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test103");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        boolean b3 = motorista0.getDisponibilidade();
        int i4 = motorista0.getClassificacao();
        java.lang.String str5 = motorista0.getDataDeNascimento();
        Motorista motorista6 = new Motorista();
        Veiculo veiculo7 = motorista6.getVeiculo();
        java.lang.String str8 = motorista6.getMail();
        int i9 = motorista6.getNumClassi();
        motorista6.atualizaClassificacao((int) (byte) 10);
        motorista6.atualizaClassificacao(0);
        double d14 = motorista6.getKmsTotais();
        java.lang.String str15 = motorista6.getDataDeNascimento();
        int i16 = motorista0.compareTo((Ator) motorista6);
        double d18 = motorista6.tempoViagem((double) (byte) 10);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test104");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        Motorista motorista3 = new Motorista();
        java.lang.String str4 = motorista3.toString();
        java.lang.String str5 = motorista3.getMail();
        int i6 = motorista0.compareTo((Ator) motorista3);
        java.lang.String str7 = motorista0.getPassword();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista3 and motorista3", motorista3.equals(motorista3) ? motorista3.hashCode() == motorista3.hashCode() : true);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test105");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        Motorista motorista2 = new Motorista();
        int i3 = motorista2.getGrau();
        Veiculo veiculo4 = motorista2.getVeiculo();
        java.util.Set<Viagem> set_viagem5 = motorista2.getHistorico();
        Motorista motorista6 = new Motorista();
        Veiculo veiculo7 = motorista6.getVeiculo();
        java.lang.String str8 = motorista6.getMail();
        boolean b9 = motorista6.getDisponibilidade();
        boolean b10 = motorista6.getDisponibilidade();
        java.lang.String str11 = motorista6.getDataDeNascimento();
        int i12 = motorista2.compareTo((Ator) motorista6);
        int i13 = motorista0.compareTo(motorista6);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test106");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        motorista0.atualizaClassificacao(0);
        double d8 = motorista0.getKmsTotais();
        Motorista motorista9 = new Motorista();
        int i10 = motorista9.getGrau();
        boolean b12 = motorista9.equals((java.lang.Object) (byte) 10);
        int i13 = motorista0.compareTo((Ator) motorista9);
        Motorista motorista14 = new Motorista(motorista0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test107");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        java.lang.String str9 = motorista0.getMail();
        Motorista motorista10 = new Motorista();
        Veiculo veiculo11 = motorista10.getVeiculo();
        java.lang.String str12 = motorista10.getMail();
        int i13 = motorista10.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar14 = null;
        java.util.GregorianCalendar gregorianCalendar15 = null;
        double d16 = motorista10.totalFaturado(gregorianCalendar14, gregorianCalendar15);
        boolean b17 = motorista10.getDisponibilidade();
        motorista10.setDisponibilidade(false);
        boolean b20 = motorista0.equals((java.lang.Object) false);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista10 and motorista10", motorista10.equals(motorista10) ? motorista10.hashCode() == motorista10.hashCode() : true);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test108");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        motorista0.atualizaClassificacao(0);
        double d8 = motorista0.getKmsTotais();
        Motorista motorista9 = new Motorista();
        int i10 = motorista9.getGrau();
        boolean b12 = motorista9.equals((java.lang.Object) (byte) 10);
        int i13 = motorista0.compareTo((Ator) motorista9);
        Motorista motorista14 = new Motorista();
        Veiculo veiculo15 = motorista14.getVeiculo();
        java.lang.String str16 = motorista14.getMail();
        int i17 = motorista14.getNumClassi();
        motorista14.atualizaClassificacao((int) (byte) 10);
        int i20 = motorista14.getNumClassi();
        Veiculo veiculo21 = motorista14.getVeiculo();
        Motorista motorista22 = new Motorista();
        Veiculo veiculo23 = motorista22.getVeiculo();
        java.lang.String str24 = motorista22.getMail();
        int i25 = motorista14.compareTo((Ator) motorista22);
        int i26 = motorista9.compareTo((Ator) motorista22);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista14 and motorista14", motorista14.equals(motorista14) ? motorista14.hashCode() == motorista14.hashCode() : true);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test109");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.getPassword();
        motorista0.atualizaClassificacao(100);
        Motorista motorista4 = new Motorista();
        int i5 = motorista4.getGrau();
        boolean b7 = motorista4.equals((java.lang.Object) (byte) 10);
        int i8 = motorista4.getGrau();
        java.lang.String str9 = motorista4.getNome();
        int i10 = motorista4.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar11 = null;
        java.util.GregorianCalendar gregorianCalendar12 = null;
        double d13 = motorista4.totalFaturado(gregorianCalendar11, gregorianCalendar12);
        int i14 = motorista0.compareTo((Ator) motorista4);
        java.lang.String str15 = motorista4.getMorada();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test110");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        Veiculo veiculo7 = motorista0.getVeiculo();
        Motorista motorista8 = new Motorista();
        Veiculo veiculo9 = motorista8.getVeiculo();
        java.lang.String str10 = motorista8.getMail();
        int i11 = motorista0.compareTo((Ator) motorista8);
        Motorista motorista12 = motorista8.clone();
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test111");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        Veiculo veiculo11 = null;
        Motorista motorista12 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo11);
        int i13 = motorista0.compareTo(motorista12);
        java.lang.String str14 = motorista12.getNome();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test112");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        int i2 = motorista0.getNumClassi();
        Motorista motorista3 = new Motorista(motorista0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test113");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.lang.String str2 = motorista0.getMail();
        Motorista motorista3 = new Motorista();
        Veiculo veiculo4 = motorista3.getVeiculo();
        java.lang.String str5 = motorista3.getMail();
        int i6 = motorista3.getNumClassi();
        motorista3.atualizaClassificacao((int) (byte) 10);
        int i9 = motorista3.getNumClassi();
        Veiculo veiculo10 = motorista3.getVeiculo();
        Motorista motorista11 = new Motorista();
        Veiculo veiculo12 = motorista11.getVeiculo();
        java.lang.String str13 = motorista11.getMail();
        int i14 = motorista3.compareTo((Ator) motorista11);
        int i15 = motorista0.compareTo(motorista11);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test114");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        motorista0.atualizaClassificacao(0);
        java.lang.String str8 = motorista0.getMorada();
        double d10 = motorista0.tempoViagem(10.0d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test115");
        Motorista motorista0 = new Motorista();
        double d1 = motorista0.totalFaturado();
        int i2 = motorista0.getGrau();
        boolean b3 = motorista0.getDisponibilidade();
        Motorista motorista4 = motorista0.clone();
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test116");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        motorista0.setDisponibilidade(true);
        Motorista motorista11 = new Motorista();
        double d12 = motorista11.totalFaturado();
        int i13 = motorista11.getGrau();
        int i14 = motorista0.compareTo((Ator) motorista11);
        double d16 = motorista11.precoViagem((double) 10L);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test117");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        motorista0.atualizaClassificacao(0);
        double d9 = motorista0.tempoViagem((double) (-3));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test118");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        double d2 = motorista0.getKmsTotais();
        Motorista motorista3 = new Motorista(motorista0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test119");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        java.lang.String str4 = motorista0.getDataDeNascimento();
        double d5 = motorista0.totalFaturado();
        double d7 = motorista0.tempoViagem((-1.0d));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test120");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        Veiculo veiculo6 = motorista0.getVeiculo();
        motorista0.atualizaClassificacao(100);
        Veiculo veiculo9 = motorista0.getVeiculo();
        Motorista motorista10 = new Motorista(motorista0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test121");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", veiculo5);
        java.lang.String str7 = motorista6.getPassword();
        Veiculo veiculo13 = null;
        Motorista motorista14 = new Motorista("hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "", veiculo13);
        int i15 = motorista6.compareTo((Ator) motorista14);
        motorista14.setDisponibilidade(false);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista6 and motorista6", motorista6.equals(motorista6) ? motorista6.hashCode() == motorista6.hashCode() : true);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test122");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", veiculo5);
        java.lang.String str7 = motorista6.getPassword();
        Veiculo veiculo13 = null;
        Motorista motorista14 = new Motorista("hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "", veiculo13);
        int i15 = motorista6.compareTo((Ator) motorista14);
        java.lang.String str16 = motorista6.toString();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista14 and motorista14", motorista14.equals(motorista14) ? motorista14.hashCode() == motorista14.hashCode() : true);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test123");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        Veiculo veiculo6 = motorista0.getVeiculo();
        motorista0.atualizaClassificacao(100);
        Veiculo veiculo9 = motorista0.getVeiculo();
        Veiculo veiculo15 = null;
        Motorista motorista16 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "", veiculo15);
        int i17 = motorista16.getGrau();
        int i18 = motorista0.compareTo((Ator) motorista16);
        motorista0.atualizaClassificacao(0);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista16 and motorista16", motorista16.equals(motorista16) ? motorista16.hashCode() == motorista16.hashCode() : true);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test124");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.setDisponibilidade(false);
        java.lang.String str6 = motorista0.getMorada();
        double d7 = motorista0.totalFaturado();
        double d9 = motorista0.tempoViagem((double) 100L);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test125");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.lang.String str2 = motorista0.getMail();
        java.lang.String str3 = motorista0.getMail();
        motorista0.atualizaClassificacao((int) (byte) 1);
        Motorista motorista6 = new Motorista();
        Veiculo veiculo7 = motorista6.getVeiculo();
        java.lang.String str8 = motorista6.getMail();
        int i9 = motorista6.getNumClassi();
        motorista6.atualizaClassificacao((int) (byte) 10);
        motorista6.atualizaClassificacao(0);
        java.lang.String str14 = motorista6.getMorada();
        int i15 = motorista0.compareTo(motorista6);
        Motorista motorista16 = new Motorista();
        java.lang.String str17 = motorista16.toString();
        java.util.GregorianCalendar gregorianCalendar18 = null;
        java.util.GregorianCalendar gregorianCalendar19 = null;
        double d20 = motorista16.totalFaturado(gregorianCalendar18, gregorianCalendar19);
        int i21 = motorista6.compareTo(motorista16);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test126");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        Veiculo veiculo2 = motorista0.getVeiculo();
        double d3 = motorista0.getKmsTotais();
        motorista0.setDisponibilidade(true);
        Motorista motorista6 = motorista0.clone();
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test127");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.lang.String str2 = motorista0.getMail();
        java.lang.String str3 = motorista0.getMail();
        java.lang.String str4 = motorista0.toString();
        Motorista motorista5 = new Motorista(motorista0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test128");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        Veiculo veiculo14 = null;
        Motorista motorista15 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "hi!", "hi!", veiculo14);
        int i16 = motorista0.compareTo(motorista15);
        double d17 = motorista15.totalFaturado();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test129");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        double d9 = motorista0.totalFaturado();
        java.lang.String str10 = motorista0.toString();
        Motorista motorista11 = motorista0.clone();
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test130");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        Veiculo veiculo2 = motorista0.getVeiculo();
        java.lang.String str3 = motorista0.getDataDeNascimento();
        double d4 = motorista0.getKmsTotais();
        Motorista motorista5 = new Motorista(motorista0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test131");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "hi!", "", "", "", veiculo5);
        Motorista motorista7 = new Motorista();
        java.lang.String str8 = motorista7.getPassword();
        motorista7.atualizaClassificacao(100);
        Motorista motorista11 = new Motorista();
        int i12 = motorista11.getGrau();
        boolean b14 = motorista11.equals((java.lang.Object) (byte) 10);
        int i15 = motorista11.getGrau();
        java.lang.String str16 = motorista11.getNome();
        int i17 = motorista11.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar18 = null;
        java.util.GregorianCalendar gregorianCalendar19 = null;
        double d20 = motorista11.totalFaturado(gregorianCalendar18, gregorianCalendar19);
        int i21 = motorista7.compareTo((Ator) motorista11);
        int i22 = motorista6.compareTo((Ator) motorista7);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista11 and motorista11", motorista11.equals(motorista11) ? motorista11.hashCode() == motorista11.hashCode() : true);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test132");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        int i2 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao(0);
        java.lang.String str5 = motorista0.getDataDeNascimento();
        Motorista motorista6 = motorista0.clone();
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test133");
        Motorista motorista0 = new Motorista();
        double d1 = motorista0.totalFaturado();
        motorista0.setDisponibilidade(false);
        int i4 = motorista0.getNumClassi();
        boolean b6 = motorista0.equals((java.lang.Object) (byte) 10);
        java.lang.String str7 = motorista0.getPassword();
        Motorista motorista8 = new Motorista();
        java.lang.String str9 = motorista8.getPassword();
        java.lang.String str10 = motorista8.getDataDeNascimento();
        boolean b12 = motorista8.equals((java.lang.Object) 100L);
        boolean b13 = motorista0.equals((java.lang.Object) b12);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista8 and motorista8", motorista8.equals(motorista8) ? motorista8.hashCode() == motorista8.hashCode() : true);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test134");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("hi!", "hi!", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", veiculo5);
        int i7 = motorista6.getNumClassi();
        java.lang.String str8 = motorista6.getMail();
        Motorista motorista9 = new Motorista();
        Veiculo veiculo10 = motorista9.getVeiculo();
        java.lang.String str11 = motorista9.getMail();
        int i12 = motorista9.getNumClassi();
        motorista9.atualizaClassificacao((int) (byte) 10);
        int i15 = motorista9.getNumClassi();
        int i16 = motorista6.compareTo((Ator) motorista9);
        int i17 = motorista9.getNumClassi();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista6 and motorista6", motorista6.equals(motorista6) ? motorista6.hashCode() == motorista6.hashCode() : true);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test135");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        boolean b3 = motorista0.getDisponibilidade();
        int i4 = motorista0.getClassificacao();
        java.lang.String str5 = motorista0.getDataDeNascimento();
        Motorista motorista6 = new Motorista();
        Veiculo veiculo7 = motorista6.getVeiculo();
        java.lang.String str8 = motorista6.getMail();
        int i9 = motorista6.getNumClassi();
        motorista6.atualizaClassificacao((int) (byte) 10);
        motorista6.atualizaClassificacao(0);
        double d14 = motorista6.getKmsTotais();
        java.lang.String str15 = motorista6.getDataDeNascimento();
        int i16 = motorista0.compareTo((Ator) motorista6);
        int i17 = motorista0.getClassificacao();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista6 and motorista6", motorista6.equals(motorista6) ? motorista6.hashCode() == motorista6.hashCode() : true);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test136");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        double d9 = motorista0.totalFaturado();
        java.lang.String str10 = motorista0.toString();
        Motorista motorista11 = new Motorista();
        Veiculo veiculo12 = motorista11.getVeiculo();
        java.lang.String str13 = motorista11.getMail();
        int i14 = motorista11.getNumClassi();
        motorista11.setDisponibilidade(false);
        java.lang.String str17 = motorista11.getMorada();
        int i18 = motorista0.compareTo((Ator) motorista11);
        Motorista motorista19 = new Motorista();
        java.lang.String str20 = motorista19.toString();
        java.lang.String str21 = motorista19.toString();
        java.lang.String str22 = motorista19.getDataDeNascimento();
        java.lang.String str23 = motorista19.getPassword();
        Veiculo veiculo24 = motorista19.getVeiculo();
        int i25 = motorista11.compareTo((Ator) motorista19);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test137");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        java.lang.String str4 = motorista0.getDataDeNascimento();
        boolean b5 = motorista0.getDisponibilidade();
        double d7 = motorista0.tempoViagem((double) ' ');
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test138");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        Veiculo veiculo2 = motorista0.getVeiculo();
        java.lang.String str3 = motorista0.getDataDeNascimento();
        Motorista motorista4 = new Motorista();
        int i5 = motorista4.getGrau();
        boolean b7 = motorista4.equals((java.lang.Object) (byte) 10);
        int i8 = motorista4.getGrau();
        java.lang.String str9 = motorista4.getNome();
        int i10 = motorista4.getNumClassi();
        boolean b11 = motorista0.equals((java.lang.Object) i10);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista4 and motorista4", motorista4.equals(motorista4) ? motorista4.hashCode() == motorista4.hashCode() : true);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test139");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.lang.String str2 = motorista0.toString();
        java.lang.String str3 = motorista0.getDataDeNascimento();
        java.lang.String str4 = motorista0.getPassword();
        Motorista motorista5 = new Motorista(motorista0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test140");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        Veiculo veiculo2 = motorista0.getVeiculo();
        double d3 = motorista0.getKmsTotais();
        Motorista motorista4 = new Motorista();
        int i5 = motorista4.getGrau();
        boolean b7 = motorista4.equals((java.lang.Object) (byte) 10);
        int i8 = motorista4.getGrau();
        java.lang.String str9 = motorista4.getNome();
        int i10 = motorista4.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar11 = null;
        java.util.GregorianCalendar gregorianCalendar12 = null;
        double d13 = motorista4.totalFaturado(gregorianCalendar11, gregorianCalendar12);
        java.lang.String str14 = motorista4.getMorada();
        java.util.Set<Viagem> set_viagem15 = motorista4.getHistorico();
        boolean b16 = motorista0.equals((java.lang.Object) set_viagem15);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista4 and motorista4", motorista4.equals(motorista4) ? motorista4.hashCode() == motorista4.hashCode() : true);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test141");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        Veiculo veiculo7 = motorista0.getVeiculo();
        double d8 = motorista0.getKmsTotais();
        Motorista motorista9 = new Motorista();
        java.lang.String str10 = motorista9.toString();
        java.lang.String str11 = motorista9.getMail();
        int i12 = motorista0.compareTo((Ator) motorista9);
        double d14 = motorista9.precoViagem((double) 3);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test142");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        double d9 = motorista0.totalFaturado();
        java.lang.String str10 = motorista0.toString();
        Motorista motorista11 = new Motorista();
        Veiculo veiculo12 = motorista11.getVeiculo();
        java.lang.String str13 = motorista11.getMail();
        int i14 = motorista11.getNumClassi();
        motorista11.setDisponibilidade(false);
        java.lang.String str17 = motorista11.getMorada();
        int i18 = motorista0.compareTo((Ator) motorista11);
        java.lang.String str19 = motorista11.getMorada();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test143");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
        java.lang.String str7 = motorista6.getPassword();
        Veiculo veiculo13 = null;
        Motorista motorista14 = new Motorista("", "hi!", "", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo13);
        int i15 = motorista6.compareTo((Ator) motorista14);
        java.util.Set<Viagem> set_viagem16 = motorista6.getHistorico();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista14 and motorista14", motorista14.equals(motorista14) ? motorista14.hashCode() == motorista14.hashCode() : true);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test144");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        int i2 = motorista0.getNumClassi();
        java.lang.String str3 = motorista0.getNome();
        java.lang.String str4 = motorista0.toString();
        double d5 = motorista0.getKmsTotais();
        Motorista motorista6 = motorista0.clone();
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test145");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        Veiculo veiculo11 = null;
        Motorista motorista12 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo11);
        int i13 = motorista0.compareTo(motorista12);
        java.util.GregorianCalendar gregorianCalendar14 = null;
        java.util.GregorianCalendar gregorianCalendar15 = null;
        double d16 = motorista12.totalFaturado(gregorianCalendar14, gregorianCalendar15);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test146");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        Veiculo veiculo2 = motorista0.getVeiculo();
        java.lang.String str3 = motorista0.getDataDeNascimento();
        java.lang.String str4 = motorista0.getNome();
        Motorista motorista5 = new Motorista(motorista0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test147");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.getPassword();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        double d4 = motorista0.totalFaturado(gregorianCalendar2, gregorianCalendar3);
        double d5 = motorista0.getKmsTotais();
        Motorista motorista6 = new Motorista();
        Veiculo veiculo7 = motorista6.getVeiculo();
        java.lang.String str8 = motorista6.getMail();
        int i9 = motorista6.getNumClassi();
        motorista6.atualizaClassificacao((int) (byte) 10);
        Veiculo veiculo12 = null;
        motorista6.setVeiculo(veiculo12);
        java.lang.String str14 = motorista6.getDataDeNascimento();
        motorista6.setDisponibilidade(true);
        int i17 = motorista0.compareTo((Ator) motorista6);
        int i18 = motorista0.getClassificacao();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista6 and motorista6", motorista6.equals(motorista6) ? motorista6.hashCode() == motorista6.hashCode() : true);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test148");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        double d4 = motorista0.totalFaturado(gregorianCalendar2, gregorianCalendar3);
        java.lang.Object obj5 = null;
        boolean b6 = motorista0.equals(obj5);
        Motorista motorista7 = new Motorista();
        Veiculo veiculo8 = motorista7.getVeiculo();
        java.lang.String str9 = motorista7.getMail();
        boolean b10 = motorista7.getDisponibilidade();
        boolean b11 = motorista7.getDisponibilidade();
        java.lang.String str12 = motorista7.getDataDeNascimento();
        int i13 = motorista0.compareTo((Ator) motorista7);
        int i14 = motorista0.getGrau();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista7 and motorista7", motorista7.equals(motorista7) ? motorista7.hashCode() == motorista7.hashCode() : true);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test149");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        Veiculo veiculo6 = motorista0.getVeiculo();
        motorista0.atualizaClassificacao(100);
        double d10 = motorista0.tempoViagem((double) 'a');
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test150");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("hi!", "hi!", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", veiculo5);
        int i7 = motorista6.getNumClassi();
        java.lang.String str8 = motorista6.getMail();
        Motorista motorista9 = new Motorista();
        Veiculo veiculo10 = motorista9.getVeiculo();
        java.lang.String str11 = motorista9.getMail();
        int i12 = motorista9.getNumClassi();
        motorista9.atualizaClassificacao((int) (byte) 10);
        int i15 = motorista9.getNumClassi();
        int i16 = motorista6.compareTo((Ator) motorista9);
        java.lang.String str17 = motorista9.getPassword();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista6 and motorista6", motorista6.equals(motorista6) ? motorista6.hashCode() == motorista6.hashCode() : true);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test151");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        int i2 = motorista0.getNumClassi();
        java.lang.String str3 = motorista0.getNome();
        java.lang.String str4 = motorista0.toString();
        double d5 = motorista0.getKmsTotais();
        Motorista motorista6 = new Motorista(motorista0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test152");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.lang.String str2 = motorista0.getMail();
        double d4 = motorista0.tempoViagem((double) 100);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test153");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        Veiculo veiculo3 = motorista0.getVeiculo();
        Motorista motorista4 = new Motorista();
        Veiculo veiculo5 = motorista4.getVeiculo();
        java.lang.String str6 = motorista4.getMail();
        int i7 = motorista4.getNumClassi();
        motorista4.atualizaClassificacao((int) (byte) 10);
        Veiculo veiculo10 = motorista4.getVeiculo();
        motorista4.atualizaClassificacao(100);
        Veiculo veiculo13 = motorista4.getVeiculo();
        Veiculo veiculo19 = null;
        Motorista motorista20 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "", veiculo19);
        int i21 = motorista20.getGrau();
        int i22 = motorista4.compareTo((Ator) motorista20);
        int i23 = motorista0.compareTo(motorista20);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista4 and motorista4", motorista4.equals(motorista4) ? motorista4.hashCode() == motorista4.hashCode() : true);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test154");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        Veiculo veiculo11 = null;
        Motorista motorista12 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo11);
        int i13 = motorista0.compareTo(motorista12);
        Veiculo veiculo14 = motorista12.getVeiculo();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test155");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "hi!", "hi!", veiculo5);
        motorista6.atualizaClassificacao(100);
        motorista6.atualizaClassificacao((int) (short) 1);
        Veiculo veiculo11 = motorista6.getVeiculo();
        Veiculo veiculo17 = null;
        Motorista motorista18 = new Motorista("", "hi!", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", veiculo17);
        Motorista motorista19 = new Motorista();
        int i20 = motorista19.getGrau();
        Veiculo veiculo21 = motorista19.getVeiculo();
        int i22 = motorista19.getNumClassi();
        motorista19.atualizaClassificacao(100);
        int i25 = motorista18.compareTo(motorista19);
        int i26 = motorista6.compareTo((Ator) motorista19);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista18 and motorista18", motorista18.equals(motorista18) ? motorista18.hashCode() == motorista18.hashCode() : true);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test156");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar4 = null;
        java.util.GregorianCalendar gregorianCalendar5 = null;
        double d6 = motorista0.totalFaturado(gregorianCalendar4, gregorianCalendar5);
        java.lang.Object obj7 = null;
        boolean b8 = motorista0.equals(obj7);
        int i9 = motorista0.getNumClassi();
        Motorista motorista10 = new Motorista();
        Veiculo veiculo11 = motorista10.getVeiculo();
        java.lang.String str12 = motorista10.getMail();
        int i13 = motorista10.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar14 = null;
        java.util.GregorianCalendar gregorianCalendar15 = null;
        double d16 = motorista10.totalFaturado(gregorianCalendar14, gregorianCalendar15);
        java.lang.String str17 = motorista10.getMorada();
        int i18 = motorista10.getGrau();
        int i19 = motorista0.compareTo((Ator) motorista10);
        int i20 = motorista0.getNumClassi();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista10 and motorista10", motorista10.equals(motorista10) ? motorista10.hashCode() == motorista10.hashCode() : true);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test157");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.lang.String str2 = motorista0.getMail();
        java.lang.String str3 = motorista0.getMail();
        motorista0.atualizaClassificacao((int) (byte) 1);
        Motorista motorista6 = new Motorista();
        Veiculo veiculo7 = motorista6.getVeiculo();
        java.lang.String str8 = motorista6.getMail();
        int i9 = motorista6.getNumClassi();
        motorista6.atualizaClassificacao((int) (byte) 10);
        motorista6.atualizaClassificacao(0);
        java.lang.String str14 = motorista6.getMorada();
        int i15 = motorista0.compareTo(motorista6);
        Motorista motorista16 = new Motorista();
        java.lang.String str17 = motorista16.getPassword();
        java.util.GregorianCalendar gregorianCalendar18 = null;
        java.util.GregorianCalendar gregorianCalendar19 = null;
        double d20 = motorista16.totalFaturado(gregorianCalendar18, gregorianCalendar19);
        java.lang.String str21 = motorista16.getPassword();
        java.lang.String str22 = motorista16.getPassword();
        int i23 = motorista16.getClassificacao();
        int i24 = motorista0.compareTo((Ator) motorista16);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista6 and motorista6", motorista6.equals(motorista6) ? motorista6.hashCode() == motorista6.hashCode() : true);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test158");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        Motorista motorista3 = new Motorista();
        java.lang.String str4 = motorista3.toString();
        java.lang.String str5 = motorista3.getMail();
        int i6 = motorista0.compareTo((Ator) motorista3);
        java.lang.String str7 = motorista3.getDataDeNascimento();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test159");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        Motorista motorista2 = new Motorista();
        Veiculo veiculo3 = motorista2.getVeiculo();
        java.lang.String str4 = motorista2.getMail();
        int i5 = motorista0.compareTo((Ator) motorista2);
        motorista2.setDisponibilidade(true);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test160");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", veiculo5);
        double d7 = motorista6.totalFaturado();
        motorista6.setDisponibilidade(false);
        Motorista motorista10 = new Motorista();
        int i11 = motorista10.getGrau();
        boolean b13 = motorista10.equals((java.lang.Object) (byte) 10);
        int i14 = motorista10.getGrau();
        java.lang.String str15 = motorista10.getNome();
        int i16 = motorista10.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar17 = null;
        java.util.GregorianCalendar gregorianCalendar18 = null;
        double d19 = motorista10.totalFaturado(gregorianCalendar17, gregorianCalendar18);
        boolean b20 = motorista10.getDisponibilidade();
        int i21 = motorista6.compareTo(motorista10);
        Motorista motorista22 = new Motorista();
        Veiculo veiculo23 = motorista22.getVeiculo();
        java.lang.String str24 = motorista22.getMail();
        int i25 = motorista22.getNumClassi();
        motorista22.atualizaClassificacao((int) (byte) 10);
        int i28 = motorista22.getNumClassi();
        java.lang.String str29 = motorista22.getNome();
        int i30 = motorista22.getClassificacao();
        double d31 = motorista22.totalFaturado();
        java.lang.String str32 = motorista22.getNome();
        int i33 = motorista6.compareTo((Ator) motorista22);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista10 and motorista10", motorista10.equals(motorista10) ? motorista10.hashCode() == motorista10.hashCode() : true);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test161");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        boolean b3 = motorista0.getDisponibilidade();
        int i4 = motorista0.getClassificacao();
        java.lang.String str5 = motorista0.getDataDeNascimento();
        Motorista motorista6 = new Motorista();
        Veiculo veiculo7 = motorista6.getVeiculo();
        java.lang.String str8 = motorista6.getMail();
        int i9 = motorista6.getNumClassi();
        motorista6.atualizaClassificacao((int) (byte) 10);
        motorista6.atualizaClassificacao(0);
        double d14 = motorista6.getKmsTotais();
        java.lang.String str15 = motorista6.getDataDeNascimento();
        int i16 = motorista0.compareTo((Ator) motorista6);
        int i17 = motorista0.getGrau();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista6 and motorista6", motorista6.equals(motorista6) ? motorista6.hashCode() == motorista6.hashCode() : true);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test162");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        motorista0.setDisponibilidade(true);
        int i11 = motorista0.getClassificacao();
        Veiculo veiculo17 = null;
        Motorista motorista18 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: true\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", veiculo17);
        int i19 = motorista0.compareTo((Ator) motorista18);
        java.lang.String str20 = motorista0.getDataDeNascimento();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista18 and motorista18", motorista18.equals(motorista18) ? motorista18.hashCode() == motorista18.hashCode() : true);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test163");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
        java.lang.String str7 = motorista6.getPassword();
        Veiculo veiculo13 = null;
        Motorista motorista14 = new Motorista("", "hi!", "", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo13);
        int i15 = motorista6.compareTo((Ator) motorista14);
        Veiculo veiculo16 = null;
        motorista6.setVeiculo(veiculo16);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista14 and motorista14", motorista14.equals(motorista14) ? motorista14.hashCode() == motorista14.hashCode() : true);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test164");
        Motorista motorista0 = new Motorista();
        Motorista motorista1 = new Motorista();
        Veiculo veiculo2 = motorista1.getVeiculo();
        java.lang.String str3 = motorista1.getMail();
        int i4 = motorista1.getNumClassi();
        motorista1.atualizaClassificacao((int) (byte) 10);
        int i7 = motorista1.getNumClassi();
        java.lang.String str8 = motorista1.getNome();
        int i9 = motorista1.getClassificacao();
        Veiculo veiculo15 = null;
        Motorista motorista16 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "hi!", "hi!", veiculo15);
        int i17 = motorista1.compareTo(motorista16);
        int i18 = motorista0.compareTo(motorista16);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista1 and motorista1", motorista1.equals(motorista1) ? motorista1.hashCode() == motorista1.hashCode() : true);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test165");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        Veiculo veiculo2 = motorista0.getVeiculo();
        java.util.Set<Viagem> set_viagem3 = motorista0.getHistorico();
        Motorista motorista4 = new Motorista();
        Veiculo veiculo5 = motorista4.getVeiculo();
        java.lang.String str6 = motorista4.getMail();
        boolean b7 = motorista4.getDisponibilidade();
        boolean b8 = motorista4.getDisponibilidade();
        java.lang.String str9 = motorista4.getDataDeNascimento();
        int i10 = motorista0.compareTo((Ator) motorista4);
        java.lang.String str11 = motorista4.getMorada();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test166");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar4 = null;
        java.util.GregorianCalendar gregorianCalendar5 = null;
        double d6 = motorista0.totalFaturado(gregorianCalendar4, gregorianCalendar5);
        java.lang.Object obj7 = null;
        boolean b8 = motorista0.equals(obj7);
        int i9 = motorista0.getNumClassi();
        Motorista motorista10 = new Motorista();
        Veiculo veiculo11 = motorista10.getVeiculo();
        java.lang.String str12 = motorista10.getMail();
        int i13 = motorista10.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar14 = null;
        java.util.GregorianCalendar gregorianCalendar15 = null;
        double d16 = motorista10.totalFaturado(gregorianCalendar14, gregorianCalendar15);
        java.lang.String str17 = motorista10.getMorada();
        int i18 = motorista10.getGrau();
        int i19 = motorista0.compareTo((Ator) motorista10);
        double d20 = motorista0.totalFaturado();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista10 and motorista10", motorista10.equals(motorista10) ? motorista10.hashCode() == motorista10.hashCode() : true);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test167");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        Motorista motorista3 = new Motorista();
        java.lang.String str4 = motorista3.toString();
        java.lang.String str5 = motorista3.getMail();
        int i6 = motorista0.compareTo((Ator) motorista3);
        java.util.Set<Viagem> set_viagem7 = motorista3.getHistorico();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test168");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar4 = null;
        java.util.GregorianCalendar gregorianCalendar5 = null;
        double d6 = motorista0.totalFaturado(gregorianCalendar4, gregorianCalendar5);
        java.lang.Object obj7 = null;
        boolean b8 = motorista0.equals(obj7);
        int i9 = motorista0.getNumClassi();
        Motorista motorista10 = new Motorista();
        Veiculo veiculo11 = motorista10.getVeiculo();
        java.lang.String str12 = motorista10.getMail();
        int i13 = motorista10.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar14 = null;
        java.util.GregorianCalendar gregorianCalendar15 = null;
        double d16 = motorista10.totalFaturado(gregorianCalendar14, gregorianCalendar15);
        java.lang.String str17 = motorista10.getMorada();
        int i18 = motorista10.getGrau();
        int i19 = motorista0.compareTo((Ator) motorista10);
        int i20 = motorista10.getNumClassi();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test169");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", veiculo5);
        double d7 = motorista6.totalFaturado();
        Motorista motorista8 = new Motorista();
        Veiculo veiculo9 = motorista8.getVeiculo();
        java.lang.String str10 = motorista8.getMail();
        int i11 = motorista8.getNumClassi();
        motorista8.atualizaClassificacao((int) (byte) 10);
        int i14 = motorista8.getNumClassi();
        java.lang.String str15 = motorista8.getNome();
        int i16 = motorista8.getClassificacao();
        Veiculo veiculo22 = null;
        Motorista motorista23 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "hi!", "hi!", veiculo22);
        int i24 = motorista8.compareTo(motorista23);
        int i25 = motorista6.compareTo(motorista8);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista23 and motorista23", motorista23.equals(motorista23) ? motorista23.hashCode() == motorista23.hashCode() : true);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test170");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.getPassword();
        motorista0.atualizaClassificacao(100);
        Motorista motorista4 = new Motorista();
        int i5 = motorista4.getGrau();
        boolean b7 = motorista4.equals((java.lang.Object) (byte) 10);
        int i8 = motorista4.getGrau();
        java.lang.String str9 = motorista4.getNome();
        int i10 = motorista4.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar11 = null;
        java.util.GregorianCalendar gregorianCalendar12 = null;
        double d13 = motorista4.totalFaturado(gregorianCalendar11, gregorianCalendar12);
        int i14 = motorista0.compareTo((Ator) motorista4);
        java.lang.String str15 = motorista4.getPassword();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test171");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        Motorista motorista6 = motorista0.clone();
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test172");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        motorista0.setDisponibilidade(true);
        int i11 = motorista0.getClassificacao();
        Veiculo veiculo17 = null;
        Motorista motorista18 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: true\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", veiculo17);
        int i19 = motorista0.compareTo((Ator) motorista18);
        double d20 = motorista0.getKmsTotais();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista18 and motorista18", motorista18.equals(motorista18) ? motorista18.hashCode() == motorista18.hashCode() : true);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test173");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", veiculo5);
        double d7 = motorista6.totalFaturado();
        int i8 = motorista6.getClassificacao();
        Veiculo veiculo14 = null;
        Motorista motorista15 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "", "", veiculo14);
        int i16 = motorista15.getNumClassi();
        int i17 = motorista6.compareTo((Ator) motorista15);
        Motorista motorista18 = new Motorista();
        Veiculo veiculo19 = motorista18.getVeiculo();
        java.lang.String str20 = motorista18.getMail();
        int i21 = motorista18.getNumClassi();
        motorista18.setDisponibilidade(false);
        java.lang.String str24 = motorista18.getMorada();
        double d25 = motorista18.totalFaturado();
        java.util.GregorianCalendar gregorianCalendar26 = null;
        java.util.GregorianCalendar gregorianCalendar27 = null;
        double d28 = motorista18.totalFaturado(gregorianCalendar26, gregorianCalendar27);
        int i29 = motorista6.compareTo((Ator) motorista18);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista15 and motorista15", motorista15.equals(motorista15) ? motorista15.hashCode() == motorista15.hashCode() : true);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test174");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.lang.String str2 = motorista0.getMail();
        java.lang.String str3 = motorista0.getMail();
        motorista0.atualizaClassificacao((int) (byte) 1);
        Motorista motorista6 = new Motorista();
        Veiculo veiculo7 = motorista6.getVeiculo();
        java.lang.String str8 = motorista6.getMail();
        int i9 = motorista6.getNumClassi();
        motorista6.atualizaClassificacao((int) (byte) 10);
        motorista6.atualizaClassificacao(0);
        java.lang.String str14 = motorista6.getMorada();
        int i15 = motorista0.compareTo(motorista6);
        int i16 = motorista6.getNumClassi();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test175");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        Veiculo veiculo11 = null;
        Motorista motorista12 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo11);
        int i13 = motorista0.compareTo(motorista12);
        int i14 = motorista12.getNumClassi();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test176");
        Motorista motorista0 = new Motorista();
        double d1 = motorista0.totalFaturado();
        motorista0.setDisponibilidade(false);
        Veiculo veiculo4 = null;
        motorista0.setVeiculo(veiculo4);
        int i6 = motorista0.getClassificacao();
        Veiculo veiculo12 = null;
        Motorista motorista13 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "hi!", "hi!", veiculo12);
        motorista13.atualizaClassificacao(100);
        int i16 = motorista0.compareTo((Ator) motorista13);
        int i17 = motorista13.getClassificacao();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test177");
        Motorista motorista0 = new Motorista();
        double d1 = motorista0.totalFaturado();
        boolean b2 = motorista0.getDisponibilidade();
        java.lang.String str3 = motorista0.getMail();
        java.lang.String str4 = motorista0.toString();
        Motorista motorista5 = new Motorista(motorista0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test178");
        Motorista motorista0 = new Motorista();
        double d1 = motorista0.totalFaturado();
        motorista0.setDisponibilidade(false);
        java.lang.String str4 = motorista0.getNome();
        Motorista motorista5 = motorista0.clone();
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test179");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        motorista0.setDisponibilidade(true);
        Motorista motorista11 = new Motorista();
        double d12 = motorista11.totalFaturado();
        int i13 = motorista11.getGrau();
        int i14 = motorista0.compareTo((Ator) motorista11);
        Veiculo veiculo15 = null;
        motorista0.setVeiculo(veiculo15);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista11 and motorista11", motorista11.equals(motorista11) ? motorista11.hashCode() == motorista11.hashCode() : true);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test180");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        Veiculo veiculo14 = null;
        Motorista motorista15 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "hi!", "hi!", veiculo14);
        int i16 = motorista0.compareTo(motorista15);
        java.lang.String str17 = motorista0.getDataDeNascimento();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista15 and motorista15", motorista15.equals(motorista15) ? motorista15.hashCode() == motorista15.hashCode() : true);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test181");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar4 = null;
        java.util.GregorianCalendar gregorianCalendar5 = null;
        double d6 = motorista0.totalFaturado(gregorianCalendar4, gregorianCalendar5);
        Motorista motorista7 = new Motorista();
        Veiculo veiculo8 = motorista7.getVeiculo();
        java.lang.String str9 = motorista7.getMail();
        int i10 = motorista7.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar11 = null;
        java.util.GregorianCalendar gregorianCalendar12 = null;
        double d13 = motorista7.totalFaturado(gregorianCalendar11, gregorianCalendar12);
        java.lang.String str14 = motorista7.getMorada();
        int i15 = motorista7.getGrau();
        java.util.Set<Viagem> set_viagem16 = motorista7.getHistorico();
        int i17 = motorista7.getClassificacao();
        int i18 = motorista0.compareTo((Ator) motorista7);
        boolean b19 = motorista7.getDisponibilidade();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test182");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.getPassword();
        motorista0.atualizaClassificacao(100);
        Motorista motorista4 = new Motorista();
        int i5 = motorista4.getGrau();
        boolean b7 = motorista4.equals((java.lang.Object) (byte) 10);
        int i8 = motorista4.getGrau();
        java.lang.String str9 = motorista4.getNome();
        int i10 = motorista4.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar11 = null;
        java.util.GregorianCalendar gregorianCalendar12 = null;
        double d13 = motorista4.totalFaturado(gregorianCalendar11, gregorianCalendar12);
        int i14 = motorista0.compareTo((Ator) motorista4);
        int i15 = motorista0.getNumClassi();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista4 and motorista4", motorista4.equals(motorista4) ? motorista4.hashCode() == motorista4.hashCode() : true);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test183");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        double d2 = motorista0.getKmsTotais();
        int i3 = motorista0.getClassificacao();
        Motorista motorista4 = new Motorista();
        Veiculo veiculo5 = motorista4.getVeiculo();
        java.lang.String str6 = motorista4.getMail();
        int i7 = motorista4.getNumClassi();
        motorista4.atualizaClassificacao((int) (byte) 10);
        int i10 = motorista4.getNumClassi();
        java.lang.String str11 = motorista4.getNome();
        int i12 = motorista4.getClassificacao();
        java.util.GregorianCalendar gregorianCalendar13 = null;
        java.util.GregorianCalendar gregorianCalendar14 = null;
        double d15 = motorista4.totalFaturado(gregorianCalendar13, gregorianCalendar14);
        Veiculo veiculo16 = null;
        motorista4.setVeiculo(veiculo16);
        motorista4.setDisponibilidade(false);
        int i20 = motorista0.compareTo((Ator) motorista4);
        java.lang.String str21 = motorista0.getMail();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista4 and motorista4", motorista4.equals(motorista4) ? motorista4.hashCode() == motorista4.hashCode() : true);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test184");
        Motorista motorista0 = new Motorista();
        double d1 = motorista0.totalFaturado();
        motorista0.setDisponibilidade(false);
        int i4 = motorista0.getNumClassi();
        boolean b6 = motorista0.equals((java.lang.Object) (byte) 10);
        java.lang.String str7 = motorista0.getPassword();
        motorista0.atualizaClassificacao(0);
        double d11 = motorista0.tempoViagem((double) 100);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test185");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.getPassword();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        double d4 = motorista0.totalFaturado(gregorianCalendar2, gregorianCalendar3);
        double d5 = motorista0.getKmsTotais();
        Motorista motorista6 = new Motorista();
        Veiculo veiculo7 = motorista6.getVeiculo();
        java.lang.String str8 = motorista6.getMail();
        int i9 = motorista6.getNumClassi();
        motorista6.atualizaClassificacao((int) (byte) 10);
        Veiculo veiculo12 = null;
        motorista6.setVeiculo(veiculo12);
        java.lang.String str14 = motorista6.getDataDeNascimento();
        motorista6.setDisponibilidade(true);
        int i17 = motorista0.compareTo((Ator) motorista6);
        motorista6.setDisponibilidade(false);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test186");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar4 = null;
        java.util.GregorianCalendar gregorianCalendar5 = null;
        double d6 = motorista0.totalFaturado(gregorianCalendar4, gregorianCalendar5);
        Motorista motorista7 = new Motorista();
        Veiculo veiculo8 = motorista7.getVeiculo();
        java.lang.String str9 = motorista7.getMail();
        int i10 = motorista7.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar11 = null;
        java.util.GregorianCalendar gregorianCalendar12 = null;
        double d13 = motorista7.totalFaturado(gregorianCalendar11, gregorianCalendar12);
        java.lang.String str14 = motorista7.getMorada();
        int i15 = motorista7.getGrau();
        java.util.Set<Viagem> set_viagem16 = motorista7.getHistorico();
        int i17 = motorista7.getClassificacao();
        int i18 = motorista0.compareTo((Ator) motorista7);
        java.lang.String str19 = motorista0.getNome();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista7 and motorista7", motorista7.equals(motorista7) ? motorista7.hashCode() == motorista7.hashCode() : true);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test187");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        Veiculo veiculo7 = motorista0.getVeiculo();
        Motorista motorista8 = new Motorista();
        Veiculo veiculo9 = motorista8.getVeiculo();
        java.lang.String str10 = motorista8.getMail();
        int i11 = motorista0.compareTo((Ator) motorista8);
        boolean b12 = motorista0.getDisponibilidade();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista8 and motorista8", motorista8.equals(motorista8) ? motorista8.hashCode() == motorista8.hashCode() : true);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test188");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        java.lang.String str8 = motorista0.getMorada();
        Motorista motorista9 = new Motorista(motorista0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test189");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
        Veiculo veiculo12 = null;
        Motorista motorista13 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "hi!", "hi!", veiculo12);
        motorista13.atualizaClassificacao(100);
        int i16 = motorista6.compareTo(motorista13);
        java.lang.String str17 = motorista13.getDataDeNascimento();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista6 and motorista6", motorista6.equals(motorista6) ? motorista6.hashCode() == motorista6.hashCode() : true);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test190");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", veiculo5);
        double d7 = motorista6.totalFaturado();
        motorista6.setDisponibilidade(false);
        Motorista motorista10 = new Motorista();
        int i11 = motorista10.getGrau();
        boolean b13 = motorista10.equals((java.lang.Object) (byte) 10);
        int i14 = motorista10.getGrau();
        java.lang.String str15 = motorista10.getNome();
        int i16 = motorista10.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar17 = null;
        java.util.GregorianCalendar gregorianCalendar18 = null;
        double d19 = motorista10.totalFaturado(gregorianCalendar17, gregorianCalendar18);
        boolean b20 = motorista10.getDisponibilidade();
        int i21 = motorista6.compareTo(motorista10);
        motorista6.setDisponibilidade(false);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista10 and motorista10", motorista10.equals(motorista10) ? motorista10.hashCode() == motorista10.hashCode() : true);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test191");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", veiculo5);
        double d7 = motorista6.totalFaturado();
        int i8 = motorista6.getClassificacao();
        Veiculo veiculo14 = null;
        Motorista motorista15 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "", "", veiculo14);
        int i16 = motorista15.getNumClassi();
        int i17 = motorista6.compareTo((Ator) motorista15);
        motorista6.setDisponibilidade(true);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista15 and motorista15", motorista15.equals(motorista15) ? motorista15.hashCode() == motorista15.hashCode() : true);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test192");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nNome: hi!\nPassword: hi!\nMorada: hi!\nData de nascimento: hi!\nGrau de cumprimento de horário: 100\nClassificação do motorista: 50\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", "E-mail: hi!\nNome: hi!\nPassword: hi!\nMorada: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
        Motorista motorista7 = new Motorista();
        int i8 = motorista7.getGrau();
        boolean b10 = motorista7.equals((java.lang.Object) (byte) 10);
        int i11 = motorista7.getGrau();
        java.lang.String str12 = motorista7.getNome();
        int i13 = motorista7.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar14 = null;
        java.util.GregorianCalendar gregorianCalendar15 = null;
        double d16 = motorista7.totalFaturado(gregorianCalendar14, gregorianCalendar15);
        java.lang.String str17 = motorista7.getMorada();
        boolean b18 = motorista6.equals((java.lang.Object) str17);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista7 and motorista7", motorista7.equals(motorista7) ? motorista7.hashCode() == motorista7.hashCode() : true);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test193");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.lang.String str2 = motorista0.getMail();
        java.lang.String str3 = motorista0.getMail();
        motorista0.atualizaClassificacao((int) (byte) 1);
        Motorista motorista6 = new Motorista();
        Veiculo veiculo7 = motorista6.getVeiculo();
        java.lang.String str8 = motorista6.getMail();
        int i9 = motorista6.getNumClassi();
        motorista6.atualizaClassificacao((int) (byte) 10);
        motorista6.atualizaClassificacao(0);
        java.lang.String str14 = motorista6.getMorada();
        int i15 = motorista0.compareTo(motorista6);
        Motorista motorista16 = new Motorista();
        java.lang.String str17 = motorista16.toString();
        int i18 = motorista16.getNumClassi();
        java.lang.String str19 = motorista16.getNome();
        java.lang.String str20 = motorista16.toString();
        double d21 = motorista16.getKmsTotais();
        Veiculo veiculo22 = null;
        motorista16.setVeiculo(veiculo22);
        java.lang.String str24 = motorista16.getMorada();
        int i25 = motorista0.compareTo((Ator) motorista16);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista6 and motorista6", motorista6.equals(motorista6) ? motorista6.hashCode() == motorista6.hashCode() : true);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test194");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.getPassword();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        double d4 = motorista0.totalFaturado(gregorianCalendar2, gregorianCalendar3);
        double d5 = motorista0.getKmsTotais();
        Motorista motorista6 = new Motorista();
        Veiculo veiculo7 = motorista6.getVeiculo();
        java.lang.String str8 = motorista6.getMail();
        int i9 = motorista6.getNumClassi();
        motorista6.atualizaClassificacao((int) (byte) 10);
        Veiculo veiculo12 = null;
        motorista6.setVeiculo(veiculo12);
        java.lang.String str14 = motorista6.getDataDeNascimento();
        motorista6.setDisponibilidade(true);
        int i17 = motorista0.compareTo((Ator) motorista6);
        Veiculo veiculo18 = motorista0.getVeiculo();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista6 and motorista6", motorista6.equals(motorista6) ? motorista6.hashCode() == motorista6.hashCode() : true);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test195");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        Motorista motorista3 = new Motorista();
        java.lang.String str4 = motorista3.toString();
        java.lang.String str5 = motorista3.getMail();
        int i6 = motorista0.compareTo((Ator) motorista3);
        java.util.GregorianCalendar gregorianCalendar7 = null;
        java.util.GregorianCalendar gregorianCalendar8 = null;
        double d9 = motorista0.totalFaturado(gregorianCalendar7, gregorianCalendar8);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista3 and motorista3", motorista3.equals(motorista3) ? motorista3.hashCode() == motorista3.hashCode() : true);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test196");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        Veiculo veiculo7 = motorista0.getVeiculo();
        double d8 = motorista0.getKmsTotais();
        Motorista motorista9 = new Motorista();
        java.lang.String str10 = motorista9.toString();
        java.lang.String str11 = motorista9.getMail();
        int i12 = motorista0.compareTo((Ator) motorista9);
        int i13 = motorista9.getNumClassi();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test197");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "hi!", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", veiculo5);
        Motorista motorista7 = new Motorista();
        Veiculo veiculo8 = motorista7.getVeiculo();
        java.lang.String str9 = motorista7.getMail();
        int i10 = motorista7.getNumClassi();
        java.lang.String str11 = motorista7.getDataDeNascimento();
        int i12 = motorista6.compareTo((Ator) motorista7);
        java.lang.String str13 = motorista7.getMorada();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista6 and motorista6", motorista6.equals(motorista6) ? motorista6.hashCode() == motorista6.hashCode() : true);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test198");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        double d2 = motorista0.getKmsTotais();
        double d4 = motorista0.precoViagem((double) (byte) -1);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test199");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "hi!", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", veiculo5);
        Motorista motorista7 = new Motorista();
        Veiculo veiculo8 = motorista7.getVeiculo();
        java.lang.String str9 = motorista7.getMail();
        int i10 = motorista7.getNumClassi();
        java.lang.String str11 = motorista7.getDataDeNascimento();
        int i12 = motorista6.compareTo((Ator) motorista7);
        int i13 = motorista7.getGrau();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista6 and motorista6", motorista6.equals(motorista6) ? motorista6.hashCode() == motorista6.hashCode() : true);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test200");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nNome: hi!\nPassword: hi!\nMorada: hi!\nData de nascimento: hi!\nGrau de cumprimento de horário: 100\nClassificação do motorista: 50\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", "E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
        Motorista motorista7 = new Motorista();
        Veiculo veiculo8 = motorista7.getVeiculo();
        java.lang.String str9 = motorista7.getMail();
        int i10 = motorista7.getNumClassi();
        motorista7.atualizaClassificacao((int) (byte) 10);
        int i13 = motorista7.getNumClassi();
        java.lang.String str14 = motorista7.getNome();
        int i15 = motorista7.getClassificacao();
        double d16 = motorista7.totalFaturado();
        motorista7.atualizaClassificacao((int) (short) 1);
        int i19 = motorista6.compareTo((Ator) motorista7);
        int i20 = motorista6.getGrau();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista7 and motorista7", motorista7.equals(motorista7) ? motorista7.hashCode() == motorista7.hashCode() : true);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test201");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "hi!", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", veiculo5);
        Veiculo veiculo12 = null;
        Motorista motorista13 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo12);
        boolean b14 = motorista6.equals((java.lang.Object) "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n");
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista13 and motorista13", motorista13.equals(motorista13) ? motorista13.hashCode() == motorista13.hashCode() : true);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test202");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        motorista0.setDisponibilidade(true);
        Motorista motorista11 = new Motorista();
        double d12 = motorista11.totalFaturado();
        int i13 = motorista11.getGrau();
        int i14 = motorista0.compareTo((Ator) motorista11);
        double d16 = motorista11.tempoViagem((double) 10);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test203");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        Veiculo veiculo2 = motorista0.getVeiculo();
        java.lang.String str3 = motorista0.getDataDeNascimento();
        double d4 = motorista0.getKmsTotais();
        java.lang.String str5 = motorista0.getMorada();
        double d6 = motorista0.getKmsTotais();
        Motorista motorista7 = new Motorista();
        Veiculo veiculo8 = motorista7.getVeiculo();
        java.lang.String str9 = motorista7.getMail();
        int i10 = motorista7.getNumClassi();
        motorista7.atualizaClassificacao((int) (byte) 10);
        int i13 = motorista7.getNumClassi();
        boolean b15 = motorista7.equals((java.lang.Object) (byte) 0);
        Veiculo veiculo21 = null;
        Motorista motorista22 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo21);
        double d23 = motorista22.getKmsTotais();
        Veiculo veiculo24 = motorista22.getVeiculo();
        int i25 = motorista7.compareTo(motorista22);
        int i26 = motorista0.compareTo(motorista7);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista22 and motorista22", motorista22.equals(motorista22) ? motorista22.hashCode() == motorista22.hashCode() : true);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test204");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        Veiculo veiculo3 = motorista0.getVeiculo();
        boolean b4 = motorista0.getDisponibilidade();
        java.lang.String str5 = motorista0.getMail();
        Motorista motorista6 = motorista0.clone();
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test205");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", veiculo5);
        double d7 = motorista6.totalFaturado();
        Motorista motorista8 = new Motorista();
        int i9 = motorista8.getGrau();
        Veiculo veiculo10 = motorista8.getVeiculo();
        double d11 = motorista8.getKmsTotais();
        motorista8.setDisponibilidade(true);
        java.lang.String str14 = motorista8.getPassword();
        boolean b15 = motorista8.getDisponibilidade();
        int i16 = motorista6.compareTo((Ator) motorista8);
        Veiculo veiculo17 = null;
        motorista6.setVeiculo(veiculo17);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista8 and motorista8", motorista8.equals(motorista8) ? motorista8.hashCode() == motorista8.hashCode() : true);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test206");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        boolean b3 = motorista0.getDisponibilidade();
        boolean b4 = motorista0.getDisponibilidade();
        Veiculo veiculo5 = motorista0.getVeiculo();
        Veiculo veiculo6 = motorista0.getVeiculo();
        double d8 = motorista0.tempoViagem((double) (-229));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test207");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        java.lang.String str2 = motorista0.getMorada();
        int i3 = motorista0.getClassificacao();
        double d5 = motorista0.precoViagem((double) 0L);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test208");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        java.lang.String str2 = motorista0.getPassword();
        motorista0.atualizaClassificacao(0);
        Motorista motorista5 = motorista0.clone();
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test209");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        boolean b3 = motorista0.getDisponibilidade();
        int i4 = motorista0.getClassificacao();
        Motorista motorista5 = new Motorista();
        java.lang.String str6 = motorista5.getPassword();
        java.util.GregorianCalendar gregorianCalendar7 = null;
        java.util.GregorianCalendar gregorianCalendar8 = null;
        double d9 = motorista5.totalFaturado(gregorianCalendar7, gregorianCalendar8);
        double d10 = motorista5.getKmsTotais();
        boolean b11 = motorista0.equals((java.lang.Object) d10);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista5 and motorista5", motorista5.equals(motorista5) ? motorista5.hashCode() == motorista5.hashCode() : true);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test210");
        Motorista motorista0 = new Motorista();
        double d1 = motorista0.totalFaturado();
        int i2 = motorista0.getGrau();
        boolean b3 = motorista0.getDisponibilidade();
        int i4 = motorista0.getClassificacao();
        Motorista motorista5 = new Motorista(motorista0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test211");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        boolean b3 = motorista0.getDisponibilidade();
        boolean b4 = motorista0.getDisponibilidade();
        double d6 = motorista0.precoViagem((-1.0d));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test212");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        double d4 = motorista0.totalFaturado(gregorianCalendar2, gregorianCalendar3);
        java.lang.Object obj5 = null;
        boolean b6 = motorista0.equals(obj5);
        Motorista motorista7 = new Motorista();
        Veiculo veiculo8 = motorista7.getVeiculo();
        java.lang.String str9 = motorista7.getMail();
        boolean b10 = motorista7.getDisponibilidade();
        boolean b11 = motorista7.getDisponibilidade();
        java.lang.String str12 = motorista7.getDataDeNascimento();
        int i13 = motorista0.compareTo((Ator) motorista7);
        motorista0.setDisponibilidade(false);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista7 and motorista7", motorista7.equals(motorista7) ? motorista7.hashCode() == motorista7.hashCode() : true);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test213");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        java.util.GregorianCalendar gregorianCalendar9 = null;
        java.util.GregorianCalendar gregorianCalendar10 = null;
        double d11 = motorista0.totalFaturado(gregorianCalendar9, gregorianCalendar10);
        java.lang.String str12 = motorista0.toString();
        java.lang.String str13 = motorista0.getMorada();
        Motorista motorista14 = new Motorista();
        java.lang.String str15 = motorista14.toString();
        java.util.GregorianCalendar gregorianCalendar16 = null;
        java.util.GregorianCalendar gregorianCalendar17 = null;
        double d18 = motorista14.totalFaturado(gregorianCalendar16, gregorianCalendar17);
        double d19 = motorista14.getKmsTotais();
        motorista14.setDisponibilidade(true);
        int i22 = motorista0.compareTo(motorista14);
        java.lang.String str23 = motorista14.getNome();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test214");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.lang.String str2 = motorista0.toString();
        java.lang.String str3 = motorista0.getNome();
        Motorista motorista4 = new Motorista(motorista0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test215");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar4 = null;
        java.util.GregorianCalendar gregorianCalendar5 = null;
        double d6 = motorista0.totalFaturado(gregorianCalendar4, gregorianCalendar5);
        Motorista motorista7 = new Motorista();
        Veiculo veiculo8 = motorista7.getVeiculo();
        java.lang.String str9 = motorista7.getMail();
        int i10 = motorista7.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar11 = null;
        java.util.GregorianCalendar gregorianCalendar12 = null;
        double d13 = motorista7.totalFaturado(gregorianCalendar11, gregorianCalendar12);
        java.lang.String str14 = motorista7.getMorada();
        int i15 = motorista7.getGrau();
        java.util.Set<Viagem> set_viagem16 = motorista7.getHistorico();
        int i17 = motorista7.getClassificacao();
        int i18 = motorista0.compareTo((Ator) motorista7);
        int i19 = motorista0.getClassificacao();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista7 and motorista7", motorista7.equals(motorista7) ? motorista7.hashCode() == motorista7.hashCode() : true);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test216");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        Veiculo veiculo6 = motorista0.getVeiculo();
        motorista0.atualizaClassificacao(100);
        Veiculo veiculo9 = motorista0.getVeiculo();
        Veiculo veiculo15 = null;
        Motorista motorista16 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "", veiculo15);
        int i17 = motorista16.getGrau();
        int i18 = motorista0.compareTo((Ator) motorista16);
        java.util.GregorianCalendar gregorianCalendar19 = null;
        java.util.GregorianCalendar gregorianCalendar20 = null;
        double d21 = motorista16.totalFaturado(gregorianCalendar19, gregorianCalendar20);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test217");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar4 = null;
        java.util.GregorianCalendar gregorianCalendar5 = null;
        double d6 = motorista0.totalFaturado(gregorianCalendar4, gregorianCalendar5);
        boolean b7 = motorista0.getDisponibilidade();
        motorista0.setDisponibilidade(false);
        int i10 = motorista0.getNumClassi();
        Motorista motorista11 = new Motorista();
        Veiculo veiculo12 = motorista11.getVeiculo();
        java.lang.String str13 = motorista11.getMail();
        int i14 = motorista11.getNumClassi();
        motorista11.atualizaClassificacao((int) (byte) 10);
        motorista11.atualizaClassificacao(0);
        double d19 = motorista11.getKmsTotais();
        Motorista motorista20 = new Motorista();
        int i21 = motorista20.getGrau();
        boolean b23 = motorista20.equals((java.lang.Object) (byte) 10);
        int i24 = motorista11.compareTo((Ator) motorista20);
        int i25 = motorista0.compareTo((Ator) motorista11);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista20 and motorista20", motorista20.equals(motorista20) ? motorista20.hashCode() == motorista20.hashCode() : true);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test218");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", veiculo5);
        double d7 = motorista6.totalFaturado();
        int i8 = motorista6.getClassificacao();
        Veiculo veiculo14 = null;
        Motorista motorista15 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "", "", veiculo14);
        int i16 = motorista15.getNumClassi();
        int i17 = motorista6.compareTo((Ator) motorista15);
        int i18 = motorista6.getGrau();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista15 and motorista15", motorista15.equals(motorista15) ? motorista15.hashCode() == motorista15.hashCode() : true);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test219");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        Motorista motorista3 = new Motorista();
        java.lang.String str4 = motorista3.toString();
        java.lang.String str5 = motorista3.getMail();
        int i6 = motorista0.compareTo((Ator) motorista3);
        double d7 = motorista0.totalFaturado();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista3 and motorista3", motorista3.equals(motorista3) ? motorista3.hashCode() == motorista3.hashCode() : true);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test220");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        java.lang.String str2 = motorista0.getPassword();
        motorista0.atualizaClassificacao(0);
        motorista0.setDisponibilidade(true);
        double d8 = motorista0.precoViagem((double) 1);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test221");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        double d4 = motorista0.totalFaturado(gregorianCalendar2, gregorianCalendar3);
        motorista0.setDisponibilidade(false);
        int i7 = motorista0.getClassificacao();
        Veiculo veiculo13 = null;
        Motorista motorista14 = new Motorista("hi!", "hi!", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", veiculo13);
        int i15 = motorista14.getNumClassi();
        java.lang.String str16 = motorista14.getMail();
        Veiculo veiculo17 = motorista14.getVeiculo();
        int i18 = motorista0.compareTo((Ator) motorista14);
        java.lang.String str19 = motorista0.getMail();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista14 and motorista14", motorista14.equals(motorista14) ? motorista14.hashCode() == motorista14.hashCode() : true);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test222");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        motorista0.setDisponibilidade(true);
        int i11 = motorista0.getClassificacao();
        Veiculo veiculo17 = null;
        Motorista motorista18 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: true\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", veiculo17);
        int i19 = motorista0.compareTo((Ator) motorista18);
        java.util.GregorianCalendar gregorianCalendar20 = null;
        java.util.GregorianCalendar gregorianCalendar21 = null;
        double d22 = motorista18.totalFaturado(gregorianCalendar20, gregorianCalendar21);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test223");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        boolean b3 = motorista0.getDisponibilidade();
        int i4 = motorista0.getClassificacao();
        motorista0.atualizaClassificacao(0);
        double d8 = motorista0.precoViagem((double) (byte) 0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test224");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        java.util.GregorianCalendar gregorianCalendar9 = null;
        java.util.GregorianCalendar gregorianCalendar10 = null;
        double d11 = motorista0.totalFaturado(gregorianCalendar9, gregorianCalendar10);
        Veiculo veiculo17 = null;
        Motorista motorista18 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "", veiculo17);
        int i19 = motorista18.getGrau();
        int i20 = motorista0.compareTo((Ator) motorista18);
        double d21 = motorista0.getKmsTotais();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista18 and motorista18", motorista18.equals(motorista18) ? motorista18.hashCode() == motorista18.hashCode() : true);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test225");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        Motorista motorista3 = new Motorista();
        java.lang.String str4 = motorista3.toString();
        java.lang.String str5 = motorista3.getMail();
        int i6 = motorista0.compareTo((Ator) motorista3);
        java.util.Set<Viagem> set_viagem7 = motorista0.getHistorico();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista3 and motorista3", motorista3.equals(motorista3) ? motorista3.hashCode() == motorista3.hashCode() : true);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test226");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        int i2 = motorista0.getNumClassi();
        Motorista motorista3 = new Motorista();
        java.lang.String str4 = motorista3.toString();
        java.lang.String str5 = motorista3.getMail();
        java.lang.String str6 = motorista3.getMail();
        int i7 = motorista3.getGrau();
        boolean b8 = motorista0.equals((java.lang.Object) motorista3);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test227");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        boolean b8 = motorista0.equals((java.lang.Object) (byte) 0);
        Veiculo veiculo14 = null;
        Motorista motorista15 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo14);
        double d16 = motorista15.getKmsTotais();
        Veiculo veiculo17 = motorista15.getVeiculo();
        int i18 = motorista0.compareTo(motorista15);
        double d19 = motorista15.totalFaturado();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test228");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.getPassword();
        java.lang.String str2 = motorista0.getDataDeNascimento();
        double d4 = motorista0.tempoViagem((double) (short) -1);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test229");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", veiculo5);
        double d7 = motorista6.totalFaturado();
        Motorista motorista8 = new Motorista();
        int i9 = motorista8.getGrau();
        Veiculo veiculo10 = motorista8.getVeiculo();
        double d11 = motorista8.getKmsTotais();
        motorista8.setDisponibilidade(true);
        java.lang.String str14 = motorista8.getPassword();
        boolean b15 = motorista8.getDisponibilidade();
        int i16 = motorista6.compareTo((Ator) motorista8);
        java.lang.String str17 = motorista8.getMorada();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista6 and motorista6", motorista6.equals(motorista6) ? motorista6.hashCode() == motorista6.hashCode() : true);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test230");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        double d4 = motorista0.totalFaturado(gregorianCalendar2, gregorianCalendar3);
        java.lang.Object obj5 = null;
        boolean b6 = motorista0.equals(obj5);
        Motorista motorista7 = new Motorista();
        Veiculo veiculo8 = motorista7.getVeiculo();
        java.lang.String str9 = motorista7.getMail();
        boolean b10 = motorista7.getDisponibilidade();
        boolean b11 = motorista7.getDisponibilidade();
        java.lang.String str12 = motorista7.getDataDeNascimento();
        int i13 = motorista0.compareTo((Ator) motorista7);
        java.lang.String str14 = motorista7.getNome();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test231");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", veiculo5);
        java.util.GregorianCalendar gregorianCalendar7 = null;
        java.util.GregorianCalendar gregorianCalendar8 = null;
        double d9 = motorista6.totalFaturado(gregorianCalendar7, gregorianCalendar8);
        Motorista motorista10 = new Motorista();
        double d11 = motorista10.totalFaturado();
        motorista10.setDisponibilidade(false);
        int i14 = motorista10.getNumClassi();
        boolean b16 = motorista10.equals((java.lang.Object) (byte) 10);
        int i17 = motorista6.compareTo((Ator) motorista10);
        java.lang.String str18 = motorista10.getPassword();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista6 and motorista6", motorista6.equals(motorista6) ? motorista6.hashCode() == motorista6.hashCode() : true);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test232");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar4 = null;
        java.util.GregorianCalendar gregorianCalendar5 = null;
        double d6 = motorista0.totalFaturado(gregorianCalendar4, gregorianCalendar5);
        java.lang.String str7 = motorista0.getMorada();
        int i8 = motorista0.getGrau();
        Motorista motorista9 = new Motorista();
        double d10 = motorista9.totalFaturado();
        int i11 = motorista9.getGrau();
        boolean b12 = motorista9.getDisponibilidade();
        int i13 = motorista9.getClassificacao();
        motorista9.atualizaClassificacao((int) '#');
        int i16 = motorista0.compareTo(motorista9);
        java.lang.String str17 = motorista0.getNome();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista9 and motorista9", motorista9.equals(motorista9) ? motorista9.hashCode() == motorista9.hashCode() : true);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test233");
        Motorista motorista0 = new Motorista();
        double d1 = motorista0.totalFaturado();
        motorista0.setDisponibilidade(false);
        motorista0.setDisponibilidade(false);
        Motorista motorista6 = new Motorista();
        Veiculo veiculo7 = motorista6.getVeiculo();
        java.lang.String str8 = motorista6.getMail();
        int i9 = motorista6.getNumClassi();
        motorista6.atualizaClassificacao((int) (byte) 10);
        motorista6.atualizaClassificacao(0);
        java.lang.String str14 = motorista6.getMorada();
        int i15 = motorista0.compareTo(motorista6);
        Veiculo veiculo16 = motorista0.getVeiculo();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista6 and motorista6", motorista6.equals(motorista6) ? motorista6.hashCode() == motorista6.hashCode() : true);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test234");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        boolean b3 = motorista0.getDisponibilidade();
        boolean b4 = motorista0.getDisponibilidade();
        double d5 = motorista0.totalFaturado();
        Motorista motorista6 = motorista0.clone();
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test235");
        Motorista motorista0 = new Motorista();
        double d1 = motorista0.totalFaturado();
        int i2 = motorista0.getGrau();
        boolean b3 = motorista0.getDisponibilidade();
        int i4 = motorista0.getClassificacao();
        motorista0.atualizaClassificacao((int) '#');
        double d7 = motorista0.getKmsTotais();
        double d9 = motorista0.tempoViagem((double) 3);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test236");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        boolean b3 = motorista0.equals((java.lang.Object) (byte) 10);
        java.util.GregorianCalendar gregorianCalendar4 = null;
        java.util.GregorianCalendar gregorianCalendar5 = null;
        double d6 = motorista0.totalFaturado(gregorianCalendar4, gregorianCalendar5);
        boolean b7 = motorista0.getDisponibilidade();
        motorista0.atualizaClassificacao((int) (short) 0);
        Motorista motorista10 = new Motorista();
        int i11 = motorista10.getGrau();
        boolean b13 = motorista10.equals((java.lang.Object) (byte) 10);
        int i14 = motorista10.getGrau();
        java.lang.String str15 = motorista10.getNome();
        boolean b16 = motorista0.equals((java.lang.Object) str15);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista10 and motorista10", motorista10.equals(motorista10) ? motorista10.hashCode() == motorista10.hashCode() : true);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test237");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        Veiculo veiculo2 = motorista0.getVeiculo();
        java.util.Set<Viagem> set_viagem3 = motorista0.getHistorico();
        Motorista motorista4 = new Motorista();
        Veiculo veiculo5 = motorista4.getVeiculo();
        java.lang.String str6 = motorista4.getMail();
        boolean b7 = motorista4.getDisponibilidade();
        boolean b8 = motorista4.getDisponibilidade();
        java.lang.String str9 = motorista4.getDataDeNascimento();
        int i10 = motorista0.compareTo((Ator) motorista4);
        double d12 = motorista0.tempoViagem((double) 230);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test238");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "hi!", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", veiculo5);
        Motorista motorista7 = new Motorista();
        int i8 = motorista7.getGrau();
        Veiculo veiculo9 = motorista7.getVeiculo();
        int i10 = motorista7.getNumClassi();
        motorista7.atualizaClassificacao(100);
        int i13 = motorista6.compareTo(motorista7);
        int i14 = motorista6.getClassificacao();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista7 and motorista7", motorista7.equals(motorista7) ? motorista7.hashCode() == motorista7.hashCode() : true);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test239");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.setDisponibilidade(false);
        java.lang.String str6 = motorista0.getMorada();
        Veiculo veiculo7 = motorista0.getVeiculo();
        Motorista motorista8 = motorista0.clone();
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test240");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        boolean b3 = motorista0.getDisponibilidade();
        int i4 = motorista0.getClassificacao();
        java.lang.String str5 = motorista0.getDataDeNascimento();
        Motorista motorista6 = new Motorista();
        Veiculo veiculo7 = motorista6.getVeiculo();
        java.lang.String str8 = motorista6.getMail();
        int i9 = motorista6.getNumClassi();
        motorista6.atualizaClassificacao((int) (byte) 10);
        motorista6.atualizaClassificacao(0);
        double d14 = motorista6.getKmsTotais();
        java.lang.String str15 = motorista6.getDataDeNascimento();
        int i16 = motorista0.compareTo((Ator) motorista6);
        java.lang.String str17 = motorista6.getPassword();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test241");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        double d9 = motorista0.totalFaturado();
        java.lang.String str10 = motorista0.toString();
        Motorista motorista11 = new Motorista();
        Veiculo veiculo12 = motorista11.getVeiculo();
        java.lang.String str13 = motorista11.getMail();
        int i14 = motorista11.getNumClassi();
        motorista11.setDisponibilidade(false);
        java.lang.String str17 = motorista11.getMorada();
        int i18 = motorista0.compareTo((Ator) motorista11);
        int i19 = motorista11.getGrau();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test242");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        Motorista motorista8 = new Motorista();
        java.lang.String str9 = motorista8.getPassword();
        java.util.GregorianCalendar gregorianCalendar10 = null;
        java.util.GregorianCalendar gregorianCalendar11 = null;
        double d12 = motorista8.totalFaturado(gregorianCalendar10, gregorianCalendar11);
        int i13 = motorista0.compareTo((Ator) motorista8);
        int i14 = motorista0.getGrau();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista8 and motorista8", motorista8.equals(motorista8) ? motorista8.hashCode() == motorista8.hashCode() : true);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test243");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        boolean b3 = motorista0.getDisponibilidade();
        int i4 = motorista0.getNumClassi();
        java.lang.String str5 = motorista0.getPassword();
        double d7 = motorista0.precoViagem((double) (-1L));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test244");
        Motorista motorista0 = new Motorista();
        double d1 = motorista0.totalFaturado();
        motorista0.setDisponibilidade(false);
        Veiculo veiculo4 = null;
        motorista0.setVeiculo(veiculo4);
        int i6 = motorista0.getClassificacao();
        Motorista motorista7 = new Motorista();
        Veiculo veiculo8 = motorista7.getVeiculo();
        java.lang.String str9 = motorista7.getMail();
        int i10 = motorista7.getNumClassi();
        motorista7.atualizaClassificacao((int) (byte) 10);
        motorista7.atualizaClassificacao(0);
        double d15 = motorista7.getKmsTotais();
        java.lang.String str16 = motorista7.getDataDeNascimento();
        Motorista motorista17 = new Motorista();
        java.lang.String str18 = motorista17.toString();
        java.util.GregorianCalendar gregorianCalendar19 = null;
        java.util.GregorianCalendar gregorianCalendar20 = null;
        double d21 = motorista17.totalFaturado(gregorianCalendar19, gregorianCalendar20);
        java.lang.Object obj22 = null;
        boolean b23 = motorista17.equals(obj22);
        int i24 = motorista17.getGrau();
        java.lang.String str25 = motorista17.getDataDeNascimento();
        int i26 = motorista7.compareTo((Ator) motorista17);
        int i27 = motorista0.compareTo((Ator) motorista17);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista7 and motorista7", motorista7.equals(motorista7) ? motorista7.hashCode() == motorista7.hashCode() : true);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test245");
        Motorista motorista0 = new Motorista();
        double d1 = motorista0.totalFaturado();
        motorista0.setDisponibilidade(false);
        int i4 = motorista0.getNumClassi();
        boolean b6 = motorista0.equals((java.lang.Object) (byte) 10);
        Motorista motorista7 = motorista0.clone();
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test246");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", veiculo5);
        double d7 = motorista6.totalFaturado();
        motorista6.setDisponibilidade(false);
        Motorista motorista10 = new Motorista();
        int i11 = motorista10.getGrau();
        boolean b13 = motorista10.equals((java.lang.Object) (byte) 10);
        int i14 = motorista10.getGrau();
        java.lang.String str15 = motorista10.getNome();
        int i16 = motorista10.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar17 = null;
        java.util.GregorianCalendar gregorianCalendar18 = null;
        double d19 = motorista10.totalFaturado(gregorianCalendar17, gregorianCalendar18);
        boolean b20 = motorista10.getDisponibilidade();
        int i21 = motorista6.compareTo(motorista10);
        java.lang.String str22 = motorista10.getPassword();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista6 and motorista6", motorista6.equals(motorista6) ? motorista6.hashCode() == motorista6.hashCode() : true);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test247");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar4 = null;
        java.util.GregorianCalendar gregorianCalendar5 = null;
        double d6 = motorista0.totalFaturado(gregorianCalendar4, gregorianCalendar5);
        Motorista motorista7 = new Motorista();
        Veiculo veiculo8 = motorista7.getVeiculo();
        java.lang.String str9 = motorista7.getMail();
        int i10 = motorista7.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar11 = null;
        java.util.GregorianCalendar gregorianCalendar12 = null;
        double d13 = motorista7.totalFaturado(gregorianCalendar11, gregorianCalendar12);
        java.lang.String str14 = motorista7.getMorada();
        int i15 = motorista7.getGrau();
        java.util.Set<Viagem> set_viagem16 = motorista7.getHistorico();
        int i17 = motorista7.getClassificacao();
        int i18 = motorista0.compareTo((Ator) motorista7);
        double d19 = motorista7.totalFaturado();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test248");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        double d9 = motorista0.totalFaturado();
        java.lang.String str10 = motorista0.toString();
        boolean b11 = motorista0.getDisponibilidade();
        Motorista motorista12 = motorista0.clone();
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test249");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        Veiculo veiculo11 = null;
        Motorista motorista12 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo11);
        int i13 = motorista0.compareTo(motorista12);
        int i14 = motorista0.getClassificacao();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista12 and motorista12", motorista12.equals(motorista12) ? motorista12.hashCode() == motorista12.hashCode() : true);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test250");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("hi!", "hi!", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", veiculo5);
        int i7 = motorista6.getNumClassi();
        java.lang.String str8 = motorista6.getMail();
        Motorista motorista9 = new Motorista();
        Veiculo veiculo10 = motorista9.getVeiculo();
        java.lang.String str11 = motorista9.getMail();
        int i12 = motorista9.getNumClassi();
        motorista9.atualizaClassificacao((int) (byte) 10);
        int i15 = motorista9.getNumClassi();
        int i16 = motorista6.compareTo((Ator) motorista9);
        motorista9.setDisponibilidade(false);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista6 and motorista6", motorista6.equals(motorista6) ? motorista6.hashCode() == motorista6.hashCode() : true);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test251");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar4 = null;
        java.util.GregorianCalendar gregorianCalendar5 = null;
        double d6 = motorista0.totalFaturado(gregorianCalendar4, gregorianCalendar5);
        java.lang.Object obj7 = null;
        boolean b8 = motorista0.equals(obj7);
        int i9 = motorista0.getNumClassi();
        Motorista motorista10 = new Motorista();
        Veiculo veiculo11 = motorista10.getVeiculo();
        java.lang.String str12 = motorista10.getMail();
        int i13 = motorista10.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar14 = null;
        java.util.GregorianCalendar gregorianCalendar15 = null;
        double d16 = motorista10.totalFaturado(gregorianCalendar14, gregorianCalendar15);
        java.lang.String str17 = motorista10.getMorada();
        int i18 = motorista10.getGrau();
        int i19 = motorista0.compareTo((Ator) motorista10);
        motorista10.setDisponibilidade(false);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test252");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        java.lang.String str2 = motorista0.getPassword();
        motorista0.atualizaClassificacao(0);
        Motorista motorista5 = new Motorista();
        int i6 = motorista5.getGrau();
        boolean b8 = motorista5.equals((java.lang.Object) (byte) 10);
        Veiculo veiculo9 = motorista5.getVeiculo();
        java.lang.String str10 = motorista5.getMorada();
        int i11 = motorista0.compareTo(motorista5);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test253");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", veiculo5);
        double d7 = motorista6.totalFaturado();
        Veiculo veiculo8 = motorista6.getVeiculo();
        Motorista motorista9 = new Motorista();
        int i10 = motorista9.getGrau();
        boolean b12 = motorista9.equals((java.lang.Object) (byte) 10);
        java.util.Set<Viagem> set_viagem13 = motorista9.getHistorico();
        Veiculo veiculo14 = null;
        motorista9.setVeiculo(veiculo14);
        int i16 = motorista6.compareTo(motorista9);
        Veiculo veiculo22 = null;
        Motorista motorista23 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: true\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", veiculo22);
        java.lang.String str24 = motorista23.getPassword();
        int i25 = motorista9.compareTo((Ator) motorista23);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista6 and motorista6", motorista6.equals(motorista6) ? motorista6.hashCode() == motorista6.hashCode() : true);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test254");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        Veiculo veiculo2 = motorista0.getVeiculo();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao(100);
        motorista0.setDisponibilidade(false);
        double d9 = motorista0.tempoViagem((double) 100.0f);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test255");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        double d4 = motorista0.totalFaturado(gregorianCalendar2, gregorianCalendar3);
        double d5 = motorista0.getKmsTotais();
        motorista0.setDisponibilidade(true);
        java.lang.String str8 = motorista0.getMorada();
        double d9 = motorista0.getKmsTotais();
        Motorista motorista10 = new Motorista();
        int i11 = motorista10.getGrau();
        boolean b13 = motorista10.equals((java.lang.Object) (byte) 10);
        int i14 = motorista10.getGrau();
        java.lang.String str15 = motorista10.getNome();
        int i16 = motorista10.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar17 = null;
        java.util.GregorianCalendar gregorianCalendar18 = null;
        double d19 = motorista10.totalFaturado(gregorianCalendar17, gregorianCalendar18);
        java.util.GregorianCalendar gregorianCalendar20 = null;
        java.util.GregorianCalendar gregorianCalendar21 = null;
        double d22 = motorista10.totalFaturado(gregorianCalendar20, gregorianCalendar21);
        int i23 = motorista0.compareTo((Ator) motorista10);
        java.util.Set<Viagem> set_viagem24 = motorista10.getHistorico();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test256");
        Motorista motorista0 = new Motorista();
        double d1 = motorista0.totalFaturado();
        motorista0.setDisponibilidade(false);
        double d4 = motorista0.totalFaturado();
        motorista0.atualizaClassificacao((int) '4');
        double d8 = motorista0.precoViagem((-1.0d));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test257");
        Motorista motorista0 = new Motorista();
        double d1 = motorista0.totalFaturado();
        motorista0.setDisponibilidade(false);
        int i4 = motorista0.getNumClassi();
        boolean b6 = motorista0.equals((java.lang.Object) (byte) 10);
        java.lang.String str7 = motorista0.getPassword();
        double d9 = motorista0.precoViagem((double) '#');
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test258");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.getPassword();
        motorista0.atualizaClassificacao(100);
        Motorista motorista4 = new Motorista();
        int i5 = motorista4.getGrau();
        boolean b7 = motorista4.equals((java.lang.Object) (byte) 10);
        int i8 = motorista4.getGrau();
        java.lang.String str9 = motorista4.getNome();
        int i10 = motorista4.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar11 = null;
        java.util.GregorianCalendar gregorianCalendar12 = null;
        double d13 = motorista4.totalFaturado(gregorianCalendar11, gregorianCalendar12);
        int i14 = motorista0.compareTo((Ator) motorista4);
        java.lang.String str15 = motorista0.getDataDeNascimento();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista4 and motorista4", motorista4.equals(motorista4) ? motorista4.hashCode() == motorista4.hashCode() : true);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test259");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        java.util.GregorianCalendar gregorianCalendar9 = null;
        java.util.GregorianCalendar gregorianCalendar10 = null;
        double d11 = motorista0.totalFaturado(gregorianCalendar9, gregorianCalendar10);
        Veiculo veiculo12 = motorista0.getVeiculo();
        Motorista motorista13 = new Motorista();
        Veiculo veiculo14 = motorista13.getVeiculo();
        java.lang.String str15 = motorista13.getMail();
        int i16 = motorista13.getNumClassi();
        motorista13.atualizaClassificacao((int) (byte) 10);
        int i19 = motorista13.getNumClassi();
        java.lang.String str20 = motorista13.getNome();
        int i21 = motorista13.getClassificacao();
        motorista13.setDisponibilidade(true);
        int i24 = motorista13.getClassificacao();
        int i25 = motorista0.compareTo((Ator) motorista13);
        boolean b26 = motorista0.getDisponibilidade();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista13 and motorista13", motorista13.equals(motorista13) ? motorista13.hashCode() == motorista13.hashCode() : true);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test260");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.lang.String str2 = motorista0.getMail();
        java.lang.String str3 = motorista0.getMail();
        motorista0.atualizaClassificacao((int) (byte) 1);
        Motorista motorista6 = new Motorista();
        Veiculo veiculo7 = motorista6.getVeiculo();
        java.lang.String str8 = motorista6.getMail();
        int i9 = motorista6.getNumClassi();
        motorista6.atualizaClassificacao((int) (byte) 10);
        motorista6.atualizaClassificacao(0);
        java.lang.String str14 = motorista6.getMorada();
        int i15 = motorista0.compareTo(motorista6);
        java.lang.String str16 = motorista6.toString();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test261");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        Veiculo veiculo2 = motorista0.getVeiculo();
        java.lang.String str3 = motorista0.getDataDeNascimento();
        java.lang.String str4 = motorista0.getNome();
        double d6 = motorista0.tempoViagem((double) (-3));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test262");
        Motorista motorista0 = new Motorista();
        double d1 = motorista0.totalFaturado();
        motorista0.setDisponibilidade(false);
        motorista0.setDisponibilidade(false);
        Motorista motorista6 = new Motorista();
        Veiculo veiculo7 = motorista6.getVeiculo();
        java.lang.String str8 = motorista6.getMail();
        int i9 = motorista6.getNumClassi();
        motorista6.atualizaClassificacao((int) (byte) 10);
        motorista6.atualizaClassificacao(0);
        java.lang.String str14 = motorista6.getMorada();
        int i15 = motorista0.compareTo(motorista6);
        java.lang.String str16 = motorista6.getDataDeNascimento();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test263");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar4 = null;
        java.util.GregorianCalendar gregorianCalendar5 = null;
        double d6 = motorista0.totalFaturado(gregorianCalendar4, gregorianCalendar5);
        Motorista motorista7 = new Motorista();
        Veiculo veiculo8 = motorista7.getVeiculo();
        java.lang.String str9 = motorista7.getMail();
        int i10 = motorista7.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar11 = null;
        java.util.GregorianCalendar gregorianCalendar12 = null;
        double d13 = motorista7.totalFaturado(gregorianCalendar11, gregorianCalendar12);
        java.lang.String str14 = motorista7.getMorada();
        int i15 = motorista7.getGrau();
        java.util.Set<Viagem> set_viagem16 = motorista7.getHistorico();
        int i17 = motorista7.getClassificacao();
        int i18 = motorista0.compareTo((Ator) motorista7);
        Veiculo veiculo19 = motorista0.getVeiculo();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista7 and motorista7", motorista7.equals(motorista7) ? motorista7.hashCode() == motorista7.hashCode() : true);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test264");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        double d10 = motorista0.precoViagem((double) 1.0f);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test265");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        Veiculo veiculo6 = motorista0.getVeiculo();
        motorista0.atualizaClassificacao(100);
        java.lang.String str9 = motorista0.getMorada();
        Motorista motorista10 = motorista0.clone();
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test266");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar4 = null;
        java.util.GregorianCalendar gregorianCalendar5 = null;
        double d6 = motorista0.totalFaturado(gregorianCalendar4, gregorianCalendar5);
        java.lang.Object obj7 = null;
        boolean b8 = motorista0.equals(obj7);
        int i9 = motorista0.getNumClassi();
        Motorista motorista10 = new Motorista();
        Veiculo veiculo11 = motorista10.getVeiculo();
        java.lang.String str12 = motorista10.getMail();
        int i13 = motorista10.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar14 = null;
        java.util.GregorianCalendar gregorianCalendar15 = null;
        double d16 = motorista10.totalFaturado(gregorianCalendar14, gregorianCalendar15);
        java.lang.String str17 = motorista10.getMorada();
        int i18 = motorista10.getGrau();
        int i19 = motorista0.compareTo((Ator) motorista10);
        motorista10.atualizaClassificacao((int) 'a');
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test267");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        double d4 = motorista0.totalFaturado(gregorianCalendar2, gregorianCalendar3);
        double d5 = motorista0.getKmsTotais();
        motorista0.setDisponibilidade(true);
        java.lang.String str8 = motorista0.getMorada();
        double d9 = motorista0.getKmsTotais();
        Motorista motorista10 = new Motorista();
        int i11 = motorista10.getGrau();
        boolean b13 = motorista10.equals((java.lang.Object) (byte) 10);
        int i14 = motorista10.getGrau();
        java.lang.String str15 = motorista10.getNome();
        int i16 = motorista10.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar17 = null;
        java.util.GregorianCalendar gregorianCalendar18 = null;
        double d19 = motorista10.totalFaturado(gregorianCalendar17, gregorianCalendar18);
        java.util.GregorianCalendar gregorianCalendar20 = null;
        java.util.GregorianCalendar gregorianCalendar21 = null;
        double d22 = motorista10.totalFaturado(gregorianCalendar20, gregorianCalendar21);
        int i23 = motorista0.compareTo((Ator) motorista10);
        java.lang.String str24 = motorista10.getDataDeNascimento();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test268");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "hi!", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", veiculo5);
        Motorista motorista7 = new Motorista();
        Veiculo veiculo8 = motorista7.getVeiculo();
        java.lang.String str9 = motorista7.getMail();
        int i10 = motorista7.getNumClassi();
        java.lang.String str11 = motorista7.getDataDeNascimento();
        int i12 = motorista6.compareTo((Ator) motorista7);
        Motorista motorista13 = new Motorista();
        int i14 = motorista13.getGrau();
        Veiculo veiculo15 = motorista13.getVeiculo();
        java.lang.String str16 = motorista13.getDataDeNascimento();
        java.lang.String str17 = motorista13.getNome();
        Veiculo veiculo18 = motorista13.getVeiculo();
        Veiculo veiculo24 = null;
        Motorista motorista25 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "hi!", "hi!", veiculo24);
        int i26 = motorista13.compareTo(motorista25);
        int i27 = motorista6.compareTo(motorista13);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista25 and motorista25", motorista25.equals(motorista25) ? motorista25.hashCode() == motorista25.hashCode() : true);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test269");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.lang.String str2 = motorista0.toString();
        java.lang.String str3 = motorista0.getDataDeNascimento();
        java.lang.String str4 = motorista0.getPassword();
        Veiculo veiculo5 = motorista0.getVeiculo();
        Motorista motorista6 = motorista0.clone();
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test270");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        boolean b8 = motorista0.equals((java.lang.Object) (byte) 0);
        Veiculo veiculo14 = null;
        Motorista motorista15 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo14);
        double d16 = motorista15.getKmsTotais();
        Veiculo veiculo17 = motorista15.getVeiculo();
        int i18 = motorista0.compareTo(motorista15);
        motorista0.setDisponibilidade(false);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista15 and motorista15", motorista15.equals(motorista15) ? motorista15.hashCode() == motorista15.hashCode() : true);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test271");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        motorista0.atualizaClassificacao(0);
        double d8 = motorista0.getKmsTotais();
        java.lang.String str9 = motorista0.getDataDeNascimento();
        Motorista motorista10 = new Motorista();
        java.lang.String str11 = motorista10.toString();
        java.util.GregorianCalendar gregorianCalendar12 = null;
        java.util.GregorianCalendar gregorianCalendar13 = null;
        double d14 = motorista10.totalFaturado(gregorianCalendar12, gregorianCalendar13);
        java.lang.Object obj15 = null;
        boolean b16 = motorista10.equals(obj15);
        int i17 = motorista10.getGrau();
        java.lang.String str18 = motorista10.getDataDeNascimento();
        int i19 = motorista0.compareTo((Ator) motorista10);
        motorista0.setDisponibilidade(true);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista10 and motorista10", motorista10.equals(motorista10) ? motorista10.hashCode() == motorista10.hashCode() : true);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test272");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        double d4 = motorista0.totalFaturado(gregorianCalendar2, gregorianCalendar3);
        motorista0.setDisponibilidade(false);
        int i7 = motorista0.getClassificacao();
        Veiculo veiculo13 = null;
        Motorista motorista14 = new Motorista("hi!", "hi!", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", veiculo13);
        int i15 = motorista14.getNumClassi();
        java.lang.String str16 = motorista14.getMail();
        Veiculo veiculo17 = motorista14.getVeiculo();
        int i18 = motorista0.compareTo((Ator) motorista14);
        java.lang.String str19 = motorista0.toString();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista14 and motorista14", motorista14.equals(motorista14) ? motorista14.hashCode() == motorista14.hashCode() : true);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test273");
        Motorista motorista0 = new Motorista();
        double d1 = motorista0.totalFaturado();
        motorista0.setDisponibilidade(false);
        Veiculo veiculo4 = null;
        motorista0.setVeiculo(veiculo4);
        int i6 = motorista0.getClassificacao();
        Veiculo veiculo12 = null;
        Motorista motorista13 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "hi!", "hi!", veiculo12);
        motorista13.atualizaClassificacao(100);
        int i16 = motorista0.compareTo((Ator) motorista13);
        java.lang.String str17 = motorista0.getMail();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista13 and motorista13", motorista13.equals(motorista13) ? motorista13.hashCode() == motorista13.hashCode() : true);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test274");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        motorista0.atualizaClassificacao(0);
        double d8 = motorista0.getKmsTotais();
        java.lang.String str9 = motorista0.getDataDeNascimento();
        Motorista motorista10 = new Motorista();
        java.lang.String str11 = motorista10.toString();
        java.util.GregorianCalendar gregorianCalendar12 = null;
        java.util.GregorianCalendar gregorianCalendar13 = null;
        double d14 = motorista10.totalFaturado(gregorianCalendar12, gregorianCalendar13);
        java.lang.Object obj15 = null;
        boolean b16 = motorista10.equals(obj15);
        int i17 = motorista10.getGrau();
        java.lang.String str18 = motorista10.getDataDeNascimento();
        int i19 = motorista0.compareTo((Ator) motorista10);
        boolean b20 = motorista0.getDisponibilidade();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista10 and motorista10", motorista10.equals(motorista10) ? motorista10.hashCode() == motorista10.hashCode() : true);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test275");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        Veiculo veiculo6 = motorista0.getVeiculo();
        java.lang.String str7 = motorista0.getMorada();
        Motorista motorista8 = motorista0.clone();
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test276");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        double d9 = motorista0.totalFaturado();
        java.lang.String str10 = motorista0.toString();
        double d11 = motorista0.totalFaturado();
        motorista0.setDisponibilidade(false);
        Motorista motorista14 = new Motorista();
        int i15 = motorista14.getGrau();
        boolean b17 = motorista14.equals((java.lang.Object) (byte) 10);
        Veiculo veiculo18 = motorista14.getVeiculo();
        java.lang.String str19 = motorista14.getMorada();
        java.lang.String str20 = motorista14.getNome();
        boolean b21 = motorista0.equals((java.lang.Object) motorista14);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test277");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        double d4 = motorista0.totalFaturado(gregorianCalendar2, gregorianCalendar3);
        double d5 = motorista0.getKmsTotais();
        motorista0.setDisponibilidade(true);
        java.lang.String str8 = motorista0.getMorada();
        double d9 = motorista0.getKmsTotais();
        Motorista motorista10 = new Motorista();
        int i11 = motorista10.getGrau();
        boolean b13 = motorista10.equals((java.lang.Object) (byte) 10);
        int i14 = motorista10.getGrau();
        java.lang.String str15 = motorista10.getNome();
        int i16 = motorista10.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar17 = null;
        java.util.GregorianCalendar gregorianCalendar18 = null;
        double d19 = motorista10.totalFaturado(gregorianCalendar17, gregorianCalendar18);
        java.util.GregorianCalendar gregorianCalendar20 = null;
        java.util.GregorianCalendar gregorianCalendar21 = null;
        double d22 = motorista10.totalFaturado(gregorianCalendar20, gregorianCalendar21);
        int i23 = motorista0.compareTo((Ator) motorista10);
        Veiculo veiculo29 = null;
        Motorista motorista30 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", "", veiculo29);
        double d31 = motorista30.totalFaturado();
        java.util.GregorianCalendar gregorianCalendar32 = null;
        java.util.GregorianCalendar gregorianCalendar33 = null;
        double d34 = motorista30.totalFaturado(gregorianCalendar32, gregorianCalendar33);
        int i35 = motorista0.compareTo((Ator) motorista30);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista10 and motorista10", motorista10.equals(motorista10) ? motorista10.hashCode() == motorista10.hashCode() : true);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test278");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        double d2 = motorista0.getKmsTotais();
        int i3 = motorista0.getClassificacao();
        Motorista motorista4 = new Motorista();
        Veiculo veiculo5 = motorista4.getVeiculo();
        java.lang.String str6 = motorista4.getMail();
        int i7 = motorista4.getNumClassi();
        motorista4.atualizaClassificacao((int) (byte) 10);
        int i10 = motorista4.getNumClassi();
        java.lang.String str11 = motorista4.getNome();
        int i12 = motorista4.getClassificacao();
        java.util.GregorianCalendar gregorianCalendar13 = null;
        java.util.GregorianCalendar gregorianCalendar14 = null;
        double d15 = motorista4.totalFaturado(gregorianCalendar13, gregorianCalendar14);
        Veiculo veiculo16 = null;
        motorista4.setVeiculo(veiculo16);
        motorista4.setDisponibilidade(false);
        int i20 = motorista0.compareTo((Ator) motorista4);
        double d21 = motorista4.totalFaturado();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test279");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        int i2 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao(0);
        motorista0.atualizaClassificacao(100);
        double d8 = motorista0.tempoViagem((double) 100.0f);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test280");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        java.lang.String str8 = motorista0.getMorada();
        boolean b9 = motorista0.getDisponibilidade();
        java.lang.String str10 = motorista0.getNome();
        double d12 = motorista0.tempoViagem(100.0d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test281");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.lang.String str2 = motorista0.getMail();
        java.lang.String str3 = motorista0.getMail();
        motorista0.atualizaClassificacao((int) (byte) 1);
        double d6 = motorista0.getKmsTotais();
        Motorista motorista7 = new Motorista(motorista0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test282");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar4 = null;
        java.util.GregorianCalendar gregorianCalendar5 = null;
        double d6 = motorista0.totalFaturado(gregorianCalendar4, gregorianCalendar5);
        java.lang.String str7 = motorista0.getMorada();
        int i8 = motorista0.getGrau();
        Motorista motorista9 = new Motorista();
        double d10 = motorista9.totalFaturado();
        int i11 = motorista9.getGrau();
        boolean b12 = motorista9.getDisponibilidade();
        int i13 = motorista9.getClassificacao();
        motorista9.atualizaClassificacao((int) '#');
        int i16 = motorista0.compareTo(motorista9);
        java.lang.String str17 = motorista9.toString();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test283");
        Motorista motorista0 = new Motorista();
        double d1 = motorista0.totalFaturado();
        motorista0.setDisponibilidade(false);
        int i4 = motorista0.getNumClassi();
        java.lang.String str5 = motorista0.getMail();
        java.lang.String str6 = motorista0.getPassword();
        double d8 = motorista0.precoViagem((double) (-1));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test284");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        double d9 = motorista0.totalFaturado();
        java.lang.String str10 = motorista0.toString();
        boolean b12 = motorista0.equals((java.lang.Object) 1.0d);
        java.lang.String str13 = motorista0.getMorada();
        Motorista motorista14 = new Motorista(motorista0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test285");
        Motorista motorista0 = new Motorista();
        double d1 = motorista0.totalFaturado();
        int i2 = motorista0.getGrau();
        boolean b3 = motorista0.getDisponibilidade();
        int i4 = motorista0.getClassificacao();
        java.util.GregorianCalendar gregorianCalendar5 = null;
        java.util.GregorianCalendar gregorianCalendar6 = null;
        double d7 = motorista0.totalFaturado(gregorianCalendar5, gregorianCalendar6);
        Motorista motorista8 = new Motorista();
        Veiculo veiculo9 = motorista8.getVeiculo();
        java.lang.String str10 = motorista8.getMail();
        int i11 = motorista8.getNumClassi();
        motorista8.atualizaClassificacao((int) (byte) 10);
        int i14 = motorista8.getNumClassi();
        java.lang.String str15 = motorista8.getNome();
        int i16 = motorista8.getClassificacao();
        java.lang.String str17 = motorista8.getMail();
        java.lang.String str18 = motorista8.toString();
        double d19 = motorista8.getKmsTotais();
        Motorista motorista20 = new Motorista();
        java.lang.String str21 = motorista20.toString();
        java.util.GregorianCalendar gregorianCalendar22 = null;
        java.util.GregorianCalendar gregorianCalendar23 = null;
        double d24 = motorista20.totalFaturado(gregorianCalendar22, gregorianCalendar23);
        double d25 = motorista20.getKmsTotais();
        motorista20.setDisponibilidade(true);
        java.lang.String str28 = motorista20.getMorada();
        double d29 = motorista20.getKmsTotais();
        int i30 = motorista8.compareTo((Ator) motorista20);
        int i31 = motorista0.compareTo(motorista20);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista8 and motorista8", motorista8.equals(motorista8) ? motorista8.hashCode() == motorista8.hashCode() : true);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test286");
        Motorista motorista0 = new Motorista();
        double d1 = motorista0.totalFaturado();
        motorista0.setDisponibilidade(false);
        motorista0.setDisponibilidade(false);
        Veiculo veiculo11 = null;
        Motorista motorista12 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "hi!", "hi!", veiculo11);
        motorista12.atualizaClassificacao(100);
        motorista12.atualizaClassificacao((int) (short) 1);
        Veiculo veiculo17 = motorista12.getVeiculo();
        Veiculo veiculo18 = null;
        motorista12.setVeiculo(veiculo18);
        int i20 = motorista0.compareTo((Ator) motorista12);
        java.lang.String str21 = motorista0.getMail();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista12 and motorista12", motorista12.equals(motorista12) ? motorista12.hashCode() == motorista12.hashCode() : true);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test287");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", veiculo5);
        double d7 = motorista6.totalFaturado();
        Motorista motorista8 = new Motorista();
        int i9 = motorista8.getGrau();
        Veiculo veiculo10 = motorista8.getVeiculo();
        double d11 = motorista8.getKmsTotais();
        motorista8.setDisponibilidade(true);
        java.lang.String str14 = motorista8.getPassword();
        boolean b15 = motorista8.getDisponibilidade();
        int i16 = motorista6.compareTo((Ator) motorista8);
        int i17 = motorista6.getNumClassi();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista8 and motorista8", motorista8.equals(motorista8) ? motorista8.hashCode() == motorista8.hashCode() : true);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test288");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        java.lang.String str2 = motorista0.getPassword();
        motorista0.atualizaClassificacao(0);
        motorista0.setDisponibilidade(true);
        Motorista motorista7 = new Motorista(motorista0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test289");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
        Veiculo veiculo12 = null;
        Motorista motorista13 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "hi!", "hi!", veiculo12);
        motorista13.atualizaClassificacao(100);
        int i16 = motorista6.compareTo(motorista13);
        Motorista motorista17 = new Motorista();
        Veiculo veiculo18 = motorista17.getVeiculo();
        java.lang.String str19 = motorista17.getMail();
        int i20 = motorista17.getNumClassi();
        motorista17.atualizaClassificacao((int) (byte) 10);
        int i23 = motorista17.getNumClassi();
        java.lang.String str24 = motorista17.getNome();
        int i25 = motorista17.getClassificacao();
        double d26 = motorista17.totalFaturado();
        java.lang.String str27 = motorista17.toString();
        boolean b29 = motorista17.equals((java.lang.Object) 1.0d);
        java.lang.String str30 = motorista17.getMorada();
        double d31 = motorista17.getKmsTotais();
        int i32 = motorista17.getGrau();
        int i33 = motorista13.compareTo((Ator) motorista17);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista6 and motorista6", motorista6.equals(motorista6) ? motorista6.hashCode() == motorista6.hashCode() : true);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test290");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.lang.String str2 = motorista0.toString();
        java.lang.String str3 = motorista0.getDataDeNascimento();
        java.lang.String str4 = motorista0.getPassword();
        double d6 = motorista0.precoViagem((double) ' ');
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test291");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        Veiculo veiculo2 = motorista0.getVeiculo();
        java.util.Set<Viagem> set_viagem3 = motorista0.getHistorico();
        Motorista motorista4 = new Motorista();
        Veiculo veiculo5 = motorista4.getVeiculo();
        java.lang.String str6 = motorista4.getMail();
        boolean b7 = motorista4.getDisponibilidade();
        boolean b8 = motorista4.getDisponibilidade();
        java.lang.String str9 = motorista4.getDataDeNascimento();
        int i10 = motorista0.compareTo((Ator) motorista4);
        Veiculo veiculo11 = motorista0.getVeiculo();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista4 and motorista4", motorista4.equals(motorista4) ? motorista4.hashCode() == motorista4.hashCode() : true);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test292");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        int i2 = motorista0.getNumClassi();
        Veiculo veiculo3 = motorista0.getVeiculo();
        Veiculo veiculo9 = null;
        Motorista motorista10 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "", veiculo9);
        int i11 = motorista10.getGrau();
        int i12 = motorista0.compareTo((Ator) motorista10);
        int i13 = motorista0.getClassificacao();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista10 and motorista10", motorista10.equals(motorista10) ? motorista10.hashCode() == motorista10.hashCode() : true);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test293");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        int i2 = motorista0.getNumClassi();
        java.util.Set<Viagem> set_viagem3 = motorista0.getHistorico();
        double d5 = motorista0.tempoViagem((double) (short) 0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test294");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        Veiculo veiculo2 = motorista0.getVeiculo();
        java.util.Set<Viagem> set_viagem3 = motorista0.getHistorico();
        Motorista motorista4 = new Motorista();
        Veiculo veiculo5 = motorista4.getVeiculo();
        java.lang.String str6 = motorista4.getMail();
        boolean b7 = motorista4.getDisponibilidade();
        boolean b8 = motorista4.getDisponibilidade();
        java.lang.String str9 = motorista4.getDataDeNascimento();
        int i10 = motorista0.compareTo((Ator) motorista4);
        double d12 = motorista0.tempoViagem((double) ' ');
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test295");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        boolean b3 = motorista0.equals((java.lang.Object) (byte) 10);
        Motorista motorista4 = new Motorista();
        int i5 = motorista4.getGrau();
        boolean b7 = motorista4.equals((java.lang.Object) (byte) 10);
        int i8 = motorista0.compareTo((Ator) motorista4);
        int i9 = motorista0.getNumClassi();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista4 and motorista4", motorista4.equals(motorista4) ? motorista4.hashCode() == motorista4.hashCode() : true);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test296");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        java.lang.String str4 = motorista0.getDataDeNascimento();
        double d5 = motorista0.totalFaturado();
        double d7 = motorista0.precoViagem((double) (short) -1);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test297");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        java.lang.String str2 = motorista0.getMorada();
        int i3 = motorista0.getClassificacao();
        Motorista motorista4 = motorista0.clone();
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test298");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "", veiculo5);
        int i7 = motorista6.getGrau();
        boolean b8 = motorista6.getDisponibilidade();
        Motorista motorista9 = new Motorista();
        Veiculo veiculo10 = motorista9.getVeiculo();
        java.lang.String str11 = motorista9.getMail();
        int i12 = motorista9.getNumClassi();
        motorista9.atualizaClassificacao((int) (byte) 10);
        int i15 = motorista9.getNumClassi();
        java.lang.String str16 = motorista9.getNome();
        int i17 = motorista9.getClassificacao();
        double d18 = motorista9.totalFaturado();
        java.util.GregorianCalendar gregorianCalendar19 = null;
        java.util.GregorianCalendar gregorianCalendar20 = null;
        double d21 = motorista9.totalFaturado(gregorianCalendar19, gregorianCalendar20);
        int i22 = motorista6.compareTo(motorista9);
        motorista6.atualizaClassificacao((int) ' ');
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista9 and motorista9", motorista9.equals(motorista9) ? motorista9.hashCode() == motorista9.hashCode() : true);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test299");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        java.lang.String str6 = motorista0.getNome();
        Motorista motorista7 = new Motorista();
        java.lang.String str8 = motorista7.getPassword();
        motorista7.atualizaClassificacao(100);
        java.util.GregorianCalendar gregorianCalendar11 = null;
        java.util.GregorianCalendar gregorianCalendar12 = null;
        double d13 = motorista7.totalFaturado(gregorianCalendar11, gregorianCalendar12);
        boolean b14 = motorista0.equals((java.lang.Object) d13);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista7 and motorista7", motorista7.equals(motorista7) ? motorista7.hashCode() == motorista7.hashCode() : true);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test300");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        java.lang.String str9 = motorista0.getMail();
        java.util.GregorianCalendar gregorianCalendar10 = null;
        java.util.GregorianCalendar gregorianCalendar11 = null;
        double d12 = motorista0.totalFaturado(gregorianCalendar10, gregorianCalendar11);
        Motorista motorista13 = new Motorista();
        java.lang.String str14 = motorista13.toString();
        java.util.GregorianCalendar gregorianCalendar15 = null;
        java.util.GregorianCalendar gregorianCalendar16 = null;
        double d17 = motorista13.totalFaturado(gregorianCalendar15, gregorianCalendar16);
        motorista13.setDisponibilidade(false);
        java.lang.String str20 = motorista13.getPassword();
        int i21 = motorista13.getGrau();
        Motorista motorista22 = new Motorista();
        int i23 = motorista22.getGrau();
        Veiculo veiculo24 = motorista22.getVeiculo();
        java.lang.String str25 = motorista22.toString();
        java.lang.String str26 = motorista22.getNome();
        int i27 = motorista22.getGrau();
        int i28 = motorista13.compareTo((Ator) motorista22);
        int i29 = motorista0.compareTo(motorista22);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista13 and motorista13", motorista13.equals(motorista13) ? motorista13.hashCode() == motorista13.hashCode() : true);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test301");
        Motorista motorista0 = new Motorista();
        java.lang.String str1 = motorista0.toString();
        java.util.GregorianCalendar gregorianCalendar2 = null;
        java.util.GregorianCalendar gregorianCalendar3 = null;
        double d4 = motorista0.totalFaturado(gregorianCalendar2, gregorianCalendar3);
        motorista0.setDisponibilidade(false);
        java.lang.String str7 = motorista0.getPassword();
        int i8 = motorista0.getGrau();
        Motorista motorista9 = new Motorista();
        int i10 = motorista9.getGrau();
        Veiculo veiculo11 = motorista9.getVeiculo();
        java.lang.String str12 = motorista9.toString();
        java.lang.String str13 = motorista9.getNome();
        int i14 = motorista9.getGrau();
        int i15 = motorista0.compareTo((Ator) motorista9);
        motorista9.setDisponibilidade(true);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test302");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        boolean b3 = motorista0.equals((java.lang.Object) (byte) 10);
        Motorista motorista4 = new Motorista();
        int i5 = motorista4.getGrau();
        boolean b7 = motorista4.equals((java.lang.Object) (byte) 10);
        int i8 = motorista0.compareTo((Ator) motorista4);
        java.lang.String str9 = motorista4.getPassword();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test303");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        boolean b8 = motorista0.equals((java.lang.Object) (byte) 0);
        Veiculo veiculo14 = null;
        Motorista motorista15 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo14);
        double d16 = motorista15.getKmsTotais();
        Veiculo veiculo17 = motorista15.getVeiculo();
        int i18 = motorista0.compareTo(motorista15);
        int i19 = motorista15.getNumClassi();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test304");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        Motorista motorista2 = new Motorista();
        Veiculo veiculo3 = motorista2.getVeiculo();
        java.lang.String str4 = motorista2.getMail();
        int i5 = motorista0.compareTo((Ator) motorista2);
        Motorista motorista6 = new Motorista(motorista2);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test305");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar4 = null;
        java.util.GregorianCalendar gregorianCalendar5 = null;
        double d6 = motorista0.totalFaturado(gregorianCalendar4, gregorianCalendar5);
        java.lang.String str7 = motorista0.getMorada();
        int i8 = motorista0.getGrau();
        Motorista motorista9 = new Motorista();
        double d10 = motorista9.totalFaturado();
        int i11 = motorista9.getGrau();
        boolean b12 = motorista9.getDisponibilidade();
        int i13 = motorista9.getClassificacao();
        motorista9.atualizaClassificacao((int) '#');
        int i16 = motorista0.compareTo(motorista9);
        int i17 = motorista9.getGrau();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test306");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        boolean b3 = motorista0.equals((java.lang.Object) (byte) 10);
        Motorista motorista4 = new Motorista();
        int i5 = motorista4.getGrau();
        boolean b7 = motorista4.equals((java.lang.Object) (byte) 10);
        int i8 = motorista0.compareTo((Ator) motorista4);
        int i9 = motorista4.getClassificacao();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test307");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("", "hi!", "hi!", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", veiculo5);
        Motorista motorista7 = new Motorista();
        int i8 = motorista7.getGrau();
        Veiculo veiculo9 = motorista7.getVeiculo();
        int i10 = motorista7.getNumClassi();
        motorista7.atualizaClassificacao(100);
        int i13 = motorista6.compareTo(motorista7);
        java.lang.String str14 = motorista7.toString();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista6 and motorista6", motorista6.equals(motorista6) ? motorista6.hashCode() == motorista6.hashCode() : true);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test308");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        java.util.GregorianCalendar gregorianCalendar4 = null;
        java.util.GregorianCalendar gregorianCalendar5 = null;
        double d6 = motorista0.totalFaturado(gregorianCalendar4, gregorianCalendar5);
        java.lang.String str7 = motorista0.getMorada();
        int i8 = motorista0.getGrau();
        Motorista motorista9 = new Motorista();
        double d10 = motorista9.totalFaturado();
        int i11 = motorista9.getGrau();
        boolean b12 = motorista9.getDisponibilidade();
        int i13 = motorista9.getClassificacao();
        motorista9.atualizaClassificacao((int) '#');
        int i16 = motorista0.compareTo(motorista9);
        java.lang.String str17 = motorista0.getDataDeNascimento();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista9 and motorista9", motorista9.equals(motorista9) ? motorista9.hashCode() == motorista9.hashCode() : true);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test309");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        boolean b3 = motorista0.getDisponibilidade();
        int i4 = motorista0.getClassificacao();
        java.lang.String str5 = motorista0.getDataDeNascimento();
        Motorista motorista6 = new Motorista();
        Veiculo veiculo7 = motorista6.getVeiculo();
        java.lang.String str8 = motorista6.getMail();
        int i9 = motorista6.getNumClassi();
        motorista6.atualizaClassificacao((int) (byte) 10);
        motorista6.atualizaClassificacao(0);
        double d14 = motorista6.getKmsTotais();
        java.lang.String str15 = motorista6.getDataDeNascimento();
        int i16 = motorista0.compareTo((Ator) motorista6);
        Veiculo veiculo17 = motorista6.getVeiculo();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista0 and motorista0", motorista0.equals(motorista0) ? motorista0.hashCode() == motorista0.hashCode() : true);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test310");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        int i8 = motorista0.getClassificacao();
        motorista0.setDisponibilidade(true);
        Motorista motorista11 = new Motorista();
        double d12 = motorista11.totalFaturado();
        int i13 = motorista11.getGrau();
        int i14 = motorista0.compareTo((Ator) motorista11);
        java.lang.String str15 = motorista0.getNome();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista11 and motorista11", motorista11.equals(motorista11) ? motorista11.hashCode() == motorista11.hashCode() : true);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test311");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        Veiculo veiculo11 = null;
        Motorista motorista12 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo11);
        int i13 = motorista0.compareTo(motorista12);
        Veiculo veiculo14 = motorista0.getVeiculo();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista12 and motorista12", motorista12.equals(motorista12) ? motorista12.hashCode() == motorista12.hashCode() : true);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test312");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("hi!", "E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: true\n", veiculo5);
        double d7 = motorista6.totalFaturado();
        Motorista motorista8 = new Motorista();
        int i9 = motorista8.getGrau();
        java.lang.String str10 = motorista8.getPassword();
        boolean b11 = motorista6.equals((java.lang.Object) str10);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista8 and motorista8", motorista8.equals(motorista8) ? motorista8.hashCode() == motorista8.hashCode() : true);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test313");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nNome: hi!\nPassword: hi!\nMorada: hi!\nData de nascimento: hi!\nGrau de cumprimento de horário: 100\nClassificação do motorista: 50\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 5\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", "E-mail: hi!\nNome: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nPassword: E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nMorada: hi!\nData de nascimento: \nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", veiculo5);
        Motorista motorista7 = new Motorista();
        Veiculo veiculo8 = motorista7.getVeiculo();
        java.lang.String str9 = motorista7.getMail();
        int i10 = motorista7.getNumClassi();
        motorista7.atualizaClassificacao((int) (byte) 10);
        int i13 = motorista7.getNumClassi();
        java.lang.String str14 = motorista7.getNome();
        int i15 = motorista7.getClassificacao();
        double d16 = motorista7.totalFaturado();
        motorista7.atualizaClassificacao((int) (short) 1);
        int i19 = motorista6.compareTo((Ator) motorista7);
        java.lang.String str20 = motorista6.toString();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista7 and motorista7", motorista7.equals(motorista7) ? motorista7.hashCode() == motorista7.hashCode() : true);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test314");
        Motorista motorista0 = new Motorista();
        int i1 = motorista0.getGrau();
        boolean b3 = motorista0.equals((java.lang.Object) (byte) 10);
        int i4 = motorista0.getGrau();
        Motorista motorista5 = new Motorista(motorista0);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test315");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        double d5 = motorista0.precoViagem((double) (byte) 10);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test316");
        Veiculo veiculo5 = null;
        Motorista motorista6 = new Motorista("E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 0\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "", "", veiculo5);
        int i7 = motorista6.getClassificacao();
        int i8 = motorista6.getClassificacao();
        int i9 = motorista6.getClassificacao();
        Veiculo veiculo15 = null;
        Motorista motorista16 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "", veiculo15);
        java.util.GregorianCalendar gregorianCalendar17 = null;
        java.util.GregorianCalendar gregorianCalendar18 = null;
        double d19 = motorista16.totalFaturado(gregorianCalendar17, gregorianCalendar18);
        int i20 = motorista6.compareTo((Ator) motorista16);
        int i21 = motorista6.getNumClassi();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista16 and motorista16", motorista16.equals(motorista16) ? motorista16.hashCode() == motorista16.hashCode() : true);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test317");
        Motorista motorista0 = new Motorista();
        Veiculo veiculo1 = motorista0.getVeiculo();
        java.lang.String str2 = motorista0.getMail();
        int i3 = motorista0.getNumClassi();
        motorista0.atualizaClassificacao((int) (byte) 10);
        int i6 = motorista0.getNumClassi();
        java.lang.String str7 = motorista0.getNome();
        java.lang.String str8 = motorista0.getMorada();
        Motorista motorista9 = new Motorista();
        Veiculo veiculo10 = motorista9.getVeiculo();
        java.lang.String str11 = motorista9.getMail();
        int i12 = motorista9.getNumClassi();
        motorista9.atualizaClassificacao((int) (byte) 10);
        int i15 = motorista9.getNumClassi();
        java.lang.String str16 = motorista9.getNome();
        int i17 = motorista9.getClassificacao();
        java.util.GregorianCalendar gregorianCalendar18 = null;
        java.util.GregorianCalendar gregorianCalendar19 = null;
        double d20 = motorista9.totalFaturado(gregorianCalendar18, gregorianCalendar19);
        Veiculo veiculo26 = null;
        Motorista motorista27 = new Motorista("", "E-mail: \nNome: \nPassword: \nMorada: \nData de nascimento: \nGrau de cumprimento de horário: 0\nClassificação do motorista: 10\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n", "hi!", "hi!", "", veiculo26);
        int i28 = motorista27.getGrau();
        int i29 = motorista9.compareTo((Ator) motorista27);
        int i30 = motorista0.compareTo(motorista27);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on motorista9 and motorista9", motorista9.equals(motorista9) ? motorista9.hashCode() == motorista9.hashCode() : true);
    }
}

