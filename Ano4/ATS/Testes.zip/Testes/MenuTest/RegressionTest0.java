import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test1() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test1");
        java.lang.String[] str_array0 = null;
        try {
            Menu menu1 = new Menu(str_array0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test2() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test2");
        java.lang.String[] str_array2 = new java.lang.String[] { "hi!", "hi!" };
        Menu menu3 = new Menu(str_array2);
        org.junit.Assert.assertNotNull(str_array2);
    }

    @Test
    public void test3() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test3");
        java.lang.String[] str_array6 = new java.lang.String[] { "hi!", "", "hi!", "hi!", "", "" };
        Menu menu7 = new Menu(str_array6);
        Menu menu8 = new Menu(str_array6);
        int i9 = menu8.getOpcao();
        int i10 = menu8.getOpcao();
        org.junit.Assert.assertNotNull(str_array6);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertTrue(i10 == 0);
    }

    @Test
    public void test4() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test4");
        java.lang.String[] str_array6 = new java.lang.String[] { "hi!", "", "hi!", "", "hi!", "hi!" };
        Menu menu7 = new Menu(str_array6);
        Menu menu8 = new Menu(str_array6);
        Menu menu9 = new Menu(str_array6);
        Menu menu10 = new Menu(str_array6);
        Menu menu11 = new Menu(str_array6);
        org.junit.Assert.assertNotNull(str_array6);
    }

    @Test
    public void test5() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test5");
        java.lang.String[] str_array6 = new java.lang.String[] { "hi!", "", "hi!", "hi!", "", "" };
        Menu menu7 = new Menu(str_array6);
        Menu menu8 = new Menu(str_array6);
        Menu menu9 = new Menu(str_array6);
        int i10 = menu9.getOpcao();
        int i11 = menu9.getOpcao();
        org.junit.Assert.assertNotNull(str_array6);
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i11 == 0);
    }
}

