import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ErrorTest0 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test01");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        Utilizadores utilizadores16 = utilizadores0.clone();
        java.lang.String str17 = utilizadores16.toString();
        Veiculo veiculo23 = null;
        utilizadores16.adiciona("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "", "", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", veiculo23);
        org.junit.Assert.assertTrue("Contract failed: equals-transitive on utilizadores16, utilizadores5, and utilizadores3.", !(utilizadores16.equals(utilizadores5) && utilizadores5.equals(utilizadores3)) || utilizadores16.equals(utilizadores3));
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test02");
        Utilizadores utilizadores0 = new Utilizadores();
        Utilizadores utilizadores1 = new Utilizadores();
        java.util.List<Cliente> list_cliente2 = utilizadores1.top10ClientesGastadores();
        Utilizadores utilizadores3 = new Utilizadores();
        utilizadores3.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista10 = utilizadores3.top5MotoristasComMaiorDesvio();
        int i11 = utilizadores1.compareTo(utilizadores3);
        int i12 = utilizadores0.compareTo(utilizadores1);
        Veiculo veiculo18 = null;
        utilizadores0.adiciona("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "", veiculo18);
        org.junit.Assert.assertTrue("Contract failed: equals-transitive on utilizadores0, utilizadores3, and utilizadores3.", !(utilizadores0.equals(utilizadores3) && utilizadores3.equals(utilizadores3)) || utilizadores0.equals(utilizadores3));
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test03");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        Utilizadores utilizadores16 = utilizadores0.clone();
        Veiculo veiculo22 = null;
        utilizadores16.adiciona("------- UMeR --------\n", "hi!", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\n", "", veiculo22);
        org.junit.Assert.assertTrue("Contract failed: equals-transitive on utilizadores16, utilizadores5, and list_cliente1.", !(utilizadores16.equals(utilizadores5) && utilizadores5.equals(list_cliente1)) || utilizadores16.equals(list_cliente1));
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test04");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        Utilizadores utilizadores16 = new Utilizadores();
        java.util.List<Cliente> list_cliente17 = utilizadores16.top10ClientesGastadores();
        Utilizadores utilizadores18 = new Utilizadores();
        Utilizadores utilizadores19 = new Utilizadores();
        java.util.List<Cliente> list_cliente20 = utilizadores19.top10ClientesGastadores();
        Utilizadores utilizadores21 = new Utilizadores();
        utilizadores21.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista28 = utilizadores21.top5MotoristasComMaiorDesvio();
        int i29 = utilizadores19.compareTo(utilizadores21);
        int i30 = utilizadores18.compareTo(utilizadores19);
        boolean b31 = utilizadores16.equals((java.lang.Object) utilizadores19);
        Utilizadores utilizadores32 = utilizadores16.clone();
        boolean b33 = utilizadores0.equals((java.lang.Object) utilizadores16);
        Utilizadores utilizadores34 = new Utilizadores();
        utilizadores34.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores34.adiciona("", "", "hi!", "", "");
        Ator ator48 = utilizadores34.getAtor("hi!");
        Utilizadores utilizadores49 = new Utilizadores(utilizadores34);
        Ator ator51 = utilizadores49.getAtor("");
        utilizadores0.adiciona(ator51);
        Utilizadores utilizadores53 = new Utilizadores();
        java.util.List<Cliente> list_cliente54 = utilizadores53.top10ClientesGastadores();
        Utilizadores utilizadores55 = new Utilizadores();
        utilizadores55.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista62 = utilizadores55.top5MotoristasComMaiorDesvio();
        int i63 = utilizadores53.compareTo(utilizadores55);
        Utilizadores utilizadores64 = new Utilizadores();
        java.util.List<Motorista> list_motorista65 = utilizadores64.top5MotoristasComMaiorDesvio();
        int i66 = utilizadores55.compareTo(utilizadores64);
        java.util.List<Motorista> list_motorista67 = utilizadores64.top5MotoristasComMaiorDesvio();
        utilizadores64.adiciona("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\n", "", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
        boolean b74 = utilizadores0.equals((java.lang.Object) "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
        Veiculo veiculo80 = null;
        utilizadores0.adiciona("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\n", "", veiculo80);
        org.junit.Assert.assertTrue("Contract failed: equals-transitive on utilizadores0, utilizadores49, and list_cliente54.", !(utilizadores0.equals(utilizadores49) && utilizadores49.equals(list_cliente54)) || utilizadores0.equals(list_cliente54));
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test05");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        boolean b3 = utilizadores0.equals((java.lang.Object) 100L);
        Utilizadores utilizadores4 = new Utilizadores();
        utilizadores4.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores4.adiciona("", "", "hi!", "", "");
        Ator ator18 = utilizadores4.getAtor("hi!");
        utilizadores0.adiciona(ator18);
        Veiculo veiculo25 = null;
        utilizadores0.adiciona("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "", "------- UMeR --------\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!", veiculo25);
        org.junit.Assert.assertTrue("Contract failed: equals-transitive on utilizadores0, utilizadores4, and utilizadores4.", !(utilizadores0.equals(utilizadores4) && utilizadores4.equals(utilizadores4)) || utilizadores0.equals(utilizadores4));
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test06");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        java.util.List<Motorista> list_motorista16 = utilizadores15.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores17 = new Utilizadores(utilizadores15);
        Utilizadores utilizadores18 = new Utilizadores();
        java.util.List<Cliente> list_cliente19 = utilizadores18.top10ClientesGastadores();
        Utilizadores utilizadores20 = new Utilizadores();
        Utilizadores utilizadores21 = new Utilizadores();
        java.util.List<Cliente> list_cliente22 = utilizadores21.top10ClientesGastadores();
        Utilizadores utilizadores23 = new Utilizadores();
        utilizadores23.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista30 = utilizadores23.top5MotoristasComMaiorDesvio();
        int i31 = utilizadores21.compareTo(utilizadores23);
        int i32 = utilizadores20.compareTo(utilizadores21);
        boolean b33 = utilizadores18.equals((java.lang.Object) utilizadores21);
        java.lang.String str34 = utilizadores18.toString();
        int i35 = utilizadores17.compareTo(utilizadores18);
        Veiculo veiculo41 = null;
        utilizadores18.adiciona("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\n", "hi!", "------- UMeR --------\n", "", veiculo41);
        org.junit.Assert.assertTrue("Contract failed: equals-transitive on utilizadores18, utilizadores23, and ator14.", !(utilizadores18.equals(utilizadores23) && utilizadores23.equals(ator14)) || utilizadores18.equals(ator14));
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test07");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        Utilizadores utilizadores16 = utilizadores0.clone();
        Utilizadores utilizadores17 = new Utilizadores();
        utilizadores17.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores17.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista30 = utilizadores17.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores31 = new Utilizadores();
        java.util.List<Cliente> list_cliente32 = utilizadores31.top10ClientesGastadores();
        Utilizadores utilizadores33 = new Utilizadores();
        Utilizadores utilizadores34 = new Utilizadores();
        java.util.List<Cliente> list_cliente35 = utilizadores34.top10ClientesGastadores();
        Utilizadores utilizadores36 = new Utilizadores();
        utilizadores36.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista43 = utilizadores36.top5MotoristasComMaiorDesvio();
        int i44 = utilizadores34.compareTo(utilizadores36);
        int i45 = utilizadores33.compareTo(utilizadores34);
        boolean b46 = utilizadores31.equals((java.lang.Object) utilizadores34);
        java.lang.String str47 = utilizadores31.toString();
        Utilizadores utilizadores48 = utilizadores31.clone();
        int i49 = utilizadores17.compareTo(utilizadores48);
        int i50 = utilizadores0.compareTo(utilizadores48);
        utilizadores48.adiciona("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\n\nNome: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: \nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\n\nNome: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: \nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "", "");
        Veiculo veiculo62 = null;
        utilizadores48.adiciona("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\n\nNome: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: \nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!", veiculo62);
        org.junit.Assert.assertTrue("Contract failed: equals-transitive on utilizadores48, utilizadores15, and utilizadores15.", !(utilizadores48.equals(utilizadores15) && utilizadores15.equals(utilizadores15)) || utilizadores48.equals(utilizadores15));
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test08");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        utilizadores2.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista9 = utilizadores2.top5MotoristasComMaiorDesvio();
        int i10 = utilizadores0.compareTo(utilizadores2);
        Veiculo veiculo16 = null;
        utilizadores0.adiciona("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\n\nNome: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: \nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", veiculo16);
        org.junit.Assert.assertTrue("Contract failed: equals-transitive on utilizadores0, utilizadores2, and utilizadores2.", !(utilizadores0.equals(utilizadores2) && utilizadores2.equals(utilizadores2)) || utilizadores0.equals(utilizadores2));
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test09");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        Utilizadores utilizadores16 = new Utilizadores();
        utilizadores16.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores16.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista29 = utilizadores16.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator30 = utilizadores16.getUtilizadores();
        java.lang.String str31 = utilizadores16.toString();
        int i32 = utilizadores0.compareTo(utilizadores16);
        Utilizadores utilizadores33 = utilizadores0.clone();
        Veiculo veiculo39 = null;
        utilizadores33.adiciona("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\n\nNome: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: \nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", veiculo39);
        org.junit.Assert.assertTrue("Contract failed: equals-transitive on utilizadores33, utilizadores5, and utilizadores5.", !(utilizadores33.equals(utilizadores5) && utilizadores5.equals(utilizadores5)) || utilizadores33.equals(utilizadores5));
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test10");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        Utilizadores utilizadores16 = new Utilizadores();
        java.util.List<Cliente> list_cliente17 = utilizadores16.top10ClientesGastadores();
        Utilizadores utilizadores18 = new Utilizadores();
        Utilizadores utilizadores19 = new Utilizadores();
        java.util.List<Cliente> list_cliente20 = utilizadores19.top10ClientesGastadores();
        Utilizadores utilizadores21 = new Utilizadores();
        utilizadores21.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista28 = utilizadores21.top5MotoristasComMaiorDesvio();
        int i29 = utilizadores19.compareTo(utilizadores21);
        int i30 = utilizadores18.compareTo(utilizadores19);
        boolean b31 = utilizadores16.equals((java.lang.Object) utilizadores19);
        Utilizadores utilizadores32 = utilizadores16.clone();
        boolean b33 = utilizadores0.equals((java.lang.Object) utilizadores16);
        Utilizadores utilizadores34 = new Utilizadores();
        utilizadores34.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores34.adiciona("", "", "hi!", "", "");
        Ator ator48 = utilizadores34.getAtor("hi!");
        Utilizadores utilizadores49 = new Utilizadores(utilizadores34);
        Ator ator51 = utilizadores49.getAtor("");
        utilizadores0.adiciona(ator51);
        Utilizadores utilizadores53 = utilizadores0.clone();
        Utilizadores utilizadores54 = new Utilizadores(utilizadores0);
        Veiculo veiculo60 = null;
        utilizadores54.adiciona("hi!", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", veiculo60);
        org.junit.Assert.assertTrue("Contract failed: equals-transitive on utilizadores54, utilizadores34, and utilizadores0.", !(utilizadores54.equals(utilizadores34) && utilizadores34.equals(utilizadores0)) || utilizadores54.equals(utilizadores0));
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test11");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        java.lang.String str16 = utilizadores0.toString();
        Utilizadores utilizadores17 = utilizadores0.clone();
        Utilizadores utilizadores18 = new Utilizadores(utilizadores17);
        Veiculo veiculo24 = null;
        utilizadores18.adiciona("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\n", "hi!", "", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", veiculo24);
        org.junit.Assert.assertTrue("Contract failed: equals-transitive on utilizadores18, utilizadores5, and utilizadores3.", !(utilizadores18.equals(utilizadores5) && utilizadores5.equals(utilizadores3)) || utilizadores18.equals(utilizadores3));
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test12");
        Utilizadores utilizadores0 = new Utilizadores();
        Utilizadores utilizadores1 = utilizadores0.clone();
        Veiculo veiculo7 = null;
        utilizadores0.adiciona("", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!", "", veiculo7);
        Ator ator10 = utilizadores0.getAtor("");
        java.util.List<Cliente> list_cliente11 = utilizadores0.top10ClientesGastadores();
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on ator10 and ator10", ator10.equals(ator10) ? ator10.hashCode() == ator10.hashCode() : true);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test13");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        Utilizadores utilizadores16 = new Utilizadores();
        java.util.List<Cliente> list_cliente17 = utilizadores16.top10ClientesGastadores();
        Utilizadores utilizadores18 = new Utilizadores();
        Utilizadores utilizadores19 = new Utilizadores();
        java.util.List<Cliente> list_cliente20 = utilizadores19.top10ClientesGastadores();
        Utilizadores utilizadores21 = new Utilizadores();
        utilizadores21.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista28 = utilizadores21.top5MotoristasComMaiorDesvio();
        int i29 = utilizadores19.compareTo(utilizadores21);
        int i30 = utilizadores18.compareTo(utilizadores19);
        boolean b31 = utilizadores16.equals((java.lang.Object) utilizadores19);
        Utilizadores utilizadores32 = utilizadores16.clone();
        boolean b33 = utilizadores0.equals((java.lang.Object) utilizadores16);
        Utilizadores utilizadores34 = new Utilizadores();
        utilizadores34.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores34.adiciona("", "", "hi!", "", "");
        Ator ator48 = utilizadores34.getAtor("hi!");
        Utilizadores utilizadores49 = new Utilizadores(utilizadores34);
        Ator ator51 = utilizadores49.getAtor("");
        utilizadores0.adiciona(ator51);
        Utilizadores utilizadores53 = utilizadores0.clone();
        Utilizadores utilizadores54 = new Utilizadores(utilizadores53);
        Veiculo veiculo60 = null;
        utilizadores53.adiciona("------- UMeR --------\nE-mail: \nNome: ------- UMeR --------\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nData de nascimento: ------- UMeR --------\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: \nPassword: ------- UMeR --------\n\nMorada: \nData de nascimento: ------- UMeR --------\n\nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\n\nNome: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: \nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\n\nNome: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: \nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: ------- UMeR --------\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nData de nascimento: ------- UMeR --------\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: \nPassword: ------- UMeR --------\n\nMorada: \nData de nascimento: ------- UMeR --------\n\nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\n", veiculo60);
        org.junit.Assert.assertTrue("Contract failed: equals-transitive on utilizadores53, utilizadores49, and utilizadores49.", !(utilizadores53.equals(utilizadores49) && utilizadores49.equals(utilizadores49)) || utilizadores53.equals(utilizadores49));
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test14");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        Utilizadores utilizadores16 = new Utilizadores();
        utilizadores16.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores16.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista29 = utilizadores16.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator30 = utilizadores16.getUtilizadores();
        java.lang.String str31 = utilizadores16.toString();
        int i32 = utilizadores0.compareTo(utilizadores16);
        Utilizadores utilizadores33 = utilizadores16.clone();
        java.util.Map<java.lang.String, Ator> map_str_ator34 = utilizadores33.getUtilizadores();
        Veiculo veiculo40 = null;
        utilizadores33.adiciona("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\n\nNome: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: \nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\n\nNome: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: \nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", veiculo40);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on map_str_ator34 and map_str_ator34", map_str_ator34.equals(map_str_ator34) ? map_str_ator34.hashCode() == map_str_ator34.hashCode() : true);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test15");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        Utilizadores utilizadores16 = new Utilizadores();
        java.util.List<Cliente> list_cliente17 = utilizadores16.top10ClientesGastadores();
        boolean b19 = utilizadores16.equals((java.lang.Object) 100L);
        Utilizadores utilizadores20 = new Utilizadores();
        utilizadores20.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores20.adiciona("", "", "hi!", "", "");
        Ator ator34 = utilizadores20.getAtor("hi!");
        utilizadores16.adiciona(ator34);
        utilizadores3.adiciona(ator34);
        java.util.List<Motorista> list_motorista37 = utilizadores3.top5MotoristasComMaiorDesvio();
        Veiculo veiculo43 = null;
        utilizadores3.adiciona("", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "", veiculo43);
        org.junit.Assert.assertTrue("Contract failed: equals-transitive on utilizadores3, utilizadores20, and utilizadores5.", !(utilizadores3.equals(utilizadores20) && utilizadores20.equals(utilizadores5)) || utilizadores3.equals(utilizadores5));
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test16");
        Utilizadores utilizadores0 = new Utilizadores();
        Utilizadores utilizadores1 = utilizadores0.clone();
        Veiculo veiculo7 = null;
        utilizadores0.adiciona("", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!", "", veiculo7);
        Ator ator10 = utilizadores0.getAtor("");
        Utilizadores utilizadores11 = new Utilizadores();
        utilizadores11.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores11.adiciona("", "", "hi!", "", "");
        java.lang.String str24 = utilizadores11.toString();
        boolean b26 = utilizadores11.equals((java.lang.Object) (short) 10);
        java.util.Map<java.lang.String, Ator> map_str_ator27 = utilizadores11.getUtilizadores();
        int i28 = utilizadores0.compareTo(utilizadores11);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on ator10 and ator10", ator10.equals(ator10) ? ator10.hashCode() == ator10.hashCode() : true);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test17");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        Utilizadores utilizadores16 = new Utilizadores();
        utilizadores16.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores16.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista29 = utilizadores16.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator30 = utilizadores16.getUtilizadores();
        java.lang.String str31 = utilizadores16.toString();
        int i32 = utilizadores0.compareTo(utilizadores16);
        Utilizadores utilizadores33 = utilizadores16.clone();
        utilizadores16.adiciona("------- UMeR --------\n", "hi!", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!", "hi!");
        Veiculo veiculo45 = null;
        utilizadores16.adiciona("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: ------- UMeR --------\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nData de nascimento: ------- UMeR --------\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: \nPassword: ------- UMeR --------\n\nMorada: \nData de nascimento: ------- UMeR --------\n\nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", veiculo45);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on map_str_ator30 and map_str_ator30", map_str_ator30.equals(map_str_ator30) ? map_str_ator30.hashCode() == map_str_ator30.hashCode() : true);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test18");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Motorista> list_motorista1 = utilizadores0.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores2 = new Utilizadores();
        boolean b4 = utilizadores2.equals((java.lang.Object) (short) 1);
        boolean b5 = utilizadores0.equals((java.lang.Object) b4);
        java.util.Map<java.lang.String, Ator> map_str_ator6 = utilizadores0.getUtilizadores();
        Veiculo veiculo12 = null;
        utilizadores0.adiciona("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\n\nNome: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: \nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\n\nNome: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: \nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\n", veiculo12);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on map_str_ator6 and map_str_ator6", map_str_ator6.equals(map_str_ator6) ? map_str_ator6.hashCode() == map_str_ator6.hashCode() : true);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test19");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        Utilizadores utilizadores16 = new Utilizadores();
        java.util.List<Cliente> list_cliente17 = utilizadores16.top10ClientesGastadores();
        Utilizadores utilizadores18 = new Utilizadores();
        Utilizadores utilizadores19 = new Utilizadores();
        java.util.List<Cliente> list_cliente20 = utilizadores19.top10ClientesGastadores();
        Utilizadores utilizadores21 = new Utilizadores();
        utilizadores21.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista28 = utilizadores21.top5MotoristasComMaiorDesvio();
        int i29 = utilizadores19.compareTo(utilizadores21);
        int i30 = utilizadores18.compareTo(utilizadores19);
        boolean b31 = utilizadores16.equals((java.lang.Object) utilizadores19);
        Utilizadores utilizadores32 = utilizadores16.clone();
        boolean b33 = utilizadores0.equals((java.lang.Object) utilizadores16);
        Utilizadores utilizadores34 = new Utilizadores();
        utilizadores34.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores34.adiciona("", "", "hi!", "", "");
        Ator ator48 = utilizadores34.getAtor("hi!");
        Utilizadores utilizadores49 = new Utilizadores(utilizadores34);
        Ator ator51 = utilizadores49.getAtor("");
        utilizadores0.adiciona(ator51);
        Veiculo veiculo58 = null;
        utilizadores0.adiciona("------- UMeR --------\n", "", "", "hi!", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", veiculo58);
        org.junit.Assert.assertTrue("Contract failed: equals-transitive on utilizadores0, utilizadores49, and list_motorista28.", !(utilizadores0.equals(utilizadores49) && utilizadores49.equals(list_motorista28)) || utilizadores0.equals(list_motorista28));
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test20");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores14 = new Utilizadores(utilizadores0);
        java.util.Map<java.lang.String, Ator> map_str_ator15 = utilizadores14.getUtilizadores();
        Utilizadores utilizadores16 = new Utilizadores(utilizadores14);
        Veiculo veiculo22 = null;
        utilizadores14.adiciona("------- UMeR --------\nE-mail: \nNome: ------- UMeR --------\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nData de nascimento: ------- UMeR --------\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: \nPassword: ------- UMeR --------\n\nMorada: \nData de nascimento: ------- UMeR --------\n\nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\n", "", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: ------- UMeR --------\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nData de nascimento: ------- UMeR --------\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: \nPassword: ------- UMeR --------\n\nMorada: \nData de nascimento: ------- UMeR --------\n\nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\n", veiculo22);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on map_str_ator15 and map_str_ator15", map_str_ator15.equals(map_str_ator15) ? map_str_ator15.hashCode() == map_str_ator15.hashCode() : true);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test21");
        Utilizadores utilizadores0 = new Utilizadores();
        Utilizadores utilizadores1 = new Utilizadores();
        java.util.List<Cliente> list_cliente2 = utilizadores1.top10ClientesGastadores();
        Utilizadores utilizadores3 = new Utilizadores();
        utilizadores3.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista10 = utilizadores3.top5MotoristasComMaiorDesvio();
        int i11 = utilizadores1.compareTo(utilizadores3);
        int i12 = utilizadores0.compareTo(utilizadores1);
        java.util.Map<java.lang.String, Ator> map_str_ator13 = utilizadores1.getUtilizadores();
        Utilizadores utilizadores14 = new Utilizadores();
        utilizadores14.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores14.adiciona("", "", "hi!", "", "");
        Ator ator28 = utilizadores14.getAtor("hi!");
        utilizadores1.adiciona(ator28);
        Utilizadores utilizadores30 = utilizadores1.clone();
        Veiculo veiculo36 = null;
        utilizadores1.adiciona("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\n\nNome: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: \nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", veiculo36);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on map_str_ator13 and map_str_ator13", map_str_ator13.equals(map_str_ator13) ? map_str_ator13.hashCode() == map_str_ator13.hashCode() : true);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test22");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        java.util.List<Motorista> list_motorista16 = utilizadores15.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores17 = new Utilizadores(utilizadores15);
        java.lang.String str18 = utilizadores17.toString();
        java.util.Map<java.lang.String, Ator> map_str_ator19 = utilizadores17.getUtilizadores();
        Veiculo veiculo25 = null;
        utilizadores17.adiciona("------- UMeR --------\nE-mail: \nNome: ------- UMeR --------\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nData de nascimento: ------- UMeR --------\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: \nPassword: ------- UMeR --------\n\nMorada: \nData de nascimento: ------- UMeR --------\n\nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\n", "hi!", "------- UMeR --------\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: ------- UMeR --------\n\nData de nascimento: hi!\nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\n", "------- UMeR --------\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: ------- UMeR --------\n\nData de nascimento: hi!\nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", veiculo25);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on map_str_ator19 and map_str_ator19", map_str_ator19.equals(map_str_ator19) ? map_str_ator19.hashCode() == map_str_ator19.hashCode() : true);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test23");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        Utilizadores utilizadores7 = utilizadores0.clone();
        Veiculo veiculo13 = null;
        utilizadores0.adiciona("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "", "------- UMeR --------\n", "", "------- UMeR --------\n", veiculo13);
        java.util.Map<java.lang.String, Ator> map_str_ator15 = utilizadores0.getUtilizadores();
        Utilizadores utilizadores16 = new Utilizadores();
        Utilizadores utilizadores17 = utilizadores16.clone();
        java.lang.String str18 = utilizadores17.toString();
        java.util.Map<java.lang.String, Ator> map_str_ator19 = utilizadores17.getUtilizadores();
        Utilizadores utilizadores20 = new Utilizadores(map_str_ator19);
        int i21 = utilizadores0.compareTo(utilizadores20);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on map_str_ator15 and map_str_ator15", map_str_ator15.equals(map_str_ator15) ? map_str_ator15.hashCode() == map_str_ator15.hashCode() : true);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test24");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores14 = new Utilizadores(utilizadores0);
        java.util.Map<java.lang.String, Ator> map_str_ator15 = utilizadores14.getUtilizadores();
        Utilizadores utilizadores16 = new Utilizadores(map_str_ator15);
        Utilizadores utilizadores17 = new Utilizadores(utilizadores16);
        Utilizadores utilizadores18 = new Utilizadores();
        Utilizadores utilizadores19 = utilizadores18.clone();
        Veiculo veiculo25 = null;
        utilizadores18.adiciona("", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!", "", veiculo25);
        Ator ator28 = utilizadores18.getAtor("");
        int i29 = utilizadores16.compareTo(utilizadores18);
        org.junit.Assert.assertTrue("Contract failed: equals-hashcode on ator28 and ator28", ator28.equals(ator28) ? ator28.hashCode() == ator28.hashCode() : true);
    }
}

