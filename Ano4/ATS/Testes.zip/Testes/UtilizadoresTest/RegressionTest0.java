import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        Utilizadores utilizadores0 = new Utilizadores();
        Ator ator1 = null;
        try {
            utilizadores0.adiciona(ator1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.util.Map<java.lang.String, Ator> map_str_ator0 = null;
        try {
            Utilizadores utilizadores1 = new Utilizadores(map_str_ator0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Veiculo veiculo18 = null;
        try {
            utilizadores0.adiciona("", "", "", "hi!", "", veiculo18);
            org.junit.Assert.fail("Expected exception of type EmailAlreadyInUseException");
        } catch (EmailAlreadyInUseException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        utilizadores0.adiciona("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
        Veiculo veiculo25 = null;
        try {
            utilizadores0.adiciona("hi!", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", veiculo25);
            org.junit.Assert.fail("Expected exception of type EmailAlreadyInUseException");
        } catch (EmailAlreadyInUseException e) {
        }
        org.junit.Assert.assertNotNull(list_motorista13);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        Veiculo veiculo12 = null;
        try {
            utilizadores0.adiciona("hi!", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "", "hi!", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", veiculo12);
            org.junit.Assert.fail("Expected exception of type EmailAlreadyInUseException");
        } catch (EmailAlreadyInUseException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        Utilizadores utilizadores7 = new Utilizadores();
        utilizadores7.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores7.adiciona("", "", "hi!", "", "");
        Ator ator21 = utilizadores7.getAtor("hi!");
        try {
            utilizadores0.adiciona(ator21);
            org.junit.Assert.fail("Expected exception of type EmailAlreadyInUseException");
        } catch (EmailAlreadyInUseException e) {
        }
        org.junit.Assert.assertNotNull(ator21);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores14 = new Utilizadores(utilizadores0);
        Veiculo veiculo20 = null;
        try {
            utilizadores14.adiciona("", "------- UMeR --------\n", "", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "", veiculo20);
            org.junit.Assert.fail("Expected exception of type EmailAlreadyInUseException");
        } catch (EmailAlreadyInUseException e) {
        }
        org.junit.Assert.assertNotNull(list_motorista13);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        java.lang.String str15 = utilizadores0.toString();
        Utilizadores utilizadores16 = new Utilizadores();
        utilizadores16.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores16.adiciona("", "", "hi!", "", "");
        Ator ator30 = utilizadores16.getAtor("hi!");
        try {
            utilizadores0.adiciona(ator30);
            org.junit.Assert.fail("Expected exception of type EmailAlreadyInUseException");
        } catch (EmailAlreadyInUseException e) {
        }
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str15.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertNotNull(ator30);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores14 = new Utilizadores(utilizadores0);
        Veiculo veiculo20 = null;
        utilizadores14.adiciona("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", veiculo20);
        Utilizadores utilizadores22 = null;
        try {
            int i23 = utilizadores14.compareTo(utilizadores22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(list_motorista13);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator14 = utilizadores0.getUtilizadores();
        Utilizadores utilizadores15 = new Utilizadores(map_str_ator14);
        Utilizadores utilizadores16 = new Utilizadores();
        java.util.List<Cliente> list_cliente17 = utilizadores16.top10ClientesGastadores();
        java.lang.String str18 = utilizadores16.toString();
        Utilizadores utilizadores19 = new Utilizadores();
        java.util.List<Motorista> list_motorista20 = utilizadores19.top5MotoristasComMaiorDesvio();
        boolean b21 = utilizadores16.equals((java.lang.Object) list_motorista20);
        boolean b22 = utilizadores15.equals((java.lang.Object) list_motorista20);
        try {
            Ator ator24 = utilizadores15.getAtor("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
            org.junit.Assert.fail("Expected exception of type EmailDoesNotExistException");
        } catch (EmailDoesNotExistException e) {
        }
        org.junit.Assert.assertNotNull(list_motorista13);
        org.junit.Assert.assertNotNull(map_str_ator14);
        org.junit.Assert.assertNotNull(list_cliente17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "------- UMeR --------\n" + "'", str18.equals("------- UMeR --------\n"));
        org.junit.Assert.assertNotNull(list_motorista20);
        org.junit.Assert.assertTrue(b21 == false);
        org.junit.Assert.assertTrue(b22 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        try {
            utilizadores0.adiciona("", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\n");
            org.junit.Assert.fail("Expected exception of type EmailAlreadyInUseException");
        } catch (EmailAlreadyInUseException e) {
        }
        org.junit.Assert.assertNotNull(ator14);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        java.util.List<Motorista> list_motorista16 = utilizadores15.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores17 = new Utilizadores(utilizadores15);
        Veiculo veiculo23 = null;
        try {
            utilizadores15.adiciona("hi!", "", "------- UMeR --------\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", veiculo23);
            org.junit.Assert.fail("Expected exception of type EmailAlreadyInUseException");
        } catch (EmailAlreadyInUseException e) {
        }
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(list_motorista16);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores14 = new Utilizadores();
        utilizadores14.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores14.adiciona("", "", "hi!", "", "");
        Ator ator28 = utilizadores14.getAtor("hi!");
        Utilizadores utilizadores29 = new Utilizadores(utilizadores14);
        boolean b30 = utilizadores0.equals((java.lang.Object) utilizadores29);
        java.lang.Object obj31 = null;
        boolean b32 = utilizadores29.equals(obj31);
        org.junit.Assert.assertNotNull(list_motorista13);
        org.junit.Assert.assertNotNull(ator28);
        org.junit.Assert.assertTrue(b30 == true);
        org.junit.Assert.assertTrue(b32 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista7 = utilizadores0.top5MotoristasComMaiorDesvio();
        try {
            Ator ator9 = utilizadores0.getAtor("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
            org.junit.Assert.fail("Expected exception of type EmailDoesNotExistException");
        } catch (EmailDoesNotExistException e) {
        }
        org.junit.Assert.assertNotNull(list_motorista7);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        java.util.List<Motorista> list_motorista16 = utilizadores15.top5MotoristasComMaiorDesvio();
        boolean b18 = utilizadores15.equals((java.lang.Object) 1);
        Utilizadores utilizadores19 = new Utilizadores();
        java.util.List<Cliente> list_cliente20 = utilizadores19.top10ClientesGastadores();
        boolean b22 = utilizadores19.equals((java.lang.Object) 100L);
        Utilizadores utilizadores23 = new Utilizadores();
        utilizadores23.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores23.adiciona("", "", "hi!", "", "");
        Ator ator37 = utilizadores23.getAtor("hi!");
        utilizadores19.adiciona(ator37);
        try {
            utilizadores15.adiciona(ator37);
            org.junit.Assert.fail("Expected exception of type EmailAlreadyInUseException");
        } catch (EmailAlreadyInUseException e) {
        }
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(list_motorista16);
        org.junit.Assert.assertTrue(b18 == false);
        org.junit.Assert.assertNotNull(list_cliente20);
        org.junit.Assert.assertTrue(b22 == false);
        org.junit.Assert.assertNotNull(ator37);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        utilizadores0.adiciona("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
        java.lang.String str20 = utilizadores0.toString();
        Ator ator22 = utilizadores0.getAtor("");
        Utilizadores utilizadores23 = new Utilizadores();
        Utilizadores utilizadores24 = new Utilizadores();
        java.util.List<Cliente> list_cliente25 = utilizadores24.top10ClientesGastadores();
        Utilizadores utilizadores26 = new Utilizadores();
        utilizadores26.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista33 = utilizadores26.top5MotoristasComMaiorDesvio();
        int i34 = utilizadores24.compareTo(utilizadores26);
        int i35 = utilizadores23.compareTo(utilizadores24);
        Utilizadores utilizadores36 = new Utilizadores();
        utilizadores36.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores36.adiciona("", "", "hi!", "", "");
        Ator ator50 = utilizadores36.getAtor("hi!");
        utilizadores24.adiciona(ator50);
        try {
            utilizadores0.adiciona(ator50);
            org.junit.Assert.fail("Expected exception of type EmailAlreadyInUseException");
        } catch (EmailAlreadyInUseException e) {
        }
        org.junit.Assert.assertNotNull(list_motorista13);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str20.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertNotNull(ator22);
        org.junit.Assert.assertNotNull(list_cliente25);
        org.junit.Assert.assertNotNull(list_motorista33);
        org.junit.Assert.assertTrue(i34 == (-1));
        org.junit.Assert.assertTrue(i35 == 0);
        org.junit.Assert.assertNotNull(ator50);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator14 = utilizadores0.getUtilizadores();
        Utilizadores utilizadores15 = new Utilizadores(map_str_ator14);
        Utilizadores utilizadores16 = new Utilizadores();
        utilizadores16.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores16.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista29 = utilizadores16.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator30 = utilizadores16.getUtilizadores();
        Utilizadores utilizadores31 = new Utilizadores(map_str_ator30);
        int i32 = utilizadores15.compareTo(utilizadores31);
        java.lang.String str33 = utilizadores15.toString();
        Utilizadores utilizadores34 = new Utilizadores();
        utilizadores34.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores34.adiciona("", "", "hi!", "", "");
        Ator ator48 = utilizadores34.getAtor("hi!");
        try {
            utilizadores15.adiciona(ator48);
            org.junit.Assert.fail("Expected exception of type EmailAlreadyInUseException");
        } catch (EmailAlreadyInUseException e) {
        }
        org.junit.Assert.assertNotNull(list_motorista13);
        org.junit.Assert.assertNotNull(map_str_ator14);
        org.junit.Assert.assertNotNull(list_motorista29);
        org.junit.Assert.assertNotNull(map_str_ator30);
        org.junit.Assert.assertTrue(i32 == 0);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str33.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertNotNull(ator48);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        Utilizadores utilizadores0 = null;
        try {
            Utilizadores utilizadores1 = new Utilizadores(utilizadores0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        utilizadores0.adiciona("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
        try {
            utilizadores0.adiciona("hi!", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "", "hi!", "------- UMeR --------\n");
            org.junit.Assert.fail("Expected exception of type EmailAlreadyInUseException");
        } catch (EmailAlreadyInUseException e) {
        }
        org.junit.Assert.assertNotNull(list_motorista13);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator14 = utilizadores0.getUtilizadores();
        Veiculo veiculo20 = null;
        try {
            utilizadores0.adiciona("hi!", "hi!", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", veiculo20);
            org.junit.Assert.fail("Expected exception of type EmailAlreadyInUseException");
        } catch (EmailAlreadyInUseException e) {
        }
        org.junit.Assert.assertNotNull(list_motorista13);
        org.junit.Assert.assertNotNull(map_str_ator14);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator14 = utilizadores0.getUtilizadores();
        Utilizadores utilizadores15 = new Utilizadores(map_str_ator14);
        Utilizadores utilizadores16 = new Utilizadores();
        utilizadores16.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores16.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista29 = utilizadores16.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator30 = utilizadores16.getUtilizadores();
        Utilizadores utilizadores31 = new Utilizadores(map_str_ator30);
        int i32 = utilizadores15.compareTo(utilizadores31);
        Utilizadores utilizadores33 = new Utilizadores();
        utilizadores33.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores33.adiciona("", "", "hi!", "", "");
        Ator ator47 = utilizadores33.getAtor("");
        try {
            utilizadores15.adiciona(ator47);
            org.junit.Assert.fail("Expected exception of type EmailAlreadyInUseException");
        } catch (EmailAlreadyInUseException e) {
        }
        org.junit.Assert.assertNotNull(list_motorista13);
        org.junit.Assert.assertNotNull(map_str_ator14);
        org.junit.Assert.assertNotNull(list_motorista29);
        org.junit.Assert.assertNotNull(map_str_ator30);
        org.junit.Assert.assertTrue(i32 == 0);
        org.junit.Assert.assertNotNull(ator47);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        java.util.List<Motorista> list_motorista16 = utilizadores15.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores17 = utilizadores15.clone();
        java.util.List<Cliente> list_cliente18 = utilizadores17.top10ClientesGastadores();
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(list_motorista16);
        org.junit.Assert.assertNotNull(utilizadores17);
        org.junit.Assert.assertNotNull(list_cliente18);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        java.util.List<Motorista> list_motorista16 = utilizadores15.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores17 = new Utilizadores(utilizadores15);
        Utilizadores utilizadores18 = new Utilizadores();
        java.util.List<Cliente> list_cliente19 = utilizadores18.top10ClientesGastadores();
        Utilizadores utilizadores20 = new Utilizadores();
        Utilizadores utilizadores21 = new Utilizadores();
        java.util.List<Cliente> list_cliente22 = utilizadores21.top10ClientesGastadores();
        Utilizadores utilizadores23 = new Utilizadores();
        utilizadores23.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista30 = utilizadores23.top5MotoristasComMaiorDesvio();
        int i31 = utilizadores21.compareTo(utilizadores23);
        int i32 = utilizadores20.compareTo(utilizadores21);
        boolean b33 = utilizadores18.equals((java.lang.Object) utilizadores21);
        java.lang.String str34 = utilizadores18.toString();
        int i35 = utilizadores17.compareTo(utilizadores18);
        Utilizadores utilizadores36 = new Utilizadores();
        Utilizadores utilizadores37 = utilizadores36.clone();
        Veiculo veiculo43 = null;
        utilizadores36.adiciona("", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!", "", veiculo43);
        Ator ator46 = utilizadores36.getAtor("");
        try {
            utilizadores18.adiciona(ator46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(list_motorista16);
        org.junit.Assert.assertNotNull(list_cliente19);
        org.junit.Assert.assertNotNull(list_cliente22);
        org.junit.Assert.assertNotNull(list_motorista30);
        org.junit.Assert.assertTrue(i31 == (-1));
        org.junit.Assert.assertTrue(i32 == 0);
        org.junit.Assert.assertTrue(b33 == true);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "------- UMeR --------\n" + "'", str34.equals("------- UMeR --------\n"));
        org.junit.Assert.assertTrue(i35 == 1);
        org.junit.Assert.assertNotNull(utilizadores37);
        org.junit.Assert.assertNotNull(ator46);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator14 = utilizadores0.getUtilizadores();
        Utilizadores utilizadores15 = new Utilizadores(map_str_ator14);
        Utilizadores utilizadores16 = new Utilizadores();
        utilizadores16.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores16.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista29 = utilizadores16.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator30 = utilizadores16.getUtilizadores();
        Utilizadores utilizadores31 = new Utilizadores(map_str_ator30);
        int i32 = utilizadores15.compareTo(utilizadores31);
        java.lang.String str33 = utilizadores15.toString();
        Utilizadores utilizadores34 = new Utilizadores();
        java.util.List<Cliente> list_cliente35 = utilizadores34.top10ClientesGastadores();
        boolean b37 = utilizadores34.equals((java.lang.Object) 100L);
        Utilizadores utilizadores38 = new Utilizadores();
        utilizadores38.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores38.adiciona("", "", "hi!", "", "");
        Ator ator52 = utilizadores38.getAtor("hi!");
        utilizadores34.adiciona(ator52);
        try {
            utilizadores15.adiciona(ator52);
            org.junit.Assert.fail("Expected exception of type EmailAlreadyInUseException");
        } catch (EmailAlreadyInUseException e) {
        }
        org.junit.Assert.assertNotNull(list_motorista13);
        org.junit.Assert.assertNotNull(map_str_ator14);
        org.junit.Assert.assertNotNull(list_motorista29);
        org.junit.Assert.assertNotNull(map_str_ator30);
        org.junit.Assert.assertTrue(i32 == 0);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str33.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertNotNull(list_cliente35);
        org.junit.Assert.assertTrue(b37 == false);
        org.junit.Assert.assertNotNull(ator52);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        Utilizadores utilizadores0 = new Utilizadores();
        Utilizadores utilizadores1 = utilizadores0.clone();
        java.util.Map<java.lang.String, Ator> map_str_ator2 = utilizadores1.getUtilizadores();
        Utilizadores utilizadores3 = new Utilizadores(map_str_ator2);
        org.junit.Assert.assertNotNull(utilizadores1);
        org.junit.Assert.assertNotNull(map_str_ator2);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        Utilizadores utilizadores16 = new Utilizadores();
        utilizadores16.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores16.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista29 = utilizadores16.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator30 = utilizadores16.getUtilizadores();
        java.lang.String str31 = utilizadores16.toString();
        int i32 = utilizadores0.compareTo(utilizadores16);
        Utilizadores utilizadores33 = utilizadores16.clone();
        java.util.Map<java.lang.String, Ator> map_str_ator34 = utilizadores33.getUtilizadores();
        Utilizadores utilizadores35 = new Utilizadores();
        java.util.List<Cliente> list_cliente36 = utilizadores35.top10ClientesGastadores();
        boolean b38 = utilizadores35.equals((java.lang.Object) 100L);
        Utilizadores utilizadores39 = new Utilizadores();
        utilizadores39.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores39.adiciona("", "", "hi!", "", "");
        Ator ator53 = utilizadores39.getAtor("hi!");
        utilizadores35.adiciona(ator53);
        try {
            utilizadores33.adiciona(ator53);
            org.junit.Assert.fail("Expected exception of type EmailAlreadyInUseException");
        } catch (EmailAlreadyInUseException e) {
        }
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_cliente4);
        org.junit.Assert.assertNotNull(list_motorista12);
        org.junit.Assert.assertTrue(i13 == (-1));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(b15 == true);
        org.junit.Assert.assertNotNull(list_motorista29);
        org.junit.Assert.assertNotNull(map_str_ator30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str31.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertTrue(i32 == (-1));
        org.junit.Assert.assertNotNull(utilizadores33);
        org.junit.Assert.assertNotNull(map_str_ator34);
        org.junit.Assert.assertNotNull(list_cliente36);
        org.junit.Assert.assertTrue(b38 == false);
        org.junit.Assert.assertNotNull(ator53);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        utilizadores0.adiciona("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
        java.lang.String str20 = utilizadores0.toString();
        Ator ator22 = utilizadores0.getAtor("");
        Veiculo veiculo28 = null;
        try {
            utilizadores0.adiciona("hi!", "", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\n", veiculo28);
            org.junit.Assert.fail("Expected exception of type EmailAlreadyInUseException");
        } catch (EmailAlreadyInUseException e) {
        }
        org.junit.Assert.assertNotNull(list_motorista13);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str20.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertNotNull(ator22);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        java.util.List<Motorista> list_motorista16 = utilizadores15.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores17 = new Utilizadores(utilizadores15);
        Utilizadores utilizadores18 = new Utilizadores();
        utilizadores18.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores18.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista31 = utilizadores18.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores32 = new Utilizadores(utilizadores18);
        int i33 = utilizadores17.compareTo(utilizadores18);
        Utilizadores utilizadores34 = new Utilizadores();
        utilizadores34.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores34.adiciona("", "", "hi!", "", "");
        Ator ator48 = utilizadores34.getAtor("hi!");
        Utilizadores utilizadores49 = new Utilizadores(utilizadores34);
        Ator ator51 = utilizadores49.getAtor("");
        try {
            utilizadores18.adiciona(ator51);
            org.junit.Assert.fail("Expected exception of type EmailAlreadyInUseException");
        } catch (EmailAlreadyInUseException e) {
        }
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(list_motorista16);
        org.junit.Assert.assertNotNull(list_motorista31);
        org.junit.Assert.assertTrue(i33 == 0);
        org.junit.Assert.assertNotNull(ator48);
        org.junit.Assert.assertNotNull(ator51);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        Utilizadores utilizadores0 = new Utilizadores();
        Utilizadores utilizadores1 = new Utilizadores();
        utilizadores1.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista8 = utilizadores1.top5MotoristasComMaiorDesvio();
        boolean b9 = utilizadores0.equals((java.lang.Object) list_motorista8);
        try {
            Ator ator11 = utilizadores0.getAtor("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
            org.junit.Assert.fail("Expected exception of type EmailDoesNotExistException");
        } catch (EmailDoesNotExistException e) {
        }
        org.junit.Assert.assertNotNull(list_motorista8);
        org.junit.Assert.assertTrue(b9 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        utilizadores2.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista9 = utilizadores2.top5MotoristasComMaiorDesvio();
        int i10 = utilizadores0.compareTo(utilizadores2);
        Utilizadores utilizadores11 = new Utilizadores();
        java.util.List<Motorista> list_motorista12 = utilizadores11.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores2.compareTo(utilizadores11);
        Utilizadores utilizadores14 = null;
        try {
            int i15 = utilizadores11.compareTo(utilizadores14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_motorista9);
        org.junit.Assert.assertTrue(i10 == (-1));
        org.junit.Assert.assertNotNull(list_motorista12);
        org.junit.Assert.assertTrue(i13 == 1);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        utilizadores2.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista9 = utilizadores2.top5MotoristasComMaiorDesvio();
        int i10 = utilizadores0.compareTo(utilizadores2);
        Utilizadores utilizadores11 = new Utilizadores();
        java.util.List<Cliente> list_cliente12 = utilizadores11.top10ClientesGastadores();
        Utilizadores utilizadores13 = new Utilizadores();
        Utilizadores utilizadores14 = new Utilizadores();
        java.util.List<Cliente> list_cliente15 = utilizadores14.top10ClientesGastadores();
        Utilizadores utilizadores16 = new Utilizadores();
        utilizadores16.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista23 = utilizadores16.top5MotoristasComMaiorDesvio();
        int i24 = utilizadores14.compareTo(utilizadores16);
        int i25 = utilizadores13.compareTo(utilizadores14);
        boolean b26 = utilizadores11.equals((java.lang.Object) utilizadores14);
        Utilizadores utilizadores27 = new Utilizadores();
        java.util.List<Cliente> list_cliente28 = utilizadores27.top10ClientesGastadores();
        boolean b30 = utilizadores27.equals((java.lang.Object) 100L);
        Utilizadores utilizadores31 = new Utilizadores();
        utilizadores31.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores31.adiciona("", "", "hi!", "", "");
        Ator ator45 = utilizadores31.getAtor("hi!");
        utilizadores27.adiciona(ator45);
        utilizadores14.adiciona(ator45);
        try {
            utilizadores2.adiciona(ator45);
            org.junit.Assert.fail("Expected exception of type EmailAlreadyInUseException");
        } catch (EmailAlreadyInUseException e) {
        }
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_motorista9);
        org.junit.Assert.assertTrue(i10 == (-1));
        org.junit.Assert.assertNotNull(list_cliente12);
        org.junit.Assert.assertNotNull(list_cliente15);
        org.junit.Assert.assertNotNull(list_motorista23);
        org.junit.Assert.assertTrue(i24 == (-1));
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue(b26 == true);
        org.junit.Assert.assertNotNull(list_cliente28);
        org.junit.Assert.assertTrue(b30 == false);
        org.junit.Assert.assertNotNull(ator45);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        utilizadores0.adiciona("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
        try {
            Ator ator21 = utilizadores0.getAtor("------- UMeR --------\n");
            org.junit.Assert.fail("Expected exception of type EmailDoesNotExistException");
        } catch (EmailDoesNotExistException e) {
        }
        org.junit.Assert.assertNotNull(list_motorista13);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        java.util.List<Motorista> list_motorista16 = utilizadores15.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores17 = new Utilizadores(utilizadores15);
        Utilizadores utilizadores18 = new Utilizadores();
        java.util.List<Cliente> list_cliente19 = utilizadores18.top10ClientesGastadores();
        Utilizadores utilizadores20 = new Utilizadores();
        Utilizadores utilizadores21 = new Utilizadores();
        java.util.List<Cliente> list_cliente22 = utilizadores21.top10ClientesGastadores();
        Utilizadores utilizadores23 = new Utilizadores();
        utilizadores23.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista30 = utilizadores23.top5MotoristasComMaiorDesvio();
        int i31 = utilizadores21.compareTo(utilizadores23);
        int i32 = utilizadores20.compareTo(utilizadores21);
        boolean b33 = utilizadores18.equals((java.lang.Object) utilizadores21);
        java.lang.String str34 = utilizadores18.toString();
        int i35 = utilizadores17.compareTo(utilizadores18);
        java.util.List<Motorista> list_motorista36 = utilizadores17.top5MotoristasComMaiorDesvio();
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(list_motorista16);
        org.junit.Assert.assertNotNull(list_cliente19);
        org.junit.Assert.assertNotNull(list_cliente22);
        org.junit.Assert.assertNotNull(list_motorista30);
        org.junit.Assert.assertTrue(i31 == (-1));
        org.junit.Assert.assertTrue(i32 == 0);
        org.junit.Assert.assertTrue(b33 == true);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "------- UMeR --------\n" + "'", str34.equals("------- UMeR --------\n"));
        org.junit.Assert.assertTrue(i35 == 1);
        org.junit.Assert.assertNotNull(list_motorista36);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores14 = new Utilizadores(utilizadores0);
        java.util.Map<java.lang.String, Ator> map_str_ator15 = utilizadores14.getUtilizadores();
        java.util.List<Cliente> list_cliente16 = utilizadores14.top10ClientesGastadores();
        try {
            Ator ator18 = utilizadores14.getAtor("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
            org.junit.Assert.fail("Expected exception of type EmailDoesNotExistException");
        } catch (EmailDoesNotExistException e) {
        }
        org.junit.Assert.assertNotNull(list_motorista13);
        org.junit.Assert.assertNotNull(map_str_ator15);
        org.junit.Assert.assertNotNull(list_cliente16);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator14 = utilizadores0.getUtilizadores();
        Utilizadores utilizadores15 = new Utilizadores(map_str_ator14);
        Utilizadores utilizadores16 = new Utilizadores();
        java.util.List<Cliente> list_cliente17 = utilizadores16.top10ClientesGastadores();
        java.lang.String str18 = utilizadores16.toString();
        Utilizadores utilizadores19 = new Utilizadores();
        java.util.List<Motorista> list_motorista20 = utilizadores19.top5MotoristasComMaiorDesvio();
        boolean b21 = utilizadores16.equals((java.lang.Object) list_motorista20);
        boolean b22 = utilizadores15.equals((java.lang.Object) list_motorista20);
        Utilizadores utilizadores23 = new Utilizadores(utilizadores15);
        try {
            Ator ator25 = utilizadores23.getAtor("------- UMeR --------\n");
            org.junit.Assert.fail("Expected exception of type EmailDoesNotExistException");
        } catch (EmailDoesNotExistException e) {
        }
        org.junit.Assert.assertNotNull(list_motorista13);
        org.junit.Assert.assertNotNull(map_str_ator14);
        org.junit.Assert.assertNotNull(list_cliente17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "------- UMeR --------\n" + "'", str18.equals("------- UMeR --------\n"));
        org.junit.Assert.assertNotNull(list_motorista20);
        org.junit.Assert.assertTrue(b21 == false);
        org.junit.Assert.assertTrue(b22 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        Utilizadores utilizadores0 = new Utilizadores();
        Utilizadores utilizadores1 = utilizadores0.clone();
        java.util.Map<java.lang.String, Ator> map_str_ator2 = utilizadores1.getUtilizadores();
        Utilizadores utilizadores3 = utilizadores1.clone();
        Utilizadores utilizadores4 = utilizadores1.clone();
        try {
            Ator ator6 = utilizadores1.getAtor("");
            org.junit.Assert.fail("Expected exception of type EmailDoesNotExistException");
        } catch (EmailDoesNotExistException e) {
        }
        org.junit.Assert.assertNotNull(utilizadores1);
        org.junit.Assert.assertNotNull(map_str_ator2);
        org.junit.Assert.assertNotNull(utilizadores3);
        org.junit.Assert.assertNotNull(utilizadores4);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        Utilizadores utilizadores16 = new Utilizadores();
        utilizadores16.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores16.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista29 = utilizadores16.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator30 = utilizadores16.getUtilizadores();
        java.lang.String str31 = utilizadores16.toString();
        int i32 = utilizadores0.compareTo(utilizadores16);
        try {
            Ator ator34 = utilizadores16.getAtor("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
            org.junit.Assert.fail("Expected exception of type EmailDoesNotExistException");
        } catch (EmailDoesNotExistException e) {
        }
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_cliente4);
        org.junit.Assert.assertNotNull(list_motorista12);
        org.junit.Assert.assertTrue(i13 == (-1));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(b15 == true);
        org.junit.Assert.assertNotNull(list_motorista29);
        org.junit.Assert.assertNotNull(map_str_ator30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str31.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertTrue(i32 == (-1));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        Utilizadores utilizadores16 = utilizadores0.clone();
        try {
            Ator ator18 = utilizadores0.getAtor("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
            org.junit.Assert.fail("Expected exception of type EmailDoesNotExistException");
        } catch (EmailDoesNotExistException e) {
        }
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_cliente4);
        org.junit.Assert.assertNotNull(list_motorista12);
        org.junit.Assert.assertTrue(i13 == (-1));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(b15 == true);
        org.junit.Assert.assertNotNull(utilizadores16);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores14 = new Utilizadores(utilizadores0);
        java.util.Map<java.lang.String, Ator> map_str_ator15 = utilizadores14.getUtilizadores();
        try {
            Ator ator17 = utilizadores14.getAtor("------- UMeR --------\n");
            org.junit.Assert.fail("Expected exception of type EmailDoesNotExistException");
        } catch (EmailDoesNotExistException e) {
        }
        org.junit.Assert.assertNotNull(list_motorista13);
        org.junit.Assert.assertNotNull(map_str_ator15);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        java.lang.String str16 = utilizadores0.toString();
        Utilizadores utilizadores17 = utilizadores0.clone();
        java.util.List<Cliente> list_cliente18 = utilizadores17.top10ClientesGastadores();
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_cliente4);
        org.junit.Assert.assertNotNull(list_motorista12);
        org.junit.Assert.assertTrue(i13 == (-1));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(b15 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "------- UMeR --------\n" + "'", str16.equals("------- UMeR --------\n"));
        org.junit.Assert.assertNotNull(utilizadores17);
        org.junit.Assert.assertNotNull(list_cliente18);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        Utilizadores utilizadores0 = new Utilizadores();
        Utilizadores utilizadores1 = new Utilizadores();
        utilizadores1.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista8 = utilizadores1.top5MotoristasComMaiorDesvio();
        boolean b9 = utilizadores0.equals((java.lang.Object) list_motorista8);
        try {
            Ator ator11 = utilizadores0.getAtor("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
            org.junit.Assert.fail("Expected exception of type EmailDoesNotExistException");
        } catch (EmailDoesNotExistException e) {
        }
        org.junit.Assert.assertNotNull(list_motorista8);
        org.junit.Assert.assertTrue(b9 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        Utilizadores utilizadores16 = new Utilizadores(utilizadores0);
        try {
            Ator ator18 = utilizadores16.getAtor("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
            org.junit.Assert.fail("Expected exception of type EmailDoesNotExistException");
        } catch (EmailDoesNotExistException e) {
        }
        org.junit.Assert.assertNotNull(ator14);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        utilizadores0.adiciona("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
        java.lang.String str20 = utilizadores0.toString();
        Ator ator22 = utilizadores0.getAtor("");
        Ator ator24 = utilizadores0.getAtor("");
        org.junit.Assert.assertNotNull(list_motorista13);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str20.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertNotNull(ator22);
        org.junit.Assert.assertNotNull(ator24);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores();
        utilizadores15.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores15.adiciona("", "", "hi!", "", "");
        Ator ator29 = utilizadores15.getAtor("hi!");
        Utilizadores utilizadores30 = new Utilizadores(utilizadores15);
        java.util.List<Motorista> list_motorista31 = utilizadores30.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores32 = utilizadores30.clone();
        int i33 = utilizadores0.compareTo(utilizadores30);
        java.util.List<Motorista> list_motorista34 = utilizadores0.top5MotoristasComMaiorDesvio();
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(ator29);
        org.junit.Assert.assertNotNull(list_motorista31);
        org.junit.Assert.assertNotNull(utilizadores32);
        org.junit.Assert.assertTrue(i33 == 0);
        org.junit.Assert.assertNotNull(list_motorista34);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        Utilizadores utilizadores16 = new Utilizadores(utilizadores0);
        Veiculo veiculo22 = null;
        try {
            utilizadores0.adiciona("hi!", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", veiculo22);
            org.junit.Assert.fail("Expected exception of type EmailAlreadyInUseException");
        } catch (EmailAlreadyInUseException e) {
        }
        org.junit.Assert.assertNotNull(ator14);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        java.util.List<Motorista> list_motorista16 = utilizadores15.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores17 = utilizadores15.clone();
        Veiculo veiculo23 = null;
        try {
            utilizadores17.adiciona("", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", veiculo23);
            org.junit.Assert.fail("Expected exception of type EmailAlreadyInUseException");
        } catch (EmailAlreadyInUseException e) {
        }
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(list_motorista16);
        org.junit.Assert.assertNotNull(utilizadores17);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        java.util.List<Motorista> list_motorista16 = utilizadores15.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores17 = new Utilizadores(utilizadores15);
        Utilizadores utilizadores18 = new Utilizadores();
        utilizadores18.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores18.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista31 = utilizadores18.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores32 = new Utilizadores(utilizadores18);
        int i33 = utilizadores17.compareTo(utilizadores18);
        Utilizadores utilizadores34 = new Utilizadores();
        java.util.List<Cliente> list_cliente35 = utilizadores34.top10ClientesGastadores();
        Utilizadores utilizadores36 = new Utilizadores();
        Utilizadores utilizadores37 = new Utilizadores();
        java.util.List<Cliente> list_cliente38 = utilizadores37.top10ClientesGastadores();
        Utilizadores utilizadores39 = new Utilizadores();
        utilizadores39.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista46 = utilizadores39.top5MotoristasComMaiorDesvio();
        int i47 = utilizadores37.compareTo(utilizadores39);
        int i48 = utilizadores36.compareTo(utilizadores37);
        boolean b49 = utilizadores34.equals((java.lang.Object) utilizadores37);
        Utilizadores utilizadores50 = new Utilizadores();
        java.util.List<Cliente> list_cliente51 = utilizadores50.top10ClientesGastadores();
        boolean b53 = utilizadores50.equals((java.lang.Object) 100L);
        Utilizadores utilizadores54 = new Utilizadores();
        utilizadores54.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores54.adiciona("", "", "hi!", "", "");
        Ator ator68 = utilizadores54.getAtor("hi!");
        utilizadores50.adiciona(ator68);
        utilizadores37.adiciona(ator68);
        try {
            utilizadores18.adiciona(ator68);
            org.junit.Assert.fail("Expected exception of type EmailAlreadyInUseException");
        } catch (EmailAlreadyInUseException e) {
        }
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(list_motorista16);
        org.junit.Assert.assertNotNull(list_motorista31);
        org.junit.Assert.assertTrue(i33 == 0);
        org.junit.Assert.assertNotNull(list_cliente35);
        org.junit.Assert.assertNotNull(list_cliente38);
        org.junit.Assert.assertNotNull(list_motorista46);
        org.junit.Assert.assertTrue(i47 == (-1));
        org.junit.Assert.assertTrue(i48 == 0);
        org.junit.Assert.assertTrue(b49 == true);
        org.junit.Assert.assertNotNull(list_cliente51);
        org.junit.Assert.assertTrue(b53 == false);
        org.junit.Assert.assertNotNull(ator68);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        Utilizadores utilizadores16 = new Utilizadores();
        java.util.List<Cliente> list_cliente17 = utilizadores16.top10ClientesGastadores();
        Utilizadores utilizadores18 = new Utilizadores();
        Utilizadores utilizadores19 = new Utilizadores();
        java.util.List<Cliente> list_cliente20 = utilizadores19.top10ClientesGastadores();
        Utilizadores utilizadores21 = new Utilizadores();
        utilizadores21.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista28 = utilizadores21.top5MotoristasComMaiorDesvio();
        int i29 = utilizadores19.compareTo(utilizadores21);
        int i30 = utilizadores18.compareTo(utilizadores19);
        boolean b31 = utilizadores16.equals((java.lang.Object) utilizadores19);
        Utilizadores utilizadores32 = utilizadores16.clone();
        boolean b33 = utilizadores0.equals((java.lang.Object) utilizadores16);
        Utilizadores utilizadores34 = new Utilizadores();
        utilizadores34.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores34.adiciona("", "", "hi!", "", "");
        Ator ator48 = utilizadores34.getAtor("hi!");
        Utilizadores utilizadores49 = new Utilizadores(utilizadores34);
        Ator ator51 = utilizadores49.getAtor("");
        utilizadores0.adiciona(ator51);
        Utilizadores utilizadores53 = utilizadores0.clone();
        Utilizadores utilizadores54 = new Utilizadores();
        utilizadores54.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores54.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista67 = utilizadores54.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator68 = utilizadores54.getUtilizadores();
        Utilizadores utilizadores69 = new Utilizadores(map_str_ator68);
        Utilizadores utilizadores70 = new Utilizadores();
        utilizadores70.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores70.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista83 = utilizadores70.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator84 = utilizadores70.getUtilizadores();
        Utilizadores utilizadores85 = new Utilizadores(map_str_ator84);
        int i86 = utilizadores69.compareTo(utilizadores85);
        boolean b87 = utilizadores53.equals((java.lang.Object) utilizadores85);
        Veiculo veiculo93 = null;
        try {
            utilizadores53.adiciona("", "------- UMeR --------\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", veiculo93);
            org.junit.Assert.fail("Expected exception of type EmailAlreadyInUseException");
        } catch (EmailAlreadyInUseException e) {
        }
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_cliente4);
        org.junit.Assert.assertNotNull(list_motorista12);
        org.junit.Assert.assertTrue(i13 == (-1));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(b15 == true);
        org.junit.Assert.assertNotNull(list_cliente17);
        org.junit.Assert.assertNotNull(list_cliente20);
        org.junit.Assert.assertNotNull(list_motorista28);
        org.junit.Assert.assertTrue(i29 == (-1));
        org.junit.Assert.assertTrue(i30 == 0);
        org.junit.Assert.assertTrue(b31 == true);
        org.junit.Assert.assertNotNull(utilizadores32);
        org.junit.Assert.assertTrue(b33 == true);
        org.junit.Assert.assertNotNull(ator48);
        org.junit.Assert.assertNotNull(ator51);
        org.junit.Assert.assertNotNull(utilizadores53);
        org.junit.Assert.assertNotNull(list_motorista67);
        org.junit.Assert.assertNotNull(map_str_ator68);
        org.junit.Assert.assertNotNull(list_motorista83);
        org.junit.Assert.assertNotNull(map_str_ator84);
        org.junit.Assert.assertTrue(i86 == 0);
        org.junit.Assert.assertTrue(b87 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        Utilizadores utilizadores7 = utilizadores0.clone();
        utilizadores7.adiciona("------- UMeR --------\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "", "", "");
        java.lang.String str14 = utilizadores7.toString();
        org.junit.Assert.assertNotNull(utilizadores7);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\n\nNome: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: \nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str14.equals("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\n\nNome: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: \nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        Utilizadores utilizadores0 = new Utilizadores();
        Utilizadores utilizadores1 = utilizadores0.clone();
        java.lang.String str2 = utilizadores1.toString();
        Utilizadores utilizadores3 = new Utilizadores();
        utilizadores3.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores3.adiciona("", "", "hi!", "", "");
        Ator ator17 = utilizadores3.getAtor("hi!");
        Utilizadores utilizadores18 = new Utilizadores(utilizadores3);
        java.util.List<Motorista> list_motorista19 = utilizadores18.top5MotoristasComMaiorDesvio();
        Ator ator21 = utilizadores18.getAtor("");
        utilizadores1.adiciona(ator21);
        try {
            Ator ator24 = utilizadores1.getAtor("------- UMeR --------\n");
            org.junit.Assert.fail("Expected exception of type EmailDoesNotExistException");
        } catch (EmailDoesNotExistException e) {
        }
        org.junit.Assert.assertNotNull(utilizadores1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "------- UMeR --------\n" + "'", str2.equals("------- UMeR --------\n"));
        org.junit.Assert.assertNotNull(ator17);
        org.junit.Assert.assertNotNull(list_motorista19);
        org.junit.Assert.assertNotNull(ator21);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores();
        utilizadores15.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores15.adiciona("", "", "hi!", "", "");
        Ator ator29 = utilizadores15.getAtor("hi!");
        Utilizadores utilizadores30 = new Utilizadores(utilizadores15);
        java.util.List<Motorista> list_motorista31 = utilizadores30.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores32 = utilizadores30.clone();
        int i33 = utilizadores0.compareTo(utilizadores30);
        java.lang.String str34 = utilizadores30.toString();
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(ator29);
        org.junit.Assert.assertNotNull(list_motorista31);
        org.junit.Assert.assertNotNull(utilizadores32);
        org.junit.Assert.assertTrue(i33 == 0);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str34.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        utilizadores0.adiciona("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
        java.lang.String str20 = utilizadores0.toString();
        Utilizadores utilizadores21 = new Utilizadores();
        utilizadores21.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores21.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista34 = utilizadores21.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator35 = utilizadores21.getUtilizadores();
        java.lang.String str36 = utilizadores21.toString();
        Utilizadores utilizadores37 = new Utilizadores();
        java.util.List<Cliente> list_cliente38 = utilizadores37.top10ClientesGastadores();
        Utilizadores utilizadores39 = new Utilizadores();
        Utilizadores utilizadores40 = new Utilizadores();
        java.util.List<Cliente> list_cliente41 = utilizadores40.top10ClientesGastadores();
        Utilizadores utilizadores42 = new Utilizadores();
        utilizadores42.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista49 = utilizadores42.top5MotoristasComMaiorDesvio();
        int i50 = utilizadores40.compareTo(utilizadores42);
        int i51 = utilizadores39.compareTo(utilizadores40);
        boolean b52 = utilizadores37.equals((java.lang.Object) utilizadores40);
        Utilizadores utilizadores53 = new Utilizadores();
        utilizadores53.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores53.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista66 = utilizadores53.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator67 = utilizadores53.getUtilizadores();
        java.lang.String str68 = utilizadores53.toString();
        int i69 = utilizadores37.compareTo(utilizadores53);
        Utilizadores utilizadores70 = utilizadores37.clone();
        int i71 = utilizadores21.compareTo(utilizadores70);
        boolean b72 = utilizadores0.equals((java.lang.Object) i71);
        Utilizadores utilizadores73 = new Utilizadores();
        java.util.List<Cliente> list_cliente74 = utilizadores73.top10ClientesGastadores();
        boolean b76 = utilizadores73.equals((java.lang.Object) 100L);
        Utilizadores utilizadores77 = new Utilizadores();
        utilizadores77.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores77.adiciona("", "", "hi!", "", "");
        Ator ator91 = utilizadores77.getAtor("hi!");
        utilizadores73.adiciona(ator91);
        try {
            utilizadores0.adiciona(ator91);
            org.junit.Assert.fail("Expected exception of type EmailAlreadyInUseException");
        } catch (EmailAlreadyInUseException e) {
        }
        org.junit.Assert.assertNotNull(list_motorista13);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str20.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertNotNull(list_motorista34);
        org.junit.Assert.assertNotNull(map_str_ator35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str36.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertNotNull(list_cliente38);
        org.junit.Assert.assertNotNull(list_cliente41);
        org.junit.Assert.assertNotNull(list_motorista49);
        org.junit.Assert.assertTrue(i50 == (-1));
        org.junit.Assert.assertTrue(i51 == 0);
        org.junit.Assert.assertTrue(b52 == true);
        org.junit.Assert.assertNotNull(list_motorista66);
        org.junit.Assert.assertNotNull(map_str_ator67);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str68.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertTrue(i69 == (-1));
        org.junit.Assert.assertNotNull(utilizadores70);
        org.junit.Assert.assertTrue(i71 == 1);
        org.junit.Assert.assertTrue(b72 == false);
        org.junit.Assert.assertNotNull(list_cliente74);
        org.junit.Assert.assertTrue(b76 == false);
        org.junit.Assert.assertNotNull(ator91);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        Utilizadores utilizadores0 = new Utilizadores();
        boolean b2 = utilizadores0.equals((java.lang.Object) (short) 1);
        Utilizadores utilizadores3 = new Utilizadores();
        utilizadores3.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores3.adiciona("", "", "hi!", "", "");
        Ator ator17 = utilizadores3.getAtor("hi!");
        int i18 = utilizadores0.compareTo(utilizadores3);
        Utilizadores utilizadores19 = new Utilizadores();
        java.util.List<Cliente> list_cliente20 = utilizadores19.top10ClientesGastadores();
        Utilizadores utilizadores21 = new Utilizadores();
        Utilizadores utilizadores22 = new Utilizadores();
        java.util.List<Cliente> list_cliente23 = utilizadores22.top10ClientesGastadores();
        Utilizadores utilizadores24 = new Utilizadores();
        utilizadores24.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista31 = utilizadores24.top5MotoristasComMaiorDesvio();
        int i32 = utilizadores22.compareTo(utilizadores24);
        int i33 = utilizadores21.compareTo(utilizadores22);
        boolean b34 = utilizadores19.equals((java.lang.Object) utilizadores22);
        java.lang.String str35 = utilizadores19.toString();
        int i36 = utilizadores0.compareTo(utilizadores19);
        java.util.Map<java.lang.String, Ator> map_str_ator37 = utilizadores0.getUtilizadores();
        org.junit.Assert.assertTrue(b2 == false);
        org.junit.Assert.assertNotNull(ator17);
        org.junit.Assert.assertTrue(i18 == (-1));
        org.junit.Assert.assertNotNull(list_cliente20);
        org.junit.Assert.assertNotNull(list_cliente23);
        org.junit.Assert.assertNotNull(list_motorista31);
        org.junit.Assert.assertTrue(i32 == (-1));
        org.junit.Assert.assertTrue(i33 == 0);
        org.junit.Assert.assertTrue(b34 == true);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "------- UMeR --------\n" + "'", str35.equals("------- UMeR --------\n"));
        org.junit.Assert.assertTrue(i36 == 0);
        org.junit.Assert.assertNotNull(map_str_ator37);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        Utilizadores utilizadores16 = new Utilizadores();
        java.util.List<Cliente> list_cliente17 = utilizadores16.top10ClientesGastadores();
        Utilizadores utilizadores18 = new Utilizadores();
        Utilizadores utilizadores19 = new Utilizadores();
        java.util.List<Cliente> list_cliente20 = utilizadores19.top10ClientesGastadores();
        Utilizadores utilizadores21 = new Utilizadores();
        utilizadores21.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista28 = utilizadores21.top5MotoristasComMaiorDesvio();
        int i29 = utilizadores19.compareTo(utilizadores21);
        int i30 = utilizadores18.compareTo(utilizadores19);
        boolean b31 = utilizadores16.equals((java.lang.Object) utilizadores19);
        Utilizadores utilizadores32 = utilizadores16.clone();
        boolean b33 = utilizadores0.equals((java.lang.Object) utilizadores16);
        Utilizadores utilizadores34 = new Utilizadores();
        utilizadores34.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores34.adiciona("", "", "hi!", "", "");
        Ator ator48 = utilizadores34.getAtor("hi!");
        Utilizadores utilizadores49 = new Utilizadores(utilizadores34);
        Ator ator51 = utilizadores49.getAtor("");
        utilizadores0.adiciona(ator51);
        Utilizadores utilizadores53 = utilizadores0.clone();
        Utilizadores utilizadores54 = new Utilizadores(utilizadores0);
        java.lang.String str55 = utilizadores0.toString();
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_cliente4);
        org.junit.Assert.assertNotNull(list_motorista12);
        org.junit.Assert.assertTrue(i13 == (-1));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(b15 == true);
        org.junit.Assert.assertNotNull(list_cliente17);
        org.junit.Assert.assertNotNull(list_cliente20);
        org.junit.Assert.assertNotNull(list_motorista28);
        org.junit.Assert.assertTrue(i29 == (-1));
        org.junit.Assert.assertTrue(i30 == 0);
        org.junit.Assert.assertTrue(b31 == true);
        org.junit.Assert.assertNotNull(utilizadores32);
        org.junit.Assert.assertTrue(b33 == true);
        org.junit.Assert.assertNotNull(ator48);
        org.junit.Assert.assertNotNull(ator51);
        org.junit.Assert.assertNotNull(utilizadores53);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str55.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        java.util.List<Motorista> list_motorista16 = utilizadores15.top5MotoristasComMaiorDesvio();
        Ator ator18 = utilizadores15.getAtor("");
        java.util.List<Motorista> list_motorista19 = utilizadores15.top5MotoristasComMaiorDesvio();
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(list_motorista16);
        org.junit.Assert.assertNotNull(ator18);
        org.junit.Assert.assertNotNull(list_motorista19);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        java.util.List<Motorista> list_motorista16 = utilizadores0.top5MotoristasComMaiorDesvio();
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(list_motorista16);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        Utilizadores utilizadores16 = utilizadores0.clone();
        Utilizadores utilizadores17 = new Utilizadores();
        java.util.List<Motorista> list_motorista18 = utilizadores17.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores19 = new Utilizadores();
        boolean b21 = utilizadores19.equals((java.lang.Object) (short) 1);
        boolean b22 = utilizadores17.equals((java.lang.Object) b21);
        java.util.Map<java.lang.String, Ator> map_str_ator23 = utilizadores17.getUtilizadores();
        Utilizadores utilizadores24 = new Utilizadores(map_str_ator23);
        java.util.Map<java.lang.String, Ator> map_str_ator25 = utilizadores24.getUtilizadores();
        Utilizadores utilizadores26 = new Utilizadores(map_str_ator25);
        Utilizadores utilizadores27 = new Utilizadores(map_str_ator25);
        Utilizadores utilizadores28 = new Utilizadores(map_str_ator25);
        boolean b29 = utilizadores16.equals((java.lang.Object) map_str_ator25);
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_cliente4);
        org.junit.Assert.assertNotNull(list_motorista12);
        org.junit.Assert.assertTrue(i13 == (-1));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(b15 == true);
        org.junit.Assert.assertNotNull(utilizadores16);
        org.junit.Assert.assertNotNull(list_motorista18);
        org.junit.Assert.assertTrue(b21 == false);
        org.junit.Assert.assertTrue(b22 == false);
        org.junit.Assert.assertNotNull(map_str_ator23);
        org.junit.Assert.assertNotNull(map_str_ator25);
        org.junit.Assert.assertTrue(b29 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        boolean b3 = utilizadores0.equals((java.lang.Object) 100L);
        java.util.Map<java.lang.String, Ator> map_str_ator4 = utilizadores0.getUtilizadores();
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertNotNull(map_str_ator4);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        Utilizadores utilizadores7 = utilizadores0.clone();
        java.util.List<Cliente> list_cliente8 = utilizadores0.top10ClientesGastadores();
        java.util.List<Cliente> list_cliente9 = utilizadores0.top10ClientesGastadores();
        org.junit.Assert.assertNotNull(utilizadores7);
        org.junit.Assert.assertNotNull(list_cliente8);
        org.junit.Assert.assertNotNull(list_cliente9);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        Utilizadores utilizadores16 = new Utilizadores(utilizadores0);
        Utilizadores utilizadores17 = new Utilizadores();
        utilizadores17.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores17.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista30 = utilizadores17.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator31 = utilizadores17.getUtilizadores();
        Utilizadores utilizadores32 = new Utilizadores(map_str_ator31);
        Utilizadores utilizadores33 = new Utilizadores();
        java.util.List<Cliente> list_cliente34 = utilizadores33.top10ClientesGastadores();
        java.lang.String str35 = utilizadores33.toString();
        Utilizadores utilizadores36 = new Utilizadores();
        java.util.List<Motorista> list_motorista37 = utilizadores36.top5MotoristasComMaiorDesvio();
        boolean b38 = utilizadores33.equals((java.lang.Object) list_motorista37);
        boolean b39 = utilizadores32.equals((java.lang.Object) list_motorista37);
        int i40 = utilizadores0.compareTo(utilizadores32);
        try {
            Ator ator42 = utilizadores0.getAtor("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
            org.junit.Assert.fail("Expected exception of type EmailDoesNotExistException");
        } catch (EmailDoesNotExistException e) {
        }
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(list_motorista30);
        org.junit.Assert.assertNotNull(map_str_ator31);
        org.junit.Assert.assertNotNull(list_cliente34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "------- UMeR --------\n" + "'", str35.equals("------- UMeR --------\n"));
        org.junit.Assert.assertNotNull(list_motorista37);
        org.junit.Assert.assertTrue(b38 == false);
        org.junit.Assert.assertTrue(b39 == false);
        org.junit.Assert.assertTrue(i40 == 0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        Utilizadores utilizadores16 = new Utilizadores();
        utilizadores16.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores16.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista29 = utilizadores16.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator30 = utilizadores16.getUtilizadores();
        java.lang.String str31 = utilizadores16.toString();
        int i32 = utilizadores0.compareTo(utilizadores16);
        Utilizadores utilizadores33 = utilizadores16.clone();
        java.util.Map<java.lang.String, Ator> map_str_ator34 = utilizadores33.getUtilizadores();
        Utilizadores utilizadores35 = new Utilizadores(map_str_ator34);
        java.util.List<Motorista> list_motorista36 = utilizadores35.top5MotoristasComMaiorDesvio();
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_cliente4);
        org.junit.Assert.assertNotNull(list_motorista12);
        org.junit.Assert.assertTrue(i13 == (-1));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(b15 == true);
        org.junit.Assert.assertNotNull(list_motorista29);
        org.junit.Assert.assertNotNull(map_str_ator30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str31.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertTrue(i32 == (-1));
        org.junit.Assert.assertNotNull(utilizadores33);
        org.junit.Assert.assertNotNull(map_str_ator34);
        org.junit.Assert.assertNotNull(list_motorista36);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Motorista> list_motorista1 = utilizadores0.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores2 = new Utilizadores();
        boolean b4 = utilizadores2.equals((java.lang.Object) (short) 1);
        boolean b5 = utilizadores0.equals((java.lang.Object) b4);
        java.util.Map<java.lang.String, Ator> map_str_ator6 = utilizadores0.getUtilizadores();
        Utilizadores utilizadores7 = new Utilizadores(utilizadores0);
        org.junit.Assert.assertNotNull(list_motorista1);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(b5 == false);
        org.junit.Assert.assertNotNull(map_str_ator6);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        Veiculo veiculo19 = null;
        utilizadores0.adiciona("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\n\nNome: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: \nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", veiculo19);
        org.junit.Assert.assertNotNull(list_motorista13);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        Utilizadores utilizadores16 = new Utilizadores();
        utilizadores16.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores16.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista29 = utilizadores16.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator30 = utilizadores16.getUtilizadores();
        java.lang.String str31 = utilizadores16.toString();
        int i32 = utilizadores0.compareTo(utilizadores16);
        Utilizadores utilizadores33 = utilizadores16.clone();
        Utilizadores utilizadores34 = new Utilizadores();
        utilizadores34.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores34.adiciona("", "", "hi!", "", "");
        Ator ator48 = utilizadores34.getAtor("hi!");
        Utilizadores utilizadores49 = new Utilizadores(utilizadores34);
        java.util.List<Motorista> list_motorista50 = utilizadores49.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores51 = new Utilizadores(utilizadores49);
        Utilizadores utilizadores52 = new Utilizadores();
        java.util.List<Cliente> list_cliente53 = utilizadores52.top10ClientesGastadores();
        Utilizadores utilizadores54 = new Utilizadores();
        Utilizadores utilizadores55 = new Utilizadores();
        java.util.List<Cliente> list_cliente56 = utilizadores55.top10ClientesGastadores();
        Utilizadores utilizadores57 = new Utilizadores();
        utilizadores57.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista64 = utilizadores57.top5MotoristasComMaiorDesvio();
        int i65 = utilizadores55.compareTo(utilizadores57);
        int i66 = utilizadores54.compareTo(utilizadores55);
        boolean b67 = utilizadores52.equals((java.lang.Object) utilizadores55);
        java.lang.String str68 = utilizadores52.toString();
        int i69 = utilizadores51.compareTo(utilizadores52);
        Utilizadores utilizadores70 = new Utilizadores();
        utilizadores70.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores70.adiciona("", "", "hi!", "", "");
        Ator ator84 = utilizadores70.getAtor("hi!");
        utilizadores52.adiciona(ator84);
        try {
            utilizadores33.adiciona(ator84);
            org.junit.Assert.fail("Expected exception of type EmailAlreadyInUseException");
        } catch (EmailAlreadyInUseException e) {
        }
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_cliente4);
        org.junit.Assert.assertNotNull(list_motorista12);
        org.junit.Assert.assertTrue(i13 == (-1));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(b15 == true);
        org.junit.Assert.assertNotNull(list_motorista29);
        org.junit.Assert.assertNotNull(map_str_ator30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str31.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertTrue(i32 == (-1));
        org.junit.Assert.assertNotNull(utilizadores33);
        org.junit.Assert.assertNotNull(ator48);
        org.junit.Assert.assertNotNull(list_motorista50);
        org.junit.Assert.assertNotNull(list_cliente53);
        org.junit.Assert.assertNotNull(list_cliente56);
        org.junit.Assert.assertNotNull(list_motorista64);
        org.junit.Assert.assertTrue(i65 == (-1));
        org.junit.Assert.assertTrue(i66 == 0);
        org.junit.Assert.assertTrue(b67 == true);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "------- UMeR --------\n" + "'", str68.equals("------- UMeR --------\n"));
        org.junit.Assert.assertTrue(i69 == 1);
        org.junit.Assert.assertNotNull(ator84);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        utilizadores2.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista9 = utilizadores2.top5MotoristasComMaiorDesvio();
        int i10 = utilizadores0.compareTo(utilizadores2);
        Utilizadores utilizadores11 = new Utilizadores();
        java.util.List<Motorista> list_motorista12 = utilizadores11.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores2.compareTo(utilizadores11);
        java.util.Map<java.lang.String, Ator> map_str_ator14 = utilizadores2.getUtilizadores();
        java.util.Map<java.lang.String, Ator> map_str_ator15 = utilizadores2.getUtilizadores();
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_motorista9);
        org.junit.Assert.assertTrue(i10 == (-1));
        org.junit.Assert.assertNotNull(list_motorista12);
        org.junit.Assert.assertTrue(i13 == 1);
        org.junit.Assert.assertNotNull(map_str_ator14);
        org.junit.Assert.assertNotNull(map_str_ator15);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        Utilizadores utilizadores16 = new Utilizadores(utilizadores0);
        Veiculo veiculo22 = null;
        utilizadores16.adiciona("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "", veiculo22);
        org.junit.Assert.assertNotNull(ator14);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        java.lang.String str16 = utilizadores0.toString();
        Utilizadores utilizadores17 = utilizadores0.clone();
        try {
            Ator ator19 = utilizadores17.getAtor("hi!");
            org.junit.Assert.fail("Expected exception of type EmailDoesNotExistException");
        } catch (EmailDoesNotExistException e) {
        }
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_cliente4);
        org.junit.Assert.assertNotNull(list_motorista12);
        org.junit.Assert.assertTrue(i13 == (-1));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(b15 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "------- UMeR --------\n" + "'", str16.equals("------- UMeR --------\n"));
        org.junit.Assert.assertNotNull(utilizadores17);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        Utilizadores utilizadores16 = new Utilizadores();
        utilizadores16.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores16.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista29 = utilizadores16.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator30 = utilizadores16.getUtilizadores();
        java.lang.String str31 = utilizadores16.toString();
        int i32 = utilizadores0.compareTo(utilizadores16);
        Utilizadores utilizadores33 = utilizadores16.clone();
        try {
            Ator ator35 = utilizadores16.getAtor("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
            org.junit.Assert.fail("Expected exception of type EmailDoesNotExistException");
        } catch (EmailDoesNotExistException e) {
        }
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_cliente4);
        org.junit.Assert.assertNotNull(list_motorista12);
        org.junit.Assert.assertTrue(i13 == (-1));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(b15 == true);
        org.junit.Assert.assertNotNull(list_motorista29);
        org.junit.Assert.assertNotNull(map_str_ator30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str31.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertTrue(i32 == (-1));
        org.junit.Assert.assertNotNull(utilizadores33);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        Utilizadores utilizadores16 = utilizadores0.clone();
        java.util.List<Motorista> list_motorista17 = utilizadores0.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores18 = new Utilizadores();
        java.util.List<Motorista> list_motorista19 = utilizadores18.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores20 = new Utilizadores();
        boolean b22 = utilizadores20.equals((java.lang.Object) (short) 1);
        boolean b23 = utilizadores18.equals((java.lang.Object) b22);
        java.util.Map<java.lang.String, Ator> map_str_ator24 = utilizadores18.getUtilizadores();
        Utilizadores utilizadores25 = new Utilizadores(map_str_ator24);
        java.util.Map<java.lang.String, Ator> map_str_ator26 = utilizadores25.getUtilizadores();
        Utilizadores utilizadores27 = new Utilizadores(map_str_ator26);
        boolean b28 = utilizadores0.equals((java.lang.Object) map_str_ator26);
        Utilizadores utilizadores29 = new Utilizadores(utilizadores0);
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_cliente4);
        org.junit.Assert.assertNotNull(list_motorista12);
        org.junit.Assert.assertTrue(i13 == (-1));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(b15 == true);
        org.junit.Assert.assertNotNull(utilizadores16);
        org.junit.Assert.assertNotNull(list_motorista17);
        org.junit.Assert.assertNotNull(list_motorista19);
        org.junit.Assert.assertTrue(b22 == false);
        org.junit.Assert.assertTrue(b23 == false);
        org.junit.Assert.assertNotNull(map_str_ator24);
        org.junit.Assert.assertNotNull(map_str_ator26);
        org.junit.Assert.assertTrue(b28 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        Utilizadores utilizadores16 = utilizadores0.clone();
        Utilizadores utilizadores17 = new Utilizadores();
        utilizadores17.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores17.adiciona("", "", "hi!", "", "");
        Ator ator31 = utilizadores17.getAtor("hi!");
        Utilizadores utilizadores32 = new Utilizadores();
        utilizadores32.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores32.adiciona("", "", "hi!", "", "");
        Ator ator46 = utilizadores32.getAtor("hi!");
        Utilizadores utilizadores47 = new Utilizadores(utilizadores32);
        java.util.List<Motorista> list_motorista48 = utilizadores47.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores49 = utilizadores47.clone();
        int i50 = utilizadores17.compareTo(utilizadores47);
        Utilizadores utilizadores51 = new Utilizadores(utilizadores47);
        int i52 = utilizadores0.compareTo(utilizadores47);
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(utilizadores16);
        org.junit.Assert.assertNotNull(ator31);
        org.junit.Assert.assertNotNull(ator46);
        org.junit.Assert.assertNotNull(list_motorista48);
        org.junit.Assert.assertNotNull(utilizadores49);
        org.junit.Assert.assertTrue(i50 == 0);
        org.junit.Assert.assertTrue(i52 == 0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores14 = new Utilizadores();
        utilizadores14.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores14.adiciona("", "", "hi!", "", "");
        Ator ator28 = utilizadores14.getAtor("hi!");
        Utilizadores utilizadores29 = new Utilizadores(utilizadores14);
        boolean b30 = utilizadores0.equals((java.lang.Object) utilizadores29);
        Utilizadores utilizadores31 = new Utilizadores();
        utilizadores31.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores31.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista44 = utilizadores31.top5MotoristasComMaiorDesvio();
        utilizadores31.adiciona("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
        java.lang.String str51 = utilizadores31.toString();
        Ator ator53 = utilizadores31.getAtor("");
        Utilizadores utilizadores54 = new Utilizadores(utilizadores31);
        boolean b55 = utilizadores0.equals((java.lang.Object) utilizadores31);
        org.junit.Assert.assertNotNull(list_motorista13);
        org.junit.Assert.assertNotNull(ator28);
        org.junit.Assert.assertTrue(b30 == true);
        org.junit.Assert.assertNotNull(list_motorista44);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str51.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertNotNull(ator53);
        org.junit.Assert.assertTrue(b55 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        utilizadores2.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista9 = utilizadores2.top5MotoristasComMaiorDesvio();
        int i10 = utilizadores0.compareTo(utilizadores2);
        Utilizadores utilizadores11 = new Utilizadores();
        java.util.List<Motorista> list_motorista12 = utilizadores11.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores2.compareTo(utilizadores11);
        java.util.List<Motorista> list_motorista14 = utilizadores11.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores15 = new Utilizadores(utilizadores11);
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_motorista9);
        org.junit.Assert.assertTrue(i10 == (-1));
        org.junit.Assert.assertNotNull(list_motorista12);
        org.junit.Assert.assertTrue(i13 == 1);
        org.junit.Assert.assertNotNull(list_motorista14);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        Utilizadores utilizadores0 = new Utilizadores();
        Utilizadores utilizadores1 = utilizadores0.clone();
        java.util.Map<java.lang.String, Ator> map_str_ator2 = utilizadores1.getUtilizadores();
        Utilizadores utilizadores3 = utilizadores1.clone();
        Utilizadores utilizadores4 = utilizadores1.clone();
        Utilizadores utilizadores5 = utilizadores1.clone();
        java.util.List<Motorista> list_motorista6 = utilizadores5.top5MotoristasComMaiorDesvio();
        utilizadores5.adiciona("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
        org.junit.Assert.assertNotNull(utilizadores1);
        org.junit.Assert.assertNotNull(map_str_ator2);
        org.junit.Assert.assertNotNull(utilizadores3);
        org.junit.Assert.assertNotNull(utilizadores4);
        org.junit.Assert.assertNotNull(utilizadores5);
        org.junit.Assert.assertNotNull(list_motorista6);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores14 = new Utilizadores(utilizadores0);
        java.util.Map<java.lang.String, Ator> map_str_ator15 = utilizadores14.getUtilizadores();
        Utilizadores utilizadores16 = new Utilizadores(map_str_ator15);
        java.lang.String str17 = utilizadores16.toString();
        org.junit.Assert.assertNotNull(list_motorista13);
        org.junit.Assert.assertNotNull(map_str_ator15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str17.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator14 = utilizadores0.getUtilizadores();
        Utilizadores utilizadores15 = new Utilizadores(map_str_ator14);
        Utilizadores utilizadores16 = new Utilizadores();
        java.util.List<Cliente> list_cliente17 = utilizadores16.top10ClientesGastadores();
        java.lang.String str18 = utilizadores16.toString();
        Utilizadores utilizadores19 = new Utilizadores();
        java.util.List<Motorista> list_motorista20 = utilizadores19.top5MotoristasComMaiorDesvio();
        boolean b21 = utilizadores16.equals((java.lang.Object) list_motorista20);
        boolean b22 = utilizadores15.equals((java.lang.Object) list_motorista20);
        Utilizadores utilizadores23 = new Utilizadores();
        Utilizadores utilizadores24 = utilizadores23.clone();
        Utilizadores utilizadores25 = new Utilizadores(utilizadores23);
        Utilizadores utilizadores26 = new Utilizadores();
        Utilizadores utilizadores27 = utilizadores26.clone();
        java.lang.String str28 = utilizadores27.toString();
        Utilizadores utilizadores29 = new Utilizadores();
        utilizadores29.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores29.adiciona("", "", "hi!", "", "");
        Ator ator43 = utilizadores29.getAtor("hi!");
        Utilizadores utilizadores44 = new Utilizadores(utilizadores29);
        java.util.List<Motorista> list_motorista45 = utilizadores44.top5MotoristasComMaiorDesvio();
        Ator ator47 = utilizadores44.getAtor("");
        utilizadores27.adiciona(ator47);
        utilizadores23.adiciona(ator47);
        try {
            utilizadores15.adiciona(ator47);
            org.junit.Assert.fail("Expected exception of type EmailAlreadyInUseException");
        } catch (EmailAlreadyInUseException e) {
        }
        org.junit.Assert.assertNotNull(list_motorista13);
        org.junit.Assert.assertNotNull(map_str_ator14);
        org.junit.Assert.assertNotNull(list_cliente17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "------- UMeR --------\n" + "'", str18.equals("------- UMeR --------\n"));
        org.junit.Assert.assertNotNull(list_motorista20);
        org.junit.Assert.assertTrue(b21 == false);
        org.junit.Assert.assertTrue(b22 == false);
        org.junit.Assert.assertNotNull(utilizadores24);
        org.junit.Assert.assertNotNull(utilizadores27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "------- UMeR --------\n" + "'", str28.equals("------- UMeR --------\n"));
        org.junit.Assert.assertNotNull(ator43);
        org.junit.Assert.assertNotNull(list_motorista45);
        org.junit.Assert.assertNotNull(ator47);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        Utilizadores utilizadores16 = new Utilizadores();
        java.util.List<Cliente> list_cliente17 = utilizadores16.top10ClientesGastadores();
        Utilizadores utilizadores18 = new Utilizadores();
        Utilizadores utilizadores19 = new Utilizadores();
        java.util.List<Cliente> list_cliente20 = utilizadores19.top10ClientesGastadores();
        Utilizadores utilizadores21 = new Utilizadores();
        utilizadores21.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista28 = utilizadores21.top5MotoristasComMaiorDesvio();
        int i29 = utilizadores19.compareTo(utilizadores21);
        int i30 = utilizadores18.compareTo(utilizadores19);
        boolean b31 = utilizadores16.equals((java.lang.Object) utilizadores19);
        Utilizadores utilizadores32 = utilizadores16.clone();
        boolean b33 = utilizadores0.equals((java.lang.Object) utilizadores16);
        Utilizadores utilizadores34 = new Utilizadores();
        utilizadores34.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores34.adiciona("", "", "hi!", "", "");
        Ator ator48 = utilizadores34.getAtor("hi!");
        Utilizadores utilizadores49 = new Utilizadores(utilizadores34);
        Ator ator51 = utilizadores49.getAtor("");
        utilizadores0.adiciona(ator51);
        Utilizadores utilizadores53 = utilizadores0.clone();
        Utilizadores utilizadores54 = new Utilizadores(utilizadores0);
        Utilizadores utilizadores55 = new Utilizadores(utilizadores54);
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_cliente4);
        org.junit.Assert.assertNotNull(list_motorista12);
        org.junit.Assert.assertTrue(i13 == (-1));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(b15 == true);
        org.junit.Assert.assertNotNull(list_cliente17);
        org.junit.Assert.assertNotNull(list_cliente20);
        org.junit.Assert.assertNotNull(list_motorista28);
        org.junit.Assert.assertTrue(i29 == (-1));
        org.junit.Assert.assertTrue(i30 == 0);
        org.junit.Assert.assertTrue(b31 == true);
        org.junit.Assert.assertNotNull(utilizadores32);
        org.junit.Assert.assertTrue(b33 == true);
        org.junit.Assert.assertNotNull(ator48);
        org.junit.Assert.assertNotNull(ator51);
        org.junit.Assert.assertNotNull(utilizadores53);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        Utilizadores utilizadores0 = new Utilizadores();
        Utilizadores utilizadores1 = utilizadores0.clone();
        java.util.Map<java.lang.String, Ator> map_str_ator2 = utilizadores1.getUtilizadores();
        Utilizadores utilizadores3 = utilizadores1.clone();
        java.util.List<Motorista> list_motorista4 = utilizadores1.top5MotoristasComMaiorDesvio();
        org.junit.Assert.assertNotNull(utilizadores1);
        org.junit.Assert.assertNotNull(map_str_ator2);
        org.junit.Assert.assertNotNull(utilizadores3);
        org.junit.Assert.assertNotNull(list_motorista4);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        java.util.List<Motorista> list_motorista16 = utilizadores0.top5MotoristasComMaiorDesvio();
        utilizadores0.adiciona("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!", "------- UMeR --------\n", "");
        Utilizadores utilizadores23 = new Utilizadores(utilizadores0);
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_cliente4);
        org.junit.Assert.assertNotNull(list_motorista12);
        org.junit.Assert.assertTrue(i13 == (-1));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(b15 == true);
        org.junit.Assert.assertNotNull(list_motorista16);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        Utilizadores utilizadores16 = utilizadores0.clone();
        java.util.List<Motorista> list_motorista17 = utilizadores0.top5MotoristasComMaiorDesvio();
        java.lang.String str18 = utilizadores0.toString();
        java.lang.String str19 = utilizadores0.toString();
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_cliente4);
        org.junit.Assert.assertNotNull(list_motorista12);
        org.junit.Assert.assertTrue(i13 == (-1));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(b15 == true);
        org.junit.Assert.assertNotNull(utilizadores16);
        org.junit.Assert.assertNotNull(list_motorista17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "------- UMeR --------\n" + "'", str18.equals("------- UMeR --------\n"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "------- UMeR --------\n" + "'", str19.equals("------- UMeR --------\n"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        utilizadores3.adiciona("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "", "------- UMeR --------\n", "hi!", "");
        Veiculo veiculo27 = null;
        try {
            utilizadores3.adiciona("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!", "", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\n\nNome: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: \nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", veiculo27);
            org.junit.Assert.fail("Expected exception of type EmailAlreadyInUseException");
        } catch (EmailAlreadyInUseException e) {
        }
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_cliente4);
        org.junit.Assert.assertNotNull(list_motorista12);
        org.junit.Assert.assertTrue(i13 == (-1));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(b15 == true);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        Utilizadores utilizadores0 = new Utilizadores();
        Utilizadores utilizadores1 = new Utilizadores();
        java.util.List<Cliente> list_cliente2 = utilizadores1.top10ClientesGastadores();
        Utilizadores utilizadores3 = new Utilizadores();
        utilizadores3.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista10 = utilizadores3.top5MotoristasComMaiorDesvio();
        int i11 = utilizadores1.compareTo(utilizadores3);
        int i12 = utilizadores0.compareTo(utilizadores1);
        java.util.Map<java.lang.String, Ator> map_str_ator13 = utilizadores1.getUtilizadores();
        Utilizadores utilizadores14 = new Utilizadores(map_str_ator13);
        java.util.List<Motorista> list_motorista15 = utilizadores14.top5MotoristasComMaiorDesvio();
        org.junit.Assert.assertNotNull(list_cliente2);
        org.junit.Assert.assertNotNull(list_motorista10);
        org.junit.Assert.assertTrue(i11 == (-1));
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertNotNull(map_str_ator13);
        org.junit.Assert.assertNotNull(list_motorista15);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        utilizadores0.adiciona("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
        Utilizadores utilizadores20 = new Utilizadores();
        utilizadores20.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores20.adiciona("", "", "hi!", "", "");
        Ator ator34 = utilizadores20.getAtor("hi!");
        Utilizadores utilizadores35 = new Utilizadores(utilizadores20);
        java.util.List<Motorista> list_motorista36 = utilizadores35.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores37 = new Utilizadores(utilizadores35);
        java.lang.String str38 = utilizadores37.toString();
        boolean b39 = utilizadores0.equals((java.lang.Object) utilizadores37);
        Utilizadores utilizadores40 = new Utilizadores();
        Utilizadores utilizadores41 = utilizadores40.clone();
        Utilizadores utilizadores42 = new Utilizadores(utilizadores40);
        Utilizadores utilizadores43 = new Utilizadores();
        Utilizadores utilizadores44 = utilizadores43.clone();
        java.lang.String str45 = utilizadores44.toString();
        Utilizadores utilizadores46 = new Utilizadores();
        utilizadores46.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores46.adiciona("", "", "hi!", "", "");
        Ator ator60 = utilizadores46.getAtor("hi!");
        Utilizadores utilizadores61 = new Utilizadores(utilizadores46);
        java.util.List<Motorista> list_motorista62 = utilizadores61.top5MotoristasComMaiorDesvio();
        Ator ator64 = utilizadores61.getAtor("");
        utilizadores44.adiciona(ator64);
        utilizadores40.adiciona(ator64);
        try {
            utilizadores0.adiciona(ator64);
            org.junit.Assert.fail("Expected exception of type EmailAlreadyInUseException");
        } catch (EmailAlreadyInUseException e) {
        }
        org.junit.Assert.assertNotNull(list_motorista13);
        org.junit.Assert.assertNotNull(ator34);
        org.junit.Assert.assertNotNull(list_motorista36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str38.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertTrue(b39 == false);
        org.junit.Assert.assertNotNull(utilizadores41);
        org.junit.Assert.assertNotNull(utilizadores44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "------- UMeR --------\n" + "'", str45.equals("------- UMeR --------\n"));
        org.junit.Assert.assertNotNull(ator60);
        org.junit.Assert.assertNotNull(list_motorista62);
        org.junit.Assert.assertNotNull(ator64);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        Utilizadores utilizadores0 = new Utilizadores();
        Utilizadores utilizadores1 = new Utilizadores();
        java.util.List<Cliente> list_cliente2 = utilizadores1.top10ClientesGastadores();
        Utilizadores utilizadores3 = new Utilizadores();
        utilizadores3.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista10 = utilizadores3.top5MotoristasComMaiorDesvio();
        int i11 = utilizadores1.compareTo(utilizadores3);
        int i12 = utilizadores0.compareTo(utilizadores1);
        java.util.Map<java.lang.String, Ator> map_str_ator13 = utilizadores1.getUtilizadores();
        Utilizadores utilizadores14 = new Utilizadores();
        utilizadores14.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores14.adiciona("", "", "hi!", "", "");
        Ator ator28 = utilizadores14.getAtor("hi!");
        utilizadores1.adiciona(ator28);
        Utilizadores utilizadores30 = new Utilizadores();
        utilizadores30.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores30.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista43 = utilizadores30.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator44 = utilizadores30.getUtilizadores();
        Utilizadores utilizadores45 = new Utilizadores(map_str_ator44);
        Utilizadores utilizadores46 = new Utilizadores();
        java.util.List<Cliente> list_cliente47 = utilizadores46.top10ClientesGastadores();
        java.lang.String str48 = utilizadores46.toString();
        Utilizadores utilizadores49 = new Utilizadores();
        java.util.List<Motorista> list_motorista50 = utilizadores49.top5MotoristasComMaiorDesvio();
        boolean b51 = utilizadores46.equals((java.lang.Object) list_motorista50);
        boolean b52 = utilizadores45.equals((java.lang.Object) list_motorista50);
        int i53 = utilizadores1.compareTo(utilizadores45);
        Utilizadores utilizadores54 = new Utilizadores(utilizadores45);
        java.util.Map<java.lang.String, Ator> map_str_ator55 = utilizadores45.getUtilizadores();
        org.junit.Assert.assertNotNull(list_cliente2);
        org.junit.Assert.assertNotNull(list_motorista10);
        org.junit.Assert.assertTrue(i11 == (-1));
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertNotNull(map_str_ator13);
        org.junit.Assert.assertNotNull(ator28);
        org.junit.Assert.assertNotNull(list_motorista43);
        org.junit.Assert.assertNotNull(map_str_ator44);
        org.junit.Assert.assertNotNull(list_cliente47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "------- UMeR --------\n" + "'", str48.equals("------- UMeR --------\n"));
        org.junit.Assert.assertNotNull(list_motorista50);
        org.junit.Assert.assertTrue(b51 == false);
        org.junit.Assert.assertTrue(b52 == false);
        org.junit.Assert.assertTrue(i53 == 3);
        org.junit.Assert.assertNotNull(map_str_ator55);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        boolean b3 = utilizadores0.equals((java.lang.Object) 1L);
        java.util.List<Cliente> list_cliente4 = utilizadores0.top10ClientesGastadores();
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertNotNull(list_cliente4);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        java.util.List<Motorista> list_motorista16 = utilizadores15.top5MotoristasComMaiorDesvio();
        boolean b18 = utilizadores15.equals((java.lang.Object) 1);
        java.util.List<Motorista> list_motorista19 = utilizadores15.top5MotoristasComMaiorDesvio();
        java.util.List<Motorista> list_motorista20 = utilizadores15.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores21 = utilizadores15.clone();
        Utilizadores utilizadores22 = new Utilizadores(utilizadores21);
        java.lang.String str23 = utilizadores22.toString();
        Utilizadores utilizadores24 = new Utilizadores(utilizadores22);
        java.lang.String str25 = utilizadores22.toString();
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(list_motorista16);
        org.junit.Assert.assertTrue(b18 == false);
        org.junit.Assert.assertNotNull(list_motorista19);
        org.junit.Assert.assertNotNull(list_motorista20);
        org.junit.Assert.assertNotNull(utilizadores21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str23.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str25.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        Utilizadores utilizadores0 = new Utilizadores();
        Utilizadores utilizadores1 = utilizadores0.clone();
        Veiculo veiculo7 = null;
        utilizadores0.adiciona("", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!", "", veiculo7);
        utilizadores0.adiciona("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\n\nNome: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: \nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "", "------- UMeR --------\n", "------- UMeR --------\n", "");
        try {
            Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(utilizadores1);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        java.util.List<Cliente> list_cliente16 = utilizadores0.top10ClientesGastadores();
        Veiculo veiculo22 = null;
        utilizadores0.adiciona("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\n\nNome: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: \nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\n\nNome: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: \nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\n", "hi!", veiculo22);
        try {
            Utilizadores utilizadores24 = utilizadores0.clone();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(list_cliente16);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        utilizadores0.adiciona("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "", "hi!", "------- UMeR --------\n");
        Utilizadores utilizadores19 = new Utilizadores();
        java.util.List<Motorista> list_motorista20 = utilizadores19.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores21 = new Utilizadores();
        boolean b23 = utilizadores21.equals((java.lang.Object) (short) 1);
        boolean b24 = utilizadores19.equals((java.lang.Object) b23);
        java.util.Map<java.lang.String, Ator> map_str_ator25 = utilizadores19.getUtilizadores();
        Utilizadores utilizadores26 = new Utilizadores(map_str_ator25);
        java.util.Map<java.lang.String, Ator> map_str_ator27 = utilizadores26.getUtilizadores();
        int i28 = utilizadores0.compareTo(utilizadores26);
        org.junit.Assert.assertNotNull(list_motorista20);
        org.junit.Assert.assertTrue(b23 == false);
        org.junit.Assert.assertTrue(b24 == false);
        org.junit.Assert.assertNotNull(map_str_ator25);
        org.junit.Assert.assertNotNull(map_str_ator27);
        org.junit.Assert.assertTrue(i28 == 1);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        java.util.List<Motorista> list_motorista16 = utilizadores15.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores17 = new Utilizadores(utilizadores15);
        Utilizadores utilizadores18 = new Utilizadores();
        java.util.List<Cliente> list_cliente19 = utilizadores18.top10ClientesGastadores();
        Utilizadores utilizadores20 = new Utilizadores();
        Utilizadores utilizadores21 = new Utilizadores();
        java.util.List<Cliente> list_cliente22 = utilizadores21.top10ClientesGastadores();
        Utilizadores utilizadores23 = new Utilizadores();
        utilizadores23.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista30 = utilizadores23.top5MotoristasComMaiorDesvio();
        int i31 = utilizadores21.compareTo(utilizadores23);
        int i32 = utilizadores20.compareTo(utilizadores21);
        boolean b33 = utilizadores18.equals((java.lang.Object) utilizadores21);
        java.lang.String str34 = utilizadores18.toString();
        int i35 = utilizadores17.compareTo(utilizadores18);
        Utilizadores utilizadores36 = new Utilizadores();
        utilizadores36.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores36.adiciona("", "", "hi!", "", "");
        Ator ator50 = utilizadores36.getAtor("hi!");
        utilizadores18.adiciona(ator50);
        Utilizadores utilizadores52 = utilizadores18.clone();
        Utilizadores utilizadores53 = new Utilizadores();
        Utilizadores utilizadores54 = utilizadores53.clone();
        java.util.Map<java.lang.String, Ator> map_str_ator55 = utilizadores54.getUtilizadores();
        Utilizadores utilizadores56 = utilizadores54.clone();
        Utilizadores utilizadores57 = utilizadores54.clone();
        Utilizadores utilizadores58 = new Utilizadores();
        utilizadores58.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores58.adiciona("", "", "hi!", "", "");
        Ator ator72 = utilizadores58.getAtor("hi!");
        Utilizadores utilizadores73 = new Utilizadores(utilizadores58);
        Utilizadores utilizadores74 = utilizadores58.clone();
        Ator ator76 = utilizadores74.getAtor("");
        utilizadores54.adiciona(ator76);
        utilizadores18.adiciona(ator76);
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(list_motorista16);
        org.junit.Assert.assertNotNull(list_cliente19);
        org.junit.Assert.assertNotNull(list_cliente22);
        org.junit.Assert.assertNotNull(list_motorista30);
        org.junit.Assert.assertTrue(i31 == (-1));
        org.junit.Assert.assertTrue(i32 == 0);
        org.junit.Assert.assertTrue(b33 == true);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "------- UMeR --------\n" + "'", str34.equals("------- UMeR --------\n"));
        org.junit.Assert.assertTrue(i35 == 1);
        org.junit.Assert.assertNotNull(ator50);
        org.junit.Assert.assertNotNull(utilizadores52);
        org.junit.Assert.assertNotNull(utilizadores54);
        org.junit.Assert.assertNotNull(map_str_ator55);
        org.junit.Assert.assertNotNull(utilizadores56);
        org.junit.Assert.assertNotNull(utilizadores57);
        org.junit.Assert.assertNotNull(ator72);
        org.junit.Assert.assertNotNull(utilizadores74);
        org.junit.Assert.assertNotNull(ator76);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores14 = new Utilizadores();
        utilizadores14.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores14.adiciona("", "", "hi!", "", "");
        Ator ator28 = utilizadores14.getAtor("hi!");
        Utilizadores utilizadores29 = new Utilizadores(utilizadores14);
        boolean b30 = utilizadores0.equals((java.lang.Object) utilizadores29);
        java.util.List<Cliente> list_cliente31 = utilizadores0.top10ClientesGastadores();
        try {
            utilizadores0.adiciona("hi!", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
            org.junit.Assert.fail("Expected exception of type EmailAlreadyInUseException");
        } catch (EmailAlreadyInUseException e) {
        }
        org.junit.Assert.assertNotNull(list_motorista13);
        org.junit.Assert.assertNotNull(ator28);
        org.junit.Assert.assertTrue(b30 == true);
        org.junit.Assert.assertNotNull(list_cliente31);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        Utilizadores utilizadores0 = new Utilizadores();
        boolean b2 = utilizadores0.equals((java.lang.Object) (short) 1);
        Utilizadores utilizadores3 = new Utilizadores();
        utilizadores3.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores3.adiciona("", "", "hi!", "", "");
        Ator ator17 = utilizadores3.getAtor("hi!");
        int i18 = utilizadores0.compareTo(utilizadores3);
        Utilizadores utilizadores19 = utilizadores3.clone();
        Utilizadores utilizadores20 = new Utilizadores();
        java.util.List<Cliente> list_cliente21 = utilizadores20.top10ClientesGastadores();
        Utilizadores utilizadores22 = new Utilizadores();
        Utilizadores utilizadores23 = new Utilizadores();
        java.util.List<Cliente> list_cliente24 = utilizadores23.top10ClientesGastadores();
        Utilizadores utilizadores25 = new Utilizadores();
        utilizadores25.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista32 = utilizadores25.top5MotoristasComMaiorDesvio();
        int i33 = utilizadores23.compareTo(utilizadores25);
        int i34 = utilizadores22.compareTo(utilizadores23);
        boolean b35 = utilizadores20.equals((java.lang.Object) utilizadores23);
        Utilizadores utilizadores36 = new Utilizadores();
        utilizadores36.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores36.adiciona("", "", "hi!", "", "");
        Ator ator50 = utilizadores36.getAtor("hi!");
        Utilizadores utilizadores51 = new Utilizadores(utilizadores36);
        java.util.List<Motorista> list_motorista52 = utilizadores51.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores53 = new Utilizadores(utilizadores51);
        Utilizadores utilizadores54 = new Utilizadores();
        java.util.List<Cliente> list_cliente55 = utilizadores54.top10ClientesGastadores();
        Utilizadores utilizadores56 = new Utilizadores();
        Utilizadores utilizadores57 = new Utilizadores();
        java.util.List<Cliente> list_cliente58 = utilizadores57.top10ClientesGastadores();
        Utilizadores utilizadores59 = new Utilizadores();
        utilizadores59.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista66 = utilizadores59.top5MotoristasComMaiorDesvio();
        int i67 = utilizadores57.compareTo(utilizadores59);
        int i68 = utilizadores56.compareTo(utilizadores57);
        boolean b69 = utilizadores54.equals((java.lang.Object) utilizadores57);
        java.lang.String str70 = utilizadores54.toString();
        int i71 = utilizadores53.compareTo(utilizadores54);
        Utilizadores utilizadores72 = new Utilizadores();
        utilizadores72.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores72.adiciona("", "", "hi!", "", "");
        Ator ator86 = utilizadores72.getAtor("hi!");
        utilizadores54.adiciona(ator86);
        utilizadores23.adiciona(ator86);
        try {
            utilizadores3.adiciona(ator86);
            org.junit.Assert.fail("Expected exception of type EmailAlreadyInUseException");
        } catch (EmailAlreadyInUseException e) {
        }
        org.junit.Assert.assertTrue(b2 == false);
        org.junit.Assert.assertNotNull(ator17);
        org.junit.Assert.assertTrue(i18 == (-1));
        org.junit.Assert.assertNotNull(utilizadores19);
        org.junit.Assert.assertNotNull(list_cliente21);
        org.junit.Assert.assertNotNull(list_cliente24);
        org.junit.Assert.assertNotNull(list_motorista32);
        org.junit.Assert.assertTrue(i33 == (-1));
        org.junit.Assert.assertTrue(i34 == 0);
        org.junit.Assert.assertTrue(b35 == true);
        org.junit.Assert.assertNotNull(ator50);
        org.junit.Assert.assertNotNull(list_motorista52);
        org.junit.Assert.assertNotNull(list_cliente55);
        org.junit.Assert.assertNotNull(list_cliente58);
        org.junit.Assert.assertNotNull(list_motorista66);
        org.junit.Assert.assertTrue(i67 == (-1));
        org.junit.Assert.assertTrue(i68 == 0);
        org.junit.Assert.assertTrue(b69 == true);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "------- UMeR --------\n" + "'", str70.equals("------- UMeR --------\n"));
        org.junit.Assert.assertTrue(i71 == 1);
        org.junit.Assert.assertNotNull(ator86);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores14 = utilizadores0.clone();
        java.util.List<Motorista> list_motorista15 = utilizadores0.top5MotoristasComMaiorDesvio();
        org.junit.Assert.assertNotNull(list_motorista13);
        org.junit.Assert.assertNotNull(utilizadores14);
        org.junit.Assert.assertNotNull(list_motorista15);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        Utilizadores utilizadores16 = new Utilizadores();
        java.util.List<Cliente> list_cliente17 = utilizadores16.top10ClientesGastadores();
        Utilizadores utilizadores18 = new Utilizadores();
        Utilizadores utilizadores19 = new Utilizadores();
        java.util.List<Cliente> list_cliente20 = utilizadores19.top10ClientesGastadores();
        Utilizadores utilizadores21 = new Utilizadores();
        utilizadores21.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista28 = utilizadores21.top5MotoristasComMaiorDesvio();
        int i29 = utilizadores19.compareTo(utilizadores21);
        int i30 = utilizadores18.compareTo(utilizadores19);
        boolean b31 = utilizadores16.equals((java.lang.Object) utilizadores19);
        Utilizadores utilizadores32 = utilizadores16.clone();
        boolean b33 = utilizadores0.equals((java.lang.Object) utilizadores16);
        Utilizadores utilizadores34 = new Utilizadores(utilizadores0);
        Utilizadores utilizadores35 = utilizadores34.clone();
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_cliente4);
        org.junit.Assert.assertNotNull(list_motorista12);
        org.junit.Assert.assertTrue(i13 == (-1));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(b15 == true);
        org.junit.Assert.assertNotNull(list_cliente17);
        org.junit.Assert.assertNotNull(list_cliente20);
        org.junit.Assert.assertNotNull(list_motorista28);
        org.junit.Assert.assertTrue(i29 == (-1));
        org.junit.Assert.assertTrue(i30 == 0);
        org.junit.Assert.assertTrue(b31 == true);
        org.junit.Assert.assertNotNull(utilizadores32);
        org.junit.Assert.assertTrue(b33 == true);
        org.junit.Assert.assertNotNull(utilizadores35);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        Utilizadores utilizadores16 = new Utilizadores();
        java.util.List<Cliente> list_cliente17 = utilizadores16.top10ClientesGastadores();
        boolean b19 = utilizadores16.equals((java.lang.Object) 100L);
        Utilizadores utilizadores20 = new Utilizadores();
        utilizadores20.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores20.adiciona("", "", "hi!", "", "");
        Ator ator34 = utilizadores20.getAtor("hi!");
        utilizadores16.adiciona(ator34);
        utilizadores3.adiciona(ator34);
        Utilizadores utilizadores37 = new Utilizadores();
        java.util.List<Cliente> list_cliente38 = utilizadores37.top10ClientesGastadores();
        Utilizadores utilizadores39 = new Utilizadores();
        Utilizadores utilizadores40 = new Utilizadores();
        java.util.List<Cliente> list_cliente41 = utilizadores40.top10ClientesGastadores();
        Utilizadores utilizadores42 = new Utilizadores();
        utilizadores42.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista49 = utilizadores42.top5MotoristasComMaiorDesvio();
        int i50 = utilizadores40.compareTo(utilizadores42);
        int i51 = utilizadores39.compareTo(utilizadores40);
        boolean b52 = utilizadores37.equals((java.lang.Object) utilizadores40);
        Utilizadores utilizadores53 = new Utilizadores();
        utilizadores53.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores53.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista66 = utilizadores53.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator67 = utilizadores53.getUtilizadores();
        java.lang.String str68 = utilizadores53.toString();
        int i69 = utilizadores37.compareTo(utilizadores53);
        Utilizadores utilizadores70 = utilizadores53.clone();
        int i71 = utilizadores3.compareTo(utilizadores70);
        try {
            Ator ator73 = utilizadores3.getAtor("");
            org.junit.Assert.fail("Expected exception of type EmailDoesNotExistException");
        } catch (EmailDoesNotExistException e) {
        }
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_cliente4);
        org.junit.Assert.assertNotNull(list_motorista12);
        org.junit.Assert.assertTrue(i13 == (-1));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(b15 == true);
        org.junit.Assert.assertNotNull(list_cliente17);
        org.junit.Assert.assertTrue(b19 == false);
        org.junit.Assert.assertNotNull(ator34);
        org.junit.Assert.assertNotNull(list_cliente38);
        org.junit.Assert.assertNotNull(list_cliente41);
        org.junit.Assert.assertNotNull(list_motorista49);
        org.junit.Assert.assertTrue(i50 == (-1));
        org.junit.Assert.assertTrue(i51 == 0);
        org.junit.Assert.assertTrue(b52 == true);
        org.junit.Assert.assertNotNull(list_motorista66);
        org.junit.Assert.assertNotNull(map_str_ator67);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str68.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertTrue(i69 == (-1));
        org.junit.Assert.assertNotNull(utilizadores70);
        org.junit.Assert.assertTrue(i71 == 3);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        Ator ator17 = utilizadores15.getAtor("");
        Utilizadores utilizadores18 = utilizadores15.clone();
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(ator17);
        org.junit.Assert.assertNotNull(utilizadores18);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        Utilizadores utilizadores16 = new Utilizadores(utilizadores0);
        utilizadores16.adiciona("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\n\nNome: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: \nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "", "hi!", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
        java.util.Map<java.lang.String, Ator> map_str_ator23 = utilizadores16.getUtilizadores();
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(map_str_ator23);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        utilizadores0.adiciona("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "", "hi!", "------- UMeR --------\n");
        java.util.List<Cliente> list_cliente19 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores20 = new Utilizadores(utilizadores0);
        org.junit.Assert.assertNotNull(list_cliente19);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        Utilizadores utilizadores16 = utilizadores0.clone();
        Utilizadores utilizadores17 = new Utilizadores();
        utilizadores17.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores17.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista30 = utilizadores17.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores31 = new Utilizadores();
        java.util.List<Cliente> list_cliente32 = utilizadores31.top10ClientesGastadores();
        Utilizadores utilizadores33 = new Utilizadores();
        Utilizadores utilizadores34 = new Utilizadores();
        java.util.List<Cliente> list_cliente35 = utilizadores34.top10ClientesGastadores();
        Utilizadores utilizadores36 = new Utilizadores();
        utilizadores36.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista43 = utilizadores36.top5MotoristasComMaiorDesvio();
        int i44 = utilizadores34.compareTo(utilizadores36);
        int i45 = utilizadores33.compareTo(utilizadores34);
        boolean b46 = utilizadores31.equals((java.lang.Object) utilizadores34);
        java.lang.String str47 = utilizadores31.toString();
        Utilizadores utilizadores48 = utilizadores31.clone();
        int i49 = utilizadores17.compareTo(utilizadores48);
        int i50 = utilizadores0.compareTo(utilizadores48);
        utilizadores48.adiciona("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\n\nNome: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: \nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\n\nNome: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: \nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "", "");
        utilizadores48.adiciona("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\n\nNome: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: \nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\n\nNome: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: \nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\n\nNome: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: \nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(utilizadores16);
        org.junit.Assert.assertNotNull(list_motorista30);
        org.junit.Assert.assertNotNull(list_cliente32);
        org.junit.Assert.assertNotNull(list_cliente35);
        org.junit.Assert.assertNotNull(list_motorista43);
        org.junit.Assert.assertTrue(i44 == (-1));
        org.junit.Assert.assertTrue(i45 == 0);
        org.junit.Assert.assertTrue(b46 == true);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "------- UMeR --------\n" + "'", str47.equals("------- UMeR --------\n"));
        org.junit.Assert.assertNotNull(utilizadores48);
        org.junit.Assert.assertTrue(i49 == 1);
        org.junit.Assert.assertTrue(i50 == 1);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        utilizadores0.adiciona("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
        java.lang.String str20 = utilizadores0.toString();
        Ator ator22 = utilizadores0.getAtor("");
        Utilizadores utilizadores23 = new Utilizadores(utilizadores0);
        Utilizadores utilizadores24 = new Utilizadores();
        utilizadores24.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores24.adiciona("", "", "hi!", "", "");
        Ator ator38 = utilizadores24.getAtor("hi!");
        Utilizadores utilizadores39 = new Utilizadores(utilizadores24);
        java.util.List<Motorista> list_motorista40 = utilizadores39.top5MotoristasComMaiorDesvio();
        boolean b42 = utilizadores39.equals((java.lang.Object) 1);
        java.util.List<Motorista> list_motorista43 = utilizadores39.top5MotoristasComMaiorDesvio();
        java.util.List<Motorista> list_motorista44 = utilizadores39.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores45 = utilizadores39.clone();
        Utilizadores utilizadores46 = new Utilizadores(utilizadores45);
        java.lang.String str47 = utilizadores46.toString();
        boolean b48 = utilizadores0.equals((java.lang.Object) str47);
        try {
            utilizadores0.adiciona("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "", "hi!", "hi!");
            org.junit.Assert.fail("Expected exception of type EmailAlreadyInUseException");
        } catch (EmailAlreadyInUseException e) {
        }
        org.junit.Assert.assertNotNull(list_motorista13);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str20.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertNotNull(ator22);
        org.junit.Assert.assertNotNull(ator38);
        org.junit.Assert.assertNotNull(list_motorista40);
        org.junit.Assert.assertTrue(b42 == false);
        org.junit.Assert.assertNotNull(list_motorista43);
        org.junit.Assert.assertNotNull(list_motorista44);
        org.junit.Assert.assertNotNull(utilizadores45);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str47.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertTrue(b48 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        Utilizadores utilizadores0 = new Utilizadores();
        Utilizadores utilizadores1 = utilizadores0.clone();
        java.util.Map<java.lang.String, Ator> map_str_ator2 = utilizadores1.getUtilizadores();
        Utilizadores utilizadores3 = utilizadores1.clone();
        Utilizadores utilizadores4 = utilizadores1.clone();
        Utilizadores utilizadores5 = utilizadores1.clone();
        Utilizadores utilizadores6 = utilizadores1.clone();
        org.junit.Assert.assertNotNull(utilizadores1);
        org.junit.Assert.assertNotNull(map_str_ator2);
        org.junit.Assert.assertNotNull(utilizadores3);
        org.junit.Assert.assertNotNull(utilizadores4);
        org.junit.Assert.assertNotNull(utilizadores5);
        org.junit.Assert.assertNotNull(utilizadores6);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        Ator ator17 = utilizadores15.getAtor("");
        Utilizadores utilizadores18 = new Utilizadores();
        java.util.List<Cliente> list_cliente19 = utilizadores18.top10ClientesGastadores();
        Utilizadores utilizadores20 = new Utilizadores();
        Utilizadores utilizadores21 = new Utilizadores();
        java.util.List<Cliente> list_cliente22 = utilizadores21.top10ClientesGastadores();
        Utilizadores utilizadores23 = new Utilizadores();
        utilizadores23.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista30 = utilizadores23.top5MotoristasComMaiorDesvio();
        int i31 = utilizadores21.compareTo(utilizadores23);
        int i32 = utilizadores20.compareTo(utilizadores21);
        boolean b33 = utilizadores18.equals((java.lang.Object) utilizadores21);
        java.lang.String str34 = utilizadores18.toString();
        Utilizadores utilizadores35 = utilizadores18.clone();
        Utilizadores utilizadores36 = new Utilizadores();
        utilizadores36.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores36.adiciona("", "", "hi!", "", "");
        Ator ator50 = utilizadores36.getAtor("hi!");
        Utilizadores utilizadores51 = new Utilizadores(utilizadores36);
        Ator ator53 = utilizadores51.getAtor("");
        utilizadores35.adiciona(ator53);
        try {
            utilizadores15.adiciona(ator53);
            org.junit.Assert.fail("Expected exception of type EmailAlreadyInUseException");
        } catch (EmailAlreadyInUseException e) {
        }
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(ator17);
        org.junit.Assert.assertNotNull(list_cliente19);
        org.junit.Assert.assertNotNull(list_cliente22);
        org.junit.Assert.assertNotNull(list_motorista30);
        org.junit.Assert.assertTrue(i31 == (-1));
        org.junit.Assert.assertTrue(i32 == 0);
        org.junit.Assert.assertTrue(b33 == true);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "------- UMeR --------\n" + "'", str34.equals("------- UMeR --------\n"));
        org.junit.Assert.assertNotNull(utilizadores35);
        org.junit.Assert.assertNotNull(ator50);
        org.junit.Assert.assertNotNull(ator53);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores14 = new Utilizadores(utilizadores0);
        java.util.Map<java.lang.String, Ator> map_str_ator15 = utilizadores14.getUtilizadores();
        java.util.Map<java.lang.String, Ator> map_str_ator16 = utilizadores14.getUtilizadores();
        org.junit.Assert.assertNotNull(list_motorista13);
        org.junit.Assert.assertNotNull(map_str_ator15);
        org.junit.Assert.assertNotNull(map_str_ator16);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        java.util.List<Cliente> list_cliente15 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores16 = new Utilizadores();
        utilizadores16.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores16.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista29 = utilizadores16.top5MotoristasComMaiorDesvio();
        utilizadores16.adiciona("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
        java.lang.String str36 = utilizadores16.toString();
        Ator ator38 = utilizadores16.getAtor("");
        try {
            utilizadores0.adiciona(ator38);
            org.junit.Assert.fail("Expected exception of type EmailAlreadyInUseException");
        } catch (EmailAlreadyInUseException e) {
        }
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(list_cliente15);
        org.junit.Assert.assertNotNull(list_motorista29);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str36.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertNotNull(ator38);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        Utilizadores utilizadores16 = utilizadores0.clone();
        Utilizadores utilizadores17 = new Utilizadores();
        utilizadores17.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores17.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista30 = utilizadores17.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores31 = new Utilizadores();
        java.util.List<Cliente> list_cliente32 = utilizadores31.top10ClientesGastadores();
        Utilizadores utilizadores33 = new Utilizadores();
        Utilizadores utilizadores34 = new Utilizadores();
        java.util.List<Cliente> list_cliente35 = utilizadores34.top10ClientesGastadores();
        Utilizadores utilizadores36 = new Utilizadores();
        utilizadores36.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista43 = utilizadores36.top5MotoristasComMaiorDesvio();
        int i44 = utilizadores34.compareTo(utilizadores36);
        int i45 = utilizadores33.compareTo(utilizadores34);
        boolean b46 = utilizadores31.equals((java.lang.Object) utilizadores34);
        java.lang.String str47 = utilizadores31.toString();
        Utilizadores utilizadores48 = utilizadores31.clone();
        int i49 = utilizadores17.compareTo(utilizadores48);
        int i50 = utilizadores0.compareTo(utilizadores48);
        java.util.List<Motorista> list_motorista51 = utilizadores0.top5MotoristasComMaiorDesvio();
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(utilizadores16);
        org.junit.Assert.assertNotNull(list_motorista30);
        org.junit.Assert.assertNotNull(list_cliente32);
        org.junit.Assert.assertNotNull(list_cliente35);
        org.junit.Assert.assertNotNull(list_motorista43);
        org.junit.Assert.assertTrue(i44 == (-1));
        org.junit.Assert.assertTrue(i45 == 0);
        org.junit.Assert.assertTrue(b46 == true);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "------- UMeR --------\n" + "'", str47.equals("------- UMeR --------\n"));
        org.junit.Assert.assertNotNull(utilizadores48);
        org.junit.Assert.assertTrue(i49 == 1);
        org.junit.Assert.assertTrue(i50 == 1);
        org.junit.Assert.assertNotNull(list_motorista51);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        utilizadores0.adiciona("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
        java.lang.String str20 = utilizadores0.toString();
        Ator ator22 = utilizadores0.getAtor("");
        Utilizadores utilizadores23 = new Utilizadores(utilizadores0);
        try {
            Ator ator25 = utilizadores0.getAtor("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
            org.junit.Assert.fail("Expected exception of type EmailDoesNotExistException");
        } catch (EmailDoesNotExistException e) {
        }
        org.junit.Assert.assertNotNull(list_motorista13);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str20.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertNotNull(ator22);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        utilizadores2.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista9 = utilizadores2.top5MotoristasComMaiorDesvio();
        int i10 = utilizadores0.compareTo(utilizadores2);
        java.lang.String str11 = utilizadores2.toString();
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_motorista9);
        org.junit.Assert.assertTrue(i10 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str11.equals("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        Utilizadores utilizadores16 = new Utilizadores();
        java.util.List<Cliente> list_cliente17 = utilizadores16.top10ClientesGastadores();
        Utilizadores utilizadores18 = new Utilizadores();
        Utilizadores utilizadores19 = new Utilizadores();
        java.util.List<Cliente> list_cliente20 = utilizadores19.top10ClientesGastadores();
        Utilizadores utilizadores21 = new Utilizadores();
        utilizadores21.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista28 = utilizadores21.top5MotoristasComMaiorDesvio();
        int i29 = utilizadores19.compareTo(utilizadores21);
        int i30 = utilizadores18.compareTo(utilizadores19);
        boolean b31 = utilizadores16.equals((java.lang.Object) utilizadores19);
        Utilizadores utilizadores32 = utilizadores16.clone();
        boolean b33 = utilizadores0.equals((java.lang.Object) utilizadores16);
        Utilizadores utilizadores34 = new Utilizadores();
        utilizadores34.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores34.adiciona("", "", "hi!", "", "");
        Ator ator48 = utilizadores34.getAtor("hi!");
        Utilizadores utilizadores49 = new Utilizadores(utilizadores34);
        Ator ator51 = utilizadores49.getAtor("");
        utilizadores0.adiciona(ator51);
        Utilizadores utilizadores53 = utilizadores0.clone();
        Utilizadores utilizadores54 = new Utilizadores();
        utilizadores54.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores54.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista67 = utilizadores54.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator68 = utilizadores54.getUtilizadores();
        Utilizadores utilizadores69 = new Utilizadores(map_str_ator68);
        Utilizadores utilizadores70 = new Utilizadores();
        utilizadores70.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores70.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista83 = utilizadores70.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator84 = utilizadores70.getUtilizadores();
        Utilizadores utilizadores85 = new Utilizadores(map_str_ator84);
        int i86 = utilizadores69.compareTo(utilizadores85);
        boolean b87 = utilizadores53.equals((java.lang.Object) utilizadores85);
        java.util.List<Cliente> list_cliente88 = utilizadores53.top10ClientesGastadores();
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_cliente4);
        org.junit.Assert.assertNotNull(list_motorista12);
        org.junit.Assert.assertTrue(i13 == (-1));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(b15 == true);
        org.junit.Assert.assertNotNull(list_cliente17);
        org.junit.Assert.assertNotNull(list_cliente20);
        org.junit.Assert.assertNotNull(list_motorista28);
        org.junit.Assert.assertTrue(i29 == (-1));
        org.junit.Assert.assertTrue(i30 == 0);
        org.junit.Assert.assertTrue(b31 == true);
        org.junit.Assert.assertNotNull(utilizadores32);
        org.junit.Assert.assertTrue(b33 == true);
        org.junit.Assert.assertNotNull(ator48);
        org.junit.Assert.assertNotNull(ator51);
        org.junit.Assert.assertNotNull(utilizadores53);
        org.junit.Assert.assertNotNull(list_motorista67);
        org.junit.Assert.assertNotNull(map_str_ator68);
        org.junit.Assert.assertNotNull(list_motorista83);
        org.junit.Assert.assertNotNull(map_str_ator84);
        org.junit.Assert.assertTrue(i86 == 0);
        org.junit.Assert.assertTrue(b87 == false);
        org.junit.Assert.assertNotNull(list_cliente88);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        Utilizadores utilizadores16 = new Utilizadores();
        java.util.List<Cliente> list_cliente17 = utilizadores16.top10ClientesGastadores();
        Utilizadores utilizadores18 = new Utilizadores();
        Utilizadores utilizadores19 = new Utilizadores();
        java.util.List<Cliente> list_cliente20 = utilizadores19.top10ClientesGastadores();
        Utilizadores utilizadores21 = new Utilizadores();
        utilizadores21.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista28 = utilizadores21.top5MotoristasComMaiorDesvio();
        int i29 = utilizadores19.compareTo(utilizadores21);
        int i30 = utilizadores18.compareTo(utilizadores19);
        boolean b31 = utilizadores16.equals((java.lang.Object) utilizadores19);
        Utilizadores utilizadores32 = utilizadores16.clone();
        boolean b33 = utilizadores0.equals((java.lang.Object) utilizadores16);
        Utilizadores utilizadores34 = new Utilizadores();
        utilizadores34.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores34.adiciona("", "", "hi!", "", "");
        Ator ator48 = utilizadores34.getAtor("hi!");
        Utilizadores utilizadores49 = new Utilizadores(utilizadores34);
        Ator ator51 = utilizadores49.getAtor("");
        utilizadores0.adiciona(ator51);
        Utilizadores utilizadores53 = utilizadores0.clone();
        Utilizadores utilizadores54 = new Utilizadores(utilizadores53);
        Utilizadores utilizadores55 = new Utilizadores();
        java.util.List<Cliente> list_cliente56 = utilizadores55.top10ClientesGastadores();
        Utilizadores utilizadores57 = new Utilizadores();
        Utilizadores utilizadores58 = new Utilizadores();
        java.util.List<Cliente> list_cliente59 = utilizadores58.top10ClientesGastadores();
        Utilizadores utilizadores60 = new Utilizadores();
        utilizadores60.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista67 = utilizadores60.top5MotoristasComMaiorDesvio();
        int i68 = utilizadores58.compareTo(utilizadores60);
        int i69 = utilizadores57.compareTo(utilizadores58);
        boolean b70 = utilizadores55.equals((java.lang.Object) utilizadores58);
        java.lang.String str71 = utilizadores55.toString();
        Utilizadores utilizadores72 = utilizadores55.clone();
        Utilizadores utilizadores73 = new Utilizadores();
        utilizadores73.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores73.adiciona("", "", "hi!", "", "");
        Ator ator87 = utilizadores73.getAtor("hi!");
        Utilizadores utilizadores88 = new Utilizadores(utilizadores73);
        Ator ator90 = utilizadores88.getAtor("");
        utilizadores72.adiciona(ator90);
        try {
            utilizadores54.adiciona(ator90);
            org.junit.Assert.fail("Expected exception of type EmailAlreadyInUseException");
        } catch (EmailAlreadyInUseException e) {
        }
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_cliente4);
        org.junit.Assert.assertNotNull(list_motorista12);
        org.junit.Assert.assertTrue(i13 == (-1));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(b15 == true);
        org.junit.Assert.assertNotNull(list_cliente17);
        org.junit.Assert.assertNotNull(list_cliente20);
        org.junit.Assert.assertNotNull(list_motorista28);
        org.junit.Assert.assertTrue(i29 == (-1));
        org.junit.Assert.assertTrue(i30 == 0);
        org.junit.Assert.assertTrue(b31 == true);
        org.junit.Assert.assertNotNull(utilizadores32);
        org.junit.Assert.assertTrue(b33 == true);
        org.junit.Assert.assertNotNull(ator48);
        org.junit.Assert.assertNotNull(ator51);
        org.junit.Assert.assertNotNull(utilizadores53);
        org.junit.Assert.assertNotNull(list_cliente56);
        org.junit.Assert.assertNotNull(list_cliente59);
        org.junit.Assert.assertNotNull(list_motorista67);
        org.junit.Assert.assertTrue(i68 == (-1));
        org.junit.Assert.assertTrue(i69 == 0);
        org.junit.Assert.assertTrue(b70 == true);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "------- UMeR --------\n" + "'", str71.equals("------- UMeR --------\n"));
        org.junit.Assert.assertNotNull(utilizadores72);
        org.junit.Assert.assertNotNull(ator87);
        org.junit.Assert.assertNotNull(ator90);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        Utilizadores utilizadores7 = utilizadores0.clone();
        Veiculo veiculo13 = null;
        utilizadores0.adiciona("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "", "------- UMeR --------\n", "", "------- UMeR --------\n", veiculo13);
        utilizadores0.adiciona("", "------- UMeR --------\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\n");
        Veiculo veiculo26 = null;
        utilizadores0.adiciona("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\n", veiculo26);
        Utilizadores utilizadores28 = new Utilizadores();
        java.util.List<Cliente> list_cliente29 = utilizadores28.top10ClientesGastadores();
        boolean b31 = utilizadores28.equals((java.lang.Object) 100L);
        Utilizadores utilizadores32 = new Utilizadores();
        utilizadores32.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores32.adiciona("", "", "hi!", "", "");
        Ator ator46 = utilizadores32.getAtor("hi!");
        utilizadores28.adiciona(ator46);
        try {
            utilizadores0.adiciona(ator46);
            org.junit.Assert.fail("Expected exception of type EmailAlreadyInUseException");
        } catch (EmailAlreadyInUseException e) {
        }
        org.junit.Assert.assertNotNull(utilizadores7);
        org.junit.Assert.assertNotNull(list_cliente29);
        org.junit.Assert.assertTrue(b31 == false);
        org.junit.Assert.assertNotNull(ator46);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        java.util.List<Motorista> list_motorista16 = utilizadores15.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores17 = new Utilizadores(utilizadores15);
        Utilizadores utilizadores18 = new Utilizadores(utilizadores17);
        java.util.Map<java.lang.String, Ator> map_str_ator19 = utilizadores18.getUtilizadores();
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(list_motorista16);
        org.junit.Assert.assertNotNull(map_str_ator19);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        Utilizadores utilizadores0 = new Utilizadores();
        Utilizadores utilizadores1 = new Utilizadores();
        java.util.List<Cliente> list_cliente2 = utilizadores1.top10ClientesGastadores();
        Utilizadores utilizadores3 = new Utilizadores();
        utilizadores3.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista10 = utilizadores3.top5MotoristasComMaiorDesvio();
        int i11 = utilizadores1.compareTo(utilizadores3);
        int i12 = utilizadores0.compareTo(utilizadores1);
        java.util.Map<java.lang.String, Ator> map_str_ator13 = utilizadores1.getUtilizadores();
        Utilizadores utilizadores14 = new Utilizadores();
        utilizadores14.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores14.adiciona("", "", "hi!", "", "");
        Ator ator28 = utilizadores14.getAtor("hi!");
        utilizadores1.adiciona(ator28);
        Utilizadores utilizadores30 = new Utilizadores();
        utilizadores30.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores30.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista43 = utilizadores30.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator44 = utilizadores30.getUtilizadores();
        Utilizadores utilizadores45 = new Utilizadores(map_str_ator44);
        Utilizadores utilizadores46 = new Utilizadores();
        java.util.List<Cliente> list_cliente47 = utilizadores46.top10ClientesGastadores();
        java.lang.String str48 = utilizadores46.toString();
        Utilizadores utilizadores49 = new Utilizadores();
        java.util.List<Motorista> list_motorista50 = utilizadores49.top5MotoristasComMaiorDesvio();
        boolean b51 = utilizadores46.equals((java.lang.Object) list_motorista50);
        boolean b52 = utilizadores45.equals((java.lang.Object) list_motorista50);
        int i53 = utilizadores1.compareTo(utilizadores45);
        Utilizadores utilizadores54 = new Utilizadores(utilizadores45);
        java.util.List<Motorista> list_motorista55 = utilizadores45.top5MotoristasComMaiorDesvio();
        java.util.List<Cliente> list_cliente56 = utilizadores45.top10ClientesGastadores();
        boolean b58 = utilizadores45.equals((java.lang.Object) "------- UMeR --------\n");
        org.junit.Assert.assertNotNull(list_cliente2);
        org.junit.Assert.assertNotNull(list_motorista10);
        org.junit.Assert.assertTrue(i11 == (-1));
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertNotNull(map_str_ator13);
        org.junit.Assert.assertNotNull(ator28);
        org.junit.Assert.assertNotNull(list_motorista43);
        org.junit.Assert.assertNotNull(map_str_ator44);
        org.junit.Assert.assertNotNull(list_cliente47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "------- UMeR --------\n" + "'", str48.equals("------- UMeR --------\n"));
        org.junit.Assert.assertNotNull(list_motorista50);
        org.junit.Assert.assertTrue(b51 == false);
        org.junit.Assert.assertTrue(b52 == false);
        org.junit.Assert.assertTrue(i53 == 3);
        org.junit.Assert.assertNotNull(list_motorista55);
        org.junit.Assert.assertNotNull(list_cliente56);
        org.junit.Assert.assertTrue(b58 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        java.util.List<Motorista> list_motorista16 = utilizadores15.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores17 = new Utilizadores(utilizadores15);
        Utilizadores utilizadores18 = new Utilizadores();
        java.util.List<Cliente> list_cliente19 = utilizadores18.top10ClientesGastadores();
        Utilizadores utilizadores20 = new Utilizadores();
        Utilizadores utilizadores21 = new Utilizadores();
        java.util.List<Cliente> list_cliente22 = utilizadores21.top10ClientesGastadores();
        Utilizadores utilizadores23 = new Utilizadores();
        utilizadores23.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista30 = utilizadores23.top5MotoristasComMaiorDesvio();
        int i31 = utilizadores21.compareTo(utilizadores23);
        int i32 = utilizadores20.compareTo(utilizadores21);
        boolean b33 = utilizadores18.equals((java.lang.Object) utilizadores21);
        java.lang.String str34 = utilizadores18.toString();
        int i35 = utilizadores17.compareTo(utilizadores18);
        Utilizadores utilizadores36 = utilizadores17.clone();
        Utilizadores utilizadores37 = new Utilizadores();
        utilizadores37.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores37.adiciona("", "", "hi!", "", "");
        Ator ator51 = utilizadores37.getAtor("hi!");
        Utilizadores utilizadores52 = new Utilizadores(utilizadores37);
        java.util.List<Motorista> list_motorista53 = utilizadores52.top5MotoristasComMaiorDesvio();
        boolean b55 = utilizadores52.equals((java.lang.Object) 1);
        java.util.List<Motorista> list_motorista56 = utilizadores52.top5MotoristasComMaiorDesvio();
        java.util.List<Motorista> list_motorista57 = utilizadores52.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores58 = utilizadores52.clone();
        int i59 = utilizadores17.compareTo(utilizadores52);
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(list_motorista16);
        org.junit.Assert.assertNotNull(list_cliente19);
        org.junit.Assert.assertNotNull(list_cliente22);
        org.junit.Assert.assertNotNull(list_motorista30);
        org.junit.Assert.assertTrue(i31 == (-1));
        org.junit.Assert.assertTrue(i32 == 0);
        org.junit.Assert.assertTrue(b33 == true);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "------- UMeR --------\n" + "'", str34.equals("------- UMeR --------\n"));
        org.junit.Assert.assertTrue(i35 == 1);
        org.junit.Assert.assertNotNull(utilizadores36);
        org.junit.Assert.assertNotNull(ator51);
        org.junit.Assert.assertNotNull(list_motorista53);
        org.junit.Assert.assertTrue(b55 == false);
        org.junit.Assert.assertNotNull(list_motorista56);
        org.junit.Assert.assertNotNull(list_motorista57);
        org.junit.Assert.assertNotNull(utilizadores58);
        org.junit.Assert.assertTrue(i59 == 0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        Utilizadores utilizadores16 = new Utilizadores();
        utilizadores16.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores16.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista29 = utilizadores16.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator30 = utilizadores16.getUtilizadores();
        java.lang.String str31 = utilizadores16.toString();
        int i32 = utilizadores0.compareTo(utilizadores16);
        Utilizadores utilizadores33 = utilizadores16.clone();
        java.lang.String str34 = utilizadores16.toString();
        utilizadores16.adiciona("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!");
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_cliente4);
        org.junit.Assert.assertNotNull(list_motorista12);
        org.junit.Assert.assertTrue(i13 == (-1));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(b15 == true);
        org.junit.Assert.assertNotNull(list_motorista29);
        org.junit.Assert.assertNotNull(map_str_ator30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str31.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertTrue(i32 == (-1));
        org.junit.Assert.assertNotNull(utilizadores33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str34.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        Utilizadores utilizadores16 = new Utilizadores(utilizadores0);
        Utilizadores utilizadores17 = new Utilizadores();
        utilizadores17.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores17.adiciona("", "", "hi!", "", "");
        Ator ator31 = utilizadores17.getAtor("");
        try {
            utilizadores16.adiciona(ator31);
            org.junit.Assert.fail("Expected exception of type EmailAlreadyInUseException");
        } catch (EmailAlreadyInUseException e) {
        }
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(ator31);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        Utilizadores utilizadores7 = utilizadores0.clone();
        java.lang.String str8 = utilizadores7.toString();
        java.lang.String str9 = utilizadores7.toString();
        Utilizadores utilizadores10 = new Utilizadores();
        java.util.List<Cliente> list_cliente11 = utilizadores10.top10ClientesGastadores();
        Utilizadores utilizadores12 = new Utilizadores();
        Utilizadores utilizadores13 = new Utilizadores();
        java.util.List<Cliente> list_cliente14 = utilizadores13.top10ClientesGastadores();
        Utilizadores utilizadores15 = new Utilizadores();
        utilizadores15.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista22 = utilizadores15.top5MotoristasComMaiorDesvio();
        int i23 = utilizadores13.compareTo(utilizadores15);
        int i24 = utilizadores12.compareTo(utilizadores13);
        boolean b25 = utilizadores10.equals((java.lang.Object) utilizadores13);
        java.lang.String str26 = utilizadores10.toString();
        Utilizadores utilizadores27 = utilizadores10.clone();
        int i28 = utilizadores7.compareTo(utilizadores27);
        org.junit.Assert.assertNotNull(utilizadores7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str8.equals("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str9.equals("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertNotNull(list_cliente11);
        org.junit.Assert.assertNotNull(list_cliente14);
        org.junit.Assert.assertNotNull(list_motorista22);
        org.junit.Assert.assertTrue(i23 == (-1));
        org.junit.Assert.assertTrue(i24 == 0);
        org.junit.Assert.assertTrue(b25 == true);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "------- UMeR --------\n" + "'", str26.equals("------- UMeR --------\n"));
        org.junit.Assert.assertNotNull(utilizadores27);
        org.junit.Assert.assertTrue(i28 == 1);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        Utilizadores utilizadores7 = utilizadores0.clone();
        Veiculo veiculo13 = null;
        utilizadores0.adiciona("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "", "------- UMeR --------\n", "", "------- UMeR --------\n", veiculo13);
        utilizadores0.adiciona("", "------- UMeR --------\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\n");
        Veiculo veiculo26 = null;
        utilizadores0.adiciona("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\n", veiculo26);
        java.util.Map<java.lang.String, Ator> map_str_ator28 = utilizadores0.getUtilizadores();
        org.junit.Assert.assertNotNull(utilizadores7);
        org.junit.Assert.assertNotNull(map_str_ator28);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        Utilizadores utilizadores0 = new Utilizadores();
        Utilizadores utilizadores1 = new Utilizadores();
        java.util.List<Cliente> list_cliente2 = utilizadores1.top10ClientesGastadores();
        Utilizadores utilizadores3 = new Utilizadores();
        utilizadores3.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista10 = utilizadores3.top5MotoristasComMaiorDesvio();
        int i11 = utilizadores1.compareTo(utilizadores3);
        int i12 = utilizadores0.compareTo(utilizadores1);
        java.util.Map<java.lang.String, Ator> map_str_ator13 = utilizadores1.getUtilizadores();
        Utilizadores utilizadores14 = new Utilizadores();
        utilizadores14.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores14.adiciona("", "", "hi!", "", "");
        Ator ator28 = utilizadores14.getAtor("hi!");
        utilizadores1.adiciona(ator28);
        Utilizadores utilizadores30 = new Utilizadores();
        utilizadores30.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores30.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista43 = utilizadores30.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator44 = utilizadores30.getUtilizadores();
        Utilizadores utilizadores45 = new Utilizadores(map_str_ator44);
        Utilizadores utilizadores46 = new Utilizadores();
        java.util.List<Cliente> list_cliente47 = utilizadores46.top10ClientesGastadores();
        java.lang.String str48 = utilizadores46.toString();
        Utilizadores utilizadores49 = new Utilizadores();
        java.util.List<Motorista> list_motorista50 = utilizadores49.top5MotoristasComMaiorDesvio();
        boolean b51 = utilizadores46.equals((java.lang.Object) list_motorista50);
        boolean b52 = utilizadores45.equals((java.lang.Object) list_motorista50);
        int i53 = utilizadores1.compareTo(utilizadores45);
        Utilizadores utilizadores54 = new Utilizadores(utilizadores45);
        Utilizadores utilizadores55 = new Utilizadores();
        java.util.List<Cliente> list_cliente56 = utilizadores55.top10ClientesGastadores();
        boolean b58 = utilizadores55.equals((java.lang.Object) 100L);
        Utilizadores utilizadores59 = new Utilizadores();
        utilizadores59.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores59.adiciona("", "", "hi!", "", "");
        Ator ator73 = utilizadores59.getAtor("hi!");
        utilizadores55.adiciona(ator73);
        try {
            utilizadores54.adiciona(ator73);
            org.junit.Assert.fail("Expected exception of type EmailAlreadyInUseException");
        } catch (EmailAlreadyInUseException e) {
        }
        org.junit.Assert.assertNotNull(list_cliente2);
        org.junit.Assert.assertNotNull(list_motorista10);
        org.junit.Assert.assertTrue(i11 == (-1));
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertNotNull(map_str_ator13);
        org.junit.Assert.assertNotNull(ator28);
        org.junit.Assert.assertNotNull(list_motorista43);
        org.junit.Assert.assertNotNull(map_str_ator44);
        org.junit.Assert.assertNotNull(list_cliente47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "------- UMeR --------\n" + "'", str48.equals("------- UMeR --------\n"));
        org.junit.Assert.assertNotNull(list_motorista50);
        org.junit.Assert.assertTrue(b51 == false);
        org.junit.Assert.assertTrue(b52 == false);
        org.junit.Assert.assertTrue(i53 == 3);
        org.junit.Assert.assertNotNull(list_cliente56);
        org.junit.Assert.assertTrue(b58 == false);
        org.junit.Assert.assertNotNull(ator73);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        Utilizadores utilizadores0 = new Utilizadores();
        boolean b2 = utilizadores0.equals((java.lang.Object) (short) 1);
        Utilizadores utilizadores3 = new Utilizadores();
        utilizadores3.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores3.adiciona("", "", "hi!", "", "");
        Ator ator17 = utilizadores3.getAtor("hi!");
        int i18 = utilizadores0.compareTo(utilizadores3);
        Utilizadores utilizadores19 = new Utilizadores();
        java.util.List<Cliente> list_cliente20 = utilizadores19.top10ClientesGastadores();
        Utilizadores utilizadores21 = new Utilizadores();
        Utilizadores utilizadores22 = new Utilizadores();
        java.util.List<Cliente> list_cliente23 = utilizadores22.top10ClientesGastadores();
        Utilizadores utilizadores24 = new Utilizadores();
        utilizadores24.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista31 = utilizadores24.top5MotoristasComMaiorDesvio();
        int i32 = utilizadores22.compareTo(utilizadores24);
        int i33 = utilizadores21.compareTo(utilizadores22);
        boolean b34 = utilizadores19.equals((java.lang.Object) utilizadores22);
        java.lang.String str35 = utilizadores19.toString();
        int i36 = utilizadores0.compareTo(utilizadores19);
        java.util.List<Cliente> list_cliente37 = utilizadores0.top10ClientesGastadores();
        org.junit.Assert.assertTrue(b2 == false);
        org.junit.Assert.assertNotNull(ator17);
        org.junit.Assert.assertTrue(i18 == (-1));
        org.junit.Assert.assertNotNull(list_cliente20);
        org.junit.Assert.assertNotNull(list_cliente23);
        org.junit.Assert.assertNotNull(list_motorista31);
        org.junit.Assert.assertTrue(i32 == (-1));
        org.junit.Assert.assertTrue(i33 == 0);
        org.junit.Assert.assertTrue(b34 == true);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "------- UMeR --------\n" + "'", str35.equals("------- UMeR --------\n"));
        org.junit.Assert.assertTrue(i36 == 0);
        org.junit.Assert.assertNotNull(list_cliente37);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        Utilizadores utilizadores0 = new Utilizadores();
        Utilizadores utilizadores1 = utilizadores0.clone();
        java.util.Map<java.lang.String, Ator> map_str_ator2 = utilizadores1.getUtilizadores();
        Utilizadores utilizadores3 = utilizadores1.clone();
        Utilizadores utilizadores4 = utilizadores1.clone();
        Veiculo veiculo10 = null;
        utilizadores4.adiciona("hi!", "------- UMeR --------\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", veiculo10);
        org.junit.Assert.assertNotNull(utilizadores1);
        org.junit.Assert.assertNotNull(map_str_ator2);
        org.junit.Assert.assertNotNull(utilizadores3);
        org.junit.Assert.assertNotNull(utilizadores4);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        Utilizadores utilizadores0 = new Utilizadores();
        Utilizadores utilizadores1 = new Utilizadores();
        java.util.List<Cliente> list_cliente2 = utilizadores1.top10ClientesGastadores();
        Utilizadores utilizadores3 = new Utilizadores();
        utilizadores3.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista10 = utilizadores3.top5MotoristasComMaiorDesvio();
        int i11 = utilizadores1.compareTo(utilizadores3);
        int i12 = utilizadores0.compareTo(utilizadores1);
        java.util.Map<java.lang.String, Ator> map_str_ator13 = utilizadores1.getUtilizadores();
        Utilizadores utilizadores14 = utilizadores1.clone();
        Utilizadores utilizadores15 = new Utilizadores();
        utilizadores15.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores15.adiciona("", "", "hi!", "", "");
        Ator ator29 = utilizadores15.getAtor("hi!");
        Utilizadores utilizadores30 = new Utilizadores();
        utilizadores30.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores30.adiciona("", "", "hi!", "", "");
        Ator ator44 = utilizadores30.getAtor("hi!");
        Utilizadores utilizadores45 = new Utilizadores(utilizadores30);
        java.util.List<Motorista> list_motorista46 = utilizadores45.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores47 = utilizadores45.clone();
        int i48 = utilizadores15.compareTo(utilizadores45);
        Utilizadores utilizadores49 = new Utilizadores(utilizadores45);
        java.util.List<Cliente> list_cliente50 = utilizadores49.top10ClientesGastadores();
        int i51 = utilizadores14.compareTo(utilizadores49);
        org.junit.Assert.assertNotNull(list_cliente2);
        org.junit.Assert.assertNotNull(list_motorista10);
        org.junit.Assert.assertTrue(i11 == (-1));
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertNotNull(map_str_ator13);
        org.junit.Assert.assertNotNull(utilizadores14);
        org.junit.Assert.assertNotNull(ator29);
        org.junit.Assert.assertNotNull(ator44);
        org.junit.Assert.assertNotNull(list_motorista46);
        org.junit.Assert.assertNotNull(utilizadores47);
        org.junit.Assert.assertTrue(i48 == 0);
        org.junit.Assert.assertNotNull(list_cliente50);
        org.junit.Assert.assertTrue(i51 == (-1));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        java.util.List<Motorista> list_motorista16 = utilizadores15.top5MotoristasComMaiorDesvio();
        boolean b18 = utilizadores15.equals((java.lang.Object) 1);
        java.util.List<Motorista> list_motorista19 = utilizadores15.top5MotoristasComMaiorDesvio();
        java.util.List<Motorista> list_motorista20 = utilizadores15.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores21 = utilizadores15.clone();
        java.util.List<Motorista> list_motorista22 = utilizadores15.top5MotoristasComMaiorDesvio();
        try {
            utilizadores15.adiciona("", "", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
            org.junit.Assert.fail("Expected exception of type EmailAlreadyInUseException");
        } catch (EmailAlreadyInUseException e) {
        }
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(list_motorista16);
        org.junit.Assert.assertTrue(b18 == false);
        org.junit.Assert.assertNotNull(list_motorista19);
        org.junit.Assert.assertNotNull(list_motorista20);
        org.junit.Assert.assertNotNull(utilizadores21);
        org.junit.Assert.assertNotNull(list_motorista22);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        Utilizadores utilizadores0 = new Utilizadores();
        boolean b2 = utilizadores0.equals((java.lang.Object) (short) 1);
        Utilizadores utilizadores3 = new Utilizadores();
        utilizadores3.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores3.adiciona("", "", "hi!", "", "");
        Ator ator17 = utilizadores3.getAtor("hi!");
        int i18 = utilizadores0.compareTo(utilizadores3);
        Utilizadores utilizadores19 = new Utilizadores();
        java.util.List<Motorista> list_motorista20 = utilizadores19.top5MotoristasComMaiorDesvio();
        int i21 = utilizadores3.compareTo(utilizadores19);
        Utilizadores utilizadores22 = utilizadores3.clone();
        java.util.List<Motorista> list_motorista23 = utilizadores22.top5MotoristasComMaiorDesvio();
        org.junit.Assert.assertTrue(b2 == false);
        org.junit.Assert.assertNotNull(ator17);
        org.junit.Assert.assertTrue(i18 == (-1));
        org.junit.Assert.assertNotNull(list_motorista20);
        org.junit.Assert.assertTrue(i21 == 1);
        org.junit.Assert.assertNotNull(utilizadores22);
        org.junit.Assert.assertNotNull(list_motorista23);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        Utilizadores utilizadores16 = new Utilizadores(utilizadores0);
        Utilizadores utilizadores17 = new Utilizadores();
        utilizadores17.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores17.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista30 = utilizadores17.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator31 = utilizadores17.getUtilizadores();
        Utilizadores utilizadores32 = new Utilizadores(map_str_ator31);
        Utilizadores utilizadores33 = new Utilizadores();
        java.util.List<Cliente> list_cliente34 = utilizadores33.top10ClientesGastadores();
        java.lang.String str35 = utilizadores33.toString();
        Utilizadores utilizadores36 = new Utilizadores();
        java.util.List<Motorista> list_motorista37 = utilizadores36.top5MotoristasComMaiorDesvio();
        boolean b38 = utilizadores33.equals((java.lang.Object) list_motorista37);
        boolean b39 = utilizadores32.equals((java.lang.Object) list_motorista37);
        int i40 = utilizadores0.compareTo(utilizadores32);
        Veiculo veiculo46 = null;
        utilizadores32.adiciona("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "", "", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "", veiculo46);
        Veiculo veiculo53 = null;
        try {
            utilizadores32.adiciona("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\n", veiculo53);
            org.junit.Assert.fail("Expected exception of type EmailAlreadyInUseException");
        } catch (EmailAlreadyInUseException e) {
        }
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(list_motorista30);
        org.junit.Assert.assertNotNull(map_str_ator31);
        org.junit.Assert.assertNotNull(list_cliente34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "------- UMeR --------\n" + "'", str35.equals("------- UMeR --------\n"));
        org.junit.Assert.assertNotNull(list_motorista37);
        org.junit.Assert.assertTrue(b38 == false);
        org.junit.Assert.assertTrue(b39 == false);
        org.junit.Assert.assertTrue(i40 == 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        Utilizadores utilizadores16 = new Utilizadores();
        java.util.List<Cliente> list_cliente17 = utilizadores16.top10ClientesGastadores();
        Utilizadores utilizadores18 = new Utilizadores();
        Utilizadores utilizadores19 = new Utilizadores();
        java.util.List<Cliente> list_cliente20 = utilizadores19.top10ClientesGastadores();
        Utilizadores utilizadores21 = new Utilizadores();
        utilizadores21.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista28 = utilizadores21.top5MotoristasComMaiorDesvio();
        int i29 = utilizadores19.compareTo(utilizadores21);
        int i30 = utilizadores18.compareTo(utilizadores19);
        boolean b31 = utilizadores16.equals((java.lang.Object) utilizadores19);
        Utilizadores utilizadores32 = utilizadores16.clone();
        boolean b33 = utilizadores0.equals((java.lang.Object) utilizadores16);
        Utilizadores utilizadores34 = new Utilizadores(utilizadores0);
        Utilizadores utilizadores35 = new Utilizadores();
        java.util.List<Cliente> list_cliente36 = utilizadores35.top10ClientesGastadores();
        java.lang.String str37 = utilizadores35.toString();
        Utilizadores utilizadores38 = new Utilizadores();
        java.util.List<Motorista> list_motorista39 = utilizadores38.top5MotoristasComMaiorDesvio();
        boolean b40 = utilizadores35.equals((java.lang.Object) list_motorista39);
        int i41 = utilizadores0.compareTo(utilizadores35);
        Utilizadores utilizadores42 = new Utilizadores();
        utilizadores42.adiciona("hi!", "hi!", "", "", "hi!");
        Utilizadores utilizadores49 = utilizadores42.clone();
        boolean b50 = utilizadores0.equals((java.lang.Object) utilizadores49);
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_cliente4);
        org.junit.Assert.assertNotNull(list_motorista12);
        org.junit.Assert.assertTrue(i13 == (-1));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(b15 == true);
        org.junit.Assert.assertNotNull(list_cliente17);
        org.junit.Assert.assertNotNull(list_cliente20);
        org.junit.Assert.assertNotNull(list_motorista28);
        org.junit.Assert.assertTrue(i29 == (-1));
        org.junit.Assert.assertTrue(i30 == 0);
        org.junit.Assert.assertTrue(b31 == true);
        org.junit.Assert.assertNotNull(utilizadores32);
        org.junit.Assert.assertTrue(b33 == true);
        org.junit.Assert.assertNotNull(list_cliente36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "------- UMeR --------\n" + "'", str37.equals("------- UMeR --------\n"));
        org.junit.Assert.assertNotNull(list_motorista39);
        org.junit.Assert.assertTrue(b40 == false);
        org.junit.Assert.assertTrue(i41 == 0);
        org.junit.Assert.assertNotNull(utilizadores49);
        org.junit.Assert.assertTrue(b50 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        Utilizadores utilizadores16 = utilizadores0.clone();
        Utilizadores utilizadores17 = new Utilizadores();
        utilizadores17.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores17.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista30 = utilizadores17.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores31 = new Utilizadores();
        java.util.List<Cliente> list_cliente32 = utilizadores31.top10ClientesGastadores();
        Utilizadores utilizadores33 = new Utilizadores();
        Utilizadores utilizadores34 = new Utilizadores();
        java.util.List<Cliente> list_cliente35 = utilizadores34.top10ClientesGastadores();
        Utilizadores utilizadores36 = new Utilizadores();
        utilizadores36.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista43 = utilizadores36.top5MotoristasComMaiorDesvio();
        int i44 = utilizadores34.compareTo(utilizadores36);
        int i45 = utilizadores33.compareTo(utilizadores34);
        boolean b46 = utilizadores31.equals((java.lang.Object) utilizadores34);
        java.lang.String str47 = utilizadores31.toString();
        Utilizadores utilizadores48 = utilizadores31.clone();
        int i49 = utilizadores17.compareTo(utilizadores48);
        int i50 = utilizadores0.compareTo(utilizadores48);
        Utilizadores utilizadores51 = utilizadores0.clone();
        try {
            utilizadores51.adiciona("", "hi!", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!", "");
            org.junit.Assert.fail("Expected exception of type EmailAlreadyInUseException");
        } catch (EmailAlreadyInUseException e) {
        }
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(utilizadores16);
        org.junit.Assert.assertNotNull(list_motorista30);
        org.junit.Assert.assertNotNull(list_cliente32);
        org.junit.Assert.assertNotNull(list_cliente35);
        org.junit.Assert.assertNotNull(list_motorista43);
        org.junit.Assert.assertTrue(i44 == (-1));
        org.junit.Assert.assertTrue(i45 == 0);
        org.junit.Assert.assertTrue(b46 == true);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "------- UMeR --------\n" + "'", str47.equals("------- UMeR --------\n"));
        org.junit.Assert.assertNotNull(utilizadores48);
        org.junit.Assert.assertTrue(i49 == 1);
        org.junit.Assert.assertTrue(i50 == 1);
        org.junit.Assert.assertNotNull(utilizadores51);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        Utilizadores utilizadores0 = new Utilizadores();
        boolean b2 = utilizadores0.equals((java.lang.Object) (short) 1);
        java.util.Map<java.lang.String, Ator> map_str_ator3 = utilizadores0.getUtilizadores();
        Utilizadores utilizadores4 = new Utilizadores(map_str_ator3);
        org.junit.Assert.assertTrue(b2 == false);
        org.junit.Assert.assertNotNull(map_str_ator3);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        Utilizadores utilizadores16 = new Utilizadores();
        java.util.List<Cliente> list_cliente17 = utilizadores16.top10ClientesGastadores();
        Utilizadores utilizadores18 = new Utilizadores();
        Utilizadores utilizadores19 = new Utilizadores();
        java.util.List<Cliente> list_cliente20 = utilizadores19.top10ClientesGastadores();
        Utilizadores utilizadores21 = new Utilizadores();
        utilizadores21.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista28 = utilizadores21.top5MotoristasComMaiorDesvio();
        int i29 = utilizadores19.compareTo(utilizadores21);
        int i30 = utilizadores18.compareTo(utilizadores19);
        boolean b31 = utilizadores16.equals((java.lang.Object) utilizadores19);
        Utilizadores utilizadores32 = utilizadores16.clone();
        boolean b33 = utilizadores0.equals((java.lang.Object) utilizadores16);
        Utilizadores utilizadores34 = new Utilizadores();
        utilizadores34.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores34.adiciona("", "", "hi!", "", "");
        Ator ator48 = utilizadores34.getAtor("hi!");
        Utilizadores utilizadores49 = new Utilizadores(utilizadores34);
        Ator ator51 = utilizadores49.getAtor("");
        utilizadores0.adiciona(ator51);
        Utilizadores utilizadores53 = new Utilizadores(utilizadores0);
        java.lang.String str54 = utilizadores53.toString();
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_cliente4);
        org.junit.Assert.assertNotNull(list_motorista12);
        org.junit.Assert.assertTrue(i13 == (-1));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(b15 == true);
        org.junit.Assert.assertNotNull(list_cliente17);
        org.junit.Assert.assertNotNull(list_cliente20);
        org.junit.Assert.assertNotNull(list_motorista28);
        org.junit.Assert.assertTrue(i29 == (-1));
        org.junit.Assert.assertTrue(i30 == 0);
        org.junit.Assert.assertTrue(b31 == true);
        org.junit.Assert.assertNotNull(utilizadores32);
        org.junit.Assert.assertTrue(b33 == true);
        org.junit.Assert.assertNotNull(ator48);
        org.junit.Assert.assertNotNull(ator51);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str54.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        Utilizadores utilizadores0 = new Utilizadores();
        Utilizadores utilizadores1 = utilizadores0.clone();
        java.util.Map<java.lang.String, Ator> map_str_ator2 = utilizadores1.getUtilizadores();
        Utilizadores utilizadores3 = utilizadores1.clone();
        Utilizadores utilizadores4 = utilizadores1.clone();
        Utilizadores utilizadores5 = utilizadores1.clone();
        java.util.List<Motorista> list_motorista6 = utilizadores5.top5MotoristasComMaiorDesvio();
        try {
            Ator ator8 = utilizadores5.getAtor("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
            org.junit.Assert.fail("Expected exception of type EmailDoesNotExistException");
        } catch (EmailDoesNotExistException e) {
        }
        org.junit.Assert.assertNotNull(utilizadores1);
        org.junit.Assert.assertNotNull(map_str_ator2);
        org.junit.Assert.assertNotNull(utilizadores3);
        org.junit.Assert.assertNotNull(utilizadores4);
        org.junit.Assert.assertNotNull(utilizadores5);
        org.junit.Assert.assertNotNull(list_motorista6);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        Utilizadores utilizadores16 = utilizadores0.clone();
        Utilizadores utilizadores17 = new Utilizadores();
        utilizadores17.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores17.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista30 = utilizadores17.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores31 = new Utilizadores();
        java.util.List<Cliente> list_cliente32 = utilizadores31.top10ClientesGastadores();
        Utilizadores utilizadores33 = new Utilizadores();
        Utilizadores utilizadores34 = new Utilizadores();
        java.util.List<Cliente> list_cliente35 = utilizadores34.top10ClientesGastadores();
        Utilizadores utilizadores36 = new Utilizadores();
        utilizadores36.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista43 = utilizadores36.top5MotoristasComMaiorDesvio();
        int i44 = utilizadores34.compareTo(utilizadores36);
        int i45 = utilizadores33.compareTo(utilizadores34);
        boolean b46 = utilizadores31.equals((java.lang.Object) utilizadores34);
        java.lang.String str47 = utilizadores31.toString();
        Utilizadores utilizadores48 = utilizadores31.clone();
        int i49 = utilizadores17.compareTo(utilizadores48);
        int i50 = utilizadores0.compareTo(utilizadores48);
        utilizadores48.adiciona("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\n\nNome: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: \nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\n\nNome: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: \nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "", "");
        try {
            Ator ator58 = utilizadores48.getAtor("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
            org.junit.Assert.fail("Expected exception of type EmailDoesNotExistException");
        } catch (EmailDoesNotExistException e) {
        }
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(utilizadores16);
        org.junit.Assert.assertNotNull(list_motorista30);
        org.junit.Assert.assertNotNull(list_cliente32);
        org.junit.Assert.assertNotNull(list_cliente35);
        org.junit.Assert.assertNotNull(list_motorista43);
        org.junit.Assert.assertTrue(i44 == (-1));
        org.junit.Assert.assertTrue(i45 == 0);
        org.junit.Assert.assertTrue(b46 == true);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "------- UMeR --------\n" + "'", str47.equals("------- UMeR --------\n"));
        org.junit.Assert.assertNotNull(utilizadores48);
        org.junit.Assert.assertTrue(i49 == 1);
        org.junit.Assert.assertTrue(i50 == 1);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores14 = new Utilizadores(utilizadores0);
        Veiculo veiculo20 = null;
        utilizadores14.adiciona("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", veiculo20);
        utilizadores14.adiciona("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\n", "");
        Utilizadores utilizadores28 = new Utilizadores();
        Utilizadores utilizadores29 = utilizadores28.clone();
        Utilizadores utilizadores30 = new Utilizadores(utilizadores28);
        Utilizadores utilizadores31 = new Utilizadores();
        Utilizadores utilizadores32 = utilizadores31.clone();
        java.lang.String str33 = utilizadores32.toString();
        Utilizadores utilizadores34 = new Utilizadores();
        utilizadores34.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores34.adiciona("", "", "hi!", "", "");
        Ator ator48 = utilizadores34.getAtor("hi!");
        Utilizadores utilizadores49 = new Utilizadores(utilizadores34);
        java.util.List<Motorista> list_motorista50 = utilizadores49.top5MotoristasComMaiorDesvio();
        Ator ator52 = utilizadores49.getAtor("");
        utilizadores32.adiciona(ator52);
        utilizadores28.adiciona(ator52);
        try {
            utilizadores14.adiciona(ator52);
            org.junit.Assert.fail("Expected exception of type EmailAlreadyInUseException");
        } catch (EmailAlreadyInUseException e) {
        }
        org.junit.Assert.assertNotNull(list_motorista13);
        org.junit.Assert.assertNotNull(utilizadores29);
        org.junit.Assert.assertNotNull(utilizadores32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "------- UMeR --------\n" + "'", str33.equals("------- UMeR --------\n"));
        org.junit.Assert.assertNotNull(ator48);
        org.junit.Assert.assertNotNull(list_motorista50);
        org.junit.Assert.assertNotNull(ator52);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        Utilizadores utilizadores0 = new Utilizadores();
        Utilizadores utilizadores1 = utilizadores0.clone();
        Utilizadores utilizadores2 = new Utilizadores(utilizadores0);
        java.util.List<Motorista> list_motorista3 = utilizadores2.top5MotoristasComMaiorDesvio();
        org.junit.Assert.assertNotNull(utilizadores1);
        org.junit.Assert.assertNotNull(list_motorista3);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        java.util.List<Motorista> list_motorista16 = utilizadores15.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores17 = new Utilizadores(utilizadores15);
        java.util.Map<java.lang.String, Ator> map_str_ator18 = utilizadores17.getUtilizadores();
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(list_motorista16);
        org.junit.Assert.assertNotNull(map_str_ator18);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
        java.util.Map<java.lang.String, Ator> map_str_ator7 = utilizadores0.getUtilizadores();
        org.junit.Assert.assertNotNull(map_str_ator7);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista7 = utilizadores0.top5MotoristasComMaiorDesvio();
        utilizadores0.adiciona("", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
        org.junit.Assert.assertNotNull(list_motorista7);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        utilizadores0.adiciona("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
        Utilizadores utilizadores20 = new Utilizadores();
        utilizadores20.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores20.adiciona("", "", "hi!", "", "");
        Ator ator34 = utilizadores20.getAtor("hi!");
        Utilizadores utilizadores35 = new Utilizadores(utilizadores20);
        java.util.List<Motorista> list_motorista36 = utilizadores35.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores37 = new Utilizadores(utilizadores35);
        java.lang.String str38 = utilizadores37.toString();
        boolean b39 = utilizadores0.equals((java.lang.Object) utilizadores37);
        java.util.List<Cliente> list_cliente40 = utilizadores0.top10ClientesGastadores();
        org.junit.Assert.assertNotNull(list_motorista13);
        org.junit.Assert.assertNotNull(ator34);
        org.junit.Assert.assertNotNull(list_motorista36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str38.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertTrue(b39 == false);
        org.junit.Assert.assertNotNull(list_cliente40);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        Utilizadores utilizadores0 = new Utilizadores();
        Utilizadores utilizadores1 = new Utilizadores();
        java.util.List<Cliente> list_cliente2 = utilizadores1.top10ClientesGastadores();
        Utilizadores utilizadores3 = new Utilizadores();
        utilizadores3.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista10 = utilizadores3.top5MotoristasComMaiorDesvio();
        int i11 = utilizadores1.compareTo(utilizadores3);
        int i12 = utilizadores0.compareTo(utilizadores1);
        Utilizadores utilizadores13 = new Utilizadores();
        utilizadores13.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores13.adiciona("", "", "hi!", "", "");
        Ator ator27 = utilizadores13.getAtor("hi!");
        utilizadores1.adiciona(ator27);
        java.util.List<Cliente> list_cliente29 = utilizadores1.top10ClientesGastadores();
        org.junit.Assert.assertNotNull(list_cliente2);
        org.junit.Assert.assertNotNull(list_motorista10);
        org.junit.Assert.assertTrue(i11 == (-1));
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertNotNull(ator27);
        org.junit.Assert.assertNotNull(list_cliente29);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        Utilizadores utilizadores16 = new Utilizadores();
        java.util.List<Cliente> list_cliente17 = utilizadores16.top10ClientesGastadores();
        boolean b19 = utilizadores16.equals((java.lang.Object) 100L);
        Utilizadores utilizadores20 = new Utilizadores();
        utilizadores20.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores20.adiciona("", "", "hi!", "", "");
        Ator ator34 = utilizadores20.getAtor("hi!");
        utilizadores16.adiciona(ator34);
        utilizadores3.adiciona(ator34);
        Utilizadores utilizadores37 = new Utilizadores();
        java.util.List<Cliente> list_cliente38 = utilizadores37.top10ClientesGastadores();
        Utilizadores utilizadores39 = new Utilizadores();
        Utilizadores utilizadores40 = new Utilizadores();
        java.util.List<Cliente> list_cliente41 = utilizadores40.top10ClientesGastadores();
        Utilizadores utilizadores42 = new Utilizadores();
        utilizadores42.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista49 = utilizadores42.top5MotoristasComMaiorDesvio();
        int i50 = utilizadores40.compareTo(utilizadores42);
        int i51 = utilizadores39.compareTo(utilizadores40);
        boolean b52 = utilizadores37.equals((java.lang.Object) utilizadores40);
        Utilizadores utilizadores53 = new Utilizadores();
        utilizadores53.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores53.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista66 = utilizadores53.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator67 = utilizadores53.getUtilizadores();
        java.lang.String str68 = utilizadores53.toString();
        int i69 = utilizadores37.compareTo(utilizadores53);
        Utilizadores utilizadores70 = utilizadores53.clone();
        int i71 = utilizadores3.compareTo(utilizadores70);
        java.util.List<Cliente> list_cliente72 = utilizadores3.top10ClientesGastadores();
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_cliente4);
        org.junit.Assert.assertNotNull(list_motorista12);
        org.junit.Assert.assertTrue(i13 == (-1));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(b15 == true);
        org.junit.Assert.assertNotNull(list_cliente17);
        org.junit.Assert.assertTrue(b19 == false);
        org.junit.Assert.assertNotNull(ator34);
        org.junit.Assert.assertNotNull(list_cliente38);
        org.junit.Assert.assertNotNull(list_cliente41);
        org.junit.Assert.assertNotNull(list_motorista49);
        org.junit.Assert.assertTrue(i50 == (-1));
        org.junit.Assert.assertTrue(i51 == 0);
        org.junit.Assert.assertTrue(b52 == true);
        org.junit.Assert.assertNotNull(list_motorista66);
        org.junit.Assert.assertNotNull(map_str_ator67);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str68.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertTrue(i69 == (-1));
        org.junit.Assert.assertNotNull(utilizadores70);
        org.junit.Assert.assertTrue(i71 == 3);
        org.junit.Assert.assertNotNull(list_cliente72);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        Utilizadores utilizadores7 = utilizadores0.clone();
        Veiculo veiculo13 = null;
        utilizadores0.adiciona("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "", "------- UMeR --------\n", "", "------- UMeR --------\n", veiculo13);
        utilizadores0.adiciona("", "------- UMeR --------\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\n");
        java.lang.String str21 = utilizadores0.toString();
        org.junit.Assert.assertNotNull(utilizadores7);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "------- UMeR --------\nE-mail: \nNome: ------- UMeR --------\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nData de nascimento: ------- UMeR --------\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: \nPassword: ------- UMeR --------\n\nMorada: \nData de nascimento: ------- UMeR --------\n\nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\n" + "'", str21.equals("------- UMeR --------\nE-mail: \nNome: ------- UMeR --------\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nData de nascimento: ------- UMeR --------\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: \nPassword: ------- UMeR --------\n\nMorada: \nData de nascimento: ------- UMeR --------\n\nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\n"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        Utilizadores utilizadores0 = new Utilizadores();
        Utilizadores utilizadores1 = utilizadores0.clone();
        java.util.Map<java.lang.String, Ator> map_str_ator2 = utilizadores1.getUtilizadores();
        Utilizadores utilizadores3 = utilizadores1.clone();
        Utilizadores utilizadores4 = utilizadores1.clone();
        Utilizadores utilizadores5 = utilizadores4.clone();
        java.util.Map<java.lang.String, Ator> map_str_ator6 = utilizadores5.getUtilizadores();
        org.junit.Assert.assertNotNull(utilizadores1);
        org.junit.Assert.assertNotNull(map_str_ator2);
        org.junit.Assert.assertNotNull(utilizadores3);
        org.junit.Assert.assertNotNull(utilizadores4);
        org.junit.Assert.assertNotNull(utilizadores5);
        org.junit.Assert.assertNotNull(map_str_ator6);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        Veiculo veiculo21 = null;
        utilizadores0.adiciona("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "", veiculo21);
        java.util.Map<java.lang.String, Ator> map_str_ator23 = utilizadores0.getUtilizadores();
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(map_str_ator23);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("");
        Utilizadores utilizadores15 = new Utilizadores();
        utilizadores15.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores15.adiciona("", "", "hi!", "", "");
        Ator ator29 = utilizadores15.getAtor("hi!");
        Utilizadores utilizadores30 = new Utilizadores(utilizadores15);
        Utilizadores utilizadores31 = utilizadores15.clone();
        Utilizadores utilizadores32 = new Utilizadores();
        utilizadores32.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores32.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista45 = utilizadores32.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores46 = new Utilizadores();
        java.util.List<Cliente> list_cliente47 = utilizadores46.top10ClientesGastadores();
        Utilizadores utilizadores48 = new Utilizadores();
        Utilizadores utilizadores49 = new Utilizadores();
        java.util.List<Cliente> list_cliente50 = utilizadores49.top10ClientesGastadores();
        Utilizadores utilizadores51 = new Utilizadores();
        utilizadores51.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista58 = utilizadores51.top5MotoristasComMaiorDesvio();
        int i59 = utilizadores49.compareTo(utilizadores51);
        int i60 = utilizadores48.compareTo(utilizadores49);
        boolean b61 = utilizadores46.equals((java.lang.Object) utilizadores49);
        java.lang.String str62 = utilizadores46.toString();
        Utilizadores utilizadores63 = utilizadores46.clone();
        int i64 = utilizadores32.compareTo(utilizadores63);
        int i65 = utilizadores15.compareTo(utilizadores63);
        boolean b66 = utilizadores0.equals((java.lang.Object) utilizadores15);
        java.util.Map<java.lang.String, Ator> map_str_ator67 = utilizadores0.getUtilizadores();
        java.lang.Object obj68 = null;
        boolean b69 = utilizadores0.equals(obj68);
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(ator29);
        org.junit.Assert.assertNotNull(utilizadores31);
        org.junit.Assert.assertNotNull(list_motorista45);
        org.junit.Assert.assertNotNull(list_cliente47);
        org.junit.Assert.assertNotNull(list_cliente50);
        org.junit.Assert.assertNotNull(list_motorista58);
        org.junit.Assert.assertTrue(i59 == (-1));
        org.junit.Assert.assertTrue(i60 == 0);
        org.junit.Assert.assertTrue(b61 == true);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "------- UMeR --------\n" + "'", str62.equals("------- UMeR --------\n"));
        org.junit.Assert.assertNotNull(utilizadores63);
        org.junit.Assert.assertTrue(i64 == 1);
        org.junit.Assert.assertTrue(i65 == 1);
        org.junit.Assert.assertTrue(b66 == true);
        org.junit.Assert.assertNotNull(map_str_ator67);
        org.junit.Assert.assertTrue(b69 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        Utilizadores utilizadores0 = new Utilizadores();
        boolean b2 = utilizadores0.equals((java.lang.Object) (short) 1);
        Utilizadores utilizadores3 = new Utilizadores();
        utilizadores3.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores3.adiciona("", "", "hi!", "", "");
        Ator ator17 = utilizadores3.getAtor("hi!");
        int i18 = utilizadores0.compareTo(utilizadores3);
        Utilizadores utilizadores19 = new Utilizadores();
        java.util.List<Cliente> list_cliente20 = utilizadores19.top10ClientesGastadores();
        Utilizadores utilizadores21 = new Utilizadores();
        Utilizadores utilizadores22 = new Utilizadores();
        java.util.List<Cliente> list_cliente23 = utilizadores22.top10ClientesGastadores();
        Utilizadores utilizadores24 = new Utilizadores();
        utilizadores24.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista31 = utilizadores24.top5MotoristasComMaiorDesvio();
        int i32 = utilizadores22.compareTo(utilizadores24);
        int i33 = utilizadores21.compareTo(utilizadores22);
        boolean b34 = utilizadores19.equals((java.lang.Object) utilizadores22);
        java.lang.String str35 = utilizadores19.toString();
        int i36 = utilizadores0.compareTo(utilizadores19);
        Utilizadores utilizadores37 = new Utilizadores();
        Utilizadores utilizadores38 = utilizadores37.clone();
        Veiculo veiculo44 = null;
        utilizadores37.adiciona("", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!", "", veiculo44);
        Ator ator47 = utilizadores37.getAtor("");
        try {
            utilizadores0.adiciona(ator47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(b2 == false);
        org.junit.Assert.assertNotNull(ator17);
        org.junit.Assert.assertTrue(i18 == (-1));
        org.junit.Assert.assertNotNull(list_cliente20);
        org.junit.Assert.assertNotNull(list_cliente23);
        org.junit.Assert.assertNotNull(list_motorista31);
        org.junit.Assert.assertTrue(i32 == (-1));
        org.junit.Assert.assertTrue(i33 == 0);
        org.junit.Assert.assertTrue(b34 == true);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "------- UMeR --------\n" + "'", str35.equals("------- UMeR --------\n"));
        org.junit.Assert.assertTrue(i36 == 0);
        org.junit.Assert.assertNotNull(utilizadores38);
        org.junit.Assert.assertNotNull(ator47);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        java.util.List<Motorista> list_motorista16 = utilizadores15.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores17 = new Utilizadores(utilizadores15);
        java.util.Map<java.lang.String, Ator> map_str_ator18 = utilizadores15.getUtilizadores();
        Ator ator20 = utilizadores15.getAtor("");
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(list_motorista16);
        org.junit.Assert.assertNotNull(map_str_ator18);
        org.junit.Assert.assertNotNull(ator20);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        Utilizadores utilizadores16 = new Utilizadores();
        java.util.List<Cliente> list_cliente17 = utilizadores16.top10ClientesGastadores();
        Utilizadores utilizadores18 = new Utilizadores();
        Utilizadores utilizadores19 = new Utilizadores();
        java.util.List<Cliente> list_cliente20 = utilizadores19.top10ClientesGastadores();
        Utilizadores utilizadores21 = new Utilizadores();
        utilizadores21.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista28 = utilizadores21.top5MotoristasComMaiorDesvio();
        int i29 = utilizadores19.compareTo(utilizadores21);
        int i30 = utilizadores18.compareTo(utilizadores19);
        boolean b31 = utilizadores16.equals((java.lang.Object) utilizadores19);
        Utilizadores utilizadores32 = utilizadores16.clone();
        boolean b33 = utilizadores0.equals((java.lang.Object) utilizadores16);
        Utilizadores utilizadores34 = new Utilizadores();
        utilizadores34.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores34.adiciona("", "", "hi!", "", "");
        Ator ator48 = utilizadores34.getAtor("hi!");
        Utilizadores utilizadores49 = new Utilizadores(utilizadores34);
        Ator ator51 = utilizadores49.getAtor("");
        utilizadores0.adiciona(ator51);
        Utilizadores utilizadores53 = new Utilizadores();
        java.util.List<Cliente> list_cliente54 = utilizadores53.top10ClientesGastadores();
        Utilizadores utilizadores55 = new Utilizadores();
        utilizadores55.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista62 = utilizadores55.top5MotoristasComMaiorDesvio();
        int i63 = utilizadores53.compareTo(utilizadores55);
        Utilizadores utilizadores64 = new Utilizadores();
        java.util.List<Motorista> list_motorista65 = utilizadores64.top5MotoristasComMaiorDesvio();
        int i66 = utilizadores55.compareTo(utilizadores64);
        java.util.List<Motorista> list_motorista67 = utilizadores64.top5MotoristasComMaiorDesvio();
        utilizadores64.adiciona("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\n", "", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
        boolean b74 = utilizadores0.equals((java.lang.Object) "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
        java.util.Map<java.lang.String, Ator> map_str_ator75 = utilizadores0.getUtilizadores();
        Utilizadores utilizadores76 = new Utilizadores();
        java.util.List<Motorista> list_motorista77 = utilizadores76.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores78 = new Utilizadores();
        boolean b80 = utilizadores78.equals((java.lang.Object) (short) 1);
        boolean b81 = utilizadores76.equals((java.lang.Object) b80);
        java.util.Map<java.lang.String, Ator> map_str_ator82 = utilizadores76.getUtilizadores();
        Utilizadores utilizadores83 = new Utilizadores(map_str_ator82);
        java.util.Map<java.lang.String, Ator> map_str_ator84 = utilizadores83.getUtilizadores();
        Utilizadores utilizadores85 = new Utilizadores(map_str_ator84);
        Utilizadores utilizadores86 = new Utilizadores(map_str_ator84);
        Utilizadores utilizadores87 = new Utilizadores(map_str_ator84);
        Utilizadores utilizadores88 = new Utilizadores(map_str_ator84);
        boolean b89 = utilizadores0.equals((java.lang.Object) map_str_ator84);
        java.util.List<Motorista> list_motorista90 = utilizadores0.top5MotoristasComMaiorDesvio();
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_cliente4);
        org.junit.Assert.assertNotNull(list_motorista12);
        org.junit.Assert.assertTrue(i13 == (-1));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(b15 == true);
        org.junit.Assert.assertNotNull(list_cliente17);
        org.junit.Assert.assertNotNull(list_cliente20);
        org.junit.Assert.assertNotNull(list_motorista28);
        org.junit.Assert.assertTrue(i29 == (-1));
        org.junit.Assert.assertTrue(i30 == 0);
        org.junit.Assert.assertTrue(b31 == true);
        org.junit.Assert.assertNotNull(utilizadores32);
        org.junit.Assert.assertTrue(b33 == true);
        org.junit.Assert.assertNotNull(ator48);
        org.junit.Assert.assertNotNull(ator51);
        org.junit.Assert.assertNotNull(list_cliente54);
        org.junit.Assert.assertNotNull(list_motorista62);
        org.junit.Assert.assertTrue(i63 == (-1));
        org.junit.Assert.assertNotNull(list_motorista65);
        org.junit.Assert.assertTrue(i66 == 1);
        org.junit.Assert.assertNotNull(list_motorista67);
        org.junit.Assert.assertTrue(b74 == false);
        org.junit.Assert.assertNotNull(map_str_ator75);
        org.junit.Assert.assertNotNull(list_motorista77);
        org.junit.Assert.assertTrue(b80 == false);
        org.junit.Assert.assertTrue(b81 == false);
        org.junit.Assert.assertNotNull(map_str_ator82);
        org.junit.Assert.assertNotNull(map_str_ator84);
        org.junit.Assert.assertTrue(b89 == false);
        org.junit.Assert.assertNotNull(list_motorista90);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        java.util.List<Cliente> list_cliente15 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores16 = new Utilizadores(utilizadores0);
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(list_cliente15);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        Utilizadores utilizadores0 = new Utilizadores();
        Utilizadores utilizadores1 = new Utilizadores();
        java.util.List<Cliente> list_cliente2 = utilizadores1.top10ClientesGastadores();
        Utilizadores utilizadores3 = new Utilizadores();
        utilizadores3.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista10 = utilizadores3.top5MotoristasComMaiorDesvio();
        int i11 = utilizadores1.compareTo(utilizadores3);
        int i12 = utilizadores0.compareTo(utilizadores1);
        Utilizadores utilizadores13 = new Utilizadores();
        utilizadores13.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores13.adiciona("", "", "hi!", "", "");
        Ator ator27 = utilizadores13.getAtor("hi!");
        utilizadores1.adiciona(ator27);
        Utilizadores utilizadores29 = utilizadores1.clone();
        utilizadores1.adiciona("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\n", "hi!", "------- UMeR --------\nE-mail: \nNome: ------- UMeR --------\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nData de nascimento: ------- UMeR --------\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: \nPassword: ------- UMeR --------\n\nMorada: \nData de nascimento: ------- UMeR --------\n\nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\n");
        org.junit.Assert.assertNotNull(list_cliente2);
        org.junit.Assert.assertNotNull(list_motorista10);
        org.junit.Assert.assertTrue(i11 == (-1));
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertNotNull(ator27);
        org.junit.Assert.assertNotNull(utilizadores29);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        java.util.List<Motorista> list_motorista16 = utilizadores15.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores17 = utilizadores15.clone();
        utilizadores17.adiciona("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\n\nNome: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: \nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "", "");
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(list_motorista16);
        org.junit.Assert.assertNotNull(utilizadores17);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        Utilizadores utilizadores0 = new Utilizadores();
        boolean b2 = utilizadores0.equals((java.lang.Object) (short) 1);
        Utilizadores utilizadores3 = new Utilizadores();
        utilizadores3.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores3.adiciona("", "", "hi!", "", "");
        Ator ator17 = utilizadores3.getAtor("hi!");
        int i18 = utilizadores0.compareTo(utilizadores3);
        Utilizadores utilizadores19 = new Utilizadores();
        java.util.List<Motorista> list_motorista20 = utilizadores19.top5MotoristasComMaiorDesvio();
        int i21 = utilizadores3.compareTo(utilizadores19);
        Utilizadores utilizadores22 = new Utilizadores();
        java.util.List<Cliente> list_cliente23 = utilizadores22.top10ClientesGastadores();
        Utilizadores utilizadores24 = new Utilizadores();
        Utilizadores utilizadores25 = new Utilizadores();
        java.util.List<Cliente> list_cliente26 = utilizadores25.top10ClientesGastadores();
        Utilizadores utilizadores27 = new Utilizadores();
        utilizadores27.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista34 = utilizadores27.top5MotoristasComMaiorDesvio();
        int i35 = utilizadores25.compareTo(utilizadores27);
        int i36 = utilizadores24.compareTo(utilizadores25);
        boolean b37 = utilizadores22.equals((java.lang.Object) utilizadores25);
        Utilizadores utilizadores38 = utilizadores22.clone();
        java.util.List<Motorista> list_motorista39 = utilizadores22.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores40 = utilizadores22.clone();
        boolean b41 = utilizadores19.equals((java.lang.Object) utilizadores40);
        java.util.List<Cliente> list_cliente42 = utilizadores19.top10ClientesGastadores();
        org.junit.Assert.assertTrue(b2 == false);
        org.junit.Assert.assertNotNull(ator17);
        org.junit.Assert.assertTrue(i18 == (-1));
        org.junit.Assert.assertNotNull(list_motorista20);
        org.junit.Assert.assertTrue(i21 == 1);
        org.junit.Assert.assertNotNull(list_cliente23);
        org.junit.Assert.assertNotNull(list_cliente26);
        org.junit.Assert.assertNotNull(list_motorista34);
        org.junit.Assert.assertTrue(i35 == (-1));
        org.junit.Assert.assertTrue(i36 == 0);
        org.junit.Assert.assertTrue(b37 == true);
        org.junit.Assert.assertNotNull(utilizadores38);
        org.junit.Assert.assertNotNull(list_motorista39);
        org.junit.Assert.assertNotNull(utilizadores40);
        org.junit.Assert.assertTrue(b41 == true);
        org.junit.Assert.assertNotNull(list_cliente42);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        utilizadores2.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista9 = utilizadores2.top5MotoristasComMaiorDesvio();
        int i10 = utilizadores0.compareTo(utilizadores2);
        Utilizadores utilizadores11 = new Utilizadores();
        java.util.List<Motorista> list_motorista12 = utilizadores11.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores2.compareTo(utilizadores11);
        java.util.Map<java.lang.String, Ator> map_str_ator14 = utilizadores11.getUtilizadores();
        Utilizadores utilizadores15 = new Utilizadores();
        Utilizadores utilizadores16 = new Utilizadores();
        java.util.List<Cliente> list_cliente17 = utilizadores16.top10ClientesGastadores();
        Utilizadores utilizadores18 = new Utilizadores();
        utilizadores18.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista25 = utilizadores18.top5MotoristasComMaiorDesvio();
        int i26 = utilizadores16.compareTo(utilizadores18);
        int i27 = utilizadores15.compareTo(utilizadores16);
        java.util.Map<java.lang.String, Ator> map_str_ator28 = utilizadores16.getUtilizadores();
        Utilizadores utilizadores29 = new Utilizadores();
        utilizadores29.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores29.adiciona("", "", "hi!", "", "");
        Ator ator43 = utilizadores29.getAtor("hi!");
        utilizadores16.adiciona(ator43);
        Utilizadores utilizadores45 = new Utilizadores();
        utilizadores45.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores45.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista58 = utilizadores45.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator59 = utilizadores45.getUtilizadores();
        Utilizadores utilizadores60 = new Utilizadores(map_str_ator59);
        Utilizadores utilizadores61 = new Utilizadores();
        java.util.List<Cliente> list_cliente62 = utilizadores61.top10ClientesGastadores();
        java.lang.String str63 = utilizadores61.toString();
        Utilizadores utilizadores64 = new Utilizadores();
        java.util.List<Motorista> list_motorista65 = utilizadores64.top5MotoristasComMaiorDesvio();
        boolean b66 = utilizadores61.equals((java.lang.Object) list_motorista65);
        boolean b67 = utilizadores60.equals((java.lang.Object) list_motorista65);
        int i68 = utilizadores16.compareTo(utilizadores60);
        Utilizadores utilizadores69 = new Utilizadores(utilizadores60);
        java.util.List<Motorista> list_motorista70 = utilizadores60.top5MotoristasComMaiorDesvio();
        java.util.List<Cliente> list_cliente71 = utilizadores60.top10ClientesGastadores();
        int i72 = utilizadores11.compareTo(utilizadores60);
        java.lang.String str73 = utilizadores60.toString();
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_motorista9);
        org.junit.Assert.assertTrue(i10 == (-1));
        org.junit.Assert.assertNotNull(list_motorista12);
        org.junit.Assert.assertTrue(i13 == 1);
        org.junit.Assert.assertNotNull(map_str_ator14);
        org.junit.Assert.assertNotNull(list_cliente17);
        org.junit.Assert.assertNotNull(list_motorista25);
        org.junit.Assert.assertTrue(i26 == (-1));
        org.junit.Assert.assertTrue(i27 == 0);
        org.junit.Assert.assertNotNull(map_str_ator28);
        org.junit.Assert.assertNotNull(ator43);
        org.junit.Assert.assertNotNull(list_motorista58);
        org.junit.Assert.assertNotNull(map_str_ator59);
        org.junit.Assert.assertNotNull(list_cliente62);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "------- UMeR --------\n" + "'", str63.equals("------- UMeR --------\n"));
        org.junit.Assert.assertNotNull(list_motorista65);
        org.junit.Assert.assertTrue(b66 == false);
        org.junit.Assert.assertTrue(b67 == false);
        org.junit.Assert.assertTrue(i68 == 3);
        org.junit.Assert.assertNotNull(list_motorista70);
        org.junit.Assert.assertNotNull(list_cliente71);
        org.junit.Assert.assertTrue(i72 == (-1));
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str73.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores14 = new Utilizadores();
        java.util.List<Cliente> list_cliente15 = utilizadores14.top10ClientesGastadores();
        Utilizadores utilizadores16 = new Utilizadores();
        Utilizadores utilizadores17 = new Utilizadores();
        java.util.List<Cliente> list_cliente18 = utilizadores17.top10ClientesGastadores();
        Utilizadores utilizadores19 = new Utilizadores();
        utilizadores19.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista26 = utilizadores19.top5MotoristasComMaiorDesvio();
        int i27 = utilizadores17.compareTo(utilizadores19);
        int i28 = utilizadores16.compareTo(utilizadores17);
        boolean b29 = utilizadores14.equals((java.lang.Object) utilizadores17);
        java.lang.String str30 = utilizadores14.toString();
        Utilizadores utilizadores31 = utilizadores14.clone();
        int i32 = utilizadores0.compareTo(utilizadores31);
        java.util.Map<java.lang.String, Ator> map_str_ator33 = utilizadores31.getUtilizadores();
        java.lang.String str34 = utilizadores31.toString();
        Utilizadores utilizadores35 = new Utilizadores(utilizadores31);
        org.junit.Assert.assertNotNull(list_motorista13);
        org.junit.Assert.assertNotNull(list_cliente15);
        org.junit.Assert.assertNotNull(list_cliente18);
        org.junit.Assert.assertNotNull(list_motorista26);
        org.junit.Assert.assertTrue(i27 == (-1));
        org.junit.Assert.assertTrue(i28 == 0);
        org.junit.Assert.assertTrue(b29 == true);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "------- UMeR --------\n" + "'", str30.equals("------- UMeR --------\n"));
        org.junit.Assert.assertNotNull(utilizadores31);
        org.junit.Assert.assertTrue(i32 == 1);
        org.junit.Assert.assertNotNull(map_str_ator33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "------- UMeR --------\n" + "'", str34.equals("------- UMeR --------\n"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        java.lang.String str16 = utilizadores0.toString();
        java.util.Map<java.lang.String, Ator> map_str_ator17 = utilizadores0.getUtilizadores();
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_cliente4);
        org.junit.Assert.assertNotNull(list_motorista12);
        org.junit.Assert.assertTrue(i13 == (-1));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(b15 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "------- UMeR --------\n" + "'", str16.equals("------- UMeR --------\n"));
        org.junit.Assert.assertNotNull(map_str_ator17);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores14 = new Utilizadores();
        java.util.List<Cliente> list_cliente15 = utilizadores14.top10ClientesGastadores();
        Utilizadores utilizadores16 = new Utilizadores();
        Utilizadores utilizadores17 = new Utilizadores();
        java.util.List<Cliente> list_cliente18 = utilizadores17.top10ClientesGastadores();
        Utilizadores utilizadores19 = new Utilizadores();
        utilizadores19.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista26 = utilizadores19.top5MotoristasComMaiorDesvio();
        int i27 = utilizadores17.compareTo(utilizadores19);
        int i28 = utilizadores16.compareTo(utilizadores17);
        boolean b29 = utilizadores14.equals((java.lang.Object) utilizadores17);
        java.lang.String str30 = utilizadores14.toString();
        Utilizadores utilizadores31 = utilizadores14.clone();
        int i32 = utilizadores0.compareTo(utilizadores31);
        java.util.Map<java.lang.String, Ator> map_str_ator33 = utilizadores31.getUtilizadores();
        java.lang.String str34 = utilizadores31.toString();
        java.lang.String str35 = utilizadores31.toString();
        org.junit.Assert.assertNotNull(list_motorista13);
        org.junit.Assert.assertNotNull(list_cliente15);
        org.junit.Assert.assertNotNull(list_cliente18);
        org.junit.Assert.assertNotNull(list_motorista26);
        org.junit.Assert.assertTrue(i27 == (-1));
        org.junit.Assert.assertTrue(i28 == 0);
        org.junit.Assert.assertTrue(b29 == true);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "------- UMeR --------\n" + "'", str30.equals("------- UMeR --------\n"));
        org.junit.Assert.assertNotNull(utilizadores31);
        org.junit.Assert.assertTrue(i32 == 1);
        org.junit.Assert.assertNotNull(map_str_ator33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "------- UMeR --------\n" + "'", str34.equals("------- UMeR --------\n"));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "------- UMeR --------\n" + "'", str35.equals("------- UMeR --------\n"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        Utilizadores utilizadores0 = new Utilizadores();
        Utilizadores utilizadores1 = utilizadores0.clone();
        java.util.Map<java.lang.String, Ator> map_str_ator2 = utilizadores1.getUtilizadores();
        Utilizadores utilizadores3 = utilizadores1.clone();
        Utilizadores utilizadores4 = utilizadores1.clone();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores5.adiciona("", "", "hi!", "", "");
        Ator ator19 = utilizadores5.getAtor("hi!");
        Utilizadores utilizadores20 = new Utilizadores(utilizadores5);
        Utilizadores utilizadores21 = utilizadores5.clone();
        Ator ator23 = utilizadores21.getAtor("");
        utilizadores1.adiciona(ator23);
        java.util.Map<java.lang.String, Ator> map_str_ator25 = utilizadores1.getUtilizadores();
        org.junit.Assert.assertNotNull(utilizadores1);
        org.junit.Assert.assertNotNull(map_str_ator2);
        org.junit.Assert.assertNotNull(utilizadores3);
        org.junit.Assert.assertNotNull(utilizadores4);
        org.junit.Assert.assertNotNull(ator19);
        org.junit.Assert.assertNotNull(utilizadores21);
        org.junit.Assert.assertNotNull(ator23);
        org.junit.Assert.assertNotNull(map_str_ator25);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        java.util.List<Motorista> list_motorista16 = utilizadores15.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores17 = new Utilizadores(utilizadores15);
        java.lang.String str18 = utilizadores17.toString();
        Utilizadores utilizadores19 = new Utilizadores();
        java.util.List<Cliente> list_cliente20 = utilizadores19.top10ClientesGastadores();
        Utilizadores utilizadores21 = new Utilizadores();
        Utilizadores utilizadores22 = new Utilizadores();
        java.util.List<Cliente> list_cliente23 = utilizadores22.top10ClientesGastadores();
        Utilizadores utilizadores24 = new Utilizadores();
        utilizadores24.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista31 = utilizadores24.top5MotoristasComMaiorDesvio();
        int i32 = utilizadores22.compareTo(utilizadores24);
        int i33 = utilizadores21.compareTo(utilizadores22);
        boolean b34 = utilizadores19.equals((java.lang.Object) utilizadores22);
        Utilizadores utilizadores35 = new Utilizadores();
        utilizadores35.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores35.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista48 = utilizadores35.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator49 = utilizadores35.getUtilizadores();
        java.lang.String str50 = utilizadores35.toString();
        int i51 = utilizadores19.compareTo(utilizadores35);
        Utilizadores utilizadores52 = utilizadores35.clone();
        Utilizadores utilizadores53 = new Utilizadores(utilizadores52);
        int i54 = utilizadores17.compareTo(utilizadores53);
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(list_motorista16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str18.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertNotNull(list_cliente20);
        org.junit.Assert.assertNotNull(list_cliente23);
        org.junit.Assert.assertNotNull(list_motorista31);
        org.junit.Assert.assertTrue(i32 == (-1));
        org.junit.Assert.assertTrue(i33 == 0);
        org.junit.Assert.assertTrue(b34 == true);
        org.junit.Assert.assertNotNull(list_motorista48);
        org.junit.Assert.assertNotNull(map_str_ator49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str50.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertTrue(i51 == (-1));
        org.junit.Assert.assertNotNull(utilizadores52);
        org.junit.Assert.assertTrue(i54 == 0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        Utilizadores utilizadores16 = new Utilizadores(utilizadores0);
        utilizadores16.adiciona("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\n\nNome: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: \nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "", "hi!", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
        Veiculo veiculo28 = null;
        utilizadores16.adiciona("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "", "", veiculo28);
        org.junit.Assert.assertNotNull(ator14);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        Utilizadores utilizadores16 = new Utilizadores();
        utilizadores16.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores16.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista29 = utilizadores16.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator30 = utilizadores16.getUtilizadores();
        java.lang.String str31 = utilizadores16.toString();
        int i32 = utilizadores0.compareTo(utilizadores16);
        Utilizadores utilizadores33 = utilizadores16.clone();
        java.util.Map<java.lang.String, Ator> map_str_ator34 = utilizadores33.getUtilizadores();
        java.lang.String str35 = utilizadores33.toString();
        java.util.List<Cliente> list_cliente36 = utilizadores33.top10ClientesGastadores();
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_cliente4);
        org.junit.Assert.assertNotNull(list_motorista12);
        org.junit.Assert.assertTrue(i13 == (-1));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(b15 == true);
        org.junit.Assert.assertNotNull(list_motorista29);
        org.junit.Assert.assertNotNull(map_str_ator30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str31.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertTrue(i32 == (-1));
        org.junit.Assert.assertNotNull(utilizadores33);
        org.junit.Assert.assertNotNull(map_str_ator34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str35.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertNotNull(list_cliente36);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        Utilizadores utilizadores0 = new Utilizadores();
        Utilizadores utilizadores1 = new Utilizadores();
        java.util.List<Cliente> list_cliente2 = utilizadores1.top10ClientesGastadores();
        Utilizadores utilizadores3 = new Utilizadores();
        utilizadores3.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista10 = utilizadores3.top5MotoristasComMaiorDesvio();
        int i11 = utilizadores1.compareTo(utilizadores3);
        int i12 = utilizadores0.compareTo(utilizadores1);
        Utilizadores utilizadores13 = new Utilizadores();
        Utilizadores utilizadores14 = utilizadores13.clone();
        java.lang.String str15 = utilizadores14.toString();
        int i16 = utilizadores1.compareTo(utilizadores14);
        Utilizadores utilizadores17 = new Utilizadores();
        utilizadores17.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores17.adiciona("", "", "hi!", "", "");
        java.lang.String str30 = utilizadores17.toString();
        boolean b32 = utilizadores17.equals((java.lang.Object) (short) 10);
        boolean b33 = utilizadores1.equals((java.lang.Object) b32);
        java.lang.String str34 = utilizadores1.toString();
        java.lang.String str35 = utilizadores1.toString();
        org.junit.Assert.assertNotNull(list_cliente2);
        org.junit.Assert.assertNotNull(list_motorista10);
        org.junit.Assert.assertTrue(i11 == (-1));
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertNotNull(utilizadores14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "------- UMeR --------\n" + "'", str15.equals("------- UMeR --------\n"));
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str30.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertTrue(b32 == false);
        org.junit.Assert.assertTrue(b33 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "------- UMeR --------\n" + "'", str34.equals("------- UMeR --------\n"));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "------- UMeR --------\n" + "'", str35.equals("------- UMeR --------\n"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        boolean b16 = utilizadores0.equals((java.lang.Object) 1.0f);
        java.util.List<Cliente> list_cliente17 = utilizadores0.top10ClientesGastadores();
        java.lang.String str18 = utilizadores0.toString();
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertTrue(b16 == false);
        org.junit.Assert.assertNotNull(list_cliente17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str18.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        java.util.List<Motorista> list_motorista16 = utilizadores15.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores17 = new Utilizadores(utilizadores15);
        Utilizadores utilizadores18 = new Utilizadores();
        java.util.List<Cliente> list_cliente19 = utilizadores18.top10ClientesGastadores();
        Utilizadores utilizadores20 = new Utilizadores();
        Utilizadores utilizadores21 = new Utilizadores();
        java.util.List<Cliente> list_cliente22 = utilizadores21.top10ClientesGastadores();
        Utilizadores utilizadores23 = new Utilizadores();
        utilizadores23.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista30 = utilizadores23.top5MotoristasComMaiorDesvio();
        int i31 = utilizadores21.compareTo(utilizadores23);
        int i32 = utilizadores20.compareTo(utilizadores21);
        boolean b33 = utilizadores18.equals((java.lang.Object) utilizadores21);
        java.lang.String str34 = utilizadores18.toString();
        int i35 = utilizadores17.compareTo(utilizadores18);
        Utilizadores utilizadores36 = utilizadores17.clone();
        try {
            Ator ator38 = utilizadores36.getAtor("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
            org.junit.Assert.fail("Expected exception of type EmailDoesNotExistException");
        } catch (EmailDoesNotExistException e) {
        }
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(list_motorista16);
        org.junit.Assert.assertNotNull(list_cliente19);
        org.junit.Assert.assertNotNull(list_cliente22);
        org.junit.Assert.assertNotNull(list_motorista30);
        org.junit.Assert.assertTrue(i31 == (-1));
        org.junit.Assert.assertTrue(i32 == 0);
        org.junit.Assert.assertTrue(b33 == true);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "------- UMeR --------\n" + "'", str34.equals("------- UMeR --------\n"));
        org.junit.Assert.assertTrue(i35 == 1);
        org.junit.Assert.assertNotNull(utilizadores36);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores14 = new Utilizadores(utilizadores0);
        java.util.Map<java.lang.String, Ator> map_str_ator15 = utilizadores0.getUtilizadores();
        Utilizadores utilizadores16 = new Utilizadores(utilizadores0);
        org.junit.Assert.assertNotNull(list_motorista13);
        org.junit.Assert.assertNotNull(map_str_ator15);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        Utilizadores utilizadores0 = new Utilizadores();
        Utilizadores utilizadores1 = new Utilizadores();
        java.util.List<Cliente> list_cliente2 = utilizadores1.top10ClientesGastadores();
        Utilizadores utilizadores3 = new Utilizadores();
        utilizadores3.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista10 = utilizadores3.top5MotoristasComMaiorDesvio();
        int i11 = utilizadores1.compareTo(utilizadores3);
        int i12 = utilizadores0.compareTo(utilizadores1);
        java.util.Map<java.lang.String, Ator> map_str_ator13 = utilizadores1.getUtilizadores();
        java.util.Map<java.lang.String, Ator> map_str_ator14 = utilizadores1.getUtilizadores();
        java.util.List<Cliente> list_cliente15 = utilizadores1.top10ClientesGastadores();
        org.junit.Assert.assertNotNull(list_cliente2);
        org.junit.Assert.assertNotNull(list_motorista10);
        org.junit.Assert.assertTrue(i11 == (-1));
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertNotNull(map_str_ator13);
        org.junit.Assert.assertNotNull(map_str_ator14);
        org.junit.Assert.assertNotNull(list_cliente15);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Motorista> list_motorista1 = utilizadores0.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores2 = new Utilizadores();
        boolean b4 = utilizadores2.equals((java.lang.Object) (short) 1);
        boolean b5 = utilizadores0.equals((java.lang.Object) b4);
        java.util.Map<java.lang.String, Ator> map_str_ator6 = utilizadores0.getUtilizadores();
        Utilizadores utilizadores7 = new Utilizadores(map_str_ator6);
        java.util.Map<java.lang.String, Ator> map_str_ator8 = utilizadores7.getUtilizadores();
        Utilizadores utilizadores9 = new Utilizadores(map_str_ator8);
        Utilizadores utilizadores10 = new Utilizadores(map_str_ator8);
        Utilizadores utilizadores11 = new Utilizadores(map_str_ator8);
        Utilizadores utilizadores12 = new Utilizadores(map_str_ator8);
        try {
            Ator ator14 = utilizadores12.getAtor("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
            org.junit.Assert.fail("Expected exception of type EmailDoesNotExistException");
        } catch (EmailDoesNotExistException e) {
        }
        org.junit.Assert.assertNotNull(list_motorista1);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(b5 == false);
        org.junit.Assert.assertNotNull(map_str_ator6);
        org.junit.Assert.assertNotNull(map_str_ator8);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        Utilizadores utilizadores0 = new Utilizadores();
        Utilizadores utilizadores1 = new Utilizadores();
        java.util.List<Cliente> list_cliente2 = utilizadores1.top10ClientesGastadores();
        Utilizadores utilizadores3 = new Utilizadores();
        utilizadores3.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista10 = utilizadores3.top5MotoristasComMaiorDesvio();
        int i11 = utilizadores1.compareTo(utilizadores3);
        int i12 = utilizadores0.compareTo(utilizadores1);
        java.util.Map<java.lang.String, Ator> map_str_ator13 = utilizadores1.getUtilizadores();
        Utilizadores utilizadores14 = new Utilizadores();
        utilizadores14.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores14.adiciona("", "", "hi!", "", "");
        Ator ator28 = utilizadores14.getAtor("hi!");
        utilizadores1.adiciona(ator28);
        Utilizadores utilizadores30 = new Utilizadores();
        utilizadores30.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores30.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista43 = utilizadores30.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator44 = utilizadores30.getUtilizadores();
        Utilizadores utilizadores45 = new Utilizadores(map_str_ator44);
        Utilizadores utilizadores46 = new Utilizadores();
        java.util.List<Cliente> list_cliente47 = utilizadores46.top10ClientesGastadores();
        java.lang.String str48 = utilizadores46.toString();
        Utilizadores utilizadores49 = new Utilizadores();
        java.util.List<Motorista> list_motorista50 = utilizadores49.top5MotoristasComMaiorDesvio();
        boolean b51 = utilizadores46.equals((java.lang.Object) list_motorista50);
        boolean b52 = utilizadores45.equals((java.lang.Object) list_motorista50);
        int i53 = utilizadores1.compareTo(utilizadores45);
        utilizadores1.adiciona("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: ------- UMeR --------\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nData de nascimento: ------- UMeR --------\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: \nPassword: ------- UMeR --------\n\nMorada: \nData de nascimento: ------- UMeR --------\n\nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "");
        org.junit.Assert.assertNotNull(list_cliente2);
        org.junit.Assert.assertNotNull(list_motorista10);
        org.junit.Assert.assertTrue(i11 == (-1));
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertNotNull(map_str_ator13);
        org.junit.Assert.assertNotNull(ator28);
        org.junit.Assert.assertNotNull(list_motorista43);
        org.junit.Assert.assertNotNull(map_str_ator44);
        org.junit.Assert.assertNotNull(list_cliente47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "------- UMeR --------\n" + "'", str48.equals("------- UMeR --------\n"));
        org.junit.Assert.assertNotNull(list_motorista50);
        org.junit.Assert.assertTrue(b51 == false);
        org.junit.Assert.assertTrue(b52 == false);
        org.junit.Assert.assertTrue(i53 == 3);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        Utilizadores utilizadores16 = new Utilizadores();
        java.util.List<Cliente> list_cliente17 = utilizadores16.top10ClientesGastadores();
        boolean b19 = utilizadores16.equals((java.lang.Object) 100L);
        Utilizadores utilizadores20 = new Utilizadores();
        utilizadores20.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores20.adiciona("", "", "hi!", "", "");
        Ator ator34 = utilizadores20.getAtor("hi!");
        utilizadores16.adiciona(ator34);
        utilizadores3.adiciona(ator34);
        Utilizadores utilizadores37 = new Utilizadores();
        java.util.List<Cliente> list_cliente38 = utilizadores37.top10ClientesGastadores();
        Utilizadores utilizadores39 = new Utilizadores();
        Utilizadores utilizadores40 = new Utilizadores();
        java.util.List<Cliente> list_cliente41 = utilizadores40.top10ClientesGastadores();
        Utilizadores utilizadores42 = new Utilizadores();
        utilizadores42.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista49 = utilizadores42.top5MotoristasComMaiorDesvio();
        int i50 = utilizadores40.compareTo(utilizadores42);
        int i51 = utilizadores39.compareTo(utilizadores40);
        boolean b52 = utilizadores37.equals((java.lang.Object) utilizadores40);
        Utilizadores utilizadores53 = new Utilizadores();
        utilizadores53.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores53.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista66 = utilizadores53.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator67 = utilizadores53.getUtilizadores();
        java.lang.String str68 = utilizadores53.toString();
        int i69 = utilizadores37.compareTo(utilizadores53);
        Utilizadores utilizadores70 = utilizadores53.clone();
        int i71 = utilizadores3.compareTo(utilizadores70);
        Utilizadores utilizadores72 = new Utilizadores();
        utilizadores72.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores72.adiciona("", "", "hi!", "", "");
        Ator ator86 = utilizadores72.getAtor("hi!");
        Utilizadores utilizadores87 = new Utilizadores(utilizadores72);
        Ator ator89 = utilizadores87.getAtor("");
        try {
            utilizadores70.adiciona(ator89);
            org.junit.Assert.fail("Expected exception of type EmailAlreadyInUseException");
        } catch (EmailAlreadyInUseException e) {
        }
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_cliente4);
        org.junit.Assert.assertNotNull(list_motorista12);
        org.junit.Assert.assertTrue(i13 == (-1));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(b15 == true);
        org.junit.Assert.assertNotNull(list_cliente17);
        org.junit.Assert.assertTrue(b19 == false);
        org.junit.Assert.assertNotNull(ator34);
        org.junit.Assert.assertNotNull(list_cliente38);
        org.junit.Assert.assertNotNull(list_cliente41);
        org.junit.Assert.assertNotNull(list_motorista49);
        org.junit.Assert.assertTrue(i50 == (-1));
        org.junit.Assert.assertTrue(i51 == 0);
        org.junit.Assert.assertTrue(b52 == true);
        org.junit.Assert.assertNotNull(list_motorista66);
        org.junit.Assert.assertNotNull(map_str_ator67);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str68.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertTrue(i69 == (-1));
        org.junit.Assert.assertNotNull(utilizadores70);
        org.junit.Assert.assertTrue(i71 == 3);
        org.junit.Assert.assertNotNull(ator86);
        org.junit.Assert.assertNotNull(ator89);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        utilizadores0.adiciona("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
        java.lang.String str20 = utilizadores0.toString();
        Ator ator22 = utilizadores0.getAtor("");
        Utilizadores utilizadores23 = new Utilizadores();
        java.util.List<Cliente> list_cliente24 = utilizadores23.top10ClientesGastadores();
        boolean b26 = utilizadores23.equals((java.lang.Object) 100L);
        Utilizadores utilizadores27 = new Utilizadores();
        utilizadores27.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores27.adiciona("", "", "hi!", "", "");
        Ator ator41 = utilizadores27.getAtor("hi!");
        utilizadores23.adiciona(ator41);
        boolean b43 = utilizadores0.equals((java.lang.Object) utilizadores23);
        Utilizadores utilizadores44 = utilizadores0.clone();
        org.junit.Assert.assertNotNull(list_motorista13);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str20.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertNotNull(ator22);
        org.junit.Assert.assertNotNull(list_cliente24);
        org.junit.Assert.assertTrue(b26 == false);
        org.junit.Assert.assertNotNull(ator41);
        org.junit.Assert.assertTrue(b43 == false);
        org.junit.Assert.assertNotNull(utilizadores44);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores14 = new Utilizadores();
        utilizadores14.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores14.adiciona("", "", "hi!", "", "");
        Ator ator28 = utilizadores14.getAtor("hi!");
        Utilizadores utilizadores29 = new Utilizadores(utilizadores14);
        boolean b30 = utilizadores0.equals((java.lang.Object) utilizadores29);
        java.util.List<Cliente> list_cliente31 = utilizadores0.top10ClientesGastadores();
        java.util.List<Motorista> list_motorista32 = utilizadores0.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores33 = new Utilizadores();
        utilizadores33.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores33.adiciona("", "", "hi!", "", "");
        Ator ator47 = utilizadores33.getAtor("hi!");
        Utilizadores utilizadores48 = new Utilizadores(utilizadores33);
        java.util.List<Motorista> list_motorista49 = utilizadores48.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores50 = new Utilizadores(utilizadores48);
        java.lang.String str51 = utilizadores50.toString();
        java.util.Map<java.lang.String, Ator> map_str_ator52 = utilizadores50.getUtilizadores();
        int i53 = utilizadores0.compareTo(utilizadores50);
        org.junit.Assert.assertNotNull(list_motorista13);
        org.junit.Assert.assertNotNull(ator28);
        org.junit.Assert.assertTrue(b30 == true);
        org.junit.Assert.assertNotNull(list_cliente31);
        org.junit.Assert.assertNotNull(list_motorista32);
        org.junit.Assert.assertNotNull(ator47);
        org.junit.Assert.assertNotNull(list_motorista49);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str51.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertNotNull(map_str_ator52);
        org.junit.Assert.assertTrue(i53 == 0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        java.util.List<Motorista> list_motorista16 = utilizadores15.top5MotoristasComMaiorDesvio();
        boolean b18 = utilizadores15.equals((java.lang.Object) 1);
        java.util.List<Motorista> list_motorista19 = utilizadores15.top5MotoristasComMaiorDesvio();
        java.util.List<Motorista> list_motorista20 = utilizadores15.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores21 = utilizadores15.clone();
        Utilizadores utilizadores22 = new Utilizadores();
        utilizadores22.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores22.adiciona("", "", "hi!", "", "");
        Ator ator36 = utilizadores22.getAtor("");
        try {
            utilizadores15.adiciona(ator36);
            org.junit.Assert.fail("Expected exception of type EmailAlreadyInUseException");
        } catch (EmailAlreadyInUseException e) {
        }
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(list_motorista16);
        org.junit.Assert.assertTrue(b18 == false);
        org.junit.Assert.assertNotNull(list_motorista19);
        org.junit.Assert.assertNotNull(list_motorista20);
        org.junit.Assert.assertNotNull(utilizadores21);
        org.junit.Assert.assertNotNull(ator36);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        Utilizadores utilizadores7 = utilizadores0.clone();
        java.lang.String str8 = utilizadores7.toString();
        java.lang.String str9 = utilizadores7.toString();
        java.util.Map<java.lang.String, Ator> map_str_ator10 = utilizadores7.getUtilizadores();
        utilizadores7.adiciona("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\n\nNome: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: \nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\n", "------- UMeR --------\n", "------- UMeR --------\n");
        org.junit.Assert.assertNotNull(utilizadores7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str8.equals("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str9.equals("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertNotNull(map_str_ator10);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        Utilizadores utilizadores16 = new Utilizadores();
        utilizadores16.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores16.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista29 = utilizadores16.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator30 = utilizadores16.getUtilizadores();
        java.lang.String str31 = utilizadores16.toString();
        int i32 = utilizadores0.compareTo(utilizadores16);
        Utilizadores utilizadores33 = utilizadores16.clone();
        utilizadores16.adiciona("------- UMeR --------\n", "hi!", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!", "hi!");
        Utilizadores utilizadores40 = new Utilizadores();
        java.util.List<Cliente> list_cliente41 = utilizadores40.top10ClientesGastadores();
        boolean b43 = utilizadores40.equals((java.lang.Object) 100L);
        Utilizadores utilizadores44 = new Utilizadores();
        utilizadores44.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores44.adiciona("", "", "hi!", "", "");
        Ator ator58 = utilizadores44.getAtor("hi!");
        utilizadores40.adiciona(ator58);
        try {
            utilizadores16.adiciona(ator58);
            org.junit.Assert.fail("Expected exception of type EmailAlreadyInUseException");
        } catch (EmailAlreadyInUseException e) {
        }
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_cliente4);
        org.junit.Assert.assertNotNull(list_motorista12);
        org.junit.Assert.assertTrue(i13 == (-1));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(b15 == true);
        org.junit.Assert.assertNotNull(list_motorista29);
        org.junit.Assert.assertNotNull(map_str_ator30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str31.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertTrue(i32 == (-1));
        org.junit.Assert.assertNotNull(utilizadores33);
        org.junit.Assert.assertNotNull(list_cliente41);
        org.junit.Assert.assertTrue(b43 == false);
        org.junit.Assert.assertNotNull(ator58);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Motorista> list_motorista1 = utilizadores0.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores2 = new Utilizadores();
        boolean b4 = utilizadores2.equals((java.lang.Object) (short) 1);
        boolean b5 = utilizadores0.equals((java.lang.Object) b4);
        java.util.Map<java.lang.String, Ator> map_str_ator6 = utilizadores0.getUtilizadores();
        Utilizadores utilizadores7 = new Utilizadores(map_str_ator6);
        java.util.Map<java.lang.String, Ator> map_str_ator8 = utilizadores7.getUtilizadores();
        Utilizadores utilizadores9 = new Utilizadores(map_str_ator8);
        Utilizadores utilizadores10 = new Utilizadores(map_str_ator8);
        try {
            Ator ator12 = utilizadores10.getAtor("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\n\nNome: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: \nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
            org.junit.Assert.fail("Expected exception of type EmailDoesNotExistException");
        } catch (EmailDoesNotExistException e) {
        }
        org.junit.Assert.assertNotNull(list_motorista1);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(b5 == false);
        org.junit.Assert.assertNotNull(map_str_ator6);
        org.junit.Assert.assertNotNull(map_str_ator8);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        utilizadores0.adiciona("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
        java.lang.String str20 = utilizadores0.toString();
        Ator ator22 = utilizadores0.getAtor("");
        Utilizadores utilizadores23 = new Utilizadores();
        java.util.List<Cliente> list_cliente24 = utilizadores23.top10ClientesGastadores();
        boolean b26 = utilizadores23.equals((java.lang.Object) 100L);
        Utilizadores utilizadores27 = new Utilizadores();
        utilizadores27.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores27.adiciona("", "", "hi!", "", "");
        Ator ator41 = utilizadores27.getAtor("hi!");
        utilizadores23.adiciona(ator41);
        boolean b43 = utilizadores0.equals((java.lang.Object) utilizadores23);
        utilizadores23.adiciona("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\n\nNome: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: \nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
        org.junit.Assert.assertNotNull(list_motorista13);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str20.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertNotNull(ator22);
        org.junit.Assert.assertNotNull(list_cliente24);
        org.junit.Assert.assertTrue(b26 == false);
        org.junit.Assert.assertNotNull(ator41);
        org.junit.Assert.assertTrue(b43 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        boolean b3 = utilizadores0.equals((java.lang.Object) 100L);
        Utilizadores utilizadores4 = utilizadores0.clone();
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertNotNull(utilizadores4);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        java.util.List<Motorista> list_motorista16 = utilizadores0.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores17 = new Utilizadores();
        utilizadores17.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores17.adiciona("", "", "hi!", "", "");
        Ator ator31 = utilizadores17.getAtor("hi!");
        utilizadores0.adiciona(ator31);
        Utilizadores utilizadores33 = new Utilizadores();
        utilizadores33.adiciona("hi!", "hi!", "", "", "hi!");
        Utilizadores utilizadores40 = new Utilizadores();
        utilizadores40.adiciona("hi!", "hi!", "", "", "hi!");
        Utilizadores utilizadores47 = utilizadores40.clone();
        int i48 = utilizadores33.compareTo(utilizadores47);
        java.util.List<Cliente> list_cliente49 = utilizadores33.top10ClientesGastadores();
        boolean b50 = utilizadores0.equals((java.lang.Object) utilizadores33);
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_cliente4);
        org.junit.Assert.assertNotNull(list_motorista12);
        org.junit.Assert.assertTrue(i13 == (-1));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(b15 == true);
        org.junit.Assert.assertNotNull(list_motorista16);
        org.junit.Assert.assertNotNull(ator31);
        org.junit.Assert.assertNotNull(utilizadores47);
        org.junit.Assert.assertTrue(i48 == 0);
        org.junit.Assert.assertNotNull(list_cliente49);
        org.junit.Assert.assertTrue(b50 == true);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores14 = new Utilizadores(utilizadores0);
        Veiculo veiculo20 = null;
        utilizadores14.adiciona("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", veiculo20);
        java.lang.String str22 = utilizadores14.toString();
        org.junit.Assert.assertNotNull(list_motorista13);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str22.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        Utilizadores utilizadores16 = utilizadores0.clone();
        Ator ator18 = utilizadores16.getAtor("");
        Utilizadores utilizadores19 = new Utilizadores();
        java.util.List<Cliente> list_cliente20 = utilizadores19.top10ClientesGastadores();
        Utilizadores utilizadores21 = new Utilizadores();
        Utilizadores utilizadores22 = new Utilizadores();
        java.util.List<Cliente> list_cliente23 = utilizadores22.top10ClientesGastadores();
        Utilizadores utilizadores24 = new Utilizadores();
        utilizadores24.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista31 = utilizadores24.top5MotoristasComMaiorDesvio();
        int i32 = utilizadores22.compareTo(utilizadores24);
        int i33 = utilizadores21.compareTo(utilizadores22);
        boolean b34 = utilizadores19.equals((java.lang.Object) utilizadores22);
        java.util.List<Motorista> list_motorista35 = utilizadores19.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores36 = new Utilizadores();
        utilizadores36.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores36.adiciona("", "", "hi!", "", "");
        Ator ator50 = utilizadores36.getAtor("hi!");
        Utilizadores utilizadores51 = new Utilizadores(utilizadores36);
        Utilizadores utilizadores52 = utilizadores36.clone();
        Utilizadores utilizadores53 = new Utilizadores();
        utilizadores53.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores53.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista66 = utilizadores53.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores67 = new Utilizadores();
        java.util.List<Cliente> list_cliente68 = utilizadores67.top10ClientesGastadores();
        Utilizadores utilizadores69 = new Utilizadores();
        Utilizadores utilizadores70 = new Utilizadores();
        java.util.List<Cliente> list_cliente71 = utilizadores70.top10ClientesGastadores();
        Utilizadores utilizadores72 = new Utilizadores();
        utilizadores72.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista79 = utilizadores72.top5MotoristasComMaiorDesvio();
        int i80 = utilizadores70.compareTo(utilizadores72);
        int i81 = utilizadores69.compareTo(utilizadores70);
        boolean b82 = utilizadores67.equals((java.lang.Object) utilizadores70);
        java.lang.String str83 = utilizadores67.toString();
        Utilizadores utilizadores84 = utilizadores67.clone();
        int i85 = utilizadores53.compareTo(utilizadores84);
        int i86 = utilizadores36.compareTo(utilizadores84);
        int i87 = utilizadores19.compareTo(utilizadores84);
        int i88 = utilizadores16.compareTo(utilizadores19);
        java.util.List<Cliente> list_cliente89 = utilizadores19.top10ClientesGastadores();
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(utilizadores16);
        org.junit.Assert.assertNotNull(ator18);
        org.junit.Assert.assertNotNull(list_cliente20);
        org.junit.Assert.assertNotNull(list_cliente23);
        org.junit.Assert.assertNotNull(list_motorista31);
        org.junit.Assert.assertTrue(i32 == (-1));
        org.junit.Assert.assertTrue(i33 == 0);
        org.junit.Assert.assertTrue(b34 == true);
        org.junit.Assert.assertNotNull(list_motorista35);
        org.junit.Assert.assertNotNull(ator50);
        org.junit.Assert.assertNotNull(utilizadores52);
        org.junit.Assert.assertNotNull(list_motorista66);
        org.junit.Assert.assertNotNull(list_cliente68);
        org.junit.Assert.assertNotNull(list_cliente71);
        org.junit.Assert.assertNotNull(list_motorista79);
        org.junit.Assert.assertTrue(i80 == (-1));
        org.junit.Assert.assertTrue(i81 == 0);
        org.junit.Assert.assertTrue(b82 == true);
        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "------- UMeR --------\n" + "'", str83.equals("------- UMeR --------\n"));
        org.junit.Assert.assertNotNull(utilizadores84);
        org.junit.Assert.assertTrue(i85 == 1);
        org.junit.Assert.assertTrue(i86 == 1);
        org.junit.Assert.assertTrue(i87 == 0);
        org.junit.Assert.assertTrue(i88 == 1);
        org.junit.Assert.assertNotNull(list_cliente89);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator14 = utilizadores0.getUtilizadores();
        Utilizadores utilizadores15 = new Utilizadores(map_str_ator14);
        Utilizadores utilizadores16 = new Utilizadores();
        utilizadores16.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores16.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista29 = utilizadores16.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator30 = utilizadores16.getUtilizadores();
        Utilizadores utilizadores31 = new Utilizadores(map_str_ator30);
        int i32 = utilizadores15.compareTo(utilizadores31);
        boolean b34 = utilizadores31.equals((java.lang.Object) "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
        Utilizadores utilizadores35 = utilizadores31.clone();
        org.junit.Assert.assertNotNull(list_motorista13);
        org.junit.Assert.assertNotNull(map_str_ator14);
        org.junit.Assert.assertNotNull(list_motorista29);
        org.junit.Assert.assertNotNull(map_str_ator30);
        org.junit.Assert.assertTrue(i32 == 0);
        org.junit.Assert.assertTrue(b34 == false);
        org.junit.Assert.assertNotNull(utilizadores35);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        Utilizadores utilizadores16 = new Utilizadores();
        java.util.List<Cliente> list_cliente17 = utilizadores16.top10ClientesGastadores();
        Utilizadores utilizadores18 = new Utilizadores();
        Utilizadores utilizadores19 = new Utilizadores();
        java.util.List<Cliente> list_cliente20 = utilizadores19.top10ClientesGastadores();
        Utilizadores utilizadores21 = new Utilizadores();
        utilizadores21.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista28 = utilizadores21.top5MotoristasComMaiorDesvio();
        int i29 = utilizadores19.compareTo(utilizadores21);
        int i30 = utilizadores18.compareTo(utilizadores19);
        boolean b31 = utilizadores16.equals((java.lang.Object) utilizadores19);
        Utilizadores utilizadores32 = utilizadores16.clone();
        boolean b33 = utilizadores0.equals((java.lang.Object) utilizadores16);
        Utilizadores utilizadores34 = new Utilizadores();
        utilizadores34.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores34.adiciona("", "", "hi!", "", "");
        Ator ator48 = utilizadores34.getAtor("hi!");
        Utilizadores utilizadores49 = new Utilizadores(utilizadores34);
        Ator ator51 = utilizadores49.getAtor("");
        utilizadores0.adiciona(ator51);
        utilizadores0.adiciona("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!", "------- UMeR --------\n");
        utilizadores0.adiciona("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\n\nNome: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: \nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\n\nNome: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: \nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\n", "");
        Utilizadores utilizadores65 = utilizadores0.clone();
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_cliente4);
        org.junit.Assert.assertNotNull(list_motorista12);
        org.junit.Assert.assertTrue(i13 == (-1));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(b15 == true);
        org.junit.Assert.assertNotNull(list_cliente17);
        org.junit.Assert.assertNotNull(list_cliente20);
        org.junit.Assert.assertNotNull(list_motorista28);
        org.junit.Assert.assertTrue(i29 == (-1));
        org.junit.Assert.assertTrue(i30 == 0);
        org.junit.Assert.assertTrue(b31 == true);
        org.junit.Assert.assertNotNull(utilizadores32);
        org.junit.Assert.assertTrue(b33 == true);
        org.junit.Assert.assertNotNull(ator48);
        org.junit.Assert.assertNotNull(ator51);
        org.junit.Assert.assertNotNull(utilizadores65);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        Utilizadores utilizadores16 = new Utilizadores();
        utilizadores16.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores16.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista29 = utilizadores16.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator30 = utilizadores16.getUtilizadores();
        java.lang.String str31 = utilizadores16.toString();
        int i32 = utilizadores0.compareTo(utilizadores16);
        Utilizadores utilizadores33 = utilizadores16.clone();
        Utilizadores utilizadores34 = new Utilizadores(utilizadores33);
        utilizadores33.adiciona("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\n\nNome: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: \nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
        Utilizadores utilizadores41 = new Utilizadores();
        java.util.List<Cliente> list_cliente42 = utilizadores41.top10ClientesGastadores();
        Utilizadores utilizadores43 = new Utilizadores();
        utilizadores43.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista50 = utilizadores43.top5MotoristasComMaiorDesvio();
        int i51 = utilizadores41.compareTo(utilizadores43);
        Utilizadores utilizadores52 = new Utilizadores();
        java.util.List<Motorista> list_motorista53 = utilizadores52.top5MotoristasComMaiorDesvio();
        int i54 = utilizadores43.compareTo(utilizadores52);
        Utilizadores utilizadores55 = new Utilizadores();
        utilizadores55.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores55.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista68 = utilizadores55.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores69 = utilizadores55.clone();
        Utilizadores utilizadores70 = utilizadores69.clone();
        boolean b71 = utilizadores52.equals((java.lang.Object) utilizadores70);
        int i72 = utilizadores33.compareTo(utilizadores52);
        Utilizadores utilizadores73 = new Utilizadores();
        utilizadores73.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores73.adiciona("", "", "hi!", "", "");
        Ator ator87 = utilizadores73.getAtor("");
        try {
            utilizadores33.adiciona(ator87);
            org.junit.Assert.fail("Expected exception of type EmailAlreadyInUseException");
        } catch (EmailAlreadyInUseException e) {
        }
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_cliente4);
        org.junit.Assert.assertNotNull(list_motorista12);
        org.junit.Assert.assertTrue(i13 == (-1));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(b15 == true);
        org.junit.Assert.assertNotNull(list_motorista29);
        org.junit.Assert.assertNotNull(map_str_ator30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str31.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertTrue(i32 == (-1));
        org.junit.Assert.assertNotNull(utilizadores33);
        org.junit.Assert.assertNotNull(list_cliente42);
        org.junit.Assert.assertNotNull(list_motorista50);
        org.junit.Assert.assertTrue(i51 == (-1));
        org.junit.Assert.assertNotNull(list_motorista53);
        org.junit.Assert.assertTrue(i54 == 1);
        org.junit.Assert.assertNotNull(list_motorista68);
        org.junit.Assert.assertNotNull(utilizadores69);
        org.junit.Assert.assertNotNull(utilizadores70);
        org.junit.Assert.assertTrue(b71 == false);
        org.junit.Assert.assertTrue(i72 == 1);
        org.junit.Assert.assertNotNull(ator87);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        Utilizadores utilizadores7 = utilizadores0.clone();
        java.lang.String str8 = utilizadores7.toString();
        java.lang.String str9 = utilizadores7.toString();
        try {
            Ator ator11 = utilizadores7.getAtor("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\n\nNome: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: \nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
            org.junit.Assert.fail("Expected exception of type EmailDoesNotExistException");
        } catch (EmailDoesNotExistException e) {
        }
        org.junit.Assert.assertNotNull(utilizadores7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str8.equals("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str9.equals("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        java.util.List<Motorista> list_motorista16 = utilizadores15.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores17 = new Utilizadores(utilizadores15);
        Utilizadores utilizadores18 = new Utilizadores(utilizadores17);
        Veiculo veiculo24 = null;
        try {
            utilizadores18.adiciona("", "", "------- UMeR --------\n", "------- UMeR --------\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\n\nNome: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: \nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", veiculo24);
            org.junit.Assert.fail("Expected exception of type EmailAlreadyInUseException");
        } catch (EmailAlreadyInUseException e) {
        }
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(list_motorista16);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        java.util.List<Motorista> list_motorista16 = utilizadores15.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores17 = new Utilizadores(utilizadores15);
        Utilizadores utilizadores18 = new Utilizadores(utilizadores17);
        Utilizadores utilizadores19 = new Utilizadores();
        java.util.List<Cliente> list_cliente20 = utilizadores19.top10ClientesGastadores();
        Utilizadores utilizadores21 = new Utilizadores();
        Utilizadores utilizadores22 = new Utilizadores();
        java.util.List<Cliente> list_cliente23 = utilizadores22.top10ClientesGastadores();
        Utilizadores utilizadores24 = new Utilizadores();
        utilizadores24.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista31 = utilizadores24.top5MotoristasComMaiorDesvio();
        int i32 = utilizadores22.compareTo(utilizadores24);
        int i33 = utilizadores21.compareTo(utilizadores22);
        boolean b34 = utilizadores19.equals((java.lang.Object) utilizadores22);
        Utilizadores utilizadores35 = new Utilizadores();
        java.util.List<Cliente> list_cliente36 = utilizadores35.top10ClientesGastadores();
        Utilizadores utilizadores37 = new Utilizadores();
        Utilizadores utilizadores38 = new Utilizadores();
        java.util.List<Cliente> list_cliente39 = utilizadores38.top10ClientesGastadores();
        Utilizadores utilizadores40 = new Utilizadores();
        utilizadores40.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista47 = utilizadores40.top5MotoristasComMaiorDesvio();
        int i48 = utilizadores38.compareTo(utilizadores40);
        int i49 = utilizadores37.compareTo(utilizadores38);
        boolean b50 = utilizadores35.equals((java.lang.Object) utilizadores38);
        Utilizadores utilizadores51 = utilizadores35.clone();
        boolean b52 = utilizadores19.equals((java.lang.Object) utilizadores35);
        Utilizadores utilizadores53 = new Utilizadores();
        utilizadores53.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores53.adiciona("", "", "hi!", "", "");
        Ator ator67 = utilizadores53.getAtor("hi!");
        Utilizadores utilizadores68 = new Utilizadores(utilizadores53);
        Ator ator70 = utilizadores68.getAtor("");
        utilizadores19.adiciona(ator70);
        try {
            utilizadores18.adiciona(ator70);
            org.junit.Assert.fail("Expected exception of type EmailAlreadyInUseException");
        } catch (EmailAlreadyInUseException e) {
        }
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(list_motorista16);
        org.junit.Assert.assertNotNull(list_cliente20);
        org.junit.Assert.assertNotNull(list_cliente23);
        org.junit.Assert.assertNotNull(list_motorista31);
        org.junit.Assert.assertTrue(i32 == (-1));
        org.junit.Assert.assertTrue(i33 == 0);
        org.junit.Assert.assertTrue(b34 == true);
        org.junit.Assert.assertNotNull(list_cliente36);
        org.junit.Assert.assertNotNull(list_cliente39);
        org.junit.Assert.assertNotNull(list_motorista47);
        org.junit.Assert.assertTrue(i48 == (-1));
        org.junit.Assert.assertTrue(i49 == 0);
        org.junit.Assert.assertTrue(b50 == true);
        org.junit.Assert.assertNotNull(utilizadores51);
        org.junit.Assert.assertTrue(b52 == true);
        org.junit.Assert.assertNotNull(ator67);
        org.junit.Assert.assertNotNull(ator70);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        Utilizadores utilizadores16 = new Utilizadores();
        java.util.List<Cliente> list_cliente17 = utilizadores16.top10ClientesGastadores();
        Utilizadores utilizadores18 = new Utilizadores();
        Utilizadores utilizadores19 = new Utilizadores();
        java.util.List<Cliente> list_cliente20 = utilizadores19.top10ClientesGastadores();
        Utilizadores utilizadores21 = new Utilizadores();
        utilizadores21.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista28 = utilizadores21.top5MotoristasComMaiorDesvio();
        int i29 = utilizadores19.compareTo(utilizadores21);
        int i30 = utilizadores18.compareTo(utilizadores19);
        boolean b31 = utilizadores16.equals((java.lang.Object) utilizadores19);
        Utilizadores utilizadores32 = utilizadores16.clone();
        boolean b33 = utilizadores0.equals((java.lang.Object) utilizadores16);
        Utilizadores utilizadores34 = new Utilizadores();
        utilizadores34.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores34.adiciona("", "", "hi!", "", "");
        Ator ator48 = utilizadores34.getAtor("hi!");
        Utilizadores utilizadores49 = new Utilizadores(utilizadores34);
        Ator ator51 = utilizadores49.getAtor("");
        utilizadores0.adiciona(ator51);
        Utilizadores utilizadores53 = utilizadores0.clone();
        Utilizadores utilizadores54 = new Utilizadores();
        utilizadores54.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores54.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista67 = utilizadores54.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator68 = utilizadores54.getUtilizadores();
        Utilizadores utilizadores69 = new Utilizadores(map_str_ator68);
        Utilizadores utilizadores70 = new Utilizadores();
        utilizadores70.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores70.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista83 = utilizadores70.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator84 = utilizadores70.getUtilizadores();
        Utilizadores utilizadores85 = new Utilizadores(map_str_ator84);
        int i86 = utilizadores69.compareTo(utilizadores85);
        boolean b87 = utilizadores53.equals((java.lang.Object) utilizadores85);
        Veiculo veiculo93 = null;
        utilizadores85.adiciona("------- UMeR --------\nE-mail: \nNome: ------- UMeR --------\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nData de nascimento: ------- UMeR --------\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: \nPassword: ------- UMeR --------\n\nMorada: \nData de nascimento: ------- UMeR --------\n\nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", veiculo93);
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_cliente4);
        org.junit.Assert.assertNotNull(list_motorista12);
        org.junit.Assert.assertTrue(i13 == (-1));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(b15 == true);
        org.junit.Assert.assertNotNull(list_cliente17);
        org.junit.Assert.assertNotNull(list_cliente20);
        org.junit.Assert.assertNotNull(list_motorista28);
        org.junit.Assert.assertTrue(i29 == (-1));
        org.junit.Assert.assertTrue(i30 == 0);
        org.junit.Assert.assertTrue(b31 == true);
        org.junit.Assert.assertNotNull(utilizadores32);
        org.junit.Assert.assertTrue(b33 == true);
        org.junit.Assert.assertNotNull(ator48);
        org.junit.Assert.assertNotNull(ator51);
        org.junit.Assert.assertNotNull(utilizadores53);
        org.junit.Assert.assertNotNull(list_motorista67);
        org.junit.Assert.assertNotNull(map_str_ator68);
        org.junit.Assert.assertNotNull(list_motorista83);
        org.junit.Assert.assertNotNull(map_str_ator84);
        org.junit.Assert.assertTrue(i86 == 0);
        org.junit.Assert.assertTrue(b87 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("");
        Utilizadores utilizadores15 = new Utilizadores();
        utilizadores15.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores15.adiciona("", "", "hi!", "", "");
        Ator ator29 = utilizadores15.getAtor("hi!");
        Utilizadores utilizadores30 = new Utilizadores(utilizadores15);
        Utilizadores utilizadores31 = utilizadores15.clone();
        Utilizadores utilizadores32 = new Utilizadores();
        utilizadores32.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores32.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista45 = utilizadores32.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores46 = new Utilizadores();
        java.util.List<Cliente> list_cliente47 = utilizadores46.top10ClientesGastadores();
        Utilizadores utilizadores48 = new Utilizadores();
        Utilizadores utilizadores49 = new Utilizadores();
        java.util.List<Cliente> list_cliente50 = utilizadores49.top10ClientesGastadores();
        Utilizadores utilizadores51 = new Utilizadores();
        utilizadores51.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista58 = utilizadores51.top5MotoristasComMaiorDesvio();
        int i59 = utilizadores49.compareTo(utilizadores51);
        int i60 = utilizadores48.compareTo(utilizadores49);
        boolean b61 = utilizadores46.equals((java.lang.Object) utilizadores49);
        java.lang.String str62 = utilizadores46.toString();
        Utilizadores utilizadores63 = utilizadores46.clone();
        int i64 = utilizadores32.compareTo(utilizadores63);
        int i65 = utilizadores15.compareTo(utilizadores63);
        boolean b66 = utilizadores0.equals((java.lang.Object) utilizadores15);
        java.util.Map<java.lang.String, Ator> map_str_ator67 = utilizadores0.getUtilizadores();
        java.lang.String str68 = utilizadores0.toString();
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(ator29);
        org.junit.Assert.assertNotNull(utilizadores31);
        org.junit.Assert.assertNotNull(list_motorista45);
        org.junit.Assert.assertNotNull(list_cliente47);
        org.junit.Assert.assertNotNull(list_cliente50);
        org.junit.Assert.assertNotNull(list_motorista58);
        org.junit.Assert.assertTrue(i59 == (-1));
        org.junit.Assert.assertTrue(i60 == 0);
        org.junit.Assert.assertTrue(b61 == true);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "------- UMeR --------\n" + "'", str62.equals("------- UMeR --------\n"));
        org.junit.Assert.assertNotNull(utilizadores63);
        org.junit.Assert.assertTrue(i64 == 1);
        org.junit.Assert.assertTrue(i65 == 1);
        org.junit.Assert.assertTrue(b66 == true);
        org.junit.Assert.assertNotNull(map_str_ator67);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str68.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        utilizadores2.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista9 = utilizadores2.top5MotoristasComMaiorDesvio();
        int i10 = utilizadores0.compareTo(utilizadores2);
        Utilizadores utilizadores11 = new Utilizadores();
        java.util.List<Motorista> list_motorista12 = utilizadores11.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores2.compareTo(utilizadores11);
        Utilizadores utilizadores14 = new Utilizadores();
        utilizadores14.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores14.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista27 = utilizadores14.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores28 = utilizadores14.clone();
        Utilizadores utilizadores29 = utilizadores28.clone();
        boolean b30 = utilizadores11.equals((java.lang.Object) utilizadores29);
        Utilizadores utilizadores31 = new Utilizadores();
        boolean b33 = utilizadores31.equals((java.lang.Object) (short) 1);
        java.util.Map<java.lang.String, Ator> map_str_ator34 = utilizadores31.getUtilizadores();
        boolean b35 = utilizadores11.equals((java.lang.Object) utilizadores31);
        Utilizadores utilizadores36 = new Utilizadores();
        utilizadores36.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores36.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista49 = utilizadores36.top5MotoristasComMaiorDesvio();
        utilizadores36.adiciona("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
        java.lang.String str56 = utilizadores36.toString();
        java.lang.String str57 = utilizadores36.toString();
        java.util.Map<java.lang.String, Ator> map_str_ator58 = utilizadores36.getUtilizadores();
        int i59 = utilizadores31.compareTo(utilizadores36);
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_motorista9);
        org.junit.Assert.assertTrue(i10 == (-1));
        org.junit.Assert.assertNotNull(list_motorista12);
        org.junit.Assert.assertTrue(i13 == 1);
        org.junit.Assert.assertNotNull(list_motorista27);
        org.junit.Assert.assertNotNull(utilizadores28);
        org.junit.Assert.assertNotNull(utilizadores29);
        org.junit.Assert.assertTrue(b30 == false);
        org.junit.Assert.assertTrue(b33 == false);
        org.junit.Assert.assertNotNull(map_str_ator34);
        org.junit.Assert.assertTrue(b35 == true);
        org.junit.Assert.assertNotNull(list_motorista49);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str56.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str57.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertNotNull(map_str_ator58);
        org.junit.Assert.assertTrue(i59 == (-1));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores(utilizadores0);
        Utilizadores utilizadores3 = new Utilizadores(utilizadores0);
        org.junit.Assert.assertNotNull(list_cliente1);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        Utilizadores utilizadores16 = utilizadores0.clone();
        Ator ator18 = utilizadores16.getAtor("");
        Utilizadores utilizadores19 = new Utilizadores();
        java.util.List<Cliente> list_cliente20 = utilizadores19.top10ClientesGastadores();
        Utilizadores utilizadores21 = new Utilizadores();
        Utilizadores utilizadores22 = new Utilizadores();
        java.util.List<Cliente> list_cliente23 = utilizadores22.top10ClientesGastadores();
        Utilizadores utilizadores24 = new Utilizadores();
        utilizadores24.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista31 = utilizadores24.top5MotoristasComMaiorDesvio();
        int i32 = utilizadores22.compareTo(utilizadores24);
        int i33 = utilizadores21.compareTo(utilizadores22);
        boolean b34 = utilizadores19.equals((java.lang.Object) utilizadores22);
        java.util.List<Motorista> list_motorista35 = utilizadores19.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores36 = new Utilizadores();
        utilizadores36.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores36.adiciona("", "", "hi!", "", "");
        Ator ator50 = utilizadores36.getAtor("hi!");
        Utilizadores utilizadores51 = new Utilizadores(utilizadores36);
        Utilizadores utilizadores52 = utilizadores36.clone();
        Utilizadores utilizadores53 = new Utilizadores();
        utilizadores53.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores53.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista66 = utilizadores53.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores67 = new Utilizadores();
        java.util.List<Cliente> list_cliente68 = utilizadores67.top10ClientesGastadores();
        Utilizadores utilizadores69 = new Utilizadores();
        Utilizadores utilizadores70 = new Utilizadores();
        java.util.List<Cliente> list_cliente71 = utilizadores70.top10ClientesGastadores();
        Utilizadores utilizadores72 = new Utilizadores();
        utilizadores72.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista79 = utilizadores72.top5MotoristasComMaiorDesvio();
        int i80 = utilizadores70.compareTo(utilizadores72);
        int i81 = utilizadores69.compareTo(utilizadores70);
        boolean b82 = utilizadores67.equals((java.lang.Object) utilizadores70);
        java.lang.String str83 = utilizadores67.toString();
        Utilizadores utilizadores84 = utilizadores67.clone();
        int i85 = utilizadores53.compareTo(utilizadores84);
        int i86 = utilizadores36.compareTo(utilizadores84);
        int i87 = utilizadores19.compareTo(utilizadores84);
        int i88 = utilizadores16.compareTo(utilizadores19);
        Utilizadores utilizadores89 = new Utilizadores(utilizadores16);
        java.util.Map<java.lang.String, Ator> map_str_ator90 = utilizadores16.getUtilizadores();
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(utilizadores16);
        org.junit.Assert.assertNotNull(ator18);
        org.junit.Assert.assertNotNull(list_cliente20);
        org.junit.Assert.assertNotNull(list_cliente23);
        org.junit.Assert.assertNotNull(list_motorista31);
        org.junit.Assert.assertTrue(i32 == (-1));
        org.junit.Assert.assertTrue(i33 == 0);
        org.junit.Assert.assertTrue(b34 == true);
        org.junit.Assert.assertNotNull(list_motorista35);
        org.junit.Assert.assertNotNull(ator50);
        org.junit.Assert.assertNotNull(utilizadores52);
        org.junit.Assert.assertNotNull(list_motorista66);
        org.junit.Assert.assertNotNull(list_cliente68);
        org.junit.Assert.assertNotNull(list_cliente71);
        org.junit.Assert.assertNotNull(list_motorista79);
        org.junit.Assert.assertTrue(i80 == (-1));
        org.junit.Assert.assertTrue(i81 == 0);
        org.junit.Assert.assertTrue(b82 == true);
        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "------- UMeR --------\n" + "'", str83.equals("------- UMeR --------\n"));
        org.junit.Assert.assertNotNull(utilizadores84);
        org.junit.Assert.assertTrue(i85 == 1);
        org.junit.Assert.assertTrue(i86 == 1);
        org.junit.Assert.assertTrue(i87 == 0);
        org.junit.Assert.assertTrue(i88 == 1);
        org.junit.Assert.assertNotNull(map_str_ator90);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        java.util.List<Motorista> list_motorista16 = utilizadores15.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores17 = new Utilizadores(utilizadores15);
        Utilizadores utilizadores18 = new Utilizadores();
        java.util.List<Cliente> list_cliente19 = utilizadores18.top10ClientesGastadores();
        Utilizadores utilizadores20 = new Utilizadores();
        Utilizadores utilizadores21 = new Utilizadores();
        java.util.List<Cliente> list_cliente22 = utilizadores21.top10ClientesGastadores();
        Utilizadores utilizadores23 = new Utilizadores();
        utilizadores23.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista30 = utilizadores23.top5MotoristasComMaiorDesvio();
        int i31 = utilizadores21.compareTo(utilizadores23);
        int i32 = utilizadores20.compareTo(utilizadores21);
        boolean b33 = utilizadores18.equals((java.lang.Object) utilizadores21);
        java.lang.String str34 = utilizadores18.toString();
        int i35 = utilizadores17.compareTo(utilizadores18);
        Utilizadores utilizadores36 = new Utilizadores();
        utilizadores36.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores36.adiciona("", "", "hi!", "", "");
        Ator ator50 = utilizadores36.getAtor("hi!");
        utilizadores18.adiciona(ator50);
        Utilizadores utilizadores52 = utilizadores18.clone();
        java.util.Map<java.lang.String, Ator> map_str_ator53 = utilizadores52.getUtilizadores();
        Utilizadores utilizadores54 = new Utilizadores();
        utilizadores54.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores54.adiciona("", "", "hi!", "", "");
        Ator ator68 = utilizadores54.getAtor("hi!");
        Utilizadores utilizadores69 = new Utilizadores(utilizadores54);
        java.util.List<Motorista> list_motorista70 = utilizadores69.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores71 = new Utilizadores(utilizadores69);
        java.lang.String str72 = utilizadores71.toString();
        java.util.Map<java.lang.String, Ator> map_str_ator73 = utilizadores71.getUtilizadores();
        boolean b74 = utilizadores52.equals((java.lang.Object) utilizadores71);
        java.lang.String str75 = utilizadores71.toString();
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(list_motorista16);
        org.junit.Assert.assertNotNull(list_cliente19);
        org.junit.Assert.assertNotNull(list_cliente22);
        org.junit.Assert.assertNotNull(list_motorista30);
        org.junit.Assert.assertTrue(i31 == (-1));
        org.junit.Assert.assertTrue(i32 == 0);
        org.junit.Assert.assertTrue(b33 == true);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "------- UMeR --------\n" + "'", str34.equals("------- UMeR --------\n"));
        org.junit.Assert.assertTrue(i35 == 1);
        org.junit.Assert.assertNotNull(ator50);
        org.junit.Assert.assertNotNull(utilizadores52);
        org.junit.Assert.assertNotNull(map_str_ator53);
        org.junit.Assert.assertNotNull(ator68);
        org.junit.Assert.assertNotNull(list_motorista70);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str72.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertNotNull(map_str_ator73);
        org.junit.Assert.assertTrue(b74 == false);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str75.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        Utilizadores utilizadores0 = new Utilizadores();
        Utilizadores utilizadores1 = utilizadores0.clone();
        Veiculo veiculo7 = null;
        utilizadores0.adiciona("", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!", "", veiculo7);
        utilizadores0.adiciona("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\n\nNome: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: \nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "", "------- UMeR --------\n", "------- UMeR --------\n", "");
        java.util.Map<java.lang.String, Ator> map_str_ator15 = utilizadores0.getUtilizadores();
        org.junit.Assert.assertNotNull(utilizadores1);
        org.junit.Assert.assertNotNull(map_str_ator15);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores14 = new Utilizadores();
        java.util.List<Cliente> list_cliente15 = utilizadores14.top10ClientesGastadores();
        Utilizadores utilizadores16 = new Utilizadores();
        Utilizadores utilizadores17 = new Utilizadores();
        java.util.List<Cliente> list_cliente18 = utilizadores17.top10ClientesGastadores();
        Utilizadores utilizadores19 = new Utilizadores();
        utilizadores19.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista26 = utilizadores19.top5MotoristasComMaiorDesvio();
        int i27 = utilizadores17.compareTo(utilizadores19);
        int i28 = utilizadores16.compareTo(utilizadores17);
        boolean b29 = utilizadores14.equals((java.lang.Object) utilizadores17);
        java.lang.String str30 = utilizadores14.toString();
        Utilizadores utilizadores31 = utilizadores14.clone();
        int i32 = utilizadores0.compareTo(utilizadores31);
        utilizadores31.adiciona("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\n\nNome: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: \nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "", "------- UMeR --------\nE-mail: \nNome: ------- UMeR --------\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nData de nascimento: ------- UMeR --------\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: \nPassword: ------- UMeR --------\n\nMorada: \nData de nascimento: ------- UMeR --------\n\nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "");
        org.junit.Assert.assertNotNull(list_motorista13);
        org.junit.Assert.assertNotNull(list_cliente15);
        org.junit.Assert.assertNotNull(list_cliente18);
        org.junit.Assert.assertNotNull(list_motorista26);
        org.junit.Assert.assertTrue(i27 == (-1));
        org.junit.Assert.assertTrue(i28 == 0);
        org.junit.Assert.assertTrue(b29 == true);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "------- UMeR --------\n" + "'", str30.equals("------- UMeR --------\n"));
        org.junit.Assert.assertNotNull(utilizadores31);
        org.junit.Assert.assertTrue(i32 == 1);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        Utilizadores utilizadores16 = utilizadores0.clone();
        Utilizadores utilizadores17 = new Utilizadores();
        utilizadores17.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores17.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista30 = utilizadores17.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores31 = new Utilizadores();
        java.util.List<Cliente> list_cliente32 = utilizadores31.top10ClientesGastadores();
        Utilizadores utilizadores33 = new Utilizadores();
        Utilizadores utilizadores34 = new Utilizadores();
        java.util.List<Cliente> list_cliente35 = utilizadores34.top10ClientesGastadores();
        Utilizadores utilizadores36 = new Utilizadores();
        utilizadores36.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista43 = utilizadores36.top5MotoristasComMaiorDesvio();
        int i44 = utilizadores34.compareTo(utilizadores36);
        int i45 = utilizadores33.compareTo(utilizadores34);
        boolean b46 = utilizadores31.equals((java.lang.Object) utilizadores34);
        java.lang.String str47 = utilizadores31.toString();
        Utilizadores utilizadores48 = utilizadores31.clone();
        int i49 = utilizadores17.compareTo(utilizadores48);
        int i50 = utilizadores0.compareTo(utilizadores48);
        java.util.Map<java.lang.String, Ator> map_str_ator51 = utilizadores48.getUtilizadores();
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(utilizadores16);
        org.junit.Assert.assertNotNull(list_motorista30);
        org.junit.Assert.assertNotNull(list_cliente32);
        org.junit.Assert.assertNotNull(list_cliente35);
        org.junit.Assert.assertNotNull(list_motorista43);
        org.junit.Assert.assertTrue(i44 == (-1));
        org.junit.Assert.assertTrue(i45 == 0);
        org.junit.Assert.assertTrue(b46 == true);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "------- UMeR --------\n" + "'", str47.equals("------- UMeR --------\n"));
        org.junit.Assert.assertNotNull(utilizadores48);
        org.junit.Assert.assertTrue(i49 == 1);
        org.junit.Assert.assertTrue(i50 == 1);
        org.junit.Assert.assertNotNull(map_str_ator51);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        Utilizadores utilizadores16 = new Utilizadores();
        utilizadores16.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores16.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista29 = utilizadores16.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator30 = utilizadores16.getUtilizadores();
        java.lang.String str31 = utilizadores16.toString();
        int i32 = utilizadores0.compareTo(utilizadores16);
        java.util.Map<java.lang.String, Ator> map_str_ator33 = utilizadores0.getUtilizadores();
        Utilizadores utilizadores34 = new Utilizadores(map_str_ator33);
        Utilizadores utilizadores35 = new Utilizadores(map_str_ator33);
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_cliente4);
        org.junit.Assert.assertNotNull(list_motorista12);
        org.junit.Assert.assertTrue(i13 == (-1));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(b15 == true);
        org.junit.Assert.assertNotNull(list_motorista29);
        org.junit.Assert.assertNotNull(map_str_ator30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str31.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertTrue(i32 == (-1));
        org.junit.Assert.assertNotNull(map_str_ator33);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        java.util.List<Motorista> list_motorista16 = utilizadores15.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores17 = new Utilizadores(utilizadores15);
        Veiculo veiculo23 = null;
        utilizadores17.adiciona("------- UMeR --------\n", "------- UMeR --------\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "", veiculo23);
        Utilizadores utilizadores25 = new Utilizadores();
        utilizadores25.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores25.adiciona("", "", "hi!", "", "");
        Ator ator39 = utilizadores25.getAtor("hi!");
        Utilizadores utilizadores40 = new Utilizadores(utilizadores25);
        java.util.List<Motorista> list_motorista41 = utilizadores40.top5MotoristasComMaiorDesvio();
        boolean b43 = utilizadores40.equals((java.lang.Object) 1);
        java.util.List<Motorista> list_motorista44 = utilizadores40.top5MotoristasComMaiorDesvio();
        java.util.List<Motorista> list_motorista45 = utilizadores40.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores46 = utilizadores40.clone();
        Utilizadores utilizadores47 = new Utilizadores(utilizadores46);
        Utilizadores utilizadores48 = new Utilizadores();
        java.util.List<Cliente> list_cliente49 = utilizadores48.top10ClientesGastadores();
        Utilizadores utilizadores50 = new Utilizadores();
        Utilizadores utilizadores51 = new Utilizadores();
        java.util.List<Cliente> list_cliente52 = utilizadores51.top10ClientesGastadores();
        Utilizadores utilizadores53 = new Utilizadores();
        utilizadores53.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista60 = utilizadores53.top5MotoristasComMaiorDesvio();
        int i61 = utilizadores51.compareTo(utilizadores53);
        int i62 = utilizadores50.compareTo(utilizadores51);
        boolean b63 = utilizadores48.equals((java.lang.Object) utilizadores51);
        java.lang.String str64 = utilizadores48.toString();
        Utilizadores utilizadores65 = utilizadores48.clone();
        int i66 = utilizadores47.compareTo(utilizadores65);
        int i67 = utilizadores17.compareTo(utilizadores65);
        try {
            Utilizadores utilizadores68 = utilizadores17.clone();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(list_motorista16);
        org.junit.Assert.assertNotNull(ator39);
        org.junit.Assert.assertNotNull(list_motorista41);
        org.junit.Assert.assertTrue(b43 == false);
        org.junit.Assert.assertNotNull(list_motorista44);
        org.junit.Assert.assertNotNull(list_motorista45);
        org.junit.Assert.assertNotNull(utilizadores46);
        org.junit.Assert.assertNotNull(list_cliente49);
        org.junit.Assert.assertNotNull(list_cliente52);
        org.junit.Assert.assertNotNull(list_motorista60);
        org.junit.Assert.assertTrue(i61 == (-1));
        org.junit.Assert.assertTrue(i62 == 0);
        org.junit.Assert.assertTrue(b63 == true);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "------- UMeR --------\n" + "'", str64.equals("------- UMeR --------\n"));
        org.junit.Assert.assertNotNull(utilizadores65);
        org.junit.Assert.assertTrue(i66 == 1);
        org.junit.Assert.assertTrue(i67 == 1);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        Utilizadores utilizadores16 = new Utilizadores();
        utilizadores16.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores16.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista29 = utilizadores16.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator30 = utilizadores16.getUtilizadores();
        java.lang.String str31 = utilizadores16.toString();
        int i32 = utilizadores0.compareTo(utilizadores16);
        Utilizadores utilizadores33 = utilizadores16.clone();
        Utilizadores utilizadores34 = new Utilizadores(utilizadores33);
        java.util.List<Cliente> list_cliente35 = utilizadores33.top10ClientesGastadores();
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_cliente4);
        org.junit.Assert.assertNotNull(list_motorista12);
        org.junit.Assert.assertTrue(i13 == (-1));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(b15 == true);
        org.junit.Assert.assertNotNull(list_motorista29);
        org.junit.Assert.assertNotNull(map_str_ator30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str31.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertTrue(i32 == (-1));
        org.junit.Assert.assertNotNull(utilizadores33);
        org.junit.Assert.assertNotNull(list_cliente35);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        utilizadores2.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista9 = utilizadores2.top5MotoristasComMaiorDesvio();
        int i10 = utilizadores0.compareTo(utilizadores2);
        Utilizadores utilizadores11 = new Utilizadores();
        java.util.List<Motorista> list_motorista12 = utilizadores11.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores2.compareTo(utilizadores11);
        Utilizadores utilizadores14 = new Utilizadores();
        utilizadores14.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores14.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista27 = utilizadores14.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores28 = utilizadores14.clone();
        Utilizadores utilizadores29 = utilizadores28.clone();
        boolean b30 = utilizadores11.equals((java.lang.Object) utilizadores29);
        Utilizadores utilizadores31 = new Utilizadores(utilizadores11);
        java.util.List<Cliente> list_cliente32 = utilizadores11.top10ClientesGastadores();
        java.lang.String str33 = utilizadores11.toString();
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_motorista9);
        org.junit.Assert.assertTrue(i10 == (-1));
        org.junit.Assert.assertNotNull(list_motorista12);
        org.junit.Assert.assertTrue(i13 == 1);
        org.junit.Assert.assertNotNull(list_motorista27);
        org.junit.Assert.assertNotNull(utilizadores28);
        org.junit.Assert.assertNotNull(utilizadores29);
        org.junit.Assert.assertTrue(b30 == false);
        org.junit.Assert.assertNotNull(list_cliente32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "------- UMeR --------\n" + "'", str33.equals("------- UMeR --------\n"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        java.util.List<Cliente> list_cliente16 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores17 = new Utilizadores();
        utilizadores17.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores17.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista30 = utilizadores17.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores31 = new Utilizadores(utilizadores17);
        java.util.Map<java.lang.String, Ator> map_str_ator32 = utilizadores31.getUtilizadores();
        java.util.List<Motorista> list_motorista33 = utilizadores31.top5MotoristasComMaiorDesvio();
        boolean b34 = utilizadores0.equals((java.lang.Object) list_motorista33);
        java.util.List<Cliente> list_cliente35 = utilizadores0.top10ClientesGastadores();
        try {
            Ator ator37 = utilizadores0.getAtor("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
            org.junit.Assert.fail("Expected exception of type EmailDoesNotExistException");
        } catch (EmailDoesNotExistException e) {
        }
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(list_cliente16);
        org.junit.Assert.assertNotNull(list_motorista30);
        org.junit.Assert.assertNotNull(map_str_ator32);
        org.junit.Assert.assertNotNull(list_motorista33);
        org.junit.Assert.assertTrue(b34 == false);
        org.junit.Assert.assertNotNull(list_cliente35);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        Utilizadores utilizadores16 = new Utilizadores();
        java.util.List<Cliente> list_cliente17 = utilizadores16.top10ClientesGastadores();
        Utilizadores utilizadores18 = new Utilizadores();
        Utilizadores utilizadores19 = new Utilizadores();
        java.util.List<Cliente> list_cliente20 = utilizadores19.top10ClientesGastadores();
        Utilizadores utilizadores21 = new Utilizadores();
        utilizadores21.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista28 = utilizadores21.top5MotoristasComMaiorDesvio();
        int i29 = utilizadores19.compareTo(utilizadores21);
        int i30 = utilizadores18.compareTo(utilizadores19);
        boolean b31 = utilizadores16.equals((java.lang.Object) utilizadores19);
        Utilizadores utilizadores32 = utilizadores16.clone();
        boolean b33 = utilizadores0.equals((java.lang.Object) utilizadores16);
        Utilizadores utilizadores34 = new Utilizadores();
        utilizadores34.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores34.adiciona("", "", "hi!", "", "");
        Ator ator48 = utilizadores34.getAtor("hi!");
        Utilizadores utilizadores49 = new Utilizadores(utilizadores34);
        Ator ator51 = utilizadores49.getAtor("");
        utilizadores0.adiciona(ator51);
        Utilizadores utilizadores53 = utilizadores0.clone();
        Utilizadores utilizadores54 = new Utilizadores(utilizadores0);
        Utilizadores utilizadores55 = utilizadores54.clone();
        utilizadores55.adiciona("hi!", "------- UMeR --------\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\n\nNome: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: \nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_cliente4);
        org.junit.Assert.assertNotNull(list_motorista12);
        org.junit.Assert.assertTrue(i13 == (-1));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(b15 == true);
        org.junit.Assert.assertNotNull(list_cliente17);
        org.junit.Assert.assertNotNull(list_cliente20);
        org.junit.Assert.assertNotNull(list_motorista28);
        org.junit.Assert.assertTrue(i29 == (-1));
        org.junit.Assert.assertTrue(i30 == 0);
        org.junit.Assert.assertTrue(b31 == true);
        org.junit.Assert.assertNotNull(utilizadores32);
        org.junit.Assert.assertTrue(b33 == true);
        org.junit.Assert.assertNotNull(ator48);
        org.junit.Assert.assertNotNull(ator51);
        org.junit.Assert.assertNotNull(utilizadores53);
        org.junit.Assert.assertNotNull(utilizadores55);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        Utilizadores utilizadores16 = utilizadores0.clone();
        Utilizadores utilizadores17 = new Utilizadores();
        utilizadores17.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores17.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista30 = utilizadores17.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores31 = new Utilizadores();
        java.util.List<Cliente> list_cliente32 = utilizadores31.top10ClientesGastadores();
        Utilizadores utilizadores33 = new Utilizadores();
        Utilizadores utilizadores34 = new Utilizadores();
        java.util.List<Cliente> list_cliente35 = utilizadores34.top10ClientesGastadores();
        Utilizadores utilizadores36 = new Utilizadores();
        utilizadores36.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista43 = utilizadores36.top5MotoristasComMaiorDesvio();
        int i44 = utilizadores34.compareTo(utilizadores36);
        int i45 = utilizadores33.compareTo(utilizadores34);
        boolean b46 = utilizadores31.equals((java.lang.Object) utilizadores34);
        java.lang.String str47 = utilizadores31.toString();
        Utilizadores utilizadores48 = utilizadores31.clone();
        int i49 = utilizadores17.compareTo(utilizadores48);
        int i50 = utilizadores0.compareTo(utilizadores48);
        Utilizadores utilizadores51 = utilizadores0.clone();
        java.util.List<Motorista> list_motorista52 = utilizadores51.top5MotoristasComMaiorDesvio();
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(utilizadores16);
        org.junit.Assert.assertNotNull(list_motorista30);
        org.junit.Assert.assertNotNull(list_cliente32);
        org.junit.Assert.assertNotNull(list_cliente35);
        org.junit.Assert.assertNotNull(list_motorista43);
        org.junit.Assert.assertTrue(i44 == (-1));
        org.junit.Assert.assertTrue(i45 == 0);
        org.junit.Assert.assertTrue(b46 == true);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "------- UMeR --------\n" + "'", str47.equals("------- UMeR --------\n"));
        org.junit.Assert.assertNotNull(utilizadores48);
        org.junit.Assert.assertTrue(i49 == 1);
        org.junit.Assert.assertTrue(i50 == 1);
        org.junit.Assert.assertNotNull(utilizadores51);
        org.junit.Assert.assertNotNull(list_motorista52);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        boolean b3 = utilizadores0.equals((java.lang.Object) 100L);
        Utilizadores utilizadores4 = new Utilizadores();
        utilizadores4.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores4.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista17 = utilizadores4.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator18 = utilizadores4.getUtilizadores();
        Utilizadores utilizadores19 = new Utilizadores(map_str_ator18);
        boolean b20 = utilizadores0.equals((java.lang.Object) map_str_ator18);
        Utilizadores utilizadores21 = new Utilizadores(map_str_ator18);
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertNotNull(list_motorista17);
        org.junit.Assert.assertNotNull(map_str_ator18);
        org.junit.Assert.assertTrue(b20 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator14 = utilizadores0.getUtilizadores();
        java.util.List<Motorista> list_motorista15 = utilizadores0.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores16 = new Utilizadores();
        boolean b18 = utilizadores16.equals((java.lang.Object) (short) 1);
        Utilizadores utilizadores19 = new Utilizadores();
        utilizadores19.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores19.adiciona("", "", "hi!", "", "");
        Ator ator33 = utilizadores19.getAtor("hi!");
        int i34 = utilizadores16.compareTo(utilizadores19);
        Utilizadores utilizadores35 = new Utilizadores();
        utilizadores35.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores35.adiciona("", "", "hi!", "", "");
        Ator ator49 = utilizadores35.getAtor("hi!");
        Utilizadores utilizadores50 = new Utilizadores(utilizadores35);
        Utilizadores utilizadores51 = new Utilizadores(utilizadores35);
        utilizadores51.adiciona("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\n\nNome: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: \nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "", "hi!", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
        java.util.List<Cliente> list_cliente58 = utilizadores51.top10ClientesGastadores();
        boolean b59 = utilizadores16.equals((java.lang.Object) utilizadores51);
        Utilizadores utilizadores60 = new Utilizadores();
        java.util.List<Cliente> list_cliente61 = utilizadores60.top10ClientesGastadores();
        boolean b63 = utilizadores60.equals((java.lang.Object) 100L);
        Utilizadores utilizadores64 = new Utilizadores();
        utilizadores64.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores64.adiciona("", "", "hi!", "", "");
        Ator ator78 = utilizadores64.getAtor("hi!");
        utilizadores60.adiciona(ator78);
        utilizadores16.adiciona(ator78);
        try {
            utilizadores0.adiciona(ator78);
            org.junit.Assert.fail("Expected exception of type EmailAlreadyInUseException");
        } catch (EmailAlreadyInUseException e) {
        }
        org.junit.Assert.assertNotNull(list_motorista13);
        org.junit.Assert.assertNotNull(map_str_ator14);
        org.junit.Assert.assertNotNull(list_motorista15);
        org.junit.Assert.assertTrue(b18 == false);
        org.junit.Assert.assertNotNull(ator33);
        org.junit.Assert.assertTrue(i34 == (-1));
        org.junit.Assert.assertNotNull(ator49);
        org.junit.Assert.assertNotNull(list_cliente58);
        org.junit.Assert.assertTrue(b59 == false);
        org.junit.Assert.assertNotNull(list_cliente61);
        org.junit.Assert.assertTrue(b63 == false);
        org.junit.Assert.assertNotNull(ator78);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        java.util.List<Cliente> list_cliente16 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores17 = new Utilizadores(utilizadores0);
        Utilizadores utilizadores18 = utilizadores0.clone();
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(list_cliente16);
        org.junit.Assert.assertNotNull(utilizadores18);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores14 = new Utilizadores(utilizadores0);
        Utilizadores utilizadores15 = new Utilizadores();
        utilizadores15.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores15.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista28 = utilizadores15.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator29 = utilizadores15.getUtilizadores();
        Utilizadores utilizadores30 = new Utilizadores(map_str_ator29);
        int i31 = utilizadores0.compareTo(utilizadores30);
        org.junit.Assert.assertNotNull(list_motorista13);
        org.junit.Assert.assertNotNull(list_motorista28);
        org.junit.Assert.assertNotNull(map_str_ator29);
        org.junit.Assert.assertTrue(i31 == 0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        java.lang.String str16 = utilizadores0.toString();
        Utilizadores utilizadores17 = utilizadores0.clone();
        Utilizadores utilizadores18 = new Utilizadores();
        utilizadores18.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores18.adiciona("", "", "hi!", "", "");
        Ator ator32 = utilizadores18.getAtor("hi!");
        Utilizadores utilizadores33 = new Utilizadores(utilizadores18);
        Ator ator35 = utilizadores33.getAtor("");
        utilizadores17.adiciona(ator35);
        Utilizadores utilizadores37 = utilizadores17.clone();
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_cliente4);
        org.junit.Assert.assertNotNull(list_motorista12);
        org.junit.Assert.assertTrue(i13 == (-1));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(b15 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "------- UMeR --------\n" + "'", str16.equals("------- UMeR --------\n"));
        org.junit.Assert.assertNotNull(utilizadores17);
        org.junit.Assert.assertNotNull(ator32);
        org.junit.Assert.assertNotNull(ator35);
        org.junit.Assert.assertNotNull(utilizadores37);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        Utilizadores utilizadores16 = new Utilizadores();
        java.util.List<Cliente> list_cliente17 = utilizadores16.top10ClientesGastadores();
        Utilizadores utilizadores18 = new Utilizadores();
        Utilizadores utilizadores19 = new Utilizadores();
        java.util.List<Cliente> list_cliente20 = utilizadores19.top10ClientesGastadores();
        Utilizadores utilizadores21 = new Utilizadores();
        utilizadores21.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista28 = utilizadores21.top5MotoristasComMaiorDesvio();
        int i29 = utilizadores19.compareTo(utilizadores21);
        int i30 = utilizadores18.compareTo(utilizadores19);
        boolean b31 = utilizadores16.equals((java.lang.Object) utilizadores19);
        Utilizadores utilizadores32 = utilizadores16.clone();
        boolean b33 = utilizadores0.equals((java.lang.Object) utilizadores16);
        Utilizadores utilizadores34 = new Utilizadores();
        utilizadores34.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores34.adiciona("", "", "hi!", "", "");
        Ator ator48 = utilizadores34.getAtor("hi!");
        Utilizadores utilizadores49 = new Utilizadores(utilizadores34);
        Ator ator51 = utilizadores49.getAtor("");
        utilizadores0.adiciona(ator51);
        Utilizadores utilizadores53 = utilizadores0.clone();
        Utilizadores utilizadores54 = new Utilizadores(utilizadores53);
        Utilizadores utilizadores55 = utilizadores54.clone();
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_cliente4);
        org.junit.Assert.assertNotNull(list_motorista12);
        org.junit.Assert.assertTrue(i13 == (-1));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(b15 == true);
        org.junit.Assert.assertNotNull(list_cliente17);
        org.junit.Assert.assertNotNull(list_cliente20);
        org.junit.Assert.assertNotNull(list_motorista28);
        org.junit.Assert.assertTrue(i29 == (-1));
        org.junit.Assert.assertTrue(i30 == 0);
        org.junit.Assert.assertTrue(b31 == true);
        org.junit.Assert.assertNotNull(utilizadores32);
        org.junit.Assert.assertTrue(b33 == true);
        org.junit.Assert.assertNotNull(ator48);
        org.junit.Assert.assertNotNull(ator51);
        org.junit.Assert.assertNotNull(utilizadores53);
        org.junit.Assert.assertNotNull(utilizadores55);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        Utilizadores utilizadores16 = new Utilizadores(utilizadores0);
        Utilizadores utilizadores17 = new Utilizadores();
        utilizadores17.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores17.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista30 = utilizadores17.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator31 = utilizadores17.getUtilizadores();
        Utilizadores utilizadores32 = new Utilizadores(map_str_ator31);
        Utilizadores utilizadores33 = new Utilizadores();
        java.util.List<Cliente> list_cliente34 = utilizadores33.top10ClientesGastadores();
        java.lang.String str35 = utilizadores33.toString();
        Utilizadores utilizadores36 = new Utilizadores();
        java.util.List<Motorista> list_motorista37 = utilizadores36.top5MotoristasComMaiorDesvio();
        boolean b38 = utilizadores33.equals((java.lang.Object) list_motorista37);
        boolean b39 = utilizadores32.equals((java.lang.Object) list_motorista37);
        int i40 = utilizadores0.compareTo(utilizadores32);
        java.lang.String str41 = utilizadores32.toString();
        utilizadores32.adiciona("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\n\nNome: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: \nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\n\nNome: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: \nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(list_motorista30);
        org.junit.Assert.assertNotNull(map_str_ator31);
        org.junit.Assert.assertNotNull(list_cliente34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "------- UMeR --------\n" + "'", str35.equals("------- UMeR --------\n"));
        org.junit.Assert.assertNotNull(list_motorista37);
        org.junit.Assert.assertTrue(b38 == false);
        org.junit.Assert.assertTrue(b39 == false);
        org.junit.Assert.assertTrue(i40 == 0);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str41.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        java.util.List<Motorista> list_motorista16 = utilizadores15.top5MotoristasComMaiorDesvio();
        boolean b18 = utilizadores15.equals((java.lang.Object) 1);
        java.util.List<Motorista> list_motorista19 = utilizadores15.top5MotoristasComMaiorDesvio();
        java.util.List<Motorista> list_motorista20 = utilizadores15.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores21 = utilizadores15.clone();
        java.util.Map<java.lang.String, Ator> map_str_ator22 = utilizadores15.getUtilizadores();
        Utilizadores utilizadores23 = new Utilizadores(map_str_ator22);
        Utilizadores utilizadores24 = new Utilizadores(map_str_ator22);
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(list_motorista16);
        org.junit.Assert.assertTrue(b18 == false);
        org.junit.Assert.assertNotNull(list_motorista19);
        org.junit.Assert.assertNotNull(list_motorista20);
        org.junit.Assert.assertNotNull(utilizadores21);
        org.junit.Assert.assertNotNull(map_str_ator22);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        Utilizadores utilizadores0 = new Utilizadores();
        boolean b2 = utilizadores0.equals((java.lang.Object) (short) 1);
        Utilizadores utilizadores3 = new Utilizadores();
        utilizadores3.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores3.adiciona("", "", "hi!", "", "");
        Ator ator17 = utilizadores3.getAtor("hi!");
        int i18 = utilizadores0.compareTo(utilizadores3);
        Utilizadores utilizadores19 = new Utilizadores();
        java.util.List<Motorista> list_motorista20 = utilizadores19.top5MotoristasComMaiorDesvio();
        int i21 = utilizadores3.compareTo(utilizadores19);
        try {
            Ator ator23 = utilizadores3.getAtor("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\n\nNome: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: \nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
            org.junit.Assert.fail("Expected exception of type EmailDoesNotExistException");
        } catch (EmailDoesNotExistException e) {
        }
        org.junit.Assert.assertTrue(b2 == false);
        org.junit.Assert.assertNotNull(ator17);
        org.junit.Assert.assertTrue(i18 == (-1));
        org.junit.Assert.assertNotNull(list_motorista20);
        org.junit.Assert.assertTrue(i21 == 1);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("");
        Utilizadores utilizadores15 = new Utilizadores();
        utilizadores15.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores15.adiciona("", "", "hi!", "", "");
        Ator ator29 = utilizadores15.getAtor("hi!");
        Utilizadores utilizadores30 = new Utilizadores(utilizadores15);
        Utilizadores utilizadores31 = utilizadores15.clone();
        Utilizadores utilizadores32 = new Utilizadores();
        utilizadores32.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores32.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista45 = utilizadores32.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores46 = new Utilizadores();
        java.util.List<Cliente> list_cliente47 = utilizadores46.top10ClientesGastadores();
        Utilizadores utilizadores48 = new Utilizadores();
        Utilizadores utilizadores49 = new Utilizadores();
        java.util.List<Cliente> list_cliente50 = utilizadores49.top10ClientesGastadores();
        Utilizadores utilizadores51 = new Utilizadores();
        utilizadores51.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista58 = utilizadores51.top5MotoristasComMaiorDesvio();
        int i59 = utilizadores49.compareTo(utilizadores51);
        int i60 = utilizadores48.compareTo(utilizadores49);
        boolean b61 = utilizadores46.equals((java.lang.Object) utilizadores49);
        java.lang.String str62 = utilizadores46.toString();
        Utilizadores utilizadores63 = utilizadores46.clone();
        int i64 = utilizadores32.compareTo(utilizadores63);
        int i65 = utilizadores15.compareTo(utilizadores63);
        boolean b66 = utilizadores0.equals((java.lang.Object) utilizadores15);
        java.util.Map<java.lang.String, Ator> map_str_ator67 = utilizadores0.getUtilizadores();
        Utilizadores utilizadores68 = new Utilizadores(map_str_ator67);
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(ator29);
        org.junit.Assert.assertNotNull(utilizadores31);
        org.junit.Assert.assertNotNull(list_motorista45);
        org.junit.Assert.assertNotNull(list_cliente47);
        org.junit.Assert.assertNotNull(list_cliente50);
        org.junit.Assert.assertNotNull(list_motorista58);
        org.junit.Assert.assertTrue(i59 == (-1));
        org.junit.Assert.assertTrue(i60 == 0);
        org.junit.Assert.assertTrue(b61 == true);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "------- UMeR --------\n" + "'", str62.equals("------- UMeR --------\n"));
        org.junit.Assert.assertNotNull(utilizadores63);
        org.junit.Assert.assertTrue(i64 == 1);
        org.junit.Assert.assertTrue(i65 == 1);
        org.junit.Assert.assertTrue(b66 == true);
        org.junit.Assert.assertNotNull(map_str_ator67);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        java.util.List<Motorista> list_motorista16 = utilizadores15.top5MotoristasComMaiorDesvio();
        boolean b18 = utilizadores15.equals((java.lang.Object) 1);
        java.util.List<Motorista> list_motorista19 = utilizadores15.top5MotoristasComMaiorDesvio();
        java.util.List<Motorista> list_motorista20 = utilizadores15.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores21 = utilizadores15.clone();
        Utilizadores utilizadores22 = new Utilizadores(utilizadores21);
        Utilizadores utilizadores23 = new Utilizadores();
        java.util.List<Cliente> list_cliente24 = utilizadores23.top10ClientesGastadores();
        Utilizadores utilizadores25 = new Utilizadores();
        Utilizadores utilizadores26 = new Utilizadores();
        java.util.List<Cliente> list_cliente27 = utilizadores26.top10ClientesGastadores();
        Utilizadores utilizadores28 = new Utilizadores();
        utilizadores28.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista35 = utilizadores28.top5MotoristasComMaiorDesvio();
        int i36 = utilizadores26.compareTo(utilizadores28);
        int i37 = utilizadores25.compareTo(utilizadores26);
        boolean b38 = utilizadores23.equals((java.lang.Object) utilizadores26);
        java.lang.String str39 = utilizadores23.toString();
        Utilizadores utilizadores40 = utilizadores23.clone();
        int i41 = utilizadores22.compareTo(utilizadores40);
        java.util.List<Cliente> list_cliente42 = utilizadores40.top10ClientesGastadores();
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(list_motorista16);
        org.junit.Assert.assertTrue(b18 == false);
        org.junit.Assert.assertNotNull(list_motorista19);
        org.junit.Assert.assertNotNull(list_motorista20);
        org.junit.Assert.assertNotNull(utilizadores21);
        org.junit.Assert.assertNotNull(list_cliente24);
        org.junit.Assert.assertNotNull(list_cliente27);
        org.junit.Assert.assertNotNull(list_motorista35);
        org.junit.Assert.assertTrue(i36 == (-1));
        org.junit.Assert.assertTrue(i37 == 0);
        org.junit.Assert.assertTrue(b38 == true);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "------- UMeR --------\n" + "'", str39.equals("------- UMeR --------\n"));
        org.junit.Assert.assertNotNull(utilizadores40);
        org.junit.Assert.assertTrue(i41 == 1);
        org.junit.Assert.assertNotNull(list_cliente42);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        Utilizadores utilizadores0 = new Utilizadores();
        boolean b2 = utilizadores0.equals((java.lang.Object) (short) 1);
        Utilizadores utilizadores3 = new Utilizadores();
        utilizadores3.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores3.adiciona("", "", "hi!", "", "");
        Ator ator17 = utilizadores3.getAtor("hi!");
        int i18 = utilizadores0.compareTo(utilizadores3);
        boolean b20 = utilizadores3.equals((java.lang.Object) 1.0f);
        Utilizadores utilizadores21 = new Utilizadores();
        java.util.List<Cliente> list_cliente22 = utilizadores21.top10ClientesGastadores();
        Utilizadores utilizadores23 = new Utilizadores();
        Utilizadores utilizadores24 = new Utilizadores();
        java.util.List<Cliente> list_cliente25 = utilizadores24.top10ClientesGastadores();
        Utilizadores utilizadores26 = new Utilizadores();
        utilizadores26.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista33 = utilizadores26.top5MotoristasComMaiorDesvio();
        int i34 = utilizadores24.compareTo(utilizadores26);
        int i35 = utilizadores23.compareTo(utilizadores24);
        boolean b36 = utilizadores21.equals((java.lang.Object) utilizadores24);
        Utilizadores utilizadores37 = utilizadores21.clone();
        Utilizadores utilizadores38 = new Utilizadores();
        Utilizadores utilizadores39 = new Utilizadores();
        java.util.List<Cliente> list_cliente40 = utilizadores39.top10ClientesGastadores();
        Utilizadores utilizadores41 = new Utilizadores();
        utilizadores41.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista48 = utilizadores41.top5MotoristasComMaiorDesvio();
        int i49 = utilizadores39.compareTo(utilizadores41);
        int i50 = utilizadores38.compareTo(utilizadores39);
        java.util.Map<java.lang.String, Ator> map_str_ator51 = utilizadores39.getUtilizadores();
        Utilizadores utilizadores52 = new Utilizadores();
        utilizadores52.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores52.adiciona("", "", "hi!", "", "");
        Ator ator66 = utilizadores52.getAtor("hi!");
        utilizadores39.adiciona(ator66);
        Utilizadores utilizadores68 = new Utilizadores();
        utilizadores68.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores68.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista81 = utilizadores68.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator82 = utilizadores68.getUtilizadores();
        Utilizadores utilizadores83 = new Utilizadores(map_str_ator82);
        Utilizadores utilizadores84 = new Utilizadores();
        java.util.List<Cliente> list_cliente85 = utilizadores84.top10ClientesGastadores();
        java.lang.String str86 = utilizadores84.toString();
        Utilizadores utilizadores87 = new Utilizadores();
        java.util.List<Motorista> list_motorista88 = utilizadores87.top5MotoristasComMaiorDesvio();
        boolean b89 = utilizadores84.equals((java.lang.Object) list_motorista88);
        boolean b90 = utilizadores83.equals((java.lang.Object) list_motorista88);
        int i91 = utilizadores39.compareTo(utilizadores83);
        Utilizadores utilizadores92 = new Utilizadores(utilizadores83);
        int i93 = utilizadores21.compareTo(utilizadores92);
        Utilizadores utilizadores94 = utilizadores92.clone();
        Utilizadores utilizadores95 = utilizadores92.clone();
        int i96 = utilizadores3.compareTo(utilizadores95);
        org.junit.Assert.assertTrue(b2 == false);
        org.junit.Assert.assertNotNull(ator17);
        org.junit.Assert.assertTrue(i18 == (-1));
        org.junit.Assert.assertTrue(b20 == false);
        org.junit.Assert.assertNotNull(list_cliente22);
        org.junit.Assert.assertNotNull(list_cliente25);
        org.junit.Assert.assertNotNull(list_motorista33);
        org.junit.Assert.assertTrue(i34 == (-1));
        org.junit.Assert.assertTrue(i35 == 0);
        org.junit.Assert.assertTrue(b36 == true);
        org.junit.Assert.assertNotNull(utilizadores37);
        org.junit.Assert.assertNotNull(list_cliente40);
        org.junit.Assert.assertNotNull(list_motorista48);
        org.junit.Assert.assertTrue(i49 == (-1));
        org.junit.Assert.assertTrue(i50 == 0);
        org.junit.Assert.assertNotNull(map_str_ator51);
        org.junit.Assert.assertNotNull(ator66);
        org.junit.Assert.assertNotNull(list_motorista81);
        org.junit.Assert.assertNotNull(map_str_ator82);
        org.junit.Assert.assertNotNull(list_cliente85);
        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "------- UMeR --------\n" + "'", str86.equals("------- UMeR --------\n"));
        org.junit.Assert.assertNotNull(list_motorista88);
        org.junit.Assert.assertTrue(b89 == false);
        org.junit.Assert.assertTrue(b90 == false);
        org.junit.Assert.assertTrue(i91 == 3);
        org.junit.Assert.assertTrue(i93 == (-1));
        org.junit.Assert.assertNotNull(utilizadores94);
        org.junit.Assert.assertNotNull(utilizadores95);
        org.junit.Assert.assertTrue(i96 == 0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        Utilizadores utilizadores0 = new Utilizadores();
        Utilizadores utilizadores1 = utilizadores0.clone();
        java.util.Map<java.lang.String, Ator> map_str_ator2 = utilizadores1.getUtilizadores();
        Utilizadores utilizadores3 = utilizadores1.clone();
        java.util.Map<java.lang.String, Ator> map_str_ator4 = utilizadores3.getUtilizadores();
        org.junit.Assert.assertNotNull(utilizadores1);
        org.junit.Assert.assertNotNull(map_str_ator2);
        org.junit.Assert.assertNotNull(utilizadores3);
        org.junit.Assert.assertNotNull(map_str_ator4);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator14 = utilizadores0.getUtilizadores();
        Utilizadores utilizadores15 = new Utilizadores(map_str_ator14);
        Utilizadores utilizadores16 = new Utilizadores();
        utilizadores16.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores16.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista29 = utilizadores16.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator30 = utilizadores16.getUtilizadores();
        Utilizadores utilizadores31 = new Utilizadores(map_str_ator30);
        int i32 = utilizadores15.compareTo(utilizadores31);
        Utilizadores utilizadores33 = new Utilizadores();
        utilizadores33.adiciona("hi!", "hi!", "", "", "hi!");
        Utilizadores utilizadores40 = utilizadores33.clone();
        java.util.List<Cliente> list_cliente41 = utilizadores33.top10ClientesGastadores();
        boolean b42 = utilizadores15.equals((java.lang.Object) list_cliente41);
        utilizadores15.adiciona("------- UMeR --------\nE-mail: \nNome: ------- UMeR --------\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nData de nascimento: ------- UMeR --------\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: \nPassword: ------- UMeR --------\n\nMorada: \nData de nascimento: ------- UMeR --------\n\nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\n", "hi!", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
        java.util.List<Motorista> list_motorista49 = utilizadores15.top5MotoristasComMaiorDesvio();
        org.junit.Assert.assertNotNull(list_motorista13);
        org.junit.Assert.assertNotNull(map_str_ator14);
        org.junit.Assert.assertNotNull(list_motorista29);
        org.junit.Assert.assertNotNull(map_str_ator30);
        org.junit.Assert.assertTrue(i32 == 0);
        org.junit.Assert.assertNotNull(utilizadores40);
        org.junit.Assert.assertNotNull(list_cliente41);
        org.junit.Assert.assertTrue(b42 == false);
        org.junit.Assert.assertNotNull(list_motorista49);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        Utilizadores utilizadores0 = new Utilizadores();
        Utilizadores utilizadores1 = new Utilizadores();
        java.util.List<Cliente> list_cliente2 = utilizadores1.top10ClientesGastadores();
        Utilizadores utilizadores3 = new Utilizadores();
        utilizadores3.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista10 = utilizadores3.top5MotoristasComMaiorDesvio();
        int i11 = utilizadores1.compareTo(utilizadores3);
        int i12 = utilizadores0.compareTo(utilizadores1);
        java.util.List<Motorista> list_motorista13 = utilizadores1.top5MotoristasComMaiorDesvio();
        java.util.List<Motorista> list_motorista14 = utilizadores1.top5MotoristasComMaiorDesvio();
        org.junit.Assert.assertNotNull(list_cliente2);
        org.junit.Assert.assertNotNull(list_motorista10);
        org.junit.Assert.assertTrue(i11 == (-1));
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertNotNull(list_motorista13);
        org.junit.Assert.assertNotNull(list_motorista14);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Motorista> list_motorista1 = utilizadores0.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores2 = new Utilizadores();
        boolean b4 = utilizadores2.equals((java.lang.Object) (short) 1);
        boolean b5 = utilizadores0.equals((java.lang.Object) b4);
        java.util.Map<java.lang.String, Ator> map_str_ator6 = utilizadores0.getUtilizadores();
        Utilizadores utilizadores7 = new Utilizadores(map_str_ator6);
        java.util.Map<java.lang.String, Ator> map_str_ator8 = utilizadores7.getUtilizadores();
        Utilizadores utilizadores9 = new Utilizadores(map_str_ator8);
        java.util.List<Cliente> list_cliente10 = utilizadores9.top10ClientesGastadores();
        org.junit.Assert.assertNotNull(list_motorista1);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(b5 == false);
        org.junit.Assert.assertNotNull(map_str_ator6);
        org.junit.Assert.assertNotNull(map_str_ator8);
        org.junit.Assert.assertNotNull(list_cliente10);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores14 = new Utilizadores();
        utilizadores14.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores14.adiciona("", "", "hi!", "", "");
        Ator ator28 = utilizadores14.getAtor("hi!");
        Utilizadores utilizadores29 = new Utilizadores(utilizadores14);
        boolean b30 = utilizadores0.equals((java.lang.Object) utilizadores29);
        java.util.List<Cliente> list_cliente31 = utilizadores0.top10ClientesGastadores();
        java.util.List<Motorista> list_motorista32 = utilizadores0.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores33 = utilizadores0.clone();
        org.junit.Assert.assertNotNull(list_motorista13);
        org.junit.Assert.assertNotNull(ator28);
        org.junit.Assert.assertTrue(b30 == true);
        org.junit.Assert.assertNotNull(list_cliente31);
        org.junit.Assert.assertNotNull(list_motorista32);
        org.junit.Assert.assertNotNull(utilizadores33);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        Utilizadores utilizadores0 = new Utilizadores();
        Utilizadores utilizadores1 = utilizadores0.clone();
        Utilizadores utilizadores2 = new Utilizadores(utilizadores0);
        Utilizadores utilizadores3 = new Utilizadores(utilizadores2);
        org.junit.Assert.assertNotNull(utilizadores1);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        Utilizadores utilizadores16 = utilizadores0.clone();
        Utilizadores utilizadores17 = new Utilizadores();
        utilizadores17.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores17.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista30 = utilizadores17.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores31 = new Utilizadores();
        java.util.List<Cliente> list_cliente32 = utilizadores31.top10ClientesGastadores();
        Utilizadores utilizadores33 = new Utilizadores();
        Utilizadores utilizadores34 = new Utilizadores();
        java.util.List<Cliente> list_cliente35 = utilizadores34.top10ClientesGastadores();
        Utilizadores utilizadores36 = new Utilizadores();
        utilizadores36.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista43 = utilizadores36.top5MotoristasComMaiorDesvio();
        int i44 = utilizadores34.compareTo(utilizadores36);
        int i45 = utilizadores33.compareTo(utilizadores34);
        boolean b46 = utilizadores31.equals((java.lang.Object) utilizadores34);
        java.lang.String str47 = utilizadores31.toString();
        Utilizadores utilizadores48 = utilizadores31.clone();
        int i49 = utilizadores17.compareTo(utilizadores48);
        int i50 = utilizadores0.compareTo(utilizadores48);
        Utilizadores utilizadores51 = utilizadores0.clone();
        Utilizadores utilizadores52 = utilizadores51.clone();
        java.util.List<Motorista> list_motorista53 = utilizadores51.top5MotoristasComMaiorDesvio();
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(utilizadores16);
        org.junit.Assert.assertNotNull(list_motorista30);
        org.junit.Assert.assertNotNull(list_cliente32);
        org.junit.Assert.assertNotNull(list_cliente35);
        org.junit.Assert.assertNotNull(list_motorista43);
        org.junit.Assert.assertTrue(i44 == (-1));
        org.junit.Assert.assertTrue(i45 == 0);
        org.junit.Assert.assertTrue(b46 == true);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "------- UMeR --------\n" + "'", str47.equals("------- UMeR --------\n"));
        org.junit.Assert.assertNotNull(utilizadores48);
        org.junit.Assert.assertTrue(i49 == 1);
        org.junit.Assert.assertTrue(i50 == 1);
        org.junit.Assert.assertNotNull(utilizadores51);
        org.junit.Assert.assertNotNull(utilizadores52);
        org.junit.Assert.assertNotNull(list_motorista53);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        Utilizadores utilizadores0 = new Utilizadores();
        boolean b2 = utilizadores0.equals((java.lang.Object) (short) 1);
        Utilizadores utilizadores3 = new Utilizadores();
        utilizadores3.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores3.adiciona("", "", "hi!", "", "");
        Ator ator17 = utilizadores3.getAtor("hi!");
        int i18 = utilizadores0.compareTo(utilizadores3);
        Utilizadores utilizadores19 = new Utilizadores(utilizadores0);
        Veiculo veiculo25 = null;
        utilizadores19.adiciona("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\n", "hi!", veiculo25);
        java.lang.String str27 = utilizadores19.toString();
        org.junit.Assert.assertTrue(b2 == false);
        org.junit.Assert.assertNotNull(ator17);
        org.junit.Assert.assertTrue(i18 == (-1));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "------- UMeR --------\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: ------- UMeR --------\n\nData de nascimento: hi!\nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\n" + "'", str27.equals("------- UMeR --------\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: ------- UMeR --------\n\nData de nascimento: hi!\nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\n"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator14 = utilizadores0.getUtilizadores();
        java.util.Map<java.lang.String, Ator> map_str_ator15 = utilizadores0.getUtilizadores();
        Utilizadores utilizadores16 = new Utilizadores(map_str_ator15);
        org.junit.Assert.assertNotNull(list_motorista13);
        org.junit.Assert.assertNotNull(map_str_ator14);
        org.junit.Assert.assertNotNull(map_str_ator15);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores14 = new Utilizadores();
        java.util.List<Cliente> list_cliente15 = utilizadores14.top10ClientesGastadores();
        Utilizadores utilizadores16 = new Utilizadores();
        Utilizadores utilizadores17 = new Utilizadores();
        java.util.List<Cliente> list_cliente18 = utilizadores17.top10ClientesGastadores();
        Utilizadores utilizadores19 = new Utilizadores();
        utilizadores19.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista26 = utilizadores19.top5MotoristasComMaiorDesvio();
        int i27 = utilizadores17.compareTo(utilizadores19);
        int i28 = utilizadores16.compareTo(utilizadores17);
        boolean b29 = utilizadores14.equals((java.lang.Object) utilizadores17);
        java.lang.String str30 = utilizadores14.toString();
        Utilizadores utilizadores31 = utilizadores14.clone();
        int i32 = utilizadores0.compareTo(utilizadores31);
        java.util.Map<java.lang.String, Ator> map_str_ator33 = utilizadores31.getUtilizadores();
        Utilizadores utilizadores34 = utilizadores31.clone();
        org.junit.Assert.assertNotNull(list_motorista13);
        org.junit.Assert.assertNotNull(list_cliente15);
        org.junit.Assert.assertNotNull(list_cliente18);
        org.junit.Assert.assertNotNull(list_motorista26);
        org.junit.Assert.assertTrue(i27 == (-1));
        org.junit.Assert.assertTrue(i28 == 0);
        org.junit.Assert.assertTrue(b29 == true);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "------- UMeR --------\n" + "'", str30.equals("------- UMeR --------\n"));
        org.junit.Assert.assertNotNull(utilizadores31);
        org.junit.Assert.assertTrue(i32 == 1);
        org.junit.Assert.assertNotNull(map_str_ator33);
        org.junit.Assert.assertNotNull(utilizadores34);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores(utilizadores0);
        java.util.Map<java.lang.String, Ator> map_str_ator3 = utilizadores2.getUtilizadores();
        Utilizadores utilizadores4 = new Utilizadores(map_str_ator3);
        Utilizadores utilizadores5 = new Utilizadores(utilizadores4);
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(map_str_ator3);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        boolean b3 = utilizadores0.equals((java.lang.Object) 100L);
        Utilizadores utilizadores4 = new Utilizadores();
        utilizadores4.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores4.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista17 = utilizadores4.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator18 = utilizadores4.getUtilizadores();
        Utilizadores utilizadores19 = new Utilizadores(map_str_ator18);
        boolean b20 = utilizadores0.equals((java.lang.Object) map_str_ator18);
        Utilizadores utilizadores21 = new Utilizadores();
        utilizadores21.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista28 = utilizadores21.top5MotoristasComMaiorDesvio();
        java.lang.String str29 = utilizadores21.toString();
        Utilizadores utilizadores30 = new Utilizadores();
        java.util.List<Cliente> list_cliente31 = utilizadores30.top10ClientesGastadores();
        Utilizadores utilizadores32 = new Utilizadores();
        Utilizadores utilizadores33 = new Utilizadores();
        java.util.List<Cliente> list_cliente34 = utilizadores33.top10ClientesGastadores();
        Utilizadores utilizadores35 = new Utilizadores();
        utilizadores35.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista42 = utilizadores35.top5MotoristasComMaiorDesvio();
        int i43 = utilizadores33.compareTo(utilizadores35);
        int i44 = utilizadores32.compareTo(utilizadores33);
        boolean b45 = utilizadores30.equals((java.lang.Object) utilizadores33);
        Utilizadores utilizadores46 = utilizadores30.clone();
        int i47 = utilizadores21.compareTo(utilizadores30);
        int i48 = utilizadores0.compareTo(utilizadores30);
        try {
            Ator ator50 = utilizadores30.getAtor("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
            org.junit.Assert.fail("Expected exception of type EmailDoesNotExistException");
        } catch (EmailDoesNotExistException e) {
        }
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertNotNull(list_motorista17);
        org.junit.Assert.assertNotNull(map_str_ator18);
        org.junit.Assert.assertTrue(b20 == false);
        org.junit.Assert.assertNotNull(list_motorista28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str29.equals("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertNotNull(list_cliente31);
        org.junit.Assert.assertNotNull(list_cliente34);
        org.junit.Assert.assertNotNull(list_motorista42);
        org.junit.Assert.assertTrue(i43 == (-1));
        org.junit.Assert.assertTrue(i44 == 0);
        org.junit.Assert.assertTrue(b45 == true);
        org.junit.Assert.assertNotNull(utilizadores46);
        org.junit.Assert.assertTrue(i47 == 1);
        org.junit.Assert.assertTrue(i48 == 0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        java.lang.String str16 = utilizadores0.toString();
        Utilizadores utilizadores17 = utilizadores0.clone();
        java.lang.String str18 = utilizadores0.toString();
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_cliente4);
        org.junit.Assert.assertNotNull(list_motorista12);
        org.junit.Assert.assertTrue(i13 == (-1));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(b15 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "------- UMeR --------\n" + "'", str16.equals("------- UMeR --------\n"));
        org.junit.Assert.assertNotNull(utilizadores17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "------- UMeR --------\n" + "'", str18.equals("------- UMeR --------\n"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        Utilizadores utilizadores16 = new Utilizadores();
        java.util.List<Cliente> list_cliente17 = utilizadores16.top10ClientesGastadores();
        Utilizadores utilizadores18 = new Utilizadores();
        Utilizadores utilizadores19 = new Utilizadores();
        java.util.List<Cliente> list_cliente20 = utilizadores19.top10ClientesGastadores();
        Utilizadores utilizadores21 = new Utilizadores();
        utilizadores21.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista28 = utilizadores21.top5MotoristasComMaiorDesvio();
        int i29 = utilizadores19.compareTo(utilizadores21);
        int i30 = utilizadores18.compareTo(utilizadores19);
        boolean b31 = utilizadores16.equals((java.lang.Object) utilizadores19);
        Utilizadores utilizadores32 = utilizadores16.clone();
        boolean b33 = utilizadores0.equals((java.lang.Object) utilizadores16);
        Utilizadores utilizadores34 = new Utilizadores();
        utilizadores34.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores34.adiciona("", "", "hi!", "", "");
        Ator ator48 = utilizadores34.getAtor("hi!");
        Utilizadores utilizadores49 = new Utilizadores(utilizadores34);
        Ator ator51 = utilizadores49.getAtor("");
        utilizadores0.adiciona(ator51);
        Utilizadores utilizadores53 = utilizadores0.clone();
        Utilizadores utilizadores54 = new Utilizadores(utilizadores53);
        Utilizadores utilizadores55 = utilizadores53.clone();
        java.util.List<Motorista> list_motorista56 = utilizadores55.top5MotoristasComMaiorDesvio();
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_cliente4);
        org.junit.Assert.assertNotNull(list_motorista12);
        org.junit.Assert.assertTrue(i13 == (-1));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(b15 == true);
        org.junit.Assert.assertNotNull(list_cliente17);
        org.junit.Assert.assertNotNull(list_cliente20);
        org.junit.Assert.assertNotNull(list_motorista28);
        org.junit.Assert.assertTrue(i29 == (-1));
        org.junit.Assert.assertTrue(i30 == 0);
        org.junit.Assert.assertTrue(b31 == true);
        org.junit.Assert.assertNotNull(utilizadores32);
        org.junit.Assert.assertTrue(b33 == true);
        org.junit.Assert.assertNotNull(ator48);
        org.junit.Assert.assertNotNull(ator51);
        org.junit.Assert.assertNotNull(utilizadores53);
        org.junit.Assert.assertNotNull(utilizadores55);
        org.junit.Assert.assertNotNull(list_motorista56);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        Utilizadores utilizadores16 = new Utilizadores();
        java.util.List<Cliente> list_cliente17 = utilizadores16.top10ClientesGastadores();
        Utilizadores utilizadores18 = new Utilizadores();
        Utilizadores utilizadores19 = new Utilizadores();
        java.util.List<Cliente> list_cliente20 = utilizadores19.top10ClientesGastadores();
        Utilizadores utilizadores21 = new Utilizadores();
        utilizadores21.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista28 = utilizadores21.top5MotoristasComMaiorDesvio();
        int i29 = utilizadores19.compareTo(utilizadores21);
        int i30 = utilizadores18.compareTo(utilizadores19);
        boolean b31 = utilizadores16.equals((java.lang.Object) utilizadores19);
        Utilizadores utilizadores32 = utilizadores16.clone();
        boolean b33 = utilizadores0.equals((java.lang.Object) utilizadores16);
        Utilizadores utilizadores34 = new Utilizadores();
        utilizadores34.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores34.adiciona("", "", "hi!", "", "");
        Ator ator48 = utilizadores34.getAtor("hi!");
        Utilizadores utilizadores49 = new Utilizadores(utilizadores34);
        Ator ator51 = utilizadores49.getAtor("");
        utilizadores0.adiciona(ator51);
        utilizadores0.adiciona("hi!", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "");
        java.util.List<Cliente> list_cliente59 = utilizadores0.top10ClientesGastadores();
        java.util.List<Motorista> list_motorista60 = utilizadores0.top5MotoristasComMaiorDesvio();
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_cliente4);
        org.junit.Assert.assertNotNull(list_motorista12);
        org.junit.Assert.assertTrue(i13 == (-1));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(b15 == true);
        org.junit.Assert.assertNotNull(list_cliente17);
        org.junit.Assert.assertNotNull(list_cliente20);
        org.junit.Assert.assertNotNull(list_motorista28);
        org.junit.Assert.assertTrue(i29 == (-1));
        org.junit.Assert.assertTrue(i30 == 0);
        org.junit.Assert.assertTrue(b31 == true);
        org.junit.Assert.assertNotNull(utilizadores32);
        org.junit.Assert.assertTrue(b33 == true);
        org.junit.Assert.assertNotNull(ator48);
        org.junit.Assert.assertNotNull(ator51);
        org.junit.Assert.assertNotNull(list_cliente59);
        org.junit.Assert.assertNotNull(list_motorista60);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        Utilizadores utilizadores0 = new Utilizadores();
        boolean b2 = utilizadores0.equals((java.lang.Object) (short) 1);
        Utilizadores utilizadores3 = new Utilizadores();
        utilizadores3.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores3.adiciona("", "", "hi!", "", "");
        Ator ator17 = utilizadores3.getAtor("hi!");
        int i18 = utilizadores0.compareTo(utilizadores3);
        Utilizadores utilizadores19 = new Utilizadores();
        java.util.List<Motorista> list_motorista20 = utilizadores19.top5MotoristasComMaiorDesvio();
        int i21 = utilizadores3.compareTo(utilizadores19);
        java.util.List<Motorista> list_motorista22 = utilizadores3.top5MotoristasComMaiorDesvio();
        java.lang.String str23 = utilizadores3.toString();
        org.junit.Assert.assertTrue(b2 == false);
        org.junit.Assert.assertNotNull(ator17);
        org.junit.Assert.assertTrue(i18 == (-1));
        org.junit.Assert.assertNotNull(list_motorista20);
        org.junit.Assert.assertTrue(i21 == 1);
        org.junit.Assert.assertNotNull(list_motorista22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str23.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        Utilizadores utilizadores16 = new Utilizadores();
        java.util.List<Cliente> list_cliente17 = utilizadores16.top10ClientesGastadores();
        boolean b19 = utilizadores16.equals((java.lang.Object) 100L);
        Utilizadores utilizadores20 = new Utilizadores();
        utilizadores20.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores20.adiciona("", "", "hi!", "", "");
        Ator ator34 = utilizadores20.getAtor("hi!");
        utilizadores16.adiciona(ator34);
        utilizadores3.adiciona(ator34);
        Utilizadores utilizadores37 = utilizadores3.clone();
        Utilizadores utilizadores38 = new Utilizadores();
        java.util.List<Cliente> list_cliente39 = utilizadores38.top10ClientesGastadores();
        Utilizadores utilizadores40 = new Utilizadores();
        Utilizadores utilizadores41 = new Utilizadores();
        java.util.List<Cliente> list_cliente42 = utilizadores41.top10ClientesGastadores();
        Utilizadores utilizadores43 = new Utilizadores();
        utilizadores43.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista50 = utilizadores43.top5MotoristasComMaiorDesvio();
        int i51 = utilizadores41.compareTo(utilizadores43);
        int i52 = utilizadores40.compareTo(utilizadores41);
        boolean b53 = utilizadores38.equals((java.lang.Object) utilizadores41);
        Utilizadores utilizadores54 = new Utilizadores();
        java.util.List<Cliente> list_cliente55 = utilizadores54.top10ClientesGastadores();
        boolean b57 = utilizadores54.equals((java.lang.Object) 100L);
        Utilizadores utilizadores58 = new Utilizadores();
        utilizadores58.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores58.adiciona("", "", "hi!", "", "");
        Ator ator72 = utilizadores58.getAtor("hi!");
        utilizadores54.adiciona(ator72);
        utilizadores41.adiciona(ator72);
        try {
            utilizadores37.adiciona(ator72);
            org.junit.Assert.fail("Expected exception of type EmailAlreadyInUseException");
        } catch (EmailAlreadyInUseException e) {
        }
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_cliente4);
        org.junit.Assert.assertNotNull(list_motorista12);
        org.junit.Assert.assertTrue(i13 == (-1));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(b15 == true);
        org.junit.Assert.assertNotNull(list_cliente17);
        org.junit.Assert.assertTrue(b19 == false);
        org.junit.Assert.assertNotNull(ator34);
        org.junit.Assert.assertNotNull(utilizadores37);
        org.junit.Assert.assertNotNull(list_cliente39);
        org.junit.Assert.assertNotNull(list_cliente42);
        org.junit.Assert.assertNotNull(list_motorista50);
        org.junit.Assert.assertTrue(i51 == (-1));
        org.junit.Assert.assertTrue(i52 == 0);
        org.junit.Assert.assertTrue(b53 == true);
        org.junit.Assert.assertNotNull(list_cliente55);
        org.junit.Assert.assertTrue(b57 == false);
        org.junit.Assert.assertNotNull(ator72);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        Utilizadores utilizadores16 = new Utilizadores();
        utilizadores16.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores16.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista29 = utilizadores16.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator30 = utilizadores16.getUtilizadores();
        java.lang.String str31 = utilizadores16.toString();
        int i32 = utilizadores0.compareTo(utilizadores16);
        Utilizadores utilizadores33 = utilizadores16.clone();
        Utilizadores utilizadores34 = utilizadores16.clone();
        Utilizadores utilizadores35 = utilizadores34.clone();
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_cliente4);
        org.junit.Assert.assertNotNull(list_motorista12);
        org.junit.Assert.assertTrue(i13 == (-1));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(b15 == true);
        org.junit.Assert.assertNotNull(list_motorista29);
        org.junit.Assert.assertNotNull(map_str_ator30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str31.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertTrue(i32 == (-1));
        org.junit.Assert.assertNotNull(utilizadores33);
        org.junit.Assert.assertNotNull(utilizadores34);
        org.junit.Assert.assertNotNull(utilizadores35);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator14 = utilizadores0.getUtilizadores();
        java.util.List<Motorista> list_motorista15 = utilizadores0.top5MotoristasComMaiorDesvio();
        java.util.List<Cliente> list_cliente16 = utilizadores0.top10ClientesGastadores();
        java.util.Map<java.lang.String, Ator> map_str_ator17 = utilizadores0.getUtilizadores();
        Utilizadores utilizadores18 = new Utilizadores(utilizadores0);
        org.junit.Assert.assertNotNull(list_motorista13);
        org.junit.Assert.assertNotNull(map_str_ator14);
        org.junit.Assert.assertNotNull(list_motorista15);
        org.junit.Assert.assertNotNull(list_cliente16);
        org.junit.Assert.assertNotNull(map_str_ator17);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        Utilizadores utilizadores16 = new Utilizadores(utilizadores0);
        java.lang.Object obj17 = null;
        boolean b18 = utilizadores0.equals(obj17);
        Utilizadores utilizadores19 = utilizadores0.clone();
        Utilizadores utilizadores20 = utilizadores19.clone();
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertTrue(b18 == false);
        org.junit.Assert.assertNotNull(utilizadores19);
        org.junit.Assert.assertNotNull(utilizadores20);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        Utilizadores utilizadores0 = new Utilizadores();
        Utilizadores utilizadores1 = utilizadores0.clone();
        java.util.Map<java.lang.String, Ator> map_str_ator2 = utilizadores1.getUtilizadores();
        Utilizadores utilizadores3 = utilizadores1.clone();
        Utilizadores utilizadores4 = utilizadores1.clone();
        Utilizadores utilizadores5 = utilizadores4.clone();
        Utilizadores utilizadores6 = new Utilizadores();
        utilizadores6.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores6.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista19 = utilizadores6.top5MotoristasComMaiorDesvio();
        utilizadores6.adiciona("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
        java.lang.String str26 = utilizadores6.toString();
        Ator ator28 = utilizadores6.getAtor("");
        boolean b29 = utilizadores4.equals((java.lang.Object) ator28);
        Veiculo veiculo35 = null;
        utilizadores4.adiciona("------- UMeR --------\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: ------- UMeR --------\n\nData de nascimento: hi!\nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\n\nNome: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: \nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!", veiculo35);
        org.junit.Assert.assertNotNull(utilizadores1);
        org.junit.Assert.assertNotNull(map_str_ator2);
        org.junit.Assert.assertNotNull(utilizadores3);
        org.junit.Assert.assertNotNull(utilizadores4);
        org.junit.Assert.assertNotNull(utilizadores5);
        org.junit.Assert.assertNotNull(list_motorista19);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str26.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertNotNull(ator28);
        org.junit.Assert.assertTrue(b29 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        java.lang.String str16 = utilizadores0.toString();
        Utilizadores utilizadores17 = utilizadores0.clone();
        Utilizadores utilizadores18 = utilizadores17.clone();
        Utilizadores utilizadores19 = new Utilizadores();
        java.util.List<Cliente> list_cliente20 = utilizadores19.top10ClientesGastadores();
        Utilizadores utilizadores21 = new Utilizadores();
        Utilizadores utilizadores22 = new Utilizadores();
        java.util.List<Cliente> list_cliente23 = utilizadores22.top10ClientesGastadores();
        Utilizadores utilizadores24 = new Utilizadores();
        utilizadores24.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista31 = utilizadores24.top5MotoristasComMaiorDesvio();
        int i32 = utilizadores22.compareTo(utilizadores24);
        int i33 = utilizadores21.compareTo(utilizadores22);
        boolean b34 = utilizadores19.equals((java.lang.Object) utilizadores22);
        Utilizadores utilizadores35 = new Utilizadores();
        utilizadores35.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores35.adiciona("", "", "hi!", "", "");
        Ator ator49 = utilizadores35.getAtor("hi!");
        Utilizadores utilizadores50 = new Utilizadores(utilizadores35);
        java.util.List<Motorista> list_motorista51 = utilizadores50.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores52 = new Utilizadores(utilizadores50);
        Utilizadores utilizadores53 = new Utilizadores();
        java.util.List<Cliente> list_cliente54 = utilizadores53.top10ClientesGastadores();
        Utilizadores utilizadores55 = new Utilizadores();
        Utilizadores utilizadores56 = new Utilizadores();
        java.util.List<Cliente> list_cliente57 = utilizadores56.top10ClientesGastadores();
        Utilizadores utilizadores58 = new Utilizadores();
        utilizadores58.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista65 = utilizadores58.top5MotoristasComMaiorDesvio();
        int i66 = utilizadores56.compareTo(utilizadores58);
        int i67 = utilizadores55.compareTo(utilizadores56);
        boolean b68 = utilizadores53.equals((java.lang.Object) utilizadores56);
        java.lang.String str69 = utilizadores53.toString();
        int i70 = utilizadores52.compareTo(utilizadores53);
        Utilizadores utilizadores71 = new Utilizadores();
        utilizadores71.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores71.adiciona("", "", "hi!", "", "");
        Ator ator85 = utilizadores71.getAtor("hi!");
        utilizadores53.adiciona(ator85);
        utilizadores22.adiciona(ator85);
        utilizadores18.adiciona(ator85);
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_cliente4);
        org.junit.Assert.assertNotNull(list_motorista12);
        org.junit.Assert.assertTrue(i13 == (-1));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(b15 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "------- UMeR --------\n" + "'", str16.equals("------- UMeR --------\n"));
        org.junit.Assert.assertNotNull(utilizadores17);
        org.junit.Assert.assertNotNull(utilizadores18);
        org.junit.Assert.assertNotNull(list_cliente20);
        org.junit.Assert.assertNotNull(list_cliente23);
        org.junit.Assert.assertNotNull(list_motorista31);
        org.junit.Assert.assertTrue(i32 == (-1));
        org.junit.Assert.assertTrue(i33 == 0);
        org.junit.Assert.assertTrue(b34 == true);
        org.junit.Assert.assertNotNull(ator49);
        org.junit.Assert.assertNotNull(list_motorista51);
        org.junit.Assert.assertNotNull(list_cliente54);
        org.junit.Assert.assertNotNull(list_cliente57);
        org.junit.Assert.assertNotNull(list_motorista65);
        org.junit.Assert.assertTrue(i66 == (-1));
        org.junit.Assert.assertTrue(i67 == 0);
        org.junit.Assert.assertTrue(b68 == true);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "------- UMeR --------\n" + "'", str69.equals("------- UMeR --------\n"));
        org.junit.Assert.assertTrue(i70 == 1);
        org.junit.Assert.assertNotNull(ator85);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        Utilizadores utilizadores16 = new Utilizadores();
        java.util.List<Cliente> list_cliente17 = utilizadores16.top10ClientesGastadores();
        boolean b19 = utilizadores16.equals((java.lang.Object) 100L);
        Utilizadores utilizadores20 = new Utilizadores();
        utilizadores20.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores20.adiciona("", "", "hi!", "", "");
        Ator ator34 = utilizadores20.getAtor("hi!");
        utilizadores16.adiciona(ator34);
        utilizadores3.adiciona(ator34);
        Utilizadores utilizadores37 = new Utilizadores();
        java.util.List<Cliente> list_cliente38 = utilizadores37.top10ClientesGastadores();
        Utilizadores utilizadores39 = new Utilizadores();
        Utilizadores utilizadores40 = new Utilizadores();
        java.util.List<Cliente> list_cliente41 = utilizadores40.top10ClientesGastadores();
        Utilizadores utilizadores42 = new Utilizadores();
        utilizadores42.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista49 = utilizadores42.top5MotoristasComMaiorDesvio();
        int i50 = utilizadores40.compareTo(utilizadores42);
        int i51 = utilizadores39.compareTo(utilizadores40);
        boolean b52 = utilizadores37.equals((java.lang.Object) utilizadores40);
        Utilizadores utilizadores53 = new Utilizadores();
        utilizadores53.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores53.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista66 = utilizadores53.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator67 = utilizadores53.getUtilizadores();
        java.lang.String str68 = utilizadores53.toString();
        int i69 = utilizadores37.compareTo(utilizadores53);
        Utilizadores utilizadores70 = utilizadores53.clone();
        int i71 = utilizadores3.compareTo(utilizadores70);
        java.util.Map<java.lang.String, Ator> map_str_ator72 = utilizadores70.getUtilizadores();
        java.util.List<Motorista> list_motorista73 = utilizadores70.top5MotoristasComMaiorDesvio();
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_cliente4);
        org.junit.Assert.assertNotNull(list_motorista12);
        org.junit.Assert.assertTrue(i13 == (-1));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(b15 == true);
        org.junit.Assert.assertNotNull(list_cliente17);
        org.junit.Assert.assertTrue(b19 == false);
        org.junit.Assert.assertNotNull(ator34);
        org.junit.Assert.assertNotNull(list_cliente38);
        org.junit.Assert.assertNotNull(list_cliente41);
        org.junit.Assert.assertNotNull(list_motorista49);
        org.junit.Assert.assertTrue(i50 == (-1));
        org.junit.Assert.assertTrue(i51 == 0);
        org.junit.Assert.assertTrue(b52 == true);
        org.junit.Assert.assertNotNull(list_motorista66);
        org.junit.Assert.assertNotNull(map_str_ator67);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str68.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertTrue(i69 == (-1));
        org.junit.Assert.assertNotNull(utilizadores70);
        org.junit.Assert.assertTrue(i71 == 3);
        org.junit.Assert.assertNotNull(map_str_ator72);
        org.junit.Assert.assertNotNull(list_motorista73);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores14 = new Utilizadores(utilizadores0);
        Veiculo veiculo20 = null;
        utilizadores14.adiciona("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", veiculo20);
        utilizadores14.adiciona("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\n", "");
        Utilizadores utilizadores28 = new Utilizadores();
        Utilizadores utilizadores29 = utilizadores28.clone();
        java.util.Map<java.lang.String, Ator> map_str_ator30 = utilizadores29.getUtilizadores();
        Utilizadores utilizadores31 = utilizadores29.clone();
        Utilizadores utilizadores32 = utilizadores29.clone();
        Utilizadores utilizadores33 = utilizadores32.clone();
        Utilizadores utilizadores34 = new Utilizadores();
        utilizadores34.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores34.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista47 = utilizadores34.top5MotoristasComMaiorDesvio();
        utilizadores34.adiciona("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
        java.lang.String str54 = utilizadores34.toString();
        Ator ator56 = utilizadores34.getAtor("");
        boolean b57 = utilizadores32.equals((java.lang.Object) ator56);
        int i58 = utilizadores14.compareTo(utilizadores32);
        org.junit.Assert.assertNotNull(list_motorista13);
        org.junit.Assert.assertNotNull(utilizadores29);
        org.junit.Assert.assertNotNull(map_str_ator30);
        org.junit.Assert.assertNotNull(utilizadores31);
        org.junit.Assert.assertNotNull(utilizadores32);
        org.junit.Assert.assertNotNull(utilizadores33);
        org.junit.Assert.assertNotNull(list_motorista47);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str54.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertNotNull(ator56);
        org.junit.Assert.assertTrue(b57 == false);
        org.junit.Assert.assertTrue(i58 == 1);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator14 = utilizadores0.getUtilizadores();
        java.util.Map<java.lang.String, Ator> map_str_ator15 = utilizadores0.getUtilizadores();
        Utilizadores utilizadores16 = new Utilizadores();
        utilizadores16.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores16.adiciona("", "", "hi!", "", "");
        Ator ator30 = utilizadores16.getAtor("hi!");
        Utilizadores utilizadores31 = new Utilizadores(utilizadores16);
        java.util.List<Motorista> list_motorista32 = utilizadores31.top5MotoristasComMaiorDesvio();
        boolean b34 = utilizadores31.equals((java.lang.Object) 1);
        java.util.List<Motorista> list_motorista35 = utilizadores31.top5MotoristasComMaiorDesvio();
        java.util.List<Motorista> list_motorista36 = utilizadores31.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores37 = utilizadores31.clone();
        java.util.Map<java.lang.String, Ator> map_str_ator38 = utilizadores37.getUtilizadores();
        boolean b39 = utilizadores0.equals((java.lang.Object) utilizadores37);
        org.junit.Assert.assertNotNull(list_motorista13);
        org.junit.Assert.assertNotNull(map_str_ator14);
        org.junit.Assert.assertNotNull(map_str_ator15);
        org.junit.Assert.assertNotNull(ator30);
        org.junit.Assert.assertNotNull(list_motorista32);
        org.junit.Assert.assertTrue(b34 == false);
        org.junit.Assert.assertNotNull(list_motorista35);
        org.junit.Assert.assertNotNull(list_motorista36);
        org.junit.Assert.assertNotNull(utilizadores37);
        org.junit.Assert.assertNotNull(map_str_ator38);
        org.junit.Assert.assertTrue(b39 == true);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        java.util.List<Motorista> list_motorista16 = utilizadores15.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores17 = new Utilizadores(utilizadores15);
        Utilizadores utilizadores18 = new Utilizadores(utilizadores17);
        java.lang.String str19 = utilizadores17.toString();
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(list_motorista16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str19.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        java.util.List<Motorista> list_motorista16 = utilizadores15.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores17 = new Utilizadores(utilizadores15);
        Utilizadores utilizadores18 = new Utilizadores();
        java.util.List<Cliente> list_cliente19 = utilizadores18.top10ClientesGastadores();
        Utilizadores utilizadores20 = new Utilizadores();
        Utilizadores utilizadores21 = new Utilizadores();
        java.util.List<Cliente> list_cliente22 = utilizadores21.top10ClientesGastadores();
        Utilizadores utilizadores23 = new Utilizadores();
        utilizadores23.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista30 = utilizadores23.top5MotoristasComMaiorDesvio();
        int i31 = utilizadores21.compareTo(utilizadores23);
        int i32 = utilizadores20.compareTo(utilizadores21);
        boolean b33 = utilizadores18.equals((java.lang.Object) utilizadores21);
        java.lang.String str34 = utilizadores18.toString();
        int i35 = utilizadores17.compareTo(utilizadores18);
        Utilizadores utilizadores36 = new Utilizadores();
        utilizadores36.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores36.adiciona("", "", "hi!", "", "");
        Ator ator50 = utilizadores36.getAtor("hi!");
        utilizadores18.adiciona(ator50);
        Utilizadores utilizadores52 = utilizadores18.clone();
        Utilizadores utilizadores53 = utilizadores52.clone();
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(list_motorista16);
        org.junit.Assert.assertNotNull(list_cliente19);
        org.junit.Assert.assertNotNull(list_cliente22);
        org.junit.Assert.assertNotNull(list_motorista30);
        org.junit.Assert.assertTrue(i31 == (-1));
        org.junit.Assert.assertTrue(i32 == 0);
        org.junit.Assert.assertTrue(b33 == true);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "------- UMeR --------\n" + "'", str34.equals("------- UMeR --------\n"));
        org.junit.Assert.assertTrue(i35 == 1);
        org.junit.Assert.assertNotNull(ator50);
        org.junit.Assert.assertNotNull(utilizadores52);
        org.junit.Assert.assertNotNull(utilizadores53);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Veiculo veiculo7 = null;
        utilizadores0.adiciona("hi!", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!", veiculo7);
        Veiculo veiculo14 = null;
        utilizadores0.adiciona("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!", "------- UMeR --------\nE-mail: \nNome: ------- UMeR --------\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nData de nascimento: ------- UMeR --------\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: \nPassword: ------- UMeR --------\n\nMorada: \nData de nascimento: ------- UMeR --------\n\nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", veiculo14);
        Utilizadores utilizadores16 = new Utilizadores();
        Utilizadores utilizadores17 = utilizadores16.clone();
        Utilizadores utilizadores18 = new Utilizadores();
        java.util.List<Cliente> list_cliente19 = utilizadores18.top10ClientesGastadores();
        Utilizadores utilizadores20 = new Utilizadores();
        utilizadores20.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista27 = utilizadores20.top5MotoristasComMaiorDesvio();
        int i28 = utilizadores18.compareTo(utilizadores20);
        Utilizadores utilizadores29 = new Utilizadores();
        java.util.List<Motorista> list_motorista30 = utilizadores29.top5MotoristasComMaiorDesvio();
        int i31 = utilizadores20.compareTo(utilizadores29);
        java.util.Map<java.lang.String, Ator> map_str_ator32 = utilizadores20.getUtilizadores();
        boolean b33 = utilizadores17.equals((java.lang.Object) utilizadores20);
        int i34 = utilizadores0.compareTo(utilizadores20);
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(utilizadores17);
        org.junit.Assert.assertNotNull(list_cliente19);
        org.junit.Assert.assertNotNull(list_motorista27);
        org.junit.Assert.assertTrue(i28 == (-1));
        org.junit.Assert.assertNotNull(list_motorista30);
        org.junit.Assert.assertTrue(i31 == 1);
        org.junit.Assert.assertNotNull(map_str_ator32);
        org.junit.Assert.assertTrue(b33 == false);
        org.junit.Assert.assertTrue(i34 == (-59));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        java.util.List<Motorista> list_motorista16 = utilizadores15.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores17 = new Utilizadores(utilizadores15);
        java.lang.String str18 = utilizadores17.toString();
        java.util.Map<java.lang.String, Ator> map_str_ator19 = utilizadores17.getUtilizadores();
        Utilizadores utilizadores20 = new Utilizadores();
        utilizadores20.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores20.adiciona("", "", "hi!", "", "");
        java.lang.String str33 = utilizadores20.toString();
        boolean b35 = utilizadores20.equals((java.lang.Object) (short) 10);
        java.util.Map<java.lang.String, Ator> map_str_ator36 = utilizadores20.getUtilizadores();
        int i37 = utilizadores17.compareTo(utilizadores20);
        utilizadores20.adiciona("------- UMeR --------\nE-mail: \nNome: ------- UMeR --------\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nData de nascimento: ------- UMeR --------\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: \nPassword: ------- UMeR --------\n\nMorada: \nData de nascimento: ------- UMeR --------\n\nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\n", "", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: ------- UMeR --------\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nData de nascimento: ------- UMeR --------\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: \nPassword: ------- UMeR --------\n\nMorada: \nData de nascimento: ------- UMeR --------\n\nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(list_motorista16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str18.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertNotNull(map_str_ator19);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str33.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertTrue(b35 == false);
        org.junit.Assert.assertNotNull(map_str_ator36);
        org.junit.Assert.assertTrue(i37 == 0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        utilizadores0.adiciona("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
        Utilizadores utilizadores20 = new Utilizadores();
        utilizadores20.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores20.adiciona("", "", "hi!", "", "");
        Ator ator34 = utilizadores20.getAtor("hi!");
        Utilizadores utilizadores35 = new Utilizadores(utilizadores20);
        java.util.List<Motorista> list_motorista36 = utilizadores35.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores37 = new Utilizadores(utilizadores35);
        java.lang.String str38 = utilizadores37.toString();
        boolean b39 = utilizadores0.equals((java.lang.Object) utilizadores37);
        java.lang.String str40 = utilizadores37.toString();
        org.junit.Assert.assertNotNull(list_motorista13);
        org.junit.Assert.assertNotNull(ator34);
        org.junit.Assert.assertNotNull(list_motorista36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str38.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertTrue(b39 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str40.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        Utilizadores utilizadores16 = new Utilizadores(utilizadores0);
        Utilizadores utilizadores17 = new Utilizadores();
        utilizadores17.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores17.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista30 = utilizadores17.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator31 = utilizadores17.getUtilizadores();
        Utilizadores utilizadores32 = new Utilizadores(map_str_ator31);
        Utilizadores utilizadores33 = new Utilizadores();
        java.util.List<Cliente> list_cliente34 = utilizadores33.top10ClientesGastadores();
        java.lang.String str35 = utilizadores33.toString();
        Utilizadores utilizadores36 = new Utilizadores();
        java.util.List<Motorista> list_motorista37 = utilizadores36.top5MotoristasComMaiorDesvio();
        boolean b38 = utilizadores33.equals((java.lang.Object) list_motorista37);
        boolean b39 = utilizadores32.equals((java.lang.Object) list_motorista37);
        int i40 = utilizadores0.compareTo(utilizadores32);
        Ator ator42 = utilizadores32.getAtor("");
        Veiculo veiculo48 = null;
        utilizadores32.adiciona("------- UMeR --------\nE-mail: \nNome: ------- UMeR --------\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nData de nascimento: ------- UMeR --------\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: \nPassword: ------- UMeR --------\n\nMorada: \nData de nascimento: ------- UMeR --------\n\nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\n\nNome: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: \nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\n\nNome: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: \nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", veiculo48);
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(list_motorista30);
        org.junit.Assert.assertNotNull(map_str_ator31);
        org.junit.Assert.assertNotNull(list_cliente34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "------- UMeR --------\n" + "'", str35.equals("------- UMeR --------\n"));
        org.junit.Assert.assertNotNull(list_motorista37);
        org.junit.Assert.assertTrue(b38 == false);
        org.junit.Assert.assertTrue(b39 == false);
        org.junit.Assert.assertTrue(i40 == 0);
        org.junit.Assert.assertNotNull(ator42);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores14 = new Utilizadores(utilizadores0);
        java.util.Map<java.lang.String, Ator> map_str_ator15 = utilizadores0.getUtilizadores();
        java.util.Map<java.lang.String, Ator> map_str_ator16 = utilizadores0.getUtilizadores();
        org.junit.Assert.assertNotNull(list_motorista13);
        org.junit.Assert.assertNotNull(map_str_ator15);
        org.junit.Assert.assertNotNull(map_str_ator16);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        Utilizadores utilizadores7 = new Utilizadores();
        utilizadores7.adiciona("hi!", "hi!", "", "", "hi!");
        Utilizadores utilizadores14 = utilizadores7.clone();
        int i15 = utilizadores0.compareTo(utilizadores14);
        Utilizadores utilizadores16 = new Utilizadores(utilizadores14);
        org.junit.Assert.assertNotNull(utilizadores14);
        org.junit.Assert.assertTrue(i15 == 0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        java.util.List<Motorista> list_motorista16 = utilizadores15.top5MotoristasComMaiorDesvio();
        java.lang.String str17 = utilizadores15.toString();
        java.lang.String str18 = utilizadores15.toString();
        Veiculo veiculo24 = null;
        utilizadores15.adiciona("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\n\nNome: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: \nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", veiculo24);
        try {
            Utilizadores utilizadores26 = new Utilizadores(utilizadores15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(list_motorista16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str17.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str18.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        Utilizadores utilizadores0 = new Utilizadores();
        Utilizadores utilizadores1 = utilizadores0.clone();
        java.util.Map<java.lang.String, Ator> map_str_ator2 = utilizadores1.getUtilizadores();
        Utilizadores utilizadores3 = utilizadores1.clone();
        Utilizadores utilizadores4 = utilizadores1.clone();
        Utilizadores utilizadores5 = utilizadores1.clone();
        java.util.List<Motorista> list_motorista6 = utilizadores5.top5MotoristasComMaiorDesvio();
        utilizadores5.adiciona("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
        java.util.List<Cliente> list_cliente13 = utilizadores5.top10ClientesGastadores();
        org.junit.Assert.assertNotNull(utilizadores1);
        org.junit.Assert.assertNotNull(map_str_ator2);
        org.junit.Assert.assertNotNull(utilizadores3);
        org.junit.Assert.assertNotNull(utilizadores4);
        org.junit.Assert.assertNotNull(utilizadores5);
        org.junit.Assert.assertNotNull(list_motorista6);
        org.junit.Assert.assertNotNull(list_cliente13);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        Veiculo veiculo21 = null;
        utilizadores0.adiciona("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "", veiculo21);
        try {
            Utilizadores utilizadores23 = new Utilizadores(utilizadores0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(ator14);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        java.util.List<Cliente> list_cliente16 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores17 = new Utilizadores();
        utilizadores17.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores17.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista30 = utilizadores17.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores31 = new Utilizadores(utilizadores17);
        java.util.Map<java.lang.String, Ator> map_str_ator32 = utilizadores31.getUtilizadores();
        java.util.List<Motorista> list_motorista33 = utilizadores31.top5MotoristasComMaiorDesvio();
        boolean b34 = utilizadores0.equals((java.lang.Object) list_motorista33);
        java.util.List<Cliente> list_cliente35 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores36 = new Utilizadores();
        utilizadores36.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores36.adiciona("", "", "hi!", "", "");
        Ator ator50 = utilizadores36.getAtor("");
        try {
            utilizadores0.adiciona(ator50);
            org.junit.Assert.fail("Expected exception of type EmailAlreadyInUseException");
        } catch (EmailAlreadyInUseException e) {
        }
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(list_cliente16);
        org.junit.Assert.assertNotNull(list_motorista30);
        org.junit.Assert.assertNotNull(map_str_ator32);
        org.junit.Assert.assertNotNull(list_motorista33);
        org.junit.Assert.assertTrue(b34 == false);
        org.junit.Assert.assertNotNull(list_cliente35);
        org.junit.Assert.assertNotNull(ator50);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        java.util.List<Motorista> list_motorista16 = utilizadores15.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores17 = new Utilizadores(utilizadores15);
        java.lang.String str18 = utilizadores17.toString();
        java.util.Map<java.lang.String, Ator> map_str_ator19 = utilizadores17.getUtilizadores();
        java.util.Map<java.lang.String, Ator> map_str_ator20 = utilizadores17.getUtilizadores();
        Utilizadores utilizadores21 = new Utilizadores(map_str_ator20);
        utilizadores21.adiciona("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: ------- UMeR --------\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nData de nascimento: ------- UMeR --------\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: \nPassword: ------- UMeR --------\n\nMorada: \nData de nascimento: ------- UMeR --------\n\nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\n");
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(list_motorista16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str18.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertNotNull(map_str_ator19);
        org.junit.Assert.assertNotNull(map_str_ator20);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        Utilizadores utilizadores16 = utilizadores0.clone();
        utilizadores0.adiciona("------- UMeR --------\n", "", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
        Utilizadores utilizadores23 = new Utilizadores();
        utilizadores23.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores23.adiciona("", "", "hi!", "", "");
        Ator ator37 = utilizadores23.getAtor("hi!");
        Utilizadores utilizadores38 = new Utilizadores(utilizadores23);
        Utilizadores utilizadores39 = utilizadores23.clone();
        Utilizadores utilizadores40 = new Utilizadores(utilizadores39);
        boolean b41 = utilizadores0.equals((java.lang.Object) utilizadores39);
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_cliente4);
        org.junit.Assert.assertNotNull(list_motorista12);
        org.junit.Assert.assertTrue(i13 == (-1));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(b15 == true);
        org.junit.Assert.assertNotNull(utilizadores16);
        org.junit.Assert.assertNotNull(ator37);
        org.junit.Assert.assertNotNull(utilizadores39);
        org.junit.Assert.assertTrue(b41 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores14 = new Utilizadores(utilizadores0);
        java.util.Map<java.lang.String, Ator> map_str_ator15 = utilizadores14.getUtilizadores();
        java.util.List<Cliente> list_cliente16 = utilizadores14.top10ClientesGastadores();
        java.util.List<Cliente> list_cliente17 = utilizadores14.top10ClientesGastadores();
        java.util.List<Cliente> list_cliente18 = utilizadores14.top10ClientesGastadores();
        org.junit.Assert.assertNotNull(list_motorista13);
        org.junit.Assert.assertNotNull(map_str_ator15);
        org.junit.Assert.assertNotNull(list_cliente16);
        org.junit.Assert.assertNotNull(list_cliente17);
        org.junit.Assert.assertNotNull(list_cliente18);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        Utilizadores utilizadores0 = new Utilizadores();
        Utilizadores utilizadores1 = new Utilizadores();
        java.util.List<Cliente> list_cliente2 = utilizadores1.top10ClientesGastadores();
        Utilizadores utilizadores3 = new Utilizadores();
        utilizadores3.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista10 = utilizadores3.top5MotoristasComMaiorDesvio();
        int i11 = utilizadores1.compareTo(utilizadores3);
        int i12 = utilizadores0.compareTo(utilizadores1);
        java.util.Map<java.lang.String, Ator> map_str_ator13 = utilizadores1.getUtilizadores();
        Utilizadores utilizadores14 = new Utilizadores();
        utilizadores14.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores14.adiciona("", "", "hi!", "", "");
        Ator ator28 = utilizadores14.getAtor("hi!");
        utilizadores1.adiciona(ator28);
        Utilizadores utilizadores30 = utilizadores1.clone();
        java.util.List<Cliente> list_cliente31 = utilizadores1.top10ClientesGastadores();
        org.junit.Assert.assertNotNull(list_cliente2);
        org.junit.Assert.assertNotNull(list_motorista10);
        org.junit.Assert.assertTrue(i11 == (-1));
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertNotNull(map_str_ator13);
        org.junit.Assert.assertNotNull(ator28);
        org.junit.Assert.assertNotNull(utilizadores30);
        org.junit.Assert.assertNotNull(list_cliente31);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        java.util.List<Cliente> list_cliente16 = utilizadores0.top10ClientesGastadores();
        Veiculo veiculo22 = null;
        utilizadores0.adiciona("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\n\nNome: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: \nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\n\nNome: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: \nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\n", "hi!", veiculo22);
        Utilizadores utilizadores24 = new Utilizadores();
        java.util.List<Cliente> list_cliente25 = utilizadores24.top10ClientesGastadores();
        boolean b27 = utilizadores24.equals((java.lang.Object) 1L);
        int i28 = utilizadores0.compareTo(utilizadores24);
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(list_cliente16);
        org.junit.Assert.assertNotNull(list_cliente25);
        org.junit.Assert.assertTrue(b27 == false);
        org.junit.Assert.assertTrue(i28 == 1);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        Utilizadores utilizadores16 = new Utilizadores(utilizadores0);
        Utilizadores utilizadores17 = new Utilizadores();
        utilizadores17.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores17.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista30 = utilizadores17.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator31 = utilizadores17.getUtilizadores();
        Utilizadores utilizadores32 = new Utilizadores(map_str_ator31);
        Utilizadores utilizadores33 = new Utilizadores();
        java.util.List<Cliente> list_cliente34 = utilizadores33.top10ClientesGastadores();
        java.lang.String str35 = utilizadores33.toString();
        Utilizadores utilizadores36 = new Utilizadores();
        java.util.List<Motorista> list_motorista37 = utilizadores36.top5MotoristasComMaiorDesvio();
        boolean b38 = utilizadores33.equals((java.lang.Object) list_motorista37);
        boolean b39 = utilizadores32.equals((java.lang.Object) list_motorista37);
        int i40 = utilizadores0.compareTo(utilizadores32);
        java.util.List<Cliente> list_cliente41 = utilizadores32.top10ClientesGastadores();
        java.util.List<Motorista> list_motorista42 = utilizadores32.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores43 = new Utilizadores();
        Utilizadores utilizadores44 = new Utilizadores();
        java.util.List<Cliente> list_cliente45 = utilizadores44.top10ClientesGastadores();
        Utilizadores utilizadores46 = new Utilizadores();
        utilizadores46.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista53 = utilizadores46.top5MotoristasComMaiorDesvio();
        int i54 = utilizadores44.compareTo(utilizadores46);
        int i55 = utilizadores43.compareTo(utilizadores44);
        java.util.Map<java.lang.String, Ator> map_str_ator56 = utilizadores44.getUtilizadores();
        Utilizadores utilizadores57 = new Utilizadores();
        utilizadores57.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores57.adiciona("", "", "hi!", "", "");
        Ator ator71 = utilizadores57.getAtor("hi!");
        utilizadores44.adiciona(ator71);
        try {
            utilizadores32.adiciona(ator71);
            org.junit.Assert.fail("Expected exception of type EmailAlreadyInUseException");
        } catch (EmailAlreadyInUseException e) {
        }
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(list_motorista30);
        org.junit.Assert.assertNotNull(map_str_ator31);
        org.junit.Assert.assertNotNull(list_cliente34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "------- UMeR --------\n" + "'", str35.equals("------- UMeR --------\n"));
        org.junit.Assert.assertNotNull(list_motorista37);
        org.junit.Assert.assertTrue(b38 == false);
        org.junit.Assert.assertTrue(b39 == false);
        org.junit.Assert.assertTrue(i40 == 0);
        org.junit.Assert.assertNotNull(list_cliente41);
        org.junit.Assert.assertNotNull(list_motorista42);
        org.junit.Assert.assertNotNull(list_cliente45);
        org.junit.Assert.assertNotNull(list_motorista53);
        org.junit.Assert.assertTrue(i54 == (-1));
        org.junit.Assert.assertTrue(i55 == 0);
        org.junit.Assert.assertNotNull(map_str_ator56);
        org.junit.Assert.assertNotNull(ator71);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        utilizadores0.adiciona("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
        java.lang.String str20 = utilizadores0.toString();
        Ator ator22 = utilizadores0.getAtor("");
        Utilizadores utilizadores23 = new Utilizadores(utilizadores0);
        Utilizadores utilizadores24 = new Utilizadores();
        utilizadores24.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores24.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista37 = utilizadores24.top5MotoristasComMaiorDesvio();
        utilizadores24.adiciona("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
        Utilizadores utilizadores44 = new Utilizadores();
        utilizadores44.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores44.adiciona("", "", "hi!", "", "");
        Ator ator58 = utilizadores44.getAtor("hi!");
        Utilizadores utilizadores59 = new Utilizadores(utilizadores44);
        java.util.List<Motorista> list_motorista60 = utilizadores59.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores61 = new Utilizadores(utilizadores59);
        java.lang.String str62 = utilizadores61.toString();
        boolean b63 = utilizadores24.equals((java.lang.Object) utilizadores61);
        java.util.Map<java.lang.String, Ator> map_str_ator64 = utilizadores24.getUtilizadores();
        boolean b65 = utilizadores0.equals((java.lang.Object) utilizadores24);
        org.junit.Assert.assertNotNull(list_motorista13);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str20.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertNotNull(ator22);
        org.junit.Assert.assertNotNull(list_motorista37);
        org.junit.Assert.assertNotNull(ator58);
        org.junit.Assert.assertNotNull(list_motorista60);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str62.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertTrue(b63 == false);
        org.junit.Assert.assertNotNull(map_str_ator64);
        org.junit.Assert.assertTrue(b65 == true);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        Utilizadores utilizadores0 = new Utilizadores();
        Utilizadores utilizadores1 = utilizadores0.clone();
        Utilizadores utilizadores2 = new Utilizadores();
        utilizadores2.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores2.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista15 = utilizadores2.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator16 = utilizadores2.getUtilizadores();
        Utilizadores utilizadores17 = new Utilizadores(map_str_ator16);
        Utilizadores utilizadores18 = new Utilizadores();
        java.util.List<Cliente> list_cliente19 = utilizadores18.top10ClientesGastadores();
        java.lang.String str20 = utilizadores18.toString();
        Utilizadores utilizadores21 = new Utilizadores();
        java.util.List<Motorista> list_motorista22 = utilizadores21.top5MotoristasComMaiorDesvio();
        boolean b23 = utilizadores18.equals((java.lang.Object) list_motorista22);
        boolean b24 = utilizadores17.equals((java.lang.Object) list_motorista22);
        boolean b25 = utilizadores1.equals((java.lang.Object) b24);
        java.util.List<Motorista> list_motorista26 = utilizadores1.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores27 = utilizadores1.clone();
        Utilizadores utilizadores28 = new Utilizadores();
        Utilizadores utilizadores29 = utilizadores28.clone();
        java.lang.String str30 = utilizadores29.toString();
        int i31 = utilizadores27.compareTo(utilizadores29);
        org.junit.Assert.assertNotNull(utilizadores1);
        org.junit.Assert.assertNotNull(list_motorista15);
        org.junit.Assert.assertNotNull(map_str_ator16);
        org.junit.Assert.assertNotNull(list_cliente19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "------- UMeR --------\n" + "'", str20.equals("------- UMeR --------\n"));
        org.junit.Assert.assertNotNull(list_motorista22);
        org.junit.Assert.assertTrue(b23 == false);
        org.junit.Assert.assertTrue(b24 == false);
        org.junit.Assert.assertTrue(b25 == false);
        org.junit.Assert.assertNotNull(list_motorista26);
        org.junit.Assert.assertNotNull(utilizadores27);
        org.junit.Assert.assertNotNull(utilizadores29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "------- UMeR --------\n" + "'", str30.equals("------- UMeR --------\n"));
        org.junit.Assert.assertTrue(i31 == 0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores14 = new Utilizadores(utilizadores0);
        java.util.List<Motorista> list_motorista15 = utilizadores14.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores16 = new Utilizadores();
        boolean b18 = utilizadores16.equals((java.lang.Object) (short) 1);
        Utilizadores utilizadores19 = new Utilizadores();
        utilizadores19.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores19.adiciona("", "", "hi!", "", "");
        Ator ator33 = utilizadores19.getAtor("hi!");
        int i34 = utilizadores16.compareTo(utilizadores19);
        boolean b36 = utilizadores19.equals((java.lang.Object) 1.0f);
        int i37 = utilizadores14.compareTo(utilizadores19);
        Utilizadores utilizadores38 = new Utilizadores();
        utilizadores38.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista45 = utilizadores38.top5MotoristasComMaiorDesvio();
        java.lang.String str46 = utilizadores38.toString();
        java.util.List<Cliente> list_cliente47 = utilizadores38.top10ClientesGastadores();
        int i48 = utilizadores14.compareTo(utilizadores38);
        org.junit.Assert.assertNotNull(list_motorista13);
        org.junit.Assert.assertNotNull(list_motorista15);
        org.junit.Assert.assertTrue(b18 == false);
        org.junit.Assert.assertNotNull(ator33);
        org.junit.Assert.assertTrue(i34 == (-1));
        org.junit.Assert.assertTrue(b36 == false);
        org.junit.Assert.assertTrue(i37 == 0);
        org.junit.Assert.assertNotNull(list_motorista45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str46.equals("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertNotNull(list_cliente47);
        org.junit.Assert.assertTrue(i48 == (-3));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        Utilizadores utilizadores0 = new Utilizadores();
        Utilizadores utilizadores1 = new Utilizadores();
        java.util.List<Cliente> list_cliente2 = utilizadores1.top10ClientesGastadores();
        Utilizadores utilizadores3 = new Utilizadores();
        utilizadores3.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista10 = utilizadores3.top5MotoristasComMaiorDesvio();
        int i11 = utilizadores1.compareTo(utilizadores3);
        int i12 = utilizadores0.compareTo(utilizadores1);
        java.util.Map<java.lang.String, Ator> map_str_ator13 = utilizadores1.getUtilizadores();
        java.util.Map<java.lang.String, Ator> map_str_ator14 = utilizadores1.getUtilizadores();
        Utilizadores utilizadores15 = new Utilizadores();
        Utilizadores utilizadores16 = utilizadores15.clone();
        java.lang.String str17 = utilizadores16.toString();
        Utilizadores utilizadores18 = new Utilizadores();
        utilizadores18.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores18.adiciona("", "", "hi!", "", "");
        Ator ator32 = utilizadores18.getAtor("hi!");
        Utilizadores utilizadores33 = new Utilizadores(utilizadores18);
        java.util.List<Motorista> list_motorista34 = utilizadores33.top5MotoristasComMaiorDesvio();
        Ator ator36 = utilizadores33.getAtor("");
        utilizadores16.adiciona(ator36);
        utilizadores1.adiciona(ator36);
        org.junit.Assert.assertNotNull(list_cliente2);
        org.junit.Assert.assertNotNull(list_motorista10);
        org.junit.Assert.assertTrue(i11 == (-1));
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertNotNull(map_str_ator13);
        org.junit.Assert.assertNotNull(map_str_ator14);
        org.junit.Assert.assertNotNull(utilizadores16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "------- UMeR --------\n" + "'", str17.equals("------- UMeR --------\n"));
        org.junit.Assert.assertNotNull(ator32);
        org.junit.Assert.assertNotNull(list_motorista34);
        org.junit.Assert.assertNotNull(ator36);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores14 = new Utilizadores();
        utilizadores14.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores14.adiciona("", "", "hi!", "", "");
        Ator ator28 = utilizadores14.getAtor("hi!");
        Utilizadores utilizadores29 = new Utilizadores(utilizadores14);
        boolean b30 = utilizadores0.equals((java.lang.Object) utilizadores29);
        java.util.List<Cliente> list_cliente31 = utilizadores0.top10ClientesGastadores();
        java.util.List<Motorista> list_motorista32 = utilizadores0.top5MotoristasComMaiorDesvio();
        try {
            Ator ator34 = utilizadores0.getAtor("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
            org.junit.Assert.fail("Expected exception of type EmailDoesNotExistException");
        } catch (EmailDoesNotExistException e) {
        }
        org.junit.Assert.assertNotNull(list_motorista13);
        org.junit.Assert.assertNotNull(ator28);
        org.junit.Assert.assertTrue(b30 == true);
        org.junit.Assert.assertNotNull(list_cliente31);
        org.junit.Assert.assertNotNull(list_motorista32);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Veiculo veiculo7 = null;
        utilizadores0.adiciona("hi!", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!", veiculo7);
        try {
            Utilizadores utilizadores9 = new Utilizadores(utilizadores0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(list_cliente1);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        Utilizadores utilizadores16 = utilizadores0.clone();
        java.util.List<Motorista> list_motorista17 = utilizadores0.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores18 = utilizadores0.clone();
        java.util.List<Cliente> list_cliente19 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores20 = utilizadores0.clone();
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_cliente4);
        org.junit.Assert.assertNotNull(list_motorista12);
        org.junit.Assert.assertTrue(i13 == (-1));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(b15 == true);
        org.junit.Assert.assertNotNull(utilizadores16);
        org.junit.Assert.assertNotNull(list_motorista17);
        org.junit.Assert.assertNotNull(utilizadores18);
        org.junit.Assert.assertNotNull(list_cliente19);
        org.junit.Assert.assertNotNull(utilizadores20);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        Utilizadores utilizadores0 = new Utilizadores();
        Utilizadores utilizadores1 = new Utilizadores();
        java.util.List<Cliente> list_cliente2 = utilizadores1.top10ClientesGastadores();
        Utilizadores utilizadores3 = new Utilizadores();
        utilizadores3.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista10 = utilizadores3.top5MotoristasComMaiorDesvio();
        int i11 = utilizadores1.compareTo(utilizadores3);
        int i12 = utilizadores0.compareTo(utilizadores1);
        Utilizadores utilizadores13 = new Utilizadores();
        utilizadores13.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores13.adiciona("", "", "hi!", "", "");
        Ator ator27 = utilizadores13.getAtor("hi!");
        utilizadores1.adiciona(ator27);
        Utilizadores utilizadores29 = utilizadores1.clone();
        utilizadores29.adiciona("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\n\nNome: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: \nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: ------- UMeR --------\n\nData de nascimento: hi!\nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\n", "------- UMeR --------\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: ------- UMeR --------\n\nData de nascimento: hi!\nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
        org.junit.Assert.assertNotNull(list_cliente2);
        org.junit.Assert.assertNotNull(list_motorista10);
        org.junit.Assert.assertTrue(i11 == (-1));
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertNotNull(ator27);
        org.junit.Assert.assertNotNull(utilizadores29);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        Utilizadores utilizadores16 = utilizadores0.clone();
        Utilizadores utilizadores17 = new Utilizadores();
        utilizadores17.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores17.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista30 = utilizadores17.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores31 = new Utilizadores();
        java.util.List<Cliente> list_cliente32 = utilizadores31.top10ClientesGastadores();
        Utilizadores utilizadores33 = new Utilizadores();
        Utilizadores utilizadores34 = new Utilizadores();
        java.util.List<Cliente> list_cliente35 = utilizadores34.top10ClientesGastadores();
        Utilizadores utilizadores36 = new Utilizadores();
        utilizadores36.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista43 = utilizadores36.top5MotoristasComMaiorDesvio();
        int i44 = utilizadores34.compareTo(utilizadores36);
        int i45 = utilizadores33.compareTo(utilizadores34);
        boolean b46 = utilizadores31.equals((java.lang.Object) utilizadores34);
        java.lang.String str47 = utilizadores31.toString();
        Utilizadores utilizadores48 = utilizadores31.clone();
        int i49 = utilizadores17.compareTo(utilizadores48);
        int i50 = utilizadores0.compareTo(utilizadores48);
        utilizadores48.adiciona("------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\n\nNome: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: \nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\n\nNome: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: \nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "", "");
        Utilizadores utilizadores57 = utilizadores48.clone();
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(utilizadores16);
        org.junit.Assert.assertNotNull(list_motorista30);
        org.junit.Assert.assertNotNull(list_cliente32);
        org.junit.Assert.assertNotNull(list_cliente35);
        org.junit.Assert.assertNotNull(list_motorista43);
        org.junit.Assert.assertTrue(i44 == (-1));
        org.junit.Assert.assertTrue(i45 == 0);
        org.junit.Assert.assertTrue(b46 == true);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "------- UMeR --------\n" + "'", str47.equals("------- UMeR --------\n"));
        org.junit.Assert.assertNotNull(utilizadores48);
        org.junit.Assert.assertTrue(i49 == 1);
        org.junit.Assert.assertTrue(i50 == 1);
        org.junit.Assert.assertNotNull(utilizadores57);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        java.util.List<Motorista> list_motorista16 = utilizadores15.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores17 = utilizadores15.clone();
        Utilizadores utilizadores18 = utilizadores17.clone();
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(list_motorista16);
        org.junit.Assert.assertNotNull(utilizadores17);
        org.junit.Assert.assertNotNull(utilizadores18);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Motorista> list_motorista1 = utilizadores0.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores2 = new Utilizadores();
        boolean b4 = utilizadores2.equals((java.lang.Object) (short) 1);
        boolean b5 = utilizadores0.equals((java.lang.Object) b4);
        java.util.Map<java.lang.String, Ator> map_str_ator6 = utilizadores0.getUtilizadores();
        Utilizadores utilizadores7 = new Utilizadores(map_str_ator6);
        Utilizadores utilizadores8 = utilizadores7.clone();
        java.util.List<Motorista> list_motorista9 = utilizadores8.top5MotoristasComMaiorDesvio();
        org.junit.Assert.assertNotNull(list_motorista1);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(b5 == false);
        org.junit.Assert.assertNotNull(map_str_ator6);
        org.junit.Assert.assertNotNull(utilizadores8);
        org.junit.Assert.assertNotNull(list_motorista9);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        java.util.List<Motorista> list_motorista16 = utilizadores15.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores17 = new Utilizadores(utilizadores15);
        Utilizadores utilizadores18 = new Utilizadores();
        utilizadores18.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores18.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista31 = utilizadores18.top5MotoristasComMaiorDesvio();
        Utilizadores utilizadores32 = new Utilizadores(utilizadores18);
        int i33 = utilizadores17.compareTo(utilizadores18);
        Utilizadores utilizadores34 = new Utilizadores();
        java.util.List<Cliente> list_cliente35 = utilizadores34.top10ClientesGastadores();
        Utilizadores utilizadores36 = new Utilizadores();
        Utilizadores utilizadores37 = new Utilizadores();
        java.util.List<Cliente> list_cliente38 = utilizadores37.top10ClientesGastadores();
        Utilizadores utilizadores39 = new Utilizadores();
        utilizadores39.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista46 = utilizadores39.top5MotoristasComMaiorDesvio();
        int i47 = utilizadores37.compareTo(utilizadores39);
        int i48 = utilizadores36.compareTo(utilizadores37);
        boolean b49 = utilizadores34.equals((java.lang.Object) utilizadores37);
        Utilizadores utilizadores50 = new Utilizadores();
        java.util.List<Cliente> list_cliente51 = utilizadores50.top10ClientesGastadores();
        Utilizadores utilizadores52 = new Utilizadores();
        Utilizadores utilizadores53 = new Utilizadores();
        java.util.List<Cliente> list_cliente54 = utilizadores53.top10ClientesGastadores();
        Utilizadores utilizadores55 = new Utilizadores();
        utilizadores55.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista62 = utilizadores55.top5MotoristasComMaiorDesvio();
        int i63 = utilizadores53.compareTo(utilizadores55);
        int i64 = utilizadores52.compareTo(utilizadores53);
        boolean b65 = utilizadores50.equals((java.lang.Object) utilizadores53);
        Utilizadores utilizadores66 = utilizadores50.clone();
        boolean b67 = utilizadores34.equals((java.lang.Object) utilizadores50);
        Utilizadores utilizadores68 = new Utilizadores();
        utilizadores68.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores68.adiciona("", "", "hi!", "", "");
        Ator ator82 = utilizadores68.getAtor("hi!");
        Utilizadores utilizadores83 = new Utilizadores(utilizadores68);
        Ator ator85 = utilizadores83.getAtor("");
        utilizadores34.adiciona(ator85);
        Utilizadores utilizadores87 = utilizadores34.clone();
        java.lang.String str88 = utilizadores87.toString();
        boolean b89 = utilizadores17.equals((java.lang.Object) str88);
        Utilizadores utilizadores90 = utilizadores17.clone();
        java.util.List<Cliente> list_cliente91 = utilizadores90.top10ClientesGastadores();
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(list_motorista16);
        org.junit.Assert.assertNotNull(list_motorista31);
        org.junit.Assert.assertTrue(i33 == 0);
        org.junit.Assert.assertNotNull(list_cliente35);
        org.junit.Assert.assertNotNull(list_cliente38);
        org.junit.Assert.assertNotNull(list_motorista46);
        org.junit.Assert.assertTrue(i47 == (-1));
        org.junit.Assert.assertTrue(i48 == 0);
        org.junit.Assert.assertTrue(b49 == true);
        org.junit.Assert.assertNotNull(list_cliente51);
        org.junit.Assert.assertNotNull(list_cliente54);
        org.junit.Assert.assertNotNull(list_motorista62);
        org.junit.Assert.assertTrue(i63 == (-1));
        org.junit.Assert.assertTrue(i64 == 0);
        org.junit.Assert.assertTrue(b65 == true);
        org.junit.Assert.assertNotNull(utilizadores66);
        org.junit.Assert.assertTrue(b67 == true);
        org.junit.Assert.assertNotNull(ator82);
        org.junit.Assert.assertNotNull(ator85);
        org.junit.Assert.assertNotNull(utilizadores87);
        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str88.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertTrue(b89 == false);
        org.junit.Assert.assertNotNull(utilizadores90);
        org.junit.Assert.assertNotNull(list_cliente91);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        java.util.List<Cliente> list_cliente16 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores17 = new Utilizadores(utilizadores0);
        Veiculo veiculo23 = null;
        utilizadores0.adiciona("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", veiculo23);
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(list_cliente16);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        utilizadores3.adiciona("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "", "------- UMeR --------\n", "hi!", "");
        java.util.List<Cliente> list_cliente22 = utilizadores3.top10ClientesGastadores();
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_cliente4);
        org.junit.Assert.assertNotNull(list_motorista12);
        org.junit.Assert.assertTrue(i13 == (-1));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(b15 == true);
        org.junit.Assert.assertNotNull(list_cliente22);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator14 = utilizadores0.getUtilizadores();
        Utilizadores utilizadores15 = new Utilizadores(map_str_ator14);
        Utilizadores utilizadores16 = new Utilizadores(map_str_ator14);
        utilizadores16.adiciona("------- UMeR --------\n", "------- UMeR --------\nE-mail: \nNome: ------- UMeR --------\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nData de nascimento: ------- UMeR --------\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: \nPassword: ------- UMeR --------\n\nMorada: \nData de nascimento: ------- UMeR --------\n\nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: ------- UMeR --------\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nData de nascimento: ------- UMeR --------\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: \nPassword: ------- UMeR --------\n\nMorada: \nData de nascimento: ------- UMeR --------\n\nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\n");
        org.junit.Assert.assertNotNull(list_motorista13);
        org.junit.Assert.assertNotNull(map_str_ator14);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        java.util.List<Cliente> list_cliente16 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores17 = utilizadores0.clone();
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(list_cliente16);
        org.junit.Assert.assertNotNull(utilizadores17);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        Ator ator14 = utilizadores0.getAtor("hi!");
        Utilizadores utilizadores15 = new Utilizadores(utilizadores0);
        Utilizadores utilizadores16 = new Utilizadores();
        java.util.List<Cliente> list_cliente17 = utilizadores16.top10ClientesGastadores();
        Utilizadores utilizadores18 = new Utilizadores(utilizadores16);
        boolean b19 = utilizadores15.equals((java.lang.Object) utilizadores16);
        org.junit.Assert.assertNotNull(ator14);
        org.junit.Assert.assertNotNull(list_cliente17);
        org.junit.Assert.assertTrue(b19 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        Utilizadores utilizadores16 = new Utilizadores();
        utilizadores16.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores16.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista29 = utilizadores16.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator30 = utilizadores16.getUtilizadores();
        java.lang.String str31 = utilizadores16.toString();
        int i32 = utilizadores0.compareTo(utilizadores16);
        Utilizadores utilizadores33 = utilizadores16.clone();
        java.lang.String str34 = utilizadores16.toString();
        try {
            Ator ator36 = utilizadores16.getAtor("------- UMeR --------\nE-mail: \nNome: ------- UMeR --------\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nData de nascimento: ------- UMeR --------\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: \nPassword: ------- UMeR --------\n\nMorada: \nData de nascimento: ------- UMeR --------\n\nGrau de cumprimento de horário: 100\nClassificação do motorista: 100\nNúmero de Kms realizados na UMeR até ao momento: 0.00\nO motorista encontra-se em horário de trabalho: false\n\n");
            org.junit.Assert.fail("Expected exception of type EmailDoesNotExistException");
        } catch (EmailDoesNotExistException e) {
        }
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_cliente4);
        org.junit.Assert.assertNotNull(list_motorista12);
        org.junit.Assert.assertTrue(i13 == (-1));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(b15 == true);
        org.junit.Assert.assertNotNull(list_motorista29);
        org.junit.Assert.assertNotNull(map_str_ator30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str31.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertTrue(i32 == (-1));
        org.junit.Assert.assertNotNull(utilizadores33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str34.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator14 = utilizadores0.getUtilizadores();
        Utilizadores utilizadores15 = new Utilizadores(map_str_ator14);
        Utilizadores utilizadores16 = new Utilizadores();
        utilizadores16.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores16.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista29 = utilizadores16.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator30 = utilizadores16.getUtilizadores();
        Utilizadores utilizadores31 = new Utilizadores(map_str_ator30);
        int i32 = utilizadores15.compareTo(utilizadores31);
        Utilizadores utilizadores33 = new Utilizadores();
        utilizadores33.adiciona("hi!", "hi!", "", "", "hi!");
        Utilizadores utilizadores40 = utilizadores33.clone();
        java.util.List<Cliente> list_cliente41 = utilizadores33.top10ClientesGastadores();
        boolean b42 = utilizadores15.equals((java.lang.Object) list_cliente41);
        Ator ator44 = utilizadores15.getAtor("");
        org.junit.Assert.assertNotNull(list_motorista13);
        org.junit.Assert.assertNotNull(map_str_ator14);
        org.junit.Assert.assertNotNull(list_motorista29);
        org.junit.Assert.assertNotNull(map_str_ator30);
        org.junit.Assert.assertTrue(i32 == 0);
        org.junit.Assert.assertNotNull(utilizadores40);
        org.junit.Assert.assertNotNull(list_cliente41);
        org.junit.Assert.assertTrue(b42 == false);
        org.junit.Assert.assertNotNull(ator44);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        Utilizadores utilizadores0 = new Utilizadores();
        boolean b2 = utilizadores0.equals((java.lang.Object) (short) 1);
        Utilizadores utilizadores3 = new Utilizadores();
        utilizadores3.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores3.adiciona("", "", "hi!", "", "");
        Ator ator17 = utilizadores3.getAtor("hi!");
        int i18 = utilizadores0.compareTo(utilizadores3);
        Utilizadores utilizadores19 = new Utilizadores(utilizadores0);
        java.lang.String str20 = utilizadores19.toString();
        org.junit.Assert.assertTrue(b2 == false);
        org.junit.Assert.assertNotNull(ator17);
        org.junit.Assert.assertTrue(i18 == (-1));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "------- UMeR --------\n" + "'", str20.equals("------- UMeR --------\n"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        Utilizadores utilizadores0 = new Utilizadores();
        java.util.List<Cliente> list_cliente1 = utilizadores0.top10ClientesGastadores();
        Utilizadores utilizadores2 = new Utilizadores();
        Utilizadores utilizadores3 = new Utilizadores();
        java.util.List<Cliente> list_cliente4 = utilizadores3.top10ClientesGastadores();
        Utilizadores utilizadores5 = new Utilizadores();
        utilizadores5.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista12 = utilizadores5.top5MotoristasComMaiorDesvio();
        int i13 = utilizadores3.compareTo(utilizadores5);
        int i14 = utilizadores2.compareTo(utilizadores3);
        boolean b15 = utilizadores0.equals((java.lang.Object) utilizadores3);
        Utilizadores utilizadores16 = utilizadores0.clone();
        utilizadores0.adiciona("------- UMeR --------\n", "", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
        utilizadores0.adiciona("", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!", "", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
        org.junit.Assert.assertNotNull(list_cliente1);
        org.junit.Assert.assertNotNull(list_cliente4);
        org.junit.Assert.assertNotNull(list_motorista12);
        org.junit.Assert.assertTrue(i13 == (-1));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(b15 == true);
        org.junit.Assert.assertNotNull(utilizadores16);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        Utilizadores utilizadores0 = new Utilizadores();
        Utilizadores utilizadores1 = new Utilizadores();
        java.util.List<Cliente> list_cliente2 = utilizadores1.top10ClientesGastadores();
        Utilizadores utilizadores3 = new Utilizadores();
        utilizadores3.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista10 = utilizadores3.top5MotoristasComMaiorDesvio();
        int i11 = utilizadores1.compareTo(utilizadores3);
        int i12 = utilizadores0.compareTo(utilizadores1);
        java.util.Map<java.lang.String, Ator> map_str_ator13 = utilizadores1.getUtilizadores();
        Utilizadores utilizadores14 = new Utilizadores();
        utilizadores14.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores14.adiciona("", "", "hi!", "", "");
        Ator ator28 = utilizadores14.getAtor("hi!");
        utilizadores1.adiciona(ator28);
        Utilizadores utilizadores30 = new Utilizadores();
        utilizadores30.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores30.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista43 = utilizadores30.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator44 = utilizadores30.getUtilizadores();
        Utilizadores utilizadores45 = new Utilizadores(map_str_ator44);
        Utilizadores utilizadores46 = new Utilizadores();
        java.util.List<Cliente> list_cliente47 = utilizadores46.top10ClientesGastadores();
        java.lang.String str48 = utilizadores46.toString();
        Utilizadores utilizadores49 = new Utilizadores();
        java.util.List<Motorista> list_motorista50 = utilizadores49.top5MotoristasComMaiorDesvio();
        boolean b51 = utilizadores46.equals((java.lang.Object) list_motorista50);
        boolean b52 = utilizadores45.equals((java.lang.Object) list_motorista50);
        int i53 = utilizadores1.compareTo(utilizadores45);
        Utilizadores utilizadores54 = new Utilizadores(utilizadores45);
        java.util.List<Motorista> list_motorista55 = utilizadores45.top5MotoristasComMaiorDesvio();
        java.util.List<Cliente> list_cliente56 = utilizadores45.top10ClientesGastadores();
        Utilizadores utilizadores57 = new Utilizadores(utilizadores45);
        org.junit.Assert.assertNotNull(list_cliente2);
        org.junit.Assert.assertNotNull(list_motorista10);
        org.junit.Assert.assertTrue(i11 == (-1));
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertNotNull(map_str_ator13);
        org.junit.Assert.assertNotNull(ator28);
        org.junit.Assert.assertNotNull(list_motorista43);
        org.junit.Assert.assertNotNull(map_str_ator44);
        org.junit.Assert.assertNotNull(list_cliente47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "------- UMeR --------\n" + "'", str48.equals("------- UMeR --------\n"));
        org.junit.Assert.assertNotNull(list_motorista50);
        org.junit.Assert.assertTrue(b51 == false);
        org.junit.Assert.assertTrue(b52 == false);
        org.junit.Assert.assertTrue(i53 == 3);
        org.junit.Assert.assertNotNull(list_motorista55);
        org.junit.Assert.assertNotNull(list_cliente56);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        Utilizadores utilizadores0 = new Utilizadores();
        utilizadores0.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores0.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista13 = utilizadores0.top5MotoristasComMaiorDesvio();
        utilizadores0.adiciona("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n", "hi!", "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n");
        java.lang.String str20 = utilizadores0.toString();
        Utilizadores utilizadores21 = new Utilizadores();
        java.util.List<Cliente> list_cliente22 = utilizadores21.top10ClientesGastadores();
        Utilizadores utilizadores23 = new Utilizadores();
        Utilizadores utilizadores24 = new Utilizadores();
        java.util.List<Cliente> list_cliente25 = utilizadores24.top10ClientesGastadores();
        Utilizadores utilizadores26 = new Utilizadores();
        utilizadores26.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista33 = utilizadores26.top5MotoristasComMaiorDesvio();
        int i34 = utilizadores24.compareTo(utilizadores26);
        int i35 = utilizadores23.compareTo(utilizadores24);
        boolean b36 = utilizadores21.equals((java.lang.Object) utilizadores24);
        Utilizadores utilizadores37 = utilizadores21.clone();
        Utilizadores utilizadores38 = new Utilizadores();
        Utilizadores utilizadores39 = new Utilizadores();
        java.util.List<Cliente> list_cliente40 = utilizadores39.top10ClientesGastadores();
        Utilizadores utilizadores41 = new Utilizadores();
        utilizadores41.adiciona("hi!", "hi!", "", "", "hi!");
        java.util.List<Motorista> list_motorista48 = utilizadores41.top5MotoristasComMaiorDesvio();
        int i49 = utilizadores39.compareTo(utilizadores41);
        int i50 = utilizadores38.compareTo(utilizadores39);
        java.util.Map<java.lang.String, Ator> map_str_ator51 = utilizadores39.getUtilizadores();
        Utilizadores utilizadores52 = new Utilizadores();
        utilizadores52.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores52.adiciona("", "", "hi!", "", "");
        Ator ator66 = utilizadores52.getAtor("hi!");
        utilizadores39.adiciona(ator66);
        Utilizadores utilizadores68 = new Utilizadores();
        utilizadores68.adiciona("hi!", "hi!", "", "", "hi!");
        utilizadores68.adiciona("", "", "hi!", "", "");
        java.util.List<Motorista> list_motorista81 = utilizadores68.top5MotoristasComMaiorDesvio();
        java.util.Map<java.lang.String, Ator> map_str_ator82 = utilizadores68.getUtilizadores();
        Utilizadores utilizadores83 = new Utilizadores(map_str_ator82);
        Utilizadores utilizadores84 = new Utilizadores();
        java.util.List<Cliente> list_cliente85 = utilizadores84.top10ClientesGastadores();
        java.lang.String str86 = utilizadores84.toString();
        Utilizadores utilizadores87 = new Utilizadores();
        java.util.List<Motorista> list_motorista88 = utilizadores87.top5MotoristasComMaiorDesvio();
        boolean b89 = utilizadores84.equals((java.lang.Object) list_motorista88);
        boolean b90 = utilizadores83.equals((java.lang.Object) list_motorista88);
        int i91 = utilizadores39.compareTo(utilizadores83);
        Utilizadores utilizadores92 = new Utilizadores(utilizadores83);
        int i93 = utilizadores21.compareTo(utilizadores92);
        int i94 = utilizadores0.compareTo(utilizadores21);
        org.junit.Assert.assertNotNull(list_motorista13);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n" + "'", str20.equals("------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nNome: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nPassword: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n\nMorada: hi!\nData de nascimento: ------- UMeR --------\nE-mail: \nNome: \nPassword: hi!\nMorada: \nData de nascimento: Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\nMontante de dinheiro utilizado no serviço UMeR: 0.00\n\nE-mail: hi!\nNome: hi!\nPassword: \nMorada: \nData de nascimento: hi!Montante de dinheiro utilizado no serviço UMeR: 0.00\n\n"));
        org.junit.Assert.assertNotNull(list_cliente22);
        org.junit.Assert.assertNotNull(list_cliente25);
        org.junit.Assert.assertNotNull(list_motorista33);
        org.junit.Assert.assertTrue(i34 == (-1));
        org.junit.Assert.assertTrue(i35 == 0);
        org.junit.Assert.assertTrue(b36 == true);
        org.junit.Assert.assertNotNull(utilizadores37);
        org.junit.Assert.assertNotNull(list_cliente40);
        org.junit.Assert.assertNotNull(list_motorista48);
        org.junit.Assert.assertTrue(i49 == (-1));
        org.junit.Assert.assertTrue(i50 == 0);
        org.junit.Assert.assertNotNull(map_str_ator51);
        org.junit.Assert.assertNotNull(ator66);
        org.junit.Assert.assertNotNull(list_motorista81);
        org.junit.Assert.assertNotNull(map_str_ator82);
        org.junit.Assert.assertNotNull(list_cliente85);
        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "------- UMeR --------\n" + "'", str86.equals("------- UMeR --------\n"));
        org.junit.Assert.assertNotNull(list_motorista88);
        org.junit.Assert.assertTrue(b89 == false);
        org.junit.Assert.assertTrue(b90 == false);
        org.junit.Assert.assertTrue(i91 == 3);
        org.junit.Assert.assertTrue(i93 == (-1));
        org.junit.Assert.assertTrue(i94 == 1);
    }
}

