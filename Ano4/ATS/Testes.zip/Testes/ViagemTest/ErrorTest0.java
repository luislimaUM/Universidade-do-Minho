import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ErrorTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test001");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        Coordenada coordenada6 = null;
        viagem0.setcfinal(coordenada6);
        org.junit.Assert.assertTrue("Contract failed: compareTo-reflexive on viagem0", viagem0.compareTo(viagem0) == 0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test002");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        double d2 = viagem0.getPreco();
        Viagem viagem3 = new Viagem();
        viagem3.setTempo(10.0d);
        boolean b7 = viagem3.equals((java.lang.Object) 100L);
        Coordenada coordenada8 = viagem3.getcfinal();
        viagem0.setcfinal(coordenada8);
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem3, viagem0, and viagem3", !(viagem3.compareTo(viagem0) > 0 && viagem0.compareTo(viagem3) > 0) || viagem3.compareTo(viagem3) > 0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test003");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        double d2 = viagem0.getPreco();
        Viagem viagem3 = new Viagem();
        viagem3.setTempo(10.0d);
        boolean b7 = viagem3.equals((java.lang.Object) 100L);
        Coordenada coordenada8 = viagem3.getcfinal();
        viagem0.setcinicial(coordenada8);
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem3, viagem0, and viagem3", !(viagem3.compareTo(viagem0) > 0 && viagem0.compareTo(viagem3) > 0) || viagem3.compareTo(viagem3) > 0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test004");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Coordenada coordenada5 = viagem0.getcfinal();
        Viagem viagem6 = new Viagem();
        java.lang.String str7 = viagem6.toString();
        Viagem viagem8 = viagem6.clone();
        Coordenada coordenada9 = viagem6.getcinicial();
        Viagem viagem12 = new Viagem();
        viagem12.setTempo(10.0d);
        boolean b16 = viagem12.equals((java.lang.Object) 100L);
        Viagem viagem17 = new Viagem(viagem12);
        java.util.GregorianCalendar gregorianCalendar18 = viagem12.getData();
        Viagem viagem21 = new Viagem(coordenada5, coordenada9, (double) 0, "hi!", gregorianCalendar18, (double) 100.0f, (double) (short) 10);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem17 and viagem6", Math.signum(viagem17.compareTo(viagem6)) == -Math.signum(viagem6.compareTo(viagem17)));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test005");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Coordenada coordenada6 = viagem5.getcfinal();
        Viagem viagem7 = new Viagem();
        java.lang.String str8 = viagem7.toString();
        Viagem viagem9 = viagem7.clone();
        Coordenada coordenada10 = viagem7.getcinicial();
        Viagem viagem13 = new Viagem();
        viagem13.setTempo(10.0d);
        boolean b17 = viagem13.equals((java.lang.Object) 100L);
        Viagem viagem18 = new Viagem(viagem13);
        java.util.GregorianCalendar gregorianCalendar19 = viagem13.getData();
        Viagem viagem22 = new Viagem(coordenada6, coordenada10, (double) ' ', "hi!", gregorianCalendar19, (double) 100.0f, (double) 100L);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem5 and viagem7", Math.signum(viagem5.compareTo(viagem7)) == -Math.signum(viagem7.compareTo(viagem5)));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test006");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Coordenada coordenada9 = viagem0.getcfinal();
        Viagem viagem10 = new Viagem();
        java.lang.String str11 = viagem10.toString();
        Viagem viagem12 = viagem10.clone();
        java.lang.String str13 = viagem12.getMail();
        Viagem viagem14 = new Viagem();
        java.lang.String str15 = viagem14.toString();
        Viagem viagem16 = viagem14.clone();
        Coordenada coordenada17 = viagem14.getcinicial();
        viagem12.setcfinal(coordenada17);
        Viagem viagem21 = new Viagem();
        viagem21.setTempo(10.0d);
        boolean b25 = viagem21.equals((java.lang.Object) 100L);
        double d26 = viagem21.getTempo();
        viagem21.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str29 = viagem21.toString();
        viagem21.setMail("");
        double d32 = viagem21.getDesvio();
        java.util.GregorianCalendar gregorianCalendar33 = viagem21.getData();
        Viagem viagem36 = new Viagem(coordenada9, coordenada17, (double) 10, "", gregorianCalendar33, (double) ' ', (double) (short) 0);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem0 and viagem10", Math.signum(viagem0.compareTo(viagem10)) == -Math.signum(viagem10.compareTo(viagem0)));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test007");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        viagem0.setMail("hi!");
        Coordenada coordenada4 = viagem0.getcfinal();
        Viagem viagem5 = new Viagem();
        java.lang.String str6 = viagem5.toString();
        viagem5.setMail("hi!");
        Coordenada coordenada9 = viagem5.getcfinal();
        Viagem viagem12 = new Viagem();
        viagem12.setTempo(10.0d);
        boolean b16 = viagem12.equals((java.lang.Object) 100L);
        Viagem viagem17 = new Viagem(viagem12);
        java.util.GregorianCalendar gregorianCalendar18 = viagem12.getData();
        Viagem viagem21 = new Viagem(coordenada4, coordenada9, (double) (short) 100, "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00", gregorianCalendar18, (double) (short) 0, (double) (-1.0f));
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem12 and viagem0", Math.signum(viagem12.compareTo(viagem0)) == -Math.signum(viagem0.compareTo(viagem12)));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test008");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        java.lang.String str3 = viagem2.getMail();
        Viagem viagem4 = new Viagem();
        viagem4.setTempo(10.0d);
        boolean b8 = viagem4.equals((java.lang.Object) 100L);
        Viagem viagem9 = viagem4.clone();
        Coordenada coordenada10 = viagem9.getcfinal();
        boolean b11 = viagem2.equals((java.lang.Object) viagem9);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem0 and viagem4", Math.signum(viagem0.compareTo(viagem4)) == -Math.signum(viagem4.compareTo(viagem0)));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test009");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        double d2 = viagem0.getPreco();
        Coordenada coordenada3 = viagem0.getcfinal();
        viagem0.setMail("hi!");
        Viagem viagem6 = new Viagem();
        java.lang.String str7 = viagem6.toString();
        Viagem viagem8 = viagem6.clone();
        java.lang.String str9 = viagem8.getMail();
        Viagem viagem10 = new Viagem();
        java.lang.String str11 = viagem10.toString();
        Viagem viagem12 = viagem10.clone();
        Coordenada coordenada13 = viagem10.getcinicial();
        viagem8.setcfinal(coordenada13);
        viagem0.setcinicial(coordenada13);
        Viagem viagem16 = new Viagem();
        viagem16.setTempo(10.0d);
        boolean b20 = viagem16.equals((java.lang.Object) 100L);
        double d21 = viagem16.getTempo();
        viagem16.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str24 = viagem16.toString();
        viagem16.setMail("");
        boolean b27 = viagem0.equals((java.lang.Object) viagem16);
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem10, viagem16, and viagem10", !(viagem10.compareTo(viagem16) > 0 && viagem16.compareTo(viagem10) > 0) || viagem10.compareTo(viagem10) > 0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test010");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = new Viagem(viagem0);
        java.util.GregorianCalendar gregorianCalendar6 = viagem0.getData();
        java.lang.String str7 = viagem0.toString();
        java.lang.String str8 = viagem0.getMail();
        Viagem viagem9 = new Viagem();
        java.lang.String str10 = viagem9.toString();
        double d11 = viagem9.getPreco();
        Coordenada coordenada12 = viagem9.getcfinal();
        viagem9.setMail("hi!");
        Viagem viagem15 = new Viagem();
        java.lang.String str16 = viagem15.toString();
        Viagem viagem17 = viagem15.clone();
        java.lang.String str18 = viagem17.getMail();
        Viagem viagem19 = new Viagem();
        java.lang.String str20 = viagem19.toString();
        Viagem viagem21 = viagem19.clone();
        Coordenada coordenada22 = viagem19.getcinicial();
        viagem17.setcfinal(coordenada22);
        viagem9.setcinicial(coordenada22);
        viagem0.setcfinal(coordenada22);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem21 and viagem5", Math.signum(viagem21.compareTo(viagem5)) == -Math.signum(viagem5.compareTo(viagem21)));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test011");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        double d2 = viagem0.getPreco();
        Viagem viagem3 = new Viagem();
        viagem3.setTempo(10.0d);
        boolean b7 = viagem3.equals((java.lang.Object) 100L);
        Viagem viagem8 = viagem3.clone();
        Coordenada coordenada9 = viagem8.getcfinal();
        viagem0.setcfinal(coordenada9);
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem8, viagem0, and viagem8", !(viagem8.compareTo(viagem0) > 0 && viagem0.compareTo(viagem8) > 0) || viagem8.compareTo(viagem8) > 0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test012");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Viagem viagem6 = new Viagem(viagem0);
        Viagem viagem7 = new Viagem();
        viagem7.setTempo(10.0d);
        boolean b11 = viagem7.equals((java.lang.Object) 100L);
        Viagem viagem12 = viagem7.clone();
        Viagem viagem13 = new Viagem(viagem7);
        int i14 = viagem0.compareTo(viagem7);
        Viagem viagem15 = new Viagem();
        java.lang.String str16 = viagem15.toString();
        Viagem viagem17 = viagem15.clone();
        double d18 = viagem17.getDesvio();
        int i19 = viagem7.compareTo(viagem17);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem12 and viagem15", Math.signum(viagem12.compareTo(viagem15)) == -Math.signum(viagem15.compareTo(viagem12)));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test013");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Coordenada coordenada5 = viagem0.getcfinal();
        Viagem viagem6 = new Viagem();
        java.lang.String str7 = viagem6.toString();
        Viagem viagem8 = viagem6.clone();
        Coordenada coordenada9 = viagem6.getcfinal();
        viagem0.setcinicial(coordenada9);
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem6, viagem0, and viagem6", !(viagem6.compareTo(viagem0) > 0 && viagem0.compareTo(viagem6) > 0) || viagem6.compareTo(viagem6) > 0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test014");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        Coordenada coordenada3 = viagem0.getcinicial();
        Viagem viagem4 = new Viagem(viagem0);
        viagem4.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem7 = new Viagem();
        viagem7.setTempo(10.0d);
        boolean b11 = viagem7.equals((java.lang.Object) 100L);
        Viagem viagem12 = new Viagem(viagem7);
        java.util.GregorianCalendar gregorianCalendar13 = viagem7.getData();
        java.lang.String str14 = viagem7.toString();
        java.lang.String str15 = viagem7.getMail();
        int i16 = viagem4.compareTo(viagem7);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem0 and viagem12", Math.signum(viagem0.compareTo(viagem12)) == -Math.signum(viagem12.compareTo(viagem0)));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test015");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Coordenada coordenada5 = viagem0.getcfinal();
        double d6 = viagem0.getTempo();
        Viagem viagem7 = new Viagem(viagem0);
        Viagem viagem8 = new Viagem();
        java.lang.String str9 = viagem8.toString();
        Viagem viagem10 = new Viagem(viagem8);
        Coordenada coordenada11 = viagem10.getcinicial();
        Viagem viagem12 = new Viagem();
        java.lang.String str13 = viagem12.toString();
        Viagem viagem14 = viagem12.clone();
        java.lang.String str15 = viagem14.getMail();
        Viagem viagem16 = new Viagem();
        java.lang.String str17 = viagem16.toString();
        Viagem viagem18 = viagem16.clone();
        Coordenada coordenada19 = viagem16.getcinicial();
        viagem14.setcfinal(coordenada19);
        viagem10.setcfinal(coordenada19);
        viagem7.setcfinal(coordenada19);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem18 and viagem0", Math.signum(viagem18.compareTo(viagem0)) == -Math.signum(viagem0.compareTo(viagem18)));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test016");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = new Viagem(viagem0);
        Coordenada coordenada3 = viagem2.getcinicial();
        Coordenada coordenada4 = viagem2.getcfinal();
        Viagem viagem5 = new Viagem();
        java.lang.String str6 = viagem5.toString();
        Viagem viagem7 = viagem5.clone();
        Coordenada coordenada8 = viagem5.getcinicial();
        Viagem viagem11 = new Viagem();
        viagem11.setTempo(10.0d);
        boolean b15 = viagem11.equals((java.lang.Object) 100L);
        Viagem viagem16 = viagem11.clone();
        Viagem viagem17 = new Viagem(viagem11);
        Viagem viagem18 = new Viagem();
        viagem18.setTempo(10.0d);
        boolean b22 = viagem18.equals((java.lang.Object) 100L);
        Viagem viagem23 = viagem18.clone();
        Viagem viagem24 = new Viagem(viagem18);
        int i25 = viagem11.compareTo(viagem18);
        viagem18.setMail("");
        java.util.GregorianCalendar gregorianCalendar28 = viagem18.getData();
        Viagem viagem31 = new Viagem(coordenada4, coordenada8, (double) (byte) 1, "hi!", gregorianCalendar28, 0.0d, (double) (byte) 1);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem7 and viagem17", Math.signum(viagem7.compareTo(viagem17)) == -Math.signum(viagem17.compareTo(viagem7)));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test017");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = new Viagem(viagem0);
        Coordenada coordenada3 = viagem2.getcinicial();
        Viagem viagem4 = new Viagem();
        java.lang.String str5 = viagem4.toString();
        Viagem viagem6 = viagem4.clone();
        java.lang.String str7 = viagem6.getMail();
        Viagem viagem8 = new Viagem();
        java.lang.String str9 = viagem8.toString();
        Viagem viagem10 = viagem8.clone();
        Coordenada coordenada11 = viagem8.getcinicial();
        viagem6.setcfinal(coordenada11);
        viagem2.setcfinal(coordenada11);
        Viagem viagem14 = new Viagem();
        viagem14.setTempo(10.0d);
        boolean b18 = viagem14.equals((java.lang.Object) 100L);
        Viagem viagem19 = viagem14.clone();
        Coordenada coordenada20 = viagem19.getcfinal();
        Viagem viagem23 = new Viagem();
        viagem23.setTempo(10.0d);
        boolean b27 = viagem23.equals((java.lang.Object) 100L);
        double d28 = viagem23.getTempo();
        viagem23.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str31 = viagem23.toString();
        viagem23.setMail("");
        double d34 = viagem23.getDesvio();
        java.util.GregorianCalendar gregorianCalendar35 = viagem23.getData();
        Viagem viagem38 = new Viagem(coordenada11, coordenada20, (double) (short) 10, "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00", gregorianCalendar35, (double) (byte) 100, 0.0d);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem0 and viagem19", Math.signum(viagem0.compareTo(viagem19)) == -Math.signum(viagem19.compareTo(viagem0)));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test018");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Coordenada coordenada9 = viagem0.getcfinal();
        Viagem viagem10 = new Viagem();
        viagem10.setTempo(10.0d);
        boolean b14 = viagem10.equals((java.lang.Object) 100L);
        Coordenada coordenada15 = viagem10.getcfinal();
        double d16 = viagem10.getTempo();
        Viagem viagem17 = new Viagem(viagem10);
        int i18 = viagem0.compareTo(viagem10);
        double d19 = viagem0.getPreco();
        Viagem viagem20 = new Viagem();
        java.lang.String str21 = viagem20.toString();
        Viagem viagem22 = new Viagem(viagem20);
        Coordenada coordenada23 = viagem22.getcinicial();
        Coordenada coordenada24 = viagem22.getcfinal();
        viagem0.setcinicial(coordenada24);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem20 and viagem10", Math.signum(viagem20.compareTo(viagem10)) == -Math.signum(viagem10.compareTo(viagem20)));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test019");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Viagem viagem9 = viagem8.clone();
        viagem9.setTempo((double) (byte) -1);
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem8, viagem9, and viagem8", !(viagem8.compareTo(viagem9) > 0 && viagem9.compareTo(viagem8) > 0) || viagem8.compareTo(viagem8) > 0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test020");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Viagem viagem9 = viagem8.clone();
        Viagem viagem10 = new Viagem();
        java.lang.String str11 = viagem10.toString();
        double d12 = viagem10.getPreco();
        Coordenada coordenada13 = viagem10.getcfinal();
        viagem10.setMail("hi!");
        Viagem viagem16 = new Viagem();
        java.lang.String str17 = viagem16.toString();
        Viagem viagem18 = viagem16.clone();
        java.lang.String str19 = viagem18.getMail();
        Viagem viagem20 = new Viagem();
        java.lang.String str21 = viagem20.toString();
        Viagem viagem22 = viagem20.clone();
        Coordenada coordenada23 = viagem20.getcinicial();
        viagem18.setcfinal(coordenada23);
        viagem10.setcinicial(coordenada23);
        viagem9.setcfinal(coordenada23);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem0 and viagem22", Math.signum(viagem0.compareTo(viagem22)) == -Math.signum(viagem22.compareTo(viagem0)));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test021");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Viagem viagem6 = new Viagem(viagem0);
        Viagem viagem7 = new Viagem();
        viagem7.setTempo(10.0d);
        boolean b11 = viagem7.equals((java.lang.Object) 100L);
        Viagem viagem12 = viagem7.clone();
        Viagem viagem13 = new Viagem(viagem7);
        int i14 = viagem0.compareTo(viagem7);
        double d15 = viagem7.getTempo();
        Viagem viagem16 = viagem7.clone();
        Viagem viagem17 = new Viagem();
        java.lang.String str18 = viagem17.toString();
        Viagem viagem19 = new Viagem(viagem17);
        Coordenada coordenada20 = viagem19.getcinicial();
        viagem16.setcinicial(coordenada20);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem5 and viagem17", Math.signum(viagem5.compareTo(viagem17)) == -Math.signum(viagem17.compareTo(viagem5)));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test022");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Coordenada coordenada9 = viagem0.getcfinal();
        Viagem viagem10 = new Viagem();
        viagem10.setTempo(10.0d);
        boolean b14 = viagem10.equals((java.lang.Object) 100L);
        Coordenada coordenada15 = viagem10.getcfinal();
        double d16 = viagem10.getTempo();
        Viagem viagem17 = new Viagem(viagem10);
        int i18 = viagem0.compareTo(viagem10);
        Viagem viagem19 = new Viagem();
        java.lang.String str20 = viagem19.toString();
        Viagem viagem21 = viagem19.clone();
        Coordenada coordenada22 = viagem19.getcinicial();
        Viagem viagem23 = viagem19.clone();
        boolean b24 = viagem0.equals((java.lang.Object) viagem23);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem17 and viagem21", Math.signum(viagem17.compareTo(viagem21)) == -Math.signum(viagem21.compareTo(viagem17)));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test023");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = new Viagem(viagem0);
        Viagem viagem3 = new Viagem();
        viagem3.setTempo(10.0d);
        boolean b7 = viagem3.equals((java.lang.Object) 100L);
        Viagem viagem8 = new Viagem(viagem3);
        java.util.GregorianCalendar gregorianCalendar9 = viagem3.getData();
        java.lang.String str10 = viagem3.toString();
        double d11 = viagem3.getPreco();
        Coordenada coordenada12 = viagem3.getcinicial();
        viagem2.setcinicial(coordenada12);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem0 and viagem3", Math.signum(viagem0.compareTo(viagem3)) == -Math.signum(viagem3.compareTo(viagem0)));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test024");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        java.lang.String str3 = viagem2.getMail();
        Viagem viagem4 = new Viagem();
        java.lang.String str5 = viagem4.toString();
        Viagem viagem6 = viagem4.clone();
        Coordenada coordenada7 = viagem4.getcinicial();
        viagem2.setcfinal(coordenada7);
        double d9 = viagem2.getDesvio();
        Viagem viagem10 = new Viagem();
        java.lang.String str11 = viagem10.toString();
        Viagem viagem12 = viagem10.clone();
        Coordenada coordenada13 = viagem10.getcinicial();
        java.lang.Object obj14 = null;
        boolean b15 = viagem10.equals(obj14);
        int i16 = viagem2.compareTo(viagem10);
        Viagem viagem17 = viagem10.clone();
        Viagem viagem18 = viagem17.clone();
        Viagem viagem19 = new Viagem();
        viagem19.setTempo(10.0d);
        boolean b23 = viagem19.equals((java.lang.Object) 100L);
        double d24 = viagem19.getTempo();
        Viagem viagem25 = new Viagem();
        viagem25.setTempo(10.0d);
        boolean b29 = viagem25.equals((java.lang.Object) 100L);
        double d30 = viagem25.getTempo();
        viagem25.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Coordenada coordenada33 = viagem25.getcfinal();
        viagem19.setcinicial(coordenada33);
        viagem18.setcfinal(coordenada33);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem12 and viagem19", Math.signum(viagem12.compareTo(viagem19)) == -Math.signum(viagem19.compareTo(viagem12)));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test025");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem();
        viagem8.setTempo(10.0d);
        boolean b12 = viagem8.equals((java.lang.Object) 100L);
        double d13 = viagem8.getTempo();
        viagem8.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str16 = viagem8.toString();
        viagem8.setMail("");
        double d19 = viagem8.getDesvio();
        int i20 = viagem0.compareTo(viagem8);
        double d21 = viagem0.getPreco();
        Viagem viagem22 = new Viagem();
        java.lang.String str23 = viagem22.toString();
        double d24 = viagem22.getPreco();
        Coordenada coordenada25 = viagem22.getcfinal();
        viagem22.setMail("hi!");
        Viagem viagem28 = new Viagem();
        java.lang.String str29 = viagem28.toString();
        Viagem viagem30 = viagem28.clone();
        java.lang.String str31 = viagem30.getMail();
        Viagem viagem32 = new Viagem();
        java.lang.String str33 = viagem32.toString();
        Viagem viagem34 = viagem32.clone();
        Coordenada coordenada35 = viagem32.getcinicial();
        viagem30.setcfinal(coordenada35);
        viagem22.setcinicial(coordenada35);
        viagem22.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        int i40 = viagem0.compareTo(viagem22);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem28 and viagem8", Math.signum(viagem28.compareTo(viagem8)) == -Math.signum(viagem8.compareTo(viagem28)));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test026");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        viagem0.setMail("hi!");
        Coordenada coordenada4 = viagem0.getcfinal();
        Viagem viagem5 = new Viagem();
        viagem5.setTempo(10.0d);
        boolean b9 = viagem5.equals((java.lang.Object) 100L);
        double d10 = viagem5.getTempo();
        viagem5.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem13 = new Viagem(viagem5);
        Viagem viagem14 = viagem13.clone();
        Coordenada coordenada15 = viagem14.getcfinal();
        Viagem viagem18 = new Viagem();
        viagem18.setTempo(10.0d);
        boolean b22 = viagem18.equals((java.lang.Object) 100L);
        Viagem viagem23 = new Viagem(viagem18);
        java.util.GregorianCalendar gregorianCalendar24 = viagem18.getData();
        Viagem viagem27 = new Viagem(coordenada4, coordenada15, (double) '#', "", gregorianCalendar24, (double) 1.0f, (double) 1.0f);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem18 and viagem0", Math.signum(viagem18.compareTo(viagem0)) == -Math.signum(viagem0.compareTo(viagem18)));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test027");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = new Viagem(viagem0);
        Coordenada coordenada3 = viagem2.getcinicial();
        Viagem viagem4 = new Viagem();
        java.lang.String str5 = viagem4.toString();
        Viagem viagem6 = viagem4.clone();
        Coordenada coordenada7 = viagem4.getcfinal();
        Viagem viagem10 = new Viagem();
        java.lang.String str11 = viagem10.toString();
        Viagem viagem12 = viagem10.clone();
        Coordenada coordenada13 = viagem10.getcinicial();
        java.util.GregorianCalendar gregorianCalendar14 = viagem10.getData();
        Viagem viagem17 = new Viagem(coordenada3, coordenada7, (double) (short) 100, "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00", gregorianCalendar14, (double) (byte) 0, (double) (short) 100);
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem4, viagem17, and viagem4", !(viagem4.compareTo(viagem17) > 0 && viagem17.compareTo(viagem4) > 0) || viagem4.compareTo(viagem4) > 0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test028");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        java.lang.String str3 = viagem2.getMail();
        Viagem viagem4 = new Viagem();
        java.lang.String str5 = viagem4.toString();
        Viagem viagem6 = viagem4.clone();
        Coordenada coordenada7 = viagem4.getcinicial();
        viagem2.setcfinal(coordenada7);
        double d9 = viagem2.getDesvio();
        Viagem viagem10 = new Viagem();
        java.lang.String str11 = viagem10.toString();
        Viagem viagem12 = viagem10.clone();
        Coordenada coordenada13 = viagem10.getcinicial();
        java.lang.Object obj14 = null;
        boolean b15 = viagem10.equals(obj14);
        int i16 = viagem2.compareTo(viagem10);
        double d17 = viagem10.getDesvio();
        Viagem viagem18 = new Viagem();
        viagem18.setTempo(10.0d);
        boolean b22 = viagem18.equals((java.lang.Object) 100L);
        double d23 = viagem18.getTempo();
        viagem18.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Coordenada coordenada26 = viagem18.getcfinal();
        int i27 = viagem10.compareTo(viagem18);
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem6, viagem18, and viagem6", !(viagem6.compareTo(viagem18) > 0 && viagem18.compareTo(viagem6) > 0) || viagem6.compareTo(viagem6) > 0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test029");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        java.lang.String str3 = viagem0.getMail();
        Viagem viagem4 = new Viagem();
        viagem4.setTempo(10.0d);
        boolean b8 = viagem4.equals((java.lang.Object) 100L);
        double d9 = viagem4.getTempo();
        viagem4.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem12 = new Viagem(viagem4);
        java.lang.String str13 = viagem4.toString();
        java.lang.String str14 = viagem4.toString();
        int i15 = viagem0.compareTo(viagem4);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem12 and viagem2", Math.signum(viagem12.compareTo(viagem2)) == -Math.signum(viagem2.compareTo(viagem12)));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test030");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Coordenada coordenada9 = viagem0.getcfinal();
        Viagem viagem10 = new Viagem();
        viagem10.setTempo(10.0d);
        boolean b14 = viagem10.equals((java.lang.Object) 100L);
        java.util.GregorianCalendar gregorianCalendar15 = viagem10.getData();
        Coordenada coordenada16 = viagem10.getcinicial();
        Viagem viagem19 = new Viagem();
        viagem19.setTempo(10.0d);
        boolean b23 = viagem19.equals((java.lang.Object) 100L);
        double d24 = viagem19.getTempo();
        viagem19.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str27 = viagem19.toString();
        viagem19.setMail("");
        double d30 = viagem19.getDesvio();
        java.util.GregorianCalendar gregorianCalendar31 = viagem19.getData();
        Viagem viagem34 = new Viagem(coordenada9, coordenada16, 1.0d, "", gregorianCalendar31, (double) (byte) -1, 1.0d);
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem8, viagem34, and viagem8", !(viagem8.compareTo(viagem34) > 0 && viagem34.compareTo(viagem8) > 0) || viagem8.compareTo(viagem8) > 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test031");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        viagem0.setMail("hi!");
        Coordenada coordenada4 = viagem0.getcfinal();
        viagem0.setTempo(0.0d);
        java.lang.String str7 = viagem0.toString();
        Viagem viagem8 = new Viagem();
        viagem8.setTempo(10.0d);
        boolean b12 = viagem8.equals((java.lang.Object) 100L);
        Viagem viagem13 = new Viagem(viagem8);
        int i14 = viagem0.compareTo(viagem13);
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem8, viagem0, and viagem8", !(viagem8.compareTo(viagem0) > 0 && viagem0.compareTo(viagem8) > 0) || viagem8.compareTo(viagem8) > 0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test032");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        Coordenada coordenada3 = viagem0.getcfinal();
        Viagem viagem4 = new Viagem();
        viagem4.setTempo(10.0d);
        boolean b8 = viagem4.equals((java.lang.Object) 100L);
        double d9 = viagem4.getTempo();
        viagem4.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str12 = viagem4.toString();
        viagem4.setMail("");
        Coordenada coordenada15 = viagem4.getcinicial();
        viagem0.setcfinal(coordenada15);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem2 and viagem4", Math.signum(viagem2.compareTo(viagem4)) == -Math.signum(viagem4.compareTo(viagem2)));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test033");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        Coordenada coordenada3 = viagem0.getcinicial();
        Viagem viagem4 = viagem0.clone();
        Viagem viagem5 = new Viagem();
        viagem5.setTempo(10.0d);
        boolean b9 = viagem5.equals((java.lang.Object) 100L);
        double d10 = viagem5.getTempo();
        viagem5.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str13 = viagem5.toString();
        viagem5.setMail("");
        Coordenada coordenada16 = viagem5.getcinicial();
        int i17 = viagem0.compareTo(viagem5);
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem2, viagem5, and viagem2", !(viagem2.compareTo(viagem5) > 0 && viagem5.compareTo(viagem2) > 0) || viagem2.compareTo(viagem2) > 0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test034");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = new Viagem(viagem0);
        Coordenada coordenada6 = viagem0.getcinicial();
        Viagem viagem7 = new Viagem();
        viagem7.setTempo(10.0d);
        boolean b11 = viagem7.equals((java.lang.Object) 100L);
        Coordenada coordenada12 = viagem7.getcfinal();
        Viagem viagem15 = new Viagem();
        viagem15.setTempo(10.0d);
        boolean b19 = viagem15.equals((java.lang.Object) 100L);
        Viagem viagem20 = viagem15.clone();
        Viagem viagem21 = new Viagem(viagem15);
        Viagem viagem22 = new Viagem();
        viagem22.setTempo(10.0d);
        boolean b26 = viagem22.equals((java.lang.Object) 100L);
        Viagem viagem27 = viagem22.clone();
        Viagem viagem28 = new Viagem(viagem22);
        int i29 = viagem15.compareTo(viagem22);
        viagem22.setMail("");
        java.util.GregorianCalendar gregorianCalendar32 = viagem22.getData();
        Viagem viagem35 = new Viagem(coordenada6, coordenada12, (double) 0L, "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00", gregorianCalendar32, (double) 0.0f, (double) (-1L));
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem22, viagem35, and viagem22", !(viagem22.compareTo(viagem35) > 0 && viagem35.compareTo(viagem22) > 0) || viagem22.compareTo(viagem22) > 0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test035");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        Coordenada coordenada3 = viagem0.getcfinal();
        Viagem viagem4 = new Viagem();
        java.lang.String str5 = viagem4.toString();
        Viagem viagem6 = viagem4.clone();
        Coordenada coordenada7 = viagem4.getcinicial();
        Viagem viagem10 = new Viagem();
        viagem10.setTempo(10.0d);
        boolean b14 = viagem10.equals((java.lang.Object) 100L);
        java.util.GregorianCalendar gregorianCalendar15 = viagem10.getData();
        Viagem viagem18 = new Viagem(coordenada3, coordenada7, (-1.0d), "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00", gregorianCalendar15, (double) 0.0f, (double) '4');
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem0 and viagem6", Math.signum(viagem0.compareTo(viagem6)) == -Math.signum(viagem6.compareTo(viagem0)));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test036");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = new Viagem(viagem0);
        Coordenada coordenada3 = viagem2.getcinicial();
        Viagem viagem4 = new Viagem();
        java.lang.String str5 = viagem4.toString();
        Viagem viagem6 = viagem4.clone();
        Coordenada coordenada7 = viagem4.getcinicial();
        Viagem viagem8 = new Viagem(viagem4);
        viagem8.setTempo((double) (short) 0);
        Viagem viagem11 = new Viagem();
        java.lang.String str12 = viagem11.toString();
        Viagem viagem13 = viagem11.clone();
        Coordenada coordenada14 = viagem11.getcinicial();
        boolean b15 = viagem8.equals((java.lang.Object) coordenada14);
        Viagem viagem18 = new Viagem();
        java.lang.String str19 = viagem18.toString();
        Viagem viagem20 = new Viagem(viagem18);
        Coordenada coordenada21 = viagem20.getcinicial();
        Coordenada coordenada22 = viagem20.getcfinal();
        java.util.GregorianCalendar gregorianCalendar23 = viagem20.getData();
        Viagem viagem26 = new Viagem(coordenada3, coordenada14, (double) 100, "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00", gregorianCalendar23, (double) 100, (double) (byte) 1);
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem8, viagem26, and viagem8", !(viagem8.compareTo(viagem26) > 0 && viagem26.compareTo(viagem8) > 0) || viagem8.compareTo(viagem8) > 0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test037");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Coordenada coordenada9 = viagem0.getcfinal();
        Viagem viagem10 = new Viagem(viagem0);
        Coordenada coordenada11 = null;
        viagem0.setcfinal(coordenada11);
        org.junit.Assert.assertTrue("Contract failed: compareTo-reflexive on viagem0", viagem0.compareTo(viagem0) == 0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test038");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = new Viagem(viagem0);
        java.lang.String str6 = viagem0.getMail();
        Viagem viagem7 = new Viagem();
        viagem7.setTempo(10.0d);
        boolean b11 = viagem7.equals((java.lang.Object) 100L);
        Viagem viagem12 = new Viagem(viagem7);
        java.lang.String str13 = viagem7.getMail();
        boolean b14 = viagem0.equals((java.lang.Object) viagem7);
        Viagem viagem15 = new Viagem();
        viagem15.setTempo(10.0d);
        boolean b19 = viagem15.equals((java.lang.Object) 100L);
        Viagem viagem20 = new Viagem(viagem15);
        java.util.GregorianCalendar gregorianCalendar21 = viagem15.getData();
        java.lang.String str22 = viagem15.toString();
        double d23 = viagem15.getPreco();
        Coordenada coordenada24 = viagem15.getcinicial();
        viagem7.setcfinal(coordenada24);
        Viagem viagem26 = new Viagem();
        java.lang.String str27 = viagem26.toString();
        Viagem viagem28 = new Viagem(viagem26);
        Coordenada coordenada29 = viagem28.getcinicial();
        Viagem viagem32 = new Viagem();
        viagem32.setTempo(10.0d);
        boolean b36 = viagem32.equals((java.lang.Object) 100L);
        Coordenada coordenada37 = viagem32.getcfinal();
        double d38 = viagem32.getTempo();
        Viagem viagem39 = new Viagem(viagem32);
        viagem32.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.util.GregorianCalendar gregorianCalendar42 = viagem32.getData();
        Viagem viagem45 = new Viagem(coordenada24, coordenada29, (double) 0, "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00", gregorianCalendar42, (double) 100, (double) 1L);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem32 and viagem26", Math.signum(viagem32.compareTo(viagem26)) == -Math.signum(viagem26.compareTo(viagem32)));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test039");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Coordenada coordenada6 = viagem5.getcfinal();
        double d7 = viagem5.getDesvio();
        viagem5.setTempo((double) ' ');
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem0, viagem5, and viagem0", !(viagem0.compareTo(viagem5) > 0 && viagem5.compareTo(viagem0) > 0) || viagem0.compareTo(viagem0) > 0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test040");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Coordenada coordenada9 = viagem0.getcfinal();
        Viagem viagem10 = new Viagem();
        viagem10.setTempo(10.0d);
        boolean b14 = viagem10.equals((java.lang.Object) 100L);
        Viagem viagem15 = viagem10.clone();
        Coordenada coordenada16 = viagem15.getcfinal();
        Viagem viagem19 = new Viagem();
        java.lang.String str20 = viagem19.toString();
        Viagem viagem21 = new Viagem(viagem19);
        Coordenada coordenada22 = viagem21.getcinicial();
        Coordenada coordenada23 = viagem21.getcfinal();
        java.util.GregorianCalendar gregorianCalendar24 = viagem21.getData();
        Viagem viagem27 = new Viagem(coordenada9, coordenada16, (double) 100, "", gregorianCalendar24, (double) (-1.0f), (double) 1);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem10 and viagem19", Math.signum(viagem10.compareTo(viagem19)) == -Math.signum(viagem19.compareTo(viagem10)));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test041");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        viagem0.setMail("hi!");
        Coordenada coordenada4 = viagem0.getcfinal();
        Viagem viagem5 = new Viagem();
        viagem5.setTempo(10.0d);
        boolean b9 = viagem5.equals((java.lang.Object) 100L);
        Coordenada coordenada10 = viagem5.getcfinal();
        double d11 = viagem5.getTempo();
        double d12 = viagem5.getDesvio();
        Viagem viagem13 = new Viagem();
        viagem13.setTempo(10.0d);
        boolean b17 = viagem13.equals((java.lang.Object) 100L);
        double d18 = viagem13.getTempo();
        viagem13.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str21 = viagem13.toString();
        viagem13.setMail("");
        Coordenada coordenada24 = viagem13.getcinicial();
        boolean b25 = viagem5.equals((java.lang.Object) coordenada24);
        Viagem viagem28 = new Viagem();
        viagem28.setTempo(10.0d);
        boolean b32 = viagem28.equals((java.lang.Object) 100L);
        java.util.GregorianCalendar gregorianCalendar33 = viagem28.getData();
        Viagem viagem36 = new Viagem(coordenada4, coordenada24, (double) '#', "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00", gregorianCalendar33, (double) (short) 100, (double) 0);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem0 and viagem13", Math.signum(viagem0.compareTo(viagem13)) == -Math.signum(viagem13.compareTo(viagem0)));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test042");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = new Viagem(viagem0);
        java.lang.String str6 = viagem0.getMail();
        Viagem viagem7 = new Viagem();
        java.lang.String str8 = viagem7.toString();
        viagem7.setMail("hi!");
        Coordenada coordenada11 = viagem7.getcfinal();
        viagem7.setTempo((double) (-1.0f));
        int i14 = viagem0.compareTo(viagem7);
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem5, viagem7, and viagem5", !(viagem5.compareTo(viagem7) > 0 && viagem7.compareTo(viagem5) > 0) || viagem5.compareTo(viagem5) > 0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test043");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Viagem viagem9 = viagem0.clone();
        Viagem viagem10 = new Viagem();
        viagem10.setTempo(10.0d);
        boolean b14 = viagem10.equals((java.lang.Object) 100L);
        Viagem viagem15 = viagem10.clone();
        Viagem viagem16 = new Viagem(viagem10);
        Viagem viagem17 = viagem10.clone();
        int i18 = viagem0.compareTo(viagem17);
        viagem0.setTempo((double) 'a');
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem9, viagem0, and viagem9", !(viagem9.compareTo(viagem0) > 0 && viagem0.compareTo(viagem9) > 0) || viagem9.compareTo(viagem9) > 0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test044");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = new Viagem(viagem0);
        java.lang.String str6 = viagem0.getMail();
        double d7 = viagem0.getPreco();
        java.lang.String str8 = viagem0.getMail();
        Viagem viagem9 = new Viagem();
        java.lang.String str10 = viagem9.toString();
        Viagem viagem11 = new Viagem(viagem9);
        Coordenada coordenada12 = viagem11.getcinicial();
        Coordenada coordenada13 = viagem11.getcfinal();
        viagem0.setcinicial(coordenada13);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem9 and viagem5", Math.signum(viagem9.compareTo(viagem5)) == -Math.signum(viagem5.compareTo(viagem9)));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test045");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = new Viagem(viagem0);
        Coordenada coordenada3 = viagem2.getcinicial();
        Coordenada coordenada4 = viagem2.getcfinal();
        java.lang.String str5 = viagem2.toString();
        java.lang.String str6 = viagem2.toString();
        Viagem viagem7 = new Viagem();
        viagem7.setTempo(10.0d);
        boolean b11 = viagem7.equals((java.lang.Object) 100L);
        Viagem viagem12 = viagem7.clone();
        Coordenada coordenada13 = viagem12.getcfinal();
        java.util.GregorianCalendar gregorianCalendar14 = viagem12.getData();
        Coordenada coordenada15 = viagem12.getcfinal();
        boolean b16 = viagem2.equals((java.lang.Object) viagem12);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem0 and viagem7", Math.signum(viagem0.compareTo(viagem7)) == -Math.signum(viagem7.compareTo(viagem0)));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test046");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        double d2 = viagem0.getPreco();
        Coordenada coordenada3 = viagem0.getcfinal();
        viagem0.setMail("hi!");
        java.lang.String str6 = viagem0.getMail();
        Viagem viagem7 = new Viagem();
        viagem7.setTempo(10.0d);
        boolean b11 = viagem7.equals((java.lang.Object) 100L);
        double d12 = viagem7.getTempo();
        viagem7.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem15 = new Viagem();
        viagem15.setTempo(10.0d);
        boolean b19 = viagem15.equals((java.lang.Object) 100L);
        double d20 = viagem15.getTempo();
        viagem15.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str23 = viagem15.toString();
        viagem15.setMail("");
        double d26 = viagem15.getDesvio();
        int i27 = viagem7.compareTo(viagem15);
        Coordenada coordenada28 = viagem7.getcinicial();
        viagem0.setcinicial(coordenada28);
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem7, viagem0, and viagem7", !(viagem7.compareTo(viagem0) > 0 && viagem0.compareTo(viagem7) > 0) || viagem7.compareTo(viagem7) > 0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test047");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = new Viagem(viagem0);
        Coordenada coordenada3 = viagem2.getcinicial();
        double d4 = viagem2.getDesvio();
        Viagem viagem5 = new Viagem();
        viagem5.setTempo(10.0d);
        boolean b9 = viagem5.equals((java.lang.Object) 100L);
        Coordenada coordenada10 = viagem5.getcfinal();
        Viagem viagem11 = new Viagem();
        viagem11.setTempo(10.0d);
        boolean b15 = viagem11.equals((java.lang.Object) 100L);
        Viagem viagem16 = viagem11.clone();
        Coordenada coordenada17 = viagem16.getcfinal();
        viagem5.setcinicial(coordenada17);
        Coordenada coordenada19 = viagem5.getcfinal();
        viagem2.setcinicial(coordenada19);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem11 and viagem0", Math.signum(viagem11.compareTo(viagem0)) == -Math.signum(viagem0.compareTo(viagem11)));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test048");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        java.lang.String str3 = viagem2.getMail();
        Viagem viagem4 = new Viagem();
        java.lang.String str5 = viagem4.toString();
        Viagem viagem6 = viagem4.clone();
        Coordenada coordenada7 = viagem4.getcinicial();
        viagem2.setcfinal(coordenada7);
        double d9 = viagem2.getDesvio();
        Viagem viagem10 = new Viagem();
        java.lang.String str11 = viagem10.toString();
        Viagem viagem12 = viagem10.clone();
        Coordenada coordenada13 = viagem10.getcinicial();
        java.lang.Object obj14 = null;
        boolean b15 = viagem10.equals(obj14);
        int i16 = viagem2.compareTo(viagem10);
        double d17 = viagem10.getDesvio();
        java.lang.String str18 = viagem10.toString();
        viagem10.setTempo((double) (short) 100);
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem6, viagem10, and viagem6", !(viagem6.compareTo(viagem10) > 0 && viagem10.compareTo(viagem6) > 0) || viagem6.compareTo(viagem6) > 0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test049");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        java.lang.String str3 = viagem2.getMail();
        Viagem viagem4 = new Viagem();
        java.lang.String str5 = viagem4.toString();
        Viagem viagem6 = viagem4.clone();
        Coordenada coordenada7 = viagem4.getcinicial();
        viagem2.setcfinal(coordenada7);
        double d9 = viagem2.getDesvio();
        viagem2.setMail("hi!");
        java.lang.String str12 = viagem2.toString();
        java.util.GregorianCalendar gregorianCalendar13 = viagem2.getData();
        Viagem viagem14 = new Viagem();
        viagem14.setTempo(10.0d);
        boolean b18 = viagem14.equals((java.lang.Object) 100L);
        Coordenada coordenada19 = viagem14.getcfinal();
        Viagem viagem20 = new Viagem();
        viagem20.setTempo(10.0d);
        boolean b24 = viagem20.equals((java.lang.Object) 100L);
        Viagem viagem25 = viagem20.clone();
        Coordenada coordenada26 = viagem25.getcfinal();
        viagem14.setcinicial(coordenada26);
        Coordenada coordenada28 = viagem14.getcfinal();
        viagem2.setcfinal(coordenada28);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem4 and viagem25", Math.signum(viagem4.compareTo(viagem25)) == -Math.signum(viagem25.compareTo(viagem4)));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test050");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        double d6 = viagem0.getPreco();
        Viagem viagem7 = new Viagem();
        viagem7.setTempo(10.0d);
        boolean b11 = viagem7.equals((java.lang.Object) 100L);
        Viagem viagem12 = viagem7.clone();
        boolean b13 = viagem0.equals((java.lang.Object) viagem12);
        Viagem viagem14 = new Viagem();
        viagem14.setTempo(10.0d);
        boolean b18 = viagem14.equals((java.lang.Object) 100L);
        double d19 = viagem14.getTempo();
        viagem14.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem22 = new Viagem();
        viagem22.setTempo(10.0d);
        boolean b26 = viagem22.equals((java.lang.Object) 100L);
        double d27 = viagem22.getTempo();
        viagem22.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str30 = viagem22.toString();
        viagem22.setMail("");
        double d33 = viagem22.getDesvio();
        int i34 = viagem14.compareTo(viagem22);
        Viagem viagem35 = viagem14.clone();
        boolean b36 = viagem12.equals((java.lang.Object) viagem35);
        Viagem viagem37 = new Viagem();
        viagem37.setTempo(10.0d);
        boolean b41 = viagem37.equals((java.lang.Object) 100L);
        Viagem viagem42 = viagem37.clone();
        Viagem viagem43 = new Viagem(viagem37);
        Viagem viagem44 = new Viagem();
        viagem44.setTempo(10.0d);
        boolean b48 = viagem44.equals((java.lang.Object) 100L);
        Viagem viagem49 = viagem44.clone();
        Viagem viagem50 = new Viagem(viagem44);
        int i51 = viagem37.compareTo(viagem44);
        boolean b52 = viagem35.equals((java.lang.Object) viagem37);
        Viagem viagem53 = new Viagem();
        java.lang.String str54 = viagem53.toString();
        Viagem viagem55 = viagem53.clone();
        Coordenada coordenada56 = viagem53.getcfinal();
        Coordenada coordenada57 = viagem53.getcfinal();
        viagem35.setcinicial(coordenada57);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem44 and viagem55", Math.signum(viagem44.compareTo(viagem55)) == -Math.signum(viagem55.compareTo(viagem44)));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test051");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        Viagem viagem6 = new Viagem();
        viagem6.setTempo(10.0d);
        boolean b10 = viagem6.equals((java.lang.Object) 100L);
        double d11 = viagem6.getTempo();
        viagem6.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Coordenada coordenada14 = viagem6.getcfinal();
        viagem0.setcinicial(coordenada14);
        Viagem viagem16 = new Viagem();
        java.lang.String str17 = viagem16.toString();
        Viagem viagem18 = viagem16.clone();
        Coordenada coordenada19 = viagem16.getcinicial();
        Viagem viagem20 = new Viagem(viagem16);
        viagem20.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str23 = viagem20.toString();
        java.lang.String str24 = viagem20.toString();
        int i25 = viagem0.compareTo(viagem20);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem18 and viagem6", Math.signum(viagem18.compareTo(viagem6)) == -Math.signum(viagem6.compareTo(viagem18)));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test052");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        Coordenada coordenada3 = viagem0.getcinicial();
        java.lang.Object obj4 = null;
        boolean b5 = viagem0.equals(obj4);
        Viagem viagem6 = new Viagem();
        java.lang.String str7 = viagem6.toString();
        Viagem viagem8 = viagem6.clone();
        java.lang.String str9 = viagem8.getMail();
        boolean b10 = viagem0.equals((java.lang.Object) str9);
        viagem0.setTempo(100.0d);
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem8, viagem0, and viagem8", !(viagem8.compareTo(viagem0) > 0 && viagem0.compareTo(viagem8) > 0) || viagem8.compareTo(viagem8) > 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test053");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        viagem0.setMail("hi!");
        Coordenada coordenada4 = viagem0.getcfinal();
        viagem0.setTempo(0.0d);
        viagem0.setMail("hi!");
        double d9 = viagem0.getPreco();
        Viagem viagem10 = new Viagem();
        viagem10.setTempo(10.0d);
        boolean b14 = viagem10.equals((java.lang.Object) 100L);
        double d15 = viagem10.getTempo();
        Coordenada coordenada16 = viagem10.getcfinal();
        java.lang.String str17 = viagem10.getMail();
        Viagem viagem18 = new Viagem();
        viagem18.setTempo(10.0d);
        boolean b22 = viagem18.equals((java.lang.Object) 100L);
        double d23 = viagem18.getTempo();
        viagem18.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem26 = new Viagem();
        viagem26.setTempo(10.0d);
        boolean b30 = viagem26.equals((java.lang.Object) 100L);
        double d31 = viagem26.getTempo();
        viagem26.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str34 = viagem26.toString();
        viagem26.setMail("");
        double d37 = viagem26.getDesvio();
        int i38 = viagem18.compareTo(viagem26);
        Coordenada coordenada39 = viagem18.getcinicial();
        Viagem viagem40 = new Viagem();
        viagem40.setTempo(10.0d);
        boolean b44 = viagem40.equals((java.lang.Object) 100L);
        java.util.GregorianCalendar gregorianCalendar45 = viagem40.getData();
        Coordenada coordenada46 = viagem40.getcinicial();
        Viagem viagem47 = new Viagem();
        viagem47.setTempo(10.0d);
        boolean b51 = viagem47.equals((java.lang.Object) 100L);
        double d52 = viagem47.getTempo();
        viagem47.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem55 = new Viagem(viagem47);
        Viagem viagem56 = viagem55.clone();
        Coordenada coordenada57 = viagem56.getcfinal();
        boolean b58 = viagem40.equals((java.lang.Object) coordenada57);
        viagem18.setcfinal(coordenada57);
        viagem10.setcinicial(coordenada57);
        viagem0.setcinicial(coordenada57);
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem40, viagem0, and viagem40", !(viagem40.compareTo(viagem0) > 0 && viagem0.compareTo(viagem40) > 0) || viagem40.compareTo(viagem40) > 0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test054");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem();
        viagem8.setTempo(10.0d);
        boolean b12 = viagem8.equals((java.lang.Object) 100L);
        double d13 = viagem8.getTempo();
        viagem8.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str16 = viagem8.toString();
        viagem8.setMail("");
        double d19 = viagem8.getDesvio();
        int i20 = viagem0.compareTo(viagem8);
        double d21 = viagem0.getPreco();
        Viagem viagem22 = new Viagem();
        viagem22.setTempo(10.0d);
        boolean b26 = viagem22.equals((java.lang.Object) 100L);
        double d27 = viagem22.getTempo();
        viagem22.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str30 = viagem22.toString();
        viagem22.setMail("");
        Coordenada coordenada33 = viagem22.getcinicial();
        viagem0.setcinicial(coordenada33);
        Viagem viagem35 = viagem0.clone();
        Viagem viagem36 = new Viagem();
        java.lang.String str37 = viagem36.toString();
        Viagem viagem38 = viagem36.clone();
        Coordenada coordenada39 = viagem36.getcinicial();
        Viagem viagem40 = viagem36.clone();
        Coordenada coordenada41 = viagem36.getcfinal();
        viagem35.setcinicial(coordenada41);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem0 and viagem40", Math.signum(viagem0.compareTo(viagem40)) == -Math.signum(viagem40.compareTo(viagem0)));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test055");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        viagem0.setMail("hi!");
        Coordenada coordenada4 = viagem0.getcfinal();
        Viagem viagem5 = new Viagem();
        viagem5.setTempo(10.0d);
        boolean b9 = viagem5.equals((java.lang.Object) 100L);
        double d10 = viagem5.getTempo();
        viagem5.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem13 = new Viagem(viagem5);
        java.util.GregorianCalendar gregorianCalendar14 = viagem5.getData();
        Viagem viagem15 = new Viagem();
        viagem15.setTempo(10.0d);
        boolean b19 = viagem15.equals((java.lang.Object) 100L);
        Viagem viagem20 = viagem15.clone();
        Viagem viagem21 = new Viagem(viagem15);
        Viagem viagem22 = viagem15.clone();
        double d23 = viagem22.getPreco();
        Coordenada coordenada24 = viagem22.getcinicial();
        viagem5.setcfinal(coordenada24);
        Viagem viagem28 = new Viagem();
        java.lang.String str29 = viagem28.toString();
        Viagem viagem30 = new Viagem(viagem28);
        double d31 = viagem28.getPreco();
        java.util.GregorianCalendar gregorianCalendar32 = viagem28.getData();
        Viagem viagem35 = new Viagem(coordenada4, coordenada24, (-1.0d), "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00", gregorianCalendar32, 100.0d, (double) (-1));
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem21 and viagem0", Math.signum(viagem21.compareTo(viagem0)) == -Math.signum(viagem0.compareTo(viagem21)));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test056");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        java.lang.String str3 = viagem2.getMail();
        Viagem viagem4 = new Viagem();
        java.lang.String str5 = viagem4.toString();
        Viagem viagem6 = viagem4.clone();
        Coordenada coordenada7 = viagem4.getcinicial();
        viagem2.setcfinal(coordenada7);
        double d9 = viagem2.getDesvio();
        Viagem viagem10 = new Viagem();
        java.lang.String str11 = viagem10.toString();
        Viagem viagem12 = viagem10.clone();
        Coordenada coordenada13 = viagem10.getcinicial();
        java.lang.Object obj14 = null;
        boolean b15 = viagem10.equals(obj14);
        int i16 = viagem2.compareTo(viagem10);
        java.lang.String str17 = viagem2.getMail();
        Viagem viagem18 = new Viagem();
        viagem18.setTempo(10.0d);
        boolean b22 = viagem18.equals((java.lang.Object) 100L);
        double d23 = viagem18.getTempo();
        viagem18.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem26 = new Viagem(viagem18);
        java.util.GregorianCalendar gregorianCalendar27 = viagem18.getData();
        Viagem viagem28 = new Viagem();
        viagem28.setTempo(10.0d);
        boolean b32 = viagem28.equals((java.lang.Object) 100L);
        Viagem viagem33 = viagem28.clone();
        Viagem viagem34 = new Viagem(viagem28);
        Viagem viagem35 = viagem28.clone();
        double d36 = viagem35.getPreco();
        Coordenada coordenada37 = viagem35.getcinicial();
        viagem18.setcfinal(coordenada37);
        viagem2.setcinicial(coordenada37);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem0 and viagem35", Math.signum(viagem0.compareTo(viagem35)) == -Math.signum(viagem35.compareTo(viagem0)));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test057");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Viagem viagem9 = viagem8.clone();
        Coordenada coordenada10 = viagem9.getcfinal();
        Viagem viagem11 = new Viagem();
        viagem11.setTempo(10.0d);
        boolean b15 = viagem11.equals((java.lang.Object) 100L);
        double d16 = viagem11.getTempo();
        viagem11.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str19 = viagem11.toString();
        viagem11.setMail("");
        Viagem viagem22 = new Viagem(viagem11);
        int i23 = viagem9.compareTo(viagem22);
        double d24 = viagem9.getDesvio();
        Viagem viagem25 = viagem9.clone();
        viagem9.setTempo(100.0d);
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem22, viagem9, and viagem22", !(viagem22.compareTo(viagem9) > 0 && viagem9.compareTo(viagem22) > 0) || viagem22.compareTo(viagem22) > 0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test058");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        double d2 = viagem0.getPreco();
        Coordenada coordenada3 = viagem0.getcfinal();
        Viagem viagem4 = new Viagem();
        viagem4.setTempo(10.0d);
        boolean b8 = viagem4.equals((java.lang.Object) 100L);
        double d9 = viagem4.getTempo();
        viagem4.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem12 = new Viagem(viagem4);
        java.util.GregorianCalendar gregorianCalendar13 = viagem4.getData();
        Viagem viagem14 = new Viagem();
        viagem14.setTempo(10.0d);
        boolean b18 = viagem14.equals((java.lang.Object) 100L);
        Viagem viagem19 = viagem14.clone();
        Viagem viagem20 = new Viagem(viagem14);
        Viagem viagem21 = viagem14.clone();
        double d22 = viagem21.getPreco();
        Coordenada coordenada23 = viagem21.getcinicial();
        viagem4.setcfinal(coordenada23);
        Viagem viagem27 = new Viagem();
        java.lang.String str28 = viagem27.toString();
        double d29 = viagem27.getPreco();
        Coordenada coordenada30 = viagem27.getcfinal();
        viagem27.setMail("hi!");
        Viagem viagem33 = new Viagem();
        java.lang.String str34 = viagem33.toString();
        Viagem viagem35 = viagem33.clone();
        java.lang.String str36 = viagem35.getMail();
        Viagem viagem37 = new Viagem();
        java.lang.String str38 = viagem37.toString();
        Viagem viagem39 = viagem37.clone();
        Coordenada coordenada40 = viagem37.getcinicial();
        viagem35.setcfinal(coordenada40);
        viagem27.setcinicial(coordenada40);
        java.util.GregorianCalendar gregorianCalendar43 = viagem27.getData();
        Viagem viagem46 = new Viagem(coordenada3, coordenada23, 0.0d, "", gregorianCalendar43, (double) '#', (double) 10);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem37 and viagem12", Math.signum(viagem37.compareTo(viagem12)) == -Math.signum(viagem12.compareTo(viagem37)));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test059");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        double d2 = viagem0.getPreco();
        Coordenada coordenada3 = viagem0.getcfinal();
        viagem0.setMail("hi!");
        Viagem viagem6 = new Viagem();
        java.lang.String str7 = viagem6.toString();
        Viagem viagem8 = viagem6.clone();
        java.lang.String str9 = viagem8.getMail();
        Viagem viagem10 = new Viagem();
        java.lang.String str11 = viagem10.toString();
        Viagem viagem12 = viagem10.clone();
        Coordenada coordenada13 = viagem10.getcinicial();
        viagem8.setcfinal(coordenada13);
        viagem0.setcinicial(coordenada13);
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str18 = viagem0.toString();
        Viagem viagem19 = new Viagem();
        viagem19.setTempo(10.0d);
        boolean b23 = viagem19.equals((java.lang.Object) 100L);
        java.util.GregorianCalendar gregorianCalendar24 = viagem19.getData();
        Coordenada coordenada25 = viagem19.getcinicial();
        Viagem viagem26 = new Viagem();
        viagem26.setTempo(10.0d);
        boolean b30 = viagem26.equals((java.lang.Object) 100L);
        double d31 = viagem26.getTempo();
        viagem26.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem34 = new Viagem(viagem26);
        Viagem viagem35 = viagem34.clone();
        Coordenada coordenada36 = viagem35.getcfinal();
        boolean b37 = viagem19.equals((java.lang.Object) coordenada36);
        viagem0.setcfinal(coordenada36);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem35 and viagem6", Math.signum(viagem35.compareTo(viagem6)) == -Math.signum(viagem6.compareTo(viagem35)));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test060");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str8 = viagem0.toString();
        viagem0.setMail("");
        double d11 = viagem0.getDesvio();
        Viagem viagem12 = new Viagem();
        java.lang.String str13 = viagem12.toString();
        viagem12.setMail("hi!");
        Coordenada coordenada16 = viagem12.getcfinal();
        viagem12.setTempo(0.0d);
        java.lang.String str19 = viagem12.toString();
        boolean b20 = viagem0.equals((java.lang.Object) str19);
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem12, viagem0, and viagem12", !(viagem12.compareTo(viagem0) > 0 && viagem0.compareTo(viagem12) > 0) || viagem12.compareTo(viagem12) > 0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test061");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Coordenada coordenada5 = viagem0.getcfinal();
        double d6 = viagem0.getTempo();
        double d7 = viagem0.getDesvio();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem10 = new Viagem();
        java.lang.String str11 = viagem10.toString();
        Viagem viagem12 = viagem10.clone();
        Coordenada coordenada13 = viagem10.getcinicial();
        Viagem viagem14 = new Viagem(viagem10);
        viagem14.setTempo((double) (short) 0);
        Viagem viagem17 = new Viagem();
        java.lang.String str18 = viagem17.toString();
        Viagem viagem19 = viagem17.clone();
        Coordenada coordenada20 = viagem17.getcinicial();
        boolean b21 = viagem14.equals((java.lang.Object) coordenada20);
        viagem0.setcinicial(coordenada20);
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem19, viagem0, and viagem19", !(viagem19.compareTo(viagem0) > 0 && viagem0.compareTo(viagem19) > 0) || viagem19.compareTo(viagem19) > 0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test062");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = new Viagem(viagem0);
        Coordenada coordenada3 = viagem2.getcinicial();
        Viagem viagem4 = new Viagem();
        viagem4.setTempo(10.0d);
        boolean b8 = viagem4.equals((java.lang.Object) 100L);
        double d9 = viagem4.getTempo();
        viagem4.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem12 = new Viagem(viagem4);
        Coordenada coordenada13 = viagem4.getcfinal();
        Viagem viagem14 = new Viagem();
        viagem14.setTempo(10.0d);
        boolean b18 = viagem14.equals((java.lang.Object) 100L);
        Coordenada coordenada19 = viagem14.getcfinal();
        double d20 = viagem14.getTempo();
        Viagem viagem21 = new Viagem(viagem14);
        int i22 = viagem4.compareTo(viagem14);
        double d23 = viagem4.getPreco();
        Viagem viagem24 = new Viagem();
        viagem24.setTempo(10.0d);
        boolean b28 = viagem24.equals((java.lang.Object) 100L);
        double d29 = viagem24.getTempo();
        viagem24.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem32 = new Viagem(viagem24);
        Coordenada coordenada33 = viagem24.getcfinal();
        viagem4.setcfinal(coordenada33);
        double d35 = viagem4.getTempo();
        int i36 = viagem2.compareTo(viagem4);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem32 and viagem0", Math.signum(viagem32.compareTo(viagem0)) == -Math.signum(viagem0.compareTo(viagem32)));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test063");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = new Viagem(viagem0);
        java.lang.String str6 = viagem0.getMail();
        Viagem viagem7 = new Viagem();
        viagem7.setTempo(10.0d);
        boolean b11 = viagem7.equals((java.lang.Object) 100L);
        Viagem viagem12 = new Viagem(viagem7);
        java.lang.String str13 = viagem7.getMail();
        boolean b14 = viagem0.equals((java.lang.Object) viagem7);
        Viagem viagem15 = new Viagem();
        viagem15.setTempo(10.0d);
        boolean b19 = viagem15.equals((java.lang.Object) 100L);
        Viagem viagem20 = new Viagem(viagem15);
        java.util.GregorianCalendar gregorianCalendar21 = viagem15.getData();
        java.lang.String str22 = viagem15.toString();
        double d23 = viagem15.getPreco();
        Coordenada coordenada24 = viagem15.getcinicial();
        viagem7.setcfinal(coordenada24);
        Viagem viagem26 = new Viagem();
        java.lang.String str27 = viagem26.toString();
        Viagem viagem28 = viagem26.clone();
        java.lang.String str29 = viagem28.getMail();
        Viagem viagem30 = new Viagem();
        java.lang.String str31 = viagem30.toString();
        Viagem viagem32 = viagem30.clone();
        Coordenada coordenada33 = viagem30.getcinicial();
        viagem28.setcfinal(coordenada33);
        double d35 = viagem28.getDesvio();
        Viagem viagem36 = new Viagem();
        java.lang.String str37 = viagem36.toString();
        Viagem viagem38 = viagem36.clone();
        Coordenada coordenada39 = viagem36.getcinicial();
        java.lang.Object obj40 = null;
        boolean b41 = viagem36.equals(obj40);
        int i42 = viagem28.compareTo(viagem36);
        Viagem viagem43 = viagem36.clone();
        Viagem viagem44 = viagem43.clone();
        Coordenada coordenada45 = viagem43.getcinicial();
        viagem7.setcfinal(coordenada45);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem26 and viagem15", Math.signum(viagem26.compareTo(viagem15)) == -Math.signum(viagem15.compareTo(viagem26)));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test064");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        java.lang.String str3 = viagem2.getMail();
        Viagem viagem4 = new Viagem();
        java.lang.String str5 = viagem4.toString();
        Viagem viagem6 = viagem4.clone();
        Coordenada coordenada7 = viagem4.getcinicial();
        viagem2.setcfinal(coordenada7);
        Viagem viagem9 = new Viagem();
        java.lang.String str10 = viagem9.toString();
        Viagem viagem11 = viagem9.clone();
        java.lang.String str12 = viagem11.getMail();
        Viagem viagem13 = new Viagem();
        java.lang.String str14 = viagem13.toString();
        Viagem viagem15 = viagem13.clone();
        Coordenada coordenada16 = viagem13.getcinicial();
        viagem11.setcfinal(coordenada16);
        double d18 = viagem11.getDesvio();
        Viagem viagem19 = new Viagem();
        java.lang.String str20 = viagem19.toString();
        Viagem viagem21 = viagem19.clone();
        Coordenada coordenada22 = viagem19.getcinicial();
        java.lang.Object obj23 = null;
        boolean b24 = viagem19.equals(obj23);
        int i25 = viagem11.compareTo(viagem19);
        Viagem viagem26 = viagem19.clone();
        Viagem viagem27 = new Viagem();
        java.lang.String str28 = viagem27.toString();
        Viagem viagem29 = viagem27.clone();
        Coordenada coordenada30 = viagem27.getcfinal();
        viagem19.setcinicial(coordenada30);
        Viagem viagem34 = new Viagem();
        viagem34.setTempo(10.0d);
        boolean b38 = viagem34.equals((java.lang.Object) 100L);
        Coordenada coordenada39 = viagem34.getcfinal();
        double d40 = viagem34.getTempo();
        Viagem viagem41 = new Viagem(viagem34);
        viagem34.setTempo((double) (byte) 10);
        java.util.GregorianCalendar gregorianCalendar44 = viagem34.getData();
        Viagem viagem47 = new Viagem(coordenada7, coordenada30, (double) (byte) -1, "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: -1.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00", gregorianCalendar44, (double) 0.0f, (double) '#');
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem41 and viagem29", Math.signum(viagem41.compareTo(viagem29)) == -Math.signum(viagem29.compareTo(viagem41)));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test065");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        Coordenada coordenada6 = viagem0.getcfinal();
        Coordenada coordenada7 = viagem0.getcinicial();
        Viagem viagem8 = new Viagem();
        viagem8.setTempo(10.0d);
        boolean b12 = viagem8.equals((java.lang.Object) 100L);
        Viagem viagem13 = viagem8.clone();
        Viagem viagem14 = new Viagem();
        viagem14.setTempo(10.0d);
        boolean b18 = viagem14.equals((java.lang.Object) 100L);
        double d19 = viagem14.getTempo();
        viagem14.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str22 = viagem14.toString();
        viagem14.setMail("");
        double d25 = viagem14.getDesvio();
        java.util.GregorianCalendar gregorianCalendar26 = viagem14.getData();
        int i27 = viagem13.compareTo(viagem14);
        Viagem viagem28 = viagem13.clone();
        Coordenada coordenada29 = viagem13.getcfinal();
        Viagem viagem32 = new Viagem();
        viagem32.setTempo(10.0d);
        boolean b36 = viagem32.equals((java.lang.Object) 100L);
        Coordenada coordenada37 = viagem32.getcfinal();
        double d38 = viagem32.getTempo();
        Viagem viagem39 = new Viagem(viagem32);
        viagem32.setTempo((double) (byte) 10);
        java.util.GregorianCalendar gregorianCalendar42 = viagem32.getData();
        Viagem viagem45 = new Viagem(coordenada7, coordenada29, (double) (-1), "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00", gregorianCalendar42, (double) 1L, (double) (byte) 100);
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem8, viagem45, and viagem8", !(viagem8.compareTo(viagem45) > 0 && viagem45.compareTo(viagem8) > 0) || viagem8.compareTo(viagem8) > 0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test066");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = new Viagem(viagem0);
        java.util.GregorianCalendar gregorianCalendar6 = viagem0.getData();
        java.lang.String str7 = viagem0.toString();
        double d8 = viagem0.getPreco();
        Coordenada coordenada9 = viagem0.getcinicial();
        Viagem viagem10 = new Viagem(viagem0);
        viagem0.setTempo((double) (-1L));
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem5, viagem0, and viagem5", !(viagem5.compareTo(viagem0) > 0 && viagem0.compareTo(viagem5) > 0) || viagem5.compareTo(viagem5) > 0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test067");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Coordenada coordenada5 = viagem0.getcfinal();
        double d6 = viagem0.getTempo();
        Viagem viagem7 = new Viagem(viagem0);
        viagem0.setTempo((double) (byte) 10);
        java.util.GregorianCalendar gregorianCalendar10 = viagem0.getData();
        Viagem viagem11 = new Viagem();
        java.lang.String str12 = viagem11.toString();
        viagem11.setMail("hi!");
        Coordenada coordenada15 = viagem11.getcfinal();
        double d16 = viagem11.getPreco();
        Viagem viagem17 = new Viagem();
        java.lang.String str18 = viagem17.toString();
        double d19 = viagem17.getPreco();
        Coordenada coordenada20 = viagem17.getcfinal();
        viagem17.setMail("hi!");
        int i23 = viagem11.compareTo(viagem17);
        Viagem viagem24 = new Viagem();
        java.lang.String str25 = viagem24.toString();
        Viagem viagem26 = new Viagem(viagem24);
        Coordenada coordenada27 = viagem26.getcinicial();
        Viagem viagem28 = new Viagem();
        java.lang.String str29 = viagem28.toString();
        Viagem viagem30 = viagem28.clone();
        java.lang.String str31 = viagem30.getMail();
        Viagem viagem32 = new Viagem();
        java.lang.String str33 = viagem32.toString();
        Viagem viagem34 = viagem32.clone();
        Coordenada coordenada35 = viagem32.getcinicial();
        viagem30.setcfinal(coordenada35);
        viagem26.setcfinal(coordenada35);
        viagem11.setcfinal(coordenada35);
        viagem0.setcinicial(coordenada35);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem34 and viagem7", Math.signum(viagem34.compareTo(viagem7)) == -Math.signum(viagem7.compareTo(viagem34)));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test068");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = new Viagem(viagem0);
        java.lang.String str6 = viagem0.getMail();
        Viagem viagem7 = new Viagem();
        viagem7.setTempo(10.0d);
        boolean b11 = viagem7.equals((java.lang.Object) 100L);
        Viagem viagem12 = new Viagem(viagem7);
        java.lang.String str13 = viagem7.getMail();
        boolean b14 = viagem0.equals((java.lang.Object) viagem7);
        Viagem viagem15 = new Viagem();
        viagem15.setTempo(10.0d);
        boolean b19 = viagem15.equals((java.lang.Object) 100L);
        Viagem viagem20 = viagem15.clone();
        Viagem viagem21 = new Viagem(viagem15);
        Viagem viagem22 = new Viagem();
        viagem22.setTempo(10.0d);
        boolean b26 = viagem22.equals((java.lang.Object) 100L);
        Viagem viagem27 = viagem22.clone();
        Viagem viagem28 = new Viagem(viagem22);
        int i29 = viagem15.compareTo(viagem22);
        viagem22.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        int i32 = viagem7.compareTo(viagem22);
        viagem22.setTempo(1.0d);
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem7, viagem22, and viagem7", !(viagem7.compareTo(viagem22) > 0 && viagem22.compareTo(viagem7) > 0) || viagem7.compareTo(viagem7) > 0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test069");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Viagem viagem6 = new Viagem(viagem0);
        Viagem viagem7 = viagem0.clone();
        viagem7.setTempo((double) (-3));
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem6, viagem7, and viagem6", !(viagem6.compareTo(viagem7) > 0 && viagem7.compareTo(viagem6) > 0) || viagem6.compareTo(viagem6) > 0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test070");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Viagem viagem6 = new Viagem();
        viagem6.setTempo(10.0d);
        boolean b10 = viagem6.equals((java.lang.Object) 100L);
        double d11 = viagem6.getTempo();
        viagem6.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str14 = viagem6.toString();
        viagem6.setMail("");
        double d17 = viagem6.getDesvio();
        java.util.GregorianCalendar gregorianCalendar18 = viagem6.getData();
        int i19 = viagem5.compareTo(viagem6);
        Viagem viagem20 = viagem5.clone();
        Coordenada coordenada21 = viagem5.getcfinal();
        Viagem viagem22 = new Viagem();
        viagem22.setTempo(10.0d);
        boolean b26 = viagem22.equals((java.lang.Object) 100L);
        double d27 = viagem22.getTempo();
        viagem22.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem30 = new Viagem(viagem22);
        Viagem viagem31 = viagem30.clone();
        Coordenada coordenada32 = viagem31.getcfinal();
        Viagem viagem33 = new Viagem();
        viagem33.setTempo(10.0d);
        boolean b37 = viagem33.equals((java.lang.Object) 100L);
        double d38 = viagem33.getTempo();
        viagem33.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str41 = viagem33.toString();
        viagem33.setMail("");
        Viagem viagem44 = new Viagem(viagem33);
        int i45 = viagem31.compareTo(viagem44);
        double d46 = viagem31.getDesvio();
        Viagem viagem47 = viagem31.clone();
        java.lang.String str48 = viagem47.toString();
        Viagem viagem49 = new Viagem();
        viagem49.setTempo(10.0d);
        boolean b53 = viagem49.equals((java.lang.Object) 100L);
        Viagem viagem54 = new Viagem(viagem49);
        java.lang.String str55 = viagem49.getMail();
        Viagem viagem56 = new Viagem();
        viagem56.setTempo(10.0d);
        boolean b60 = viagem56.equals((java.lang.Object) 100L);
        Viagem viagem61 = new Viagem(viagem56);
        java.lang.String str62 = viagem56.getMail();
        boolean b63 = viagem49.equals((java.lang.Object) viagem56);
        Viagem viagem64 = new Viagem();
        viagem64.setTempo(10.0d);
        boolean b68 = viagem64.equals((java.lang.Object) 100L);
        Viagem viagem69 = new Viagem(viagem64);
        java.util.GregorianCalendar gregorianCalendar70 = viagem64.getData();
        java.lang.String str71 = viagem64.toString();
        double d72 = viagem64.getPreco();
        Coordenada coordenada73 = viagem64.getcinicial();
        viagem56.setcfinal(coordenada73);
        viagem47.setcinicial(coordenada73);
        Viagem viagem78 = new Viagem();
        java.lang.String str79 = viagem78.toString();
        Viagem viagem80 = new Viagem(viagem78);
        double d81 = viagem78.getPreco();
        java.util.GregorianCalendar gregorianCalendar82 = viagem78.getData();
        Viagem viagem85 = new Viagem(coordenada21, coordenada73, (double) (byte) 100, "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00", gregorianCalendar82, (-1.0d), (double) 0L);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem31 and viagem80", Math.signum(viagem31.compareTo(viagem80)) == -Math.signum(viagem80.compareTo(viagem31)));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test071");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Viagem viagem9 = viagem0.clone();
        Viagem viagem10 = new Viagem();
        viagem10.setTempo(10.0d);
        boolean b14 = viagem10.equals((java.lang.Object) 100L);
        Viagem viagem15 = viagem10.clone();
        Viagem viagem16 = new Viagem(viagem10);
        Viagem viagem17 = viagem10.clone();
        int i18 = viagem0.compareTo(viagem17);
        double d19 = viagem0.getTempo();
        Viagem viagem20 = new Viagem();
        java.lang.String str21 = viagem20.toString();
        Viagem viagem22 = viagem20.clone();
        Coordenada coordenada23 = viagem20.getcinicial();
        Viagem viagem24 = viagem20.clone();
        Coordenada coordenada25 = viagem24.getcfinal();
        viagem0.setcfinal(coordenada25);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem15 and viagem22", Math.signum(viagem15.compareTo(viagem22)) == -Math.signum(viagem22.compareTo(viagem15)));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test072");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = new Viagem(viagem0);
        Viagem viagem6 = new Viagem();
        java.lang.String str7 = viagem6.toString();
        Viagem viagem8 = viagem6.clone();
        java.lang.String str9 = viagem8.getMail();
        Viagem viagem10 = new Viagem();
        java.lang.String str11 = viagem10.toString();
        Viagem viagem12 = viagem10.clone();
        Coordenada coordenada13 = viagem10.getcinicial();
        viagem8.setcfinal(coordenada13);
        double d15 = viagem8.getDesvio();
        viagem8.setMail("hi!");
        java.lang.String str18 = viagem8.toString();
        Coordenada coordenada19 = viagem8.getcfinal();
        viagem0.setcfinal(coordenada19);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem8 and viagem5", Math.signum(viagem8.compareTo(viagem5)) == -Math.signum(viagem5.compareTo(viagem8)));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test073");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = new Viagem(viagem0);
        double d3 = viagem0.getPreco();
        double d4 = viagem0.getPreco();
        viagem0.setTempo((double) (-1));
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem2, viagem0, and viagem2", !(viagem2.compareTo(viagem0) > 0 && viagem0.compareTo(viagem2) > 0) || viagem2.compareTo(viagem2) > 0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test074");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        Coordenada coordenada3 = viagem0.getcinicial();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        viagem0.setTempo((double) '#');
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem2, viagem0, and viagem2", !(viagem2.compareTo(viagem0) > 0 && viagem0.compareTo(viagem2) > 0) || viagem2.compareTo(viagem2) > 0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test075");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        Coordenada coordenada3 = viagem0.getcinicial();
        Viagem viagem4 = new Viagem(viagem0);
        Viagem viagem5 = new Viagem();
        viagem5.setTempo(10.0d);
        boolean b9 = viagem5.equals((java.lang.Object) 100L);
        java.util.GregorianCalendar gregorianCalendar10 = viagem5.getData();
        Coordenada coordenada11 = viagem5.getcinicial();
        Viagem viagem12 = new Viagem();
        viagem12.setTempo(10.0d);
        boolean b16 = viagem12.equals((java.lang.Object) 100L);
        double d17 = viagem12.getTempo();
        viagem12.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem20 = new Viagem();
        viagem20.setTempo(10.0d);
        boolean b24 = viagem20.equals((java.lang.Object) 100L);
        double d25 = viagem20.getTempo();
        viagem20.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str28 = viagem20.toString();
        viagem20.setMail("");
        double d31 = viagem20.getDesvio();
        int i32 = viagem12.compareTo(viagem20);
        Coordenada coordenada33 = viagem12.getcinicial();
        viagem5.setcinicial(coordenada33);
        viagem4.setcinicial(coordenada33);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem12 and viagem2", Math.signum(viagem12.compareTo(viagem2)) == -Math.signum(viagem2.compareTo(viagem12)));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test076");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = new Viagem(viagem0);
        Viagem viagem3 = new Viagem();
        java.lang.String str4 = viagem3.toString();
        Viagem viagem5 = viagem3.clone();
        Coordenada coordenada6 = viagem3.getcfinal();
        Coordenada coordenada7 = viagem3.getcfinal();
        viagem2.setcinicial(coordenada7);
        Viagem viagem9 = new Viagem();
        java.lang.String str10 = viagem9.toString();
        Viagem viagem11 = new Viagem(viagem9);
        Coordenada coordenada12 = viagem11.getcinicial();
        Coordenada coordenada13 = viagem11.getcfinal();
        Viagem viagem16 = new Viagem();
        viagem16.setTempo(10.0d);
        boolean b20 = viagem16.equals((java.lang.Object) 100L);
        double d21 = viagem16.getTempo();
        viagem16.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem24 = new Viagem(viagem16);
        java.util.GregorianCalendar gregorianCalendar25 = viagem16.getData();
        Viagem viagem28 = new Viagem(coordenada7, coordenada13, (double) '#', "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00", gregorianCalendar25, (double) 1L, (-1.0d));
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem11 and viagem16", Math.signum(viagem11.compareTo(viagem16)) == -Math.signum(viagem16.compareTo(viagem11)));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test077");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Viagem viagem6 = new Viagem(viagem0);
        Viagem viagem7 = new Viagem();
        viagem7.setTempo(10.0d);
        boolean b11 = viagem7.equals((java.lang.Object) 100L);
        Viagem viagem12 = viagem7.clone();
        Viagem viagem13 = new Viagem(viagem7);
        int i14 = viagem0.compareTo(viagem7);
        double d15 = viagem7.getTempo();
        Viagem viagem16 = viagem7.clone();
        Viagem viagem17 = new Viagem();
        viagem17.setTempo(10.0d);
        boolean b21 = viagem17.equals((java.lang.Object) 100L);
        double d22 = viagem17.getTempo();
        double d23 = viagem17.getPreco();
        Viagem viagem24 = new Viagem(viagem17);
        Viagem viagem25 = new Viagem(viagem17);
        int i26 = viagem7.compareTo(viagem25);
        viagem7.setTempo((double) '4');
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem12, viagem7, and viagem12", !(viagem12.compareTo(viagem7) > 0 && viagem7.compareTo(viagem12) > 0) || viagem12.compareTo(viagem12) > 0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test078");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        java.lang.String str3 = viagem2.getMail();
        Viagem viagem4 = new Viagem();
        java.lang.String str5 = viagem4.toString();
        Viagem viagem6 = viagem4.clone();
        Coordenada coordenada7 = viagem4.getcinicial();
        viagem2.setcfinal(coordenada7);
        double d9 = viagem2.getDesvio();
        Viagem viagem10 = new Viagem();
        java.lang.String str11 = viagem10.toString();
        Viagem viagem12 = viagem10.clone();
        Coordenada coordenada13 = viagem10.getcinicial();
        java.lang.Object obj14 = null;
        boolean b15 = viagem10.equals(obj14);
        int i16 = viagem2.compareTo(viagem10);
        Viagem viagem17 = viagem10.clone();
        Viagem viagem18 = new Viagem();
        java.lang.String str19 = viagem18.toString();
        Viagem viagem20 = viagem18.clone();
        Coordenada coordenada21 = viagem18.getcfinal();
        viagem10.setcinicial(coordenada21);
        Viagem viagem23 = new Viagem();
        viagem23.setTempo(10.0d);
        boolean b27 = viagem23.equals((java.lang.Object) 100L);
        Coordenada coordenada28 = viagem23.getcfinal();
        Coordenada coordenada29 = viagem23.getcinicial();
        Coordenada coordenada30 = viagem23.getcinicial();
        Viagem viagem31 = new Viagem();
        viagem31.setTempo(10.0d);
        boolean b35 = viagem31.equals((java.lang.Object) 100L);
        Coordenada coordenada36 = viagem31.getcfinal();
        double d37 = viagem31.getTempo();
        Viagem viagem38 = new Viagem(viagem31);
        Coordenada coordenada39 = viagem31.getcfinal();
        Viagem viagem42 = new Viagem();
        viagem42.setTempo(10.0d);
        boolean b46 = viagem42.equals((java.lang.Object) 100L);
        Viagem viagem47 = viagem42.clone();
        Coordenada coordenada48 = viagem47.getcfinal();
        java.util.GregorianCalendar gregorianCalendar49 = viagem47.getData();
        Viagem viagem52 = new Viagem(coordenada30, coordenada39, (double) (short) 10, "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: -1.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00", gregorianCalendar49, (double) (byte) 10, (double) (short) -1);
        Viagem viagem55 = new Viagem();
        java.util.GregorianCalendar gregorianCalendar56 = viagem55.getData();
        Viagem viagem59 = new Viagem(coordenada21, coordenada30, 100.0d, "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: -1.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00", gregorianCalendar56, (double) (short) 10, (double) ' ');
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem38 and viagem6", Math.signum(viagem38.compareTo(viagem6)) == -Math.signum(viagem6.compareTo(viagem38)));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test079");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        viagem0.setMail("hi!");
        Coordenada coordenada4 = viagem0.getcfinal();
        Viagem viagem5 = new Viagem();
        viagem5.setTempo(10.0d);
        boolean b9 = viagem5.equals((java.lang.Object) 100L);
        double d10 = viagem5.getTempo();
        viagem5.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem13 = new Viagem(viagem5);
        Viagem viagem14 = viagem13.clone();
        Coordenada coordenada15 = viagem14.getcfinal();
        Viagem viagem16 = new Viagem();
        viagem16.setTempo(10.0d);
        boolean b20 = viagem16.equals((java.lang.Object) 100L);
        double d21 = viagem16.getTempo();
        viagem16.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str24 = viagem16.toString();
        viagem16.setMail("");
        Viagem viagem27 = new Viagem(viagem16);
        int i28 = viagem14.compareTo(viagem27);
        Viagem viagem29 = new Viagem();
        viagem29.setTempo(10.0d);
        boolean b33 = viagem29.equals((java.lang.Object) 100L);
        Viagem viagem34 = viagem29.clone();
        Viagem viagem35 = new Viagem();
        viagem35.setTempo(10.0d);
        boolean b39 = viagem35.equals((java.lang.Object) 100L);
        double d40 = viagem35.getTempo();
        viagem35.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str43 = viagem35.toString();
        viagem35.setMail("");
        double d46 = viagem35.getDesvio();
        java.util.GregorianCalendar gregorianCalendar47 = viagem35.getData();
        int i48 = viagem34.compareTo(viagem35);
        Viagem viagem49 = viagem34.clone();
        Coordenada coordenada50 = viagem34.getcfinal();
        viagem14.setcfinal(coordenada50);
        Viagem viagem54 = new Viagem();
        viagem54.setTempo(10.0d);
        boolean b58 = viagem54.equals((java.lang.Object) 100L);
        double d59 = viagem54.getTempo();
        viagem54.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem62 = new Viagem(viagem54);
        Viagem viagem63 = viagem54.clone();
        java.lang.String str64 = viagem63.toString();
        java.util.GregorianCalendar gregorianCalendar65 = viagem63.getData();
        Viagem viagem68 = new Viagem(coordenada4, coordenada50, 0.0d, "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00", gregorianCalendar65, (double) 1, (double) (short) 10);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem0 and viagem34", Math.signum(viagem0.compareTo(viagem34)) == -Math.signum(viagem34.compareTo(viagem0)));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test080");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem();
        viagem8.setTempo(10.0d);
        boolean b12 = viagem8.equals((java.lang.Object) 100L);
        double d13 = viagem8.getTempo();
        viagem8.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str16 = viagem8.toString();
        viagem8.setMail("");
        double d19 = viagem8.getDesvio();
        int i20 = viagem0.compareTo(viagem8);
        Viagem viagem21 = viagem8.clone();
        viagem21.setTempo((double) (short) 0);
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem8, viagem21, and viagem8", !(viagem8.compareTo(viagem21) > 0 && viagem21.compareTo(viagem8) > 0) || viagem8.compareTo(viagem8) > 0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test081");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        java.lang.String str3 = viagem2.getMail();
        Viagem viagem4 = new Viagem();
        java.lang.String str5 = viagem4.toString();
        Viagem viagem6 = viagem4.clone();
        Coordenada coordenada7 = viagem4.getcinicial();
        viagem2.setcfinal(coordenada7);
        Viagem viagem9 = new Viagem();
        viagem9.setTempo(10.0d);
        boolean b13 = viagem9.equals((java.lang.Object) 100L);
        double d14 = viagem9.getTempo();
        viagem9.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem17 = new Viagem(viagem9);
        Viagem viagem18 = viagem17.clone();
        Coordenada coordenada19 = viagem18.getcfinal();
        Viagem viagem20 = new Viagem();
        viagem20.setTempo(10.0d);
        boolean b24 = viagem20.equals((java.lang.Object) 100L);
        double d25 = viagem20.getTempo();
        viagem20.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str28 = viagem20.toString();
        viagem20.setMail("");
        Viagem viagem31 = new Viagem(viagem20);
        int i32 = viagem18.compareTo(viagem31);
        double d33 = viagem18.getDesvio();
        Viagem viagem34 = viagem18.clone();
        java.lang.String str35 = viagem34.toString();
        Viagem viagem36 = new Viagem();
        viagem36.setTempo(10.0d);
        boolean b40 = viagem36.equals((java.lang.Object) 100L);
        Viagem viagem41 = new Viagem(viagem36);
        java.lang.String str42 = viagem36.getMail();
        Viagem viagem43 = new Viagem();
        viagem43.setTempo(10.0d);
        boolean b47 = viagem43.equals((java.lang.Object) 100L);
        Viagem viagem48 = new Viagem(viagem43);
        java.lang.String str49 = viagem43.getMail();
        boolean b50 = viagem36.equals((java.lang.Object) viagem43);
        Viagem viagem51 = new Viagem();
        viagem51.setTempo(10.0d);
        boolean b55 = viagem51.equals((java.lang.Object) 100L);
        Viagem viagem56 = new Viagem(viagem51);
        java.util.GregorianCalendar gregorianCalendar57 = viagem51.getData();
        java.lang.String str58 = viagem51.toString();
        double d59 = viagem51.getPreco();
        Coordenada coordenada60 = viagem51.getcinicial();
        viagem43.setcfinal(coordenada60);
        viagem34.setcinicial(coordenada60);
        viagem2.setcfinal(coordenada60);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem51 and viagem4", Math.signum(viagem51.compareTo(viagem4)) == -Math.signum(viagem4.compareTo(viagem51)));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test082");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        viagem0.setMail("hi!");
        Coordenada coordenada4 = viagem0.getcfinal();
        double d5 = viagem0.getPreco();
        Viagem viagem6 = new Viagem();
        java.lang.String str7 = viagem6.toString();
        double d8 = viagem6.getPreco();
        Coordenada coordenada9 = viagem6.getcfinal();
        viagem6.setMail("hi!");
        int i12 = viagem0.compareTo(viagem6);
        Viagem viagem13 = new Viagem();
        viagem13.setTempo(10.0d);
        boolean b17 = viagem13.equals((java.lang.Object) 100L);
        double d18 = viagem13.getTempo();
        viagem13.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem21 = new Viagem(viagem13);
        Viagem viagem22 = viagem21.clone();
        Coordenada coordenada23 = viagem22.getcfinal();
        Viagem viagem24 = new Viagem();
        viagem24.setTempo(10.0d);
        boolean b28 = viagem24.equals((java.lang.Object) 100L);
        double d29 = viagem24.getTempo();
        viagem24.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str32 = viagem24.toString();
        viagem24.setMail("");
        Viagem viagem35 = new Viagem(viagem24);
        int i36 = viagem22.compareTo(viagem35);
        double d37 = viagem22.getDesvio();
        double d38 = viagem22.getDesvio();
        Viagem viagem39 = new Viagem();
        viagem39.setTempo(10.0d);
        boolean b43 = viagem39.equals((java.lang.Object) 100L);
        Viagem viagem44 = new Viagem(viagem39);
        double d45 = viagem39.getTempo();
        double d46 = viagem39.getPreco();
        double d47 = viagem39.getPreco();
        double d48 = viagem39.getDesvio();
        Viagem viagem49 = new Viagem();
        viagem49.setTempo(10.0d);
        boolean b53 = viagem49.equals((java.lang.Object) 100L);
        Viagem viagem54 = viagem49.clone();
        Viagem viagem55 = new Viagem();
        viagem55.setTempo(10.0d);
        boolean b59 = viagem55.equals((java.lang.Object) 100L);
        double d60 = viagem55.getTempo();
        viagem55.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str63 = viagem55.toString();
        viagem55.setMail("");
        double d66 = viagem55.getDesvio();
        java.util.GregorianCalendar gregorianCalendar67 = viagem55.getData();
        int i68 = viagem54.compareTo(viagem55);
        Viagem viagem69 = viagem54.clone();
        Coordenada coordenada70 = viagem54.getcinicial();
        viagem39.setcinicial(coordenada70);
        viagem22.setcfinal(coordenada70);
        viagem0.setcinicial(coordenada70);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem21 and viagem6", Math.signum(viagem21.compareTo(viagem6)) == -Math.signum(viagem6.compareTo(viagem21)));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test083");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        Coordenada coordenada3 = viagem0.getcinicial();
        Viagem viagem4 = viagem0.clone();
        java.lang.String str5 = viagem4.toString();
        Viagem viagem6 = new Viagem();
        viagem6.setTempo(10.0d);
        boolean b10 = viagem6.equals((java.lang.Object) 100L);
        double d11 = viagem6.getTempo();
        viagem6.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem14 = new Viagem(viagem6);
        Coordenada coordenada15 = viagem6.getcfinal();
        Viagem viagem16 = new Viagem();
        viagem16.setTempo(10.0d);
        boolean b20 = viagem16.equals((java.lang.Object) 100L);
        Coordenada coordenada21 = viagem16.getcfinal();
        double d22 = viagem16.getTempo();
        Viagem viagem23 = new Viagem(viagem16);
        int i24 = viagem6.compareTo(viagem16);
        double d25 = viagem6.getDesvio();
        Viagem viagem26 = viagem6.clone();
        boolean b27 = viagem4.equals((java.lang.Object) viagem26);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem6 and viagem0", Math.signum(viagem6.compareTo(viagem0)) == -Math.signum(viagem0.compareTo(viagem6)));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test084");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        java.lang.String str3 = viagem0.toString();
        Viagem viagem4 = new Viagem();
        viagem4.setTempo(10.0d);
        boolean b8 = viagem4.equals((java.lang.Object) 100L);
        Viagem viagem9 = viagem4.clone();
        Coordenada coordenada10 = viagem9.getcfinal();
        java.util.GregorianCalendar gregorianCalendar11 = viagem9.getData();
        Coordenada coordenada12 = viagem9.getcfinal();
        boolean b13 = viagem0.equals((java.lang.Object) viagem9);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem2 and viagem4", Math.signum(viagem2.compareTo(viagem4)) == -Math.signum(viagem4.compareTo(viagem2)));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test085");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        Coordenada coordenada3 = viagem0.getcinicial();
        Viagem viagem4 = viagem0.clone();
        Coordenada coordenada5 = viagem0.getcfinal();
        Viagem viagem6 = new Viagem();
        viagem6.setTempo(10.0d);
        boolean b10 = viagem6.equals((java.lang.Object) 100L);
        double d11 = viagem6.getTempo();
        viagem6.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem14 = new Viagem(viagem6);
        Viagem viagem15 = viagem14.clone();
        Coordenada coordenada16 = viagem15.getcfinal();
        Viagem viagem17 = new Viagem();
        viagem17.setTempo(10.0d);
        boolean b21 = viagem17.equals((java.lang.Object) 100L);
        double d22 = viagem17.getTempo();
        viagem17.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str25 = viagem17.toString();
        viagem17.setMail("");
        Viagem viagem28 = new Viagem(viagem17);
        int i29 = viagem15.compareTo(viagem28);
        Viagem viagem30 = new Viagem();
        viagem30.setTempo(10.0d);
        boolean b34 = viagem30.equals((java.lang.Object) 100L);
        Viagem viagem35 = viagem30.clone();
        Viagem viagem36 = new Viagem();
        viagem36.setTempo(10.0d);
        boolean b40 = viagem36.equals((java.lang.Object) 100L);
        double d41 = viagem36.getTempo();
        viagem36.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str44 = viagem36.toString();
        viagem36.setMail("");
        double d47 = viagem36.getDesvio();
        java.util.GregorianCalendar gregorianCalendar48 = viagem36.getData();
        int i49 = viagem35.compareTo(viagem36);
        Viagem viagem50 = viagem35.clone();
        Coordenada coordenada51 = viagem35.getcfinal();
        viagem15.setcfinal(coordenada51);
        Viagem viagem53 = new Viagem();
        viagem53.setTempo(10.0d);
        boolean b57 = viagem53.equals((java.lang.Object) 100L);
        Viagem viagem58 = viagem53.clone();
        Viagem viagem59 = new Viagem(viagem53);
        Viagem viagem60 = new Viagem();
        viagem60.setTempo(10.0d);
        boolean b64 = viagem60.equals((java.lang.Object) 100L);
        Viagem viagem65 = viagem60.clone();
        Viagem viagem66 = new Viagem(viagem60);
        int i67 = viagem53.compareTo(viagem60);
        viagem60.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Coordenada coordenada70 = viagem60.getcinicial();
        viagem15.setcinicial(coordenada70);
        viagem0.setcinicial(coordenada70);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem2 and viagem59", Math.signum(viagem2.compareTo(viagem59)) == -Math.signum(viagem59.compareTo(viagem2)));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test086");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        Coordenada coordenada3 = viagem0.getcfinal();
        Viagem viagem4 = new Viagem();
        viagem4.setTempo(10.0d);
        boolean b8 = viagem4.equals((java.lang.Object) 100L);
        double d9 = viagem4.getTempo();
        Coordenada coordenada10 = viagem4.getcfinal();
        viagem0.setcfinal(coordenada10);
        Viagem viagem12 = new Viagem();
        java.lang.String str13 = viagem12.toString();
        Viagem viagem14 = viagem12.clone();
        double d15 = viagem12.getPreco();
        double d16 = viagem12.getPreco();
        boolean b17 = viagem0.equals((java.lang.Object) d16);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem4 and viagem12", Math.signum(viagem4.compareTo(viagem12)) == -Math.signum(viagem12.compareTo(viagem4)));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test087");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        Viagem viagem3 = new Viagem();
        viagem3.setTempo(10.0d);
        boolean b7 = viagem3.equals((java.lang.Object) 100L);
        double d8 = viagem3.getTempo();
        Coordenada coordenada9 = viagem3.getcfinal();
        Viagem viagem10 = new Viagem();
        viagem10.setTempo(10.0d);
        boolean b14 = viagem10.equals((java.lang.Object) 100L);
        java.util.GregorianCalendar gregorianCalendar15 = viagem10.getData();
        Coordenada coordenada16 = viagem10.getcinicial();
        Viagem viagem17 = new Viagem();
        viagem17.setTempo(10.0d);
        boolean b21 = viagem17.equals((java.lang.Object) 100L);
        double d22 = viagem17.getTempo();
        viagem17.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem25 = new Viagem();
        viagem25.setTempo(10.0d);
        boolean b29 = viagem25.equals((java.lang.Object) 100L);
        double d30 = viagem25.getTempo();
        viagem25.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str33 = viagem25.toString();
        viagem25.setMail("");
        double d36 = viagem25.getDesvio();
        int i37 = viagem17.compareTo(viagem25);
        Coordenada coordenada38 = viagem17.getcinicial();
        viagem10.setcinicial(coordenada38);
        viagem3.setcinicial(coordenada38);
        viagem2.setcinicial(coordenada38);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem3 and viagem0", Math.signum(viagem3.compareTo(viagem0)) == -Math.signum(viagem0.compareTo(viagem3)));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test088");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        Coordenada coordenada3 = viagem0.getcinicial();
        Viagem viagem4 = new Viagem(viagem0);
        Viagem viagem5 = new Viagem(viagem0);
        Viagem viagem6 = new Viagem();
        viagem6.setTempo(10.0d);
        boolean b10 = viagem6.equals((java.lang.Object) 100L);
        Coordenada coordenada11 = viagem6.getcfinal();
        viagem0.setcfinal(coordenada11);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem4 and viagem6", Math.signum(viagem4.compareTo(viagem6)) == -Math.signum(viagem6.compareTo(viagem4)));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test089");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        java.util.GregorianCalendar gregorianCalendar9 = viagem0.getData();
        Viagem viagem10 = new Viagem();
        viagem10.setTempo(10.0d);
        boolean b14 = viagem10.equals((java.lang.Object) 100L);
        Viagem viagem15 = viagem10.clone();
        Viagem viagem16 = new Viagem(viagem10);
        Viagem viagem17 = viagem10.clone();
        double d18 = viagem17.getPreco();
        Coordenada coordenada19 = viagem17.getcinicial();
        viagem0.setcfinal(coordenada19);
        Coordenada coordenada21 = viagem0.getcinicial();
        Viagem viagem22 = new Viagem();
        java.lang.String str23 = viagem22.toString();
        viagem22.setMail("hi!");
        Coordenada coordenada26 = viagem22.getcfinal();
        Viagem viagem29 = new Viagem();
        viagem29.setTempo(10.0d);
        boolean b33 = viagem29.equals((java.lang.Object) 100L);
        double d34 = viagem29.getTempo();
        viagem29.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Coordenada coordenada37 = viagem29.getcfinal();
        java.util.GregorianCalendar gregorianCalendar38 = viagem29.getData();
        Viagem viagem41 = new Viagem(coordenada21, coordenada26, (double) (short) 10, "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00", gregorianCalendar38, (double) (short) -1, (double) 0L);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem22 and viagem10", Math.signum(viagem22.compareTo(viagem10)) == -Math.signum(viagem10.compareTo(viagem22)));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test090");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        java.lang.String str3 = viagem0.getMail();
        Viagem viagem4 = new Viagem(viagem0);
        Viagem viagem5 = new Viagem();
        viagem5.setTempo(10.0d);
        boolean b9 = viagem5.equals((java.lang.Object) 100L);
        Coordenada coordenada10 = viagem5.getcfinal();
        viagem4.setcfinal(coordenada10);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem0 and viagem5", Math.signum(viagem0.compareTo(viagem5)) == -Math.signum(viagem5.compareTo(viagem0)));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test091");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str8 = viagem0.toString();
        viagem0.setMail("");
        Viagem viagem11 = new Viagem(viagem0);
        Viagem viagem12 = new Viagem();
        java.lang.String str13 = viagem12.toString();
        Viagem viagem14 = viagem12.clone();
        java.lang.String str15 = viagem14.getMail();
        Viagem viagem16 = new Viagem();
        java.lang.String str17 = viagem16.toString();
        Viagem viagem18 = viagem16.clone();
        Coordenada coordenada19 = viagem16.getcinicial();
        viagem14.setcfinal(coordenada19);
        double d21 = viagem14.getDesvio();
        Viagem viagem22 = new Viagem();
        java.lang.String str23 = viagem22.toString();
        Viagem viagem24 = viagem22.clone();
        Coordenada coordenada25 = viagem22.getcinicial();
        java.lang.Object obj26 = null;
        boolean b27 = viagem22.equals(obj26);
        int i28 = viagem14.compareTo(viagem22);
        Viagem viagem29 = viagem22.clone();
        Viagem viagem30 = viagem29.clone();
        Coordenada coordenada31 = viagem29.getcinicial();
        viagem11.setcfinal(coordenada31);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem16 and viagem0", Math.signum(viagem16.compareTo(viagem0)) == -Math.signum(viagem0.compareTo(viagem16)));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test092");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Coordenada coordenada9 = viagem0.getcfinal();
        Viagem viagem10 = new Viagem();
        viagem10.setTempo(10.0d);
        boolean b14 = viagem10.equals((java.lang.Object) 100L);
        java.util.GregorianCalendar gregorianCalendar15 = viagem10.getData();
        Coordenada coordenada16 = viagem10.getcinicial();
        Viagem viagem19 = new Viagem();
        java.lang.String str20 = viagem19.toString();
        double d21 = viagem19.getPreco();
        Coordenada coordenada22 = viagem19.getcfinal();
        viagem19.setMail("hi!");
        Viagem viagem25 = new Viagem();
        java.lang.String str26 = viagem25.toString();
        Viagem viagem27 = viagem25.clone();
        java.lang.String str28 = viagem27.getMail();
        Viagem viagem29 = new Viagem();
        java.lang.String str30 = viagem29.toString();
        Viagem viagem31 = viagem29.clone();
        Coordenada coordenada32 = viagem29.getcinicial();
        viagem27.setcfinal(coordenada32);
        viagem19.setcinicial(coordenada32);
        java.util.GregorianCalendar gregorianCalendar35 = viagem19.getData();
        Viagem viagem38 = new Viagem(coordenada9, coordenada16, (double) (-1), "", gregorianCalendar35, (double) '#', 1.0d);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem0 and viagem31", Math.signum(viagem0.compareTo(viagem31)) == -Math.signum(viagem31.compareTo(viagem0)));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test093");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        double d3 = viagem2.getDesvio();
        Viagem viagem4 = viagem2.clone();
        double d5 = viagem2.getPreco();
        double d6 = viagem2.getTempo();
        Viagem viagem7 = new Viagem();
        viagem7.setTempo(10.0d);
        boolean b11 = viagem7.equals((java.lang.Object) 100L);
        double d12 = viagem7.getTempo();
        viagem7.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem15 = new Viagem();
        viagem15.setTempo(10.0d);
        boolean b19 = viagem15.equals((java.lang.Object) 100L);
        double d20 = viagem15.getTempo();
        viagem15.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str23 = viagem15.toString();
        viagem15.setMail("");
        double d26 = viagem15.getDesvio();
        int i27 = viagem7.compareTo(viagem15);
        Coordenada coordenada28 = viagem15.getcfinal();
        viagem2.setcfinal(coordenada28);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem7 and viagem0", Math.signum(viagem7.compareTo(viagem0)) == -Math.signum(viagem0.compareTo(viagem7)));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test094");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        java.lang.String str3 = viagem2.getMail();
        Viagem viagem4 = new Viagem();
        java.lang.String str5 = viagem4.toString();
        Viagem viagem6 = viagem4.clone();
        Coordenada coordenada7 = viagem4.getcinicial();
        viagem2.setcfinal(coordenada7);
        double d9 = viagem2.getDesvio();
        Viagem viagem10 = new Viagem();
        java.lang.String str11 = viagem10.toString();
        Viagem viagem12 = viagem10.clone();
        Coordenada coordenada13 = viagem10.getcinicial();
        java.lang.Object obj14 = null;
        boolean b15 = viagem10.equals(obj14);
        int i16 = viagem2.compareTo(viagem10);
        Viagem viagem17 = viagem10.clone();
        viagem10.setTempo((double) (short) 0);
        double d20 = viagem10.getPreco();
        Viagem viagem21 = new Viagem();
        java.lang.String str22 = viagem21.toString();
        viagem21.setMail("hi!");
        Coordenada coordenada25 = viagem21.getcfinal();
        double d26 = viagem21.getPreco();
        viagem21.setTempo(100.0d);
        int i29 = viagem10.compareTo(viagem21);
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem2, viagem21, and viagem2", !(viagem2.compareTo(viagem21) > 0 && viagem21.compareTo(viagem2) > 0) || viagem2.compareTo(viagem2) > 0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test095");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        double d3 = viagem0.getTempo();
        Viagem viagem4 = new Viagem();
        java.lang.String str5 = viagem4.toString();
        Viagem viagem6 = viagem4.clone();
        Coordenada coordenada7 = viagem4.getcinicial();
        Viagem viagem8 = viagem4.clone();
        Coordenada coordenada9 = viagem4.getcfinal();
        viagem0.setcfinal(coordenada9);
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem8, viagem0, and viagem8", !(viagem8.compareTo(viagem0) > 0 && viagem0.compareTo(viagem8) > 0) || viagem8.compareTo(viagem8) > 0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test096");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = new Viagem(viagem0);
        Coordenada coordenada3 = viagem2.getcinicial();
        Coordenada coordenada4 = viagem2.getcfinal();
        java.lang.String str5 = viagem2.toString();
        java.lang.String str6 = viagem2.toString();
        java.lang.String str7 = viagem2.toString();
        double d8 = viagem2.getTempo();
        viagem2.setTempo((double) (short) 10);
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem0, viagem2, and viagem0", !(viagem0.compareTo(viagem2) > 0 && viagem2.compareTo(viagem0) > 0) || viagem0.compareTo(viagem0) > 0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test097");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = new Viagem(viagem0);
        Coordenada coordenada3 = viagem2.getcinicial();
        Coordenada coordenada4 = viagem2.getcfinal();
        Viagem viagem5 = new Viagem();
        viagem5.setTempo(10.0d);
        boolean b9 = viagem5.equals((java.lang.Object) 100L);
        double d10 = viagem5.getTempo();
        viagem5.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str13 = viagem5.toString();
        viagem5.setMail("");
        Viagem viagem16 = new Viagem(viagem5);
        Coordenada coordenada17 = viagem5.getcfinal();
        Coordenada coordenada18 = viagem5.getcinicial();
        viagem2.setcinicial(coordenada18);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem5 and viagem0", Math.signum(viagem5.compareTo(viagem0)) == -Math.signum(viagem0.compareTo(viagem5)));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test098");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        double d6 = viagem0.getPreco();
        Viagem viagem7 = new Viagem();
        viagem7.setTempo(10.0d);
        boolean b11 = viagem7.equals((java.lang.Object) 100L);
        Viagem viagem12 = viagem7.clone();
        boolean b13 = viagem0.equals((java.lang.Object) viagem12);
        Viagem viagem14 = new Viagem();
        viagem14.setTempo(10.0d);
        boolean b18 = viagem14.equals((java.lang.Object) 100L);
        double d19 = viagem14.getTempo();
        viagem14.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str22 = viagem14.toString();
        viagem14.setMail("");
        Coordenada coordenada25 = viagem14.getcinicial();
        viagem0.setcinicial(coordenada25);
        Viagem viagem27 = new Viagem();
        java.lang.String str28 = viagem27.toString();
        Viagem viagem29 = viagem27.clone();
        Coordenada coordenada30 = viagem27.getcinicial();
        Viagem viagem31 = new Viagem(viagem27);
        viagem31.setTempo((double) (short) 0);
        Viagem viagem34 = new Viagem();
        java.lang.String str35 = viagem34.toString();
        Viagem viagem36 = viagem34.clone();
        Coordenada coordenada37 = viagem34.getcinicial();
        boolean b38 = viagem31.equals((java.lang.Object) coordenada37);
        viagem0.setcinicial(coordenada37);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem7 and viagem34", Math.signum(viagem7.compareTo(viagem34)) == -Math.signum(viagem34.compareTo(viagem7)));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test099");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Coordenada coordenada5 = viagem0.getcfinal();
        Coordenada coordenada6 = viagem0.getcinicial();
        Coordenada coordenada7 = viagem0.getcinicial();
        Viagem viagem8 = new Viagem();
        viagem8.setTempo(10.0d);
        boolean b12 = viagem8.equals((java.lang.Object) 100L);
        Coordenada coordenada13 = viagem8.getcfinal();
        double d14 = viagem8.getTempo();
        Viagem viagem15 = new Viagem(viagem8);
        Coordenada coordenada16 = viagem8.getcfinal();
        Viagem viagem19 = new Viagem();
        viagem19.setTempo(10.0d);
        boolean b23 = viagem19.equals((java.lang.Object) 100L);
        Viagem viagem24 = viagem19.clone();
        Coordenada coordenada25 = viagem24.getcfinal();
        java.util.GregorianCalendar gregorianCalendar26 = viagem24.getData();
        Viagem viagem29 = new Viagem(coordenada7, coordenada16, (double) (short) 10, "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: -1.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00", gregorianCalendar26, (double) (byte) 10, (double) (short) -1);
        Viagem viagem30 = new Viagem();
        java.lang.String str31 = viagem30.toString();
        Viagem viagem32 = new Viagem(viagem30);
        Coordenada coordenada33 = viagem32.getcinicial();
        Viagem viagem36 = new Viagem();
        viagem36.setTempo(10.0d);
        boolean b40 = viagem36.equals((java.lang.Object) 100L);
        java.util.GregorianCalendar gregorianCalendar41 = viagem36.getData();
        Viagem viagem44 = new Viagem(coordenada16, coordenada33, (double) (-1), "", gregorianCalendar41, (double) (short) 1, (double) (-266));
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem0 and viagem32", Math.signum(viagem0.compareTo(viagem32)) == -Math.signum(viagem32.compareTo(viagem0)));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test100");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = new Viagem(viagem0);
        java.util.GregorianCalendar gregorianCalendar6 = viagem0.getData();
        java.lang.String str7 = viagem0.toString();
        double d8 = viagem0.getPreco();
        Viagem viagem9 = new Viagem();
        java.lang.String str10 = viagem9.toString();
        java.util.GregorianCalendar gregorianCalendar11 = viagem9.getData();
        viagem9.setTempo((double) (short) -1);
        Coordenada coordenada14 = viagem9.getcfinal();
        viagem0.setcinicial(coordenada14);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem9 and viagem5", Math.signum(viagem9.compareTo(viagem5)) == -Math.signum(viagem5.compareTo(viagem9)));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test101");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        double d8 = viagem0.getPreco();
        double d9 = viagem0.getPreco();
        Viagem viagem10 = new Viagem();
        viagem10.setTempo(10.0d);
        boolean b14 = viagem10.equals((java.lang.Object) 100L);
        Viagem viagem15 = new Viagem(viagem10);
        java.lang.String str16 = viagem10.getMail();
        Viagem viagem17 = new Viagem();
        viagem17.setTempo(10.0d);
        boolean b21 = viagem17.equals((java.lang.Object) 100L);
        Viagem viagem22 = new Viagem(viagem17);
        java.lang.String str23 = viagem17.getMail();
        boolean b24 = viagem10.equals((java.lang.Object) viagem17);
        Viagem viagem25 = new Viagem();
        viagem25.setTempo(10.0d);
        boolean b29 = viagem25.equals((java.lang.Object) 100L);
        Viagem viagem30 = viagem25.clone();
        Viagem viagem31 = new Viagem(viagem25);
        Viagem viagem32 = new Viagem();
        viagem32.setTempo(10.0d);
        boolean b36 = viagem32.equals((java.lang.Object) 100L);
        Viagem viagem37 = viagem32.clone();
        Viagem viagem38 = new Viagem(viagem32);
        int i39 = viagem25.compareTo(viagem32);
        viagem32.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        int i42 = viagem17.compareTo(viagem32);
        int i43 = viagem0.compareTo(viagem17);
        viagem17.setTempo((double) (byte) 100);
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem0, viagem17, and viagem0", !(viagem0.compareTo(viagem17) > 0 && viagem17.compareTo(viagem0) > 0) || viagem0.compareTo(viagem0) > 0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test102");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Viagem viagem6 = new Viagem(viagem0);
        Viagem viagem7 = viagem0.clone();
        Viagem viagem8 = new Viagem();
        viagem8.setTempo(10.0d);
        boolean b12 = viagem8.equals((java.lang.Object) 100L);
        double d13 = viagem8.getTempo();
        viagem8.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem16 = new Viagem(viagem8);
        Viagem viagem17 = viagem16.clone();
        Coordenada coordenada18 = viagem17.getcfinal();
        Viagem viagem19 = new Viagem();
        viagem19.setTempo(10.0d);
        boolean b23 = viagem19.equals((java.lang.Object) 100L);
        double d24 = viagem19.getTempo();
        viagem19.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str27 = viagem19.toString();
        viagem19.setMail("");
        Viagem viagem30 = new Viagem(viagem19);
        int i31 = viagem17.compareTo(viagem30);
        boolean b32 = viagem0.equals((java.lang.Object) i31);
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem35 = new Viagem();
        java.lang.String str36 = viagem35.toString();
        Viagem viagem37 = viagem35.clone();
        java.lang.String str38 = viagem37.getMail();
        Viagem viagem39 = new Viagem();
        java.lang.String str40 = viagem39.toString();
        Viagem viagem41 = viagem39.clone();
        Coordenada coordenada42 = viagem39.getcinicial();
        viagem37.setcfinal(coordenada42);
        double d44 = viagem37.getDesvio();
        Viagem viagem45 = new Viagem();
        java.lang.String str46 = viagem45.toString();
        Viagem viagem47 = viagem45.clone();
        Coordenada coordenada48 = viagem45.getcinicial();
        java.lang.Object obj49 = null;
        boolean b50 = viagem45.equals(obj49);
        int i51 = viagem37.compareTo(viagem45);
        Viagem viagem52 = viagem45.clone();
        Viagem viagem53 = viagem52.clone();
        Coordenada coordenada54 = viagem52.getcinicial();
        int i55 = viagem0.compareTo(viagem52);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem47 and viagem30", Math.signum(viagem47.compareTo(viagem30)) == -Math.signum(viagem30.compareTo(viagem47)));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test103");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Viagem viagem6 = new Viagem(viagem0);
        Viagem viagem7 = new Viagem();
        viagem7.setTempo(10.0d);
        boolean b11 = viagem7.equals((java.lang.Object) 100L);
        Viagem viagem12 = viagem7.clone();
        Viagem viagem13 = new Viagem(viagem7);
        int i14 = viagem0.compareTo(viagem7);
        viagem7.setMail("");
        java.util.GregorianCalendar gregorianCalendar17 = viagem7.getData();
        Coordenada coordenada18 = null;
        viagem7.setcinicial(coordenada18);
        org.junit.Assert.assertTrue("Contract failed: compareTo-reflexive on viagem7", viagem7.compareTo(viagem7) == 0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test104");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Viagem viagem6 = new Viagem(viagem0);
        Viagem viagem7 = viagem0.clone();
        double d8 = viagem7.getPreco();
        Coordenada coordenada9 = viagem7.getcinicial();
        java.lang.String str10 = viagem7.getMail();
        viagem7.setTempo(100.0d);
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem6, viagem7, and viagem6", !(viagem6.compareTo(viagem7) > 0 && viagem7.compareTo(viagem6) > 0) || viagem6.compareTo(viagem6) > 0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test105");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        double d3 = viagem0.getPreco();
        viagem0.setTempo((double) (short) -1);
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem2, viagem0, and viagem2", !(viagem2.compareTo(viagem0) > 0 && viagem0.compareTo(viagem2) > 0) || viagem2.compareTo(viagem2) > 0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test106");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str8 = viagem0.toString();
        viagem0.setMail("");
        Viagem viagem11 = new Viagem(viagem0);
        Coordenada coordenada12 = viagem0.getcfinal();
        Coordenada coordenada13 = viagem0.getcinicial();
        Viagem viagem14 = new Viagem();
        java.lang.String str15 = viagem14.toString();
        Viagem viagem16 = viagem14.clone();
        Coordenada coordenada17 = viagem14.getcinicial();
        Viagem viagem18 = new Viagem(viagem14);
        double d19 = viagem18.getPreco();
        Coordenada coordenada20 = viagem18.getcfinal();
        Viagem viagem21 = viagem18.clone();
        Coordenada coordenada22 = viagem18.getcfinal();
        Viagem viagem25 = new Viagem();
        java.lang.String str26 = viagem25.toString();
        Viagem viagem27 = new Viagem(viagem25);
        double d28 = viagem25.getPreco();
        java.util.GregorianCalendar gregorianCalendar29 = viagem25.getData();
        Viagem viagem32 = new Viagem(coordenada13, coordenada22, (double) 'a', "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00", gregorianCalendar29, (double) 0, (double) 10);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem16 and viagem0", Math.signum(viagem16.compareTo(viagem0)) == -Math.signum(viagem0.compareTo(viagem16)));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test107");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        java.util.GregorianCalendar gregorianCalendar5 = viagem0.getData();
        Coordenada coordenada6 = viagem0.getcinicial();
        Viagem viagem7 = new Viagem();
        viagem7.setTempo(10.0d);
        boolean b11 = viagem7.equals((java.lang.Object) 100L);
        double d12 = viagem7.getTempo();
        viagem7.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem15 = new Viagem(viagem7);
        Viagem viagem16 = viagem15.clone();
        Coordenada coordenada17 = viagem16.getcfinal();
        boolean b18 = viagem0.equals((java.lang.Object) coordenada17);
        Viagem viagem19 = new Viagem();
        viagem19.setTempo(10.0d);
        boolean b23 = viagem19.equals((java.lang.Object) 100L);
        double d24 = viagem19.getTempo();
        viagem19.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem27 = new Viagem(viagem19);
        Viagem viagem28 = viagem27.clone();
        Coordenada coordenada29 = viagem28.getcfinal();
        Viagem viagem30 = new Viagem();
        viagem30.setTempo(10.0d);
        boolean b34 = viagem30.equals((java.lang.Object) 100L);
        double d35 = viagem30.getTempo();
        viagem30.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem38 = new Viagem();
        viagem38.setTempo(10.0d);
        boolean b42 = viagem38.equals((java.lang.Object) 100L);
        double d43 = viagem38.getTempo();
        viagem38.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str46 = viagem38.toString();
        viagem38.setMail("");
        double d49 = viagem38.getDesvio();
        int i50 = viagem30.compareTo(viagem38);
        double d51 = viagem30.getPreco();
        Viagem viagem52 = new Viagem();
        viagem52.setTempo(10.0d);
        boolean b56 = viagem52.equals((java.lang.Object) 100L);
        double d57 = viagem52.getTempo();
        viagem52.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str60 = viagem52.toString();
        viagem52.setMail("");
        Coordenada coordenada63 = viagem52.getcinicial();
        viagem30.setcinicial(coordenada63);
        viagem28.setcfinal(coordenada63);
        Viagem viagem68 = new Viagem();
        viagem68.setTempo(10.0d);
        boolean b72 = viagem68.equals((java.lang.Object) 100L);
        Coordenada coordenada73 = viagem68.getcfinal();
        double d74 = viagem68.getTempo();
        Viagem viagem75 = new Viagem(viagem68);
        viagem68.setTempo((double) (byte) 10);
        java.util.GregorianCalendar gregorianCalendar78 = viagem68.getData();
        Viagem viagem81 = new Viagem(coordenada17, coordenada63, (double) 100L, "", gregorianCalendar78, (double) (-1), (double) (byte) 10);
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem16, viagem81, and viagem16", !(viagem16.compareTo(viagem81) > 0 && viagem81.compareTo(viagem16) > 0) || viagem16.compareTo(viagem16) > 0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test108");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        Coordenada coordenada3 = viagem0.getcinicial();
        Viagem viagem4 = new Viagem(viagem0);
        viagem4.setTempo((double) (short) 0);
        Viagem viagem7 = new Viagem();
        java.lang.String str8 = viagem7.toString();
        Viagem viagem9 = viagem7.clone();
        Coordenada coordenada10 = viagem7.getcinicial();
        boolean b11 = viagem4.equals((java.lang.Object) coordenada10);
        Viagem viagem12 = new Viagem();
        viagem12.setTempo(10.0d);
        boolean b16 = viagem12.equals((java.lang.Object) 100L);
        Viagem viagem17 = new Viagem(viagem12);
        java.util.GregorianCalendar gregorianCalendar18 = viagem12.getData();
        java.lang.String str19 = viagem12.toString();
        java.lang.String str20 = viagem12.getMail();
        Viagem viagem21 = new Viagem();
        viagem21.setTempo(10.0d);
        boolean b25 = viagem21.equals((java.lang.Object) 100L);
        Coordenada coordenada26 = viagem21.getcfinal();
        Viagem viagem27 = new Viagem();
        viagem27.setTempo(10.0d);
        boolean b31 = viagem27.equals((java.lang.Object) 100L);
        Viagem viagem32 = viagem27.clone();
        Coordenada coordenada33 = viagem32.getcfinal();
        viagem21.setcinicial(coordenada33);
        viagem12.setcfinal(coordenada33);
        Viagem viagem38 = new Viagem();
        viagem38.setTempo(10.0d);
        boolean b42 = viagem38.equals((java.lang.Object) 100L);
        Coordenada coordenada43 = viagem38.getcfinal();
        double d44 = viagem38.getTempo();
        Viagem viagem45 = new Viagem(viagem38);
        viagem38.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        double d48 = viagem38.getTempo();
        double d49 = viagem38.getTempo();
        java.util.GregorianCalendar gregorianCalendar50 = viagem38.getData();
        Viagem viagem53 = new Viagem(coordenada10, coordenada33, (double) (byte) -1, "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00", gregorianCalendar50, 1.0d, (double) (-266));
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem7 and viagem17", Math.signum(viagem7.compareTo(viagem17)) == -Math.signum(viagem17.compareTo(viagem7)));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test109");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        Viagem viagem6 = new Viagem();
        viagem6.setTempo(10.0d);
        boolean b10 = viagem6.equals((java.lang.Object) 100L);
        double d11 = viagem6.getTempo();
        viagem6.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Coordenada coordenada14 = viagem6.getcfinal();
        viagem0.setcinicial(coordenada14);
        Viagem viagem16 = new Viagem();
        java.lang.String str17 = viagem16.toString();
        Viagem viagem18 = viagem16.clone();
        double d19 = viagem18.getDesvio();
        Viagem viagem20 = viagem18.clone();
        boolean b21 = viagem0.equals((java.lang.Object) viagem18);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem6 and viagem16", Math.signum(viagem6.compareTo(viagem16)) == -Math.signum(viagem16.compareTo(viagem6)));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test110");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        double d6 = viagem0.getPreco();
        Viagem viagem7 = new Viagem();
        viagem7.setTempo(10.0d);
        boolean b11 = viagem7.equals((java.lang.Object) 100L);
        Viagem viagem12 = viagem7.clone();
        boolean b13 = viagem0.equals((java.lang.Object) viagem12);
        Viagem viagem14 = new Viagem();
        viagem14.setTempo(10.0d);
        boolean b18 = viagem14.equals((java.lang.Object) 100L);
        double d19 = viagem14.getTempo();
        viagem14.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str22 = viagem14.toString();
        viagem14.setMail("");
        Coordenada coordenada25 = viagem14.getcinicial();
        viagem0.setcinicial(coordenada25);
        Viagem viagem27 = new Viagem();
        viagem27.setTempo(10.0d);
        boolean b31 = viagem27.equals((java.lang.Object) 100L);
        Coordenada coordenada32 = viagem27.getcfinal();
        Coordenada coordenada33 = viagem27.getcinicial();
        Viagem viagem36 = new Viagem();
        viagem36.setTempo(10.0d);
        boolean b40 = viagem36.equals((java.lang.Object) 100L);
        double d41 = viagem36.getTempo();
        viagem36.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Coordenada coordenada44 = viagem36.getcfinal();
        java.util.GregorianCalendar gregorianCalendar45 = viagem36.getData();
        Viagem viagem48 = new Viagem(coordenada25, coordenada33, 0.0d, "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00", gregorianCalendar45, (double) (byte) 10, (double) 100);
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem14, viagem48, and viagem14", !(viagem14.compareTo(viagem48) > 0 && viagem48.compareTo(viagem14) > 0) || viagem14.compareTo(viagem14) > 0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test111");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Coordenada coordenada9 = viagem0.getcfinal();
        Viagem viagem10 = new Viagem();
        viagem10.setTempo(10.0d);
        boolean b14 = viagem10.equals((java.lang.Object) 100L);
        Coordenada coordenada15 = viagem10.getcfinal();
        double d16 = viagem10.getTempo();
        Viagem viagem17 = new Viagem(viagem10);
        int i18 = viagem0.compareTo(viagem10);
        double d19 = viagem0.getTempo();
        Viagem viagem20 = new Viagem();
        java.lang.String str21 = viagem20.toString();
        viagem20.setMail("hi!");
        Coordenada coordenada24 = viagem20.getcfinal();
        double d25 = viagem20.getPreco();
        Viagem viagem26 = new Viagem();
        java.lang.String str27 = viagem26.toString();
        double d28 = viagem26.getPreco();
        Coordenada coordenada29 = viagem26.getcfinal();
        viagem26.setMail("hi!");
        int i32 = viagem20.compareTo(viagem26);
        Viagem viagem33 = new Viagem();
        java.lang.String str34 = viagem33.toString();
        Viagem viagem35 = new Viagem(viagem33);
        Coordenada coordenada36 = viagem35.getcinicial();
        Viagem viagem37 = new Viagem();
        java.lang.String str38 = viagem37.toString();
        Viagem viagem39 = viagem37.clone();
        java.lang.String str40 = viagem39.getMail();
        Viagem viagem41 = new Viagem();
        java.lang.String str42 = viagem41.toString();
        Viagem viagem43 = viagem41.clone();
        Coordenada coordenada44 = viagem41.getcinicial();
        viagem39.setcfinal(coordenada44);
        viagem35.setcfinal(coordenada44);
        viagem20.setcfinal(coordenada44);
        viagem0.setcfinal(coordenada44);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem41 and viagem17", Math.signum(viagem41.compareTo(viagem17)) == -Math.signum(viagem17.compareTo(viagem41)));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test112");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Coordenada coordenada9 = viagem0.getcfinal();
        Viagem viagem10 = new Viagem(viagem0);
        viagem0.setMail("");
        Viagem viagem13 = new Viagem();
        java.lang.String str14 = viagem13.toString();
        Viagem viagem15 = new Viagem(viagem13);
        Coordenada coordenada16 = viagem15.getcinicial();
        Coordenada coordenada17 = viagem15.getcfinal();
        java.lang.String str18 = viagem15.toString();
        Viagem viagem19 = new Viagem(viagem15);
        double d20 = viagem19.getDesvio();
        Coordenada coordenada21 = viagem19.getcfinal();
        viagem0.setcinicial(coordenada21);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem10 and viagem15", Math.signum(viagem10.compareTo(viagem15)) == -Math.signum(viagem15.compareTo(viagem10)));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test113");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        double d8 = viagem0.getPreco();
        Viagem viagem9 = new Viagem(viagem0);
        Viagem viagem10 = new Viagem();
        java.lang.String str11 = viagem10.toString();
        Viagem viagem12 = new Viagem(viagem10);
        Coordenada coordenada13 = viagem12.getcinicial();
        Coordenada coordenada14 = viagem12.getcfinal();
        java.lang.String str15 = viagem12.toString();
        java.lang.String str16 = viagem12.toString();
        Viagem viagem17 = new Viagem();
        java.lang.String str18 = viagem17.toString();
        Viagem viagem19 = viagem17.clone();
        java.lang.String str20 = viagem19.getMail();
        Viagem viagem21 = new Viagem();
        java.lang.String str22 = viagem21.toString();
        Viagem viagem23 = viagem21.clone();
        Coordenada coordenada24 = viagem21.getcinicial();
        viagem19.setcfinal(coordenada24);
        viagem12.setcfinal(coordenada24);
        viagem9.setcinicial(coordenada24);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem19 and viagem0", Math.signum(viagem19.compareTo(viagem0)) == -Math.signum(viagem0.compareTo(viagem19)));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test114");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        Coordenada coordenada6 = viagem0.getcfinal();
        Viagem viagem7 = new Viagem();
        viagem7.setTempo(10.0d);
        boolean b11 = viagem7.equals((java.lang.Object) 100L);
        Viagem viagem12 = viagem7.clone();
        Viagem viagem13 = new Viagem(viagem7);
        Viagem viagem14 = viagem7.clone();
        java.lang.String str15 = viagem7.toString();
        Viagem viagem16 = new Viagem();
        viagem16.setTempo(10.0d);
        boolean b20 = viagem16.equals((java.lang.Object) 100L);
        Coordenada coordenada21 = viagem16.getcfinal();
        Viagem viagem22 = new Viagem();
        viagem22.setTempo(10.0d);
        boolean b26 = viagem22.equals((java.lang.Object) 100L);
        Viagem viagem27 = viagem22.clone();
        Coordenada coordenada28 = viagem27.getcfinal();
        viagem16.setcinicial(coordenada28);
        viagem7.setcinicial(coordenada28);
        Viagem viagem33 = new Viagem();
        viagem33.setTempo(10.0d);
        boolean b37 = viagem33.equals((java.lang.Object) 100L);
        Coordenada coordenada38 = viagem33.getcfinal();
        Coordenada coordenada39 = viagem33.getcinicial();
        Coordenada coordenada40 = viagem33.getcinicial();
        Viagem viagem41 = new Viagem();
        viagem41.setTempo(10.0d);
        boolean b45 = viagem41.equals((java.lang.Object) 100L);
        Coordenada coordenada46 = viagem41.getcfinal();
        double d47 = viagem41.getTempo();
        Viagem viagem48 = new Viagem(viagem41);
        Coordenada coordenada49 = viagem41.getcfinal();
        Viagem viagem52 = new Viagem();
        viagem52.setTempo(10.0d);
        boolean b56 = viagem52.equals((java.lang.Object) 100L);
        Viagem viagem57 = viagem52.clone();
        Coordenada coordenada58 = viagem57.getcfinal();
        java.util.GregorianCalendar gregorianCalendar59 = viagem57.getData();
        Viagem viagem62 = new Viagem(coordenada40, coordenada49, (double) (short) 10, "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: -1.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00", gregorianCalendar59, (double) (byte) 10, (double) (short) -1);
        Viagem viagem65 = new Viagem(coordenada6, coordenada28, 0.0d, "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00", gregorianCalendar59, (double) (short) 10, (double) 0);
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem52, viagem65, and viagem52", !(viagem52.compareTo(viagem65) > 0 && viagem65.compareTo(viagem52) > 0) || viagem52.compareTo(viagem52) > 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test115");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        double d3 = viagem2.getDesvio();
        viagem2.setTempo((double) (byte) 10);
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem0, viagem2, and viagem0", !(viagem0.compareTo(viagem2) > 0 && viagem2.compareTo(viagem0) > 0) || viagem0.compareTo(viagem0) > 0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test116");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Coordenada coordenada5 = viagem0.getcfinal();
        double d6 = viagem0.getTempo();
        double d7 = viagem0.getDesvio();
        Viagem viagem8 = new Viagem();
        viagem8.setTempo(10.0d);
        boolean b12 = viagem8.equals((java.lang.Object) 100L);
        double d13 = viagem8.getTempo();
        viagem8.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str16 = viagem8.toString();
        viagem8.setMail("");
        Coordenada coordenada19 = viagem8.getcinicial();
        boolean b20 = viagem0.equals((java.lang.Object) coordenada19);
        java.lang.String str21 = viagem0.toString();
        viagem0.setTempo((double) '#');
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem8, viagem0, and viagem8", !(viagem8.compareTo(viagem0) > 0 && viagem0.compareTo(viagem8) > 0) || viagem8.compareTo(viagem8) > 0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test117");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Coordenada coordenada5 = viagem0.getcfinal();
        double d6 = viagem0.getTempo();
        double d7 = viagem0.getDesvio();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem10 = new Viagem();
        java.lang.String str11 = viagem10.toString();
        Viagem viagem12 = viagem10.clone();
        Coordenada coordenada13 = viagem10.getcinicial();
        Viagem viagem14 = new Viagem(viagem10);
        viagem14.setTempo((double) (short) 0);
        Viagem viagem17 = new Viagem();
        java.lang.String str18 = viagem17.toString();
        Viagem viagem19 = viagem17.clone();
        Coordenada coordenada20 = viagem17.getcinicial();
        boolean b21 = viagem14.equals((java.lang.Object) coordenada20);
        viagem0.setcfinal(coordenada20);
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem17, viagem0, and viagem17", !(viagem17.compareTo(viagem0) > 0 && viagem0.compareTo(viagem17) > 0) || viagem17.compareTo(viagem17) > 0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test118");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem();
        viagem8.setTempo(10.0d);
        boolean b12 = viagem8.equals((java.lang.Object) 100L);
        double d13 = viagem8.getTempo();
        viagem8.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str16 = viagem8.toString();
        viagem8.setMail("");
        double d19 = viagem8.getDesvio();
        int i20 = viagem0.compareTo(viagem8);
        double d21 = viagem0.getPreco();
        java.lang.String str22 = viagem0.toString();
        Viagem viagem23 = new Viagem();
        java.lang.String str24 = viagem23.toString();
        double d25 = viagem23.getPreco();
        Coordenada coordenada26 = viagem23.getcfinal();
        viagem23.setMail("hi!");
        Viagem viagem29 = new Viagem();
        java.lang.String str30 = viagem29.toString();
        Viagem viagem31 = viagem29.clone();
        java.lang.String str32 = viagem31.getMail();
        Viagem viagem33 = new Viagem();
        java.lang.String str34 = viagem33.toString();
        Viagem viagem35 = viagem33.clone();
        Coordenada coordenada36 = viagem33.getcinicial();
        viagem31.setcfinal(coordenada36);
        viagem23.setcinicial(coordenada36);
        viagem0.setcinicial(coordenada36);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem33 and viagem8", Math.signum(viagem33.compareTo(viagem8)) == -Math.signum(viagem8.compareTo(viagem33)));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test119");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Coordenada coordenada5 = viagem0.getcfinal();
        double d6 = viagem0.getTempo();
        Viagem viagem7 = new Viagem(viagem0);
        Coordenada coordenada8 = viagem0.getcfinal();
        Viagem viagem9 = new Viagem();
        viagem9.setTempo(10.0d);
        boolean b13 = viagem9.equals((java.lang.Object) 100L);
        Viagem viagem14 = viagem9.clone();
        Viagem viagem15 = new Viagem();
        viagem15.setTempo(10.0d);
        boolean b19 = viagem15.equals((java.lang.Object) 100L);
        double d20 = viagem15.getTempo();
        viagem15.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str23 = viagem15.toString();
        viagem15.setMail("");
        double d26 = viagem15.getDesvio();
        java.util.GregorianCalendar gregorianCalendar27 = viagem15.getData();
        int i28 = viagem14.compareTo(viagem15);
        Viagem viagem29 = viagem14.clone();
        Coordenada coordenada30 = viagem14.getcinicial();
        Viagem viagem33 = new Viagem();
        java.lang.String str34 = viagem33.toString();
        Viagem viagem35 = new Viagem(viagem33);
        Coordenada coordenada36 = viagem35.getcinicial();
        Coordenada coordenada37 = viagem35.getcfinal();
        java.util.GregorianCalendar gregorianCalendar38 = viagem35.getData();
        Viagem viagem41 = new Viagem(coordenada8, coordenada30, 10.0d, "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00", gregorianCalendar38, (double) 100.0f, (double) 'a');
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem33 and viagem7", Math.signum(viagem33.compareTo(viagem7)) == -Math.signum(viagem7.compareTo(viagem33)));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test120");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        java.lang.String str3 = viagem2.getMail();
        Viagem viagem4 = new Viagem();
        java.lang.String str5 = viagem4.toString();
        Viagem viagem6 = viagem4.clone();
        Coordenada coordenada7 = viagem4.getcinicial();
        viagem2.setcfinal(coordenada7);
        double d9 = viagem2.getDesvio();
        viagem2.setMail("hi!");
        java.lang.String str12 = viagem2.toString();
        Coordenada coordenada13 = viagem2.getcfinal();
        Viagem viagem14 = new Viagem();
        java.lang.String str15 = viagem14.toString();
        Viagem viagem16 = new Viagem(viagem14);
        double d17 = viagem14.getPreco();
        double d18 = viagem14.getPreco();
        Coordenada coordenada19 = viagem14.getcinicial();
        Viagem viagem22 = new Viagem();
        viagem22.setTempo(10.0d);
        boolean b26 = viagem22.equals((java.lang.Object) 100L);
        double d27 = viagem22.getTempo();
        Coordenada coordenada28 = viagem22.getcfinal();
        Viagem viagem29 = new Viagem();
        viagem29.setTempo(10.0d);
        boolean b33 = viagem29.equals((java.lang.Object) 100L);
        java.util.GregorianCalendar gregorianCalendar34 = viagem29.getData();
        Coordenada coordenada35 = viagem29.getcinicial();
        Viagem viagem36 = new Viagem();
        viagem36.setTempo(10.0d);
        boolean b40 = viagem36.equals((java.lang.Object) 100L);
        double d41 = viagem36.getTempo();
        viagem36.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem44 = new Viagem();
        viagem44.setTempo(10.0d);
        boolean b48 = viagem44.equals((java.lang.Object) 100L);
        double d49 = viagem44.getTempo();
        viagem44.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str52 = viagem44.toString();
        viagem44.setMail("");
        double d55 = viagem44.getDesvio();
        int i56 = viagem36.compareTo(viagem44);
        Coordenada coordenada57 = viagem36.getcinicial();
        viagem29.setcinicial(coordenada57);
        viagem22.setcinicial(coordenada57);
        java.util.GregorianCalendar gregorianCalendar60 = viagem22.getData();
        Viagem viagem63 = new Viagem(coordenada13, coordenada19, (double) 10, "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00", gregorianCalendar60, (double) ' ', (double) ' ');
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem6 and viagem29", Math.signum(viagem6.compareTo(viagem29)) == -Math.signum(viagem29.compareTo(viagem6)));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test121");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem();
        viagem8.setTempo(10.0d);
        boolean b12 = viagem8.equals((java.lang.Object) 100L);
        double d13 = viagem8.getTempo();
        viagem8.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str16 = viagem8.toString();
        viagem8.setMail("");
        double d19 = viagem8.getDesvio();
        int i20 = viagem0.compareTo(viagem8);
        Coordenada coordenada21 = viagem8.getcfinal();
        Viagem viagem22 = new Viagem();
        viagem22.setTempo((double) 0.0f);
        java.util.GregorianCalendar gregorianCalendar25 = viagem22.getData();
        Coordenada coordenada26 = viagem22.getcinicial();
        viagem8.setcinicial(coordenada26);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem0 and viagem22", Math.signum(viagem0.compareTo(viagem22)) == -Math.signum(viagem22.compareTo(viagem0)));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test122");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        double d3 = viagem0.getTempo();
        Coordenada coordenada4 = viagem0.getcfinal();
        double d5 = viagem0.getDesvio();
        double d6 = viagem0.getDesvio();
        Viagem viagem7 = new Viagem();
        java.lang.String str8 = viagem7.toString();
        Viagem viagem9 = viagem7.clone();
        java.lang.String str10 = viagem7.toString();
        Viagem viagem11 = new Viagem();
        java.lang.String str12 = viagem11.toString();
        Viagem viagem13 = viagem11.clone();
        java.lang.String str14 = viagem13.getMail();
        Viagem viagem15 = new Viagem();
        java.lang.String str16 = viagem15.toString();
        Viagem viagem17 = viagem15.clone();
        Coordenada coordenada18 = viagem15.getcinicial();
        viagem13.setcfinal(coordenada18);
        double d20 = viagem13.getDesvio();
        viagem13.setMail("hi!");
        java.lang.String str23 = viagem13.toString();
        Coordenada coordenada24 = viagem13.getcfinal();
        boolean b25 = viagem7.equals((java.lang.Object) coordenada24);
        viagem0.setcinicial(coordenada24);
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem17, viagem0, and viagem17", !(viagem17.compareTo(viagem0) > 0 && viagem0.compareTo(viagem17) > 0) || viagem17.compareTo(viagem17) > 0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test123");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Coordenada coordenada9 = viagem0.getcfinal();
        Viagem viagem10 = new Viagem(viagem0);
        Coordenada coordenada11 = viagem10.getcinicial();
        Viagem viagem12 = new Viagem();
        java.lang.String str13 = viagem12.toString();
        Viagem viagem14 = viagem12.clone();
        Coordenada coordenada15 = viagem12.getcinicial();
        Viagem viagem16 = viagem12.clone();
        Coordenada coordenada17 = viagem12.getcfinal();
        Viagem viagem20 = new Viagem();
        viagem20.setTempo(10.0d);
        boolean b24 = viagem20.equals((java.lang.Object) 100L);
        Viagem viagem25 = new Viagem(viagem20);
        java.util.GregorianCalendar gregorianCalendar26 = viagem20.getData();
        Viagem viagem29 = new Viagem(coordenada11, coordenada17, (double) 100L, "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: -1.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00", gregorianCalendar26, (double) (byte) 0, (double) 10);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem20 and viagem16", Math.signum(viagem20.compareTo(viagem16)) == -Math.signum(viagem16.compareTo(viagem20)));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test124");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        Coordenada coordenada6 = viagem0.getcfinal();
        Viagem viagem7 = new Viagem();
        java.lang.String str8 = viagem7.toString();
        Viagem viagem9 = viagem7.clone();
        Coordenada coordenada10 = viagem7.getcinicial();
        Viagem viagem11 = new Viagem(viagem7);
        double d12 = viagem11.getPreco();
        Coordenada coordenada13 = viagem11.getcinicial();
        Viagem viagem16 = new Viagem();
        java.lang.String str17 = viagem16.toString();
        viagem16.setMail("hi!");
        Coordenada coordenada20 = viagem16.getcfinal();
        viagem16.setTempo(0.0d);
        viagem16.setMail("hi!");
        java.util.GregorianCalendar gregorianCalendar25 = viagem16.getData();
        Viagem viagem28 = new Viagem(coordenada6, coordenada13, (double) 100L, "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00", gregorianCalendar25, (double) (short) 0, (double) (-527));
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem0 and viagem7", Math.signum(viagem0.compareTo(viagem7)) == -Math.signum(viagem7.compareTo(viagem0)));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test125");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Viagem viagem6 = new Viagem(viagem0);
        Viagem viagem7 = viagem0.clone();
        Viagem viagem8 = new Viagem();
        viagem8.setTempo(10.0d);
        boolean b12 = viagem8.equals((java.lang.Object) 100L);
        double d13 = viagem8.getTempo();
        viagem8.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem16 = new Viagem(viagem8);
        Viagem viagem17 = viagem16.clone();
        Coordenada coordenada18 = viagem17.getcfinal();
        Viagem viagem19 = new Viagem();
        viagem19.setTempo(10.0d);
        boolean b23 = viagem19.equals((java.lang.Object) 100L);
        double d24 = viagem19.getTempo();
        viagem19.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str27 = viagem19.toString();
        viagem19.setMail("");
        Viagem viagem30 = new Viagem(viagem19);
        int i31 = viagem17.compareTo(viagem30);
        boolean b32 = viagem0.equals((java.lang.Object) i31);
        Viagem viagem33 = new Viagem(viagem0);
        Viagem viagem34 = new Viagem();
        viagem34.setTempo(10.0d);
        boolean b38 = viagem34.equals((java.lang.Object) 100L);
        Viagem viagem39 = new Viagem(viagem34);
        java.lang.String str40 = viagem34.getMail();
        Viagem viagem41 = new Viagem();
        viagem41.setTempo(10.0d);
        boolean b45 = viagem41.equals((java.lang.Object) 100L);
        Viagem viagem46 = new Viagem(viagem41);
        java.lang.String str47 = viagem41.getMail();
        boolean b48 = viagem34.equals((java.lang.Object) viagem41);
        Viagem viagem49 = new Viagem();
        viagem49.setTempo(10.0d);
        boolean b53 = viagem49.equals((java.lang.Object) 100L);
        Viagem viagem54 = new Viagem(viagem49);
        java.util.GregorianCalendar gregorianCalendar55 = viagem49.getData();
        java.lang.String str56 = viagem49.toString();
        double d57 = viagem49.getPreco();
        Coordenada coordenada58 = viagem49.getcinicial();
        viagem41.setcfinal(coordenada58);
        viagem33.setcfinal(coordenada58);
        Viagem viagem61 = new Viagem();
        viagem61.setTempo(10.0d);
        boolean b65 = viagem61.equals((java.lang.Object) 100L);
        Viagem viagem66 = viagem61.clone();
        Viagem viagem67 = new Viagem(viagem61);
        Viagem viagem68 = new Viagem(viagem61);
        Coordenada coordenada69 = viagem61.getcfinal();
        Viagem viagem72 = new Viagem();
        viagem72.setTempo(10.0d);
        boolean b76 = viagem72.equals((java.lang.Object) 100L);
        java.util.GregorianCalendar gregorianCalendar77 = viagem72.getData();
        Viagem viagem80 = new Viagem(coordenada58, coordenada69, (double) 1L, "hi!", gregorianCalendar77, (double) 10L, (double) (-527));
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem49, viagem80, and viagem49", !(viagem49.compareTo(viagem80) > 0 && viagem80.compareTo(viagem49) > 0) || viagem49.compareTo(viagem49) > 0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test126");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Viagem viagem9 = viagem0.clone();
        Viagem viagem10 = new Viagem();
        viagem10.setTempo(10.0d);
        boolean b14 = viagem10.equals((java.lang.Object) 100L);
        Viagem viagem15 = viagem10.clone();
        Viagem viagem16 = new Viagem(viagem10);
        Viagem viagem17 = viagem10.clone();
        int i18 = viagem0.compareTo(viagem17);
        double d19 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        viagem0.setTempo((double) 100.0f);
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem15, viagem0, and viagem15", !(viagem15.compareTo(viagem0) > 0 && viagem0.compareTo(viagem15) > 0) || viagem15.compareTo(viagem15) > 0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test127");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        java.lang.String str9 = viagem0.toString();
        Coordenada coordenada10 = viagem0.getcfinal();
        Viagem viagem11 = new Viagem();
        java.lang.String str12 = viagem11.toString();
        double d13 = viagem11.getPreco();
        double d14 = viagem11.getPreco();
        viagem11.setTempo(100.0d);
        boolean b17 = viagem0.equals((java.lang.Object) viagem11);
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem8, viagem11, and viagem8", !(viagem8.compareTo(viagem11) > 0 && viagem11.compareTo(viagem8) > 0) || viagem8.compareTo(viagem8) > 0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test128");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Viagem viagem6 = new Viagem();
        viagem6.setTempo(10.0d);
        boolean b10 = viagem6.equals((java.lang.Object) 100L);
        double d11 = viagem6.getTempo();
        viagem6.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str14 = viagem6.toString();
        viagem6.setMail("");
        double d17 = viagem6.getDesvio();
        java.util.GregorianCalendar gregorianCalendar18 = viagem6.getData();
        int i19 = viagem5.compareTo(viagem6);
        Viagem viagem20 = new Viagem();
        viagem20.setTempo(10.0d);
        boolean b24 = viagem20.equals((java.lang.Object) 100L);
        double d25 = viagem20.getTempo();
        double d26 = viagem20.getPreco();
        Viagem viagem27 = new Viagem();
        viagem27.setTempo(10.0d);
        boolean b31 = viagem27.equals((java.lang.Object) 100L);
        Viagem viagem32 = viagem27.clone();
        boolean b33 = viagem20.equals((java.lang.Object) viagem32);
        Viagem viagem34 = new Viagem();
        viagem34.setTempo(10.0d);
        boolean b38 = viagem34.equals((java.lang.Object) 100L);
        double d39 = viagem34.getTempo();
        viagem34.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str42 = viagem34.toString();
        viagem34.setMail("");
        Coordenada coordenada45 = viagem34.getcinicial();
        viagem20.setcinicial(coordenada45);
        Viagem viagem47 = new Viagem();
        viagem47.setTempo(10.0d);
        boolean b51 = viagem47.equals((java.lang.Object) 100L);
        Viagem viagem52 = viagem47.clone();
        int i53 = viagem20.compareTo(viagem52);
        boolean b54 = viagem5.equals((java.lang.Object) viagem52);
        Viagem viagem55 = new Viagem();
        java.lang.String str56 = viagem55.toString();
        viagem55.setMail("hi!");
        Coordenada coordenada59 = viagem55.getcfinal();
        double d60 = viagem55.getPreco();
        Viagem viagem61 = new Viagem();
        java.lang.String str62 = viagem61.toString();
        double d63 = viagem61.getPreco();
        Coordenada coordenada64 = viagem61.getcfinal();
        viagem61.setMail("hi!");
        int i67 = viagem55.compareTo(viagem61);
        double d68 = viagem61.getDesvio();
        Coordenada coordenada69 = viagem61.getcinicial();
        int i70 = viagem52.compareTo(viagem61);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem47 and viagem55", Math.signum(viagem47.compareTo(viagem55)) == -Math.signum(viagem55.compareTo(viagem47)));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test129");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        Coordenada coordenada3 = viagem0.getcfinal();
        java.lang.String str4 = viagem0.toString();
        Viagem viagem5 = new Viagem();
        viagem5.setTempo(10.0d);
        Coordenada coordenada8 = viagem5.getcfinal();
        viagem0.setcfinal(coordenada8);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem5 and viagem2", Math.signum(viagem5.compareTo(viagem2)) == -Math.signum(viagem2.compareTo(viagem5)));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test130");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = new Viagem(viagem0);
        Coordenada coordenada3 = viagem2.getcinicial();
        Coordenada coordenada4 = viagem2.getcfinal();
        java.lang.String str5 = viagem2.toString();
        java.lang.String str6 = viagem2.toString();
        Viagem viagem7 = new Viagem();
        java.lang.String str8 = viagem7.toString();
        Viagem viagem9 = viagem7.clone();
        java.lang.String str10 = viagem9.getMail();
        Viagem viagem11 = new Viagem();
        java.lang.String str12 = viagem11.toString();
        Viagem viagem13 = viagem11.clone();
        Coordenada coordenada14 = viagem11.getcinicial();
        viagem9.setcfinal(coordenada14);
        viagem2.setcfinal(coordenada14);
        double d17 = viagem2.getPreco();
        java.lang.String str18 = viagem2.toString();
        Viagem viagem19 = new Viagem();
        viagem19.setTempo(10.0d);
        boolean b23 = viagem19.equals((java.lang.Object) 100L);
        Viagem viagem24 = viagem19.clone();
        Viagem viagem25 = new Viagem(viagem19);
        Viagem viagem26 = new Viagem();
        viagem26.setTempo(10.0d);
        boolean b30 = viagem26.equals((java.lang.Object) 100L);
        Viagem viagem31 = viagem26.clone();
        Viagem viagem32 = new Viagem(viagem26);
        int i33 = viagem19.compareTo(viagem26);
        viagem26.setMail("");
        int i36 = viagem2.compareTo(viagem26);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem7 and viagem32", Math.signum(viagem7.compareTo(viagem32)) == -Math.signum(viagem32.compareTo(viagem7)));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test131");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Coordenada coordenada8 = viagem0.getcinicial();
        Viagem viagem9 = new Viagem();
        java.lang.String str10 = viagem9.toString();
        Viagem viagem11 = new Viagem(viagem9);
        Viagem viagem12 = new Viagem();
        java.lang.String str13 = viagem12.toString();
        Viagem viagem14 = viagem12.clone();
        Coordenada coordenada15 = viagem12.getcfinal();
        Coordenada coordenada16 = viagem12.getcfinal();
        viagem11.setcinicial(coordenada16);
        Viagem viagem20 = new Viagem();
        viagem20.setTempo((double) 0.0f);
        java.util.GregorianCalendar gregorianCalendar23 = viagem20.getData();
        Viagem viagem26 = new Viagem(coordenada8, coordenada16, (double) (byte) 1, "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00", gregorianCalendar23, (double) 10, (double) '#');
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem11 and viagem0", Math.signum(viagem11.compareTo(viagem0)) == -Math.signum(viagem0.compareTo(viagem11)));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test132");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Coordenada coordenada5 = viagem0.getcfinal();
        double d6 = viagem0.getTempo();
        Viagem viagem7 = new Viagem(viagem0);
        Viagem viagem8 = new Viagem();
        viagem8.setTempo(10.0d);
        boolean b12 = viagem8.equals((java.lang.Object) 100L);
        Viagem viagem13 = viagem8.clone();
        Viagem viagem14 = new Viagem(viagem8);
        boolean b15 = viagem0.equals((java.lang.Object) viagem14);
        double d16 = viagem14.getDesvio();
        Viagem viagem17 = viagem14.clone();
        Viagem viagem18 = new Viagem();
        java.lang.String str19 = viagem18.toString();
        Viagem viagem20 = viagem18.clone();
        Coordenada coordenada21 = viagem18.getcinicial();
        Viagem viagem22 = viagem18.clone();
        Coordenada coordenada23 = viagem22.getcfinal();
        viagem17.setcinicial(coordenada23);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem20 and viagem7", Math.signum(viagem20.compareTo(viagem7)) == -Math.signum(viagem7.compareTo(viagem20)));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test133");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        java.lang.String str3 = viagem2.getMail();
        Viagem viagem4 = new Viagem();
        java.lang.String str5 = viagem4.toString();
        Viagem viagem6 = viagem4.clone();
        Coordenada coordenada7 = viagem4.getcinicial();
        viagem2.setcfinal(coordenada7);
        double d9 = viagem2.getDesvio();
        viagem2.setMail("hi!");
        Viagem viagem12 = new Viagem();
        viagem12.setTempo(10.0d);
        boolean b16 = viagem12.equals((java.lang.Object) 100L);
        Viagem viagem17 = viagem12.clone();
        Viagem viagem18 = new Viagem(viagem12);
        Viagem viagem19 = viagem12.clone();
        double d20 = viagem19.getPreco();
        Coordenada coordenada21 = viagem19.getcinicial();
        Viagem viagem22 = new Viagem(viagem19);
        boolean b23 = viagem2.equals((java.lang.Object) viagem19);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem22 and viagem6", Math.signum(viagem22.compareTo(viagem6)) == -Math.signum(viagem6.compareTo(viagem22)));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test134");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        java.lang.String str3 = viagem2.getMail();
        Viagem viagem4 = new Viagem();
        java.lang.String str5 = viagem4.toString();
        Viagem viagem6 = viagem4.clone();
        Coordenada coordenada7 = viagem4.getcinicial();
        viagem2.setcfinal(coordenada7);
        double d9 = viagem2.getDesvio();
        viagem2.setMail("hi!");
        java.lang.String str12 = viagem2.toString();
        java.util.GregorianCalendar gregorianCalendar13 = viagem2.getData();
        viagem2.setTempo((double) 10);
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem4, viagem2, and viagem4", !(viagem4.compareTo(viagem2) > 0 && viagem2.compareTo(viagem4) > 0) || viagem4.compareTo(viagem4) > 0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test135");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = new Viagem(viagem0);
        Coordenada coordenada3 = viagem2.getcinicial();
        viagem2.setTempo((double) (byte) 100);
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem0, viagem2, and viagem0", !(viagem0.compareTo(viagem2) > 0 && viagem2.compareTo(viagem0) > 0) || viagem0.compareTo(viagem0) > 0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test136");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem();
        viagem8.setTempo(10.0d);
        boolean b12 = viagem8.equals((java.lang.Object) 100L);
        double d13 = viagem8.getTempo();
        viagem8.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str16 = viagem8.toString();
        viagem8.setMail("");
        double d19 = viagem8.getDesvio();
        int i20 = viagem0.compareTo(viagem8);
        Viagem viagem21 = new Viagem();
        java.lang.String str22 = viagem21.toString();
        Viagem viagem23 = viagem21.clone();
        java.lang.String str24 = viagem23.getMail();
        Viagem viagem25 = new Viagem();
        java.lang.String str26 = viagem25.toString();
        Viagem viagem27 = viagem25.clone();
        Coordenada coordenada28 = viagem25.getcinicial();
        viagem23.setcfinal(coordenada28);
        double d30 = viagem23.getDesvio();
        Viagem viagem31 = viagem23.clone();
        boolean b32 = viagem8.equals((java.lang.Object) viagem23);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem31 and viagem0", Math.signum(viagem31.compareTo(viagem0)) == -Math.signum(viagem0.compareTo(viagem31)));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test137");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        Coordenada coordenada3 = viagem0.getcfinal();
        java.lang.String str4 = viagem0.toString();
        double d5 = viagem0.getPreco();
        Viagem viagem6 = new Viagem();
        viagem6.setTempo(10.0d);
        boolean b10 = viagem6.equals((java.lang.Object) 100L);
        Viagem viagem11 = viagem6.clone();
        Viagem viagem12 = new Viagem(viagem6);
        Viagem viagem13 = viagem6.clone();
        Viagem viagem14 = new Viagem();
        viagem14.setTempo(10.0d);
        boolean b18 = viagem14.equals((java.lang.Object) 100L);
        double d19 = viagem14.getTempo();
        viagem14.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem22 = new Viagem(viagem14);
        Viagem viagem23 = viagem22.clone();
        Coordenada coordenada24 = viagem23.getcfinal();
        Viagem viagem25 = new Viagem();
        viagem25.setTempo(10.0d);
        boolean b29 = viagem25.equals((java.lang.Object) 100L);
        double d30 = viagem25.getTempo();
        viagem25.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str33 = viagem25.toString();
        viagem25.setMail("");
        Viagem viagem36 = new Viagem(viagem25);
        int i37 = viagem23.compareTo(viagem36);
        boolean b38 = viagem6.equals((java.lang.Object) i37);
        Viagem viagem39 = new Viagem(viagem6);
        Coordenada coordenada40 = viagem6.getcinicial();
        Coordenada coordenada41 = viagem6.getcfinal();
        viagem0.setcinicial(coordenada41);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem13 and viagem2", Math.signum(viagem13.compareTo(viagem2)) == -Math.signum(viagem2.compareTo(viagem13)));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test138");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        double d6 = viagem0.getPreco();
        Viagem viagem7 = new Viagem(viagem0);
        java.lang.Object obj8 = null;
        boolean b9 = viagem0.equals(obj8);
        Viagem viagem10 = new Viagem();
        java.lang.String str11 = viagem10.toString();
        Viagem viagem12 = viagem10.clone();
        Coordenada coordenada13 = viagem10.getcinicial();
        Viagem viagem14 = viagem10.clone();
        Coordenada coordenada15 = viagem14.getcfinal();
        viagem0.setcfinal(coordenada15);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem14 and viagem7", Math.signum(viagem14.compareTo(viagem7)) == -Math.signum(viagem7.compareTo(viagem14)));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test139");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        Coordenada coordenada3 = viagem0.getcinicial();
        Viagem viagem4 = new Viagem(viagem0);
        viagem4.setTempo((double) (short) 0);
        Viagem viagem7 = new Viagem();
        viagem7.setTempo(10.0d);
        boolean b11 = viagem7.equals((java.lang.Object) 100L);
        Coordenada coordenada12 = viagem7.getcfinal();
        Viagem viagem13 = new Viagem();
        viagem13.setTempo(10.0d);
        boolean b17 = viagem13.equals((java.lang.Object) 100L);
        Viagem viagem18 = viagem13.clone();
        Coordenada coordenada19 = viagem18.getcfinal();
        viagem7.setcinicial(coordenada19);
        viagem4.setcfinal(coordenada19);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem7 and viagem0", Math.signum(viagem7.compareTo(viagem0)) == -Math.signum(viagem0.compareTo(viagem7)));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test140");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Coordenada coordenada9 = viagem0.getcfinal();
        Viagem viagem10 = new Viagem();
        viagem10.setTempo(10.0d);
        boolean b14 = viagem10.equals((java.lang.Object) 100L);
        Coordenada coordenada15 = viagem10.getcfinal();
        double d16 = viagem10.getTempo();
        Viagem viagem17 = new Viagem(viagem10);
        int i18 = viagem0.compareTo(viagem10);
        double d19 = viagem0.getPreco();
        Viagem viagem20 = new Viagem();
        viagem20.setTempo(10.0d);
        boolean b24 = viagem20.equals((java.lang.Object) 100L);
        double d25 = viagem20.getTempo();
        viagem20.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem28 = new Viagem(viagem20);
        Coordenada coordenada29 = viagem20.getcfinal();
        viagem0.setcfinal(coordenada29);
        Viagem viagem31 = viagem0.clone();
        double d32 = viagem0.getTempo();
        Viagem viagem33 = viagem0.clone();
        viagem0.setTempo((double) 1L);
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem8, viagem0, and viagem8", !(viagem8.compareTo(viagem0) > 0 && viagem0.compareTo(viagem8) > 0) || viagem8.compareTo(viagem8) > 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test141");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = new Viagem(viagem0);
        java.lang.String str3 = viagem2.toString();
        Viagem viagem4 = new Viagem();
        viagem4.setTempo(10.0d);
        boolean b8 = viagem4.equals((java.lang.Object) 100L);
        double d9 = viagem4.getTempo();
        viagem4.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem12 = new Viagem(viagem4);
        Viagem viagem13 = viagem12.clone();
        Coordenada coordenada14 = viagem13.getcfinal();
        Viagem viagem15 = new Viagem();
        viagem15.setTempo(10.0d);
        boolean b19 = viagem15.equals((java.lang.Object) 100L);
        double d20 = viagem15.getTempo();
        viagem15.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str23 = viagem15.toString();
        viagem15.setMail("");
        Viagem viagem26 = new Viagem(viagem15);
        int i27 = viagem13.compareTo(viagem26);
        double d28 = viagem13.getDesvio();
        double d29 = viagem13.getDesvio();
        boolean b30 = viagem2.equals((java.lang.Object) d29);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem4 and viagem0", Math.signum(viagem4.compareTo(viagem0)) == -Math.signum(viagem0.compareTo(viagem4)));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test142");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = new Viagem(viagem0);
        Coordenada coordenada3 = viagem2.getcinicial();
        Coordenada coordenada4 = viagem2.getcfinal();
        java.lang.String str5 = viagem2.toString();
        Coordenada coordenada6 = viagem2.getcfinal();
        Viagem viagem7 = new Viagem();
        viagem7.setTempo(10.0d);
        boolean b11 = viagem7.equals((java.lang.Object) 100L);
        Viagem viagem12 = viagem7.clone();
        Viagem viagem13 = new Viagem();
        viagem13.setTempo(10.0d);
        boolean b17 = viagem13.equals((java.lang.Object) 100L);
        double d18 = viagem13.getTempo();
        viagem13.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str21 = viagem13.toString();
        viagem13.setMail("");
        double d24 = viagem13.getDesvio();
        java.util.GregorianCalendar gregorianCalendar25 = viagem13.getData();
        int i26 = viagem12.compareTo(viagem13);
        Viagem viagem27 = viagem12.clone();
        Coordenada coordenada28 = viagem12.getcinicial();
        Viagem viagem31 = new Viagem();
        viagem31.setTempo(10.0d);
        boolean b35 = viagem31.equals((java.lang.Object) 100L);
        Coordenada coordenada36 = viagem31.getcfinal();
        double d37 = viagem31.getTempo();
        Viagem viagem38 = new Viagem(viagem31);
        viagem31.setTempo((double) (byte) 10);
        java.util.GregorianCalendar gregorianCalendar41 = viagem31.getData();
        Viagem viagem44 = new Viagem(coordenada6, coordenada28, (double) (short) 1, "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00", gregorianCalendar41, (double) (short) -1, (double) (-527));
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem31 and viagem2", Math.signum(viagem31.compareTo(viagem2)) == -Math.signum(viagem2.compareTo(viagem31)));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test143");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Coordenada coordenada5 = viagem0.getcfinal();
        double d6 = viagem0.getTempo();
        Viagem viagem7 = new Viagem(viagem0);
        Coordenada coordenada8 = viagem0.getcfinal();
        Viagem viagem9 = new Viagem();
        viagem9.setTempo(10.0d);
        boolean b13 = viagem9.equals((java.lang.Object) 100L);
        double d14 = viagem9.getTempo();
        viagem9.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem17 = new Viagem(viagem9);
        java.util.GregorianCalendar gregorianCalendar18 = viagem9.getData();
        Viagem viagem19 = new Viagem();
        viagem19.setTempo(10.0d);
        boolean b23 = viagem19.equals((java.lang.Object) 100L);
        Viagem viagem24 = viagem19.clone();
        Viagem viagem25 = new Viagem(viagem19);
        Viagem viagem26 = viagem19.clone();
        double d27 = viagem26.getPreco();
        Coordenada coordenada28 = viagem26.getcinicial();
        viagem9.setcfinal(coordenada28);
        Viagem viagem32 = new Viagem();
        java.lang.String str33 = viagem32.toString();
        Viagem viagem34 = new Viagem(viagem32);
        Coordenada coordenada35 = viagem34.getcinicial();
        Coordenada coordenada36 = viagem34.getcfinal();
        java.util.GregorianCalendar gregorianCalendar37 = viagem34.getData();
        Viagem viagem40 = new Viagem(coordenada8, coordenada28, (double) 263, "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00", gregorianCalendar37, 100.0d, (double) ' ');
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem25 and viagem32", Math.signum(viagem25.compareTo(viagem32)) == -Math.signum(viagem32.compareTo(viagem25)));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test144");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Coordenada coordenada5 = viagem0.getcfinal();
        double d6 = viagem0.getTempo();
        Viagem viagem7 = new Viagem(viagem0);
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        double d10 = viagem0.getTempo();
        double d11 = viagem0.getTempo();
        java.util.GregorianCalendar gregorianCalendar12 = viagem0.getData();
        Viagem viagem13 = viagem0.clone();
        Viagem viagem14 = new Viagem(viagem0);
        Viagem viagem15 = new Viagem(viagem0);
        Coordenada coordenada16 = viagem0.getcinicial();
        Viagem viagem17 = new Viagem();
        viagem17.setTempo(10.0d);
        boolean b21 = viagem17.equals((java.lang.Object) 100L);
        double d22 = viagem17.getTempo();
        viagem17.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem25 = new Viagem(viagem17);
        Coordenada coordenada26 = viagem17.getcfinal();
        Viagem viagem29 = new Viagem();
        viagem29.setTempo(10.0d);
        boolean b33 = viagem29.equals((java.lang.Object) 100L);
        Coordenada coordenada34 = viagem29.getcfinal();
        Coordenada coordenada35 = viagem29.getcinicial();
        Coordenada coordenada36 = viagem29.getcinicial();
        Viagem viagem37 = new Viagem();
        viagem37.setTempo(10.0d);
        boolean b41 = viagem37.equals((java.lang.Object) 100L);
        Coordenada coordenada42 = viagem37.getcfinal();
        double d43 = viagem37.getTempo();
        Viagem viagem44 = new Viagem(viagem37);
        Coordenada coordenada45 = viagem37.getcfinal();
        Viagem viagem48 = new Viagem();
        viagem48.setTempo(10.0d);
        boolean b52 = viagem48.equals((java.lang.Object) 100L);
        Viagem viagem53 = viagem48.clone();
        Coordenada coordenada54 = viagem53.getcfinal();
        java.util.GregorianCalendar gregorianCalendar55 = viagem53.getData();
        Viagem viagem58 = new Viagem(coordenada36, coordenada45, (double) (short) 10, "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: -1.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00", gregorianCalendar55, (double) (byte) 10, (double) (short) -1);
        Viagem viagem61 = new Viagem(coordenada16, coordenada26, 100.0d, "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: -1.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00", gregorianCalendar55, (double) '#', (double) (short) 100);
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem58, viagem61, and viagem58", !(viagem58.compareTo(viagem61) > 0 && viagem61.compareTo(viagem58) > 0) || viagem58.compareTo(viagem58) > 0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test145");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        java.lang.String str3 = viagem2.getMail();
        Viagem viagem4 = new Viagem();
        java.lang.String str5 = viagem4.toString();
        Viagem viagem6 = viagem4.clone();
        Coordenada coordenada7 = viagem4.getcinicial();
        viagem2.setcfinal(coordenada7);
        double d9 = viagem2.getDesvio();
        Viagem viagem10 = viagem2.clone();
        viagem10.setTempo((double) 1L);
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem2, viagem10, and viagem2", !(viagem2.compareTo(viagem10) > 0 && viagem10.compareTo(viagem2) > 0) || viagem2.compareTo(viagem2) > 0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test146");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem();
        viagem8.setTempo(10.0d);
        boolean b12 = viagem8.equals((java.lang.Object) 100L);
        double d13 = viagem8.getTempo();
        viagem8.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str16 = viagem8.toString();
        viagem8.setMail("");
        double d19 = viagem8.getDesvio();
        int i20 = viagem0.compareTo(viagem8);
        Coordenada coordenada21 = viagem8.getcfinal();
        Viagem viagem22 = new Viagem();
        java.lang.String str23 = viagem22.toString();
        Viagem viagem24 = viagem22.clone();
        java.lang.String str25 = viagem24.getMail();
        Viagem viagem26 = new Viagem();
        java.lang.String str27 = viagem26.toString();
        Viagem viagem28 = viagem26.clone();
        Coordenada coordenada29 = viagem26.getcinicial();
        viagem24.setcfinal(coordenada29);
        Viagem viagem33 = new Viagem();
        viagem33.setTempo((double) 0.0f);
        java.util.GregorianCalendar gregorianCalendar36 = viagem33.getData();
        Viagem viagem39 = new Viagem(coordenada21, coordenada29, (double) (short) 1, "hi!", gregorianCalendar36, (-1.0d), (double) (-263));
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem0 and viagem28", Math.signum(viagem0.compareTo(viagem28)) == -Math.signum(viagem28.compareTo(viagem0)));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test147");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        double d3 = viagem2.getDesvio();
        Viagem viagem4 = viagem2.clone();
        Viagem viagem5 = new Viagem();
        viagem5.setTempo(10.0d);
        boolean b9 = viagem5.equals((java.lang.Object) 100L);
        Coordenada coordenada10 = viagem5.getcfinal();
        double d11 = viagem5.getTempo();
        Viagem viagem12 = new Viagem(viagem5);
        viagem5.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.util.GregorianCalendar gregorianCalendar15 = viagem5.getData();
        boolean b16 = viagem4.equals((java.lang.Object) gregorianCalendar15);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem0 and viagem5", Math.signum(viagem0.compareTo(viagem5)) == -Math.signum(viagem5.compareTo(viagem0)));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test148");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem();
        viagem8.setTempo(10.0d);
        boolean b12 = viagem8.equals((java.lang.Object) 100L);
        double d13 = viagem8.getTempo();
        viagem8.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str16 = viagem8.toString();
        viagem8.setMail("");
        double d19 = viagem8.getDesvio();
        int i20 = viagem0.compareTo(viagem8);
        Viagem viagem21 = viagem0.clone();
        Viagem viagem22 = new Viagem();
        viagem22.setTempo(10.0d);
        boolean b26 = viagem22.equals((java.lang.Object) 100L);
        double d27 = viagem22.getTempo();
        viagem22.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem30 = new Viagem(viagem22);
        java.util.GregorianCalendar gregorianCalendar31 = viagem22.getData();
        Viagem viagem32 = viagem22.clone();
        int i33 = viagem21.compareTo(viagem22);
        Viagem viagem34 = new Viagem();
        java.lang.String str35 = viagem34.toString();
        Viagem viagem36 = viagem34.clone();
        java.lang.String str37 = viagem36.getMail();
        Viagem viagem38 = new Viagem();
        java.lang.String str39 = viagem38.toString();
        Viagem viagem40 = viagem38.clone();
        Coordenada coordenada41 = viagem38.getcinicial();
        viagem36.setcfinal(coordenada41);
        double d43 = viagem36.getDesvio();
        Viagem viagem44 = new Viagem();
        java.lang.String str45 = viagem44.toString();
        Viagem viagem46 = viagem44.clone();
        Coordenada coordenada47 = viagem44.getcinicial();
        java.lang.Object obj48 = null;
        boolean b49 = viagem44.equals(obj48);
        int i50 = viagem36.compareTo(viagem44);
        Viagem viagem51 = viagem44.clone();
        viagem44.setTempo((double) (short) 0);
        Viagem viagem54 = viagem44.clone();
        int i55 = viagem21.compareTo(viagem54);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem32 and viagem36", Math.signum(viagem32.compareTo(viagem36)) == -Math.signum(viagem36.compareTo(viagem32)));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test149");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Viagem viagem9 = viagem8.clone();
        Coordenada coordenada10 = viagem9.getcfinal();
        Viagem viagem11 = new Viagem();
        viagem11.setTempo(10.0d);
        boolean b15 = viagem11.equals((java.lang.Object) 100L);
        double d16 = viagem11.getTempo();
        viagem11.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str19 = viagem11.toString();
        viagem11.setMail("");
        Viagem viagem22 = new Viagem(viagem11);
        int i23 = viagem9.compareTo(viagem22);
        Viagem viagem24 = new Viagem();
        java.lang.String str25 = viagem24.toString();
        Viagem viagem26 = viagem24.clone();
        Coordenada coordenada27 = viagem24.getcinicial();
        Viagem viagem28 = new Viagem(viagem24);
        viagem28.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str31 = viagem28.toString();
        int i32 = viagem22.compareTo(viagem28);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem24 and viagem0", Math.signum(viagem24.compareTo(viagem0)) == -Math.signum(viagem0.compareTo(viagem24)));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test150");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        Coordenada coordenada3 = viagem0.getcfinal();
        Viagem viagem4 = new Viagem();
        viagem4.setTempo(10.0d);
        boolean b8 = viagem4.equals((java.lang.Object) 100L);
        java.util.GregorianCalendar gregorianCalendar9 = viagem4.getData();
        Coordenada coordenada10 = viagem4.getcinicial();
        Viagem viagem11 = new Viagem();
        viagem11.setTempo(10.0d);
        boolean b15 = viagem11.equals((java.lang.Object) 100L);
        double d16 = viagem11.getTempo();
        viagem11.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem19 = new Viagem();
        viagem19.setTempo(10.0d);
        boolean b23 = viagem19.equals((java.lang.Object) 100L);
        double d24 = viagem19.getTempo();
        viagem19.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str27 = viagem19.toString();
        viagem19.setMail("");
        double d30 = viagem19.getDesvio();
        int i31 = viagem11.compareTo(viagem19);
        Coordenada coordenada32 = viagem11.getcinicial();
        viagem4.setcinicial(coordenada32);
        Viagem viagem36 = new Viagem();
        viagem36.setTempo(10.0d);
        boolean b40 = viagem36.equals((java.lang.Object) 100L);
        Coordenada coordenada41 = viagem36.getcfinal();
        Coordenada coordenada42 = viagem36.getcinicial();
        Coordenada coordenada43 = viagem36.getcinicial();
        Viagem viagem44 = new Viagem();
        viagem44.setTempo(10.0d);
        boolean b48 = viagem44.equals((java.lang.Object) 100L);
        Coordenada coordenada49 = viagem44.getcfinal();
        double d50 = viagem44.getTempo();
        Viagem viagem51 = new Viagem(viagem44);
        Coordenada coordenada52 = viagem44.getcfinal();
        Viagem viagem55 = new Viagem();
        viagem55.setTempo(10.0d);
        boolean b59 = viagem55.equals((java.lang.Object) 100L);
        Viagem viagem60 = viagem55.clone();
        Coordenada coordenada61 = viagem60.getcfinal();
        java.util.GregorianCalendar gregorianCalendar62 = viagem60.getData();
        Viagem viagem65 = new Viagem(coordenada43, coordenada52, (double) (short) 10, "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: -1.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00", gregorianCalendar62, (double) (byte) 10, (double) (short) -1);
        Viagem viagem68 = new Viagem(coordenada3, coordenada32, (double) (-266), "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00", gregorianCalendar62, (double) (byte) -1, (double) 1L);
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem65, viagem68, and viagem65", !(viagem65.compareTo(viagem68) > 0 && viagem68.compareTo(viagem65) > 0) || viagem65.compareTo(viagem65) > 0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test151");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = new Viagem(viagem0);
        Viagem viagem3 = new Viagem();
        java.lang.String str4 = viagem3.toString();
        Viagem viagem5 = viagem3.clone();
        Coordenada coordenada6 = viagem3.getcfinal();
        Coordenada coordenada7 = viagem3.getcfinal();
        viagem2.setcinicial(coordenada7);
        Viagem viagem9 = new Viagem();
        viagem9.setTempo(10.0d);
        boolean b13 = viagem9.equals((java.lang.Object) 100L);
        Coordenada coordenada14 = viagem9.getcfinal();
        Viagem viagem17 = new Viagem();
        java.lang.String str18 = viagem17.toString();
        viagem17.setMail("hi!");
        Coordenada coordenada21 = viagem17.getcfinal();
        viagem17.setTempo(0.0d);
        java.lang.String str24 = viagem17.toString();
        java.util.GregorianCalendar gregorianCalendar25 = viagem17.getData();
        java.lang.String str26 = viagem17.getMail();
        java.util.GregorianCalendar gregorianCalendar27 = viagem17.getData();
        Viagem viagem30 = new Viagem(coordenada7, coordenada14, (double) '#', "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00", gregorianCalendar27, 100.0d, (double) (short) 10);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem0 and viagem9", Math.signum(viagem0.compareTo(viagem9)) == -Math.signum(viagem9.compareTo(viagem0)));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test152");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Coordenada coordenada5 = viagem0.getcfinal();
        double d6 = viagem0.getTempo();
        Viagem viagem7 = new Viagem(viagem0);
        viagem0.setTempo((double) (byte) 10);
        Viagem viagem10 = new Viagem(viagem0);
        Viagem viagem11 = new Viagem();
        viagem11.setTempo(10.0d);
        boolean b15 = viagem11.equals((java.lang.Object) 100L);
        double d16 = viagem11.getTempo();
        viagem11.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem19 = new Viagem();
        viagem19.setTempo(10.0d);
        boolean b23 = viagem19.equals((java.lang.Object) 100L);
        double d24 = viagem19.getTempo();
        viagem19.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str27 = viagem19.toString();
        viagem19.setMail("");
        double d30 = viagem19.getDesvio();
        int i31 = viagem11.compareTo(viagem19);
        double d32 = viagem11.getPreco();
        Viagem viagem33 = new Viagem();
        viagem33.setTempo(10.0d);
        boolean b37 = viagem33.equals((java.lang.Object) 100L);
        double d38 = viagem33.getTempo();
        viagem33.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str41 = viagem33.toString();
        viagem33.setMail("");
        Coordenada coordenada44 = viagem33.getcinicial();
        viagem11.setcinicial(coordenada44);
        viagem10.setcfinal(coordenada44);
        Viagem viagem47 = new Viagem();
        viagem47.setTempo(10.0d);
        boolean b51 = viagem47.equals((java.lang.Object) 100L);
        Coordenada coordenada52 = viagem47.getcfinal();
        double d53 = viagem47.getTempo();
        Viagem viagem54 = new Viagem(viagem47);
        Viagem viagem55 = viagem54.clone();
        double d56 = viagem54.getTempo();
        Viagem viagem57 = new Viagem();
        viagem57.setTempo(10.0d);
        boolean b61 = viagem57.equals((java.lang.Object) 100L);
        double d62 = viagem57.getTempo();
        viagem57.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem65 = new Viagem();
        viagem65.setTempo(10.0d);
        boolean b69 = viagem65.equals((java.lang.Object) 100L);
        double d70 = viagem65.getTempo();
        viagem65.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str73 = viagem65.toString();
        viagem65.setMail("");
        double d76 = viagem65.getDesvio();
        int i77 = viagem57.compareTo(viagem65);
        Coordenada coordenada78 = viagem57.getcinicial();
        viagem54.setcinicial(coordenada78);
        Viagem viagem82 = new Viagem();
        java.lang.String str83 = viagem82.toString();
        Viagem viagem84 = viagem82.clone();
        java.lang.String str85 = viagem84.getMail();
        Viagem viagem86 = new Viagem();
        java.lang.String str87 = viagem86.toString();
        Viagem viagem88 = viagem86.clone();
        Coordenada coordenada89 = viagem86.getcinicial();
        viagem84.setcfinal(coordenada89);
        double d91 = viagem84.getDesvio();
        viagem84.setMail("hi!");
        java.lang.String str94 = viagem84.toString();
        java.util.GregorianCalendar gregorianCalendar95 = viagem84.getData();
        Viagem viagem98 = new Viagem(coordenada44, coordenada78, (double) (-527), "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00", gregorianCalendar95, (double) 0.0f, (double) 1.0f);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem7 and viagem86", Math.signum(viagem7.compareTo(viagem86)) == -Math.signum(viagem86.compareTo(viagem7)));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test153");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        viagem0.setMail("hi!");
        Coordenada coordenada4 = viagem0.getcfinal();
        double d5 = viagem0.getPreco();
        Viagem viagem6 = new Viagem();
        java.lang.String str7 = viagem6.toString();
        double d8 = viagem6.getPreco();
        Coordenada coordenada9 = viagem6.getcfinal();
        viagem6.setMail("hi!");
        int i12 = viagem0.compareTo(viagem6);
        Viagem viagem13 = new Viagem();
        java.lang.String str14 = viagem13.toString();
        Viagem viagem15 = new Viagem(viagem13);
        Coordenada coordenada16 = viagem15.getcinicial();
        Viagem viagem17 = new Viagem();
        java.lang.String str18 = viagem17.toString();
        Viagem viagem19 = viagem17.clone();
        java.lang.String str20 = viagem19.getMail();
        Viagem viagem21 = new Viagem();
        java.lang.String str22 = viagem21.toString();
        Viagem viagem23 = viagem21.clone();
        Coordenada coordenada24 = viagem21.getcinicial();
        viagem19.setcfinal(coordenada24);
        viagem15.setcfinal(coordenada24);
        viagem0.setcfinal(coordenada24);
        Viagem viagem28 = new Viagem();
        viagem28.setTempo(10.0d);
        boolean b32 = viagem28.equals((java.lang.Object) 100L);
        Coordenada coordenada33 = viagem28.getcfinal();
        Coordenada coordenada34 = viagem28.getcinicial();
        Viagem viagem37 = new Viagem();
        java.lang.String str38 = viagem37.toString();
        double d39 = viagem37.getPreco();
        Coordenada coordenada40 = viagem37.getcfinal();
        viagem37.setMail("hi!");
        Viagem viagem43 = new Viagem();
        java.lang.String str44 = viagem43.toString();
        Viagem viagem45 = viagem43.clone();
        java.lang.String str46 = viagem45.getMail();
        Viagem viagem47 = new Viagem();
        java.lang.String str48 = viagem47.toString();
        Viagem viagem49 = viagem47.clone();
        Coordenada coordenada50 = viagem47.getcinicial();
        viagem45.setcfinal(coordenada50);
        viagem37.setcinicial(coordenada50);
        java.util.GregorianCalendar gregorianCalendar53 = viagem37.getData();
        Viagem viagem56 = new Viagem(coordenada24, coordenada34, (double) 0.0f, "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00", gregorianCalendar53, (double) (byte) 100, (double) (short) 10);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem6 and viagem28", Math.signum(viagem6.compareTo(viagem28)) == -Math.signum(viagem28.compareTo(viagem6)));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test154");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        Coordenada coordenada3 = viagem0.getcinicial();
        Viagem viagem4 = viagem0.clone();
        Coordenada coordenada5 = viagem0.getcfinal();
        Viagem viagem6 = new Viagem();
        viagem6.setTempo((double) 0.0f);
        java.util.GregorianCalendar gregorianCalendar9 = viagem6.getData();
        Coordenada coordenada10 = viagem6.getcinicial();
        Viagem viagem13 = new Viagem();
        java.lang.String str14 = viagem13.toString();
        viagem13.setMail("hi!");
        Coordenada coordenada17 = viagem13.getcfinal();
        viagem13.setTempo(0.0d);
        java.lang.String str20 = viagem13.toString();
        java.util.GregorianCalendar gregorianCalendar21 = viagem13.getData();
        Viagem viagem24 = new Viagem(coordenada5, coordenada10, 100.0d, "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00", gregorianCalendar21, 100.0d, (double) (-1));
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem6, viagem24, and viagem6", !(viagem6.compareTo(viagem24) > 0 && viagem24.compareTo(viagem6) > 0) || viagem6.compareTo(viagem6) > 0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test155");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Viagem viagem9 = viagem8.clone();
        Coordenada coordenada10 = viagem9.getcfinal();
        Viagem viagem11 = new Viagem();
        viagem11.setTempo(10.0d);
        boolean b15 = viagem11.equals((java.lang.Object) 100L);
        double d16 = viagem11.getTempo();
        viagem11.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str19 = viagem11.toString();
        viagem11.setMail("");
        Viagem viagem22 = new Viagem(viagem11);
        int i23 = viagem9.compareTo(viagem22);
        double d24 = viagem9.getDesvio();
        Viagem viagem25 = new Viagem();
        viagem25.setTempo(10.0d);
        boolean b29 = viagem25.equals((java.lang.Object) 100L);
        Viagem viagem30 = viagem25.clone();
        Viagem viagem31 = new Viagem(viagem25);
        Viagem viagem32 = viagem25.clone();
        Viagem viagem33 = new Viagem();
        viagem33.setTempo(10.0d);
        boolean b37 = viagem33.equals((java.lang.Object) 100L);
        double d38 = viagem33.getTempo();
        viagem33.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem41 = new Viagem(viagem33);
        Viagem viagem42 = viagem41.clone();
        Coordenada coordenada43 = viagem42.getcfinal();
        Viagem viagem44 = new Viagem();
        viagem44.setTempo(10.0d);
        boolean b48 = viagem44.equals((java.lang.Object) 100L);
        double d49 = viagem44.getTempo();
        viagem44.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str52 = viagem44.toString();
        viagem44.setMail("");
        Viagem viagem55 = new Viagem(viagem44);
        int i56 = viagem42.compareTo(viagem55);
        boolean b57 = viagem25.equals((java.lang.Object) i56);
        Viagem viagem58 = new Viagem(viagem25);
        int i59 = viagem9.compareTo(viagem25);
        Viagem viagem60 = new Viagem();
        viagem60.setTempo(10.0d);
        boolean b64 = viagem60.equals((java.lang.Object) 100L);
        Viagem viagem65 = new Viagem(viagem60);
        java.util.GregorianCalendar gregorianCalendar66 = viagem60.getData();
        java.lang.String str67 = viagem60.toString();
        java.lang.String str68 = viagem60.getMail();
        Viagem viagem69 = new Viagem();
        viagem69.setTempo(10.0d);
        boolean b73 = viagem69.equals((java.lang.Object) 100L);
        Coordenada coordenada74 = viagem69.getcfinal();
        Viagem viagem75 = new Viagem();
        viagem75.setTempo(10.0d);
        boolean b79 = viagem75.equals((java.lang.Object) 100L);
        Viagem viagem80 = viagem75.clone();
        Coordenada coordenada81 = viagem80.getcfinal();
        viagem69.setcinicial(coordenada81);
        viagem60.setcfinal(coordenada81);
        boolean b84 = viagem9.equals((java.lang.Object) coordenada81);
        Viagem viagem85 = new Viagem();
        java.lang.String str86 = viagem85.toString();
        Viagem viagem87 = viagem85.clone();
        Coordenada coordenada88 = viagem85.getcinicial();
        Viagem viagem89 = new Viagem(viagem85);
        viagem89.setTempo((double) (short) 0);
        Viagem viagem92 = new Viagem();
        java.lang.String str93 = viagem92.toString();
        Viagem viagem94 = viagem92.clone();
        Coordenada coordenada95 = viagem92.getcinicial();
        boolean b96 = viagem89.equals((java.lang.Object) coordenada95);
        viagem9.setcfinal(coordenada95);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem65 and viagem87", Math.signum(viagem65.compareTo(viagem87)) == -Math.signum(viagem87.compareTo(viagem65)));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test156");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        Coordenada coordenada3 = viagem0.getcinicial();
        java.lang.Object obj4 = null;
        boolean b5 = viagem0.equals(obj4);
        Viagem viagem6 = new Viagem();
        java.lang.String str7 = viagem6.toString();
        Viagem viagem8 = viagem6.clone();
        java.lang.String str9 = viagem8.getMail();
        boolean b10 = viagem0.equals((java.lang.Object) str9);
        Coordenada coordenada11 = viagem0.getcinicial();
        Viagem viagem12 = new Viagem();
        viagem12.setTempo(10.0d);
        boolean b16 = viagem12.equals((java.lang.Object) 100L);
        Viagem viagem17 = new Viagem(viagem12);
        double d18 = viagem12.getTempo();
        double d19 = viagem12.getPreco();
        double d20 = viagem12.getPreco();
        double d21 = viagem12.getDesvio();
        Viagem viagem22 = new Viagem();
        viagem22.setTempo(10.0d);
        boolean b26 = viagem22.equals((java.lang.Object) 100L);
        Viagem viagem27 = viagem22.clone();
        Viagem viagem28 = new Viagem();
        viagem28.setTempo(10.0d);
        boolean b32 = viagem28.equals((java.lang.Object) 100L);
        double d33 = viagem28.getTempo();
        viagem28.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str36 = viagem28.toString();
        viagem28.setMail("");
        double d39 = viagem28.getDesvio();
        java.util.GregorianCalendar gregorianCalendar40 = viagem28.getData();
        int i41 = viagem27.compareTo(viagem28);
        Viagem viagem42 = viagem27.clone();
        Coordenada coordenada43 = viagem27.getcinicial();
        viagem12.setcinicial(coordenada43);
        Viagem viagem47 = new Viagem();
        viagem47.setTempo(10.0d);
        boolean b51 = viagem47.equals((java.lang.Object) 100L);
        Viagem viagem52 = new Viagem(viagem47);
        java.lang.String str53 = viagem47.getMail();
        Viagem viagem54 = new Viagem();
        viagem54.setTempo(10.0d);
        boolean b58 = viagem54.equals((java.lang.Object) 100L);
        Viagem viagem59 = new Viagem(viagem54);
        java.lang.String str60 = viagem54.getMail();
        boolean b61 = viagem47.equals((java.lang.Object) viagem54);
        Viagem viagem62 = new Viagem();
        viagem62.setTempo(10.0d);
        boolean b66 = viagem62.equals((java.lang.Object) 100L);
        Viagem viagem67 = new Viagem(viagem62);
        java.util.GregorianCalendar gregorianCalendar68 = viagem62.getData();
        java.lang.String str69 = viagem62.toString();
        double d70 = viagem62.getPreco();
        Coordenada coordenada71 = viagem62.getcinicial();
        viagem54.setcfinal(coordenada71);
        java.util.GregorianCalendar gregorianCalendar73 = viagem54.getData();
        Viagem viagem76 = new Viagem(coordenada11, coordenada43, (double) 100, "", gregorianCalendar73, (double) 10, (double) 100);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem22 and viagem6", Math.signum(viagem22.compareTo(viagem6)) == -Math.signum(viagem6.compareTo(viagem22)));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test157");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Viagem viagem6 = new Viagem(viagem0);
        Viagem viagem7 = viagem0.clone();
        Viagem viagem8 = new Viagem(viagem0);
        Viagem viagem9 = new Viagem();
        java.lang.String str10 = viagem9.toString();
        Viagem viagem11 = viagem9.clone();
        Coordenada coordenada12 = viagem9.getcinicial();
        Viagem viagem13 = new Viagem(viagem9);
        Viagem viagem14 = new Viagem(viagem9);
        Coordenada coordenada15 = viagem9.getcfinal();
        viagem0.setcfinal(coordenada15);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem13 and viagem8", Math.signum(viagem13.compareTo(viagem8)) == -Math.signum(viagem8.compareTo(viagem13)));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test158");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        Coordenada coordenada3 = viagem0.getcinicial();
        Viagem viagem4 = new Viagem(viagem0);
        double d5 = viagem4.getPreco();
        Viagem viagem6 = new Viagem();
        viagem6.setTempo(10.0d);
        boolean b10 = viagem6.equals((java.lang.Object) 100L);
        double d11 = viagem6.getTempo();
        viagem6.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem14 = new Viagem();
        viagem14.setTempo(10.0d);
        boolean b18 = viagem14.equals((java.lang.Object) 100L);
        double d19 = viagem14.getTempo();
        viagem14.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str22 = viagem14.toString();
        viagem14.setMail("");
        double d25 = viagem14.getDesvio();
        int i26 = viagem6.compareTo(viagem14);
        double d27 = viagem6.getPreco();
        Viagem viagem28 = new Viagem();
        viagem28.setTempo(10.0d);
        boolean b32 = viagem28.equals((java.lang.Object) 100L);
        double d33 = viagem28.getTempo();
        viagem28.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str36 = viagem28.toString();
        viagem28.setMail("");
        Coordenada coordenada39 = viagem28.getcinicial();
        viagem6.setcinicial(coordenada39);
        viagem4.setcinicial(coordenada39);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem14 and viagem0", Math.signum(viagem14.compareTo(viagem0)) == -Math.signum(viagem0.compareTo(viagem14)));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test159");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Viagem viagem6 = new Viagem();
        viagem6.setTempo(10.0d);
        boolean b10 = viagem6.equals((java.lang.Object) 100L);
        double d11 = viagem6.getTempo();
        viagem6.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str14 = viagem6.toString();
        viagem6.setMail("");
        double d17 = viagem6.getDesvio();
        java.util.GregorianCalendar gregorianCalendar18 = viagem6.getData();
        int i19 = viagem5.compareTo(viagem6);
        Viagem viagem20 = new Viagem(viagem6);
        Coordenada coordenada21 = viagem6.getcinicial();
        Viagem viagem22 = new Viagem();
        viagem22.setTempo(10.0d);
        boolean b26 = viagem22.equals((java.lang.Object) 100L);
        double d27 = viagem22.getTempo();
        viagem22.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem30 = new Viagem(viagem22);
        Coordenada coordenada31 = viagem22.getcfinal();
        Viagem viagem32 = new Viagem(viagem22);
        Coordenada coordenada33 = viagem32.getcinicial();
        viagem6.setcinicial(coordenada33);
        Viagem viagem35 = new Viagem();
        viagem35.setTempo(10.0d);
        boolean b39 = viagem35.equals((java.lang.Object) 100L);
        Viagem viagem40 = viagem35.clone();
        Viagem viagem41 = new Viagem();
        viagem41.setTempo(10.0d);
        boolean b45 = viagem41.equals((java.lang.Object) 100L);
        double d46 = viagem41.getTempo();
        viagem41.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str49 = viagem41.toString();
        viagem41.setMail("");
        double d52 = viagem41.getDesvio();
        java.util.GregorianCalendar gregorianCalendar53 = viagem41.getData();
        int i54 = viagem40.compareTo(viagem41);
        Viagem viagem55 = new Viagem(viagem41);
        Coordenada coordenada56 = viagem41.getcinicial();
        Viagem viagem59 = new Viagem();
        viagem59.setTempo(10.0d);
        Coordenada coordenada62 = viagem59.getcfinal();
        Viagem viagem63 = new Viagem();
        viagem63.setTempo(10.0d);
        boolean b67 = viagem63.equals((java.lang.Object) 100L);
        double d68 = viagem63.getTempo();
        Coordenada coordenada69 = viagem63.getcfinal();
        viagem59.setcfinal(coordenada69);
        java.util.GregorianCalendar gregorianCalendar71 = viagem59.getData();
        Viagem viagem74 = new Viagem(coordenada33, coordenada56, (double) 0.0f, "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00", gregorianCalendar71, (double) (short) -1, (double) 'a');
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem20, viagem74, and viagem20", !(viagem20.compareTo(viagem74) > 0 && viagem74.compareTo(viagem20) > 0) || viagem20.compareTo(viagem20) > 0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test160");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = new Viagem(viagem0);
        Coordenada coordenada3 = viagem2.getcinicial();
        Coordenada coordenada4 = viagem2.getcfinal();
        java.lang.String str5 = viagem2.toString();
        java.lang.String str6 = viagem2.toString();
        java.lang.String str7 = viagem2.toString();
        double d8 = viagem2.getTempo();
        double d9 = viagem2.getPreco();
        Viagem viagem10 = new Viagem();
        viagem10.setTempo(10.0d);
        boolean b14 = viagem10.equals((java.lang.Object) 100L);
        Viagem viagem15 = new Viagem(viagem10);
        double d16 = viagem10.getTempo();
        double d17 = viagem10.getPreco();
        double d18 = viagem10.getPreco();
        double d19 = viagem10.getDesvio();
        Viagem viagem20 = new Viagem();
        viagem20.setTempo(10.0d);
        boolean b24 = viagem20.equals((java.lang.Object) 100L);
        Viagem viagem25 = viagem20.clone();
        Viagem viagem26 = new Viagem();
        viagem26.setTempo(10.0d);
        boolean b30 = viagem26.equals((java.lang.Object) 100L);
        double d31 = viagem26.getTempo();
        viagem26.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str34 = viagem26.toString();
        viagem26.setMail("");
        double d37 = viagem26.getDesvio();
        java.util.GregorianCalendar gregorianCalendar38 = viagem26.getData();
        int i39 = viagem25.compareTo(viagem26);
        Viagem viagem40 = viagem25.clone();
        Coordenada coordenada41 = viagem25.getcinicial();
        viagem10.setcinicial(coordenada41);
        viagem2.setcfinal(coordenada41);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem40 and viagem0", Math.signum(viagem40.compareTo(viagem0)) == -Math.signum(viagem0.compareTo(viagem40)));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test161");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = new Viagem(viagem0);
        Coordenada coordenada3 = viagem2.getcinicial();
        Coordenada coordenada4 = viagem2.getcfinal();
        java.lang.String str5 = viagem2.getMail();
        Viagem viagem6 = new Viagem();
        viagem6.setTempo(10.0d);
        boolean b10 = viagem6.equals((java.lang.Object) 100L);
        java.util.GregorianCalendar gregorianCalendar11 = viagem6.getData();
        Coordenada coordenada12 = viagem6.getcinicial();
        Viagem viagem13 = new Viagem();
        viagem13.setTempo(10.0d);
        boolean b17 = viagem13.equals((java.lang.Object) 100L);
        double d18 = viagem13.getTempo();
        viagem13.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem21 = new Viagem();
        viagem21.setTempo(10.0d);
        boolean b25 = viagem21.equals((java.lang.Object) 100L);
        double d26 = viagem21.getTempo();
        viagem21.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str29 = viagem21.toString();
        viagem21.setMail("");
        double d32 = viagem21.getDesvio();
        int i33 = viagem13.compareTo(viagem21);
        Coordenada coordenada34 = viagem13.getcinicial();
        viagem6.setcinicial(coordenada34);
        viagem2.setcinicial(coordenada34);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem6 and viagem0", Math.signum(viagem6.compareTo(viagem0)) == -Math.signum(viagem0.compareTo(viagem6)));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test162");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        double d3 = viagem2.getDesvio();
        Viagem viagem4 = viagem2.clone();
        double d5 = viagem4.getDesvio();
        Viagem viagem6 = new Viagem();
        viagem6.setTempo(10.0d);
        boolean b10 = viagem6.equals((java.lang.Object) 100L);
        double d11 = viagem6.getTempo();
        viagem6.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem14 = new Viagem(viagem6);
        Viagem viagem15 = viagem14.clone();
        Coordenada coordenada16 = viagem15.getcfinal();
        Viagem viagem17 = new Viagem();
        viagem17.setTempo(10.0d);
        boolean b21 = viagem17.equals((java.lang.Object) 100L);
        double d22 = viagem17.getTempo();
        viagem17.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str25 = viagem17.toString();
        viagem17.setMail("");
        Viagem viagem28 = new Viagem(viagem17);
        int i29 = viagem15.compareTo(viagem28);
        java.lang.String str30 = viagem28.getMail();
        Viagem viagem31 = new Viagem(viagem28);
        int i32 = viagem4.compareTo(viagem31);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem15 and viagem0", Math.signum(viagem15.compareTo(viagem0)) == -Math.signum(viagem0.compareTo(viagem15)));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test163");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Coordenada coordenada9 = viagem0.getcfinal();
        Viagem viagem10 = new Viagem(viagem0);
        Coordenada coordenada11 = viagem10.getcinicial();
        Viagem viagem12 = new Viagem();
        java.lang.String str13 = viagem12.toString();
        Viagem viagem14 = new Viagem(viagem12);
        Coordenada coordenada15 = viagem14.getcinicial();
        Viagem viagem16 = new Viagem();
        java.lang.String str17 = viagem16.toString();
        Viagem viagem18 = viagem16.clone();
        java.lang.String str19 = viagem18.getMail();
        Viagem viagem20 = new Viagem();
        java.lang.String str21 = viagem20.toString();
        Viagem viagem22 = viagem20.clone();
        Coordenada coordenada23 = viagem20.getcinicial();
        viagem18.setcfinal(coordenada23);
        viagem14.setcfinal(coordenada23);
        viagem10.setcinicial(coordenada23);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem22 and viagem8", Math.signum(viagem22.compareTo(viagem8)) == -Math.signum(viagem8.compareTo(viagem22)));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test164");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Viagem viagem9 = viagem8.clone();
        Coordenada coordenada10 = viagem9.getcfinal();
        Viagem viagem11 = new Viagem();
        viagem11.setTempo(10.0d);
        boolean b15 = viagem11.equals((java.lang.Object) 100L);
        double d16 = viagem11.getTempo();
        viagem11.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem19 = new Viagem();
        viagem19.setTempo(10.0d);
        boolean b23 = viagem19.equals((java.lang.Object) 100L);
        double d24 = viagem19.getTempo();
        viagem19.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str27 = viagem19.toString();
        viagem19.setMail("");
        double d30 = viagem19.getDesvio();
        int i31 = viagem11.compareTo(viagem19);
        double d32 = viagem11.getPreco();
        Viagem viagem33 = new Viagem();
        viagem33.setTempo(10.0d);
        boolean b37 = viagem33.equals((java.lang.Object) 100L);
        double d38 = viagem33.getTempo();
        viagem33.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str41 = viagem33.toString();
        viagem33.setMail("");
        Coordenada coordenada44 = viagem33.getcinicial();
        viagem11.setcinicial(coordenada44);
        viagem9.setcfinal(coordenada44);
        Viagem viagem47 = new Viagem();
        viagem47.setTempo(10.0d);
        boolean b51 = viagem47.equals((java.lang.Object) 100L);
        double d52 = viagem47.getTempo();
        double d53 = viagem47.getPreco();
        Viagem viagem54 = new Viagem();
        viagem54.setTempo(10.0d);
        boolean b58 = viagem54.equals((java.lang.Object) 100L);
        Viagem viagem59 = viagem54.clone();
        boolean b60 = viagem47.equals((java.lang.Object) viagem59);
        Viagem viagem61 = new Viagem();
        viagem61.setTempo(10.0d);
        boolean b65 = viagem61.equals((java.lang.Object) 100L);
        double d66 = viagem61.getTempo();
        viagem61.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str69 = viagem61.toString();
        viagem61.setMail("");
        Coordenada coordenada72 = viagem61.getcinicial();
        viagem47.setcinicial(coordenada72);
        Viagem viagem76 = new Viagem();
        java.lang.String str77 = viagem76.toString();
        Viagem viagem78 = viagem76.clone();
        double d79 = viagem78.getDesvio();
        java.util.GregorianCalendar gregorianCalendar80 = viagem78.getData();
        Viagem viagem83 = new Viagem(coordenada44, coordenada72, 0.0d, "hi!", gregorianCalendar80, 0.0d, 0.0d);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem33 and viagem76", Math.signum(viagem33.compareTo(viagem76)) == -Math.signum(viagem76.compareTo(viagem33)));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test165");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        viagem0.setMail("hi!");
        Coordenada coordenada4 = viagem0.getcfinal();
        viagem0.setTempo(0.0d);
        java.lang.String str7 = viagem0.toString();
        java.util.GregorianCalendar gregorianCalendar8 = viagem0.getData();
        java.lang.String str9 = viagem0.getMail();
        Coordenada coordenada10 = null;
        viagem0.setcinicial(coordenada10);
        org.junit.Assert.assertTrue("Contract failed: compareTo-reflexive on viagem0", viagem0.compareTo(viagem0) == 0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test166");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Coordenada coordenada9 = viagem0.getcfinal();
        Viagem viagem10 = new Viagem();
        viagem10.setTempo(10.0d);
        boolean b14 = viagem10.equals((java.lang.Object) 100L);
        Coordenada coordenada15 = viagem10.getcfinal();
        double d16 = viagem10.getTempo();
        Viagem viagem17 = new Viagem(viagem10);
        int i18 = viagem0.compareTo(viagem10);
        double d19 = viagem0.getPreco();
        Viagem viagem20 = new Viagem();
        viagem20.setTempo(10.0d);
        boolean b24 = viagem20.equals((java.lang.Object) 100L);
        double d25 = viagem20.getTempo();
        viagem20.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem28 = new Viagem(viagem20);
        Coordenada coordenada29 = viagem20.getcfinal();
        viagem0.setcfinal(coordenada29);
        java.lang.Object obj31 = null;
        boolean b32 = viagem0.equals(obj31);
        Viagem viagem33 = new Viagem();
        java.lang.String str34 = viagem33.toString();
        Viagem viagem35 = viagem33.clone();
        double d36 = viagem35.getDesvio();
        Viagem viagem37 = viagem35.clone();
        double d38 = viagem35.getPreco();
        double d39 = viagem35.getTempo();
        Viagem viagem40 = new Viagem(viagem35);
        boolean b41 = viagem0.equals((java.lang.Object) viagem40);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem8 and viagem35", Math.signum(viagem8.compareTo(viagem35)) == -Math.signum(viagem35.compareTo(viagem8)));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test167");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = new Viagem(viagem0);
        double d3 = viagem0.getPreco();
        double d4 = viagem0.getPreco();
        Coordenada coordenada5 = viagem0.getcinicial();
        Viagem viagem6 = new Viagem();
        viagem6.setTempo(10.0d);
        boolean b10 = viagem6.equals((java.lang.Object) 100L);
        Viagem viagem11 = new Viagem(viagem6);
        double d12 = viagem6.getTempo();
        double d13 = viagem6.getPreco();
        double d14 = viagem6.getPreco();
        double d15 = viagem6.getDesvio();
        boolean b16 = viagem0.equals((java.lang.Object) viagem6);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem2 and viagem11", Math.signum(viagem2.compareTo(viagem11)) == -Math.signum(viagem11.compareTo(viagem2)));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test168");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        double d6 = viagem0.getPreco();
        Viagem viagem7 = new Viagem();
        viagem7.setTempo(10.0d);
        boolean b11 = viagem7.equals((java.lang.Object) 100L);
        Viagem viagem12 = viagem7.clone();
        boolean b13 = viagem0.equals((java.lang.Object) viagem12);
        Viagem viagem14 = new Viagem();
        java.lang.String str15 = viagem14.toString();
        viagem14.setMail("hi!");
        Coordenada coordenada18 = viagem14.getcfinal();
        double d19 = viagem14.getPreco();
        Viagem viagem20 = new Viagem();
        java.lang.String str21 = viagem20.toString();
        double d22 = viagem20.getPreco();
        Coordenada coordenada23 = viagem20.getcfinal();
        viagem20.setMail("hi!");
        int i26 = viagem14.compareTo(viagem20);
        double d27 = viagem20.getDesvio();
        Coordenada coordenada28 = viagem20.getcinicial();
        viagem12.setcinicial(coordenada28);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem7 and viagem20", Math.signum(viagem7.compareTo(viagem20)) == -Math.signum(viagem20.compareTo(viagem7)));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test169");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        double d3 = viagem2.getDesvio();
        Viagem viagem4 = viagem2.clone();
        double d5 = viagem2.getPreco();
        Viagem viagem6 = new Viagem();
        java.lang.String str7 = viagem6.toString();
        Viagem viagem8 = viagem6.clone();
        java.lang.String str9 = viagem8.getMail();
        Viagem viagem10 = new Viagem();
        java.lang.String str11 = viagem10.toString();
        Viagem viagem12 = viagem10.clone();
        Coordenada coordenada13 = viagem10.getcinicial();
        viagem8.setcfinal(coordenada13);
        double d15 = viagem8.getDesvio();
        Viagem viagem16 = new Viagem();
        java.lang.String str17 = viagem16.toString();
        Viagem viagem18 = viagem16.clone();
        Coordenada coordenada19 = viagem16.getcinicial();
        java.lang.Object obj20 = null;
        boolean b21 = viagem16.equals(obj20);
        int i22 = viagem8.compareTo(viagem16);
        double d23 = viagem16.getDesvio();
        boolean b24 = viagem2.equals((java.lang.Object) viagem16);
        Viagem viagem25 = new Viagem();
        viagem25.setTempo(10.0d);
        boolean b29 = viagem25.equals((java.lang.Object) 100L);
        Viagem viagem30 = viagem25.clone();
        Viagem viagem31 = new Viagem(viagem25);
        Viagem viagem32 = viagem25.clone();
        Viagem viagem33 = new Viagem();
        viagem33.setTempo(10.0d);
        boolean b37 = viagem33.equals((java.lang.Object) 100L);
        double d38 = viagem33.getTempo();
        viagem33.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem41 = new Viagem(viagem33);
        Viagem viagem42 = viagem41.clone();
        Coordenada coordenada43 = viagem42.getcfinal();
        Viagem viagem44 = new Viagem();
        viagem44.setTempo(10.0d);
        boolean b48 = viagem44.equals((java.lang.Object) 100L);
        double d49 = viagem44.getTempo();
        viagem44.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str52 = viagem44.toString();
        viagem44.setMail("");
        Viagem viagem55 = new Viagem(viagem44);
        int i56 = viagem42.compareTo(viagem55);
        boolean b57 = viagem25.equals((java.lang.Object) i56);
        Viagem viagem58 = new Viagem(viagem25);
        Viagem viagem59 = new Viagem();
        viagem59.setTempo(10.0d);
        boolean b63 = viagem59.equals((java.lang.Object) 100L);
        Viagem viagem64 = new Viagem(viagem59);
        java.lang.String str65 = viagem59.getMail();
        Viagem viagem66 = new Viagem();
        viagem66.setTempo(10.0d);
        boolean b70 = viagem66.equals((java.lang.Object) 100L);
        Viagem viagem71 = new Viagem(viagem66);
        java.lang.String str72 = viagem66.getMail();
        boolean b73 = viagem59.equals((java.lang.Object) viagem66);
        Viagem viagem74 = new Viagem();
        viagem74.setTempo(10.0d);
        boolean b78 = viagem74.equals((java.lang.Object) 100L);
        Viagem viagem79 = new Viagem(viagem74);
        java.util.GregorianCalendar gregorianCalendar80 = viagem74.getData();
        java.lang.String str81 = viagem74.toString();
        double d82 = viagem74.getPreco();
        Coordenada coordenada83 = viagem74.getcinicial();
        viagem66.setcfinal(coordenada83);
        viagem58.setcfinal(coordenada83);
        viagem16.setcfinal(coordenada83);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem71 and viagem10", Math.signum(viagem71.compareTo(viagem10)) == -Math.signum(viagem10.compareTo(viagem71)));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test170");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Coordenada coordenada9 = viagem0.getcfinal();
        viagem0.setMail("hi!");
        Viagem viagem12 = new Viagem();
        java.lang.String str13 = viagem12.toString();
        Viagem viagem14 = viagem12.clone();
        java.lang.String str15 = viagem14.getMail();
        Viagem viagem16 = new Viagem();
        java.lang.String str17 = viagem16.toString();
        Viagem viagem18 = viagem16.clone();
        Coordenada coordenada19 = viagem16.getcinicial();
        viagem14.setcfinal(coordenada19);
        double d21 = viagem14.getDesvio();
        viagem14.setTempo((double) (short) 0);
        int i24 = viagem0.compareTo(viagem14);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem8 and viagem12", Math.signum(viagem8.compareTo(viagem12)) == -Math.signum(viagem12.compareTo(viagem8)));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test171");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Coordenada coordenada5 = viagem0.getcfinal();
        double d6 = viagem0.getTempo();
        Viagem viagem7 = new Viagem(viagem0);
        viagem0.setTempo((double) (short) 1);
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem7, viagem0, and viagem7", !(viagem7.compareTo(viagem0) > 0 && viagem0.compareTo(viagem7) > 0) || viagem7.compareTo(viagem7) > 0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test172");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Coordenada coordenada9 = viagem0.getcfinal();
        Viagem viagem10 = new Viagem();
        viagem10.setTempo(10.0d);
        boolean b14 = viagem10.equals((java.lang.Object) 100L);
        Coordenada coordenada15 = viagem10.getcfinal();
        double d16 = viagem10.getTempo();
        Viagem viagem17 = new Viagem(viagem10);
        int i18 = viagem0.compareTo(viagem10);
        double d19 = viagem0.getPreco();
        Viagem viagem20 = new Viagem();
        viagem20.setTempo(10.0d);
        boolean b24 = viagem20.equals((java.lang.Object) 100L);
        double d25 = viagem20.getTempo();
        viagem20.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem28 = new Viagem(viagem20);
        Coordenada coordenada29 = viagem20.getcfinal();
        viagem0.setcfinal(coordenada29);
        double d31 = viagem0.getTempo();
        Viagem viagem32 = new Viagem();
        java.lang.String str33 = viagem32.toString();
        Viagem viagem34 = viagem32.clone();
        java.lang.String str35 = viagem34.getMail();
        Viagem viagem36 = new Viagem();
        java.lang.String str37 = viagem36.toString();
        Viagem viagem38 = viagem36.clone();
        Coordenada coordenada39 = viagem36.getcinicial();
        viagem34.setcfinal(coordenada39);
        double d41 = viagem34.getDesvio();
        Viagem viagem42 = new Viagem();
        java.lang.String str43 = viagem42.toString();
        Viagem viagem44 = viagem42.clone();
        Coordenada coordenada45 = viagem42.getcinicial();
        java.lang.Object obj46 = null;
        boolean b47 = viagem42.equals(obj46);
        int i48 = viagem34.compareTo(viagem42);
        Viagem viagem49 = viagem42.clone();
        Viagem viagem50 = new Viagem();
        java.lang.String str51 = viagem50.toString();
        Viagem viagem52 = viagem50.clone();
        Coordenada coordenada53 = viagem50.getcfinal();
        viagem42.setcinicial(coordenada53);
        viagem0.setcinicial(coordenada53);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem52 and viagem8", Math.signum(viagem52.compareTo(viagem8)) == -Math.signum(viagem8.compareTo(viagem52)));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test173");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        Coordenada coordenada3 = viagem0.getcinicial();
        java.lang.Object obj4 = null;
        boolean b5 = viagem0.equals(obj4);
        Viagem viagem6 = new Viagem();
        java.lang.String str7 = viagem6.toString();
        Viagem viagem8 = viagem6.clone();
        java.lang.String str9 = viagem8.getMail();
        boolean b10 = viagem0.equals((java.lang.Object) str9);
        Coordenada coordenada11 = viagem0.getcinicial();
        Viagem viagem12 = new Viagem();
        viagem12.setTempo(10.0d);
        boolean b16 = viagem12.equals((java.lang.Object) 100L);
        double d17 = viagem12.getTempo();
        viagem12.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem20 = new Viagem(viagem12);
        java.lang.String str21 = viagem12.toString();
        Coordenada coordenada22 = viagem12.getcfinal();
        viagem0.setcfinal(coordenada22);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem8 and viagem20", Math.signum(viagem8.compareTo(viagem20)) == -Math.signum(viagem20.compareTo(viagem8)));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test174");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Viagem viagem9 = viagem8.clone();
        Coordenada coordenada10 = viagem9.getcfinal();
        Viagem viagem11 = new Viagem();
        viagem11.setTempo(10.0d);
        boolean b15 = viagem11.equals((java.lang.Object) 100L);
        double d16 = viagem11.getTempo();
        viagem11.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str19 = viagem11.toString();
        viagem11.setMail("");
        Viagem viagem22 = new Viagem(viagem11);
        int i23 = viagem9.compareTo(viagem22);
        double d24 = viagem9.getDesvio();
        Viagem viagem25 = viagem9.clone();
        java.lang.String str26 = viagem25.toString();
        viagem25.setTempo((double) (-3));
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem22, viagem25, and viagem22", !(viagem22.compareTo(viagem25) > 0 && viagem25.compareTo(viagem22) > 0) || viagem22.compareTo(viagem22) > 0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test175");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        viagem0.setMail("hi!");
        Coordenada coordenada4 = viagem0.getcfinal();
        double d5 = viagem0.getPreco();
        Viagem viagem6 = new Viagem();
        java.lang.String str7 = viagem6.toString();
        double d8 = viagem6.getPreco();
        Coordenada coordenada9 = viagem6.getcfinal();
        viagem6.setMail("hi!");
        int i12 = viagem0.compareTo(viagem6);
        Viagem viagem13 = new Viagem();
        java.lang.String str14 = viagem13.toString();
        Viagem viagem15 = new Viagem(viagem13);
        Coordenada coordenada16 = viagem15.getcinicial();
        Viagem viagem17 = new Viagem();
        java.lang.String str18 = viagem17.toString();
        Viagem viagem19 = viagem17.clone();
        java.lang.String str20 = viagem19.getMail();
        Viagem viagem21 = new Viagem();
        java.lang.String str22 = viagem21.toString();
        Viagem viagem23 = viagem21.clone();
        Coordenada coordenada24 = viagem21.getcinicial();
        viagem19.setcfinal(coordenada24);
        viagem15.setcfinal(coordenada24);
        viagem0.setcfinal(coordenada24);
        Viagem viagem28 = new Viagem();
        viagem28.setTempo(10.0d);
        boolean b32 = viagem28.equals((java.lang.Object) 100L);
        double d33 = viagem28.getTempo();
        viagem28.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem36 = new Viagem(viagem28);
        Coordenada coordenada37 = viagem28.getcfinal();
        Viagem viagem38 = new Viagem();
        viagem38.setTempo(10.0d);
        boolean b42 = viagem38.equals((java.lang.Object) 100L);
        Coordenada coordenada43 = viagem38.getcfinal();
        double d44 = viagem38.getTempo();
        Viagem viagem45 = new Viagem(viagem38);
        int i46 = viagem28.compareTo(viagem38);
        double d47 = viagem28.getPreco();
        Viagem viagem48 = new Viagem();
        viagem48.setTempo(10.0d);
        boolean b52 = viagem48.equals((java.lang.Object) 100L);
        double d53 = viagem48.getTempo();
        viagem48.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem56 = new Viagem(viagem48);
        Coordenada coordenada57 = viagem48.getcfinal();
        viagem28.setcfinal(coordenada57);
        Viagem viagem61 = new Viagem();
        java.lang.String str62 = viagem61.toString();
        Viagem viagem63 = viagem61.clone();
        double d64 = viagem63.getDesvio();
        Viagem viagem65 = viagem63.clone();
        java.util.GregorianCalendar gregorianCalendar66 = viagem63.getData();
        Viagem viagem69 = new Viagem(coordenada24, coordenada57, (double) 10.0f, "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00", gregorianCalendar66, (double) 1, (double) 0);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem45 and viagem15", Math.signum(viagem45.compareTo(viagem15)) == -Math.signum(viagem15.compareTo(viagem45)));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test176");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Viagem viagem9 = viagem8.clone();
        Coordenada coordenada10 = viagem9.getcfinal();
        Viagem viagem11 = new Viagem();
        viagem11.setTempo(10.0d);
        boolean b15 = viagem11.equals((java.lang.Object) 100L);
        double d16 = viagem11.getTempo();
        viagem11.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str19 = viagem11.toString();
        viagem11.setMail("");
        Viagem viagem22 = new Viagem(viagem11);
        int i23 = viagem9.compareTo(viagem22);
        double d24 = viagem9.getDesvio();
        double d25 = viagem9.getDesvio();
        Viagem viagem26 = new Viagem();
        viagem26.setTempo(10.0d);
        boolean b30 = viagem26.equals((java.lang.Object) 100L);
        Viagem viagem31 = new Viagem(viagem26);
        double d32 = viagem26.getTempo();
        double d33 = viagem26.getPreco();
        double d34 = viagem26.getPreco();
        double d35 = viagem26.getDesvio();
        Viagem viagem36 = new Viagem();
        viagem36.setTempo(10.0d);
        boolean b40 = viagem36.equals((java.lang.Object) 100L);
        Viagem viagem41 = viagem36.clone();
        Viagem viagem42 = new Viagem();
        viagem42.setTempo(10.0d);
        boolean b46 = viagem42.equals((java.lang.Object) 100L);
        double d47 = viagem42.getTempo();
        viagem42.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str50 = viagem42.toString();
        viagem42.setMail("");
        double d53 = viagem42.getDesvio();
        java.util.GregorianCalendar gregorianCalendar54 = viagem42.getData();
        int i55 = viagem41.compareTo(viagem42);
        Viagem viagem56 = viagem41.clone();
        Coordenada coordenada57 = viagem41.getcinicial();
        viagem26.setcinicial(coordenada57);
        viagem9.setcfinal(coordenada57);
        Viagem viagem60 = new Viagem();
        viagem60.setTempo(10.0d);
        boolean b64 = viagem60.equals((java.lang.Object) 100L);
        Viagem viagem65 = new Viagem(viagem60);
        java.util.GregorianCalendar gregorianCalendar66 = viagem60.getData();
        java.lang.String str67 = viagem60.toString();
        java.lang.String str68 = viagem60.getMail();
        double d69 = viagem60.getTempo();
        Coordenada coordenada70 = viagem60.getcinicial();
        Viagem viagem73 = new Viagem();
        java.lang.String str74 = viagem73.toString();
        Viagem viagem75 = viagem73.clone();
        java.lang.String str76 = viagem75.getMail();
        Viagem viagem77 = new Viagem();
        java.lang.String str78 = viagem77.toString();
        Viagem viagem79 = viagem77.clone();
        Coordenada coordenada80 = viagem77.getcinicial();
        viagem75.setcfinal(coordenada80);
        double d82 = viagem75.getDesvio();
        Viagem viagem83 = new Viagem();
        java.lang.String str84 = viagem83.toString();
        Viagem viagem85 = viagem83.clone();
        Coordenada coordenada86 = viagem83.getcinicial();
        java.lang.Object obj87 = null;
        boolean b88 = viagem83.equals(obj87);
        int i89 = viagem75.compareTo(viagem83);
        Viagem viagem90 = viagem83.clone();
        Viagem viagem91 = viagem90.clone();
        java.util.GregorianCalendar gregorianCalendar92 = viagem91.getData();
        Viagem viagem95 = new Viagem(coordenada57, coordenada70, (double) (-1L), "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00", gregorianCalendar92, (double) (-3), 1.0d);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem83 and viagem22", Math.signum(viagem83.compareTo(viagem22)) == -Math.signum(viagem22.compareTo(viagem83)));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test177");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        double d2 = viagem0.getPreco();
        Coordenada coordenada3 = viagem0.getcfinal();
        viagem0.setMail("hi!");
        Viagem viagem6 = new Viagem();
        java.lang.String str7 = viagem6.toString();
        Viagem viagem8 = viagem6.clone();
        java.lang.String str9 = viagem8.getMail();
        Viagem viagem10 = new Viagem();
        java.lang.String str11 = viagem10.toString();
        Viagem viagem12 = viagem10.clone();
        Coordenada coordenada13 = viagem10.getcinicial();
        viagem8.setcfinal(coordenada13);
        viagem0.setcinicial(coordenada13);
        double d16 = viagem0.getTempo();
        Viagem viagem17 = new Viagem();
        viagem17.setTempo(10.0d);
        boolean b21 = viagem17.equals((java.lang.Object) 100L);
        Viagem viagem22 = new Viagem(viagem17);
        java.util.GregorianCalendar gregorianCalendar23 = viagem17.getData();
        java.lang.String str24 = viagem17.toString();
        double d25 = viagem17.getPreco();
        Coordenada coordenada26 = viagem17.getcinicial();
        Viagem viagem27 = new Viagem(viagem17);
        boolean b28 = viagem0.equals((java.lang.Object) viagem17);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem22 and viagem6", Math.signum(viagem22.compareTo(viagem6)) == -Math.signum(viagem6.compareTo(viagem22)));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test178");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        viagem0.setMail("hi!");
        Coordenada coordenada4 = viagem0.getcfinal();
        double d5 = viagem0.getPreco();
        Viagem viagem6 = new Viagem();
        java.lang.String str7 = viagem6.toString();
        double d8 = viagem6.getPreco();
        Coordenada coordenada9 = viagem6.getcfinal();
        viagem6.setMail("hi!");
        int i12 = viagem0.compareTo(viagem6);
        double d13 = viagem6.getDesvio();
        Coordenada coordenada14 = viagem6.getcinicial();
        Viagem viagem15 = new Viagem();
        viagem15.setTempo(10.0d);
        boolean b19 = viagem15.equals((java.lang.Object) 100L);
        java.util.GregorianCalendar gregorianCalendar20 = viagem15.getData();
        Coordenada coordenada21 = viagem15.getcinicial();
        Viagem viagem22 = new Viagem();
        viagem22.setTempo(10.0d);
        boolean b26 = viagem22.equals((java.lang.Object) 100L);
        double d27 = viagem22.getTempo();
        viagem22.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem30 = new Viagem(viagem22);
        Viagem viagem31 = viagem30.clone();
        Coordenada coordenada32 = viagem31.getcfinal();
        boolean b33 = viagem15.equals((java.lang.Object) coordenada32);
        Viagem viagem34 = viagem15.clone();
        Coordenada coordenada35 = viagem34.getcfinal();
        Viagem viagem38 = new Viagem();
        viagem38.setTempo(10.0d);
        boolean b42 = viagem38.equals((java.lang.Object) 100L);
        Viagem viagem43 = viagem38.clone();
        java.util.GregorianCalendar gregorianCalendar44 = viagem43.getData();
        Viagem viagem47 = new Viagem(coordenada14, coordenada35, (double) (short) 10, "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00", gregorianCalendar44, (double) (-3), (double) 0L);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem0 and viagem38", Math.signum(viagem0.compareTo(viagem38)) == -Math.signum(viagem38.compareTo(viagem0)));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test179");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Coordenada coordenada9 = viagem0.getcfinal();
        viagem0.setMail("hi!");
        double d12 = viagem0.getTempo();
        viagem0.setTempo((double) (short) 100);
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem8, viagem0, and viagem8", !(viagem8.compareTo(viagem0) > 0 && viagem0.compareTo(viagem8) > 0) || viagem8.compareTo(viagem8) > 0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test180");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        double d6 = viagem0.getPreco();
        Viagem viagem7 = new Viagem(viagem0);
        Viagem viagem8 = viagem7.clone();
        double d9 = viagem8.getTempo();
        viagem8.setTempo(100.0d);
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem0, viagem8, and viagem0", !(viagem0.compareTo(viagem8) > 0 && viagem8.compareTo(viagem0) > 0) || viagem0.compareTo(viagem0) > 0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test181");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        java.lang.String str3 = viagem2.getMail();
        Viagem viagem4 = new Viagem();
        java.lang.String str5 = viagem4.toString();
        Viagem viagem6 = viagem4.clone();
        Coordenada coordenada7 = viagem4.getcinicial();
        viagem2.setcfinal(coordenada7);
        double d9 = viagem2.getDesvio();
        viagem2.setMail("hi!");
        double d12 = viagem2.getTempo();
        Viagem viagem13 = new Viagem();
        viagem13.setTempo(10.0d);
        boolean b17 = viagem13.equals((java.lang.Object) 100L);
        Viagem viagem18 = new Viagem(viagem13);
        java.lang.String str19 = viagem13.getMail();
        double d20 = viagem13.getTempo();
        boolean b21 = viagem2.equals((java.lang.Object) d20);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem18 and viagem4", Math.signum(viagem18.compareTo(viagem4)) == -Math.signum(viagem4.compareTo(viagem18)));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test182");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Coordenada coordenada5 = viagem0.getcfinal();
        Coordenada coordenada6 = viagem0.getcinicial();
        Viagem viagem7 = new Viagem();
        viagem7.setTempo(10.0d);
        boolean b11 = viagem7.equals((java.lang.Object) 100L);
        double d12 = viagem7.getTempo();
        viagem7.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Coordenada coordenada15 = viagem7.getcinicial();
        Viagem viagem18 = new Viagem();
        viagem18.setTempo(10.0d);
        boolean b22 = viagem18.equals((java.lang.Object) 100L);
        Viagem viagem23 = new Viagem(viagem18);
        java.util.GregorianCalendar gregorianCalendar24 = viagem18.getData();
        java.lang.String str25 = viagem18.toString();
        java.lang.String str26 = viagem18.getMail();
        Viagem viagem27 = new Viagem();
        viagem27.setTempo(10.0d);
        boolean b31 = viagem27.equals((java.lang.Object) 100L);
        Coordenada coordenada32 = viagem27.getcfinal();
        Viagem viagem33 = new Viagem();
        viagem33.setTempo(10.0d);
        boolean b37 = viagem33.equals((java.lang.Object) 100L);
        Viagem viagem38 = viagem33.clone();
        Coordenada coordenada39 = viagem38.getcfinal();
        viagem27.setcinicial(coordenada39);
        viagem18.setcfinal(coordenada39);
        double d42 = viagem18.getTempo();
        java.util.GregorianCalendar gregorianCalendar43 = viagem18.getData();
        Viagem viagem46 = new Viagem(coordenada6, coordenada15, (double) (short) -1, "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00", gregorianCalendar43, (double) (-1L), (double) (-1));
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem38, viagem46, and viagem38", !(viagem38.compareTo(viagem46) > 0 && viagem46.compareTo(viagem38) > 0) || viagem38.compareTo(viagem38) > 0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test183");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        Coordenada coordenada3 = viagem0.getcinicial();
        Viagem viagem4 = new Viagem(viagem0);
        double d5 = viagem4.getPreco();
        viagem4.setTempo((double) (-263));
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem2, viagem4, and viagem2", !(viagem2.compareTo(viagem4) > 0 && viagem4.compareTo(viagem2) > 0) || viagem2.compareTo(viagem2) > 0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test184");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        double d8 = viagem0.getPreco();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str11 = viagem0.getMail();
        Coordenada coordenada12 = viagem0.getcinicial();
        Coordenada coordenada13 = null;
        viagem0.setcinicial(coordenada13);
        org.junit.Assert.assertTrue("Contract failed: compareTo-reflexive on viagem0", viagem0.compareTo(viagem0) == 0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test185");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Coordenada coordenada5 = viagem0.getcfinal();
        Viagem viagem6 = new Viagem();
        viagem6.setTempo(10.0d);
        boolean b10 = viagem6.equals((java.lang.Object) 100L);
        Viagem viagem11 = viagem6.clone();
        Coordenada coordenada12 = viagem11.getcfinal();
        viagem0.setcinicial(coordenada12);
        Viagem viagem14 = new Viagem();
        viagem14.setTempo(10.0d);
        boolean b18 = viagem14.equals((java.lang.Object) 100L);
        double d19 = viagem14.getTempo();
        viagem14.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem22 = new Viagem();
        viagem22.setTempo(10.0d);
        boolean b26 = viagem22.equals((java.lang.Object) 100L);
        double d27 = viagem22.getTempo();
        viagem22.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str30 = viagem22.toString();
        viagem22.setMail("");
        double d33 = viagem22.getDesvio();
        int i34 = viagem14.compareTo(viagem22);
        double d35 = viagem14.getPreco();
        Viagem viagem36 = new Viagem();
        viagem36.setTempo(10.0d);
        boolean b40 = viagem36.equals((java.lang.Object) 100L);
        double d41 = viagem36.getTempo();
        viagem36.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str44 = viagem36.toString();
        viagem36.setMail("");
        Coordenada coordenada47 = viagem36.getcinicial();
        viagem14.setcinicial(coordenada47);
        Viagem viagem51 = new Viagem();
        java.lang.String str52 = viagem51.toString();
        Viagem viagem53 = viagem51.clone();
        double d54 = viagem53.getDesvio();
        java.util.GregorianCalendar gregorianCalendar55 = viagem53.getData();
        Viagem viagem58 = new Viagem(coordenada12, coordenada47, (double) (-527), "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 100.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00", gregorianCalendar55, (double) (byte) 100, 0.0d);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem14 and viagem51", Math.signum(viagem14.compareTo(viagem51)) == -Math.signum(viagem51.compareTo(viagem14)));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test186");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        viagem0.setMail("hi!");
        Coordenada coordenada4 = viagem0.getcfinal();
        double d5 = viagem0.getPreco();
        Viagem viagem6 = new Viagem();
        java.lang.String str7 = viagem6.toString();
        double d8 = viagem6.getPreco();
        Coordenada coordenada9 = viagem6.getcfinal();
        viagem6.setMail("hi!");
        int i12 = viagem0.compareTo(viagem6);
        double d13 = viagem6.getDesvio();
        Coordenada coordenada14 = viagem6.getcinicial();
        Viagem viagem15 = new Viagem();
        viagem15.setTempo(10.0d);
        boolean b19 = viagem15.equals((java.lang.Object) 100L);
        double d20 = viagem15.getTempo();
        viagem15.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem23 = new Viagem();
        viagem23.setTempo(10.0d);
        boolean b27 = viagem23.equals((java.lang.Object) 100L);
        double d28 = viagem23.getTempo();
        viagem23.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str31 = viagem23.toString();
        viagem23.setMail("");
        double d34 = viagem23.getDesvio();
        int i35 = viagem15.compareTo(viagem23);
        double d36 = viagem15.getPreco();
        java.util.GregorianCalendar gregorianCalendar37 = viagem15.getData();
        double d38 = viagem15.getTempo();
        Viagem viagem39 = new Viagem();
        viagem39.setTempo(10.0d);
        boolean b43 = viagem39.equals((java.lang.Object) 100L);
        Coordenada coordenada44 = viagem39.getcfinal();
        Coordenada coordenada45 = viagem39.getcinicial();
        Coordenada coordenada46 = viagem39.getcinicial();
        Viagem viagem47 = new Viagem();
        viagem47.setTempo(10.0d);
        boolean b51 = viagem47.equals((java.lang.Object) 100L);
        Coordenada coordenada52 = viagem47.getcfinal();
        double d53 = viagem47.getTempo();
        Viagem viagem54 = new Viagem(viagem47);
        Coordenada coordenada55 = viagem47.getcfinal();
        Viagem viagem58 = new Viagem();
        viagem58.setTempo(10.0d);
        boolean b62 = viagem58.equals((java.lang.Object) 100L);
        Viagem viagem63 = viagem58.clone();
        Coordenada coordenada64 = viagem63.getcfinal();
        java.util.GregorianCalendar gregorianCalendar65 = viagem63.getData();
        Viagem viagem68 = new Viagem(coordenada46, coordenada55, (double) (short) 10, "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: -1.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00", gregorianCalendar65, (double) (byte) 10, (double) (short) -1);
        viagem15.setcinicial(coordenada55);
        viagem6.setcfinal(coordenada55);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem68 and viagem0", Math.signum(viagem68.compareTo(viagem0)) == -Math.signum(viagem0.compareTo(viagem68)));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test187");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem();
        viagem8.setTempo(10.0d);
        boolean b12 = viagem8.equals((java.lang.Object) 100L);
        double d13 = viagem8.getTempo();
        viagem8.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str16 = viagem8.toString();
        viagem8.setMail("");
        double d19 = viagem8.getDesvio();
        int i20 = viagem0.compareTo(viagem8);
        double d21 = viagem0.getPreco();
        Viagem viagem22 = new Viagem();
        viagem22.setTempo(10.0d);
        boolean b26 = viagem22.equals((java.lang.Object) 100L);
        double d27 = viagem22.getTempo();
        viagem22.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str30 = viagem22.toString();
        viagem22.setMail("");
        Coordenada coordenada33 = viagem22.getcinicial();
        viagem0.setcinicial(coordenada33);
        Viagem viagem35 = viagem0.clone();
        java.util.GregorianCalendar gregorianCalendar36 = viagem0.getData();
        viagem0.setTempo((double) 'a');
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem22, viagem0, and viagem22", !(viagem22.compareTo(viagem0) > 0 && viagem0.compareTo(viagem22) > 0) || viagem22.compareTo(viagem22) > 0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test188");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Coordenada coordenada6 = viagem5.getcfinal();
        Coordenada coordenada7 = null;
        viagem5.setcinicial(coordenada7);
        org.junit.Assert.assertTrue("Contract failed: compareTo-reflexive on viagem5", viagem5.compareTo(viagem5) == 0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test189");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = new Viagem(viagem0);
        double d6 = viagem0.getTempo();
        double d7 = viagem0.getPreco();
        double d8 = viagem0.getPreco();
        double d9 = viagem0.getDesvio();
        Viagem viagem10 = new Viagem();
        viagem10.setTempo(10.0d);
        boolean b14 = viagem10.equals((java.lang.Object) 100L);
        Viagem viagem15 = viagem10.clone();
        Viagem viagem16 = new Viagem();
        viagem16.setTempo(10.0d);
        boolean b20 = viagem16.equals((java.lang.Object) 100L);
        double d21 = viagem16.getTempo();
        viagem16.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str24 = viagem16.toString();
        viagem16.setMail("");
        double d27 = viagem16.getDesvio();
        java.util.GregorianCalendar gregorianCalendar28 = viagem16.getData();
        int i29 = viagem15.compareTo(viagem16);
        Viagem viagem30 = viagem15.clone();
        Coordenada coordenada31 = viagem15.getcinicial();
        viagem0.setcinicial(coordenada31);
        viagem0.setTempo((double) 0L);
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem30, viagem0, and viagem30", !(viagem30.compareTo(viagem0) > 0 && viagem0.compareTo(viagem30) > 0) || viagem30.compareTo(viagem30) > 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test190");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem();
        java.lang.String str9 = viagem8.toString();
        double d10 = viagem8.getPreco();
        Coordenada coordenada11 = viagem8.getcfinal();
        viagem8.setMail("hi!");
        java.lang.String str14 = viagem8.getMail();
        Coordenada coordenada15 = viagem8.getcinicial();
        viagem0.setcfinal(coordenada15);
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem8, viagem0, and viagem8", !(viagem8.compareTo(viagem0) > 0 && viagem0.compareTo(viagem8) > 0) || viagem8.compareTo(viagem8) > 0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test191");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = new Viagem(viagem0);
        double d6 = viagem0.getTempo();
        double d7 = viagem0.getPreco();
        Viagem viagem8 = viagem0.clone();
        viagem8.setTempo((double) ' ');
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem0, viagem8, and viagem0", !(viagem0.compareTo(viagem8) > 0 && viagem8.compareTo(viagem0) > 0) || viagem0.compareTo(viagem0) > 0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test192");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        java.lang.String str9 = viagem0.toString();
        java.lang.String str10 = viagem0.toString();
        java.lang.String str11 = viagem0.toString();
        Viagem viagem12 = new Viagem();
        viagem12.setTempo(10.0d);
        boolean b16 = viagem12.equals((java.lang.Object) 100L);
        double d17 = viagem12.getTempo();
        viagem12.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem20 = new Viagem(viagem12);
        Coordenada coordenada21 = viagem12.getcfinal();
        Viagem viagem22 = new Viagem();
        viagem22.setTempo(10.0d);
        boolean b26 = viagem22.equals((java.lang.Object) 100L);
        Coordenada coordenada27 = viagem22.getcfinal();
        double d28 = viagem22.getTempo();
        Viagem viagem29 = new Viagem(viagem22);
        int i30 = viagem12.compareTo(viagem22);
        double d31 = viagem12.getPreco();
        Viagem viagem32 = new Viagem();
        viagem32.setTempo(10.0d);
        boolean b36 = viagem32.equals((java.lang.Object) 100L);
        double d37 = viagem32.getTempo();
        viagem32.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem40 = new Viagem(viagem32);
        Coordenada coordenada41 = viagem32.getcfinal();
        viagem12.setcfinal(coordenada41);
        Viagem viagem43 = viagem12.clone();
        Viagem viagem44 = viagem43.clone();
        Viagem viagem45 = new Viagem();
        viagem45.setTempo(10.0d);
        boolean b49 = viagem45.equals((java.lang.Object) 100L);
        Coordenada coordenada50 = viagem45.getcfinal();
        Viagem viagem51 = new Viagem();
        viagem51.setTempo(10.0d);
        boolean b55 = viagem51.equals((java.lang.Object) 100L);
        Viagem viagem56 = viagem51.clone();
        Coordenada coordenada57 = viagem56.getcfinal();
        viagem45.setcinicial(coordenada57);
        viagem44.setcfinal(coordenada57);
        viagem0.setcinicial(coordenada57);
        Viagem viagem61 = new Viagem();
        java.lang.String str62 = viagem61.toString();
        Viagem viagem63 = viagem61.clone();
        Coordenada coordenada64 = viagem61.getcfinal();
        Coordenada coordenada65 = viagem61.getcfinal();
        Viagem viagem68 = new Viagem();
        viagem68.setTempo(10.0d);
        boolean b72 = viagem68.equals((java.lang.Object) 100L);
        double d73 = viagem68.getTempo();
        viagem68.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem76 = new Viagem(viagem68);
        Viagem viagem77 = viagem76.clone();
        Coordenada coordenada78 = viagem77.getcfinal();
        Viagem viagem79 = new Viagem();
        viagem79.setTempo(10.0d);
        boolean b83 = viagem79.equals((java.lang.Object) 100L);
        double d84 = viagem79.getTempo();
        viagem79.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str87 = viagem79.toString();
        viagem79.setMail("");
        Viagem viagem90 = new Viagem(viagem79);
        int i91 = viagem77.compareTo(viagem90);
        double d92 = viagem77.getDesvio();
        java.util.GregorianCalendar gregorianCalendar93 = viagem77.getData();
        Viagem viagem96 = new Viagem(coordenada57, coordenada65, (double) (-37), "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00", gregorianCalendar93, (double) (-527), 0.0d);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem22 and viagem63", Math.signum(viagem22.compareTo(viagem63)) == -Math.signum(viagem63.compareTo(viagem22)));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test193");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Viagem viagem9 = viagem8.clone();
        Coordenada coordenada10 = viagem9.getcfinal();
        Viagem viagem11 = new Viagem();
        viagem11.setTempo(10.0d);
        boolean b15 = viagem11.equals((java.lang.Object) 100L);
        double d16 = viagem11.getTempo();
        viagem11.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str19 = viagem11.toString();
        viagem11.setMail("");
        Viagem viagem22 = new Viagem(viagem11);
        int i23 = viagem9.compareTo(viagem22);
        java.lang.String str24 = viagem22.getMail();
        java.util.GregorianCalendar gregorianCalendar25 = viagem22.getData();
        Coordenada coordenada26 = null;
        viagem22.setcinicial(coordenada26);
        org.junit.Assert.assertTrue("Contract failed: compareTo-reflexive on viagem22", viagem22.compareTo(viagem22) == 0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test194");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        double d2 = viagem0.getPreco();
        Coordenada coordenada3 = viagem0.getcfinal();
        viagem0.setMail("hi!");
        java.lang.String str6 = viagem0.getMail();
        java.lang.String str7 = viagem0.toString();
        Viagem viagem8 = new Viagem();
        viagem8.setTempo(10.0d);
        boolean b12 = viagem8.equals((java.lang.Object) 100L);
        Viagem viagem13 = viagem8.clone();
        Viagem viagem14 = new Viagem(viagem8);
        Viagem viagem15 = new Viagem();
        viagem15.setTempo(10.0d);
        boolean b19 = viagem15.equals((java.lang.Object) 100L);
        Viagem viagem20 = viagem15.clone();
        Viagem viagem21 = new Viagem(viagem15);
        int i22 = viagem8.compareTo(viagem15);
        double d23 = viagem15.getTempo();
        Viagem viagem24 = viagem15.clone();
        double d25 = viagem24.getTempo();
        Viagem viagem26 = new Viagem();
        viagem26.setTempo(10.0d);
        boolean b30 = viagem26.equals((java.lang.Object) 100L);
        double d31 = viagem26.getTempo();
        viagem26.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem34 = new Viagem(viagem26);
        Viagem viagem35 = viagem26.clone();
        java.lang.String str36 = viagem35.toString();
        Coordenada coordenada37 = viagem35.getcfinal();
        viagem24.setcinicial(coordenada37);
        viagem0.setcfinal(coordenada37);
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem14, viagem0, and viagem14", !(viagem14.compareTo(viagem0) > 0 && viagem0.compareTo(viagem14) > 0) || viagem14.compareTo(viagem14) > 0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test195");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = new Viagem(viagem0);
        java.util.GregorianCalendar gregorianCalendar6 = viagem0.getData();
        java.lang.String str7 = viagem0.toString();
        java.lang.String str8 = viagem0.getMail();
        double d9 = viagem0.getTempo();
        Coordenada coordenada10 = viagem0.getcinicial();
        Viagem viagem11 = new Viagem();
        viagem11.setTempo(10.0d);
        boolean b15 = viagem11.equals((java.lang.Object) 100L);
        double d16 = viagem11.getTempo();
        viagem11.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem19 = new Viagem(viagem11);
        Viagem viagem20 = viagem19.clone();
        Coordenada coordenada21 = viagem20.getcfinal();
        Viagem viagem22 = new Viagem();
        viagem22.setTempo(10.0d);
        boolean b26 = viagem22.equals((java.lang.Object) 100L);
        double d27 = viagem22.getTempo();
        viagem22.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str30 = viagem22.toString();
        viagem22.setMail("");
        Viagem viagem33 = new Viagem(viagem22);
        int i34 = viagem20.compareTo(viagem33);
        java.lang.String str35 = viagem33.getMail();
        Viagem viagem36 = new Viagem(viagem33);
        Viagem viagem37 = new Viagem(viagem36);
        Coordenada coordenada38 = viagem36.getcinicial();
        Viagem viagem41 = new Viagem();
        viagem41.setTempo(10.0d);
        boolean b45 = viagem41.equals((java.lang.Object) 100L);
        Coordenada coordenada46 = viagem41.getcfinal();
        Coordenada coordenada47 = viagem41.getcinicial();
        Coordenada coordenada48 = viagem41.getcinicial();
        Viagem viagem49 = new Viagem();
        viagem49.setTempo(10.0d);
        boolean b53 = viagem49.equals((java.lang.Object) 100L);
        Coordenada coordenada54 = viagem49.getcfinal();
        double d55 = viagem49.getTempo();
        Viagem viagem56 = new Viagem(viagem49);
        Coordenada coordenada57 = viagem49.getcfinal();
        Viagem viagem60 = new Viagem();
        viagem60.setTempo(10.0d);
        boolean b64 = viagem60.equals((java.lang.Object) 100L);
        Viagem viagem65 = viagem60.clone();
        Coordenada coordenada66 = viagem65.getcfinal();
        java.util.GregorianCalendar gregorianCalendar67 = viagem65.getData();
        Viagem viagem70 = new Viagem(coordenada48, coordenada57, (double) (short) 10, "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: -1.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00", gregorianCalendar67, (double) (byte) 10, (double) (short) -1);
        Viagem viagem73 = new Viagem(coordenada10, coordenada38, (double) (byte) 1, "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00", gregorianCalendar67, (double) 10L, 0.0d);
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem60, viagem73, and viagem60", !(viagem60.compareTo(viagem73) > 0 && viagem73.compareTo(viagem60) > 0) || viagem60.compareTo(viagem60) > 0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test196");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = new Viagem(viagem0);
        java.lang.String str6 = viagem0.getMail();
        Viagem viagem7 = new Viagem();
        viagem7.setTempo(10.0d);
        boolean b11 = viagem7.equals((java.lang.Object) 100L);
        Viagem viagem12 = new Viagem(viagem7);
        java.lang.String str13 = viagem7.getMail();
        boolean b14 = viagem0.equals((java.lang.Object) viagem7);
        Viagem viagem15 = new Viagem();
        viagem15.setTempo(10.0d);
        boolean b19 = viagem15.equals((java.lang.Object) 100L);
        Viagem viagem20 = viagem15.clone();
        Viagem viagem21 = new Viagem(viagem15);
        Viagem viagem22 = new Viagem();
        viagem22.setTempo(10.0d);
        boolean b26 = viagem22.equals((java.lang.Object) 100L);
        Viagem viagem27 = viagem22.clone();
        Viagem viagem28 = new Viagem(viagem22);
        int i29 = viagem15.compareTo(viagem22);
        viagem22.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        int i32 = viagem7.compareTo(viagem22);
        java.lang.String str33 = viagem7.getMail();
        viagem7.setTempo((double) ' ');
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem20, viagem7, and viagem20", !(viagem20.compareTo(viagem7) > 0 && viagem7.compareTo(viagem20) > 0) || viagem20.compareTo(viagem20) > 0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test197");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        double d2 = viagem0.getPreco();
        Coordenada coordenada3 = viagem0.getcfinal();
        viagem0.setMail("hi!");
        java.lang.String str6 = viagem0.getMail();
        Coordenada coordenada7 = viagem0.getcinicial();
        Viagem viagem8 = new Viagem();
        viagem8.setTempo(10.0d);
        boolean b12 = viagem8.equals((java.lang.Object) 100L);
        Viagem viagem13 = viagem8.clone();
        boolean b14 = viagem0.equals((java.lang.Object) viagem8);
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem13, viagem0, and viagem13", !(viagem13.compareTo(viagem0) > 0 && viagem0.compareTo(viagem13) > 0) || viagem13.compareTo(viagem13) > 0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test198");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Coordenada coordenada5 = viagem0.getcfinal();
        double d6 = viagem0.getTempo();
        Viagem viagem7 = new Viagem(viagem0);
        Viagem viagem8 = viagem7.clone();
        double d9 = viagem7.getTempo();
        Viagem viagem10 = new Viagem();
        viagem10.setTempo(10.0d);
        boolean b14 = viagem10.equals((java.lang.Object) 100L);
        double d15 = viagem10.getTempo();
        viagem10.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem18 = new Viagem();
        viagem18.setTempo(10.0d);
        boolean b22 = viagem18.equals((java.lang.Object) 100L);
        double d23 = viagem18.getTempo();
        viagem18.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str26 = viagem18.toString();
        viagem18.setMail("");
        double d29 = viagem18.getDesvio();
        int i30 = viagem10.compareTo(viagem18);
        Coordenada coordenada31 = viagem10.getcinicial();
        viagem7.setcinicial(coordenada31);
        Viagem viagem33 = new Viagem();
        java.lang.String str34 = viagem33.toString();
        Viagem viagem35 = new Viagem(viagem33);
        double d36 = viagem33.getPreco();
        int i37 = viagem7.compareTo(viagem33);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem0 and viagem35", Math.signum(viagem0.compareTo(viagem35)) == -Math.signum(viagem35.compareTo(viagem0)));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test199");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Viagem viagem6 = new Viagem(viagem0);
        Viagem viagem7 = new Viagem();
        viagem7.setTempo(10.0d);
        boolean b11 = viagem7.equals((java.lang.Object) 100L);
        Viagem viagem12 = viagem7.clone();
        Viagem viagem13 = new Viagem(viagem7);
        int i14 = viagem0.compareTo(viagem7);
        double d15 = viagem7.getTempo();
        Viagem viagem16 = viagem7.clone();
        Viagem viagem17 = viagem7.clone();
        Viagem viagem18 = new Viagem(viagem17);
        Viagem viagem19 = new Viagem();
        java.lang.String str20 = viagem19.toString();
        Viagem viagem21 = viagem19.clone();
        Coordenada coordenada22 = viagem19.getcinicial();
        java.lang.Object obj23 = null;
        boolean b24 = viagem19.equals(obj23);
        boolean b26 = viagem19.equals((java.lang.Object) (byte) 10);
        boolean b27 = viagem18.equals((java.lang.Object) b26);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem17 and viagem19", Math.signum(viagem17.compareTo(viagem19)) == -Math.signum(viagem19.compareTo(viagem17)));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test200");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = new Viagem(viagem0);
        Coordenada coordenada3 = viagem2.getcinicial();
        Coordenada coordenada4 = viagem2.getcfinal();
        java.lang.String str5 = viagem2.toString();
        Viagem viagem6 = new Viagem(viagem2);
        viagem6.setTempo((double) (short) -1);
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem0, viagem6, and viagem0", !(viagem0.compareTo(viagem6) > 0 && viagem6.compareTo(viagem0) > 0) || viagem0.compareTo(viagem0) > 0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test201");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        Coordenada coordenada3 = viagem0.getcinicial();
        Viagem viagem4 = new Viagem(viagem0);
        viagem4.setTempo((double) (short) 0);
        Viagem viagem7 = new Viagem();
        java.lang.String str8 = viagem7.toString();
        Viagem viagem9 = viagem7.clone();
        Coordenada coordenada10 = viagem7.getcinicial();
        boolean b11 = viagem4.equals((java.lang.Object) coordenada10);
        Viagem viagem12 = new Viagem();
        viagem12.setTempo(10.0d);
        boolean b16 = viagem12.equals((java.lang.Object) 100L);
        double d17 = viagem12.getTempo();
        Coordenada coordenada18 = viagem12.getcfinal();
        Viagem viagem19 = new Viagem();
        viagem19.setTempo(10.0d);
        boolean b23 = viagem19.equals((java.lang.Object) 100L);
        double d24 = viagem19.getTempo();
        viagem19.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem27 = new Viagem(viagem19);
        Coordenada coordenada28 = viagem19.getcfinal();
        Viagem viagem29 = new Viagem();
        viagem29.setTempo(10.0d);
        boolean b33 = viagem29.equals((java.lang.Object) 100L);
        Coordenada coordenada34 = viagem29.getcfinal();
        double d35 = viagem29.getTempo();
        Viagem viagem36 = new Viagem(viagem29);
        int i37 = viagem19.compareTo(viagem29);
        double d38 = viagem19.getPreco();
        Viagem viagem39 = new Viagem();
        viagem39.setTempo(10.0d);
        boolean b43 = viagem39.equals((java.lang.Object) 100L);
        double d44 = viagem39.getTempo();
        viagem39.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem47 = new Viagem(viagem39);
        Coordenada coordenada48 = viagem39.getcfinal();
        viagem19.setcfinal(coordenada48);
        viagem12.setcinicial(coordenada48);
        Viagem viagem53 = new Viagem();
        viagem53.setTempo(10.0d);
        boolean b57 = viagem53.equals((java.lang.Object) 100L);
        Viagem viagem58 = viagem53.clone();
        Viagem viagem59 = new Viagem();
        viagem59.setTempo(10.0d);
        boolean b63 = viagem59.equals((java.lang.Object) 100L);
        double d64 = viagem59.getTempo();
        viagem59.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str67 = viagem59.toString();
        viagem59.setMail("");
        double d70 = viagem59.getDesvio();
        java.util.GregorianCalendar gregorianCalendar71 = viagem59.getData();
        int i72 = viagem58.compareTo(viagem59);
        Viagem viagem73 = new Viagem(viagem59);
        java.util.GregorianCalendar gregorianCalendar74 = viagem73.getData();
        Viagem viagem77 = new Viagem(coordenada10, coordenada48, (double) (-94), "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00", gregorianCalendar74, (double) (-37), (double) (-1.0f));
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem29 and viagem7", Math.signum(viagem29.compareTo(viagem7)) == -Math.signum(viagem7.compareTo(viagem29)));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test202");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        java.util.GregorianCalendar gregorianCalendar2 = viagem0.getData();
        double d3 = viagem0.getDesvio();
        Viagem viagem4 = new Viagem();
        viagem4.setTempo(10.0d);
        boolean b8 = viagem4.equals((java.lang.Object) 100L);
        Viagem viagem9 = new Viagem(viagem4);
        java.lang.String str10 = viagem4.getMail();
        Viagem viagem11 = new Viagem();
        viagem11.setTempo(10.0d);
        boolean b15 = viagem11.equals((java.lang.Object) 100L);
        Viagem viagem16 = new Viagem(viagem11);
        java.lang.String str17 = viagem11.getMail();
        boolean b18 = viagem4.equals((java.lang.Object) viagem11);
        Viagem viagem19 = new Viagem();
        viagem19.setTempo(10.0d);
        boolean b23 = viagem19.equals((java.lang.Object) 100L);
        Viagem viagem24 = new Viagem(viagem19);
        java.util.GregorianCalendar gregorianCalendar25 = viagem19.getData();
        java.lang.String str26 = viagem19.toString();
        double d27 = viagem19.getPreco();
        Coordenada coordenada28 = viagem19.getcinicial();
        viagem11.setcfinal(coordenada28);
        viagem0.setcinicial(coordenada28);
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem19, viagem0, and viagem19", !(viagem19.compareTo(viagem0) > 0 && viagem0.compareTo(viagem19) > 0) || viagem19.compareTo(viagem19) > 0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test203");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = new Viagem(viagem0);
        Coordenada coordenada3 = viagem2.getcinicial();
        Coordenada coordenada4 = viagem2.getcfinal();
        java.lang.String str5 = viagem2.getMail();
        double d6 = viagem2.getPreco();
        Viagem viagem7 = new Viagem(viagem2);
        Coordenada coordenada8 = null;
        viagem2.setcinicial(coordenada8);
        org.junit.Assert.assertTrue("Contract failed: compareTo-reflexive on viagem2", viagem2.compareTo(viagem2) == 0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test204");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        double d3 = viagem2.getDesvio();
        java.util.GregorianCalendar gregorianCalendar4 = viagem2.getData();
        viagem2.setMail("");
        Viagem viagem7 = new Viagem();
        viagem7.setTempo(10.0d);
        boolean b11 = viagem7.equals((java.lang.Object) 100L);
        double d12 = viagem7.getTempo();
        viagem7.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.util.GregorianCalendar gregorianCalendar15 = viagem7.getData();
        Viagem viagem16 = new Viagem();
        viagem16.setTempo(10.0d);
        boolean b20 = viagem16.equals((java.lang.Object) 100L);
        double d21 = viagem16.getTempo();
        Viagem viagem22 = new Viagem();
        viagem22.setTempo(10.0d);
        boolean b26 = viagem22.equals((java.lang.Object) 100L);
        double d27 = viagem22.getTempo();
        viagem22.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Coordenada coordenada30 = viagem22.getcfinal();
        viagem16.setcinicial(coordenada30);
        viagem7.setcinicial(coordenada30);
        viagem2.setcfinal(coordenada30);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem7 and viagem0", Math.signum(viagem7.compareTo(viagem0)) == -Math.signum(viagem0.compareTo(viagem7)));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test205");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem();
        viagem8.setTempo(10.0d);
        boolean b12 = viagem8.equals((java.lang.Object) 100L);
        double d13 = viagem8.getTempo();
        viagem8.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str16 = viagem8.toString();
        viagem8.setMail("");
        double d19 = viagem8.getDesvio();
        int i20 = viagem0.compareTo(viagem8);
        double d21 = viagem0.getPreco();
        java.lang.String str22 = viagem0.toString();
        Viagem viagem23 = new Viagem();
        java.lang.String str24 = viagem23.toString();
        Viagem viagem25 = viagem23.clone();
        Coordenada coordenada26 = viagem23.getcinicial();
        Viagem viagem27 = new Viagem(viagem23);
        double d28 = viagem27.getPreco();
        Coordenada coordenada29 = viagem27.getcfinal();
        Viagem viagem30 = viagem27.clone();
        Coordenada coordenada31 = viagem27.getcfinal();
        viagem0.setcfinal(coordenada31);
        org.junit.Assert.assertTrue("Contract failed: compareTo-anti-symmetric on viagem27 and viagem8", Math.signum(viagem27.compareTo(viagem8)) == -Math.signum(viagem8.compareTo(viagem27)));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test206");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        viagem0.setMail("hi!");
        Coordenada coordenada4 = viagem0.getcfinal();
        double d5 = viagem0.getPreco();
        Viagem viagem6 = new Viagem();
        java.lang.String str7 = viagem6.toString();
        double d8 = viagem6.getPreco();
        Coordenada coordenada9 = viagem6.getcfinal();
        viagem6.setMail("hi!");
        int i12 = viagem0.compareTo(viagem6);
        Viagem viagem13 = new Viagem();
        java.lang.String str14 = viagem13.toString();
        java.util.GregorianCalendar gregorianCalendar15 = viagem13.getData();
        viagem13.setTempo((double) (short) -1);
        int i18 = viagem0.compareTo(viagem13);
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem6, viagem13, and viagem6", !(viagem6.compareTo(viagem13) > 0 && viagem13.compareTo(viagem6) > 0) || viagem6.compareTo(viagem6) > 0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test207");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Viagem viagem6 = new Viagem(viagem0);
        Viagem viagem7 = new Viagem();
        viagem7.setTempo(10.0d);
        boolean b11 = viagem7.equals((java.lang.Object) 100L);
        Viagem viagem12 = viagem7.clone();
        Viagem viagem13 = new Viagem(viagem7);
        int i14 = viagem0.compareTo(viagem7);
        double d15 = viagem7.getTempo();
        Viagem viagem16 = viagem7.clone();
        Viagem viagem17 = new Viagem();
        viagem17.setTempo(10.0d);
        boolean b21 = viagem17.equals((java.lang.Object) 100L);
        double d22 = viagem17.getTempo();
        double d23 = viagem17.getPreco();
        Viagem viagem24 = new Viagem(viagem17);
        Viagem viagem25 = new Viagem(viagem17);
        int i26 = viagem7.compareTo(viagem25);
        java.lang.String str27 = viagem7.toString();
        viagem7.setTempo((double) (byte) 1);
        org.junit.Assert.assertTrue("Contract failed: compareTo-transitive on viagem0, viagem7, and viagem0", !(viagem0.compareTo(viagem7) > 0 && viagem7.compareTo(viagem0) > 0) || viagem0.compareTo(viagem0) > 0);
    }
}

