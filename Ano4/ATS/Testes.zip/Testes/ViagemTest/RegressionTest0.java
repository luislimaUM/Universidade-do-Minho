import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        Coordenada coordenada0 = null;
        Coordenada coordenada1 = null;
        java.util.GregorianCalendar gregorianCalendar4 = null;
        try {
            Viagem viagem7 = new Viagem(coordenada0, coordenada1, (double) 0, "", gregorianCalendar4, (double) (byte) 10, (double) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        Coordenada coordenada0 = null;
        Coordenada coordenada1 = null;
        java.util.GregorianCalendar gregorianCalendar4 = null;
        try {
            Viagem viagem7 = new Viagem(coordenada0, coordenada1, 100.0d, "", gregorianCalendar4, (double) (short) 100, (double) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        Coordenada coordenada0 = null;
        Coordenada coordenada1 = null;
        java.util.GregorianCalendar gregorianCalendar4 = null;
        try {
            Viagem viagem7 = new Viagem(coordenada0, coordenada1, (double) '4', "", gregorianCalendar4, (double) (-1), (double) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Coordenada coordenada5 = viagem0.getcfinal();
        Viagem viagem6 = new Viagem();
        viagem6.setTempo(10.0d);
        boolean b10 = viagem6.equals((java.lang.Object) 100L);
        Coordenada coordenada11 = viagem6.getcfinal();
        java.util.GregorianCalendar gregorianCalendar14 = null;
        try {
            Viagem viagem17 = new Viagem(coordenada5, coordenada11, (double) (byte) 1, "", gregorianCalendar14, (double) 100, (double) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertNotNull(coordenada11);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getPreco();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 0.0d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Coordenada coordenada5 = viagem0.getcfinal();
        Viagem viagem6 = new Viagem();
        java.lang.String str7 = viagem6.toString();
        Viagem viagem8 = viagem6.clone();
        Coordenada coordenada9 = viagem6.getcinicial();
        java.util.GregorianCalendar gregorianCalendar12 = null;
        try {
            Viagem viagem15 = new Viagem(coordenada5, coordenada9, (double) 0, "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00", gregorianCalendar12, (double) 0, (double) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str7.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem8);
        org.junit.Assert.assertNotNull(coordenada9);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Coordenada coordenada5 = viagem0.getcfinal();
        Viagem viagem6 = new Viagem();
        viagem6.setTempo(10.0d);
        boolean b10 = viagem6.equals((java.lang.Object) 100L);
        Coordenada coordenada11 = viagem6.getcfinal();
        java.util.GregorianCalendar gregorianCalendar14 = null;
        try {
            Viagem viagem17 = new Viagem(coordenada5, coordenada11, (double) 10L, "hi!", gregorianCalendar14, (double) (short) 10, (double) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertNotNull(coordenada11);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        double d2 = viagem0.getPreco();
        Coordenada coordenada3 = viagem0.getcfinal();
        Viagem viagem4 = new Viagem();
        viagem4.setTempo(10.0d);
        boolean b8 = viagem4.equals((java.lang.Object) 100L);
        Coordenada coordenada9 = viagem4.getcfinal();
        java.util.GregorianCalendar gregorianCalendar12 = null;
        try {
            Viagem viagem15 = new Viagem(coordenada3, coordenada9, (double) 0, "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00", gregorianCalendar12, (double) (-1.0f), (double) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d2 == 0.0d);
        org.junit.Assert.assertNotNull(coordenada3);
        org.junit.Assert.assertTrue(b8 == false);
        org.junit.Assert.assertNotNull(coordenada9);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        Coordenada coordenada3 = viagem0.getcinicial();
        java.lang.Object obj4 = null;
        boolean b5 = viagem0.equals(obj4);
        Viagem viagem6 = new Viagem();
        java.lang.String str7 = viagem6.toString();
        Viagem viagem8 = viagem6.clone();
        java.lang.String str9 = viagem8.getMail();
        boolean b10 = viagem0.equals((java.lang.Object) str9);
        java.util.GregorianCalendar gregorianCalendar11 = viagem0.getData();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertNotNull(coordenada3);
        org.junit.Assert.assertTrue(b5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str7.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertNotNull(gregorianCalendar11);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        java.util.GregorianCalendar gregorianCalendar5 = viagem0.getData();
        double d6 = viagem0.getPreco();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(gregorianCalendar5);
        org.junit.Assert.assertTrue(d6 == 0.0d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Coordenada coordenada6 = viagem5.getcfinal();
        java.lang.String str7 = viagem5.getMail();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(viagem5);
        org.junit.Assert.assertNotNull(coordenada6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Coordenada coordenada5 = viagem0.getcfinal();
        double d6 = viagem0.getTempo();
        Viagem viagem7 = new Viagem(viagem0);
        double d8 = viagem7.getPreco();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(d6 == 10.0d);
        org.junit.Assert.assertTrue(d8 == 0.0d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        double d3 = viagem2.getDesvio();
        java.lang.String str4 = viagem2.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertTrue(d3 == 0.0d);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str4.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Coordenada coordenada9 = viagem0.getcfinal();
        java.lang.String str10 = viagem0.toString();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str10.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Viagem viagem9 = viagem8.clone();
        Coordenada coordenada10 = viagem9.getcfinal();
        Viagem viagem11 = new Viagem();
        viagem11.setTempo(10.0d);
        boolean b15 = viagem11.equals((java.lang.Object) 100L);
        double d16 = viagem11.getTempo();
        viagem11.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str19 = viagem11.toString();
        viagem11.setMail("");
        Viagem viagem22 = new Viagem(viagem11);
        int i23 = viagem9.compareTo(viagem22);
        Viagem viagem24 = new Viagem(viagem22);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertNotNull(viagem9);
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertTrue(d16 == 10.0d);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str19.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(i23 == 263);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        Coordenada coordenada3 = viagem0.getcinicial();
        Viagem viagem4 = new Viagem(viagem0);
        double d5 = viagem4.getPreco();
        viagem4.setMail("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertNotNull(coordenada3);
        org.junit.Assert.assertTrue(d5 == 0.0d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        double d6 = viagem0.getPreco();
        Viagem viagem7 = new Viagem();
        viagem7.setTempo(10.0d);
        boolean b11 = viagem7.equals((java.lang.Object) 100L);
        Viagem viagem12 = viagem7.clone();
        boolean b13 = viagem0.equals((java.lang.Object) viagem12);
        Viagem viagem14 = viagem12.clone();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertNotNull(viagem12);
        org.junit.Assert.assertTrue(b13 == true);
        org.junit.Assert.assertNotNull(viagem14);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Coordenada coordenada5 = viagem0.getcfinal();
        double d6 = viagem0.getTempo();
        double d7 = viagem0.getDesvio();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str10 = viagem0.toString();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(d6 == 10.0d);
        org.junit.Assert.assertTrue(d7 == 0.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str10.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Coordenada coordenada5 = viagem0.getcfinal();
        double d6 = viagem0.getTempo();
        Viagem viagem7 = new Viagem(viagem0);
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str10 = viagem0.toString();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(d6 == 10.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str10.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        java.util.GregorianCalendar gregorianCalendar2 = viagem0.getData();
        double d3 = viagem0.getPreco();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(gregorianCalendar2);
        org.junit.Assert.assertTrue(d3 == 0.0d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        viagem0.setMail("hi!");
        Coordenada coordenada4 = viagem0.getcfinal();
        viagem0.setTempo((double) (-1.0f));
        java.lang.String str7 = viagem0.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(coordenada4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: -1.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str7.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: -1.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        double d6 = viagem0.getPreco();
        Viagem viagem7 = new Viagem();
        viagem7.setTempo(10.0d);
        boolean b11 = viagem7.equals((java.lang.Object) 100L);
        Viagem viagem12 = viagem7.clone();
        boolean b13 = viagem0.equals((java.lang.Object) viagem12);
        double d14 = viagem12.getPreco();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertNotNull(viagem12);
        org.junit.Assert.assertTrue(b13 == false);
        org.junit.Assert.assertTrue(d14 == 0.0d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Coordenada coordenada6 = viagem5.getcfinal();
        java.util.GregorianCalendar gregorianCalendar7 = viagem5.getData();
        Coordenada coordenada8 = viagem5.getcfinal();
        double d9 = viagem5.getTempo();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(viagem5);
        org.junit.Assert.assertNotNull(coordenada6);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
        org.junit.Assert.assertNotNull(coordenada8);
        org.junit.Assert.assertTrue(d9 == 10.0d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        Coordenada coordenada3 = viagem0.getcinicial();
        java.lang.Object obj4 = null;
        boolean b5 = viagem0.equals(obj4);
        viagem0.setTempo((double) 0.0f);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertNotNull(coordenada3);
        org.junit.Assert.assertTrue(b5 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem();
        viagem8.setTempo(10.0d);
        boolean b12 = viagem8.equals((java.lang.Object) 100L);
        double d13 = viagem8.getTempo();
        viagem8.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str16 = viagem8.toString();
        viagem8.setMail("");
        double d19 = viagem8.getDesvio();
        int i20 = viagem0.compareTo(viagem8);
        double d21 = viagem0.getPreco();
        Viagem viagem22 = new Viagem();
        viagem22.setTempo(10.0d);
        boolean b26 = viagem22.equals((java.lang.Object) 100L);
        double d27 = viagem22.getTempo();
        viagem22.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str30 = viagem22.toString();
        viagem22.setMail("");
        Coordenada coordenada33 = viagem22.getcinicial();
        viagem0.setcinicial(coordenada33);
        Viagem viagem35 = viagem0.clone();
        double d36 = viagem35.getPreco();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertTrue(d13 == 10.0d);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str16.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d19 == 0.0d);
        org.junit.Assert.assertTrue(i20 == 263);
        org.junit.Assert.assertTrue(d21 == 0.0d);
        org.junit.Assert.assertTrue(b26 == false);
        org.junit.Assert.assertTrue(d27 == 10.0d);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str30.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(coordenada33);
        org.junit.Assert.assertNotNull(viagem35);
        org.junit.Assert.assertTrue(d36 == 0.0d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        viagem0.setMail("hi!");
        Coordenada coordenada4 = viagem0.getcfinal();
        viagem0.setTempo(0.0d);
        java.lang.Object obj7 = null;
        boolean b8 = viagem0.equals(obj7);
        Viagem viagem9 = null;
        try {
            int i10 = viagem0.compareTo(viagem9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(coordenada4);
        org.junit.Assert.assertTrue(b8 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = new Viagem(viagem0);
        double d3 = viagem0.getPreco();
        java.util.GregorianCalendar gregorianCalendar4 = viagem0.getData();
        Viagem viagem5 = viagem0.clone();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d3 == 0.0d);
        org.junit.Assert.assertNotNull(gregorianCalendar4);
        org.junit.Assert.assertNotNull(viagem5);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        double d2 = viagem0.getPreco();
        Coordenada coordenada3 = viagem0.getcfinal();
        viagem0.setMail("hi!");
        Viagem viagem6 = new Viagem();
        java.lang.String str7 = viagem6.toString();
        Viagem viagem8 = viagem6.clone();
        java.lang.String str9 = viagem8.getMail();
        Viagem viagem10 = new Viagem();
        java.lang.String str11 = viagem10.toString();
        Viagem viagem12 = viagem10.clone();
        Coordenada coordenada13 = viagem10.getcinicial();
        viagem8.setcfinal(coordenada13);
        viagem0.setcinicial(coordenada13);
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem18 = new Viagem();
        java.lang.String str19 = viagem18.toString();
        double d20 = viagem18.getPreco();
        double d21 = viagem18.getPreco();
        boolean b22 = viagem0.equals((java.lang.Object) viagem18);
        java.lang.String str23 = viagem0.getMail();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d2 == 0.0d);
        org.junit.Assert.assertNotNull(coordenada3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str7.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str11.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem12);
        org.junit.Assert.assertNotNull(coordenada13);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str19.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d20 == 0.0d);
        org.junit.Assert.assertTrue(d21 == 0.0d);
        org.junit.Assert.assertTrue(b22 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str23.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Viagem viagem6 = new Viagem(viagem0);
        Viagem viagem7 = viagem0.clone();
        Viagem viagem8 = new Viagem();
        viagem8.setTempo(10.0d);
        boolean b12 = viagem8.equals((java.lang.Object) 100L);
        double d13 = viagem8.getTempo();
        viagem8.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem16 = new Viagem(viagem8);
        Viagem viagem17 = viagem16.clone();
        Coordenada coordenada18 = viagem17.getcfinal();
        Viagem viagem19 = new Viagem();
        viagem19.setTempo(10.0d);
        boolean b23 = viagem19.equals((java.lang.Object) 100L);
        double d24 = viagem19.getTempo();
        viagem19.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str27 = viagem19.toString();
        viagem19.setMail("");
        Viagem viagem30 = new Viagem(viagem19);
        int i31 = viagem17.compareTo(viagem30);
        boolean b32 = viagem0.equals((java.lang.Object) i31);
        Viagem viagem33 = new Viagem(viagem0);
        viagem33.setMail("");
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(viagem5);
        org.junit.Assert.assertNotNull(viagem7);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertTrue(d13 == 10.0d);
        org.junit.Assert.assertNotNull(viagem17);
        org.junit.Assert.assertNotNull(coordenada18);
        org.junit.Assert.assertTrue(b23 == false);
        org.junit.Assert.assertTrue(d24 == 10.0d);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str27.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(i31 == 263);
        org.junit.Assert.assertTrue(b32 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Coordenada coordenada5 = viagem0.getcfinal();
        double d6 = viagem0.getTempo();
        Viagem viagem7 = new Viagem(viagem0);
        viagem0.setTempo((double) (byte) 10);
        Viagem viagem10 = new Viagem(viagem0);
        Viagem viagem11 = new Viagem();
        viagem11.setTempo(10.0d);
        boolean b15 = viagem11.equals((java.lang.Object) 100L);
        double d16 = viagem11.getTempo();
        viagem11.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem19 = new Viagem();
        viagem19.setTempo(10.0d);
        boolean b23 = viagem19.equals((java.lang.Object) 100L);
        double d24 = viagem19.getTempo();
        viagem19.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str27 = viagem19.toString();
        viagem19.setMail("");
        double d30 = viagem19.getDesvio();
        int i31 = viagem11.compareTo(viagem19);
        double d32 = viagem11.getPreco();
        Viagem viagem33 = new Viagem();
        viagem33.setTempo(10.0d);
        boolean b37 = viagem33.equals((java.lang.Object) 100L);
        double d38 = viagem33.getTempo();
        viagem33.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str41 = viagem33.toString();
        viagem33.setMail("");
        Coordenada coordenada44 = viagem33.getcinicial();
        viagem11.setcinicial(coordenada44);
        viagem10.setcfinal(coordenada44);
        Coordenada coordenada47 = viagem10.getcfinal();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(d6 == 10.0d);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertTrue(d16 == 10.0d);
        org.junit.Assert.assertTrue(b23 == false);
        org.junit.Assert.assertTrue(d24 == 10.0d);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str27.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d30 == 0.0d);
        org.junit.Assert.assertTrue(i31 == 263);
        org.junit.Assert.assertTrue(d32 == 0.0d);
        org.junit.Assert.assertTrue(b37 == false);
        org.junit.Assert.assertTrue(d38 == 10.0d);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str41.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(coordenada44);
        org.junit.Assert.assertNotNull(coordenada47);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        viagem0.setMail("hi!");
        Coordenada coordenada4 = viagem0.getcfinal();
        viagem0.setTempo(0.0d);
        java.lang.String str7 = viagem0.toString();
        java.util.GregorianCalendar gregorianCalendar8 = viagem0.getData();
        Coordenada coordenada9 = viagem0.getcinicial();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(coordenada4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str7.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(gregorianCalendar8);
        org.junit.Assert.assertNotNull(coordenada9);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        double d2 = viagem0.getPreco();
        Coordenada coordenada3 = viagem0.getcfinal();
        viagem0.setMail("hi!");
        Viagem viagem6 = new Viagem();
        java.lang.String str7 = viagem6.toString();
        Viagem viagem8 = viagem6.clone();
        java.lang.String str9 = viagem8.getMail();
        Viagem viagem10 = new Viagem();
        java.lang.String str11 = viagem10.toString();
        Viagem viagem12 = viagem10.clone();
        Coordenada coordenada13 = viagem10.getcinicial();
        viagem8.setcfinal(coordenada13);
        viagem0.setcinicial(coordenada13);
        double d16 = viagem0.getPreco();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d2 == 0.0d);
        org.junit.Assert.assertNotNull(coordenada3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str7.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str11.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem12);
        org.junit.Assert.assertNotNull(coordenada13);
        org.junit.Assert.assertTrue(d16 == 0.0d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        java.lang.String str3 = viagem2.getMail();
        Viagem viagem4 = new Viagem();
        java.lang.String str5 = viagem4.toString();
        Viagem viagem6 = viagem4.clone();
        Coordenada coordenada7 = viagem4.getcinicial();
        viagem2.setcfinal(coordenada7);
        double d9 = viagem2.getDesvio();
        Viagem viagem10 = new Viagem();
        java.lang.String str11 = viagem10.toString();
        Viagem viagem12 = viagem10.clone();
        Coordenada coordenada13 = viagem10.getcinicial();
        java.lang.Object obj14 = null;
        boolean b15 = viagem10.equals(obj14);
        int i16 = viagem2.compareTo(viagem10);
        Viagem viagem17 = viagem10.clone();
        double d18 = viagem10.getDesvio();
        double d19 = viagem10.getPreco();
        double d20 = viagem10.getTempo();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str5.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem6);
        org.junit.Assert.assertNotNull(coordenada7);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str11.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem12);
        org.junit.Assert.assertNotNull(coordenada13);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertTrue(i16 == (-1));
        org.junit.Assert.assertNotNull(viagem17);
        org.junit.Assert.assertTrue(d18 == 0.0d);
        org.junit.Assert.assertTrue(d19 == 0.0d);
        org.junit.Assert.assertTrue(d20 == 0.0d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        Coordenada coordenada3 = viagem0.getcinicial();
        Viagem viagem4 = new Viagem(viagem0);
        viagem4.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str7 = viagem4.getMail();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertNotNull(coordenada3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str7.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Coordenada coordenada9 = viagem0.getcfinal();
        Viagem viagem10 = new Viagem();
        viagem10.setTempo(10.0d);
        boolean b14 = viagem10.equals((java.lang.Object) 100L);
        Coordenada coordenada15 = viagem10.getcfinal();
        double d16 = viagem10.getTempo();
        Viagem viagem17 = new Viagem(viagem10);
        int i18 = viagem0.compareTo(viagem10);
        double d19 = viagem0.getPreco();
        Viagem viagem20 = new Viagem();
        viagem20.setTempo(10.0d);
        boolean b24 = viagem20.equals((java.lang.Object) 100L);
        double d25 = viagem20.getTempo();
        viagem20.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem28 = new Viagem(viagem20);
        Coordenada coordenada29 = viagem20.getcfinal();
        viagem0.setcfinal(coordenada29);
        Viagem viagem31 = viagem0.clone();
        java.lang.String str32 = viagem0.toString();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada9);
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertNotNull(coordenada15);
        org.junit.Assert.assertTrue(d16 == 10.0d);
        org.junit.Assert.assertTrue(i18 == 263);
        org.junit.Assert.assertTrue(d19 == 0.0d);
        org.junit.Assert.assertTrue(b24 == false);
        org.junit.Assert.assertTrue(d25 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada29);
        org.junit.Assert.assertNotNull(viagem31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str32.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        java.lang.String str9 = viagem0.toString();
        java.lang.String str10 = viagem0.toString();
        java.lang.String str11 = viagem0.toString();
        java.lang.String str12 = viagem0.toString();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str9.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str10.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str11.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str12.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        java.util.GregorianCalendar gregorianCalendar5 = viagem0.getData();
        java.lang.String str6 = viagem0.getMail();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(gregorianCalendar5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str8 = viagem0.toString();
        Viagem viagem9 = new Viagem();
        viagem9.setTempo(10.0d);
        boolean b13 = viagem9.equals((java.lang.Object) 100L);
        Viagem viagem14 = new Viagem(viagem9);
        java.util.GregorianCalendar gregorianCalendar15 = viagem9.getData();
        java.lang.String str16 = viagem9.toString();
        double d17 = viagem9.getPreco();
        Coordenada coordenada18 = viagem9.getcinicial();
        viagem0.setcfinal(coordenada18);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str8.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(b13 == false);
        org.junit.Assert.assertNotNull(gregorianCalendar15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str16.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d17 == 0.0d);
        org.junit.Assert.assertNotNull(coordenada18);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        Coordenada coordenada3 = viagem0.getcinicial();
        Viagem viagem4 = new Viagem(viagem0);
        double d5 = viagem4.getPreco();
        Coordenada coordenada6 = viagem4.getcfinal();
        Viagem viagem7 = viagem4.clone();
        java.lang.String str8 = viagem4.getMail();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertNotNull(coordenada3);
        org.junit.Assert.assertTrue(d5 == 0.0d);
        org.junit.Assert.assertNotNull(coordenada6);
        org.junit.Assert.assertNotNull(viagem7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        Coordenada coordenada3 = viagem0.getcinicial();
        java.lang.Object obj4 = null;
        boolean b5 = viagem0.equals(obj4);
        Viagem viagem6 = new Viagem();
        java.lang.String str7 = viagem6.toString();
        Viagem viagem8 = viagem6.clone();
        java.lang.String str9 = viagem8.getMail();
        boolean b10 = viagem0.equals((java.lang.Object) str9);
        java.lang.String str11 = viagem0.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertNotNull(coordenada3);
        org.junit.Assert.assertTrue(b5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str7.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str11.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Viagem viagem6 = new Viagem(viagem0);
        Viagem viagem7 = new Viagem();
        viagem7.setTempo(10.0d);
        boolean b11 = viagem7.equals((java.lang.Object) 100L);
        Viagem viagem12 = viagem7.clone();
        Viagem viagem13 = new Viagem(viagem7);
        int i14 = viagem0.compareTo(viagem7);
        viagem7.setMail("");
        java.util.GregorianCalendar gregorianCalendar17 = viagem7.getData();
        java.lang.String str18 = viagem7.toString();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(viagem5);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertNotNull(viagem12);
        org.junit.Assert.assertTrue(i14 == (-1));
        org.junit.Assert.assertNotNull(gregorianCalendar17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str18.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = new Viagem(viagem0);
        Coordenada coordenada6 = viagem0.getcfinal();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada6);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = new Viagem(viagem0);
        double d6 = viagem0.getTempo();
        double d7 = viagem0.getPreco();
        double d8 = viagem0.getPreco();
        Viagem viagem9 = new Viagem();
        viagem9.setTempo(10.0d);
        boolean b13 = viagem9.equals((java.lang.Object) 100L);
        Viagem viagem14 = new Viagem(viagem9);
        double d15 = viagem9.getTempo();
        double d16 = viagem9.getPreco();
        double d17 = viagem9.getPreco();
        double d18 = viagem9.getDesvio();
        Coordenada coordenada19 = viagem9.getcinicial();
        viagem0.setcfinal(coordenada19);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d6 == 10.0d);
        org.junit.Assert.assertTrue(d7 == 0.0d);
        org.junit.Assert.assertTrue(d8 == 0.0d);
        org.junit.Assert.assertTrue(b13 == false);
        org.junit.Assert.assertTrue(d15 == 10.0d);
        org.junit.Assert.assertTrue(d16 == 0.0d);
        org.junit.Assert.assertTrue(d17 == 0.0d);
        org.junit.Assert.assertTrue(d18 == 0.0d);
        org.junit.Assert.assertNotNull(coordenada19);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Viagem viagem9 = viagem0.clone();
        Viagem viagem10 = new Viagem();
        viagem10.setTempo(10.0d);
        boolean b14 = viagem10.equals((java.lang.Object) 100L);
        Viagem viagem15 = viagem10.clone();
        Viagem viagem16 = new Viagem(viagem10);
        Viagem viagem17 = viagem10.clone();
        int i18 = viagem0.compareTo(viagem17);
        double d19 = viagem0.getTempo();
        viagem0.setTempo(10.0d);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertNotNull(viagem9);
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertNotNull(viagem15);
        org.junit.Assert.assertNotNull(viagem17);
        org.junit.Assert.assertTrue(i18 == 263);
        org.junit.Assert.assertTrue(d19 == 10.0d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str8 = viagem0.toString();
        viagem0.setMail("");
        Viagem viagem11 = new Viagem(viagem0);
        Coordenada coordenada12 = viagem0.getcfinal();
        Viagem viagem13 = new Viagem();
        viagem13.setTempo(10.0d);
        boolean b17 = viagem13.equals((java.lang.Object) 100L);
        Viagem viagem18 = new Viagem(viagem13);
        int i19 = viagem0.compareTo(viagem13);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str8.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(coordenada12);
        org.junit.Assert.assertTrue(b17 == false);
        org.junit.Assert.assertTrue(i19 == (-1));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        Viagem viagem0 = new Viagem();
        java.util.GregorianCalendar gregorianCalendar1 = viagem0.getData();
        double d2 = viagem0.getDesvio();
        viagem0.setTempo((double) 0L);
        org.junit.Assert.assertNotNull(gregorianCalendar1);
        org.junit.Assert.assertTrue(d2 == 0.0d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        java.util.GregorianCalendar gregorianCalendar5 = viagem0.getData();
        double d6 = viagem0.getTempo();
        viagem0.setTempo(0.0d);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(gregorianCalendar5);
        org.junit.Assert.assertTrue(d6 == 10.0d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        java.lang.String str3 = viagem2.getMail();
        Viagem viagem4 = new Viagem();
        java.lang.String str5 = viagem4.toString();
        Viagem viagem6 = viagem4.clone();
        Coordenada coordenada7 = viagem4.getcinicial();
        viagem2.setcfinal(coordenada7);
        double d9 = viagem2.getDesvio();
        viagem2.setTempo((double) (short) 0);
        double d12 = viagem2.getDesvio();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str5.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem6);
        org.junit.Assert.assertNotNull(coordenada7);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue(d12 == 0.0d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        Coordenada coordenada6 = viagem0.getcfinal();
        java.lang.String str7 = viagem0.getMail();
        boolean b9 = viagem0.equals((java.lang.Object) (short) -1);
        viagem0.setMail("hi!");
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(b9 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Viagem viagem6 = new Viagem(viagem0);
        Viagem viagem7 = new Viagem();
        viagem7.setTempo(10.0d);
        boolean b11 = viagem7.equals((java.lang.Object) 100L);
        double d12 = viagem7.getTempo();
        viagem7.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem15 = new Viagem();
        viagem15.setTempo(10.0d);
        boolean b19 = viagem15.equals((java.lang.Object) 100L);
        double d20 = viagem15.getTempo();
        viagem15.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str23 = viagem15.toString();
        viagem15.setMail("");
        double d26 = viagem15.getDesvio();
        int i27 = viagem7.compareTo(viagem15);
        Coordenada coordenada28 = viagem15.getcfinal();
        viagem6.setcfinal(coordenada28);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(viagem5);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertTrue(d12 == 10.0d);
        org.junit.Assert.assertTrue(b19 == false);
        org.junit.Assert.assertTrue(d20 == 10.0d);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str23.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d26 == 0.0d);
        org.junit.Assert.assertTrue(i27 == 263);
        org.junit.Assert.assertNotNull(coordenada28);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Viagem viagem9 = viagem0.clone();
        Viagem viagem10 = new Viagem();
        viagem10.setTempo(10.0d);
        boolean b14 = viagem10.equals((java.lang.Object) 100L);
        Viagem viagem15 = viagem10.clone();
        Viagem viagem16 = new Viagem(viagem10);
        Viagem viagem17 = viagem10.clone();
        int i18 = viagem0.compareTo(viagem17);
        viagem17.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertNotNull(viagem9);
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertNotNull(viagem15);
        org.junit.Assert.assertNotNull(viagem17);
        org.junit.Assert.assertTrue(i18 == 263);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = new Viagem(viagem0);
        double d3 = viagem0.getPreco();
        double d4 = viagem0.getPreco();
        Coordenada coordenada5 = viagem0.getcinicial();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d3 == 0.0d);
        org.junit.Assert.assertTrue(d4 == 0.0d);
        org.junit.Assert.assertNotNull(coordenada5);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        java.lang.String str3 = viagem2.getMail();
        Viagem viagem4 = new Viagem();
        java.lang.String str5 = viagem4.toString();
        Viagem viagem6 = viagem4.clone();
        Coordenada coordenada7 = viagem4.getcinicial();
        viagem2.setcfinal(coordenada7);
        double d9 = viagem2.getDesvio();
        Viagem viagem10 = new Viagem();
        java.lang.String str11 = viagem10.toString();
        Viagem viagem12 = viagem10.clone();
        Coordenada coordenada13 = viagem10.getcinicial();
        java.lang.Object obj14 = null;
        boolean b15 = viagem10.equals(obj14);
        int i16 = viagem2.compareTo(viagem10);
        Viagem viagem17 = viagem10.clone();
        viagem10.setTempo((double) (short) 0);
        viagem10.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        double d22 = viagem10.getDesvio();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str5.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem6);
        org.junit.Assert.assertNotNull(coordenada7);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str11.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem12);
        org.junit.Assert.assertNotNull(coordenada13);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertTrue(i16 == (-1));
        org.junit.Assert.assertNotNull(viagem17);
        org.junit.Assert.assertTrue(d22 == 0.0d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        double d6 = viagem0.getPreco();
        Viagem viagem7 = new Viagem();
        viagem7.setTempo(10.0d);
        boolean b11 = viagem7.equals((java.lang.Object) 100L);
        Viagem viagem12 = viagem7.clone();
        boolean b13 = viagem0.equals((java.lang.Object) viagem12);
        java.lang.String str14 = viagem12.getMail();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertNotNull(viagem12);
        org.junit.Assert.assertTrue(b13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        viagem0.setMail("hi!");
        Coordenada coordenada4 = viagem0.getcfinal();
        double d5 = viagem0.getPreco();
        viagem0.setTempo(100.0d);
        Viagem viagem8 = viagem0.clone();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(coordenada4);
        org.junit.Assert.assertTrue(d5 == 0.0d);
        org.junit.Assert.assertNotNull(viagem8);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        double d6 = viagem0.getPreco();
        Viagem viagem7 = new Viagem();
        viagem7.setTempo(10.0d);
        boolean b11 = viagem7.equals((java.lang.Object) 100L);
        Viagem viagem12 = viagem7.clone();
        boolean b13 = viagem0.equals((java.lang.Object) viagem12);
        Viagem viagem14 = new Viagem();
        viagem14.setTempo(10.0d);
        boolean b18 = viagem14.equals((java.lang.Object) 100L);
        double d19 = viagem14.getTempo();
        viagem14.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem22 = new Viagem();
        viagem22.setTempo(10.0d);
        boolean b26 = viagem22.equals((java.lang.Object) 100L);
        double d27 = viagem22.getTempo();
        viagem22.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str30 = viagem22.toString();
        viagem22.setMail("");
        double d33 = viagem22.getDesvio();
        int i34 = viagem14.compareTo(viagem22);
        Viagem viagem35 = viagem14.clone();
        boolean b36 = viagem12.equals((java.lang.Object) viagem35);
        Viagem viagem37 = new Viagem();
        viagem37.setTempo(10.0d);
        boolean b41 = viagem37.equals((java.lang.Object) 100L);
        Viagem viagem42 = viagem37.clone();
        Viagem viagem43 = new Viagem(viagem37);
        Viagem viagem44 = new Viagem();
        viagem44.setTempo(10.0d);
        boolean b48 = viagem44.equals((java.lang.Object) 100L);
        Viagem viagem49 = viagem44.clone();
        Viagem viagem50 = new Viagem(viagem44);
        int i51 = viagem37.compareTo(viagem44);
        boolean b52 = viagem35.equals((java.lang.Object) viagem37);
        Viagem viagem53 = new Viagem();
        viagem53.setTempo(10.0d);
        boolean b57 = viagem53.equals((java.lang.Object) 100L);
        Viagem viagem58 = new Viagem(viagem53);
        double d59 = viagem53.getTempo();
        double d60 = viagem53.getPreco();
        double d61 = viagem53.getPreco();
        double d62 = viagem53.getDesvio();
        Viagem viagem63 = new Viagem();
        viagem63.setTempo(10.0d);
        boolean b67 = viagem63.equals((java.lang.Object) 100L);
        Viagem viagem68 = viagem63.clone();
        Viagem viagem69 = new Viagem();
        viagem69.setTempo(10.0d);
        boolean b73 = viagem69.equals((java.lang.Object) 100L);
        double d74 = viagem69.getTempo();
        viagem69.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str77 = viagem69.toString();
        viagem69.setMail("");
        double d80 = viagem69.getDesvio();
        java.util.GregorianCalendar gregorianCalendar81 = viagem69.getData();
        int i82 = viagem68.compareTo(viagem69);
        Viagem viagem83 = viagem68.clone();
        Coordenada coordenada84 = viagem68.getcinicial();
        viagem53.setcinicial(coordenada84);
        viagem37.setcinicial(coordenada84);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertNotNull(viagem12);
        org.junit.Assert.assertTrue(b13 == true);
        org.junit.Assert.assertTrue(b18 == false);
        org.junit.Assert.assertTrue(d19 == 10.0d);
        org.junit.Assert.assertTrue(b26 == false);
        org.junit.Assert.assertTrue(d27 == 10.0d);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str30.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d33 == 0.0d);
        org.junit.Assert.assertTrue(i34 == 263);
        org.junit.Assert.assertNotNull(viagem35);
        org.junit.Assert.assertTrue(b36 == false);
        org.junit.Assert.assertTrue(b41 == false);
        org.junit.Assert.assertNotNull(viagem42);
        org.junit.Assert.assertTrue(b48 == false);
        org.junit.Assert.assertNotNull(viagem49);
        org.junit.Assert.assertTrue(i51 == 0);
        org.junit.Assert.assertTrue(b52 == false);
        org.junit.Assert.assertTrue(b57 == false);
        org.junit.Assert.assertTrue(d59 == 10.0d);
        org.junit.Assert.assertTrue(d60 == 0.0d);
        org.junit.Assert.assertTrue(d61 == 0.0d);
        org.junit.Assert.assertTrue(d62 == 0.0d);
        org.junit.Assert.assertTrue(b67 == false);
        org.junit.Assert.assertNotNull(viagem68);
        org.junit.Assert.assertTrue(b73 == false);
        org.junit.Assert.assertTrue(d74 == 10.0d);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str77.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d80 == 0.0d);
        org.junit.Assert.assertNotNull(gregorianCalendar81);
        org.junit.Assert.assertTrue(i82 == (-1));
        org.junit.Assert.assertNotNull(viagem83);
        org.junit.Assert.assertNotNull(coordenada84);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        Coordenada coordenada3 = viagem0.getcinicial();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        double d6 = viagem0.getTempo();
        Coordenada coordenada7 = viagem0.getcinicial();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertNotNull(coordenada3);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertNotNull(coordenada7);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem();
        viagem8.setTempo(10.0d);
        boolean b12 = viagem8.equals((java.lang.Object) 100L);
        double d13 = viagem8.getTempo();
        viagem8.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str16 = viagem8.toString();
        viagem8.setMail("");
        double d19 = viagem8.getDesvio();
        int i20 = viagem0.compareTo(viagem8);
        double d21 = viagem0.getPreco();
        Viagem viagem22 = new Viagem();
        viagem22.setTempo(10.0d);
        boolean b26 = viagem22.equals((java.lang.Object) 100L);
        double d27 = viagem22.getTempo();
        viagem22.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str30 = viagem22.toString();
        viagem22.setMail("");
        Coordenada coordenada33 = viagem22.getcinicial();
        viagem0.setcinicial(coordenada33);
        java.lang.String str35 = viagem0.getMail();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertTrue(d13 == 10.0d);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str16.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d19 == 0.0d);
        org.junit.Assert.assertTrue(i20 == 263);
        org.junit.Assert.assertTrue(d21 == 0.0d);
        org.junit.Assert.assertTrue(b26 == false);
        org.junit.Assert.assertTrue(d27 == 10.0d);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str30.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(coordenada33);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str35.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = new Viagem(viagem0);
        java.lang.String str6 = viagem0.getMail();
        Viagem viagem7 = new Viagem();
        viagem7.setTempo(10.0d);
        boolean b11 = viagem7.equals((java.lang.Object) 100L);
        Viagem viagem12 = new Viagem(viagem7);
        java.lang.String str13 = viagem7.getMail();
        boolean b14 = viagem0.equals((java.lang.Object) viagem7);
        Viagem viagem15 = new Viagem();
        viagem15.setTempo(10.0d);
        boolean b19 = viagem15.equals((java.lang.Object) 100L);
        Viagem viagem20 = new Viagem(viagem15);
        java.util.GregorianCalendar gregorianCalendar21 = viagem15.getData();
        java.lang.String str22 = viagem15.toString();
        double d23 = viagem15.getPreco();
        Coordenada coordenada24 = viagem15.getcinicial();
        viagem7.setcfinal(coordenada24);
        java.lang.String str26 = viagem7.toString();
        java.lang.String str27 = viagem7.getMail();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertTrue(b19 == false);
        org.junit.Assert.assertNotNull(gregorianCalendar21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str22.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d23 == 0.0d);
        org.junit.Assert.assertNotNull(coordenada24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str26.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Viagem viagem6 = new Viagem(viagem0);
        Viagem viagem7 = new Viagem();
        viagem7.setTempo(10.0d);
        boolean b11 = viagem7.equals((java.lang.Object) 100L);
        Viagem viagem12 = viagem7.clone();
        Viagem viagem13 = new Viagem(viagem7);
        int i14 = viagem0.compareTo(viagem7);
        double d15 = viagem7.getTempo();
        Viagem viagem16 = viagem7.clone();
        Viagem viagem17 = viagem7.clone();
        Viagem viagem18 = new Viagem(viagem17);
        double d19 = viagem17.getDesvio();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(viagem5);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertNotNull(viagem12);
        org.junit.Assert.assertTrue(i14 == (-1));
        org.junit.Assert.assertTrue(d15 == 10.0d);
        org.junit.Assert.assertNotNull(viagem16);
        org.junit.Assert.assertNotNull(viagem17);
        org.junit.Assert.assertTrue(d19 == 0.0d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        double d2 = viagem0.getPreco();
        Coordenada coordenada3 = viagem0.getcfinal();
        viagem0.setMail("hi!");
        Viagem viagem6 = new Viagem();
        java.lang.String str7 = viagem6.toString();
        Viagem viagem8 = viagem6.clone();
        java.lang.String str9 = viagem8.getMail();
        Viagem viagem10 = new Viagem();
        java.lang.String str11 = viagem10.toString();
        Viagem viagem12 = viagem10.clone();
        Coordenada coordenada13 = viagem10.getcinicial();
        viagem8.setcfinal(coordenada13);
        viagem0.setcinicial(coordenada13);
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str18 = viagem0.toString();
        java.lang.String str19 = viagem0.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d2 == 0.0d);
        org.junit.Assert.assertNotNull(coordenada3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str7.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str11.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem12);
        org.junit.Assert.assertNotNull(coordenada13);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str18.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str19.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        java.lang.String str3 = viagem0.getMail();
        double d4 = viagem0.getDesvio();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue(d4 == 0.0d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Viagem viagem6 = new Viagem(viagem0);
        Viagem viagem7 = viagem0.clone();
        Viagem viagem8 = new Viagem();
        viagem8.setTempo(10.0d);
        boolean b12 = viagem8.equals((java.lang.Object) 100L);
        double d13 = viagem8.getTempo();
        viagem8.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem16 = new Viagem(viagem8);
        Viagem viagem17 = viagem16.clone();
        Coordenada coordenada18 = viagem17.getcfinal();
        Viagem viagem19 = new Viagem();
        viagem19.setTempo(10.0d);
        boolean b23 = viagem19.equals((java.lang.Object) 100L);
        double d24 = viagem19.getTempo();
        viagem19.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str27 = viagem19.toString();
        viagem19.setMail("");
        Viagem viagem30 = new Viagem(viagem19);
        int i31 = viagem17.compareTo(viagem30);
        boolean b32 = viagem0.equals((java.lang.Object) i31);
        Viagem viagem33 = new Viagem(viagem0);
        java.lang.String str34 = viagem33.toString();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(viagem5);
        org.junit.Assert.assertNotNull(viagem7);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertTrue(d13 == 10.0d);
        org.junit.Assert.assertNotNull(viagem17);
        org.junit.Assert.assertNotNull(coordenada18);
        org.junit.Assert.assertTrue(b23 == false);
        org.junit.Assert.assertTrue(d24 == 10.0d);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str27.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(i31 == 263);
        org.junit.Assert.assertTrue(b32 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str34.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str8 = viagem0.toString();
        viagem0.setMail("");
        Viagem viagem11 = new Viagem(viagem0);
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str8.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        viagem0.setMail("hi!");
        Coordenada coordenada4 = viagem0.getcfinal();
        viagem0.setTempo(0.0d);
        viagem0.setMail("hi!");
        java.util.GregorianCalendar gregorianCalendar9 = viagem0.getData();
        Viagem viagem10 = new Viagem();
        java.lang.String str11 = viagem10.toString();
        Viagem viagem12 = viagem10.clone();
        Coordenada coordenada13 = viagem10.getcinicial();
        Viagem viagem14 = new Viagem(viagem10);
        Coordenada coordenada15 = viagem14.getcinicial();
        viagem0.setcfinal(coordenada15);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(coordenada4);
        org.junit.Assert.assertNotNull(gregorianCalendar9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str11.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem12);
        org.junit.Assert.assertNotNull(coordenada13);
        org.junit.Assert.assertNotNull(coordenada15);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = new Viagem(viagem0);
        java.util.GregorianCalendar gregorianCalendar6 = viagem0.getData();
        java.lang.String str7 = viagem0.toString();
        double d8 = viagem0.getDesvio();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(gregorianCalendar6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str7.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d8 == 0.0d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        Coordenada coordenada3 = viagem2.getcfinal();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertNotNull(coordenada3);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Viagem viagem6 = new Viagem(viagem0);
        double d7 = viagem0.getDesvio();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(viagem5);
        org.junit.Assert.assertTrue(d7 == 0.0d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        double d6 = viagem0.getPreco();
        Viagem viagem7 = new Viagem(viagem0);
        Viagem viagem8 = viagem7.clone();
        Viagem viagem9 = new Viagem();
        viagem9.setTempo(10.0d);
        boolean b13 = viagem9.equals((java.lang.Object) 100L);
        Coordenada coordenada14 = viagem9.getcfinal();
        double d15 = viagem9.getTempo();
        Viagem viagem16 = new Viagem(viagem9);
        boolean b17 = viagem8.equals((java.lang.Object) viagem16);
        Viagem viagem18 = new Viagem();
        viagem18.setTempo(10.0d);
        boolean b22 = viagem18.equals((java.lang.Object) 100L);
        Viagem viagem23 = viagem18.clone();
        Viagem viagem24 = new Viagem(viagem18);
        Viagem viagem25 = viagem18.clone();
        double d26 = viagem25.getPreco();
        Coordenada coordenada27 = viagem25.getcinicial();
        viagem16.setcinicial(coordenada27);
        Viagem viagem29 = new Viagem(viagem16);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertNotNull(viagem8);
        org.junit.Assert.assertTrue(b13 == false);
        org.junit.Assert.assertNotNull(coordenada14);
        org.junit.Assert.assertTrue(d15 == 10.0d);
        org.junit.Assert.assertTrue(b17 == true);
        org.junit.Assert.assertTrue(b22 == false);
        org.junit.Assert.assertNotNull(viagem23);
        org.junit.Assert.assertNotNull(viagem25);
        org.junit.Assert.assertTrue(d26 == 0.0d);
        org.junit.Assert.assertNotNull(coordenada27);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        double d6 = viagem0.getPreco();
        Viagem viagem7 = new Viagem();
        viagem7.setTempo(10.0d);
        boolean b11 = viagem7.equals((java.lang.Object) 100L);
        Viagem viagem12 = viagem7.clone();
        boolean b13 = viagem0.equals((java.lang.Object) viagem12);
        Viagem viagem14 = new Viagem();
        viagem14.setTempo(10.0d);
        boolean b18 = viagem14.equals((java.lang.Object) 100L);
        double d19 = viagem14.getTempo();
        viagem14.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem22 = new Viagem();
        viagem22.setTempo(10.0d);
        boolean b26 = viagem22.equals((java.lang.Object) 100L);
        double d27 = viagem22.getTempo();
        viagem22.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str30 = viagem22.toString();
        viagem22.setMail("");
        double d33 = viagem22.getDesvio();
        int i34 = viagem14.compareTo(viagem22);
        Viagem viagem35 = viagem14.clone();
        boolean b36 = viagem12.equals((java.lang.Object) viagem35);
        Viagem viagem37 = new Viagem();
        viagem37.setTempo(10.0d);
        boolean b41 = viagem37.equals((java.lang.Object) 100L);
        Viagem viagem42 = viagem37.clone();
        Viagem viagem43 = new Viagem(viagem37);
        Viagem viagem44 = new Viagem();
        viagem44.setTempo(10.0d);
        boolean b48 = viagem44.equals((java.lang.Object) 100L);
        Viagem viagem49 = viagem44.clone();
        Viagem viagem50 = new Viagem(viagem44);
        int i51 = viagem37.compareTo(viagem44);
        boolean b52 = viagem35.equals((java.lang.Object) viagem37);
        java.util.GregorianCalendar gregorianCalendar53 = viagem37.getData();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertNotNull(viagem12);
        org.junit.Assert.assertTrue(b13 == true);
        org.junit.Assert.assertTrue(b18 == false);
        org.junit.Assert.assertTrue(d19 == 10.0d);
        org.junit.Assert.assertTrue(b26 == false);
        org.junit.Assert.assertTrue(d27 == 10.0d);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str30.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d33 == 0.0d);
        org.junit.Assert.assertTrue(i34 == 263);
        org.junit.Assert.assertNotNull(viagem35);
        org.junit.Assert.assertTrue(b36 == false);
        org.junit.Assert.assertTrue(b41 == false);
        org.junit.Assert.assertNotNull(viagem42);
        org.junit.Assert.assertTrue(b48 == false);
        org.junit.Assert.assertNotNull(viagem49);
        org.junit.Assert.assertTrue(i51 == 0);
        org.junit.Assert.assertTrue(b52 == false);
        org.junit.Assert.assertNotNull(gregorianCalendar53);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Viagem viagem6 = new Viagem();
        viagem6.setTempo(10.0d);
        boolean b10 = viagem6.equals((java.lang.Object) 100L);
        double d11 = viagem6.getTempo();
        viagem6.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str14 = viagem6.toString();
        viagem6.setMail("");
        double d17 = viagem6.getDesvio();
        java.util.GregorianCalendar gregorianCalendar18 = viagem6.getData();
        int i19 = viagem5.compareTo(viagem6);
        Viagem viagem20 = new Viagem(viagem6);
        Coordenada coordenada21 = viagem6.getcinicial();
        Viagem viagem22 = new Viagem();
        viagem22.setTempo(10.0d);
        boolean b26 = viagem22.equals((java.lang.Object) 100L);
        double d27 = viagem22.getTempo();
        viagem22.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem30 = new Viagem(viagem22);
        Coordenada coordenada31 = viagem22.getcfinal();
        Viagem viagem32 = new Viagem(viagem22);
        Coordenada coordenada33 = viagem32.getcinicial();
        viagem6.setcinicial(coordenada33);
        java.lang.String str35 = viagem6.toString();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(viagem5);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue(d11 == 10.0d);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str14.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d17 == 0.0d);
        org.junit.Assert.assertNotNull(gregorianCalendar18);
        org.junit.Assert.assertTrue(i19 == 0);
        org.junit.Assert.assertNotNull(coordenada21);
        org.junit.Assert.assertTrue(b26 == false);
        org.junit.Assert.assertTrue(d27 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada31);
        org.junit.Assert.assertNotNull(coordenada33);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str35.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Coordenada coordenada9 = viagem0.getcfinal();
        Viagem viagem10 = new Viagem();
        viagem10.setTempo(10.0d);
        boolean b14 = viagem10.equals((java.lang.Object) 100L);
        Coordenada coordenada15 = viagem10.getcfinal();
        double d16 = viagem10.getTempo();
        Viagem viagem17 = new Viagem(viagem10);
        int i18 = viagem0.compareTo(viagem10);
        double d19 = viagem0.getDesvio();
        double d20 = viagem0.getPreco();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada9);
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertNotNull(coordenada15);
        org.junit.Assert.assertTrue(d16 == 10.0d);
        org.junit.Assert.assertTrue(i18 == 263);
        org.junit.Assert.assertTrue(d19 == 0.0d);
        org.junit.Assert.assertTrue(d20 == 0.0d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        Coordenada coordenada3 = viagem0.getcfinal();
        Coordenada coordenada4 = viagem0.getcfinal();
        java.lang.String str5 = viagem0.getMail();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertNotNull(coordenada3);
        org.junit.Assert.assertNotNull(coordenada4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str8 = viagem0.toString();
        viagem0.setMail("");
        Coordenada coordenada11 = viagem0.getcinicial();
        Viagem viagem12 = new Viagem(viagem0);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str8.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(coordenada11);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Viagem viagem6 = new Viagem(viagem0);
        Viagem viagem7 = viagem6.clone();
        viagem7.setMail("");
        Viagem viagem10 = viagem7.clone();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(viagem5);
        org.junit.Assert.assertNotNull(viagem7);
        org.junit.Assert.assertNotNull(viagem10);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Viagem viagem6 = new Viagem(viagem0);
        Viagem viagem7 = viagem6.clone();
        double d8 = viagem7.getPreco();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(viagem5);
        org.junit.Assert.assertNotNull(viagem7);
        org.junit.Assert.assertTrue(d8 == 0.0d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Coordenada coordenada9 = viagem0.getcfinal();
        Viagem viagem10 = new Viagem();
        viagem10.setTempo(10.0d);
        boolean b14 = viagem10.equals((java.lang.Object) 100L);
        Coordenada coordenada15 = viagem10.getcfinal();
        double d16 = viagem10.getTempo();
        Viagem viagem17 = new Viagem(viagem10);
        int i18 = viagem0.compareTo(viagem10);
        double d19 = viagem0.getPreco();
        Viagem viagem20 = new Viagem();
        viagem20.setTempo(10.0d);
        boolean b24 = viagem20.equals((java.lang.Object) 100L);
        double d25 = viagem20.getTempo();
        viagem20.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem28 = new Viagem(viagem20);
        Coordenada coordenada29 = viagem20.getcfinal();
        viagem0.setcfinal(coordenada29);
        Viagem viagem31 = viagem0.clone();
        double d32 = viagem31.getTempo();
        double d33 = viagem31.getPreco();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada9);
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertNotNull(coordenada15);
        org.junit.Assert.assertTrue(d16 == 10.0d);
        org.junit.Assert.assertTrue(i18 == 263);
        org.junit.Assert.assertTrue(d19 == 0.0d);
        org.junit.Assert.assertTrue(b24 == false);
        org.junit.Assert.assertTrue(d25 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada29);
        org.junit.Assert.assertNotNull(viagem31);
        org.junit.Assert.assertTrue(d32 == 10.0d);
        org.junit.Assert.assertTrue(d33 == 0.0d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        double d6 = viagem0.getPreco();
        java.lang.String str7 = viagem0.getMail();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = new Viagem(viagem0);
        java.lang.String str6 = viagem0.getMail();
        Viagem viagem7 = new Viagem();
        viagem7.setTempo(10.0d);
        boolean b11 = viagem7.equals((java.lang.Object) 100L);
        Viagem viagem12 = new Viagem(viagem7);
        java.lang.String str13 = viagem7.getMail();
        boolean b14 = viagem0.equals((java.lang.Object) viagem7);
        double d15 = viagem0.getDesvio();
        viagem0.setMail("hi!");
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertTrue(d15 == 0.0d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Viagem viagem6 = new Viagem(viagem0);
        Viagem viagem7 = viagem0.clone();
        Viagem viagem8 = new Viagem();
        viagem8.setTempo(10.0d);
        boolean b12 = viagem8.equals((java.lang.Object) 100L);
        double d13 = viagem8.getTempo();
        viagem8.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem16 = new Viagem(viagem8);
        Viagem viagem17 = viagem16.clone();
        Coordenada coordenada18 = viagem17.getcfinal();
        Viagem viagem19 = new Viagem();
        viagem19.setTempo(10.0d);
        boolean b23 = viagem19.equals((java.lang.Object) 100L);
        double d24 = viagem19.getTempo();
        viagem19.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str27 = viagem19.toString();
        viagem19.setMail("");
        Viagem viagem30 = new Viagem(viagem19);
        int i31 = viagem17.compareTo(viagem30);
        boolean b32 = viagem0.equals((java.lang.Object) i31);
        Viagem viagem33 = viagem0.clone();
        double d34 = viagem0.getTempo();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(viagem5);
        org.junit.Assert.assertNotNull(viagem7);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertTrue(d13 == 10.0d);
        org.junit.Assert.assertNotNull(viagem17);
        org.junit.Assert.assertNotNull(coordenada18);
        org.junit.Assert.assertTrue(b23 == false);
        org.junit.Assert.assertTrue(d24 == 10.0d);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str27.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(i31 == 263);
        org.junit.Assert.assertTrue(b32 == false);
        org.junit.Assert.assertNotNull(viagem33);
        org.junit.Assert.assertTrue(d34 == 10.0d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Viagem viagem6 = new Viagem(viagem0);
        Viagem viagem7 = new Viagem();
        viagem7.setTempo(10.0d);
        boolean b11 = viagem7.equals((java.lang.Object) 100L);
        Viagem viagem12 = viagem7.clone();
        Viagem viagem13 = new Viagem(viagem7);
        int i14 = viagem0.compareTo(viagem7);
        double d15 = viagem7.getTempo();
        Viagem viagem16 = viagem7.clone();
        Coordenada coordenada17 = viagem7.getcinicial();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(viagem5);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertNotNull(viagem12);
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(d15 == 10.0d);
        org.junit.Assert.assertNotNull(viagem16);
        org.junit.Assert.assertNotNull(coordenada17);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Viagem viagem9 = viagem8.clone();
        Coordenada coordenada10 = viagem9.getcfinal();
        Viagem viagem11 = new Viagem();
        viagem11.setTempo(10.0d);
        boolean b15 = viagem11.equals((java.lang.Object) 100L);
        double d16 = viagem11.getTempo();
        viagem11.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str19 = viagem11.toString();
        viagem11.setMail("");
        Viagem viagem22 = new Viagem(viagem11);
        int i23 = viagem9.compareTo(viagem22);
        Viagem viagem24 = new Viagem();
        viagem24.setTempo(10.0d);
        boolean b28 = viagem24.equals((java.lang.Object) 100L);
        Viagem viagem29 = viagem24.clone();
        Viagem viagem30 = new Viagem(viagem24);
        Viagem viagem31 = viagem24.clone();
        Viagem viagem32 = new Viagem();
        viagem32.setTempo(10.0d);
        boolean b36 = viagem32.equals((java.lang.Object) 100L);
        double d37 = viagem32.getTempo();
        viagem32.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem40 = new Viagem(viagem32);
        Viagem viagem41 = viagem40.clone();
        Coordenada coordenada42 = viagem41.getcfinal();
        Viagem viagem43 = new Viagem();
        viagem43.setTempo(10.0d);
        boolean b47 = viagem43.equals((java.lang.Object) 100L);
        double d48 = viagem43.getTempo();
        viagem43.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str51 = viagem43.toString();
        viagem43.setMail("");
        Viagem viagem54 = new Viagem(viagem43);
        int i55 = viagem41.compareTo(viagem54);
        boolean b56 = viagem24.equals((java.lang.Object) i55);
        Viagem viagem57 = new Viagem(viagem24);
        Viagem viagem58 = new Viagem();
        viagem58.setTempo(10.0d);
        boolean b62 = viagem58.equals((java.lang.Object) 100L);
        Viagem viagem63 = new Viagem(viagem58);
        java.lang.String str64 = viagem58.getMail();
        Viagem viagem65 = new Viagem();
        viagem65.setTempo(10.0d);
        boolean b69 = viagem65.equals((java.lang.Object) 100L);
        Viagem viagem70 = new Viagem(viagem65);
        java.lang.String str71 = viagem65.getMail();
        boolean b72 = viagem58.equals((java.lang.Object) viagem65);
        Viagem viagem73 = new Viagem();
        viagem73.setTempo(10.0d);
        boolean b77 = viagem73.equals((java.lang.Object) 100L);
        Viagem viagem78 = new Viagem(viagem73);
        java.util.GregorianCalendar gregorianCalendar79 = viagem73.getData();
        java.lang.String str80 = viagem73.toString();
        double d81 = viagem73.getPreco();
        Coordenada coordenada82 = viagem73.getcinicial();
        viagem65.setcfinal(coordenada82);
        viagem57.setcfinal(coordenada82);
        boolean b85 = viagem9.equals((java.lang.Object) coordenada82);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertNotNull(viagem9);
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertTrue(d16 == 10.0d);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str19.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(i23 == 263);
        org.junit.Assert.assertTrue(b28 == false);
        org.junit.Assert.assertNotNull(viagem29);
        org.junit.Assert.assertNotNull(viagem31);
        org.junit.Assert.assertTrue(b36 == false);
        org.junit.Assert.assertTrue(d37 == 10.0d);
        org.junit.Assert.assertNotNull(viagem41);
        org.junit.Assert.assertNotNull(coordenada42);
        org.junit.Assert.assertTrue(b47 == false);
        org.junit.Assert.assertTrue(d48 == 10.0d);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str51.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(i55 == 263);
        org.junit.Assert.assertTrue(b56 == false);
        org.junit.Assert.assertTrue(b62 == false);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "" + "'", str64.equals(""));
        org.junit.Assert.assertTrue(b69 == false);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "" + "'", str71.equals(""));
        org.junit.Assert.assertTrue(b72 == true);
        org.junit.Assert.assertTrue(b77 == false);
        org.junit.Assert.assertNotNull(gregorianCalendar79);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str80.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d81 == 0.0d);
        org.junit.Assert.assertNotNull(coordenada82);
        org.junit.Assert.assertTrue(b85 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = new Viagem(viagem0);
        java.lang.String str3 = viagem2.toString();
        double d4 = viagem2.getTempo();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str3.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d4 == 0.0d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        java.lang.String str9 = viagem0.toString();
        java.lang.String str10 = viagem0.toString();
        java.lang.String str11 = viagem0.toString();
        java.lang.String str12 = viagem0.getMail();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str9.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str10.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str11.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str12.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Coordenada coordenada5 = viagem0.getcfinal();
        double d6 = viagem0.getTempo();
        Viagem viagem7 = new Viagem(viagem0);
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        double d10 = viagem0.getTempo();
        double d11 = viagem0.getTempo();
        double d12 = viagem0.getTempo();
        double d13 = viagem0.getPreco();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(d6 == 10.0d);
        org.junit.Assert.assertTrue(d10 == 10.0d);
        org.junit.Assert.assertTrue(d11 == 10.0d);
        org.junit.Assert.assertTrue(d12 == 10.0d);
        org.junit.Assert.assertTrue(d13 == 0.0d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem();
        viagem8.setTempo(10.0d);
        boolean b12 = viagem8.equals((java.lang.Object) 100L);
        double d13 = viagem8.getTempo();
        viagem8.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str16 = viagem8.toString();
        viagem8.setMail("");
        double d19 = viagem8.getDesvio();
        int i20 = viagem0.compareTo(viagem8);
        Viagem viagem21 = viagem0.clone();
        Viagem viagem22 = new Viagem();
        viagem22.setTempo(10.0d);
        boolean b26 = viagem22.equals((java.lang.Object) 100L);
        Viagem viagem27 = new Viagem(viagem22);
        java.lang.String str28 = viagem22.getMail();
        Viagem viagem29 = new Viagem();
        viagem29.setTempo(10.0d);
        boolean b33 = viagem29.equals((java.lang.Object) 100L);
        Viagem viagem34 = new Viagem(viagem29);
        java.lang.String str35 = viagem29.getMail();
        boolean b36 = viagem22.equals((java.lang.Object) viagem29);
        Viagem viagem37 = new Viagem();
        viagem37.setTempo(10.0d);
        boolean b41 = viagem37.equals((java.lang.Object) 100L);
        Viagem viagem42 = new Viagem(viagem37);
        java.util.GregorianCalendar gregorianCalendar43 = viagem37.getData();
        java.lang.String str44 = viagem37.toString();
        double d45 = viagem37.getPreco();
        Coordenada coordenada46 = viagem37.getcinicial();
        viagem29.setcfinal(coordenada46);
        java.lang.String str48 = viagem29.toString();
        Viagem viagem49 = viagem29.clone();
        java.lang.String str50 = viagem49.toString();
        Viagem viagem51 = new Viagem();
        viagem51.setTempo(10.0d);
        boolean b55 = viagem51.equals((java.lang.Object) 100L);
        Coordenada coordenada56 = viagem51.getcfinal();
        Viagem viagem57 = new Viagem();
        viagem57.setTempo(10.0d);
        boolean b61 = viagem57.equals((java.lang.Object) 100L);
        Viagem viagem62 = viagem57.clone();
        Coordenada coordenada63 = viagem62.getcfinal();
        viagem51.setcinicial(coordenada63);
        Coordenada coordenada65 = viagem51.getcfinal();
        viagem49.setcinicial(coordenada65);
        viagem21.setcfinal(coordenada65);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertTrue(d13 == 10.0d);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str16.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d19 == 0.0d);
        org.junit.Assert.assertTrue(i20 == 263);
        org.junit.Assert.assertNotNull(viagem21);
        org.junit.Assert.assertTrue(b26 == false);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "" + "'", str28.equals(""));
        org.junit.Assert.assertTrue(b33 == false);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "" + "'", str35.equals(""));
        org.junit.Assert.assertTrue(b36 == true);
        org.junit.Assert.assertTrue(b41 == false);
        org.junit.Assert.assertNotNull(gregorianCalendar43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str44.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d45 == 0.0d);
        org.junit.Assert.assertNotNull(coordenada46);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str48.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str50.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(b55 == false);
        org.junit.Assert.assertNotNull(coordenada56);
        org.junit.Assert.assertTrue(b61 == false);
        org.junit.Assert.assertNotNull(viagem62);
        org.junit.Assert.assertNotNull(coordenada63);
        org.junit.Assert.assertNotNull(coordenada65);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Coordenada coordenada5 = viagem0.getcfinal();
        double d6 = viagem0.getTempo();
        Viagem viagem7 = new Viagem(viagem0);
        viagem0.setTempo((double) (byte) 10);
        Viagem viagem10 = new Viagem(viagem0);
        Coordenada coordenada11 = viagem0.getcfinal();
        Viagem viagem12 = viagem0.clone();
        Viagem viagem13 = new Viagem();
        viagem13.setTempo(10.0d);
        boolean b17 = viagem13.equals((java.lang.Object) 100L);
        double d18 = viagem13.getTempo();
        viagem13.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem21 = new Viagem(viagem13);
        Viagem viagem22 = viagem21.clone();
        Coordenada coordenada23 = viagem22.getcfinal();
        boolean b24 = viagem0.equals((java.lang.Object) viagem22);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(d6 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada11);
        org.junit.Assert.assertNotNull(viagem12);
        org.junit.Assert.assertTrue(b17 == false);
        org.junit.Assert.assertTrue(d18 == 10.0d);
        org.junit.Assert.assertNotNull(viagem22);
        org.junit.Assert.assertNotNull(coordenada23);
        org.junit.Assert.assertTrue(b24 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        java.lang.String str3 = viagem2.getMail();
        Viagem viagem4 = new Viagem();
        java.lang.String str5 = viagem4.toString();
        Viagem viagem6 = viagem4.clone();
        Coordenada coordenada7 = viagem4.getcinicial();
        viagem2.setcfinal(coordenada7);
        double d9 = viagem2.getDesvio();
        Viagem viagem10 = new Viagem();
        java.lang.String str11 = viagem10.toString();
        Viagem viagem12 = viagem10.clone();
        Coordenada coordenada13 = viagem10.getcinicial();
        java.lang.Object obj14 = null;
        boolean b15 = viagem10.equals(obj14);
        int i16 = viagem2.compareTo(viagem10);
        Viagem viagem17 = viagem10.clone();
        Viagem viagem18 = viagem10.clone();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str5.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem6);
        org.junit.Assert.assertNotNull(coordenada7);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str11.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem12);
        org.junit.Assert.assertNotNull(coordenada13);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertTrue(i16 == (-1));
        org.junit.Assert.assertNotNull(viagem17);
        org.junit.Assert.assertNotNull(viagem18);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        Coordenada coordenada3 = viagem0.getcinicial();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem6 = viagem0.clone();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertNotNull(coordenada3);
        org.junit.Assert.assertNotNull(viagem6);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        Coordenada coordenada3 = viagem0.getcinicial();
        Viagem viagem4 = new Viagem(viagem0);
        double d5 = viagem4.getPreco();
        Coordenada coordenada6 = viagem4.getcfinal();
        double d7 = viagem4.getTempo();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertNotNull(coordenada3);
        org.junit.Assert.assertTrue(d5 == 0.0d);
        org.junit.Assert.assertNotNull(coordenada6);
        org.junit.Assert.assertTrue(d7 == 0.0d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str8 = viagem0.toString();
        viagem0.setMail("");
        Viagem viagem11 = new Viagem(viagem0);
        Coordenada coordenada12 = viagem0.getcfinal();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        double d15 = viagem0.getTempo();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str8.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(coordenada12);
        org.junit.Assert.assertTrue(d15 == 10.0d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str8 = viagem0.toString();
        viagem0.setMail("");
        double d11 = viagem0.getDesvio();
        java.lang.String str12 = viagem0.getMail();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem15 = new Viagem();
        viagem15.setTempo(10.0d);
        boolean b19 = viagem15.equals((java.lang.Object) 100L);
        Viagem viagem20 = viagem15.clone();
        Viagem viagem21 = new Viagem(viagem15);
        Viagem viagem22 = new Viagem(viagem15);
        boolean b23 = viagem0.equals((java.lang.Object) viagem22);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str8.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d11 == 0.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue(b19 == false);
        org.junit.Assert.assertNotNull(viagem20);
        org.junit.Assert.assertTrue(b23 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        double d6 = viagem0.getPreco();
        java.lang.String str7 = viagem0.getMail();
        Viagem viagem8 = viagem0.clone();
        Viagem viagem9 = viagem0.clone();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(viagem8);
        org.junit.Assert.assertNotNull(viagem9);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str8 = viagem0.toString();
        viagem0.setMail("");
        double d11 = viagem0.getDesvio();
        java.util.GregorianCalendar gregorianCalendar12 = viagem0.getData();
        double d13 = viagem0.getPreco();
        double d14 = viagem0.getTempo();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str8.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d11 == 0.0d);
        org.junit.Assert.assertNotNull(gregorianCalendar12);
        org.junit.Assert.assertTrue(d13 == 0.0d);
        org.junit.Assert.assertTrue(d14 == 10.0d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = new Viagem(viagem0);
        java.util.GregorianCalendar gregorianCalendar6 = viagem0.getData();
        java.lang.String str7 = viagem0.toString();
        java.lang.String str8 = viagem0.getMail();
        Viagem viagem9 = new Viagem();
        viagem9.setTempo(10.0d);
        boolean b13 = viagem9.equals((java.lang.Object) 100L);
        Coordenada coordenada14 = viagem9.getcfinal();
        Viagem viagem15 = new Viagem();
        viagem15.setTempo(10.0d);
        boolean b19 = viagem15.equals((java.lang.Object) 100L);
        Viagem viagem20 = viagem15.clone();
        Coordenada coordenada21 = viagem20.getcfinal();
        viagem9.setcinicial(coordenada21);
        viagem0.setcfinal(coordenada21);
        double d24 = viagem0.getTempo();
        Viagem viagem25 = new Viagem();
        viagem25.setTempo(10.0d);
        boolean b29 = viagem25.equals((java.lang.Object) 100L);
        double d30 = viagem25.getTempo();
        Coordenada coordenada31 = viagem25.getcfinal();
        double d32 = viagem25.getDesvio();
        boolean b33 = viagem0.equals((java.lang.Object) d32);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(gregorianCalendar6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str7.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue(b13 == false);
        org.junit.Assert.assertNotNull(coordenada14);
        org.junit.Assert.assertTrue(b19 == false);
        org.junit.Assert.assertNotNull(viagem20);
        org.junit.Assert.assertNotNull(coordenada21);
        org.junit.Assert.assertTrue(d24 == 10.0d);
        org.junit.Assert.assertTrue(b29 == false);
        org.junit.Assert.assertTrue(d30 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada31);
        org.junit.Assert.assertTrue(d32 == 0.0d);
        org.junit.Assert.assertTrue(b33 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str8 = viagem0.toString();
        viagem0.setMail("");
        double d11 = viagem0.getDesvio();
        java.util.GregorianCalendar gregorianCalendar12 = viagem0.getData();
        viagem0.setTempo((double) (-263));
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str8.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d11 == 0.0d);
        org.junit.Assert.assertNotNull(gregorianCalendar12);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        double d3 = viagem0.getTempo();
        java.lang.String str4 = viagem0.toString();
        org.junit.Assert.assertTrue(d3 == 10.0d);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str4.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        Viagem viagem0 = null;
        try {
            Viagem viagem1 = new Viagem(viagem0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Coordenada coordenada5 = viagem0.getcfinal();
        double d6 = viagem0.getTempo();
        Viagem viagem7 = new Viagem(viagem0);
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        double d10 = viagem0.getTempo();
        double d11 = viagem0.getTempo();
        double d12 = viagem0.getTempo();
        Viagem viagem13 = viagem0.clone();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(d6 == 10.0d);
        org.junit.Assert.assertTrue(d10 == 10.0d);
        org.junit.Assert.assertTrue(d11 == 10.0d);
        org.junit.Assert.assertTrue(d12 == 10.0d);
        org.junit.Assert.assertNotNull(viagem13);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = new Viagem(viagem0);
        java.lang.String str3 = viagem2.toString();
        java.lang.String str4 = viagem2.getMail();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str3.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        viagem0.setTempo((double) 100);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        viagem0.setMail("hi!");
        Coordenada coordenada4 = viagem0.getcfinal();
        double d5 = viagem0.getPreco();
        viagem0.setTempo(100.0d);
        Coordenada coordenada8 = viagem0.getcfinal();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(coordenada4);
        org.junit.Assert.assertTrue(d5 == 0.0d);
        org.junit.Assert.assertNotNull(coordenada8);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        Coordenada coordenada3 = viagem0.getcinicial();
        Viagem viagem4 = new Viagem(viagem0);
        Coordenada coordenada5 = viagem4.getcinicial();
        double d6 = viagem4.getTempo();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertNotNull(coordenada3);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(d6 == 0.0d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        java.lang.String str3 = viagem2.getMail();
        Viagem viagem4 = new Viagem();
        java.lang.String str5 = viagem4.toString();
        Viagem viagem6 = viagem4.clone();
        Coordenada coordenada7 = viagem4.getcinicial();
        viagem2.setcfinal(coordenada7);
        double d9 = viagem2.getDesvio();
        Viagem viagem10 = new Viagem();
        java.lang.String str11 = viagem10.toString();
        Viagem viagem12 = viagem10.clone();
        Coordenada coordenada13 = viagem10.getcinicial();
        java.lang.Object obj14 = null;
        boolean b15 = viagem10.equals(obj14);
        int i16 = viagem2.compareTo(viagem10);
        Viagem viagem17 = viagem10.clone();
        Coordenada coordenada18 = viagem17.getcfinal();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str5.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem6);
        org.junit.Assert.assertNotNull(coordenada7);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str11.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem12);
        org.junit.Assert.assertNotNull(coordenada13);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertTrue(i16 == (-1));
        org.junit.Assert.assertNotNull(viagem17);
        org.junit.Assert.assertNotNull(coordenada18);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        Viagem viagem3 = new Viagem(viagem0);
        Viagem viagem4 = new Viagem();
        viagem4.setTempo(10.0d);
        boolean b8 = viagem4.equals((java.lang.Object) 100L);
        Coordenada coordenada9 = viagem4.getcfinal();
        Coordenada coordenada10 = viagem4.getcinicial();
        Coordenada coordenada11 = viagem4.getcinicial();
        Viagem viagem12 = new Viagem();
        viagem12.setTempo(10.0d);
        boolean b16 = viagem12.equals((java.lang.Object) 100L);
        Coordenada coordenada17 = viagem12.getcfinal();
        double d18 = viagem12.getTempo();
        Viagem viagem19 = new Viagem(viagem12);
        Coordenada coordenada20 = viagem12.getcfinal();
        Viagem viagem23 = new Viagem();
        viagem23.setTempo(10.0d);
        boolean b27 = viagem23.equals((java.lang.Object) 100L);
        Viagem viagem28 = viagem23.clone();
        Coordenada coordenada29 = viagem28.getcfinal();
        java.util.GregorianCalendar gregorianCalendar30 = viagem28.getData();
        Viagem viagem33 = new Viagem(coordenada11, coordenada20, (double) (short) 10, "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: -1.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00", gregorianCalendar30, (double) (byte) 10, (double) (short) -1);
        viagem0.setcfinal(coordenada11);
        org.junit.Assert.assertTrue(b8 == false);
        org.junit.Assert.assertNotNull(coordenada9);
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertNotNull(coordenada11);
        org.junit.Assert.assertTrue(b16 == false);
        org.junit.Assert.assertNotNull(coordenada17);
        org.junit.Assert.assertTrue(d18 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada20);
        org.junit.Assert.assertTrue(b27 == false);
        org.junit.Assert.assertNotNull(viagem28);
        org.junit.Assert.assertNotNull(coordenada29);
        org.junit.Assert.assertNotNull(gregorianCalendar30);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        viagem0.setMail("hi!");
        Coordenada coordenada4 = viagem0.getcfinal();
        viagem0.setTempo((double) (-1.0f));
        viagem0.setTempo(10.0d);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(coordenada4);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Coordenada coordenada5 = viagem0.getcfinal();
        double d6 = viagem0.getTempo();
        double d7 = viagem0.getDesvio();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem10 = new Viagem(viagem0);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(d6 == 10.0d);
        org.junit.Assert.assertTrue(d7 == 0.0d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Coordenada coordenada5 = viagem0.getcfinal();
        double d6 = viagem0.getTempo();
        Viagem viagem7 = new Viagem(viagem0);
        viagem0.setTempo((double) (byte) 10);
        Viagem viagem10 = new Viagem(viagem0);
        double d11 = viagem0.getPreco();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(d6 == 10.0d);
        org.junit.Assert.assertTrue(d11 == 0.0d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        double d8 = viagem0.getPreco();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        double d11 = viagem0.getDesvio();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertTrue(d8 == 0.0d);
        org.junit.Assert.assertTrue(d11 == 0.0d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Coordenada coordenada8 = viagem0.getcfinal();
        java.util.GregorianCalendar gregorianCalendar9 = viagem0.getData();
        double d10 = viagem0.getTempo();
        Viagem viagem11 = new Viagem();
        viagem11.setTempo(10.0d);
        boolean b15 = viagem11.equals((java.lang.Object) 100L);
        Coordenada coordenada16 = viagem11.getcfinal();
        double d17 = viagem11.getTempo();
        Viagem viagem18 = new Viagem(viagem11);
        Viagem viagem19 = new Viagem();
        viagem19.setTempo(10.0d);
        boolean b23 = viagem19.equals((java.lang.Object) 100L);
        Viagem viagem24 = viagem19.clone();
        Viagem viagem25 = new Viagem(viagem19);
        boolean b26 = viagem11.equals((java.lang.Object) viagem25);
        double d27 = viagem25.getDesvio();
        Viagem viagem28 = viagem25.clone();
        boolean b29 = viagem0.equals((java.lang.Object) viagem28);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada8);
        org.junit.Assert.assertNotNull(gregorianCalendar9);
        org.junit.Assert.assertTrue(d10 == 10.0d);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertNotNull(coordenada16);
        org.junit.Assert.assertTrue(d17 == 10.0d);
        org.junit.Assert.assertTrue(b23 == false);
        org.junit.Assert.assertNotNull(viagem24);
        org.junit.Assert.assertTrue(b26 == false);
        org.junit.Assert.assertTrue(d27 == 0.0d);
        org.junit.Assert.assertNotNull(viagem28);
        org.junit.Assert.assertTrue(b29 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Coordenada coordenada5 = viagem0.getcfinal();
        double d6 = viagem0.getTempo();
        Viagem viagem7 = new Viagem(viagem0);
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.util.GregorianCalendar gregorianCalendar10 = viagem0.getData();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        viagem0.setMail("");
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(d6 == 10.0d);
        org.junit.Assert.assertNotNull(gregorianCalendar10);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.util.GregorianCalendar gregorianCalendar8 = viagem0.getData();
        boolean b10 = viagem0.equals((java.lang.Object) 1);
        Viagem viagem11 = viagem0.clone();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertNotNull(gregorianCalendar8);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertNotNull(viagem11);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = new Viagem(viagem0);
        java.util.GregorianCalendar gregorianCalendar6 = viagem0.getData();
        java.lang.String str7 = viagem0.toString();
        double d8 = viagem0.getPreco();
        Coordenada coordenada9 = viagem0.getcinicial();
        double d10 = viagem0.getDesvio();
        Viagem viagem11 = new Viagem(viagem0);
        Viagem viagem12 = new Viagem();
        viagem12.setTempo(10.0d);
        boolean b16 = viagem12.equals((java.lang.Object) 100L);
        double d17 = viagem12.getTempo();
        double d18 = viagem12.getTempo();
        boolean b19 = viagem11.equals((java.lang.Object) d18);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(gregorianCalendar6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str7.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d8 == 0.0d);
        org.junit.Assert.assertNotNull(coordenada9);
        org.junit.Assert.assertTrue(d10 == 0.0d);
        org.junit.Assert.assertTrue(b16 == false);
        org.junit.Assert.assertTrue(d17 == 10.0d);
        org.junit.Assert.assertTrue(d18 == 10.0d);
        org.junit.Assert.assertTrue(b19 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        Coordenada coordenada3 = viagem0.getcinicial();
        Viagem viagem4 = new Viagem(viagem0);
        viagem4.setTempo((double) (short) 0);
        Viagem viagem7 = new Viagem();
        java.lang.String str8 = viagem7.toString();
        Viagem viagem9 = viagem7.clone();
        Coordenada coordenada10 = viagem7.getcinicial();
        boolean b11 = viagem4.equals((java.lang.Object) coordenada10);
        double d12 = viagem4.getPreco();
        java.lang.String str13 = viagem4.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertNotNull(coordenada3);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str8.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem9);
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertTrue(d12 == 0.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str13.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        java.lang.String str3 = viagem2.getMail();
        Viagem viagem4 = new Viagem();
        java.lang.String str5 = viagem4.toString();
        Viagem viagem6 = viagem4.clone();
        Coordenada coordenada7 = viagem4.getcinicial();
        viagem2.setcfinal(coordenada7);
        double d9 = viagem2.getDesvio();
        Viagem viagem10 = new Viagem();
        java.lang.String str11 = viagem10.toString();
        Viagem viagem12 = viagem10.clone();
        Coordenada coordenada13 = viagem10.getcinicial();
        java.lang.Object obj14 = null;
        boolean b15 = viagem10.equals(obj14);
        int i16 = viagem2.compareTo(viagem10);
        Viagem viagem17 = viagem10.clone();
        viagem10.setTempo((double) (short) 0);
        double d20 = viagem10.getPreco();
        viagem10.setMail("");
        java.lang.String str23 = viagem10.getMail();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str5.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem6);
        org.junit.Assert.assertNotNull(coordenada7);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str11.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem12);
        org.junit.Assert.assertNotNull(coordenada13);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertTrue(i16 == (-1));
        org.junit.Assert.assertNotNull(viagem17);
        org.junit.Assert.assertTrue(d20 == 0.0d);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Viagem viagem6 = new Viagem(viagem0);
        Viagem viagem7 = new Viagem();
        viagem7.setTempo(10.0d);
        boolean b11 = viagem7.equals((java.lang.Object) 100L);
        Viagem viagem12 = viagem7.clone();
        Viagem viagem13 = new Viagem(viagem7);
        int i14 = viagem0.compareTo(viagem7);
        viagem7.setMail("");
        Viagem viagem17 = viagem7.clone();
        viagem7.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(viagem5);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertNotNull(viagem12);
        org.junit.Assert.assertTrue(i14 == (-1));
        org.junit.Assert.assertNotNull(viagem17);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Viagem viagem6 = new Viagem(viagem0);
        Viagem viagem7 = new Viagem();
        viagem7.setTempo(10.0d);
        boolean b11 = viagem7.equals((java.lang.Object) 100L);
        Viagem viagem12 = viagem7.clone();
        Viagem viagem13 = new Viagem(viagem7);
        int i14 = viagem0.compareTo(viagem7);
        double d15 = viagem7.getTempo();
        Viagem viagem16 = viagem7.clone();
        double d17 = viagem7.getPreco();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(viagem5);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertNotNull(viagem12);
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(d15 == 10.0d);
        org.junit.Assert.assertNotNull(viagem16);
        org.junit.Assert.assertTrue(d17 == 0.0d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Viagem viagem6 = new Viagem(viagem0);
        Viagem viagem7 = new Viagem();
        viagem7.setTempo(10.0d);
        boolean b11 = viagem7.equals((java.lang.Object) 100L);
        Viagem viagem12 = viagem7.clone();
        Viagem viagem13 = new Viagem(viagem7);
        int i14 = viagem0.compareTo(viagem7);
        viagem7.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem17 = new Viagem();
        viagem17.setTempo(10.0d);
        boolean b21 = viagem17.equals((java.lang.Object) 100L);
        double d22 = viagem17.getTempo();
        viagem17.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem25 = new Viagem(viagem17);
        Coordenada coordenada26 = viagem17.getcfinal();
        Viagem viagem27 = new Viagem();
        viagem27.setTempo(10.0d);
        boolean b31 = viagem27.equals((java.lang.Object) 100L);
        Coordenada coordenada32 = viagem27.getcfinal();
        double d33 = viagem27.getTempo();
        Viagem viagem34 = new Viagem(viagem27);
        int i35 = viagem17.compareTo(viagem27);
        double d36 = viagem17.getPreco();
        Viagem viagem37 = new Viagem();
        viagem37.setTempo(10.0d);
        boolean b41 = viagem37.equals((java.lang.Object) 100L);
        double d42 = viagem37.getTempo();
        viagem37.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem45 = new Viagem(viagem37);
        Coordenada coordenada46 = viagem37.getcfinal();
        viagem17.setcfinal(coordenada46);
        Viagem viagem48 = viagem17.clone();
        Viagem viagem49 = viagem48.clone();
        Viagem viagem50 = new Viagem();
        viagem50.setTempo(10.0d);
        boolean b54 = viagem50.equals((java.lang.Object) 100L);
        Coordenada coordenada55 = viagem50.getcfinal();
        Viagem viagem56 = new Viagem();
        viagem56.setTempo(10.0d);
        boolean b60 = viagem56.equals((java.lang.Object) 100L);
        Viagem viagem61 = viagem56.clone();
        Coordenada coordenada62 = viagem61.getcfinal();
        viagem50.setcinicial(coordenada62);
        viagem49.setcfinal(coordenada62);
        Viagem viagem65 = new Viagem();
        viagem65.setTempo(10.0d);
        boolean b69 = viagem65.equals((java.lang.Object) 100L);
        double d70 = viagem65.getTempo();
        viagem65.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str73 = viagem65.toString();
        viagem65.setMail("");
        Viagem viagem76 = new Viagem(viagem65);
        Coordenada coordenada77 = viagem65.getcfinal();
        Coordenada coordenada78 = viagem65.getcinicial();
        viagem49.setcfinal(coordenada78);
        viagem7.setcfinal(coordenada78);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(viagem5);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertNotNull(viagem12);
        org.junit.Assert.assertTrue(i14 == (-1));
        org.junit.Assert.assertTrue(b21 == false);
        org.junit.Assert.assertTrue(d22 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada26);
        org.junit.Assert.assertTrue(b31 == false);
        org.junit.Assert.assertNotNull(coordenada32);
        org.junit.Assert.assertTrue(d33 == 10.0d);
        org.junit.Assert.assertTrue(i35 == 263);
        org.junit.Assert.assertTrue(d36 == 0.0d);
        org.junit.Assert.assertTrue(b41 == false);
        org.junit.Assert.assertTrue(d42 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada46);
        org.junit.Assert.assertNotNull(viagem48);
        org.junit.Assert.assertNotNull(viagem49);
        org.junit.Assert.assertTrue(b54 == false);
        org.junit.Assert.assertNotNull(coordenada55);
        org.junit.Assert.assertTrue(b60 == false);
        org.junit.Assert.assertNotNull(viagem61);
        org.junit.Assert.assertNotNull(coordenada62);
        org.junit.Assert.assertTrue(b69 == false);
        org.junit.Assert.assertTrue(d70 == 10.0d);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str73.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(coordenada77);
        org.junit.Assert.assertNotNull(coordenada78);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = new Viagem(viagem0);
        Viagem viagem3 = new Viagem();
        java.lang.String str4 = viagem3.toString();
        Viagem viagem5 = viagem3.clone();
        Coordenada coordenada6 = viagem3.getcfinal();
        Coordenada coordenada7 = viagem3.getcfinal();
        viagem2.setcinicial(coordenada7);
        double d9 = viagem2.getTempo();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str4.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem5);
        org.junit.Assert.assertNotNull(coordenada6);
        org.junit.Assert.assertNotNull(coordenada7);
        org.junit.Assert.assertTrue(d9 == 0.0d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem();
        viagem8.setTempo(10.0d);
        boolean b12 = viagem8.equals((java.lang.Object) 100L);
        double d13 = viagem8.getTempo();
        viagem8.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str16 = viagem8.toString();
        viagem8.setMail("");
        double d19 = viagem8.getDesvio();
        int i20 = viagem0.compareTo(viagem8);
        Viagem viagem21 = viagem0.clone();
        Coordenada coordenada22 = viagem0.getcinicial();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertTrue(d13 == 10.0d);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str16.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d19 == 0.0d);
        org.junit.Assert.assertTrue(i20 == 263);
        org.junit.Assert.assertNotNull(viagem21);
        org.junit.Assert.assertNotNull(coordenada22);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Coordenada coordenada5 = viagem0.getcfinal();
        double d6 = viagem0.getTempo();
        Viagem viagem7 = new Viagem(viagem0);
        Coordenada coordenada8 = viagem0.getcfinal();
        Coordenada coordenada9 = viagem0.getcfinal();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(d6 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada8);
        org.junit.Assert.assertNotNull(coordenada9);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Coordenada coordenada5 = viagem0.getcfinal();
        double d6 = viagem0.getTempo();
        Viagem viagem7 = new Viagem(viagem0);
        Coordenada coordenada8 = viagem7.getcinicial();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(d6 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada8);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        java.util.GregorianCalendar gregorianCalendar9 = viagem0.getData();
        Viagem viagem10 = new Viagem();
        viagem10.setTempo(10.0d);
        boolean b14 = viagem10.equals((java.lang.Object) 100L);
        Viagem viagem15 = viagem10.clone();
        Viagem viagem16 = new Viagem(viagem10);
        Viagem viagem17 = viagem10.clone();
        double d18 = viagem17.getPreco();
        Coordenada coordenada19 = viagem17.getcinicial();
        viagem0.setcfinal(coordenada19);
        Viagem viagem21 = new Viagem();
        viagem21.setTempo(10.0d);
        boolean b25 = viagem21.equals((java.lang.Object) 100L);
        double d26 = viagem21.getTempo();
        viagem21.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem29 = new Viagem(viagem21);
        Coordenada coordenada30 = viagem21.getcfinal();
        viagem21.setMail("hi!");
        double d33 = viagem21.getTempo();
        int i34 = viagem0.compareTo(viagem21);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertNotNull(gregorianCalendar9);
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertNotNull(viagem15);
        org.junit.Assert.assertNotNull(viagem17);
        org.junit.Assert.assertTrue(d18 == 0.0d);
        org.junit.Assert.assertNotNull(coordenada19);
        org.junit.Assert.assertTrue(b25 == false);
        org.junit.Assert.assertTrue(d26 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada30);
        org.junit.Assert.assertTrue(d33 == 10.0d);
        org.junit.Assert.assertTrue(i34 == (-37));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        Coordenada coordenada3 = viagem0.getcinicial();
        Viagem viagem4 = new Viagem(viagem0);
        Viagem viagem5 = new Viagem(viagem0);
        Viagem viagem6 = viagem5.clone();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertNotNull(coordenada3);
        org.junit.Assert.assertNotNull(viagem6);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        double d3 = viagem2.getDesvio();
        Viagem viagem4 = viagem2.clone();
        double d5 = viagem2.getPreco();
        double d6 = viagem2.getTempo();
        Viagem viagem7 = new Viagem(viagem2);
        Coordenada coordenada8 = viagem2.getcinicial();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertTrue(d3 == 0.0d);
        org.junit.Assert.assertNotNull(viagem4);
        org.junit.Assert.assertTrue(d5 == 0.0d);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertNotNull(coordenada8);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        java.lang.String str9 = viagem0.toString();
        java.lang.String str10 = viagem0.getMail();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str9.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str10.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str8 = viagem0.toString();
        viagem0.setMail("");
        Viagem viagem11 = new Viagem(viagem0);
        viagem11.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str8.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        Coordenada coordenada3 = viagem0.getcinicial();
        Viagem viagem4 = new Viagem(viagem0);
        Viagem viagem5 = new Viagem(viagem0);
        Coordenada coordenada6 = viagem5.getcfinal();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertNotNull(coordenada3);
        org.junit.Assert.assertNotNull(coordenada6);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        java.lang.String str3 = viagem2.getMail();
        Viagem viagem4 = new Viagem();
        java.lang.String str5 = viagem4.toString();
        Viagem viagem6 = viagem4.clone();
        Coordenada coordenada7 = viagem4.getcinicial();
        viagem2.setcfinal(coordenada7);
        double d9 = viagem2.getDesvio();
        Viagem viagem10 = new Viagem();
        java.lang.String str11 = viagem10.toString();
        Viagem viagem12 = viagem10.clone();
        Coordenada coordenada13 = viagem10.getcinicial();
        java.lang.Object obj14 = null;
        boolean b15 = viagem10.equals(obj14);
        int i16 = viagem2.compareTo(viagem10);
        double d17 = viagem10.getDesvio();
        java.lang.String str18 = viagem10.toString();
        double d19 = viagem10.getDesvio();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str5.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem6);
        org.junit.Assert.assertNotNull(coordenada7);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str11.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem12);
        org.junit.Assert.assertNotNull(coordenada13);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertTrue(i16 == (-1));
        org.junit.Assert.assertTrue(d17 == 0.0d);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str18.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d19 == 0.0d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Viagem viagem9 = viagem8.clone();
        viagem8.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertNotNull(viagem9);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Coordenada coordenada9 = viagem0.getcfinal();
        Viagem viagem10 = new Viagem();
        viagem10.setTempo(10.0d);
        boolean b14 = viagem10.equals((java.lang.Object) 100L);
        Coordenada coordenada15 = viagem10.getcfinal();
        double d16 = viagem10.getTempo();
        Viagem viagem17 = new Viagem(viagem10);
        int i18 = viagem0.compareTo(viagem10);
        double d19 = viagem0.getPreco();
        Viagem viagem20 = new Viagem();
        viagem20.setTempo(10.0d);
        boolean b24 = viagem20.equals((java.lang.Object) 100L);
        double d25 = viagem20.getTempo();
        viagem20.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem28 = new Viagem(viagem20);
        Coordenada coordenada29 = viagem20.getcfinal();
        viagem0.setcfinal(coordenada29);
        Viagem viagem31 = viagem0.clone();
        double d32 = viagem0.getTempo();
        Viagem viagem33 = viagem0.clone();
        double d34 = viagem33.getDesvio();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada9);
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertNotNull(coordenada15);
        org.junit.Assert.assertTrue(d16 == 10.0d);
        org.junit.Assert.assertTrue(i18 == 263);
        org.junit.Assert.assertTrue(d19 == 0.0d);
        org.junit.Assert.assertTrue(b24 == false);
        org.junit.Assert.assertTrue(d25 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada29);
        org.junit.Assert.assertNotNull(viagem31);
        org.junit.Assert.assertTrue(d32 == 10.0d);
        org.junit.Assert.assertNotNull(viagem33);
        org.junit.Assert.assertTrue(d34 == 0.0d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        Coordenada coordenada3 = viagem0.getcinicial();
        Viagem viagem4 = viagem0.clone();
        Coordenada coordenada5 = viagem0.getcfinal();
        double d6 = viagem0.getDesvio();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertNotNull(coordenada3);
        org.junit.Assert.assertNotNull(viagem4);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(d6 == 0.0d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = new Viagem(viagem0);
        java.util.GregorianCalendar gregorianCalendar6 = viagem0.getData();
        Viagem viagem7 = new Viagem();
        viagem7.setTempo(10.0d);
        boolean b11 = viagem7.equals((java.lang.Object) 100L);
        double d12 = viagem7.getTempo();
        Coordenada coordenada13 = viagem7.getcfinal();
        java.lang.String str14 = viagem7.getMail();
        Viagem viagem15 = new Viagem();
        viagem15.setTempo(10.0d);
        boolean b19 = viagem15.equals((java.lang.Object) 100L);
        double d20 = viagem15.getTempo();
        viagem15.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem23 = new Viagem();
        viagem23.setTempo(10.0d);
        boolean b27 = viagem23.equals((java.lang.Object) 100L);
        double d28 = viagem23.getTempo();
        viagem23.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str31 = viagem23.toString();
        viagem23.setMail("");
        double d34 = viagem23.getDesvio();
        int i35 = viagem15.compareTo(viagem23);
        Coordenada coordenada36 = viagem15.getcinicial();
        Viagem viagem37 = new Viagem();
        viagem37.setTempo(10.0d);
        boolean b41 = viagem37.equals((java.lang.Object) 100L);
        java.util.GregorianCalendar gregorianCalendar42 = viagem37.getData();
        Coordenada coordenada43 = viagem37.getcinicial();
        Viagem viagem44 = new Viagem();
        viagem44.setTempo(10.0d);
        boolean b48 = viagem44.equals((java.lang.Object) 100L);
        double d49 = viagem44.getTempo();
        viagem44.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem52 = new Viagem(viagem44);
        Viagem viagem53 = viagem52.clone();
        Coordenada coordenada54 = viagem53.getcfinal();
        boolean b55 = viagem37.equals((java.lang.Object) coordenada54);
        viagem15.setcfinal(coordenada54);
        viagem7.setcinicial(coordenada54);
        viagem0.setcfinal(coordenada54);
        double d59 = viagem0.getTempo();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(gregorianCalendar6);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertTrue(d12 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue(b19 == false);
        org.junit.Assert.assertTrue(d20 == 10.0d);
        org.junit.Assert.assertTrue(b27 == false);
        org.junit.Assert.assertTrue(d28 == 10.0d);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str31.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d34 == 0.0d);
        org.junit.Assert.assertTrue(i35 == 263);
        org.junit.Assert.assertNotNull(coordenada36);
        org.junit.Assert.assertTrue(b41 == false);
        org.junit.Assert.assertNotNull(gregorianCalendar42);
        org.junit.Assert.assertNotNull(coordenada43);
        org.junit.Assert.assertTrue(b48 == false);
        org.junit.Assert.assertTrue(d49 == 10.0d);
        org.junit.Assert.assertNotNull(viagem53);
        org.junit.Assert.assertNotNull(coordenada54);
        org.junit.Assert.assertTrue(b55 == false);
        org.junit.Assert.assertTrue(d59 == 10.0d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Viagem viagem6 = new Viagem();
        viagem6.setTempo(10.0d);
        boolean b10 = viagem6.equals((java.lang.Object) 100L);
        double d11 = viagem6.getTempo();
        viagem6.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem14 = new Viagem(viagem6);
        Viagem viagem15 = viagem14.clone();
        Coordenada coordenada16 = viagem15.getcfinal();
        Viagem viagem17 = new Viagem();
        viagem17.setTempo(10.0d);
        boolean b21 = viagem17.equals((java.lang.Object) 100L);
        double d22 = viagem17.getTempo();
        viagem17.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str25 = viagem17.toString();
        viagem17.setMail("");
        Viagem viagem28 = new Viagem(viagem17);
        int i29 = viagem15.compareTo(viagem28);
        Coordenada coordenada30 = viagem15.getcfinal();
        int i31 = viagem5.compareTo(viagem15);
        java.lang.String str32 = viagem15.getMail();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(viagem5);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue(d11 == 10.0d);
        org.junit.Assert.assertNotNull(viagem15);
        org.junit.Assert.assertNotNull(coordenada16);
        org.junit.Assert.assertTrue(b21 == false);
        org.junit.Assert.assertTrue(d22 == 10.0d);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str25.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(i29 == 263);
        org.junit.Assert.assertNotNull(coordenada30);
        org.junit.Assert.assertTrue(i31 == (-263));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str32.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        java.lang.String str3 = viagem2.getMail();
        Viagem viagem4 = new Viagem();
        java.lang.String str5 = viagem4.toString();
        Viagem viagem6 = viagem4.clone();
        Coordenada coordenada7 = viagem4.getcinicial();
        viagem2.setcfinal(coordenada7);
        double d9 = viagem2.getDesvio();
        Viagem viagem10 = new Viagem();
        java.lang.String str11 = viagem10.toString();
        Viagem viagem12 = viagem10.clone();
        Coordenada coordenada13 = viagem10.getcinicial();
        java.lang.Object obj14 = null;
        boolean b15 = viagem10.equals(obj14);
        int i16 = viagem2.compareTo(viagem10);
        double d17 = viagem2.getDesvio();
        Coordenada coordenada18 = viagem2.getcfinal();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str5.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem6);
        org.junit.Assert.assertNotNull(coordenada7);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str11.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem12);
        org.junit.Assert.assertNotNull(coordenada13);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertTrue(i16 == (-1));
        org.junit.Assert.assertTrue(d17 == 0.0d);
        org.junit.Assert.assertNotNull(coordenada18);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        double d8 = viagem0.getPreco();
        double d9 = viagem0.getPreco();
        viagem0.setTempo(10.0d);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertTrue(d8 == 0.0d);
        org.junit.Assert.assertTrue(d9 == 0.0d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = new Viagem(viagem0);
        Coordenada coordenada3 = viagem2.getcinicial();
        Coordenada coordenada4 = viagem2.getcfinal();
        java.lang.String str5 = viagem2.getMail();
        double d6 = viagem2.getPreco();
        Viagem viagem7 = viagem2.clone();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(coordenada3);
        org.junit.Assert.assertNotNull(coordenada4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertNotNull(viagem7);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Coordenada coordenada5 = viagem0.getcfinal();
        Coordenada coordenada6 = viagem0.getcinicial();
        java.util.GregorianCalendar gregorianCalendar7 = viagem0.getData();
        Coordenada coordenada8 = viagem0.getcfinal();
        Coordenada coordenada9 = viagem0.getcfinal();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertNotNull(coordenada6);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
        org.junit.Assert.assertNotNull(coordenada8);
        org.junit.Assert.assertNotNull(coordenada9);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        double d6 = viagem0.getPreco();
        double d7 = viagem0.getPreco();
        java.lang.String str8 = viagem0.getMail();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(d7 == 0.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        double d3 = viagem2.getDesvio();
        Viagem viagem4 = viagem2.clone();
        double d5 = viagem2.getPreco();
        Viagem viagem6 = new Viagem(viagem2);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertTrue(d3 == 0.0d);
        org.junit.Assert.assertNotNull(viagem4);
        org.junit.Assert.assertTrue(d5 == 0.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Coordenada coordenada9 = viagem0.getcfinal();
        Viagem viagem10 = new Viagem();
        viagem10.setTempo(10.0d);
        boolean b14 = viagem10.equals((java.lang.Object) 100L);
        Coordenada coordenada15 = viagem10.getcfinal();
        double d16 = viagem10.getTempo();
        Viagem viagem17 = new Viagem(viagem10);
        int i18 = viagem0.compareTo(viagem10);
        double d19 = viagem0.getPreco();
        Viagem viagem20 = new Viagem();
        viagem20.setTempo(10.0d);
        boolean b24 = viagem20.equals((java.lang.Object) 100L);
        double d25 = viagem20.getTempo();
        viagem20.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem28 = new Viagem(viagem20);
        Coordenada coordenada29 = viagem20.getcfinal();
        viagem0.setcfinal(coordenada29);
        double d31 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        double d34 = viagem0.getPreco();
        Viagem viagem35 = viagem0.clone();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada9);
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertNotNull(coordenada15);
        org.junit.Assert.assertTrue(d16 == 10.0d);
        org.junit.Assert.assertTrue(i18 == 263);
        org.junit.Assert.assertTrue(d19 == 0.0d);
        org.junit.Assert.assertTrue(b24 == false);
        org.junit.Assert.assertTrue(d25 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada29);
        org.junit.Assert.assertTrue(d31 == 10.0d);
        org.junit.Assert.assertTrue(d34 == 0.0d);
        org.junit.Assert.assertNotNull(viagem35);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Viagem viagem6 = new Viagem(viagem0);
        Viagem viagem7 = viagem0.clone();
        double d8 = viagem7.getPreco();
        Coordenada coordenada9 = viagem7.getcinicial();
        java.lang.String str10 = viagem7.getMail();
        Viagem viagem11 = new Viagem(viagem7);
        java.lang.String str12 = viagem11.getMail();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(viagem5);
        org.junit.Assert.assertNotNull(viagem7);
        org.junit.Assert.assertTrue(d8 == 0.0d);
        org.junit.Assert.assertNotNull(coordenada9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Coordenada coordenada5 = viagem0.getcfinal();
        Coordenada coordenada6 = viagem0.getcinicial();
        Viagem viagem7 = viagem0.clone();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertNotNull(coordenada6);
        org.junit.Assert.assertNotNull(viagem7);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Viagem viagem6 = new Viagem(viagem0);
        Viagem viagem7 = new Viagem();
        viagem7.setTempo(10.0d);
        boolean b11 = viagem7.equals((java.lang.Object) 100L);
        Viagem viagem12 = viagem7.clone();
        Viagem viagem13 = new Viagem(viagem7);
        int i14 = viagem0.compareTo(viagem7);
        viagem7.setMail("");
        java.lang.String str17 = viagem7.toString();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(viagem5);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertNotNull(viagem12);
        org.junit.Assert.assertTrue(i14 == (-1));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str17.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Viagem viagem6 = new Viagem(viagem0);
        Viagem viagem7 = viagem6.clone();
        Viagem viagem8 = new Viagem(viagem6);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(viagem5);
        org.junit.Assert.assertNotNull(viagem7);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem();
        viagem8.setTempo(10.0d);
        boolean b12 = viagem8.equals((java.lang.Object) 100L);
        double d13 = viagem8.getTempo();
        viagem8.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str16 = viagem8.toString();
        viagem8.setMail("");
        double d19 = viagem8.getDesvio();
        int i20 = viagem0.compareTo(viagem8);
        double d21 = viagem0.getPreco();
        java.lang.String str22 = viagem0.toString();
        viagem0.setTempo((double) 10L);
        double d25 = viagem0.getTempo();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertTrue(d13 == 10.0d);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str16.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d19 == 0.0d);
        org.junit.Assert.assertTrue(i20 == 263);
        org.junit.Assert.assertTrue(d21 == 0.0d);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str22.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d25 == 10.0d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Coordenada coordenada5 = viagem0.getcfinal();
        double d6 = viagem0.getTempo();
        Viagem viagem7 = new Viagem(viagem0);
        Viagem viagem8 = new Viagem();
        viagem8.setTempo(10.0d);
        boolean b12 = viagem8.equals((java.lang.Object) 100L);
        Viagem viagem13 = viagem8.clone();
        Viagem viagem14 = new Viagem(viagem8);
        boolean b15 = viagem0.equals((java.lang.Object) viagem14);
        java.util.GregorianCalendar gregorianCalendar16 = viagem0.getData();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(d6 == 10.0d);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertNotNull(viagem13);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertNotNull(gregorianCalendar16);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Coordenada coordenada5 = viagem0.getcfinal();
        double d6 = viagem0.getTempo();
        double d7 = viagem0.getDesvio();
        Viagem viagem8 = new Viagem();
        viagem8.setTempo(10.0d);
        boolean b12 = viagem8.equals((java.lang.Object) 100L);
        double d13 = viagem8.getTempo();
        viagem8.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str16 = viagem8.toString();
        viagem8.setMail("");
        Coordenada coordenada19 = viagem8.getcinicial();
        boolean b20 = viagem0.equals((java.lang.Object) coordenada19);
        double d21 = viagem0.getTempo();
        Coordenada coordenada22 = viagem0.getcinicial();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(d6 == 10.0d);
        org.junit.Assert.assertTrue(d7 == 0.0d);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertTrue(d13 == 10.0d);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str16.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(coordenada19);
        org.junit.Assert.assertTrue(b20 == false);
        org.junit.Assert.assertTrue(d21 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada22);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        java.lang.String str3 = viagem2.getMail();
        Viagem viagem4 = new Viagem();
        java.lang.String str5 = viagem4.toString();
        Viagem viagem6 = viagem4.clone();
        Coordenada coordenada7 = viagem4.getcinicial();
        viagem2.setcfinal(coordenada7);
        double d9 = viagem2.getDesvio();
        Viagem viagem10 = new Viagem();
        java.lang.String str11 = viagem10.toString();
        Viagem viagem12 = viagem10.clone();
        Coordenada coordenada13 = viagem10.getcinicial();
        java.lang.Object obj14 = null;
        boolean b15 = viagem10.equals(obj14);
        int i16 = viagem2.compareTo(viagem10);
        double d17 = viagem10.getDesvio();
        Viagem viagem18 = new Viagem();
        java.lang.String str19 = viagem18.toString();
        Viagem viagem20 = viagem18.clone();
        Coordenada coordenada21 = viagem18.getcinicial();
        Viagem viagem22 = viagem18.clone();
        Coordenada coordenada23 = viagem22.getcfinal();
        int i24 = viagem10.compareTo(viagem22);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str5.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem6);
        org.junit.Assert.assertNotNull(coordenada7);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str11.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem12);
        org.junit.Assert.assertNotNull(coordenada13);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertTrue(i16 == (-1));
        org.junit.Assert.assertTrue(d17 == 0.0d);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str19.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem20);
        org.junit.Assert.assertNotNull(coordenada21);
        org.junit.Assert.assertNotNull(viagem22);
        org.junit.Assert.assertNotNull(coordenada23);
        org.junit.Assert.assertTrue(i24 == 0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Coordenada coordenada9 = viagem0.getcfinal();
        Viagem viagem10 = new Viagem();
        viagem10.setTempo(10.0d);
        boolean b14 = viagem10.equals((java.lang.Object) 100L);
        Coordenada coordenada15 = viagem10.getcfinal();
        double d16 = viagem10.getTempo();
        Viagem viagem17 = new Viagem(viagem10);
        int i18 = viagem0.compareTo(viagem10);
        double d19 = viagem0.getDesvio();
        Viagem viagem20 = viagem0.clone();
        Viagem viagem21 = new Viagem();
        viagem21.setTempo(10.0d);
        boolean b25 = viagem21.equals((java.lang.Object) 100L);
        double d26 = viagem21.getTempo();
        viagem21.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Coordenada coordenada29 = viagem21.getcfinal();
        java.util.GregorianCalendar gregorianCalendar30 = viagem21.getData();
        double d31 = viagem21.getTempo();
        Coordenada coordenada32 = viagem21.getcfinal();
        viagem0.setcfinal(coordenada32);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada9);
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertNotNull(coordenada15);
        org.junit.Assert.assertTrue(d16 == 10.0d);
        org.junit.Assert.assertTrue(i18 == 263);
        org.junit.Assert.assertTrue(d19 == 0.0d);
        org.junit.Assert.assertNotNull(viagem20);
        org.junit.Assert.assertTrue(b25 == false);
        org.junit.Assert.assertTrue(d26 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada29);
        org.junit.Assert.assertNotNull(gregorianCalendar30);
        org.junit.Assert.assertTrue(d31 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada32);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        double d6 = viagem0.getPreco();
        java.lang.String str7 = viagem0.getMail();
        Viagem viagem8 = viagem0.clone();
        java.util.GregorianCalendar gregorianCalendar9 = viagem0.getData();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(viagem8);
        org.junit.Assert.assertNotNull(gregorianCalendar9);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        Coordenada coordenada3 = viagem0.getcinicial();
        Viagem viagem4 = new Viagem(viagem0);
        Viagem viagem5 = new Viagem(viagem0);
        Coordenada coordenada6 = viagem0.getcfinal();
        Viagem viagem7 = new Viagem();
        java.lang.String str8 = viagem7.toString();
        Viagem viagem9 = viagem7.clone();
        java.lang.String str10 = viagem7.getMail();
        Viagem viagem11 = new Viagem(viagem7);
        int i12 = viagem0.compareTo(viagem7);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertNotNull(coordenada3);
        org.junit.Assert.assertNotNull(coordenada6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str8.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue(i12 == (-1));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Coordenada coordenada5 = viagem0.getcfinal();
        double d6 = viagem0.getTempo();
        Viagem viagem7 = new Viagem(viagem0);
        viagem0.setTempo((double) (byte) 10);
        Viagem viagem10 = new Viagem(viagem0);
        Coordenada coordenada11 = viagem0.getcfinal();
        Viagem viagem12 = viagem0.clone();
        double d13 = viagem0.getTempo();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(d6 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada11);
        org.junit.Assert.assertNotNull(viagem12);
        org.junit.Assert.assertTrue(d13 == 10.0d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        java.lang.String str3 = viagem2.getMail();
        Viagem viagem4 = new Viagem();
        java.lang.String str5 = viagem4.toString();
        Viagem viagem6 = viagem4.clone();
        java.lang.String str7 = viagem6.getMail();
        Viagem viagem8 = new Viagem();
        java.lang.String str9 = viagem8.toString();
        Viagem viagem10 = viagem8.clone();
        Coordenada coordenada11 = viagem8.getcinicial();
        viagem6.setcfinal(coordenada11);
        double d13 = viagem6.getDesvio();
        viagem6.setMail("hi!");
        java.lang.String str16 = viagem6.toString();
        Coordenada coordenada17 = viagem6.getcfinal();
        viagem2.setcfinal(coordenada17);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str5.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str9.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem10);
        org.junit.Assert.assertNotNull(coordenada11);
        org.junit.Assert.assertTrue(d13 == 0.0d);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str16.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(coordenada17);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem();
        viagem8.setTempo(10.0d);
        boolean b12 = viagem8.equals((java.lang.Object) 100L);
        double d13 = viagem8.getTempo();
        viagem8.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str16 = viagem8.toString();
        viagem8.setMail("");
        double d19 = viagem8.getDesvio();
        int i20 = viagem0.compareTo(viagem8);
        Viagem viagem21 = viagem0.clone();
        double d22 = viagem21.getTempo();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertTrue(d13 == 10.0d);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str16.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d19 == 0.0d);
        org.junit.Assert.assertTrue(i20 == 263);
        org.junit.Assert.assertNotNull(viagem21);
        org.junit.Assert.assertTrue(d22 == 10.0d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Coordenada coordenada9 = viagem0.getcfinal();
        Viagem viagem10 = new Viagem();
        viagem10.setTempo(10.0d);
        boolean b14 = viagem10.equals((java.lang.Object) 100L);
        Coordenada coordenada15 = viagem10.getcfinal();
        double d16 = viagem10.getTempo();
        Viagem viagem17 = new Viagem(viagem10);
        int i18 = viagem0.compareTo(viagem10);
        double d19 = viagem0.getPreco();
        Viagem viagem20 = new Viagem();
        viagem20.setTempo(10.0d);
        boolean b24 = viagem20.equals((java.lang.Object) 100L);
        double d25 = viagem20.getTempo();
        viagem20.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem28 = new Viagem(viagem20);
        Coordenada coordenada29 = viagem20.getcfinal();
        viagem0.setcfinal(coordenada29);
        Viagem viagem31 = viagem0.clone();
        double d32 = viagem0.getTempo();
        Viagem viagem33 = viagem0.clone();
        Coordenada coordenada34 = viagem0.getcfinal();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada9);
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertNotNull(coordenada15);
        org.junit.Assert.assertTrue(d16 == 10.0d);
        org.junit.Assert.assertTrue(i18 == 263);
        org.junit.Assert.assertTrue(d19 == 0.0d);
        org.junit.Assert.assertTrue(b24 == false);
        org.junit.Assert.assertTrue(d25 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada29);
        org.junit.Assert.assertNotNull(viagem31);
        org.junit.Assert.assertTrue(d32 == 10.0d);
        org.junit.Assert.assertNotNull(viagem33);
        org.junit.Assert.assertNotNull(coordenada34);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo((double) 0.0f);
        java.util.GregorianCalendar gregorianCalendar3 = viagem0.getData();
        Coordenada coordenada4 = viagem0.getcinicial();
        Viagem viagem5 = viagem0.clone();
        org.junit.Assert.assertNotNull(gregorianCalendar3);
        org.junit.Assert.assertNotNull(coordenada4);
        org.junit.Assert.assertNotNull(viagem5);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Coordenada coordenada5 = viagem0.getcfinal();
        double d6 = viagem0.getTempo();
        Viagem viagem7 = new Viagem(viagem0);
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        double d10 = viagem0.getTempo();
        double d11 = viagem0.getTempo();
        java.util.GregorianCalendar gregorianCalendar12 = viagem0.getData();
        Viagem viagem13 = viagem0.clone();
        double d14 = viagem13.getPreco();
        double d15 = viagem13.getTempo();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(d6 == 10.0d);
        org.junit.Assert.assertTrue(d10 == 10.0d);
        org.junit.Assert.assertTrue(d11 == 10.0d);
        org.junit.Assert.assertNotNull(gregorianCalendar12);
        org.junit.Assert.assertNotNull(viagem13);
        org.junit.Assert.assertTrue(d14 == 0.0d);
        org.junit.Assert.assertTrue(d15 == 10.0d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = new Viagem(viagem0);
        Coordenada coordenada3 = viagem2.getcinicial();
        Coordenada coordenada4 = viagem2.getcfinal();
        java.lang.String str5 = viagem2.toString();
        Viagem viagem6 = new Viagem(viagem2);
        Coordenada coordenada7 = viagem2.getcinicial();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(coordenada3);
        org.junit.Assert.assertNotNull(coordenada4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str5.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(coordenada7);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str8 = viagem0.toString();
        viagem0.setMail("");
        double d11 = viagem0.getDesvio();
        double d12 = viagem0.getPreco();
        double d13 = viagem0.getDesvio();
        Viagem viagem14 = new Viagem(viagem0);
        Viagem viagem15 = new Viagem();
        viagem15.setTempo(10.0d);
        boolean b19 = viagem15.equals((java.lang.Object) 100L);
        Viagem viagem20 = new Viagem(viagem15);
        double d21 = viagem15.getTempo();
        double d22 = viagem15.getPreco();
        Viagem viagem23 = viagem15.clone();
        Coordenada coordenada24 = viagem23.getcfinal();
        int i25 = viagem14.compareTo(viagem23);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str8.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d11 == 0.0d);
        org.junit.Assert.assertTrue(d12 == 0.0d);
        org.junit.Assert.assertTrue(d13 == 0.0d);
        org.junit.Assert.assertTrue(b19 == false);
        org.junit.Assert.assertTrue(d21 == 10.0d);
        org.junit.Assert.assertTrue(d22 == 0.0d);
        org.junit.Assert.assertNotNull(viagem23);
        org.junit.Assert.assertNotNull(coordenada24);
        org.junit.Assert.assertTrue(i25 == (-1));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Viagem viagem9 = viagem8.clone();
        Coordenada coordenada10 = viagem9.getcfinal();
        Viagem viagem11 = new Viagem();
        viagem11.setTempo(10.0d);
        boolean b15 = viagem11.equals((java.lang.Object) 100L);
        double d16 = viagem11.getTempo();
        viagem11.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str19 = viagem11.toString();
        viagem11.setMail("");
        Viagem viagem22 = new Viagem(viagem11);
        int i23 = viagem9.compareTo(viagem22);
        java.lang.String str24 = viagem22.getMail();
        java.util.GregorianCalendar gregorianCalendar25 = viagem22.getData();
        java.lang.String str26 = viagem22.toString();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertNotNull(viagem9);
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertTrue(d16 == 10.0d);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str19.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(i23 == 263);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertNotNull(gregorianCalendar25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str26.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Coordenada coordenada5 = viagem0.getcfinal();
        double d6 = viagem0.getTempo();
        Viagem viagem7 = new Viagem(viagem0);
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        double d10 = viagem0.getTempo();
        double d11 = viagem0.getTempo();
        java.util.GregorianCalendar gregorianCalendar12 = viagem0.getData();
        Viagem viagem13 = viagem0.clone();
        Viagem viagem14 = new Viagem(viagem0);
        Viagem viagem15 = new Viagem(viagem0);
        double d16 = viagem15.getPreco();
        java.util.GregorianCalendar gregorianCalendar17 = viagem15.getData();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(d6 == 10.0d);
        org.junit.Assert.assertTrue(d10 == 10.0d);
        org.junit.Assert.assertTrue(d11 == 10.0d);
        org.junit.Assert.assertNotNull(gregorianCalendar12);
        org.junit.Assert.assertNotNull(viagem13);
        org.junit.Assert.assertTrue(d16 == 0.0d);
        org.junit.Assert.assertNotNull(gregorianCalendar17);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        double d3 = viagem0.getTempo();
        Coordenada coordenada4 = viagem0.getcfinal();
        double d5 = viagem0.getDesvio();
        double d6 = viagem0.getDesvio();
        double d7 = viagem0.getDesvio();
        double d8 = viagem0.getTempo();
        org.junit.Assert.assertTrue(d3 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada4);
        org.junit.Assert.assertTrue(d5 == 0.0d);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(d7 == 0.0d);
        org.junit.Assert.assertTrue(d8 == 10.0d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        java.lang.String str3 = viagem2.getMail();
        Viagem viagem4 = new Viagem();
        java.lang.String str5 = viagem4.toString();
        Viagem viagem6 = viagem4.clone();
        Coordenada coordenada7 = viagem4.getcinicial();
        viagem2.setcfinal(coordenada7);
        double d9 = viagem2.getDesvio();
        Viagem viagem10 = new Viagem();
        java.lang.String str11 = viagem10.toString();
        Viagem viagem12 = viagem10.clone();
        Coordenada coordenada13 = viagem10.getcinicial();
        java.lang.Object obj14 = null;
        boolean b15 = viagem10.equals(obj14);
        int i16 = viagem2.compareTo(viagem10);
        Viagem viagem17 = viagem10.clone();
        double d18 = viagem10.getDesvio();
        double d19 = viagem10.getPreco();
        double d20 = viagem10.getDesvio();
        java.util.GregorianCalendar gregorianCalendar21 = viagem10.getData();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str5.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem6);
        org.junit.Assert.assertNotNull(coordenada7);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str11.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem12);
        org.junit.Assert.assertNotNull(coordenada13);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertTrue(i16 == (-1));
        org.junit.Assert.assertNotNull(viagem17);
        org.junit.Assert.assertTrue(d18 == 0.0d);
        org.junit.Assert.assertTrue(d19 == 0.0d);
        org.junit.Assert.assertTrue(d20 == 0.0d);
        org.junit.Assert.assertNotNull(gregorianCalendar21);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Viagem viagem6 = new Viagem();
        viagem6.setTempo(10.0d);
        boolean b10 = viagem6.equals((java.lang.Object) 100L);
        double d11 = viagem6.getTempo();
        viagem6.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str14 = viagem6.toString();
        viagem6.setMail("");
        double d17 = viagem6.getDesvio();
        java.util.GregorianCalendar gregorianCalendar18 = viagem6.getData();
        int i19 = viagem5.compareTo(viagem6);
        Viagem viagem20 = new Viagem(viagem6);
        Viagem viagem21 = new Viagem();
        viagem21.setTempo(10.0d);
        boolean b25 = viagem21.equals((java.lang.Object) 100L);
        double d26 = viagem21.getTempo();
        viagem21.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem29 = new Viagem(viagem21);
        Coordenada coordenada30 = viagem21.getcfinal();
        Viagem viagem31 = new Viagem();
        viagem31.setTempo(10.0d);
        boolean b35 = viagem31.equals((java.lang.Object) 100L);
        Coordenada coordenada36 = viagem31.getcfinal();
        double d37 = viagem31.getTempo();
        Viagem viagem38 = new Viagem(viagem31);
        int i39 = viagem21.compareTo(viagem31);
        double d40 = viagem21.getDesvio();
        Viagem viagem41 = viagem21.clone();
        java.lang.String str42 = viagem41.toString();
        int i43 = viagem6.compareTo(viagem41);
        viagem41.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(viagem5);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue(d11 == 10.0d);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str14.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d17 == 0.0d);
        org.junit.Assert.assertNotNull(gregorianCalendar18);
        org.junit.Assert.assertTrue(i19 == 0);
        org.junit.Assert.assertTrue(b25 == false);
        org.junit.Assert.assertTrue(d26 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada30);
        org.junit.Assert.assertTrue(b35 == false);
        org.junit.Assert.assertNotNull(coordenada36);
        org.junit.Assert.assertTrue(d37 == 10.0d);
        org.junit.Assert.assertTrue(i39 == 263);
        org.junit.Assert.assertTrue(d40 == 0.0d);
        org.junit.Assert.assertNotNull(viagem41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str42.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(i43 == (-263));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Coordenada coordenada9 = viagem0.getcfinal();
        Viagem viagem10 = new Viagem();
        viagem10.setTempo(10.0d);
        boolean b14 = viagem10.equals((java.lang.Object) 100L);
        Coordenada coordenada15 = viagem10.getcfinal();
        double d16 = viagem10.getTempo();
        Viagem viagem17 = new Viagem(viagem10);
        int i18 = viagem0.compareTo(viagem10);
        double d19 = viagem0.getPreco();
        Viagem viagem20 = new Viagem();
        viagem20.setTempo(10.0d);
        boolean b24 = viagem20.equals((java.lang.Object) 100L);
        double d25 = viagem20.getTempo();
        viagem20.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem28 = new Viagem(viagem20);
        Coordenada coordenada29 = viagem20.getcfinal();
        viagem0.setcfinal(coordenada29);
        Viagem viagem31 = viagem0.clone();
        Viagem viagem32 = viagem31.clone();
        Viagem viagem33 = new Viagem();
        viagem33.setTempo(10.0d);
        boolean b37 = viagem33.equals((java.lang.Object) 100L);
        Coordenada coordenada38 = viagem33.getcfinal();
        Viagem viagem39 = new Viagem();
        viagem39.setTempo(10.0d);
        boolean b43 = viagem39.equals((java.lang.Object) 100L);
        Viagem viagem44 = viagem39.clone();
        Coordenada coordenada45 = viagem44.getcfinal();
        viagem33.setcinicial(coordenada45);
        viagem32.setcfinal(coordenada45);
        Viagem viagem48 = new Viagem();
        viagem48.setTempo(10.0d);
        boolean b52 = viagem48.equals((java.lang.Object) 100L);
        double d53 = viagem48.getTempo();
        viagem48.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str56 = viagem48.toString();
        viagem48.setMail("");
        Viagem viagem59 = new Viagem(viagem48);
        Coordenada coordenada60 = viagem48.getcfinal();
        Coordenada coordenada61 = viagem48.getcinicial();
        viagem32.setcfinal(coordenada61);
        double d63 = viagem32.getDesvio();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada9);
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertNotNull(coordenada15);
        org.junit.Assert.assertTrue(d16 == 10.0d);
        org.junit.Assert.assertTrue(i18 == 263);
        org.junit.Assert.assertTrue(d19 == 0.0d);
        org.junit.Assert.assertTrue(b24 == false);
        org.junit.Assert.assertTrue(d25 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada29);
        org.junit.Assert.assertNotNull(viagem31);
        org.junit.Assert.assertNotNull(viagem32);
        org.junit.Assert.assertTrue(b37 == false);
        org.junit.Assert.assertNotNull(coordenada38);
        org.junit.Assert.assertTrue(b43 == false);
        org.junit.Assert.assertNotNull(viagem44);
        org.junit.Assert.assertNotNull(coordenada45);
        org.junit.Assert.assertTrue(b52 == false);
        org.junit.Assert.assertTrue(d53 == 10.0d);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str56.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(coordenada60);
        org.junit.Assert.assertNotNull(coordenada61);
        org.junit.Assert.assertTrue(d63 == 0.0d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Coordenada coordenada5 = viagem0.getcfinal();
        double d6 = viagem0.getTempo();
        double d7 = viagem0.getDesvio();
        Viagem viagem8 = new Viagem();
        viagem8.setTempo(10.0d);
        boolean b12 = viagem8.equals((java.lang.Object) 100L);
        double d13 = viagem8.getTempo();
        viagem8.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str16 = viagem8.toString();
        viagem8.setMail("");
        Viagem viagem19 = new Viagem(viagem8);
        Coordenada coordenada20 = viagem8.getcfinal();
        double d21 = viagem8.getDesvio();
        boolean b22 = viagem0.equals((java.lang.Object) d21);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(d6 == 10.0d);
        org.junit.Assert.assertTrue(d7 == 0.0d);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertTrue(d13 == 10.0d);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str16.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(coordenada20);
        org.junit.Assert.assertTrue(d21 == 0.0d);
        org.junit.Assert.assertTrue(b22 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = new Viagem(viagem0);
        java.util.GregorianCalendar gregorianCalendar6 = viagem0.getData();
        java.lang.String str7 = viagem0.toString();
        double d8 = viagem0.getPreco();
        Coordenada coordenada9 = viagem0.getcinicial();
        double d10 = viagem0.getDesvio();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem13 = viagem0.clone();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(gregorianCalendar6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str7.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d8 == 0.0d);
        org.junit.Assert.assertNotNull(coordenada9);
        org.junit.Assert.assertTrue(d10 == 0.0d);
        org.junit.Assert.assertNotNull(viagem13);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        Coordenada coordenada3 = viagem0.getcinicial();
        java.lang.Object obj4 = null;
        boolean b5 = viagem0.equals(obj4);
        Viagem viagem6 = new Viagem();
        java.lang.String str7 = viagem6.toString();
        Viagem viagem8 = viagem6.clone();
        java.lang.String str9 = viagem8.getMail();
        boolean b10 = viagem0.equals((java.lang.Object) str9);
        Coordenada coordenada11 = viagem0.getcinicial();
        Coordenada coordenada12 = viagem0.getcfinal();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertNotNull(coordenada3);
        org.junit.Assert.assertTrue(b5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str7.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertNotNull(coordenada11);
        org.junit.Assert.assertNotNull(coordenada12);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        Coordenada coordenada6 = viagem0.getcfinal();
        Coordenada coordenada7 = viagem0.getcinicial();
        java.lang.String str8 = viagem0.getMail();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada6);
        org.junit.Assert.assertNotNull(coordenada7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        java.lang.String str3 = viagem2.getMail();
        Viagem viagem4 = new Viagem();
        java.lang.String str5 = viagem4.toString();
        Viagem viagem6 = viagem4.clone();
        Coordenada coordenada7 = viagem4.getcinicial();
        viagem2.setcfinal(coordenada7);
        double d9 = viagem2.getDesvio();
        Viagem viagem10 = new Viagem();
        java.lang.String str11 = viagem10.toString();
        Viagem viagem12 = viagem10.clone();
        Coordenada coordenada13 = viagem10.getcinicial();
        java.lang.Object obj14 = null;
        boolean b15 = viagem10.equals(obj14);
        int i16 = viagem2.compareTo(viagem10);
        Viagem viagem17 = viagem10.clone();
        Viagem viagem18 = new Viagem();
        java.lang.String str19 = viagem18.toString();
        Viagem viagem20 = viagem18.clone();
        Coordenada coordenada21 = viagem18.getcfinal();
        viagem10.setcinicial(coordenada21);
        java.lang.String str23 = viagem10.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str5.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem6);
        org.junit.Assert.assertNotNull(coordenada7);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str11.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem12);
        org.junit.Assert.assertNotNull(coordenada13);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertTrue(i16 == (-1));
        org.junit.Assert.assertNotNull(viagem17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str19.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem20);
        org.junit.Assert.assertNotNull(coordenada21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str23.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Coordenada coordenada5 = viagem0.getcfinal();
        double d6 = viagem0.getTempo();
        Viagem viagem7 = new Viagem(viagem0);
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        double d10 = viagem0.getDesvio();
        double d11 = viagem0.getDesvio();
        Coordenada coordenada12 = viagem0.getcinicial();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(d6 == 10.0d);
        org.junit.Assert.assertTrue(d10 == 0.0d);
        org.junit.Assert.assertTrue(d11 == 0.0d);
        org.junit.Assert.assertNotNull(coordenada12);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Viagem viagem9 = viagem8.clone();
        Coordenada coordenada10 = viagem9.getcfinal();
        Viagem viagem11 = new Viagem();
        viagem11.setTempo(10.0d);
        boolean b15 = viagem11.equals((java.lang.Object) 100L);
        double d16 = viagem11.getTempo();
        viagem11.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str19 = viagem11.toString();
        viagem11.setMail("");
        Viagem viagem22 = new Viagem(viagem11);
        int i23 = viagem9.compareTo(viagem22);
        double d24 = viagem9.getDesvio();
        double d25 = viagem9.getDesvio();
        viagem9.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertNotNull(viagem9);
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertTrue(d16 == 10.0d);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str19.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(i23 == 263);
        org.junit.Assert.assertTrue(d24 == 0.0d);
        org.junit.Assert.assertTrue(d25 == 0.0d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Viagem viagem6 = new Viagem(viagem0);
        Viagem viagem7 = new Viagem();
        viagem7.setTempo(10.0d);
        boolean b11 = viagem7.equals((java.lang.Object) 100L);
        Viagem viagem12 = viagem7.clone();
        Viagem viagem13 = new Viagem(viagem7);
        int i14 = viagem0.compareTo(viagem7);
        double d15 = viagem7.getTempo();
        Viagem viagem16 = viagem7.clone();
        Viagem viagem17 = new Viagem();
        viagem17.setTempo(10.0d);
        boolean b21 = viagem17.equals((java.lang.Object) 100L);
        double d22 = viagem17.getTempo();
        double d23 = viagem17.getPreco();
        Viagem viagem24 = new Viagem(viagem17);
        Viagem viagem25 = new Viagem(viagem17);
        int i26 = viagem7.compareTo(viagem25);
        java.util.GregorianCalendar gregorianCalendar27 = viagem25.getData();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(viagem5);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertNotNull(viagem12);
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(d15 == 10.0d);
        org.junit.Assert.assertNotNull(viagem16);
        org.junit.Assert.assertTrue(b21 == false);
        org.junit.Assert.assertTrue(d22 == 10.0d);
        org.junit.Assert.assertTrue(d23 == 0.0d);
        org.junit.Assert.assertTrue(i26 == (-1));
        org.junit.Assert.assertNotNull(gregorianCalendar27);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        double d8 = viagem0.getPreco();
        viagem0.setTempo((double) (byte) -1);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertTrue(d8 == 0.0d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Coordenada coordenada6 = viagem5.getcfinal();
        double d7 = viagem5.getDesvio();
        java.util.GregorianCalendar gregorianCalendar8 = viagem5.getData();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(viagem5);
        org.junit.Assert.assertNotNull(coordenada6);
        org.junit.Assert.assertTrue(d7 == 0.0d);
        org.junit.Assert.assertNotNull(gregorianCalendar8);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Coordenada coordenada5 = viagem0.getcfinal();
        double d6 = viagem0.getTempo();
        Viagem viagem7 = new Viagem(viagem0);
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        double d10 = viagem0.getTempo();
        double d11 = viagem0.getTempo();
        java.util.GregorianCalendar gregorianCalendar12 = viagem0.getData();
        Viagem viagem13 = viagem0.clone();
        Viagem viagem14 = new Viagem(viagem0);
        Viagem viagem15 = new Viagem(viagem0);
        double d16 = viagem15.getPreco();
        java.lang.String str17 = viagem15.toString();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(d6 == 10.0d);
        org.junit.Assert.assertTrue(d10 == 10.0d);
        org.junit.Assert.assertTrue(d11 == 10.0d);
        org.junit.Assert.assertNotNull(gregorianCalendar12);
        org.junit.Assert.assertNotNull(viagem13);
        org.junit.Assert.assertTrue(d16 == 0.0d);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str17.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        double d3 = viagem2.getDesvio();
        Viagem viagem4 = viagem2.clone();
        double d5 = viagem2.getPreco();
        Viagem viagem6 = new Viagem();
        java.lang.String str7 = viagem6.toString();
        Viagem viagem8 = viagem6.clone();
        java.lang.String str9 = viagem8.getMail();
        Viagem viagem10 = new Viagem();
        java.lang.String str11 = viagem10.toString();
        Viagem viagem12 = viagem10.clone();
        Coordenada coordenada13 = viagem10.getcinicial();
        viagem8.setcfinal(coordenada13);
        double d15 = viagem8.getDesvio();
        Viagem viagem16 = new Viagem();
        java.lang.String str17 = viagem16.toString();
        Viagem viagem18 = viagem16.clone();
        Coordenada coordenada19 = viagem16.getcinicial();
        java.lang.Object obj20 = null;
        boolean b21 = viagem16.equals(obj20);
        int i22 = viagem8.compareTo(viagem16);
        double d23 = viagem16.getDesvio();
        boolean b24 = viagem2.equals((java.lang.Object) viagem16);
        java.util.GregorianCalendar gregorianCalendar25 = viagem16.getData();
        Viagem viagem26 = viagem16.clone();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertTrue(d3 == 0.0d);
        org.junit.Assert.assertNotNull(viagem4);
        org.junit.Assert.assertTrue(d5 == 0.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str7.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str11.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem12);
        org.junit.Assert.assertNotNull(coordenada13);
        org.junit.Assert.assertTrue(d15 == 0.0d);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str17.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem18);
        org.junit.Assert.assertNotNull(coordenada19);
        org.junit.Assert.assertTrue(b21 == false);
        org.junit.Assert.assertTrue(i22 == (-1));
        org.junit.Assert.assertTrue(d23 == 0.0d);
        org.junit.Assert.assertTrue(b24 == false);
        org.junit.Assert.assertNotNull(gregorianCalendar25);
        org.junit.Assert.assertNotNull(viagem26);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Viagem viagem6 = new Viagem(viagem0);
        Viagem viagem7 = viagem0.clone();
        Viagem viagem8 = new Viagem();
        viagem8.setTempo(10.0d);
        boolean b12 = viagem8.equals((java.lang.Object) 100L);
        double d13 = viagem8.getTempo();
        viagem8.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem16 = new Viagem(viagem8);
        Viagem viagem17 = viagem16.clone();
        Coordenada coordenada18 = viagem17.getcfinal();
        Viagem viagem19 = new Viagem();
        viagem19.setTempo(10.0d);
        boolean b23 = viagem19.equals((java.lang.Object) 100L);
        double d24 = viagem19.getTempo();
        viagem19.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str27 = viagem19.toString();
        viagem19.setMail("");
        Viagem viagem30 = new Viagem(viagem19);
        int i31 = viagem17.compareTo(viagem30);
        boolean b32 = viagem0.equals((java.lang.Object) i31);
        Viagem viagem33 = viagem0.clone();
        double d34 = viagem33.getPreco();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(viagem5);
        org.junit.Assert.assertNotNull(viagem7);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertTrue(d13 == 10.0d);
        org.junit.Assert.assertNotNull(viagem17);
        org.junit.Assert.assertNotNull(coordenada18);
        org.junit.Assert.assertTrue(b23 == false);
        org.junit.Assert.assertTrue(d24 == 10.0d);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str27.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(i31 == 263);
        org.junit.Assert.assertTrue(b32 == false);
        org.junit.Assert.assertNotNull(viagem33);
        org.junit.Assert.assertTrue(d34 == 0.0d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Viagem viagem9 = viagem0.clone();
        Viagem viagem10 = new Viagem();
        viagem10.setTempo(10.0d);
        boolean b14 = viagem10.equals((java.lang.Object) 100L);
        Viagem viagem15 = viagem10.clone();
        Viagem viagem16 = new Viagem(viagem10);
        Viagem viagem17 = viagem10.clone();
        int i18 = viagem0.compareTo(viagem17);
        viagem0.setMail("");
        Coordenada coordenada21 = viagem0.getcfinal();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertNotNull(viagem9);
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertNotNull(viagem15);
        org.junit.Assert.assertNotNull(viagem17);
        org.junit.Assert.assertTrue(i18 == 263);
        org.junit.Assert.assertNotNull(coordenada21);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Coordenada coordenada5 = viagem0.getcfinal();
        double d6 = viagem0.getTempo();
        Viagem viagem7 = new Viagem(viagem0);
        Viagem viagem8 = viagem0.clone();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(d6 == 10.0d);
        org.junit.Assert.assertNotNull(viagem8);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        Coordenada coordenada3 = viagem0.getcinicial();
        Viagem viagem4 = new Viagem(viagem0);
        Coordenada coordenada5 = viagem4.getcinicial();
        Viagem viagem6 = new Viagem();
        viagem6.setTempo(10.0d);
        boolean b10 = viagem6.equals((java.lang.Object) 100L);
        Viagem viagem11 = viagem6.clone();
        Viagem viagem12 = new Viagem();
        viagem12.setTempo(10.0d);
        boolean b16 = viagem12.equals((java.lang.Object) 100L);
        double d17 = viagem12.getTempo();
        viagem12.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str20 = viagem12.toString();
        viagem12.setMail("");
        double d23 = viagem12.getDesvio();
        java.util.GregorianCalendar gregorianCalendar24 = viagem12.getData();
        int i25 = viagem11.compareTo(viagem12);
        Viagem viagem26 = new Viagem(viagem12);
        Coordenada coordenada27 = viagem12.getcinicial();
        java.util.GregorianCalendar gregorianCalendar30 = null;
        try {
            Viagem viagem33 = new Viagem(coordenada5, coordenada27, 1.0d, "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00", gregorianCalendar30, 0.0d, (double) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertNotNull(coordenada3);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertNotNull(viagem11);
        org.junit.Assert.assertTrue(b16 == false);
        org.junit.Assert.assertTrue(d17 == 10.0d);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str20.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d23 == 0.0d);
        org.junit.Assert.assertNotNull(gregorianCalendar24);
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertNotNull(coordenada27);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        double d2 = viagem0.getPreco();
        double d3 = viagem0.getDesvio();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d2 == 0.0d);
        org.junit.Assert.assertTrue(d3 == 0.0d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        double d6 = viagem0.getPreco();
        java.lang.String str7 = viagem0.getMail();
        java.lang.String str8 = viagem0.toString();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str8.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = new Viagem(viagem0);
        double d6 = viagem0.getTempo();
        double d7 = viagem0.getPreco();
        Viagem viagem8 = viagem0.clone();
        Coordenada coordenada9 = viagem0.getcfinal();
        java.util.GregorianCalendar gregorianCalendar10 = viagem0.getData();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d6 == 10.0d);
        org.junit.Assert.assertTrue(d7 == 0.0d);
        org.junit.Assert.assertNotNull(viagem8);
        org.junit.Assert.assertNotNull(coordenada9);
        org.junit.Assert.assertNotNull(gregorianCalendar10);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        viagem0.setMail("hi!");
        Coordenada coordenada4 = viagem0.getcfinal();
        viagem0.setTempo(0.0d);
        Viagem viagem7 = viagem0.clone();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(coordenada4);
        org.junit.Assert.assertNotNull(viagem7);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        Coordenada coordenada3 = viagem0.getcinicial();
        Viagem viagem4 = viagem0.clone();
        double d5 = viagem0.getDesvio();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertNotNull(coordenada3);
        org.junit.Assert.assertNotNull(viagem4);
        org.junit.Assert.assertTrue(d5 == 0.0d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Viagem viagem6 = new Viagem(viagem0);
        Viagem viagem7 = new Viagem(viagem6);
        double d8 = viagem6.getTempo();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(viagem5);
        org.junit.Assert.assertTrue(d8 == 10.0d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        java.util.GregorianCalendar gregorianCalendar5 = viagem0.getData();
        Coordenada coordenada6 = viagem0.getcinicial();
        Viagem viagem7 = new Viagem();
        viagem7.setTempo(10.0d);
        boolean b11 = viagem7.equals((java.lang.Object) 100L);
        double d12 = viagem7.getTempo();
        viagem7.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem15 = new Viagem(viagem7);
        Viagem viagem16 = viagem15.clone();
        Coordenada coordenada17 = viagem16.getcfinal();
        boolean b18 = viagem0.equals((java.lang.Object) coordenada17);
        Viagem viagem19 = viagem0.clone();
        java.lang.String str20 = viagem19.getMail();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(gregorianCalendar5);
        org.junit.Assert.assertNotNull(coordenada6);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertTrue(d12 == 10.0d);
        org.junit.Assert.assertNotNull(viagem16);
        org.junit.Assert.assertNotNull(coordenada17);
        org.junit.Assert.assertTrue(b18 == false);
        org.junit.Assert.assertNotNull(viagem19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        Coordenada coordenada3 = viagem0.getcinicial();
        Viagem viagem4 = viagem0.clone();
        Coordenada coordenada5 = viagem4.getcfinal();
        Viagem viagem6 = new Viagem(viagem4);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertNotNull(coordenada3);
        org.junit.Assert.assertNotNull(viagem4);
        org.junit.Assert.assertNotNull(coordenada5);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Viagem viagem6 = new Viagem(viagem0);
        Viagem viagem7 = viagem0.clone();
        java.lang.String str8 = viagem0.toString();
        Viagem viagem9 = new Viagem();
        viagem9.setTempo(10.0d);
        boolean b13 = viagem9.equals((java.lang.Object) 100L);
        Coordenada coordenada14 = viagem9.getcfinal();
        Viagem viagem15 = new Viagem();
        viagem15.setTempo(10.0d);
        boolean b19 = viagem15.equals((java.lang.Object) 100L);
        Viagem viagem20 = viagem15.clone();
        Coordenada coordenada21 = viagem20.getcfinal();
        viagem9.setcinicial(coordenada21);
        viagem0.setcinicial(coordenada21);
        Viagem viagem24 = new Viagem(viagem0);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(viagem5);
        org.junit.Assert.assertNotNull(viagem7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str8.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(b13 == false);
        org.junit.Assert.assertNotNull(coordenada14);
        org.junit.Assert.assertTrue(b19 == false);
        org.junit.Assert.assertNotNull(viagem20);
        org.junit.Assert.assertNotNull(coordenada21);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        java.util.GregorianCalendar gregorianCalendar5 = viagem0.getData();
        Coordenada coordenada6 = viagem0.getcinicial();
        Viagem viagem7 = new Viagem();
        viagem7.setTempo(10.0d);
        boolean b11 = viagem7.equals((java.lang.Object) 100L);
        double d12 = viagem7.getTempo();
        viagem7.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem15 = new Viagem();
        viagem15.setTempo(10.0d);
        boolean b19 = viagem15.equals((java.lang.Object) 100L);
        double d20 = viagem15.getTempo();
        viagem15.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str23 = viagem15.toString();
        viagem15.setMail("");
        double d26 = viagem15.getDesvio();
        int i27 = viagem7.compareTo(viagem15);
        Coordenada coordenada28 = viagem7.getcinicial();
        viagem0.setcinicial(coordenada28);
        double d30 = viagem0.getPreco();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(gregorianCalendar5);
        org.junit.Assert.assertNotNull(coordenada6);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertTrue(d12 == 10.0d);
        org.junit.Assert.assertTrue(b19 == false);
        org.junit.Assert.assertTrue(d20 == 10.0d);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str23.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d26 == 0.0d);
        org.junit.Assert.assertTrue(i27 == 263);
        org.junit.Assert.assertNotNull(coordenada28);
        org.junit.Assert.assertTrue(d30 == 0.0d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Coordenada coordenada5 = viagem0.getcfinal();
        double d6 = viagem0.getTempo();
        Viagem viagem7 = new Viagem(viagem0);
        viagem0.setTempo((double) (byte) 10);
        double d10 = viagem0.getTempo();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(d6 == 10.0d);
        org.junit.Assert.assertTrue(d10 == 10.0d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = new Viagem(viagem0);
        Coordenada coordenada3 = viagem2.getcinicial();
        double d4 = viagem2.getDesvio();
        Viagem viagem5 = new Viagem();
        java.lang.String str6 = viagem5.toString();
        Viagem viagem7 = viagem5.clone();
        Coordenada coordenada8 = viagem5.getcinicial();
        java.util.GregorianCalendar gregorianCalendar9 = viagem5.getData();
        boolean b10 = viagem2.equals((java.lang.Object) viagem5);
        double d11 = viagem2.getTempo();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(coordenada3);
        org.junit.Assert.assertTrue(d4 == 0.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str6.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem7);
        org.junit.Assert.assertNotNull(coordenada8);
        org.junit.Assert.assertNotNull(gregorianCalendar9);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue(d11 == 0.0d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = new Viagem(viagem0);
        java.util.GregorianCalendar gregorianCalendar6 = viagem0.getData();
        java.lang.String str7 = viagem0.toString();
        java.lang.String str8 = viagem0.getMail();
        Viagem viagem9 = new Viagem();
        viagem9.setTempo(10.0d);
        boolean b13 = viagem9.equals((java.lang.Object) 100L);
        Coordenada coordenada14 = viagem9.getcfinal();
        Viagem viagem15 = new Viagem();
        viagem15.setTempo(10.0d);
        boolean b19 = viagem15.equals((java.lang.Object) 100L);
        Viagem viagem20 = viagem15.clone();
        Coordenada coordenada21 = viagem20.getcfinal();
        viagem9.setcinicial(coordenada21);
        viagem0.setcfinal(coordenada21);
        java.util.GregorianCalendar gregorianCalendar24 = viagem0.getData();
        Viagem viagem25 = viagem0.clone();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(gregorianCalendar6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str7.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue(b13 == false);
        org.junit.Assert.assertNotNull(coordenada14);
        org.junit.Assert.assertTrue(b19 == false);
        org.junit.Assert.assertNotNull(viagem20);
        org.junit.Assert.assertNotNull(coordenada21);
        org.junit.Assert.assertNotNull(gregorianCalendar24);
        org.junit.Assert.assertNotNull(viagem25);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        Coordenada coordenada3 = viagem0.getcinicial();
        Viagem viagem4 = new Viagem(viagem0);
        Viagem viagem5 = new Viagem(viagem0);
        java.lang.String str6 = viagem5.getMail();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertNotNull(coordenada3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Viagem viagem6 = new Viagem(viagem0);
        Viagem viagem7 = viagem6.clone();
        double d8 = viagem7.getTempo();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(viagem5);
        org.junit.Assert.assertNotNull(viagem7);
        org.junit.Assert.assertTrue(d8 == 10.0d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = new Viagem(viagem0);
        Viagem viagem6 = viagem5.clone();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(viagem6);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        java.lang.String str3 = viagem2.getMail();
        Viagem viagem4 = new Viagem();
        java.lang.String str5 = viagem4.toString();
        Viagem viagem6 = viagem4.clone();
        Coordenada coordenada7 = viagem4.getcinicial();
        viagem2.setcfinal(coordenada7);
        double d9 = viagem2.getDesvio();
        Viagem viagem10 = new Viagem();
        java.lang.String str11 = viagem10.toString();
        Viagem viagem12 = viagem10.clone();
        Coordenada coordenada13 = viagem10.getcinicial();
        java.lang.Object obj14 = null;
        boolean b15 = viagem10.equals(obj14);
        int i16 = viagem2.compareTo(viagem10);
        Viagem viagem17 = viagem10.clone();
        viagem10.setTempo((double) (short) 0);
        viagem10.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem22 = new Viagem(viagem10);
        Viagem viagem23 = null;
        try {
            int i24 = viagem22.compareTo(viagem23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str5.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem6);
        org.junit.Assert.assertNotNull(coordenada7);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str11.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem12);
        org.junit.Assert.assertNotNull(coordenada13);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertTrue(i16 == (-1));
        org.junit.Assert.assertNotNull(viagem17);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Coordenada coordenada5 = viagem0.getcfinal();
        double d6 = viagem0.getTempo();
        Viagem viagem7 = new Viagem(viagem0);
        viagem0.setTempo((double) (byte) 10);
        Viagem viagem10 = new Viagem(viagem0);
        Coordenada coordenada11 = viagem0.getcfinal();
        Viagem viagem12 = viagem0.clone();
        Coordenada coordenada13 = viagem12.getcinicial();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(d6 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada11);
        org.junit.Assert.assertNotNull(viagem12);
        org.junit.Assert.assertNotNull(coordenada13);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = new Viagem(viagem0);
        java.util.GregorianCalendar gregorianCalendar6 = viagem0.getData();
        java.lang.String str7 = viagem0.toString();
        java.lang.String str8 = viagem0.getMail();
        Viagem viagem9 = new Viagem();
        viagem9.setTempo(10.0d);
        boolean b13 = viagem9.equals((java.lang.Object) 100L);
        Coordenada coordenada14 = viagem9.getcfinal();
        Viagem viagem15 = new Viagem();
        viagem15.setTempo(10.0d);
        boolean b19 = viagem15.equals((java.lang.Object) 100L);
        Viagem viagem20 = viagem15.clone();
        Coordenada coordenada21 = viagem20.getcfinal();
        viagem9.setcinicial(coordenada21);
        viagem0.setcfinal(coordenada21);
        double d24 = viagem0.getTempo();
        Coordenada coordenada25 = viagem0.getcfinal();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(gregorianCalendar6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str7.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue(b13 == false);
        org.junit.Assert.assertNotNull(coordenada14);
        org.junit.Assert.assertTrue(b19 == false);
        org.junit.Assert.assertNotNull(viagem20);
        org.junit.Assert.assertNotNull(coordenada21);
        org.junit.Assert.assertTrue(d24 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada25);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        double d8 = viagem0.getPreco();
        Viagem viagem9 = new Viagem();
        viagem9.setTempo(10.0d);
        boolean b13 = viagem9.equals((java.lang.Object) 100L);
        Coordenada coordenada14 = viagem9.getcfinal();
        double d15 = viagem9.getTempo();
        double d16 = viagem9.getDesvio();
        boolean b17 = viagem0.equals((java.lang.Object) d16);
        Viagem viagem18 = new Viagem();
        viagem18.setTempo(10.0d);
        boolean b22 = viagem18.equals((java.lang.Object) 100L);
        Viagem viagem23 = viagem18.clone();
        Viagem viagem24 = new Viagem(viagem18);
        Viagem viagem25 = new Viagem();
        viagem25.setTempo(10.0d);
        boolean b29 = viagem25.equals((java.lang.Object) 100L);
        Viagem viagem30 = viagem25.clone();
        Viagem viagem31 = new Viagem(viagem25);
        int i32 = viagem18.compareTo(viagem25);
        double d33 = viagem25.getTempo();
        Viagem viagem34 = viagem25.clone();
        Viagem viagem35 = viagem25.clone();
        Viagem viagem36 = new Viagem(viagem35);
        int i37 = viagem0.compareTo(viagem35);
        Coordenada coordenada38 = viagem0.getcinicial();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertTrue(d8 == 0.0d);
        org.junit.Assert.assertTrue(b13 == false);
        org.junit.Assert.assertNotNull(coordenada14);
        org.junit.Assert.assertTrue(d15 == 10.0d);
        org.junit.Assert.assertTrue(d16 == 0.0d);
        org.junit.Assert.assertTrue(b17 == false);
        org.junit.Assert.assertTrue(b22 == false);
        org.junit.Assert.assertNotNull(viagem23);
        org.junit.Assert.assertTrue(b29 == false);
        org.junit.Assert.assertNotNull(viagem30);
        org.junit.Assert.assertTrue(i32 == (-1));
        org.junit.Assert.assertTrue(d33 == 10.0d);
        org.junit.Assert.assertNotNull(viagem34);
        org.junit.Assert.assertNotNull(viagem35);
        org.junit.Assert.assertTrue(i37 == 263);
        org.junit.Assert.assertNotNull(coordenada38);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        java.util.GregorianCalendar gregorianCalendar5 = viagem0.getData();
        double d6 = viagem0.getTempo();
        Viagem viagem7 = new Viagem();
        viagem7.setTempo(10.0d);
        boolean b11 = viagem7.equals((java.lang.Object) 100L);
        Viagem viagem12 = viagem7.clone();
        Viagem viagem13 = new Viagem();
        viagem13.setTempo(10.0d);
        boolean b17 = viagem13.equals((java.lang.Object) 100L);
        double d18 = viagem13.getTempo();
        viagem13.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str21 = viagem13.toString();
        viagem13.setMail("");
        double d24 = viagem13.getDesvio();
        java.util.GregorianCalendar gregorianCalendar25 = viagem13.getData();
        int i26 = viagem12.compareTo(viagem13);
        Viagem viagem27 = new Viagem();
        viagem27.setTempo(10.0d);
        boolean b31 = viagem27.equals((java.lang.Object) 100L);
        double d32 = viagem27.getTempo();
        double d33 = viagem27.getPreco();
        Viagem viagem34 = new Viagem();
        viagem34.setTempo(10.0d);
        boolean b38 = viagem34.equals((java.lang.Object) 100L);
        Viagem viagem39 = viagem34.clone();
        boolean b40 = viagem27.equals((java.lang.Object) viagem39);
        Viagem viagem41 = new Viagem();
        viagem41.setTempo(10.0d);
        boolean b45 = viagem41.equals((java.lang.Object) 100L);
        double d46 = viagem41.getTempo();
        viagem41.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str49 = viagem41.toString();
        viagem41.setMail("");
        Coordenada coordenada52 = viagem41.getcinicial();
        viagem27.setcinicial(coordenada52);
        Viagem viagem54 = new Viagem();
        viagem54.setTempo(10.0d);
        boolean b58 = viagem54.equals((java.lang.Object) 100L);
        Viagem viagem59 = viagem54.clone();
        int i60 = viagem27.compareTo(viagem59);
        boolean b61 = viagem12.equals((java.lang.Object) viagem59);
        int i62 = viagem0.compareTo(viagem12);
        double d63 = viagem12.getDesvio();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(gregorianCalendar5);
        org.junit.Assert.assertTrue(d6 == 10.0d);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertNotNull(viagem12);
        org.junit.Assert.assertTrue(b17 == false);
        org.junit.Assert.assertTrue(d18 == 10.0d);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str21.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d24 == 0.0d);
        org.junit.Assert.assertNotNull(gregorianCalendar25);
        org.junit.Assert.assertTrue(i26 == 0);
        org.junit.Assert.assertTrue(b31 == false);
        org.junit.Assert.assertTrue(d32 == 10.0d);
        org.junit.Assert.assertTrue(d33 == 0.0d);
        org.junit.Assert.assertTrue(b38 == false);
        org.junit.Assert.assertNotNull(viagem39);
        org.junit.Assert.assertTrue(b40 == true);
        org.junit.Assert.assertTrue(b45 == false);
        org.junit.Assert.assertTrue(d46 == 10.0d);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str49.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(coordenada52);
        org.junit.Assert.assertTrue(b58 == false);
        org.junit.Assert.assertNotNull(viagem59);
        org.junit.Assert.assertTrue(i60 == (-1));
        org.junit.Assert.assertTrue(b61 == false);
        org.junit.Assert.assertTrue(i62 == (-1));
        org.junit.Assert.assertTrue(d63 == 0.0d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Viagem viagem6 = new Viagem(viagem0);
        Viagem viagem7 = new Viagem();
        viagem7.setTempo(10.0d);
        boolean b11 = viagem7.equals((java.lang.Object) 100L);
        Viagem viagem12 = viagem7.clone();
        Viagem viagem13 = new Viagem(viagem7);
        int i14 = viagem0.compareTo(viagem7);
        double d15 = viagem7.getTempo();
        Viagem viagem16 = viagem7.clone();
        double d17 = viagem7.getTempo();
        java.lang.String str18 = viagem7.getMail();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(viagem5);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertNotNull(viagem12);
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(d15 == 10.0d);
        org.junit.Assert.assertNotNull(viagem16);
        org.junit.Assert.assertTrue(d17 == 10.0d);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Coordenada coordenada5 = viagem0.getcfinal();
        double d6 = viagem0.getTempo();
        Viagem viagem7 = new Viagem(viagem0);
        Viagem viagem8 = viagem7.clone();
        double d9 = viagem8.getPreco();
        double d10 = viagem8.getTempo();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(d6 == 10.0d);
        org.junit.Assert.assertNotNull(viagem8);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue(d10 == 10.0d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem();
        viagem8.setTempo(10.0d);
        boolean b12 = viagem8.equals((java.lang.Object) 100L);
        double d13 = viagem8.getTempo();
        viagem8.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str16 = viagem8.toString();
        viagem8.setMail("");
        double d19 = viagem8.getDesvio();
        int i20 = viagem0.compareTo(viagem8);
        Viagem viagem21 = new Viagem(viagem0);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertTrue(d13 == 10.0d);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str16.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d19 == 0.0d);
        org.junit.Assert.assertTrue(i20 == 263);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = new Viagem(viagem0);
        java.lang.String str6 = viagem0.getMail();
        double d7 = viagem0.getPreco();
        double d8 = viagem0.getPreco();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue(d7 == 0.0d);
        org.junit.Assert.assertTrue(d8 == 0.0d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        java.lang.String str3 = viagem2.getMail();
        Viagem viagem4 = new Viagem();
        java.lang.String str5 = viagem4.toString();
        Viagem viagem6 = viagem4.clone();
        Coordenada coordenada7 = viagem4.getcinicial();
        viagem2.setcfinal(coordenada7);
        double d9 = viagem2.getDesvio();
        Viagem viagem10 = new Viagem();
        java.lang.String str11 = viagem10.toString();
        Viagem viagem12 = viagem10.clone();
        Coordenada coordenada13 = viagem10.getcinicial();
        java.lang.Object obj14 = null;
        boolean b15 = viagem10.equals(obj14);
        int i16 = viagem2.compareTo(viagem10);
        Viagem viagem17 = viagem10.clone();
        Viagem viagem18 = viagem17.clone();
        Viagem viagem19 = new Viagem();
        java.lang.String str20 = viagem19.toString();
        double d21 = viagem19.getPreco();
        Coordenada coordenada22 = viagem19.getcfinal();
        viagem19.setMail("hi!");
        java.lang.String str25 = viagem19.getMail();
        int i26 = viagem17.compareTo(viagem19);
        Coordenada coordenada27 = viagem19.getcinicial();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str5.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem6);
        org.junit.Assert.assertNotNull(coordenada7);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str11.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem12);
        org.junit.Assert.assertNotNull(coordenada13);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertTrue(i16 == (-1));
        org.junit.Assert.assertNotNull(viagem17);
        org.junit.Assert.assertNotNull(viagem18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str20.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d21 == 0.0d);
        org.junit.Assert.assertNotNull(coordenada22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
        org.junit.Assert.assertTrue(i26 == (-3));
        org.junit.Assert.assertNotNull(coordenada27);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Coordenada coordenada5 = viagem0.getcfinal();
        double d6 = viagem0.getTempo();
        Viagem viagem7 = new Viagem(viagem0);
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        double d10 = viagem0.getTempo();
        double d11 = viagem0.getTempo();
        java.util.GregorianCalendar gregorianCalendar12 = viagem0.getData();
        Viagem viagem13 = viagem0.clone();
        Viagem viagem14 = new Viagem(viagem0);
        Viagem viagem15 = new Viagem(viagem0);
        double d16 = viagem15.getPreco();
        Viagem viagem17 = new Viagem();
        viagem17.setTempo(10.0d);
        boolean b21 = viagem17.equals((java.lang.Object) 100L);
        double d22 = viagem17.getTempo();
        viagem17.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.util.GregorianCalendar gregorianCalendar25 = viagem17.getData();
        Viagem viagem26 = new Viagem();
        viagem26.setTempo(10.0d);
        boolean b30 = viagem26.equals((java.lang.Object) 100L);
        double d31 = viagem26.getTempo();
        Viagem viagem32 = new Viagem();
        viagem32.setTempo(10.0d);
        boolean b36 = viagem32.equals((java.lang.Object) 100L);
        double d37 = viagem32.getTempo();
        viagem32.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Coordenada coordenada40 = viagem32.getcfinal();
        viagem26.setcinicial(coordenada40);
        viagem17.setcinicial(coordenada40);
        viagem15.setcfinal(coordenada40);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(d6 == 10.0d);
        org.junit.Assert.assertTrue(d10 == 10.0d);
        org.junit.Assert.assertTrue(d11 == 10.0d);
        org.junit.Assert.assertNotNull(gregorianCalendar12);
        org.junit.Assert.assertNotNull(viagem13);
        org.junit.Assert.assertTrue(d16 == 0.0d);
        org.junit.Assert.assertTrue(b21 == false);
        org.junit.Assert.assertTrue(d22 == 10.0d);
        org.junit.Assert.assertNotNull(gregorianCalendar25);
        org.junit.Assert.assertTrue(b30 == false);
        org.junit.Assert.assertTrue(d31 == 10.0d);
        org.junit.Assert.assertTrue(b36 == false);
        org.junit.Assert.assertTrue(d37 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada40);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Viagem viagem6 = new Viagem(viagem0);
        Viagem viagem7 = viagem0.clone();
        Viagem viagem8 = new Viagem();
        viagem8.setTempo(10.0d);
        boolean b12 = viagem8.equals((java.lang.Object) 100L);
        double d13 = viagem8.getTempo();
        viagem8.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem16 = new Viagem(viagem8);
        Viagem viagem17 = viagem16.clone();
        Coordenada coordenada18 = viagem17.getcfinal();
        Viagem viagem19 = new Viagem();
        viagem19.setTempo(10.0d);
        boolean b23 = viagem19.equals((java.lang.Object) 100L);
        double d24 = viagem19.getTempo();
        viagem19.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str27 = viagem19.toString();
        viagem19.setMail("");
        Viagem viagem30 = new Viagem(viagem19);
        int i31 = viagem17.compareTo(viagem30);
        boolean b32 = viagem0.equals((java.lang.Object) i31);
        Viagem viagem33 = new Viagem(viagem0);
        java.util.GregorianCalendar gregorianCalendar34 = viagem0.getData();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(viagem5);
        org.junit.Assert.assertNotNull(viagem7);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertTrue(d13 == 10.0d);
        org.junit.Assert.assertNotNull(viagem17);
        org.junit.Assert.assertNotNull(coordenada18);
        org.junit.Assert.assertTrue(b23 == false);
        org.junit.Assert.assertTrue(d24 == 10.0d);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str27.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(i31 == 263);
        org.junit.Assert.assertTrue(b32 == false);
        org.junit.Assert.assertNotNull(gregorianCalendar34);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Viagem viagem9 = viagem8.clone();
        Coordenada coordenada10 = viagem9.getcfinal();
        Viagem viagem11 = new Viagem();
        viagem11.setTempo(10.0d);
        boolean b15 = viagem11.equals((java.lang.Object) 100L);
        double d16 = viagem11.getTempo();
        viagem11.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str19 = viagem11.toString();
        viagem11.setMail("");
        Viagem viagem22 = new Viagem(viagem11);
        int i23 = viagem9.compareTo(viagem22);
        double d24 = viagem9.getDesvio();
        Viagem viagem25 = new Viagem();
        viagem25.setTempo(10.0d);
        boolean b29 = viagem25.equals((java.lang.Object) 100L);
        Viagem viagem30 = viagem25.clone();
        Viagem viagem31 = new Viagem(viagem25);
        Viagem viagem32 = viagem25.clone();
        Viagem viagem33 = new Viagem();
        viagem33.setTempo(10.0d);
        boolean b37 = viagem33.equals((java.lang.Object) 100L);
        double d38 = viagem33.getTempo();
        viagem33.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem41 = new Viagem(viagem33);
        Viagem viagem42 = viagem41.clone();
        Coordenada coordenada43 = viagem42.getcfinal();
        Viagem viagem44 = new Viagem();
        viagem44.setTempo(10.0d);
        boolean b48 = viagem44.equals((java.lang.Object) 100L);
        double d49 = viagem44.getTempo();
        viagem44.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str52 = viagem44.toString();
        viagem44.setMail("");
        Viagem viagem55 = new Viagem(viagem44);
        int i56 = viagem42.compareTo(viagem55);
        boolean b57 = viagem25.equals((java.lang.Object) i56);
        Viagem viagem58 = new Viagem(viagem25);
        int i59 = viagem9.compareTo(viagem25);
        java.lang.String str60 = viagem9.toString();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertNotNull(viagem9);
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertTrue(d16 == 10.0d);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str19.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(i23 == 263);
        org.junit.Assert.assertTrue(d24 == 0.0d);
        org.junit.Assert.assertTrue(b29 == false);
        org.junit.Assert.assertNotNull(viagem30);
        org.junit.Assert.assertNotNull(viagem32);
        org.junit.Assert.assertTrue(b37 == false);
        org.junit.Assert.assertTrue(d38 == 10.0d);
        org.junit.Assert.assertNotNull(viagem42);
        org.junit.Assert.assertNotNull(coordenada43);
        org.junit.Assert.assertTrue(b48 == false);
        org.junit.Assert.assertTrue(d49 == 10.0d);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str52.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(i56 == 263);
        org.junit.Assert.assertTrue(b57 == false);
        org.junit.Assert.assertTrue(i59 == 263);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str60.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Viagem viagem6 = new Viagem(viagem0);
        java.util.GregorianCalendar gregorianCalendar7 = viagem6.getData();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(viagem5);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = new Viagem(viagem0);
        java.util.GregorianCalendar gregorianCalendar6 = viagem0.getData();
        java.lang.String str7 = viagem0.toString();
        java.lang.String str8 = viagem0.getMail();
        double d9 = viagem0.getTempo();
        Viagem viagem10 = new Viagem();
        viagem10.setTempo(10.0d);
        boolean b14 = viagem10.equals((java.lang.Object) 100L);
        double d15 = viagem10.getTempo();
        viagem10.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        double d18 = viagem10.getPreco();
        double d19 = viagem10.getPreco();
        Viagem viagem20 = new Viagem();
        viagem20.setTempo(10.0d);
        boolean b24 = viagem20.equals((java.lang.Object) 100L);
        Viagem viagem25 = new Viagem(viagem20);
        java.lang.String str26 = viagem20.getMail();
        Viagem viagem27 = new Viagem();
        viagem27.setTempo(10.0d);
        boolean b31 = viagem27.equals((java.lang.Object) 100L);
        Viagem viagem32 = new Viagem(viagem27);
        java.lang.String str33 = viagem27.getMail();
        boolean b34 = viagem20.equals((java.lang.Object) viagem27);
        Viagem viagem35 = new Viagem();
        viagem35.setTempo(10.0d);
        boolean b39 = viagem35.equals((java.lang.Object) 100L);
        Viagem viagem40 = viagem35.clone();
        Viagem viagem41 = new Viagem(viagem35);
        Viagem viagem42 = new Viagem();
        viagem42.setTempo(10.0d);
        boolean b46 = viagem42.equals((java.lang.Object) 100L);
        Viagem viagem47 = viagem42.clone();
        Viagem viagem48 = new Viagem(viagem42);
        int i49 = viagem35.compareTo(viagem42);
        viagem42.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        int i52 = viagem27.compareTo(viagem42);
        int i53 = viagem10.compareTo(viagem27);
        double d54 = viagem27.getTempo();
        double d55 = viagem27.getTempo();
        Coordenada coordenada56 = viagem27.getcfinal();
        viagem0.setcinicial(coordenada56);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(gregorianCalendar6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str7.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue(d9 == 10.0d);
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertTrue(d15 == 10.0d);
        org.junit.Assert.assertTrue(d18 == 0.0d);
        org.junit.Assert.assertTrue(d19 == 0.0d);
        org.junit.Assert.assertTrue(b24 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertTrue(b31 == false);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
        org.junit.Assert.assertTrue(b34 == false);
        org.junit.Assert.assertTrue(b39 == false);
        org.junit.Assert.assertNotNull(viagem40);
        org.junit.Assert.assertTrue(b46 == false);
        org.junit.Assert.assertNotNull(viagem47);
        org.junit.Assert.assertTrue(i49 == (-1));
        org.junit.Assert.assertTrue(i52 == (-266));
        org.junit.Assert.assertTrue(i53 == 263);
        org.junit.Assert.assertTrue(d54 == 10.0d);
        org.junit.Assert.assertTrue(d55 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada56);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Coordenada coordenada9 = viagem0.getcfinal();
        Viagem viagem10 = new Viagem(viagem0);
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada9);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        java.lang.String str3 = viagem0.toString();
        Viagem viagem4 = new Viagem();
        java.lang.String str5 = viagem4.toString();
        Viagem viagem6 = viagem4.clone();
        java.lang.String str7 = viagem6.getMail();
        Viagem viagem8 = new Viagem();
        java.lang.String str9 = viagem8.toString();
        Viagem viagem10 = viagem8.clone();
        Coordenada coordenada11 = viagem8.getcinicial();
        viagem6.setcfinal(coordenada11);
        double d13 = viagem6.getDesvio();
        viagem6.setMail("hi!");
        java.lang.String str16 = viagem6.toString();
        Coordenada coordenada17 = viagem6.getcfinal();
        boolean b18 = viagem0.equals((java.lang.Object) coordenada17);
        Viagem viagem19 = viagem0.clone();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str3.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str5.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str9.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem10);
        org.junit.Assert.assertNotNull(coordenada11);
        org.junit.Assert.assertTrue(d13 == 0.0d);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str16.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(coordenada17);
        org.junit.Assert.assertTrue(b18 == false);
        org.junit.Assert.assertNotNull(viagem19);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getDesvio();
        double d6 = viagem0.getDesvio();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 0.0d);
        org.junit.Assert.assertTrue(d6 == 0.0d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Coordenada coordenada6 = viagem5.getcfinal();
        java.util.GregorianCalendar gregorianCalendar7 = viagem5.getData();
        Coordenada coordenada8 = viagem5.getcinicial();
        double d9 = viagem5.getPreco();
        Coordenada coordenada10 = viagem5.getcinicial();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(viagem5);
        org.junit.Assert.assertNotNull(coordenada6);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
        org.junit.Assert.assertNotNull(coordenada8);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertNotNull(coordenada10);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Coordenada coordenada9 = viagem0.getcfinal();
        Viagem viagem10 = new Viagem(viagem0);
        java.lang.String str11 = viagem0.toString();
        double d12 = viagem0.getDesvio();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str11.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d12 == 0.0d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Coordenada coordenada5 = viagem0.getcfinal();
        double d6 = viagem0.getTempo();
        Viagem viagem7 = new Viagem(viagem0);
        viagem0.setTempo((double) (byte) 10);
        Viagem viagem10 = new Viagem(viagem0);
        Viagem viagem11 = viagem10.clone();
        double d12 = viagem10.getDesvio();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(d6 == 10.0d);
        org.junit.Assert.assertNotNull(viagem11);
        org.junit.Assert.assertTrue(d12 == 0.0d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Viagem viagem6 = new Viagem(viagem0);
        Viagem viagem7 = viagem0.clone();
        Viagem viagem8 = new Viagem();
        viagem8.setTempo(10.0d);
        boolean b12 = viagem8.equals((java.lang.Object) 100L);
        double d13 = viagem8.getTempo();
        viagem8.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem16 = new Viagem(viagem8);
        Viagem viagem17 = viagem16.clone();
        Coordenada coordenada18 = viagem17.getcfinal();
        Viagem viagem19 = new Viagem();
        viagem19.setTempo(10.0d);
        boolean b23 = viagem19.equals((java.lang.Object) 100L);
        double d24 = viagem19.getTempo();
        viagem19.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str27 = viagem19.toString();
        viagem19.setMail("");
        Viagem viagem30 = new Viagem(viagem19);
        int i31 = viagem17.compareTo(viagem30);
        boolean b32 = viagem0.equals((java.lang.Object) i31);
        Coordenada coordenada33 = viagem0.getcinicial();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(viagem5);
        org.junit.Assert.assertNotNull(viagem7);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertTrue(d13 == 10.0d);
        org.junit.Assert.assertNotNull(viagem17);
        org.junit.Assert.assertNotNull(coordenada18);
        org.junit.Assert.assertTrue(b23 == false);
        org.junit.Assert.assertTrue(d24 == 10.0d);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str27.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(i31 == 263);
        org.junit.Assert.assertTrue(b32 == false);
        org.junit.Assert.assertNotNull(coordenada33);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Viagem viagem6 = new Viagem(viagem0);
        Viagem viagem7 = viagem0.clone();
        Viagem viagem8 = new Viagem();
        viagem8.setTempo(10.0d);
        boolean b12 = viagem8.equals((java.lang.Object) 100L);
        double d13 = viagem8.getTempo();
        viagem8.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem16 = new Viagem(viagem8);
        Viagem viagem17 = viagem16.clone();
        Coordenada coordenada18 = viagem17.getcfinal();
        Viagem viagem19 = new Viagem();
        viagem19.setTempo(10.0d);
        boolean b23 = viagem19.equals((java.lang.Object) 100L);
        double d24 = viagem19.getTempo();
        viagem19.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str27 = viagem19.toString();
        viagem19.setMail("");
        Viagem viagem30 = new Viagem(viagem19);
        int i31 = viagem17.compareTo(viagem30);
        boolean b32 = viagem0.equals((java.lang.Object) i31);
        Viagem viagem33 = viagem0.clone();
        double d34 = viagem33.getTempo();
        double d35 = viagem33.getTempo();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(viagem5);
        org.junit.Assert.assertNotNull(viagem7);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertTrue(d13 == 10.0d);
        org.junit.Assert.assertNotNull(viagem17);
        org.junit.Assert.assertNotNull(coordenada18);
        org.junit.Assert.assertTrue(b23 == false);
        org.junit.Assert.assertTrue(d24 == 10.0d);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str27.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(i31 == 263);
        org.junit.Assert.assertTrue(b32 == false);
        org.junit.Assert.assertNotNull(viagem33);
        org.junit.Assert.assertTrue(d34 == 10.0d);
        org.junit.Assert.assertTrue(d35 == 10.0d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str8 = viagem0.toString();
        viagem0.setMail("");
        double d11 = viagem0.getTempo();
        Viagem viagem12 = new Viagem();
        viagem12.setTempo(10.0d);
        boolean b16 = viagem12.equals((java.lang.Object) 100L);
        Coordenada coordenada17 = viagem12.getcfinal();
        double d18 = viagem12.getTempo();
        Viagem viagem19 = new Viagem(viagem12);
        viagem12.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        double d22 = viagem12.getTempo();
        int i23 = viagem0.compareTo(viagem12);
        viagem0.setMail("");
        double d26 = viagem0.getTempo();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str8.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d11 == 10.0d);
        org.junit.Assert.assertTrue(b16 == false);
        org.junit.Assert.assertNotNull(coordenada17);
        org.junit.Assert.assertTrue(d18 == 10.0d);
        org.junit.Assert.assertTrue(d22 == 10.0d);
        org.junit.Assert.assertTrue(i23 == (-527));
        org.junit.Assert.assertTrue(d26 == 10.0d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        Coordenada coordenada3 = viagem0.getcinicial();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Coordenada coordenada6 = viagem0.getcinicial();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertNotNull(coordenada3);
        org.junit.Assert.assertNotNull(coordenada6);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Viagem viagem6 = new Viagem();
        viagem6.setTempo(10.0d);
        boolean b10 = viagem6.equals((java.lang.Object) 100L);
        double d11 = viagem6.getTempo();
        viagem6.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem14 = new Viagem(viagem6);
        Viagem viagem15 = viagem14.clone();
        Coordenada coordenada16 = viagem15.getcfinal();
        Viagem viagem17 = new Viagem();
        viagem17.setTempo(10.0d);
        boolean b21 = viagem17.equals((java.lang.Object) 100L);
        double d22 = viagem17.getTempo();
        viagem17.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str25 = viagem17.toString();
        viagem17.setMail("");
        Viagem viagem28 = new Viagem(viagem17);
        int i29 = viagem15.compareTo(viagem28);
        Coordenada coordenada30 = viagem15.getcfinal();
        int i31 = viagem5.compareTo(viagem15);
        Coordenada coordenada32 = viagem5.getcfinal();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(viagem5);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue(d11 == 10.0d);
        org.junit.Assert.assertNotNull(viagem15);
        org.junit.Assert.assertNotNull(coordenada16);
        org.junit.Assert.assertTrue(b21 == false);
        org.junit.Assert.assertTrue(d22 == 10.0d);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str25.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(i29 == 263);
        org.junit.Assert.assertNotNull(coordenada30);
        org.junit.Assert.assertTrue(i31 == (-263));
        org.junit.Assert.assertNotNull(coordenada32);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem();
        viagem8.setTempo(10.0d);
        boolean b12 = viagem8.equals((java.lang.Object) 100L);
        double d13 = viagem8.getTempo();
        viagem8.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str16 = viagem8.toString();
        viagem8.setMail("");
        double d19 = viagem8.getDesvio();
        int i20 = viagem0.compareTo(viagem8);
        double d21 = viagem0.getPreco();
        double d22 = viagem0.getDesvio();
        viagem0.setMail("hi!");
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertTrue(d13 == 10.0d);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str16.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d19 == 0.0d);
        org.junit.Assert.assertTrue(i20 == 263);
        org.junit.Assert.assertTrue(d21 == 0.0d);
        org.junit.Assert.assertTrue(d22 == 0.0d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        java.lang.String str3 = viagem2.getMail();
        Viagem viagem4 = new Viagem();
        java.lang.String str5 = viagem4.toString();
        Viagem viagem6 = viagem4.clone();
        Coordenada coordenada7 = viagem4.getcinicial();
        viagem2.setcfinal(coordenada7);
        double d9 = viagem2.getDesvio();
        viagem2.setMail("hi!");
        java.lang.String str12 = viagem2.toString();
        java.lang.String str13 = viagem2.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str5.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem6);
        org.junit.Assert.assertNotNull(coordenada7);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str12.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str13.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = new Viagem(viagem0);
        Coordenada coordenada3 = viagem2.getcinicial();
        Coordenada coordenada4 = viagem2.getcfinal();
        java.lang.String str5 = viagem2.toString();
        Coordenada coordenada6 = viagem2.getcfinal();
        double d7 = viagem2.getPreco();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(coordenada3);
        org.junit.Assert.assertNotNull(coordenada4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str5.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(coordenada6);
        org.junit.Assert.assertTrue(d7 == 0.0d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        Coordenada coordenada3 = viagem0.getcinicial();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.util.GregorianCalendar gregorianCalendar6 = viagem0.getData();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertNotNull(coordenada3);
        org.junit.Assert.assertNotNull(gregorianCalendar6);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        Coordenada coordenada6 = viagem0.getcfinal();
        Viagem viagem7 = new Viagem();
        viagem7.setTempo(10.0d);
        boolean b11 = viagem7.equals((java.lang.Object) 100L);
        java.util.GregorianCalendar gregorianCalendar12 = viagem7.getData();
        Coordenada coordenada13 = viagem7.getcinicial();
        Viagem viagem14 = new Viagem();
        viagem14.setTempo(10.0d);
        boolean b18 = viagem14.equals((java.lang.Object) 100L);
        double d19 = viagem14.getTempo();
        viagem14.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem22 = new Viagem();
        viagem22.setTempo(10.0d);
        boolean b26 = viagem22.equals((java.lang.Object) 100L);
        double d27 = viagem22.getTempo();
        viagem22.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str30 = viagem22.toString();
        viagem22.setMail("");
        double d33 = viagem22.getDesvio();
        int i34 = viagem14.compareTo(viagem22);
        Coordenada coordenada35 = viagem14.getcinicial();
        viagem7.setcinicial(coordenada35);
        viagem0.setcinicial(coordenada35);
        java.util.GregorianCalendar gregorianCalendar38 = viagem0.getData();
        java.util.GregorianCalendar gregorianCalendar39 = viagem0.getData();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada6);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertNotNull(gregorianCalendar12);
        org.junit.Assert.assertNotNull(coordenada13);
        org.junit.Assert.assertTrue(b18 == false);
        org.junit.Assert.assertTrue(d19 == 10.0d);
        org.junit.Assert.assertTrue(b26 == false);
        org.junit.Assert.assertTrue(d27 == 10.0d);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str30.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d33 == 0.0d);
        org.junit.Assert.assertTrue(i34 == 263);
        org.junit.Assert.assertNotNull(coordenada35);
        org.junit.Assert.assertNotNull(gregorianCalendar38);
        org.junit.Assert.assertNotNull(gregorianCalendar39);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str8 = viagem0.toString();
        viagem0.setMail("");
        double d11 = viagem0.getDesvio();
        double d12 = viagem0.getPreco();
        Coordenada coordenada13 = viagem0.getcfinal();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str8.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d11 == 0.0d);
        org.junit.Assert.assertTrue(d12 == 0.0d);
        org.junit.Assert.assertNotNull(coordenada13);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Viagem viagem6 = new Viagem(viagem0);
        Viagem viagem7 = new Viagem();
        viagem7.setTempo(10.0d);
        boolean b11 = viagem7.equals((java.lang.Object) 100L);
        Viagem viagem12 = viagem7.clone();
        Viagem viagem13 = new Viagem(viagem7);
        int i14 = viagem0.compareTo(viagem7);
        double d15 = viagem7.getTempo();
        Viagem viagem16 = new Viagem(viagem7);
        Viagem viagem17 = new Viagem(viagem7);
        Viagem viagem18 = new Viagem();
        viagem18.setTempo(10.0d);
        boolean b22 = viagem18.equals((java.lang.Object) 100L);
        Viagem viagem23 = viagem18.clone();
        Viagem viagem24 = new Viagem(viagem18);
        Viagem viagem25 = new Viagem();
        viagem25.setTempo(10.0d);
        boolean b29 = viagem25.equals((java.lang.Object) 100L);
        Viagem viagem30 = viagem25.clone();
        Viagem viagem31 = new Viagem(viagem25);
        int i32 = viagem18.compareTo(viagem25);
        Coordenada coordenada33 = viagem25.getcinicial();
        viagem17.setcfinal(coordenada33);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(viagem5);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertNotNull(viagem12);
        org.junit.Assert.assertTrue(i14 == (-1));
        org.junit.Assert.assertTrue(d15 == 10.0d);
        org.junit.Assert.assertTrue(b22 == false);
        org.junit.Assert.assertNotNull(viagem23);
        org.junit.Assert.assertTrue(b29 == false);
        org.junit.Assert.assertNotNull(viagem30);
        org.junit.Assert.assertTrue(i32 == (-1));
        org.junit.Assert.assertNotNull(coordenada33);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem();
        viagem8.setTempo(10.0d);
        boolean b12 = viagem8.equals((java.lang.Object) 100L);
        double d13 = viagem8.getTempo();
        viagem8.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str16 = viagem8.toString();
        viagem8.setMail("");
        double d19 = viagem8.getDesvio();
        int i20 = viagem0.compareTo(viagem8);
        Viagem viagem21 = viagem0.clone();
        double d22 = viagem0.getPreco();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertTrue(d13 == 10.0d);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str16.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d19 == 0.0d);
        org.junit.Assert.assertTrue(i20 == 263);
        org.junit.Assert.assertNotNull(viagem21);
        org.junit.Assert.assertTrue(d22 == 0.0d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        double d2 = viagem0.getPreco();
        double d3 = viagem0.getPreco();
        viagem0.setTempo(100.0d);
        Viagem viagem6 = viagem0.clone();
        java.lang.String str7 = viagem6.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d2 == 0.0d);
        org.junit.Assert.assertTrue(d3 == 0.0d);
        org.junit.Assert.assertNotNull(viagem6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 100.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str7.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 100.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Viagem viagem6 = new Viagem(viagem0);
        Viagem viagem7 = viagem0.clone();
        Viagem viagem8 = new Viagem();
        viagem8.setTempo(10.0d);
        boolean b12 = viagem8.equals((java.lang.Object) 100L);
        double d13 = viagem8.getTempo();
        viagem8.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem16 = new Viagem(viagem8);
        Viagem viagem17 = viagem16.clone();
        Coordenada coordenada18 = viagem17.getcfinal();
        Viagem viagem19 = new Viagem();
        viagem19.setTempo(10.0d);
        boolean b23 = viagem19.equals((java.lang.Object) 100L);
        double d24 = viagem19.getTempo();
        viagem19.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str27 = viagem19.toString();
        viagem19.setMail("");
        Viagem viagem30 = new Viagem(viagem19);
        int i31 = viagem17.compareTo(viagem30);
        boolean b32 = viagem0.equals((java.lang.Object) i31);
        Viagem viagem33 = new Viagem(viagem0);
        Coordenada coordenada34 = viagem33.getcinicial();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(viagem5);
        org.junit.Assert.assertNotNull(viagem7);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertTrue(d13 == 10.0d);
        org.junit.Assert.assertNotNull(viagem17);
        org.junit.Assert.assertNotNull(coordenada18);
        org.junit.Assert.assertTrue(b23 == false);
        org.junit.Assert.assertTrue(d24 == 10.0d);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str27.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(i31 == 263);
        org.junit.Assert.assertTrue(b32 == false);
        org.junit.Assert.assertNotNull(coordenada34);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem();
        viagem8.setTempo(10.0d);
        boolean b12 = viagem8.equals((java.lang.Object) 100L);
        double d13 = viagem8.getTempo();
        viagem8.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str16 = viagem8.toString();
        viagem8.setMail("");
        double d19 = viagem8.getDesvio();
        int i20 = viagem0.compareTo(viagem8);
        double d21 = viagem0.getPreco();
        double d22 = viagem0.getDesvio();
        double d23 = viagem0.getTempo();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertTrue(d13 == 10.0d);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str16.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d19 == 0.0d);
        org.junit.Assert.assertTrue(i20 == 263);
        org.junit.Assert.assertTrue(d21 == 0.0d);
        org.junit.Assert.assertTrue(d22 == 0.0d);
        org.junit.Assert.assertTrue(d23 == 10.0d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = new Viagem(viagem0);
        java.util.GregorianCalendar gregorianCalendar6 = viagem0.getData();
        java.lang.String str7 = viagem0.toString();
        java.lang.String str8 = viagem0.getMail();
        double d9 = viagem0.getTempo();
        Viagem viagem10 = new Viagem(viagem0);
        java.lang.String str11 = viagem10.getMail();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(gregorianCalendar6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str7.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue(d9 == 10.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Viagem viagem9 = viagem8.clone();
        Coordenada coordenada10 = viagem9.getcfinal();
        Viagem viagem11 = new Viagem();
        viagem11.setTempo(10.0d);
        boolean b15 = viagem11.equals((java.lang.Object) 100L);
        double d16 = viagem11.getTempo();
        viagem11.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str19 = viagem11.toString();
        viagem11.setMail("");
        Viagem viagem22 = new Viagem(viagem11);
        int i23 = viagem9.compareTo(viagem22);
        java.lang.String str24 = viagem22.getMail();
        Viagem viagem25 = new Viagem(viagem22);
        Viagem viagem26 = new Viagem(viagem25);
        java.lang.String str27 = viagem25.getMail();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertNotNull(viagem9);
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertTrue(d16 == 10.0d);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str19.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(i23 == 263);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Viagem viagem6 = new Viagem(viagem0);
        Viagem viagem7 = viagem0.clone();
        Viagem viagem8 = new Viagem();
        viagem8.setTempo(10.0d);
        boolean b12 = viagem8.equals((java.lang.Object) 100L);
        double d13 = viagem8.getTempo();
        viagem8.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem16 = new Viagem(viagem8);
        Viagem viagem17 = viagem16.clone();
        Coordenada coordenada18 = viagem17.getcfinal();
        Viagem viagem19 = new Viagem();
        viagem19.setTempo(10.0d);
        boolean b23 = viagem19.equals((java.lang.Object) 100L);
        double d24 = viagem19.getTempo();
        viagem19.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str27 = viagem19.toString();
        viagem19.setMail("");
        Viagem viagem30 = new Viagem(viagem19);
        int i31 = viagem17.compareTo(viagem30);
        boolean b32 = viagem0.equals((java.lang.Object) i31);
        Viagem viagem33 = new Viagem(viagem0);
        Coordenada coordenada34 = viagem0.getcinicial();
        Viagem viagem35 = new Viagem();
        viagem35.setTempo(10.0d);
        boolean b39 = viagem35.equals((java.lang.Object) 100L);
        Viagem viagem40 = viagem35.clone();
        Viagem viagem41 = new Viagem(viagem35);
        Viagem viagem42 = viagem35.clone();
        Viagem viagem43 = new Viagem();
        viagem43.setTempo(10.0d);
        boolean b47 = viagem43.equals((java.lang.Object) 100L);
        double d48 = viagem43.getTempo();
        viagem43.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem51 = new Viagem(viagem43);
        Viagem viagem52 = viagem51.clone();
        Coordenada coordenada53 = viagem52.getcfinal();
        Viagem viagem54 = new Viagem();
        viagem54.setTempo(10.0d);
        boolean b58 = viagem54.equals((java.lang.Object) 100L);
        double d59 = viagem54.getTempo();
        viagem54.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str62 = viagem54.toString();
        viagem54.setMail("");
        Viagem viagem65 = new Viagem(viagem54);
        int i66 = viagem52.compareTo(viagem65);
        boolean b67 = viagem35.equals((java.lang.Object) i66);
        Viagem viagem68 = new Viagem(viagem35);
        Viagem viagem69 = new Viagem();
        viagem69.setTempo(10.0d);
        boolean b73 = viagem69.equals((java.lang.Object) 100L);
        Viagem viagem74 = new Viagem(viagem69);
        java.lang.String str75 = viagem69.getMail();
        Viagem viagem76 = new Viagem();
        viagem76.setTempo(10.0d);
        boolean b80 = viagem76.equals((java.lang.Object) 100L);
        Viagem viagem81 = new Viagem(viagem76);
        java.lang.String str82 = viagem76.getMail();
        boolean b83 = viagem69.equals((java.lang.Object) viagem76);
        Viagem viagem84 = new Viagem();
        viagem84.setTempo(10.0d);
        boolean b88 = viagem84.equals((java.lang.Object) 100L);
        Viagem viagem89 = new Viagem(viagem84);
        java.util.GregorianCalendar gregorianCalendar90 = viagem84.getData();
        java.lang.String str91 = viagem84.toString();
        double d92 = viagem84.getPreco();
        Coordenada coordenada93 = viagem84.getcinicial();
        viagem76.setcfinal(coordenada93);
        viagem68.setcfinal(coordenada93);
        viagem0.setcfinal(coordenada93);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(viagem5);
        org.junit.Assert.assertNotNull(viagem7);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertTrue(d13 == 10.0d);
        org.junit.Assert.assertNotNull(viagem17);
        org.junit.Assert.assertNotNull(coordenada18);
        org.junit.Assert.assertTrue(b23 == false);
        org.junit.Assert.assertTrue(d24 == 10.0d);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str27.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(i31 == 263);
        org.junit.Assert.assertTrue(b32 == false);
        org.junit.Assert.assertNotNull(coordenada34);
        org.junit.Assert.assertTrue(b39 == false);
        org.junit.Assert.assertNotNull(viagem40);
        org.junit.Assert.assertNotNull(viagem42);
        org.junit.Assert.assertTrue(b47 == false);
        org.junit.Assert.assertTrue(d48 == 10.0d);
        org.junit.Assert.assertNotNull(viagem52);
        org.junit.Assert.assertNotNull(coordenada53);
        org.junit.Assert.assertTrue(b58 == false);
        org.junit.Assert.assertTrue(d59 == 10.0d);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str62.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(i66 == 263);
        org.junit.Assert.assertTrue(b67 == false);
        org.junit.Assert.assertTrue(b73 == false);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "" + "'", str75.equals(""));
        org.junit.Assert.assertTrue(b80 == false);
        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "" + "'", str82.equals(""));
        org.junit.Assert.assertTrue(b83 == true);
        org.junit.Assert.assertTrue(b88 == false);
        org.junit.Assert.assertNotNull(gregorianCalendar90);
        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str91.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d92 == 0.0d);
        org.junit.Assert.assertNotNull(coordenada93);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = new Viagem(viagem0);
        double d6 = viagem0.getTempo();
        double d7 = viagem0.getPreco();
        double d8 = viagem0.getPreco();
        double d9 = viagem0.getDesvio();
        Coordenada coordenada10 = viagem0.getcinicial();
        java.lang.String str11 = viagem0.toString();
        Viagem viagem12 = new Viagem();
        viagem12.setTempo(10.0d);
        boolean b16 = viagem12.equals((java.lang.Object) 100L);
        Viagem viagem17 = viagem12.clone();
        Viagem viagem18 = new Viagem(viagem12);
        Viagem viagem19 = new Viagem();
        viagem19.setTempo(10.0d);
        boolean b23 = viagem19.equals((java.lang.Object) 100L);
        Viagem viagem24 = viagem19.clone();
        Viagem viagem25 = new Viagem(viagem19);
        int i26 = viagem12.compareTo(viagem19);
        double d27 = viagem19.getTempo();
        Viagem viagem28 = viagem19.clone();
        Viagem viagem29 = viagem19.clone();
        Viagem viagem30 = new Viagem(viagem29);
        int i31 = viagem0.compareTo(viagem30);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d6 == 10.0d);
        org.junit.Assert.assertTrue(d7 == 0.0d);
        org.junit.Assert.assertTrue(d8 == 0.0d);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str11.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(b16 == false);
        org.junit.Assert.assertNotNull(viagem17);
        org.junit.Assert.assertTrue(b23 == false);
        org.junit.Assert.assertNotNull(viagem24);
        org.junit.Assert.assertTrue(i26 == (-1));
        org.junit.Assert.assertTrue(d27 == 10.0d);
        org.junit.Assert.assertNotNull(viagem28);
        org.junit.Assert.assertNotNull(viagem29);
        org.junit.Assert.assertTrue(i31 == (-1));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        double d3 = viagem2.getDesvio();
        Viagem viagem4 = viagem2.clone();
        double d5 = viagem2.getPreco();
        double d6 = viagem2.getTempo();
        Viagem viagem7 = new Viagem(viagem2);
        java.util.GregorianCalendar gregorianCalendar8 = viagem2.getData();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertTrue(d3 == 0.0d);
        org.junit.Assert.assertNotNull(viagem4);
        org.junit.Assert.assertTrue(d5 == 0.0d);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertNotNull(gregorianCalendar8);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = new Viagem(viagem0);
        java.util.GregorianCalendar gregorianCalendar6 = viagem0.getData();
        java.lang.String str7 = viagem0.toString();
        java.lang.String str8 = viagem0.getMail();
        double d9 = viagem0.getTempo();
        boolean b11 = viagem0.equals((java.lang.Object) 10L);
        java.util.GregorianCalendar gregorianCalendar12 = viagem0.getData();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(gregorianCalendar6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str7.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue(d9 == 10.0d);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertNotNull(gregorianCalendar12);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Viagem viagem6 = new Viagem(viagem0);
        Viagem viagem7 = viagem0.clone();
        Viagem viagem8 = new Viagem();
        viagem8.setTempo(10.0d);
        boolean b12 = viagem8.equals((java.lang.Object) 100L);
        double d13 = viagem8.getTempo();
        viagem8.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem16 = new Viagem(viagem8);
        Viagem viagem17 = viagem16.clone();
        Coordenada coordenada18 = viagem17.getcfinal();
        Viagem viagem19 = new Viagem();
        viagem19.setTempo(10.0d);
        boolean b23 = viagem19.equals((java.lang.Object) 100L);
        double d24 = viagem19.getTempo();
        viagem19.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str27 = viagem19.toString();
        viagem19.setMail("");
        Viagem viagem30 = new Viagem(viagem19);
        int i31 = viagem17.compareTo(viagem30);
        boolean b32 = viagem0.equals((java.lang.Object) i31);
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        double d35 = viagem0.getDesvio();
        Viagem viagem36 = new Viagem();
        viagem36.setTempo(10.0d);
        boolean b40 = viagem36.equals((java.lang.Object) 100L);
        Viagem viagem41 = viagem36.clone();
        Viagem viagem42 = new Viagem();
        viagem42.setTempo(10.0d);
        boolean b46 = viagem42.equals((java.lang.Object) 100L);
        double d47 = viagem42.getTempo();
        viagem42.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str50 = viagem42.toString();
        viagem42.setMail("");
        double d53 = viagem42.getDesvio();
        java.util.GregorianCalendar gregorianCalendar54 = viagem42.getData();
        int i55 = viagem41.compareTo(viagem42);
        Viagem viagem56 = viagem41.clone();
        Coordenada coordenada57 = viagem41.getcinicial();
        viagem0.setcinicial(coordenada57);
        double d59 = viagem0.getTempo();
        Viagem viagem60 = new Viagem();
        viagem60.setTempo(10.0d);
        boolean b64 = viagem60.equals((java.lang.Object) 100L);
        double d65 = viagem60.getTempo();
        viagem60.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem68 = new Viagem(viagem60);
        Viagem viagem69 = viagem68.clone();
        int i70 = viagem0.compareTo(viagem68);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(viagem5);
        org.junit.Assert.assertNotNull(viagem7);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertTrue(d13 == 10.0d);
        org.junit.Assert.assertNotNull(viagem17);
        org.junit.Assert.assertNotNull(coordenada18);
        org.junit.Assert.assertTrue(b23 == false);
        org.junit.Assert.assertTrue(d24 == 10.0d);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str27.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(i31 == 263);
        org.junit.Assert.assertTrue(b32 == false);
        org.junit.Assert.assertTrue(d35 == 0.0d);
        org.junit.Assert.assertTrue(b40 == false);
        org.junit.Assert.assertNotNull(viagem41);
        org.junit.Assert.assertTrue(b46 == false);
        org.junit.Assert.assertTrue(d47 == 10.0d);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str50.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d53 == 0.0d);
        org.junit.Assert.assertNotNull(gregorianCalendar54);
        org.junit.Assert.assertTrue(i55 == (-1));
        org.junit.Assert.assertNotNull(viagem56);
        org.junit.Assert.assertNotNull(coordenada57);
        org.junit.Assert.assertTrue(d59 == 10.0d);
        org.junit.Assert.assertTrue(b64 == false);
        org.junit.Assert.assertTrue(d65 == 10.0d);
        org.junit.Assert.assertNotNull(viagem69);
        org.junit.Assert.assertTrue(i70 == 57);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = new Viagem(viagem0);
        double d6 = viagem0.getTempo();
        double d7 = viagem0.getPreco();
        Viagem viagem8 = viagem0.clone();
        Coordenada coordenada9 = viagem8.getcfinal();
        Viagem viagem10 = new Viagem();
        viagem10.setTempo(10.0d);
        boolean b14 = viagem10.equals((java.lang.Object) 100L);
        double d15 = viagem10.getTempo();
        viagem10.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem18 = new Viagem(viagem10);
        Viagem viagem19 = viagem18.clone();
        Coordenada coordenada20 = viagem19.getcfinal();
        Viagem viagem21 = new Viagem();
        viagem21.setTempo(10.0d);
        boolean b25 = viagem21.equals((java.lang.Object) 100L);
        double d26 = viagem21.getTempo();
        viagem21.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str29 = viagem21.toString();
        viagem21.setMail("");
        Viagem viagem32 = new Viagem(viagem21);
        int i33 = viagem19.compareTo(viagem32);
        double d34 = viagem19.getDesvio();
        java.lang.String str35 = viagem19.toString();
        int i36 = viagem8.compareTo(viagem19);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d6 == 10.0d);
        org.junit.Assert.assertTrue(d7 == 0.0d);
        org.junit.Assert.assertNotNull(viagem8);
        org.junit.Assert.assertNotNull(coordenada9);
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertTrue(d15 == 10.0d);
        org.junit.Assert.assertNotNull(viagem19);
        org.junit.Assert.assertNotNull(coordenada20);
        org.junit.Assert.assertTrue(b25 == false);
        org.junit.Assert.assertTrue(d26 == 10.0d);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str29.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(i33 == 263);
        org.junit.Assert.assertTrue(d34 == 0.0d);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str35.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(i36 == (-263));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        java.util.GregorianCalendar gregorianCalendar9 = viagem0.getData();
        Viagem viagem10 = new Viagem();
        viagem10.setTempo(10.0d);
        boolean b14 = viagem10.equals((java.lang.Object) 100L);
        Viagem viagem15 = viagem10.clone();
        Viagem viagem16 = new Viagem(viagem10);
        Viagem viagem17 = viagem10.clone();
        double d18 = viagem17.getPreco();
        Coordenada coordenada19 = viagem17.getcinicial();
        viagem0.setcfinal(coordenada19);
        Viagem viagem21 = new Viagem();
        viagem21.setTempo(10.0d);
        boolean b25 = viagem21.equals((java.lang.Object) 100L);
        Viagem viagem26 = viagem21.clone();
        Viagem viagem27 = new Viagem(viagem21);
        Viagem viagem28 = new Viagem();
        viagem28.setTempo(10.0d);
        boolean b32 = viagem28.equals((java.lang.Object) 100L);
        Viagem viagem33 = viagem28.clone();
        Viagem viagem34 = new Viagem(viagem28);
        int i35 = viagem21.compareTo(viagem28);
        viagem28.setMail("");
        Viagem viagem38 = viagem28.clone();
        boolean b39 = viagem0.equals((java.lang.Object) viagem38);
        Coordenada coordenada40 = viagem38.getcinicial();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertNotNull(gregorianCalendar9);
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertNotNull(viagem15);
        org.junit.Assert.assertNotNull(viagem17);
        org.junit.Assert.assertTrue(d18 == 0.0d);
        org.junit.Assert.assertNotNull(coordenada19);
        org.junit.Assert.assertTrue(b25 == false);
        org.junit.Assert.assertNotNull(viagem26);
        org.junit.Assert.assertTrue(b32 == false);
        org.junit.Assert.assertNotNull(viagem33);
        org.junit.Assert.assertTrue(i35 == (-1));
        org.junit.Assert.assertNotNull(viagem38);
        org.junit.Assert.assertTrue(b39 == false);
        org.junit.Assert.assertNotNull(coordenada40);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Viagem viagem9 = viagem8.clone();
        Coordenada coordenada10 = viagem9.getcfinal();
        Viagem viagem11 = new Viagem();
        viagem11.setTempo(10.0d);
        boolean b15 = viagem11.equals((java.lang.Object) 100L);
        double d16 = viagem11.getTempo();
        viagem11.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str19 = viagem11.toString();
        viagem11.setMail("");
        Viagem viagem22 = new Viagem(viagem11);
        int i23 = viagem9.compareTo(viagem22);
        double d24 = viagem9.getDesvio();
        java.lang.String str25 = viagem9.toString();
        Viagem viagem26 = viagem9.clone();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertNotNull(viagem9);
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertTrue(d16 == 10.0d);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str19.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(i23 == 263);
        org.junit.Assert.assertTrue(d24 == 0.0d);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str25.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem26);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Coordenada coordenada8 = viagem0.getcfinal();
        java.util.GregorianCalendar gregorianCalendar9 = viagem0.getData();
        double d10 = viagem0.getTempo();
        Coordenada coordenada11 = viagem0.getcfinal();
        Coordenada coordenada12 = null;
        Viagem viagem15 = new Viagem();
        java.lang.String str16 = viagem15.toString();
        Viagem viagem17 = viagem15.clone();
        java.lang.String str18 = viagem17.getMail();
        Viagem viagem19 = new Viagem();
        java.lang.String str20 = viagem19.toString();
        Viagem viagem21 = viagem19.clone();
        Coordenada coordenada22 = viagem19.getcinicial();
        viagem17.setcfinal(coordenada22);
        double d24 = viagem17.getDesvio();
        viagem17.setMail("hi!");
        java.lang.String str27 = viagem17.toString();
        java.util.GregorianCalendar gregorianCalendar28 = viagem17.getData();
        try {
            Viagem viagem31 = new Viagem(coordenada11, coordenada12, (double) (short) 0, "", gregorianCalendar28, (double) 100L, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada8);
        org.junit.Assert.assertNotNull(gregorianCalendar9);
        org.junit.Assert.assertTrue(d10 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada11);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str16.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str20.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem21);
        org.junit.Assert.assertNotNull(coordenada22);
        org.junit.Assert.assertTrue(d24 == 0.0d);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str27.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(gregorianCalendar28);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Viagem viagem6 = new Viagem(viagem0);
        Viagem viagem7 = viagem0.clone();
        java.lang.String str8 = viagem0.toString();
        double d9 = viagem0.getPreco();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(viagem5);
        org.junit.Assert.assertNotNull(viagem7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str8.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d9 == 0.0d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Coordenada coordenada5 = viagem0.getcfinal();
        Coordenada coordenada6 = viagem0.getcinicial();
        Coordenada coordenada7 = viagem0.getcinicial();
        Viagem viagem8 = new Viagem();
        viagem8.setTempo(10.0d);
        boolean b12 = viagem8.equals((java.lang.Object) 100L);
        Coordenada coordenada13 = viagem8.getcfinal();
        double d14 = viagem8.getTempo();
        Viagem viagem15 = new Viagem(viagem8);
        Coordenada coordenada16 = viagem8.getcfinal();
        Viagem viagem19 = new Viagem();
        viagem19.setTempo(10.0d);
        boolean b23 = viagem19.equals((java.lang.Object) 100L);
        Viagem viagem24 = viagem19.clone();
        Coordenada coordenada25 = viagem24.getcfinal();
        java.util.GregorianCalendar gregorianCalendar26 = viagem24.getData();
        Viagem viagem29 = new Viagem(coordenada7, coordenada16, (double) (short) 10, "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: -1.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00", gregorianCalendar26, (double) (byte) 10, (double) (short) -1);
        Coordenada coordenada30 = viagem29.getcinicial();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertNotNull(coordenada6);
        org.junit.Assert.assertNotNull(coordenada7);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertNotNull(coordenada13);
        org.junit.Assert.assertTrue(d14 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada16);
        org.junit.Assert.assertTrue(b23 == false);
        org.junit.Assert.assertNotNull(viagem24);
        org.junit.Assert.assertNotNull(coordenada25);
        org.junit.Assert.assertNotNull(gregorianCalendar26);
        org.junit.Assert.assertNotNull(coordenada30);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Viagem viagem9 = viagem8.clone();
        Coordenada coordenada10 = viagem9.getcfinal();
        Viagem viagem11 = new Viagem();
        viagem11.setTempo(10.0d);
        boolean b15 = viagem11.equals((java.lang.Object) 100L);
        double d16 = viagem11.getTempo();
        viagem11.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str19 = viagem11.toString();
        viagem11.setMail("");
        Viagem viagem22 = new Viagem(viagem11);
        int i23 = viagem9.compareTo(viagem22);
        java.lang.String str24 = viagem22.getMail();
        Viagem viagem25 = new Viagem(viagem22);
        Viagem viagem26 = new Viagem();
        viagem26.setTempo(10.0d);
        boolean b30 = viagem26.equals((java.lang.Object) 100L);
        Viagem viagem31 = new Viagem(viagem26);
        java.lang.String str32 = viagem26.getMail();
        int i33 = viagem22.compareTo(viagem26);
        viagem26.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Coordenada coordenada36 = viagem26.getcfinal();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertNotNull(viagem9);
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertTrue(d16 == 10.0d);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str19.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(i23 == 263);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertTrue(b30 == false);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "" + "'", str32.equals(""));
        org.junit.Assert.assertTrue(i33 == (-1));
        org.junit.Assert.assertNotNull(coordenada36);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        double d6 = viagem0.getPreco();
        Viagem viagem7 = new Viagem(viagem0);
        Viagem viagem8 = new Viagem(viagem0);
        viagem8.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem11 = new Viagem();
        viagem11.setTempo(10.0d);
        boolean b15 = viagem11.equals((java.lang.Object) 100L);
        double d16 = viagem11.getTempo();
        viagem11.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem19 = new Viagem(viagem11);
        Viagem viagem20 = viagem19.clone();
        Coordenada coordenada21 = viagem20.getcfinal();
        Viagem viagem22 = new Viagem();
        viagem22.setTempo(10.0d);
        boolean b26 = viagem22.equals((java.lang.Object) 100L);
        double d27 = viagem22.getTempo();
        viagem22.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str30 = viagem22.toString();
        viagem22.setMail("");
        Viagem viagem33 = new Viagem(viagem22);
        int i34 = viagem20.compareTo(viagem33);
        java.lang.String str35 = viagem33.getMail();
        Viagem viagem36 = new Viagem(viagem33);
        Viagem viagem37 = new Viagem(viagem36);
        viagem37.setMail("hi!");
        boolean b40 = viagem8.equals((java.lang.Object) "hi!");
        java.lang.String str41 = viagem8.toString();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertTrue(d16 == 10.0d);
        org.junit.Assert.assertNotNull(viagem20);
        org.junit.Assert.assertNotNull(coordenada21);
        org.junit.Assert.assertTrue(b26 == false);
        org.junit.Assert.assertTrue(d27 == 10.0d);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str30.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(i34 == 263);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "" + "'", str35.equals(""));
        org.junit.Assert.assertTrue(b40 == false);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str41.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        double d2 = viagem0.getPreco();
        Coordenada coordenada3 = viagem0.getcfinal();
        double d4 = viagem0.getDesvio();
        double d5 = viagem0.getTempo();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d2 == 0.0d);
        org.junit.Assert.assertNotNull(coordenada3);
        org.junit.Assert.assertTrue(d4 == 0.0d);
        org.junit.Assert.assertTrue(d5 == 0.0d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem();
        viagem8.setTempo(10.0d);
        boolean b12 = viagem8.equals((java.lang.Object) 100L);
        double d13 = viagem8.getTempo();
        viagem8.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str16 = viagem8.toString();
        viagem8.setMail("");
        double d19 = viagem8.getDesvio();
        int i20 = viagem0.compareTo(viagem8);
        double d21 = viagem0.getPreco();
        Viagem viagem22 = new Viagem();
        viagem22.setTempo(10.0d);
        boolean b26 = viagem22.equals((java.lang.Object) 100L);
        double d27 = viagem22.getTempo();
        viagem22.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str30 = viagem22.toString();
        viagem22.setMail("");
        Coordenada coordenada33 = viagem22.getcinicial();
        viagem0.setcinicial(coordenada33);
        java.lang.String str35 = viagem0.toString();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertTrue(d13 == 10.0d);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str16.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d19 == 0.0d);
        org.junit.Assert.assertTrue(i20 == 263);
        org.junit.Assert.assertTrue(d21 == 0.0d);
        org.junit.Assert.assertTrue(b26 == false);
        org.junit.Assert.assertTrue(d27 == 10.0d);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str30.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(coordenada33);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str35.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        java.lang.String str3 = viagem2.getMail();
        Viagem viagem4 = new Viagem();
        java.lang.String str5 = viagem4.toString();
        Viagem viagem6 = viagem4.clone();
        Coordenada coordenada7 = viagem4.getcinicial();
        viagem2.setcfinal(coordenada7);
        double d9 = viagem2.getDesvio();
        Viagem viagem10 = new Viagem();
        java.lang.String str11 = viagem10.toString();
        Viagem viagem12 = viagem10.clone();
        Coordenada coordenada13 = viagem10.getcinicial();
        java.lang.Object obj14 = null;
        boolean b15 = viagem10.equals(obj14);
        int i16 = viagem2.compareTo(viagem10);
        Viagem viagem17 = viagem10.clone();
        Viagem viagem18 = new Viagem();
        java.lang.String str19 = viagem18.toString();
        Viagem viagem20 = viagem18.clone();
        Coordenada coordenada21 = viagem18.getcfinal();
        viagem10.setcinicial(coordenada21);
        double d23 = viagem10.getPreco();
        double d24 = viagem10.getTempo();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str5.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem6);
        org.junit.Assert.assertNotNull(coordenada7);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str11.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem12);
        org.junit.Assert.assertNotNull(coordenada13);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertTrue(i16 == (-1));
        org.junit.Assert.assertNotNull(viagem17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str19.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem20);
        org.junit.Assert.assertNotNull(coordenada21);
        org.junit.Assert.assertTrue(d23 == 0.0d);
        org.junit.Assert.assertTrue(d24 == 0.0d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = new Viagem(viagem0);
        java.lang.String str6 = viagem0.getMail();
        double d7 = viagem0.getPreco();
        viagem0.setMail("");
        boolean b11 = viagem0.equals((java.lang.Object) "");
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue(d7 == 0.0d);
        org.junit.Assert.assertTrue(b11 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Coordenada coordenada9 = viagem0.getcfinal();
        viagem0.setMail("hi!");
        java.lang.String str12 = viagem0.getMail();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        Coordenada coordenada3 = viagem0.getcfinal();
        java.lang.String str4 = viagem0.getMail();
        double d5 = viagem0.getTempo();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertNotNull(coordenada3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue(d5 == 0.0d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str8 = viagem0.toString();
        viagem0.setMail("");
        Viagem viagem11 = new Viagem(viagem0);
        Viagem viagem12 = new Viagem();
        viagem12.setTempo(10.0d);
        boolean b16 = viagem12.equals((java.lang.Object) 100L);
        double d17 = viagem12.getTempo();
        viagem12.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem20 = new Viagem(viagem12);
        java.util.GregorianCalendar gregorianCalendar21 = viagem12.getData();
        Viagem viagem22 = new Viagem();
        viagem22.setTempo(10.0d);
        boolean b26 = viagem22.equals((java.lang.Object) 100L);
        Viagem viagem27 = viagem22.clone();
        Viagem viagem28 = new Viagem(viagem22);
        Viagem viagem29 = viagem22.clone();
        double d30 = viagem29.getPreco();
        Coordenada coordenada31 = viagem29.getcinicial();
        viagem12.setcfinal(coordenada31);
        Viagem viagem33 = new Viagem();
        viagem33.setTempo(10.0d);
        boolean b37 = viagem33.equals((java.lang.Object) 100L);
        Viagem viagem38 = viagem33.clone();
        Viagem viagem39 = new Viagem(viagem33);
        Viagem viagem40 = new Viagem();
        viagem40.setTempo(10.0d);
        boolean b44 = viagem40.equals((java.lang.Object) 100L);
        Viagem viagem45 = viagem40.clone();
        Viagem viagem46 = new Viagem(viagem40);
        int i47 = viagem33.compareTo(viagem40);
        viagem40.setMail("");
        Viagem viagem50 = viagem40.clone();
        boolean b51 = viagem12.equals((java.lang.Object) viagem50);
        java.lang.String str52 = viagem50.toString();
        Viagem viagem53 = new Viagem();
        viagem53.setTempo(10.0d);
        boolean b57 = viagem53.equals((java.lang.Object) 100L);
        double d58 = viagem53.getTempo();
        viagem53.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem61 = new Viagem();
        viagem61.setTempo(10.0d);
        boolean b65 = viagem61.equals((java.lang.Object) 100L);
        double d66 = viagem61.getTempo();
        viagem61.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str69 = viagem61.toString();
        viagem61.setMail("");
        double d72 = viagem61.getDesvio();
        int i73 = viagem53.compareTo(viagem61);
        Coordenada coordenada74 = viagem61.getcfinal();
        viagem50.setcfinal(coordenada74);
        viagem0.setcinicial(coordenada74);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str8.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(b16 == false);
        org.junit.Assert.assertTrue(d17 == 10.0d);
        org.junit.Assert.assertNotNull(gregorianCalendar21);
        org.junit.Assert.assertTrue(b26 == false);
        org.junit.Assert.assertNotNull(viagem27);
        org.junit.Assert.assertNotNull(viagem29);
        org.junit.Assert.assertTrue(d30 == 0.0d);
        org.junit.Assert.assertNotNull(coordenada31);
        org.junit.Assert.assertTrue(b37 == false);
        org.junit.Assert.assertNotNull(viagem38);
        org.junit.Assert.assertTrue(b44 == false);
        org.junit.Assert.assertNotNull(viagem45);
        org.junit.Assert.assertTrue(i47 == (-1));
        org.junit.Assert.assertNotNull(viagem50);
        org.junit.Assert.assertTrue(b51 == false);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str52.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(b57 == false);
        org.junit.Assert.assertTrue(d58 == 10.0d);
        org.junit.Assert.assertTrue(b65 == false);
        org.junit.Assert.assertTrue(d66 == 10.0d);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str69.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d72 == 0.0d);
        org.junit.Assert.assertTrue(i73 == 263);
        org.junit.Assert.assertNotNull(coordenada74);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = new Viagem(viagem0);
        Coordenada coordenada3 = viagem2.getcinicial();
        Viagem viagem4 = viagem2.clone();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(coordenada3);
        org.junit.Assert.assertNotNull(viagem4);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        viagem0.setMail("hi!");
        Coordenada coordenada4 = viagem0.getcfinal();
        double d5 = viagem0.getPreco();
        Viagem viagem6 = new Viagem();
        java.lang.String str7 = viagem6.toString();
        double d8 = viagem6.getPreco();
        Coordenada coordenada9 = viagem6.getcfinal();
        viagem6.setMail("hi!");
        int i12 = viagem0.compareTo(viagem6);
        Viagem viagem13 = new Viagem();
        java.lang.String str14 = viagem13.toString();
        Viagem viagem15 = new Viagem(viagem13);
        Coordenada coordenada16 = viagem15.getcinicial();
        Viagem viagem17 = new Viagem();
        java.lang.String str18 = viagem17.toString();
        Viagem viagem19 = viagem17.clone();
        java.lang.String str20 = viagem19.getMail();
        Viagem viagem21 = new Viagem();
        java.lang.String str22 = viagem21.toString();
        Viagem viagem23 = viagem21.clone();
        Coordenada coordenada24 = viagem21.getcinicial();
        viagem19.setcfinal(coordenada24);
        viagem15.setcfinal(coordenada24);
        viagem0.setcfinal(coordenada24);
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(coordenada4);
        org.junit.Assert.assertTrue(d5 == 0.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str7.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d8 == 0.0d);
        org.junit.Assert.assertNotNull(coordenada9);
        org.junit.Assert.assertTrue(i12 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str14.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(coordenada16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str18.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str22.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem23);
        org.junit.Assert.assertNotNull(coordenada24);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Coordenada coordenada9 = viagem0.getcfinal();
        Viagem viagem10 = new Viagem();
        viagem10.setTempo(10.0d);
        boolean b14 = viagem10.equals((java.lang.Object) 100L);
        Coordenada coordenada15 = viagem10.getcfinal();
        double d16 = viagem10.getTempo();
        Viagem viagem17 = new Viagem(viagem10);
        int i18 = viagem0.compareTo(viagem10);
        double d19 = viagem0.getPreco();
        Viagem viagem20 = new Viagem();
        viagem20.setTempo(10.0d);
        boolean b24 = viagem20.equals((java.lang.Object) 100L);
        double d25 = viagem20.getTempo();
        viagem20.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem28 = new Viagem(viagem20);
        Coordenada coordenada29 = viagem20.getcfinal();
        viagem0.setcfinal(coordenada29);
        Viagem viagem31 = viagem0.clone();
        Viagem viagem32 = viagem31.clone();
        Viagem viagem33 = new Viagem();
        viagem33.setTempo(10.0d);
        boolean b37 = viagem33.equals((java.lang.Object) 100L);
        Coordenada coordenada38 = viagem33.getcfinal();
        Viagem viagem39 = new Viagem();
        viagem39.setTempo(10.0d);
        boolean b43 = viagem39.equals((java.lang.Object) 100L);
        Viagem viagem44 = viagem39.clone();
        Coordenada coordenada45 = viagem44.getcfinal();
        viagem33.setcinicial(coordenada45);
        viagem32.setcfinal(coordenada45);
        Viagem viagem48 = new Viagem();
        viagem48.setTempo(10.0d);
        boolean b52 = viagem48.equals((java.lang.Object) 100L);
        double d53 = viagem48.getTempo();
        viagem48.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str56 = viagem48.toString();
        viagem48.setMail("");
        Viagem viagem59 = new Viagem(viagem48);
        Coordenada coordenada60 = viagem48.getcfinal();
        Coordenada coordenada61 = viagem48.getcinicial();
        viagem32.setcfinal(coordenada61);
        java.lang.String str63 = viagem32.toString();
        Coordenada coordenada64 = viagem32.getcfinal();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada9);
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertNotNull(coordenada15);
        org.junit.Assert.assertTrue(d16 == 10.0d);
        org.junit.Assert.assertTrue(i18 == 263);
        org.junit.Assert.assertTrue(d19 == 0.0d);
        org.junit.Assert.assertTrue(b24 == false);
        org.junit.Assert.assertTrue(d25 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada29);
        org.junit.Assert.assertNotNull(viagem31);
        org.junit.Assert.assertNotNull(viagem32);
        org.junit.Assert.assertTrue(b37 == false);
        org.junit.Assert.assertNotNull(coordenada38);
        org.junit.Assert.assertTrue(b43 == false);
        org.junit.Assert.assertNotNull(viagem44);
        org.junit.Assert.assertNotNull(coordenada45);
        org.junit.Assert.assertTrue(b52 == false);
        org.junit.Assert.assertTrue(d53 == 10.0d);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str56.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(coordenada60);
        org.junit.Assert.assertNotNull(coordenada61);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str63.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(coordenada64);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        double d3 = viagem0.getPreco();
        double d4 = viagem0.getPreco();
        Viagem viagem5 = new Viagem();
        java.lang.String str6 = viagem5.toString();
        Viagem viagem7 = viagem5.clone();
        java.lang.String str8 = viagem7.getMail();
        Viagem viagem9 = new Viagem();
        java.lang.String str10 = viagem9.toString();
        Viagem viagem11 = viagem9.clone();
        Coordenada coordenada12 = viagem9.getcinicial();
        viagem7.setcfinal(coordenada12);
        double d14 = viagem7.getDesvio();
        viagem7.setTempo((double) (short) 0);
        boolean b17 = viagem0.equals((java.lang.Object) viagem7);
        viagem0.setTempo((double) 0L);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertTrue(d3 == 0.0d);
        org.junit.Assert.assertTrue(d4 == 0.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str6.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str10.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem11);
        org.junit.Assert.assertNotNull(coordenada12);
        org.junit.Assert.assertTrue(d14 == 0.0d);
        org.junit.Assert.assertTrue(b17 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        java.lang.String str3 = viagem2.getMail();
        Viagem viagem4 = new Viagem();
        java.lang.String str5 = viagem4.toString();
        Viagem viagem6 = viagem4.clone();
        Coordenada coordenada7 = viagem4.getcinicial();
        viagem2.setcfinal(coordenada7);
        double d9 = viagem2.getDesvio();
        Viagem viagem10 = new Viagem();
        java.lang.String str11 = viagem10.toString();
        Viagem viagem12 = viagem10.clone();
        Coordenada coordenada13 = viagem10.getcinicial();
        java.lang.Object obj14 = null;
        boolean b15 = viagem10.equals(obj14);
        int i16 = viagem2.compareTo(viagem10);
        Viagem viagem17 = viagem10.clone();
        viagem10.setTempo((double) (short) 0);
        double d20 = viagem10.getPreco();
        viagem10.setMail("");
        Viagem viagem23 = new Viagem();
        viagem23.setTempo((double) 0.0f);
        int i26 = viagem10.compareTo(viagem23);
        double d27 = viagem23.getDesvio();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str5.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem6);
        org.junit.Assert.assertNotNull(coordenada7);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str11.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem12);
        org.junit.Assert.assertNotNull(coordenada13);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertTrue(i16 == (-1));
        org.junit.Assert.assertNotNull(viagem17);
        org.junit.Assert.assertTrue(d20 == 0.0d);
        org.junit.Assert.assertTrue(i26 == (-1));
        org.junit.Assert.assertTrue(d27 == 0.0d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Viagem viagem9 = viagem8.clone();
        Coordenada coordenada10 = viagem9.getcfinal();
        Viagem viagem11 = new Viagem();
        viagem11.setTempo(10.0d);
        boolean b15 = viagem11.equals((java.lang.Object) 100L);
        double d16 = viagem11.getTempo();
        viagem11.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str19 = viagem11.toString();
        viagem11.setMail("");
        Viagem viagem22 = new Viagem(viagem11);
        int i23 = viagem9.compareTo(viagem22);
        double d24 = viagem9.getDesvio();
        double d25 = viagem9.getPreco();
        double d26 = viagem9.getDesvio();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertNotNull(viagem9);
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertTrue(d16 == 10.0d);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str19.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(i23 == 263);
        org.junit.Assert.assertTrue(d24 == 0.0d);
        org.junit.Assert.assertTrue(d25 == 0.0d);
        org.junit.Assert.assertTrue(d26 == 0.0d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        double d6 = viagem0.getPreco();
        Viagem viagem7 = new Viagem(viagem0);
        Viagem viagem8 = new Viagem(viagem0);
        Viagem viagem9 = new Viagem(viagem8);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertTrue(d6 == 0.0d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Coordenada coordenada9 = viagem0.getcfinal();
        Viagem viagem10 = new Viagem();
        viagem10.setTempo(10.0d);
        boolean b14 = viagem10.equals((java.lang.Object) 100L);
        Coordenada coordenada15 = viagem10.getcfinal();
        double d16 = viagem10.getTempo();
        Viagem viagem17 = new Viagem(viagem10);
        int i18 = viagem0.compareTo(viagem10);
        Viagem viagem19 = viagem10.clone();
        Viagem viagem20 = new Viagem();
        viagem20.setTempo(10.0d);
        boolean b24 = viagem20.equals((java.lang.Object) 100L);
        double d25 = viagem20.getTempo();
        viagem20.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem28 = new Viagem(viagem20);
        Viagem viagem29 = viagem28.clone();
        Coordenada coordenada30 = viagem29.getcfinal();
        Viagem viagem31 = new Viagem();
        viagem31.setTempo(10.0d);
        boolean b35 = viagem31.equals((java.lang.Object) 100L);
        double d36 = viagem31.getTempo();
        viagem31.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str39 = viagem31.toString();
        viagem31.setMail("");
        Viagem viagem42 = new Viagem(viagem31);
        int i43 = viagem29.compareTo(viagem42);
        java.lang.String str44 = viagem42.getMail();
        Viagem viagem45 = new Viagem(viagem42);
        Viagem viagem46 = new Viagem(viagem42);
        boolean b47 = viagem10.equals((java.lang.Object) viagem42);
        Viagem viagem48 = new Viagem(viagem10);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada9);
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertNotNull(coordenada15);
        org.junit.Assert.assertTrue(d16 == 10.0d);
        org.junit.Assert.assertTrue(i18 == 263);
        org.junit.Assert.assertNotNull(viagem19);
        org.junit.Assert.assertTrue(b24 == false);
        org.junit.Assert.assertTrue(d25 == 10.0d);
        org.junit.Assert.assertNotNull(viagem29);
        org.junit.Assert.assertNotNull(coordenada30);
        org.junit.Assert.assertTrue(b35 == false);
        org.junit.Assert.assertTrue(d36 == 10.0d);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str39.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(i43 == 263);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "" + "'", str44.equals(""));
        org.junit.Assert.assertTrue(b47 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Viagem viagem9 = viagem8.clone();
        Coordenada coordenada10 = viagem9.getcfinal();
        Viagem viagem11 = new Viagem();
        viagem11.setTempo(10.0d);
        boolean b15 = viagem11.equals((java.lang.Object) 100L);
        double d16 = viagem11.getTempo();
        viagem11.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str19 = viagem11.toString();
        viagem11.setMail("");
        Viagem viagem22 = new Viagem(viagem11);
        int i23 = viagem9.compareTo(viagem22);
        double d24 = viagem9.getDesvio();
        Viagem viagem25 = new Viagem();
        viagem25.setTempo(10.0d);
        boolean b29 = viagem25.equals((java.lang.Object) 100L);
        Viagem viagem30 = viagem25.clone();
        Viagem viagem31 = new Viagem(viagem25);
        Viagem viagem32 = viagem25.clone();
        Viagem viagem33 = new Viagem();
        viagem33.setTempo(10.0d);
        boolean b37 = viagem33.equals((java.lang.Object) 100L);
        double d38 = viagem33.getTempo();
        viagem33.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem41 = new Viagem(viagem33);
        Viagem viagem42 = viagem41.clone();
        Coordenada coordenada43 = viagem42.getcfinal();
        Viagem viagem44 = new Viagem();
        viagem44.setTempo(10.0d);
        boolean b48 = viagem44.equals((java.lang.Object) 100L);
        double d49 = viagem44.getTempo();
        viagem44.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str52 = viagem44.toString();
        viagem44.setMail("");
        Viagem viagem55 = new Viagem(viagem44);
        int i56 = viagem42.compareTo(viagem55);
        boolean b57 = viagem25.equals((java.lang.Object) i56);
        Viagem viagem58 = new Viagem(viagem25);
        int i59 = viagem9.compareTo(viagem25);
        Viagem viagem60 = viagem9.clone();
        Viagem viagem61 = new Viagem();
        viagem61.setTempo(10.0d);
        boolean b65 = viagem61.equals((java.lang.Object) 100L);
        double d66 = viagem61.getTempo();
        viagem61.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.util.GregorianCalendar gregorianCalendar69 = viagem61.getData();
        Viagem viagem70 = new Viagem();
        viagem70.setTempo(10.0d);
        boolean b74 = viagem70.equals((java.lang.Object) 100L);
        double d75 = viagem70.getTempo();
        Viagem viagem76 = new Viagem();
        viagem76.setTempo(10.0d);
        boolean b80 = viagem76.equals((java.lang.Object) 100L);
        double d81 = viagem76.getTempo();
        viagem76.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Coordenada coordenada84 = viagem76.getcfinal();
        viagem70.setcinicial(coordenada84);
        viagem61.setcinicial(coordenada84);
        viagem9.setcinicial(coordenada84);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertNotNull(viagem9);
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertTrue(d16 == 10.0d);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str19.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(i23 == 263);
        org.junit.Assert.assertTrue(d24 == 0.0d);
        org.junit.Assert.assertTrue(b29 == false);
        org.junit.Assert.assertNotNull(viagem30);
        org.junit.Assert.assertNotNull(viagem32);
        org.junit.Assert.assertTrue(b37 == false);
        org.junit.Assert.assertTrue(d38 == 10.0d);
        org.junit.Assert.assertNotNull(viagem42);
        org.junit.Assert.assertNotNull(coordenada43);
        org.junit.Assert.assertTrue(b48 == false);
        org.junit.Assert.assertTrue(d49 == 10.0d);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str52.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(i56 == 263);
        org.junit.Assert.assertTrue(b57 == false);
        org.junit.Assert.assertTrue(i59 == 263);
        org.junit.Assert.assertNotNull(viagem60);
        org.junit.Assert.assertTrue(b65 == false);
        org.junit.Assert.assertTrue(d66 == 10.0d);
        org.junit.Assert.assertNotNull(gregorianCalendar69);
        org.junit.Assert.assertTrue(b74 == false);
        org.junit.Assert.assertTrue(d75 == 10.0d);
        org.junit.Assert.assertTrue(b80 == false);
        org.junit.Assert.assertTrue(d81 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada84);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        double d6 = viagem0.getPreco();
        Viagem viagem7 = new Viagem(viagem0);
        Viagem viagem8 = new Viagem(viagem0);
        viagem8.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem11 = new Viagem();
        viagem11.setTempo(10.0d);
        boolean b15 = viagem11.equals((java.lang.Object) 100L);
        double d16 = viagem11.getTempo();
        viagem11.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem19 = new Viagem(viagem11);
        Viagem viagem20 = viagem19.clone();
        Coordenada coordenada21 = viagem20.getcfinal();
        Viagem viagem22 = new Viagem();
        viagem22.setTempo(10.0d);
        boolean b26 = viagem22.equals((java.lang.Object) 100L);
        double d27 = viagem22.getTempo();
        viagem22.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str30 = viagem22.toString();
        viagem22.setMail("");
        Viagem viagem33 = new Viagem(viagem22);
        int i34 = viagem20.compareTo(viagem33);
        java.lang.String str35 = viagem33.getMail();
        Viagem viagem36 = new Viagem(viagem33);
        Viagem viagem37 = new Viagem(viagem36);
        viagem37.setMail("hi!");
        boolean b40 = viagem8.equals((java.lang.Object) "hi!");
        double d41 = viagem8.getTempo();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertTrue(d16 == 10.0d);
        org.junit.Assert.assertNotNull(viagem20);
        org.junit.Assert.assertNotNull(coordenada21);
        org.junit.Assert.assertTrue(b26 == false);
        org.junit.Assert.assertTrue(d27 == 10.0d);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str30.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(i34 == 263);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "" + "'", str35.equals(""));
        org.junit.Assert.assertTrue(b40 == false);
        org.junit.Assert.assertTrue(d41 == 10.0d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Viagem viagem6 = new Viagem(viagem0);
        Viagem viagem7 = viagem0.clone();
        Viagem viagem8 = new Viagem();
        viagem8.setTempo(10.0d);
        boolean b12 = viagem8.equals((java.lang.Object) 100L);
        double d13 = viagem8.getTempo();
        viagem8.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem16 = new Viagem(viagem8);
        Viagem viagem17 = viagem16.clone();
        Coordenada coordenada18 = viagem17.getcfinal();
        Viagem viagem19 = new Viagem();
        viagem19.setTempo(10.0d);
        boolean b23 = viagem19.equals((java.lang.Object) 100L);
        double d24 = viagem19.getTempo();
        viagem19.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str27 = viagem19.toString();
        viagem19.setMail("");
        Viagem viagem30 = new Viagem(viagem19);
        int i31 = viagem17.compareTo(viagem30);
        boolean b32 = viagem0.equals((java.lang.Object) i31);
        Viagem viagem33 = viagem0.clone();
        java.util.GregorianCalendar gregorianCalendar34 = viagem0.getData();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(viagem5);
        org.junit.Assert.assertNotNull(viagem7);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertTrue(d13 == 10.0d);
        org.junit.Assert.assertNotNull(viagem17);
        org.junit.Assert.assertNotNull(coordenada18);
        org.junit.Assert.assertTrue(b23 == false);
        org.junit.Assert.assertTrue(d24 == 10.0d);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str27.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(i31 == 263);
        org.junit.Assert.assertTrue(b32 == false);
        org.junit.Assert.assertNotNull(viagem33);
        org.junit.Assert.assertNotNull(gregorianCalendar34);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = new Viagem(viagem0);
        java.util.GregorianCalendar gregorianCalendar6 = viagem0.getData();
        java.lang.String str7 = viagem0.toString();
        double d8 = viagem0.getPreco();
        Coordenada coordenada9 = viagem0.getcinicial();
        double d10 = viagem0.getDesvio();
        Viagem viagem11 = new Viagem(viagem0);
        Viagem viagem12 = new Viagem();
        viagem12.setTempo(10.0d);
        boolean b16 = viagem12.equals((java.lang.Object) 100L);
        double d17 = viagem12.getTempo();
        viagem12.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str20 = viagem12.toString();
        viagem12.setMail("");
        Coordenada coordenada23 = viagem12.getcinicial();
        Coordenada coordenada24 = viagem12.getcinicial();
        boolean b25 = viagem0.equals((java.lang.Object) viagem12);
        Viagem viagem26 = new Viagem();
        viagem26.setTempo(10.0d);
        boolean b30 = viagem26.equals((java.lang.Object) 100L);
        Viagem viagem31 = viagem26.clone();
        Viagem viagem32 = new Viagem(viagem26);
        Viagem viagem33 = new Viagem();
        viagem33.setTempo(10.0d);
        boolean b37 = viagem33.equals((java.lang.Object) 100L);
        Viagem viagem38 = viagem33.clone();
        Viagem viagem39 = new Viagem(viagem33);
        int i40 = viagem26.compareTo(viagem33);
        Coordenada coordenada41 = viagem33.getcinicial();
        viagem0.setcinicial(coordenada41);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(gregorianCalendar6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str7.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d8 == 0.0d);
        org.junit.Assert.assertNotNull(coordenada9);
        org.junit.Assert.assertTrue(d10 == 0.0d);
        org.junit.Assert.assertTrue(b16 == false);
        org.junit.Assert.assertTrue(d17 == 10.0d);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str20.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(coordenada23);
        org.junit.Assert.assertNotNull(coordenada24);
        org.junit.Assert.assertTrue(b25 == false);
        org.junit.Assert.assertTrue(b30 == false);
        org.junit.Assert.assertNotNull(viagem31);
        org.junit.Assert.assertTrue(b37 == false);
        org.junit.Assert.assertNotNull(viagem38);
        org.junit.Assert.assertTrue(i40 == 0);
        org.junit.Assert.assertNotNull(coordenada41);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        double d8 = viagem0.getPreco();
        Viagem viagem9 = new Viagem();
        viagem9.setTempo(10.0d);
        boolean b13 = viagem9.equals((java.lang.Object) 100L);
        Coordenada coordenada14 = viagem9.getcfinal();
        double d15 = viagem9.getTempo();
        double d16 = viagem9.getDesvio();
        boolean b17 = viagem0.equals((java.lang.Object) d16);
        Viagem viagem18 = new Viagem();
        viagem18.setTempo(10.0d);
        boolean b22 = viagem18.equals((java.lang.Object) 100L);
        double d23 = viagem18.getTempo();
        viagem18.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem26 = new Viagem(viagem18);
        Coordenada coordenada27 = viagem18.getcfinal();
        Viagem viagem28 = new Viagem();
        viagem28.setTempo(10.0d);
        boolean b32 = viagem28.equals((java.lang.Object) 100L);
        Coordenada coordenada33 = viagem28.getcfinal();
        double d34 = viagem28.getTempo();
        Viagem viagem35 = new Viagem(viagem28);
        int i36 = viagem18.compareTo(viagem28);
        double d37 = viagem18.getDesvio();
        Viagem viagem38 = viagem18.clone();
        int i39 = viagem0.compareTo(viagem18);
        Viagem viagem40 = viagem0.clone();
        Viagem viagem41 = new Viagem(viagem40);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertTrue(d8 == 0.0d);
        org.junit.Assert.assertTrue(b13 == false);
        org.junit.Assert.assertNotNull(coordenada14);
        org.junit.Assert.assertTrue(d15 == 10.0d);
        org.junit.Assert.assertTrue(d16 == 0.0d);
        org.junit.Assert.assertTrue(b17 == false);
        org.junit.Assert.assertTrue(b22 == false);
        org.junit.Assert.assertTrue(d23 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada27);
        org.junit.Assert.assertTrue(b32 == false);
        org.junit.Assert.assertNotNull(coordenada33);
        org.junit.Assert.assertTrue(d34 == 10.0d);
        org.junit.Assert.assertTrue(i36 == 263);
        org.junit.Assert.assertTrue(d37 == 0.0d);
        org.junit.Assert.assertNotNull(viagem38);
        org.junit.Assert.assertTrue(i39 == (-1));
        org.junit.Assert.assertNotNull(viagem40);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        java.util.GregorianCalendar gregorianCalendar2 = viagem0.getData();
        double d3 = viagem0.getDesvio();
        Viagem viagem4 = new Viagem();
        java.lang.String str5 = viagem4.toString();
        Viagem viagem6 = viagem4.clone();
        Coordenada coordenada7 = viagem4.getcinicial();
        viagem0.setcfinal(coordenada7);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(gregorianCalendar2);
        org.junit.Assert.assertTrue(d3 == 0.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str5.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem6);
        org.junit.Assert.assertNotNull(coordenada7);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = new Viagem(viagem0);
        Coordenada coordenada3 = viagem2.getcinicial();
        Coordenada coordenada4 = viagem2.getcfinal();
        java.lang.String str5 = viagem2.toString();
        java.lang.String str6 = viagem2.toString();
        java.lang.String str7 = viagem2.toString();
        Coordenada coordenada8 = viagem2.getcinicial();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(coordenada3);
        org.junit.Assert.assertNotNull(coordenada4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str5.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str6.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str7.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(coordenada8);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        Viagem viagem3 = new Viagem();
        viagem3.setTempo(10.0d);
        boolean b7 = viagem3.equals((java.lang.Object) 100L);
        double d8 = viagem3.getTempo();
        double d9 = viagem3.getPreco();
        Viagem viagem10 = new Viagem(viagem3);
        int i11 = viagem0.compareTo(viagem10);
        Viagem viagem12 = new Viagem();
        viagem12.setTempo(10.0d);
        boolean b16 = viagem12.equals((java.lang.Object) 100L);
        double d17 = viagem12.getTempo();
        viagem12.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem20 = new Viagem(viagem12);
        Viagem viagem21 = viagem12.clone();
        java.lang.String str22 = viagem21.toString();
        Coordenada coordenada23 = viagem21.getcfinal();
        viagem10.setcfinal(coordenada23);
        org.junit.Assert.assertTrue(b7 == false);
        org.junit.Assert.assertTrue(d8 == 10.0d);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(b16 == false);
        org.junit.Assert.assertTrue(d17 == 10.0d);
        org.junit.Assert.assertNotNull(viagem21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str22.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(coordenada23);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Viagem viagem9 = viagem8.clone();
        Coordenada coordenada10 = viagem9.getcfinal();
        java.lang.String str11 = viagem9.toString();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertNotNull(viagem9);
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str11.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        double d2 = viagem0.getPreco();
        Coordenada coordenada3 = viagem0.getcfinal();
        viagem0.setMail("hi!");
        Viagem viagem6 = new Viagem();
        java.lang.String str7 = viagem6.toString();
        Viagem viagem8 = viagem6.clone();
        java.lang.String str9 = viagem8.getMail();
        Viagem viagem10 = new Viagem();
        java.lang.String str11 = viagem10.toString();
        Viagem viagem12 = viagem10.clone();
        Coordenada coordenada13 = viagem10.getcinicial();
        viagem8.setcfinal(coordenada13);
        viagem0.setcinicial(coordenada13);
        Viagem viagem16 = viagem0.clone();
        Coordenada coordenada17 = viagem0.getcfinal();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d2 == 0.0d);
        org.junit.Assert.assertNotNull(coordenada3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str7.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str11.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem12);
        org.junit.Assert.assertNotNull(coordenada13);
        org.junit.Assert.assertNotNull(viagem16);
        org.junit.Assert.assertNotNull(coordenada17);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Coordenada coordenada5 = viagem0.getcfinal();
        double d6 = viagem0.getTempo();
        Viagem viagem7 = new Viagem(viagem0);
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        double d10 = viagem0.getTempo();
        double d11 = viagem0.getTempo();
        java.util.GregorianCalendar gregorianCalendar12 = viagem0.getData();
        Viagem viagem13 = viagem0.clone();
        Viagem viagem14 = viagem0.clone();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(d6 == 10.0d);
        org.junit.Assert.assertTrue(d10 == 10.0d);
        org.junit.Assert.assertTrue(d11 == 10.0d);
        org.junit.Assert.assertNotNull(gregorianCalendar12);
        org.junit.Assert.assertNotNull(viagem13);
        org.junit.Assert.assertNotNull(viagem14);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem();
        viagem8.setTempo(10.0d);
        boolean b12 = viagem8.equals((java.lang.Object) 100L);
        double d13 = viagem8.getTempo();
        viagem8.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str16 = viagem8.toString();
        viagem8.setMail("");
        double d19 = viagem8.getDesvio();
        int i20 = viagem0.compareTo(viagem8);
        Viagem viagem21 = viagem0.clone();
        Viagem viagem22 = new Viagem();
        viagem22.setTempo(10.0d);
        boolean b26 = viagem22.equals((java.lang.Object) 100L);
        Viagem viagem27 = new Viagem(viagem22);
        double d28 = viagem22.getTempo();
        double d29 = viagem22.getPreco();
        double d30 = viagem22.getDesvio();
        int i31 = viagem21.compareTo(viagem22);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertTrue(d13 == 10.0d);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str16.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d19 == 0.0d);
        org.junit.Assert.assertTrue(i20 == 263);
        org.junit.Assert.assertNotNull(viagem21);
        org.junit.Assert.assertTrue(b26 == false);
        org.junit.Assert.assertTrue(d28 == 10.0d);
        org.junit.Assert.assertTrue(d29 == 0.0d);
        org.junit.Assert.assertTrue(d30 == 0.0d);
        org.junit.Assert.assertTrue(i31 == 263);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Coordenada coordenada5 = viagem0.getcfinal();
        double d6 = viagem0.getTempo();
        Viagem viagem7 = new Viagem(viagem0);
        viagem0.setTempo((double) (byte) 10);
        Viagem viagem10 = new Viagem(viagem0);
        Viagem viagem11 = new Viagem();
        viagem11.setTempo(10.0d);
        boolean b15 = viagem11.equals((java.lang.Object) 100L);
        Viagem viagem16 = viagem11.clone();
        Viagem viagem17 = new Viagem(viagem11);
        Viagem viagem18 = viagem11.clone();
        double d19 = viagem18.getPreco();
        Coordenada coordenada20 = viagem18.getcinicial();
        java.lang.String str21 = viagem18.getMail();
        Viagem viagem22 = new Viagem(viagem18);
        Viagem viagem23 = new Viagem();
        viagem23.setTempo(10.0d);
        boolean b27 = viagem23.equals((java.lang.Object) 100L);
        double d28 = viagem23.getTempo();
        viagem23.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        double d31 = viagem23.getPreco();
        viagem23.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str34 = viagem23.getMail();
        int i35 = viagem22.compareTo(viagem23);
        int i36 = viagem0.compareTo(viagem22);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(d6 == 10.0d);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertNotNull(viagem16);
        org.junit.Assert.assertNotNull(viagem18);
        org.junit.Assert.assertTrue(d19 == 0.0d);
        org.junit.Assert.assertNotNull(coordenada20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertTrue(b27 == false);
        org.junit.Assert.assertTrue(d28 == 10.0d);
        org.junit.Assert.assertTrue(d31 == 0.0d);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str34.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(i35 == (-266));
        org.junit.Assert.assertTrue(i36 == (-1));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        java.util.GregorianCalendar gregorianCalendar9 = viagem0.getData();
        Coordenada coordenada10 = viagem0.getcfinal();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertNotNull(gregorianCalendar9);
        org.junit.Assert.assertNotNull(coordenada10);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        double d6 = viagem0.getPreco();
        Viagem viagem7 = new Viagem(viagem0);
        Viagem viagem8 = new Viagem(viagem0);
        Viagem viagem9 = new Viagem(viagem0);
        double d10 = viagem0.getPreco();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(d10 == 0.0d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        double d8 = viagem0.getPreco();
        double d9 = viagem0.getPreco();
        java.lang.String str10 = viagem0.getMail();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertTrue(d8 == 0.0d);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str10.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Viagem viagem9 = viagem8.clone();
        Coordenada coordenada10 = viagem9.getcfinal();
        Viagem viagem11 = new Viagem();
        viagem11.setTempo(10.0d);
        boolean b15 = viagem11.equals((java.lang.Object) 100L);
        double d16 = viagem11.getTempo();
        viagem11.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str19 = viagem11.toString();
        viagem11.setMail("");
        Viagem viagem22 = new Viagem(viagem11);
        int i23 = viagem9.compareTo(viagem22);
        Viagem viagem24 = new Viagem();
        viagem24.setTempo(10.0d);
        boolean b28 = viagem24.equals((java.lang.Object) 100L);
        Viagem viagem29 = viagem24.clone();
        Viagem viagem30 = new Viagem();
        viagem30.setTempo(10.0d);
        boolean b34 = viagem30.equals((java.lang.Object) 100L);
        double d35 = viagem30.getTempo();
        viagem30.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str38 = viagem30.toString();
        viagem30.setMail("");
        double d41 = viagem30.getDesvio();
        java.util.GregorianCalendar gregorianCalendar42 = viagem30.getData();
        int i43 = viagem29.compareTo(viagem30);
        Viagem viagem44 = viagem29.clone();
        Coordenada coordenada45 = viagem29.getcfinal();
        viagem9.setcfinal(coordenada45);
        double d47 = viagem9.getTempo();
        java.lang.String str48 = viagem9.getMail();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertNotNull(viagem9);
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertTrue(d16 == 10.0d);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str19.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(i23 == 263);
        org.junit.Assert.assertTrue(b28 == false);
        org.junit.Assert.assertNotNull(viagem29);
        org.junit.Assert.assertTrue(b34 == false);
        org.junit.Assert.assertTrue(d35 == 10.0d);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str38.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d41 == 0.0d);
        org.junit.Assert.assertNotNull(gregorianCalendar42);
        org.junit.Assert.assertTrue(i43 == 0);
        org.junit.Assert.assertNotNull(viagem44);
        org.junit.Assert.assertNotNull(coordenada45);
        org.junit.Assert.assertTrue(d47 == 10.0d);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str48.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.util.GregorianCalendar gregorianCalendar8 = viagem0.getData();
        Viagem viagem9 = new Viagem();
        viagem9.setTempo(10.0d);
        boolean b13 = viagem9.equals((java.lang.Object) 100L);
        double d14 = viagem9.getTempo();
        Viagem viagem15 = new Viagem();
        viagem15.setTempo(10.0d);
        boolean b19 = viagem15.equals((java.lang.Object) 100L);
        double d20 = viagem15.getTempo();
        viagem15.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Coordenada coordenada23 = viagem15.getcfinal();
        viagem9.setcinicial(coordenada23);
        viagem0.setcinicial(coordenada23);
        Viagem viagem26 = new Viagem();
        viagem26.setTempo(10.0d);
        boolean b30 = viagem26.equals((java.lang.Object) 100L);
        Viagem viagem31 = new Viagem(viagem26);
        Coordenada coordenada32 = viagem26.getcinicial();
        viagem0.setcfinal(coordenada32);
        Viagem viagem34 = new Viagem();
        viagem34.setTempo(10.0d);
        boolean b38 = viagem34.equals((java.lang.Object) 100L);
        Coordenada coordenada39 = viagem34.getcfinal();
        Coordenada coordenada40 = viagem34.getcinicial();
        boolean b41 = viagem0.equals((java.lang.Object) coordenada40);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertNotNull(gregorianCalendar8);
        org.junit.Assert.assertTrue(b13 == false);
        org.junit.Assert.assertTrue(d14 == 10.0d);
        org.junit.Assert.assertTrue(b19 == false);
        org.junit.Assert.assertTrue(d20 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada23);
        org.junit.Assert.assertTrue(b30 == false);
        org.junit.Assert.assertNotNull(coordenada32);
        org.junit.Assert.assertTrue(b38 == false);
        org.junit.Assert.assertNotNull(coordenada39);
        org.junit.Assert.assertNotNull(coordenada40);
        org.junit.Assert.assertTrue(b41 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem();
        viagem8.setTempo(10.0d);
        boolean b12 = viagem8.equals((java.lang.Object) 100L);
        double d13 = viagem8.getTempo();
        viagem8.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str16 = viagem8.toString();
        viagem8.setMail("");
        double d19 = viagem8.getDesvio();
        int i20 = viagem0.compareTo(viagem8);
        double d21 = viagem0.getPreco();
        Viagem viagem22 = new Viagem();
        viagem22.setTempo(10.0d);
        boolean b26 = viagem22.equals((java.lang.Object) 100L);
        double d27 = viagem22.getTempo();
        viagem22.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str30 = viagem22.toString();
        viagem22.setMail("");
        Coordenada coordenada33 = viagem22.getcinicial();
        viagem0.setcinicial(coordenada33);
        Viagem viagem35 = viagem0.clone();
        Viagem viagem36 = new Viagem();
        viagem36.setTempo(10.0d);
        boolean b40 = viagem36.equals((java.lang.Object) 100L);
        double d41 = viagem36.getTempo();
        viagem36.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem44 = new Viagem();
        viagem44.setTempo(10.0d);
        boolean b48 = viagem44.equals((java.lang.Object) 100L);
        double d49 = viagem44.getTempo();
        viagem44.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str52 = viagem44.toString();
        viagem44.setMail("");
        double d55 = viagem44.getDesvio();
        int i56 = viagem36.compareTo(viagem44);
        Viagem viagem57 = viagem36.clone();
        Viagem viagem58 = new Viagem();
        viagem58.setTempo(10.0d);
        boolean b62 = viagem58.equals((java.lang.Object) 100L);
        double d63 = viagem58.getTempo();
        viagem58.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem66 = new Viagem(viagem58);
        java.util.GregorianCalendar gregorianCalendar67 = viagem58.getData();
        Viagem viagem68 = viagem58.clone();
        int i69 = viagem57.compareTo(viagem58);
        int i70 = viagem0.compareTo(viagem57);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertTrue(d13 == 10.0d);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str16.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d19 == 0.0d);
        org.junit.Assert.assertTrue(i20 == 263);
        org.junit.Assert.assertTrue(d21 == 0.0d);
        org.junit.Assert.assertTrue(b26 == false);
        org.junit.Assert.assertTrue(d27 == 10.0d);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str30.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(coordenada33);
        org.junit.Assert.assertNotNull(viagem35);
        org.junit.Assert.assertTrue(b40 == false);
        org.junit.Assert.assertTrue(d41 == 10.0d);
        org.junit.Assert.assertTrue(b48 == false);
        org.junit.Assert.assertTrue(d49 == 10.0d);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str52.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d55 == 0.0d);
        org.junit.Assert.assertTrue(i56 == 263);
        org.junit.Assert.assertNotNull(viagem57);
        org.junit.Assert.assertTrue(b62 == false);
        org.junit.Assert.assertTrue(d63 == 10.0d);
        org.junit.Assert.assertNotNull(gregorianCalendar67);
        org.junit.Assert.assertNotNull(viagem68);
        org.junit.Assert.assertTrue(i69 == (-1));
        org.junit.Assert.assertTrue(i70 == (-1));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        viagem0.setMail("hi!");
        Coordenada coordenada4 = viagem0.getcfinal();
        double d5 = viagem0.getPreco();
        viagem0.setTempo(100.0d);
        double d8 = viagem0.getTempo();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(coordenada4);
        org.junit.Assert.assertTrue(d5 == 0.0d);
        org.junit.Assert.assertTrue(d8 == 100.0d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = new Viagem(viagem0);
        java.lang.String str6 = viagem0.getMail();
        Viagem viagem7 = new Viagem();
        viagem7.setTempo(10.0d);
        boolean b11 = viagem7.equals((java.lang.Object) 100L);
        Viagem viagem12 = new Viagem(viagem7);
        java.lang.String str13 = viagem7.getMail();
        boolean b14 = viagem0.equals((java.lang.Object) viagem7);
        Viagem viagem15 = new Viagem();
        viagem15.setTempo(10.0d);
        boolean b19 = viagem15.equals((java.lang.Object) 100L);
        Viagem viagem20 = new Viagem(viagem15);
        java.util.GregorianCalendar gregorianCalendar21 = viagem15.getData();
        java.lang.String str22 = viagem15.toString();
        double d23 = viagem15.getPreco();
        Coordenada coordenada24 = viagem15.getcinicial();
        viagem7.setcfinal(coordenada24);
        java.lang.String str26 = viagem7.toString();
        Viagem viagem27 = viagem7.clone();
        Viagem viagem28 = new Viagem();
        viagem28.setTempo(10.0d);
        boolean b32 = viagem28.equals((java.lang.Object) 100L);
        Viagem viagem33 = new Viagem(viagem28);
        java.lang.String str34 = viagem28.getMail();
        Viagem viagem35 = new Viagem();
        viagem35.setTempo(10.0d);
        boolean b39 = viagem35.equals((java.lang.Object) 100L);
        Viagem viagem40 = new Viagem(viagem35);
        java.lang.String str41 = viagem35.getMail();
        boolean b42 = viagem28.equals((java.lang.Object) viagem35);
        Viagem viagem43 = new Viagem();
        viagem43.setTempo(10.0d);
        boolean b47 = viagem43.equals((java.lang.Object) 100L);
        Viagem viagem48 = new Viagem(viagem43);
        java.util.GregorianCalendar gregorianCalendar49 = viagem43.getData();
        java.lang.String str50 = viagem43.toString();
        double d51 = viagem43.getPreco();
        Coordenada coordenada52 = viagem43.getcinicial();
        viagem35.setcfinal(coordenada52);
        java.lang.String str54 = viagem35.toString();
        int i55 = viagem7.compareTo(viagem35);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue(b14 == true);
        org.junit.Assert.assertTrue(b19 == false);
        org.junit.Assert.assertNotNull(gregorianCalendar21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str22.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d23 == 0.0d);
        org.junit.Assert.assertNotNull(coordenada24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str26.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem27);
        org.junit.Assert.assertTrue(b32 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "" + "'", str34.equals(""));
        org.junit.Assert.assertTrue(b39 == false);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "" + "'", str41.equals(""));
        org.junit.Assert.assertTrue(b42 == true);
        org.junit.Assert.assertTrue(b47 == false);
        org.junit.Assert.assertNotNull(gregorianCalendar49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str50.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d51 == 0.0d);
        org.junit.Assert.assertNotNull(coordenada52);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str54.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(i55 == (-1));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        double d6 = viagem0.getPreco();
        Coordenada coordenada7 = viagem0.getcfinal();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertNotNull(coordenada7);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Coordenada coordenada5 = viagem0.getcfinal();
        Coordenada coordenada6 = viagem0.getcinicial();
        Viagem viagem7 = new Viagem();
        viagem7.setTempo(10.0d);
        boolean b11 = viagem7.equals((java.lang.Object) 100L);
        Viagem viagem12 = viagem7.clone();
        Viagem viagem13 = new Viagem();
        viagem13.setTempo(10.0d);
        boolean b17 = viagem13.equals((java.lang.Object) 100L);
        double d18 = viagem13.getTempo();
        viagem13.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str21 = viagem13.toString();
        viagem13.setMail("");
        double d24 = viagem13.getDesvio();
        java.util.GregorianCalendar gregorianCalendar25 = viagem13.getData();
        int i26 = viagem12.compareTo(viagem13);
        Viagem viagem27 = new Viagem(viagem13);
        Coordenada coordenada28 = viagem13.getcinicial();
        Viagem viagem29 = new Viagem();
        viagem29.setTempo(10.0d);
        boolean b33 = viagem29.equals((java.lang.Object) 100L);
        double d34 = viagem29.getTempo();
        viagem29.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem37 = new Viagem(viagem29);
        Coordenada coordenada38 = viagem29.getcfinal();
        Viagem viagem39 = new Viagem(viagem29);
        Coordenada coordenada40 = viagem39.getcinicial();
        viagem13.setcinicial(coordenada40);
        viagem0.setcinicial(coordenada40);
        Coordenada coordenada43 = null;
        Viagem viagem46 = new Viagem();
        java.lang.String str47 = viagem46.toString();
        Viagem viagem48 = viagem46.clone();
        Coordenada coordenada49 = viagem46.getcinicial();
        Viagem viagem50 = new Viagem(viagem46);
        double d51 = viagem50.getPreco();
        Coordenada coordenada52 = viagem50.getcfinal();
        Viagem viagem53 = viagem50.clone();
        Coordenada coordenada54 = viagem50.getcfinal();
        java.util.GregorianCalendar gregorianCalendar55 = viagem50.getData();
        try {
            Viagem viagem58 = new Viagem(coordenada40, coordenada43, (double) (-1L), "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00", gregorianCalendar55, (double) 263, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertNotNull(coordenada6);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertNotNull(viagem12);
        org.junit.Assert.assertTrue(b17 == false);
        org.junit.Assert.assertTrue(d18 == 10.0d);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str21.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d24 == 0.0d);
        org.junit.Assert.assertNotNull(gregorianCalendar25);
        org.junit.Assert.assertTrue(i26 == 0);
        org.junit.Assert.assertNotNull(coordenada28);
        org.junit.Assert.assertTrue(b33 == false);
        org.junit.Assert.assertTrue(d34 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada38);
        org.junit.Assert.assertNotNull(coordenada40);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str47.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem48);
        org.junit.Assert.assertNotNull(coordenada49);
        org.junit.Assert.assertTrue(d51 == 0.0d);
        org.junit.Assert.assertNotNull(coordenada52);
        org.junit.Assert.assertNotNull(viagem53);
        org.junit.Assert.assertNotNull(coordenada54);
        org.junit.Assert.assertNotNull(gregorianCalendar55);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Viagem viagem6 = new Viagem(viagem0);
        Viagem viagem7 = viagem0.clone();
        double d8 = viagem7.getPreco();
        Coordenada coordenada9 = viagem7.getcinicial();
        Viagem viagem10 = new Viagem(viagem7);
        viagem10.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(viagem5);
        org.junit.Assert.assertNotNull(viagem7);
        org.junit.Assert.assertTrue(d8 == 0.0d);
        org.junit.Assert.assertNotNull(coordenada9);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str8 = viagem0.toString();
        viagem0.setMail("");
        Viagem viagem11 = new Viagem(viagem0);
        Coordenada coordenada12 = viagem0.getcfinal();
        java.lang.String str13 = viagem0.getMail();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str8.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(coordenada12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Coordenada coordenada9 = viagem0.getcfinal();
        Viagem viagem10 = new Viagem();
        viagem10.setTempo(10.0d);
        boolean b14 = viagem10.equals((java.lang.Object) 100L);
        Coordenada coordenada15 = viagem10.getcfinal();
        double d16 = viagem10.getTempo();
        Viagem viagem17 = new Viagem(viagem10);
        int i18 = viagem0.compareTo(viagem10);
        double d19 = viagem0.getPreco();
        Viagem viagem20 = new Viagem();
        viagem20.setTempo(10.0d);
        boolean b24 = viagem20.equals((java.lang.Object) 100L);
        double d25 = viagem20.getTempo();
        viagem20.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem28 = new Viagem(viagem20);
        Coordenada coordenada29 = viagem20.getcfinal();
        viagem0.setcfinal(coordenada29);
        Viagem viagem31 = viagem0.clone();
        Viagem viagem32 = new Viagem();
        viagem32.setTempo(10.0d);
        boolean b36 = viagem32.equals((java.lang.Object) 100L);
        Coordenada coordenada37 = viagem32.getcfinal();
        Viagem viagem38 = new Viagem();
        viagem38.setTempo(10.0d);
        boolean b42 = viagem38.equals((java.lang.Object) 100L);
        Viagem viagem43 = viagem38.clone();
        Coordenada coordenada44 = viagem43.getcfinal();
        viagem32.setcinicial(coordenada44);
        Coordenada coordenada46 = viagem32.getcfinal();
        viagem32.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        int i49 = viagem31.compareTo(viagem32);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada9);
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertNotNull(coordenada15);
        org.junit.Assert.assertTrue(d16 == 10.0d);
        org.junit.Assert.assertTrue(i18 == 263);
        org.junit.Assert.assertTrue(d19 == 0.0d);
        org.junit.Assert.assertTrue(b24 == false);
        org.junit.Assert.assertTrue(d25 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada29);
        org.junit.Assert.assertNotNull(viagem31);
        org.junit.Assert.assertTrue(b36 == false);
        org.junit.Assert.assertNotNull(coordenada37);
        org.junit.Assert.assertTrue(b42 == false);
        org.junit.Assert.assertNotNull(viagem43);
        org.junit.Assert.assertNotNull(coordenada44);
        org.junit.Assert.assertNotNull(coordenada46);
        org.junit.Assert.assertTrue(i49 == (-94));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        java.lang.String str3 = viagem2.getMail();
        Viagem viagem4 = new Viagem();
        java.lang.String str5 = viagem4.toString();
        Viagem viagem6 = viagem4.clone();
        Coordenada coordenada7 = viagem4.getcinicial();
        viagem2.setcfinal(coordenada7);
        double d9 = viagem2.getDesvio();
        viagem2.setTempo((double) (short) 0);
        java.util.GregorianCalendar gregorianCalendar12 = viagem2.getData();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str5.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem6);
        org.junit.Assert.assertNotNull(coordenada7);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertNotNull(gregorianCalendar12);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        Coordenada coordenada3 = viagem0.getcfinal();
        java.lang.String str4 = viagem0.toString();
        Viagem viagem5 = new Viagem(viagem0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertNotNull(coordenada3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str4.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Viagem viagem9 = viagem8.clone();
        Coordenada coordenada10 = viagem9.getcfinal();
        Viagem viagem11 = new Viagem();
        viagem11.setTempo(10.0d);
        boolean b15 = viagem11.equals((java.lang.Object) 100L);
        double d16 = viagem11.getTempo();
        viagem11.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str19 = viagem11.toString();
        viagem11.setMail("");
        Viagem viagem22 = new Viagem(viagem11);
        int i23 = viagem9.compareTo(viagem22);
        java.lang.String str24 = viagem22.getMail();
        Viagem viagem25 = new Viagem(viagem22);
        Viagem viagem26 = new Viagem(viagem25);
        double d27 = viagem26.getTempo();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertNotNull(viagem9);
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertTrue(d16 == 10.0d);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str19.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(i23 == 263);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertTrue(d27 == 10.0d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        Coordenada coordenada3 = viagem0.getcinicial();
        Viagem viagem4 = new Viagem(viagem0);
        double d5 = viagem4.getPreco();
        Coordenada coordenada6 = viagem4.getcfinal();
        Viagem viagem7 = viagem4.clone();
        Coordenada coordenada8 = viagem4.getcfinal();
        Viagem viagem9 = viagem4.clone();
        java.util.GregorianCalendar gregorianCalendar10 = viagem4.getData();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertNotNull(coordenada3);
        org.junit.Assert.assertTrue(d5 == 0.0d);
        org.junit.Assert.assertNotNull(coordenada6);
        org.junit.Assert.assertNotNull(viagem7);
        org.junit.Assert.assertNotNull(coordenada8);
        org.junit.Assert.assertNotNull(viagem9);
        org.junit.Assert.assertNotNull(gregorianCalendar10);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        double d2 = viagem0.getPreco();
        Coordenada coordenada3 = viagem0.getcfinal();
        viagem0.setMail("hi!");
        java.lang.String str6 = viagem0.getMail();
        java.lang.String str7 = viagem0.toString();
        java.lang.String str8 = viagem0.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d2 == 0.0d);
        org.junit.Assert.assertNotNull(coordenada3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str7.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str8.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Coordenada coordenada9 = viagem0.getcfinal();
        Viagem viagem10 = new Viagem();
        viagem10.setTempo(10.0d);
        boolean b14 = viagem10.equals((java.lang.Object) 100L);
        Coordenada coordenada15 = viagem10.getcfinal();
        double d16 = viagem10.getTempo();
        Viagem viagem17 = new Viagem(viagem10);
        int i18 = viagem0.compareTo(viagem10);
        double d19 = viagem0.getPreco();
        Viagem viagem20 = new Viagem();
        viagem20.setTempo(10.0d);
        boolean b24 = viagem20.equals((java.lang.Object) 100L);
        double d25 = viagem20.getTempo();
        viagem20.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem28 = new Viagem(viagem20);
        Coordenada coordenada29 = viagem20.getcfinal();
        viagem0.setcfinal(coordenada29);
        Viagem viagem31 = viagem0.clone();
        Viagem viagem32 = viagem31.clone();
        java.lang.String str33 = viagem32.toString();
        double d34 = viagem32.getDesvio();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada9);
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertNotNull(coordenada15);
        org.junit.Assert.assertTrue(d16 == 10.0d);
        org.junit.Assert.assertTrue(i18 == 263);
        org.junit.Assert.assertTrue(d19 == 0.0d);
        org.junit.Assert.assertTrue(b24 == false);
        org.junit.Assert.assertTrue(d25 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada29);
        org.junit.Assert.assertNotNull(viagem31);
        org.junit.Assert.assertNotNull(viagem32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str33.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d34 == 0.0d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Coordenada coordenada8 = viagem0.getcfinal();
        java.util.GregorianCalendar gregorianCalendar9 = viagem0.getData();
        double d10 = viagem0.getTempo();
        Coordenada coordenada11 = viagem0.getcfinal();
        Coordenada coordenada12 = viagem0.getcinicial();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada8);
        org.junit.Assert.assertNotNull(gregorianCalendar9);
        org.junit.Assert.assertTrue(d10 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada11);
        org.junit.Assert.assertNotNull(coordenada12);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Viagem viagem9 = viagem8.clone();
        Coordenada coordenada10 = viagem9.getcfinal();
        Viagem viagem11 = new Viagem();
        viagem11.setTempo(10.0d);
        boolean b15 = viagem11.equals((java.lang.Object) 100L);
        double d16 = viagem11.getTempo();
        viagem11.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str19 = viagem11.toString();
        viagem11.setMail("");
        Viagem viagem22 = new Viagem(viagem11);
        int i23 = viagem9.compareTo(viagem22);
        double d24 = viagem9.getDesvio();
        Viagem viagem25 = new Viagem();
        viagem25.setTempo(10.0d);
        boolean b29 = viagem25.equals((java.lang.Object) 100L);
        Viagem viagem30 = viagem25.clone();
        Viagem viagem31 = new Viagem(viagem25);
        Viagem viagem32 = viagem25.clone();
        Viagem viagem33 = new Viagem();
        viagem33.setTempo(10.0d);
        boolean b37 = viagem33.equals((java.lang.Object) 100L);
        double d38 = viagem33.getTempo();
        viagem33.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem41 = new Viagem(viagem33);
        Viagem viagem42 = viagem41.clone();
        Coordenada coordenada43 = viagem42.getcfinal();
        Viagem viagem44 = new Viagem();
        viagem44.setTempo(10.0d);
        boolean b48 = viagem44.equals((java.lang.Object) 100L);
        double d49 = viagem44.getTempo();
        viagem44.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str52 = viagem44.toString();
        viagem44.setMail("");
        Viagem viagem55 = new Viagem(viagem44);
        int i56 = viagem42.compareTo(viagem55);
        boolean b57 = viagem25.equals((java.lang.Object) i56);
        Viagem viagem58 = new Viagem(viagem25);
        int i59 = viagem9.compareTo(viagem25);
        Viagem viagem60 = viagem9.clone();
        viagem60.setTempo((double) (byte) 10);
        java.lang.String str63 = viagem60.toString();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertNotNull(viagem9);
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertTrue(d16 == 10.0d);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str19.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(i23 == 263);
        org.junit.Assert.assertTrue(d24 == 0.0d);
        org.junit.Assert.assertTrue(b29 == false);
        org.junit.Assert.assertNotNull(viagem30);
        org.junit.Assert.assertNotNull(viagem32);
        org.junit.Assert.assertTrue(b37 == false);
        org.junit.Assert.assertTrue(d38 == 10.0d);
        org.junit.Assert.assertNotNull(viagem42);
        org.junit.Assert.assertNotNull(coordenada43);
        org.junit.Assert.assertTrue(b48 == false);
        org.junit.Assert.assertTrue(d49 == 10.0d);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str52.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(i56 == 263);
        org.junit.Assert.assertTrue(b57 == false);
        org.junit.Assert.assertTrue(i59 == 263);
        org.junit.Assert.assertNotNull(viagem60);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str63.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Viagem viagem9 = viagem8.clone();
        Coordenada coordenada10 = viagem9.getcfinal();
        Viagem viagem11 = new Viagem();
        viagem11.setTempo(10.0d);
        boolean b15 = viagem11.equals((java.lang.Object) 100L);
        double d16 = viagem11.getTempo();
        viagem11.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str19 = viagem11.toString();
        viagem11.setMail("");
        Viagem viagem22 = new Viagem(viagem11);
        int i23 = viagem9.compareTo(viagem22);
        java.lang.String str24 = viagem22.getMail();
        Viagem viagem25 = new Viagem(viagem22);
        Viagem viagem26 = new Viagem();
        viagem26.setTempo(10.0d);
        boolean b30 = viagem26.equals((java.lang.Object) 100L);
        Viagem viagem31 = new Viagem(viagem26);
        java.lang.String str32 = viagem26.getMail();
        int i33 = viagem22.compareTo(viagem26);
        Viagem viagem34 = viagem26.clone();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertNotNull(viagem9);
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertTrue(d16 == 10.0d);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str19.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(i23 == 263);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertTrue(b30 == false);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "" + "'", str32.equals(""));
        org.junit.Assert.assertTrue(i33 == (-1));
        org.junit.Assert.assertNotNull(viagem34);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Coordenada coordenada9 = viagem0.getcfinal();
        Viagem viagem10 = new Viagem();
        viagem10.setTempo(10.0d);
        boolean b14 = viagem10.equals((java.lang.Object) 100L);
        Coordenada coordenada15 = viagem10.getcfinal();
        double d16 = viagem10.getTempo();
        Viagem viagem17 = new Viagem(viagem10);
        int i18 = viagem0.compareTo(viagem10);
        Viagem viagem19 = viagem10.clone();
        double d20 = viagem19.getTempo();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada9);
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertNotNull(coordenada15);
        org.junit.Assert.assertTrue(d16 == 10.0d);
        org.junit.Assert.assertTrue(i18 == 263);
        org.junit.Assert.assertNotNull(viagem19);
        org.junit.Assert.assertTrue(d20 == 10.0d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        java.lang.String str3 = viagem2.getMail();
        Viagem viagem4 = new Viagem();
        java.lang.String str5 = viagem4.toString();
        Viagem viagem6 = viagem4.clone();
        Coordenada coordenada7 = viagem4.getcinicial();
        viagem2.setcfinal(coordenada7);
        double d9 = viagem2.getDesvio();
        Viagem viagem10 = new Viagem();
        java.lang.String str11 = viagem10.toString();
        Viagem viagem12 = viagem10.clone();
        Coordenada coordenada13 = viagem10.getcinicial();
        java.lang.Object obj14 = null;
        boolean b15 = viagem10.equals(obj14);
        int i16 = viagem2.compareTo(viagem10);
        Viagem viagem17 = viagem10.clone();
        Viagem viagem18 = new Viagem();
        java.lang.String str19 = viagem18.toString();
        Viagem viagem20 = viagem18.clone();
        Coordenada coordenada21 = viagem18.getcfinal();
        viagem10.setcinicial(coordenada21);
        Coordenada coordenada23 = viagem10.getcinicial();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str5.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem6);
        org.junit.Assert.assertNotNull(coordenada7);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str11.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem12);
        org.junit.Assert.assertNotNull(coordenada13);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertTrue(i16 == (-1));
        org.junit.Assert.assertNotNull(viagem17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str19.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem20);
        org.junit.Assert.assertNotNull(coordenada21);
        org.junit.Assert.assertNotNull(coordenada23);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Viagem viagem9 = viagem0.clone();
        double d10 = viagem0.getDesvio();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertNotNull(viagem9);
        org.junit.Assert.assertTrue(d10 == 0.0d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        Coordenada coordenada3 = viagem0.getcinicial();
        java.lang.Object obj4 = null;
        boolean b5 = viagem0.equals(obj4);
        java.lang.String str6 = viagem0.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertNotNull(coordenada3);
        org.junit.Assert.assertTrue(b5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str6.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        viagem0.setMail("hi!");
        Coordenada coordenada4 = viagem0.getcfinal();
        viagem0.setTempo(0.0d);
        java.lang.String str7 = viagem0.toString();
        Coordenada coordenada8 = viagem0.getcfinal();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(coordenada4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str7.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(coordenada8);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        Coordenada coordenada3 = viagem0.getcinicial();
        Viagem viagem4 = new Viagem(viagem0);
        viagem4.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem7 = viagem4.clone();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertNotNull(coordenada3);
        org.junit.Assert.assertNotNull(viagem7);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        java.util.GregorianCalendar gregorianCalendar9 = viagem0.getData();
        Viagem viagem10 = new Viagem();
        viagem10.setTempo(10.0d);
        boolean b14 = viagem10.equals((java.lang.Object) 100L);
        double d15 = viagem10.getTempo();
        viagem10.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        double d18 = viagem10.getPreco();
        viagem10.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str21 = viagem10.toString();
        boolean b22 = viagem0.equals((java.lang.Object) viagem10);
        Coordenada coordenada23 = viagem10.getcinicial();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertNotNull(gregorianCalendar9);
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertTrue(d15 == 10.0d);
        org.junit.Assert.assertTrue(d18 == 0.0d);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str21.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(b22 == false);
        org.junit.Assert.assertNotNull(coordenada23);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        viagem0.setMail("hi!");
        Coordenada coordenada4 = viagem0.getcfinal();
        double d5 = viagem0.getPreco();
        Viagem viagem6 = new Viagem();
        java.lang.String str7 = viagem6.toString();
        double d8 = viagem6.getPreco();
        Coordenada coordenada9 = viagem6.getcfinal();
        viagem6.setMail("hi!");
        int i12 = viagem0.compareTo(viagem6);
        double d13 = viagem6.getDesvio();
        Viagem viagem14 = new Viagem(viagem6);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(coordenada4);
        org.junit.Assert.assertTrue(d5 == 0.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str7.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d8 == 0.0d);
        org.junit.Assert.assertNotNull(coordenada9);
        org.junit.Assert.assertTrue(i12 == (-1));
        org.junit.Assert.assertTrue(d13 == 0.0d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        viagem0.setMail("hi!");
        Coordenada coordenada4 = viagem0.getcfinal();
        viagem0.setTempo(0.0d);
        java.lang.String str7 = viagem0.toString();
        java.util.GregorianCalendar gregorianCalendar8 = viagem0.getData();
        java.lang.String str9 = viagem0.getMail();
        java.util.GregorianCalendar gregorianCalendar10 = viagem0.getData();
        double d11 = viagem0.getPreco();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(coordenada4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str7.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(gregorianCalendar8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertNotNull(gregorianCalendar10);
        org.junit.Assert.assertTrue(d11 == 0.0d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Viagem viagem6 = new Viagem(viagem0);
        Viagem viagem7 = new Viagem();
        viagem7.setTempo(10.0d);
        boolean b11 = viagem7.equals((java.lang.Object) 100L);
        Viagem viagem12 = viagem7.clone();
        Viagem viagem13 = new Viagem(viagem7);
        int i14 = viagem0.compareTo(viagem7);
        viagem7.setMail("");
        Viagem viagem17 = viagem7.clone();
        viagem17.setMail("");
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(viagem5);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertNotNull(viagem12);
        org.junit.Assert.assertTrue(i14 == (-1));
        org.junit.Assert.assertNotNull(viagem17);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Coordenada coordenada5 = viagem0.getcfinal();
        double d6 = viagem0.getTempo();
        Viagem viagem7 = new Viagem(viagem0);
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        double d10 = viagem0.getTempo();
        Coordenada coordenada11 = viagem0.getcinicial();
        Viagem viagem12 = new Viagem();
        viagem12.setTempo(10.0d);
        boolean b16 = viagem12.equals((java.lang.Object) 100L);
        Coordenada coordenada17 = viagem12.getcfinal();
        double d18 = viagem12.getTempo();
        Viagem viagem19 = new Viagem(viagem12);
        viagem12.setTempo((double) (byte) 10);
        Viagem viagem22 = new Viagem(viagem12);
        Viagem viagem23 = new Viagem();
        viagem23.setTempo(10.0d);
        boolean b27 = viagem23.equals((java.lang.Object) 100L);
        double d28 = viagem23.getTempo();
        viagem23.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem31 = new Viagem();
        viagem31.setTempo(10.0d);
        boolean b35 = viagem31.equals((java.lang.Object) 100L);
        double d36 = viagem31.getTempo();
        viagem31.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str39 = viagem31.toString();
        viagem31.setMail("");
        double d42 = viagem31.getDesvio();
        int i43 = viagem23.compareTo(viagem31);
        double d44 = viagem23.getPreco();
        Viagem viagem45 = new Viagem();
        viagem45.setTempo(10.0d);
        boolean b49 = viagem45.equals((java.lang.Object) 100L);
        double d50 = viagem45.getTempo();
        viagem45.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str53 = viagem45.toString();
        viagem45.setMail("");
        Coordenada coordenada56 = viagem45.getcinicial();
        viagem23.setcinicial(coordenada56);
        viagem22.setcfinal(coordenada56);
        boolean b59 = viagem0.equals((java.lang.Object) viagem22);
        double d60 = viagem0.getPreco();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(d6 == 10.0d);
        org.junit.Assert.assertTrue(d10 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada11);
        org.junit.Assert.assertTrue(b16 == false);
        org.junit.Assert.assertNotNull(coordenada17);
        org.junit.Assert.assertTrue(d18 == 10.0d);
        org.junit.Assert.assertTrue(b27 == false);
        org.junit.Assert.assertTrue(d28 == 10.0d);
        org.junit.Assert.assertTrue(b35 == false);
        org.junit.Assert.assertTrue(d36 == 10.0d);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str39.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d42 == 0.0d);
        org.junit.Assert.assertTrue(i43 == 263);
        org.junit.Assert.assertTrue(d44 == 0.0d);
        org.junit.Assert.assertTrue(b49 == false);
        org.junit.Assert.assertTrue(d50 == 10.0d);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str53.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(coordenada56);
        org.junit.Assert.assertTrue(b59 == false);
        org.junit.Assert.assertTrue(d60 == 0.0d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Viagem viagem6 = new Viagem();
        viagem6.setTempo(10.0d);
        boolean b10 = viagem6.equals((java.lang.Object) 100L);
        double d11 = viagem6.getTempo();
        viagem6.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str14 = viagem6.toString();
        viagem6.setMail("");
        double d17 = viagem6.getDesvio();
        java.util.GregorianCalendar gregorianCalendar18 = viagem6.getData();
        int i19 = viagem5.compareTo(viagem6);
        Viagem viagem20 = viagem5.clone();
        Coordenada coordenada21 = viagem5.getcinicial();
        Viagem viagem22 = new Viagem(viagem5);
        Viagem viagem23 = new Viagem();
        viagem23.setTempo(10.0d);
        boolean b27 = viagem23.equals((java.lang.Object) 100L);
        double d28 = viagem23.getTempo();
        Coordenada coordenada29 = viagem23.getcfinal();
        viagem22.setcfinal(coordenada29);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(viagem5);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue(d11 == 10.0d);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str14.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d17 == 0.0d);
        org.junit.Assert.assertNotNull(gregorianCalendar18);
        org.junit.Assert.assertTrue(i19 == (-1));
        org.junit.Assert.assertNotNull(viagem20);
        org.junit.Assert.assertNotNull(coordenada21);
        org.junit.Assert.assertTrue(b27 == false);
        org.junit.Assert.assertTrue(d28 == 10.0d);
        org.junit.Assert.assertNotNull(coordenada29);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        double d6 = viagem0.getPreco();
        Viagem viagem7 = new Viagem(viagem0);
        Viagem viagem8 = viagem7.clone();
        Viagem viagem9 = new Viagem();
        viagem9.setTempo(10.0d);
        boolean b13 = viagem9.equals((java.lang.Object) 100L);
        Coordenada coordenada14 = viagem9.getcfinal();
        double d15 = viagem9.getTempo();
        Viagem viagem16 = new Viagem(viagem9);
        boolean b17 = viagem8.equals((java.lang.Object) viagem16);
        double d18 = viagem16.getPreco();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertNotNull(viagem8);
        org.junit.Assert.assertTrue(b13 == false);
        org.junit.Assert.assertNotNull(coordenada14);
        org.junit.Assert.assertTrue(d15 == 10.0d);
        org.junit.Assert.assertTrue(b17 == true);
        org.junit.Assert.assertTrue(d18 == 0.0d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = new Viagem(viagem0);
        java.lang.String str6 = viagem0.getMail();
        Viagem viagem7 = new Viagem();
        viagem7.setTempo(10.0d);
        boolean b11 = viagem7.equals((java.lang.Object) 100L);
        Viagem viagem12 = new Viagem(viagem7);
        java.lang.String str13 = viagem7.getMail();
        boolean b14 = viagem0.equals((java.lang.Object) viagem7);
        Viagem viagem15 = new Viagem();
        viagem15.setTempo(10.0d);
        boolean b19 = viagem15.equals((java.lang.Object) 100L);
        Viagem viagem20 = new Viagem(viagem15);
        java.util.GregorianCalendar gregorianCalendar21 = viagem15.getData();
        java.lang.String str22 = viagem15.toString();
        double d23 = viagem15.getPreco();
        Coordenada coordenada24 = viagem15.getcinicial();
        viagem7.setcfinal(coordenada24);
        java.lang.String str26 = viagem7.toString();
        Viagem viagem27 = viagem7.clone();
        Viagem viagem28 = viagem7.clone();
        double d29 = viagem28.getDesvio();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertTrue(b19 == false);
        org.junit.Assert.assertNotNull(gregorianCalendar21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str22.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d23 == 0.0d);
        org.junit.Assert.assertNotNull(coordenada24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str26.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem27);
        org.junit.Assert.assertNotNull(viagem28);
        org.junit.Assert.assertTrue(d29 == 0.0d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        Coordenada coordenada3 = viagem0.getcinicial();
        Viagem viagem4 = new Viagem(viagem0);
        viagem4.setTempo((double) (short) 0);
        Viagem viagem7 = new Viagem();
        java.lang.String str8 = viagem7.toString();
        Viagem viagem9 = viagem7.clone();
        Coordenada coordenada10 = viagem7.getcinicial();
        boolean b11 = viagem4.equals((java.lang.Object) coordenada10);
        double d12 = viagem4.getTempo();
        viagem4.setTempo((double) 0.0f);
        viagem4.setTempo((double) 0.0f);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertNotNull(coordenada3);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str8.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem9);
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertTrue(d12 == 0.0d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = viagem0.clone();
        Viagem viagem6 = new Viagem();
        viagem6.setTempo(10.0d);
        boolean b10 = viagem6.equals((java.lang.Object) 100L);
        double d11 = viagem6.getTempo();
        viagem6.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str14 = viagem6.toString();
        viagem6.setMail("");
        double d17 = viagem6.getDesvio();
        java.util.GregorianCalendar gregorianCalendar18 = viagem6.getData();
        int i19 = viagem5.compareTo(viagem6);
        Viagem viagem20 = viagem5.clone();
        Coordenada coordenada21 = viagem5.getcinicial();
        java.lang.String str22 = viagem5.getMail();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(viagem5);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue(d11 == 10.0d);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str14.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d17 == 0.0d);
        org.junit.Assert.assertNotNull(gregorianCalendar18);
        org.junit.Assert.assertTrue(i19 == 0);
        org.junit.Assert.assertNotNull(viagem20);
        org.junit.Assert.assertNotNull(coordenada21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Coordenada coordenada5 = viagem0.getcfinal();
        Coordenada coordenada6 = viagem0.getcinicial();
        Coordenada coordenada7 = viagem0.getcinicial();
        Viagem viagem8 = new Viagem();
        viagem8.setTempo(10.0d);
        boolean b12 = viagem8.equals((java.lang.Object) 100L);
        double d13 = viagem8.getTempo();
        viagem8.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem16 = new Viagem();
        viagem16.setTempo(10.0d);
        boolean b20 = viagem16.equals((java.lang.Object) 100L);
        double d21 = viagem16.getTempo();
        viagem16.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str24 = viagem16.toString();
        viagem16.setMail("");
        double d27 = viagem16.getDesvio();
        int i28 = viagem8.compareTo(viagem16);
        double d29 = viagem8.getPreco();
        Viagem viagem30 = new Viagem();
        viagem30.setTempo(10.0d);
        boolean b34 = viagem30.equals((java.lang.Object) 100L);
        double d35 = viagem30.getTempo();
        viagem30.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str38 = viagem30.toString();
        viagem30.setMail("");
        Coordenada coordenada41 = viagem30.getcinicial();
        viagem8.setcinicial(coordenada41);
        viagem0.setcfinal(coordenada41);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertNotNull(coordenada6);
        org.junit.Assert.assertNotNull(coordenada7);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertTrue(d13 == 10.0d);
        org.junit.Assert.assertTrue(b20 == false);
        org.junit.Assert.assertTrue(d21 == 10.0d);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str24.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d27 == 0.0d);
        org.junit.Assert.assertTrue(i28 == 263);
        org.junit.Assert.assertTrue(d29 == 0.0d);
        org.junit.Assert.assertTrue(b34 == false);
        org.junit.Assert.assertTrue(d35 == 10.0d);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str38.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(coordenada41);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem(viagem0);
        Viagem viagem9 = viagem8.clone();
        Coordenada coordenada10 = viagem9.getcfinal();
        Viagem viagem11 = new Viagem();
        viagem11.setTempo(10.0d);
        boolean b15 = viagem11.equals((java.lang.Object) 100L);
        double d16 = viagem11.getTempo();
        viagem11.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str19 = viagem11.toString();
        viagem11.setMail("");
        Viagem viagem22 = new Viagem(viagem11);
        int i23 = viagem9.compareTo(viagem22);
        Coordenada coordenada24 = viagem9.getcfinal();
        java.lang.String str25 = viagem9.getMail();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertNotNull(viagem9);
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertTrue(d16 == 10.0d);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str19.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(i23 == 263);
        org.junit.Assert.assertNotNull(coordenada24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str25.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        viagem0.setMail("hi!");
        Coordenada coordenada4 = viagem0.getcfinal();
        double d5 = viagem0.getPreco();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: -1.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = viagem0.clone();
        Coordenada coordenada9 = viagem8.getcfinal();
        java.lang.String str10 = viagem8.getMail();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(coordenada4);
        org.junit.Assert.assertTrue(d5 == 0.0d);
        org.junit.Assert.assertNotNull(viagem8);
        org.junit.Assert.assertNotNull(coordenada9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: -1.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str10.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: -1.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem8 = new Viagem();
        viagem8.setTempo(10.0d);
        boolean b12 = viagem8.equals((java.lang.Object) 100L);
        double d13 = viagem8.getTempo();
        viagem8.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str16 = viagem8.toString();
        viagem8.setMail("");
        double d19 = viagem8.getDesvio();
        int i20 = viagem0.compareTo(viagem8);
        double d21 = viagem0.getPreco();
        Viagem viagem22 = new Viagem();
        viagem22.setTempo(10.0d);
        boolean b26 = viagem22.equals((java.lang.Object) 100L);
        double d27 = viagem22.getTempo();
        viagem22.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str30 = viagem22.toString();
        viagem22.setMail("");
        Coordenada coordenada33 = viagem22.getcinicial();
        viagem0.setcinicial(coordenada33);
        Viagem viagem35 = viagem0.clone();
        java.util.GregorianCalendar gregorianCalendar36 = viagem0.getData();
        Viagem viagem37 = new Viagem();
        viagem37.setTempo(10.0d);
        boolean b41 = viagem37.equals((java.lang.Object) 100L);
        Viagem viagem42 = new Viagem(viagem37);
        java.util.GregorianCalendar gregorianCalendar43 = viagem37.getData();
        java.lang.String str44 = viagem37.toString();
        java.lang.String str45 = viagem37.getMail();
        Viagem viagem46 = new Viagem();
        viagem46.setTempo(10.0d);
        boolean b50 = viagem46.equals((java.lang.Object) 100L);
        Coordenada coordenada51 = viagem46.getcfinal();
        Viagem viagem52 = new Viagem();
        viagem52.setTempo(10.0d);
        boolean b56 = viagem52.equals((java.lang.Object) 100L);
        Viagem viagem57 = viagem52.clone();
        Coordenada coordenada58 = viagem57.getcfinal();
        viagem46.setcinicial(coordenada58);
        viagem37.setcfinal(coordenada58);
        double d61 = viagem37.getDesvio();
        boolean b62 = viagem0.equals((java.lang.Object) d61);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertTrue(d13 == 10.0d);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str16.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d19 == 0.0d);
        org.junit.Assert.assertTrue(i20 == 263);
        org.junit.Assert.assertTrue(d21 == 0.0d);
        org.junit.Assert.assertTrue(b26 == false);
        org.junit.Assert.assertTrue(d27 == 10.0d);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str30.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(coordenada33);
        org.junit.Assert.assertNotNull(viagem35);
        org.junit.Assert.assertNotNull(gregorianCalendar36);
        org.junit.Assert.assertTrue(b41 == false);
        org.junit.Assert.assertNotNull(gregorianCalendar43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str44.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "" + "'", str45.equals(""));
        org.junit.Assert.assertTrue(b50 == false);
        org.junit.Assert.assertNotNull(coordenada51);
        org.junit.Assert.assertTrue(b56 == false);
        org.junit.Assert.assertNotNull(viagem57);
        org.junit.Assert.assertNotNull(coordenada58);
        org.junit.Assert.assertTrue(d61 == 0.0d);
        org.junit.Assert.assertTrue(b62 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Coordenada coordenada5 = viagem0.getcfinal();
        double d6 = viagem0.getTempo();
        Viagem viagem7 = new Viagem(viagem0);
        Viagem viagem8 = new Viagem();
        viagem8.setTempo(10.0d);
        boolean b12 = viagem8.equals((java.lang.Object) 100L);
        Viagem viagem13 = viagem8.clone();
        Viagem viagem14 = new Viagem(viagem8);
        boolean b15 = viagem0.equals((java.lang.Object) viagem14);
        Viagem viagem16 = viagem14.clone();
        Coordenada coordenada17 = viagem16.getcfinal();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(d6 == 10.0d);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertNotNull(viagem13);
        org.junit.Assert.assertTrue(b15 == true);
        org.junit.Assert.assertNotNull(viagem16);
        org.junit.Assert.assertNotNull(coordenada17);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        Viagem viagem2 = viagem0.clone();
        Coordenada coordenada3 = viagem0.getcinicial();
        java.lang.Object obj4 = null;
        boolean b5 = viagem0.equals(obj4);
        boolean b7 = viagem0.equals((java.lang.Object) (byte) 10);
        java.lang.String str8 = viagem0.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem2);
        org.junit.Assert.assertNotNull(coordenada3);
        org.junit.Assert.assertTrue(b5 == false);
        org.junit.Assert.assertTrue(b7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str8.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        double d5 = viagem0.getTempo();
        viagem0.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str8 = viagem0.toString();
        viagem0.setMail("");
        Coordenada coordenada11 = viagem0.getcinicial();
        Coordenada coordenada12 = null;
        Viagem viagem15 = new Viagem();
        viagem15.setTempo(10.0d);
        boolean b19 = viagem15.equals((java.lang.Object) 100L);
        double d20 = viagem15.getTempo();
        viagem15.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        Viagem viagem23 = new Viagem();
        viagem23.setTempo(10.0d);
        boolean b27 = viagem23.equals((java.lang.Object) 100L);
        double d28 = viagem23.getTempo();
        viagem23.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str31 = viagem23.toString();
        viagem23.setMail("");
        double d34 = viagem23.getDesvio();
        int i35 = viagem15.compareTo(viagem23);
        double d36 = viagem15.getPreco();
        Viagem viagem37 = new Viagem();
        viagem37.setTempo(10.0d);
        boolean b41 = viagem37.equals((java.lang.Object) 100L);
        double d42 = viagem37.getTempo();
        viagem37.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        java.lang.String str45 = viagem37.toString();
        viagem37.setMail("");
        Coordenada coordenada48 = viagem37.getcinicial();
        viagem15.setcinicial(coordenada48);
        Viagem viagem50 = viagem15.clone();
        java.util.GregorianCalendar gregorianCalendar51 = viagem15.getData();
        try {
            Viagem viagem54 = new Viagem(coordenada11, coordenada12, (double) (short) 0, "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00", gregorianCalendar51, (double) (byte) 0, 100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d5 == 10.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str8.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(coordenada11);
        org.junit.Assert.assertTrue(b19 == false);
        org.junit.Assert.assertTrue(d20 == 10.0d);
        org.junit.Assert.assertTrue(b27 == false);
        org.junit.Assert.assertTrue(d28 == 10.0d);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str31.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d34 == 0.0d);
        org.junit.Assert.assertTrue(i35 == 263);
        org.junit.Assert.assertTrue(d36 == 0.0d);
        org.junit.Assert.assertTrue(b41 == false);
        org.junit.Assert.assertTrue(d42 == 10.0d);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str45.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(coordenada48);
        org.junit.Assert.assertNotNull(viagem50);
        org.junit.Assert.assertNotNull(gregorianCalendar51);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        Viagem viagem0 = new Viagem();
        viagem0.setTempo(10.0d);
        boolean b4 = viagem0.equals((java.lang.Object) 100L);
        Viagem viagem5 = new Viagem(viagem0);
        java.util.GregorianCalendar gregorianCalendar6 = viagem0.getData();
        java.lang.String str7 = viagem0.toString();
        double d8 = viagem0.getPreco();
        Coordenada coordenada9 = viagem0.getcinicial();
        double d10 = viagem0.getDesvio();
        Viagem viagem11 = new Viagem(viagem0);
        Viagem viagem12 = new Viagem();
        viagem12.setTempo(10.0d);
        boolean b16 = viagem12.equals((java.lang.Object) 100L);
        double d17 = viagem12.getTempo();
        viagem12.setMail("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00");
        double d20 = viagem12.getPreco();
        Viagem viagem21 = new Viagem(viagem12);
        Viagem viagem22 = new Viagem();
        viagem22.setTempo(10.0d);
        boolean b26 = viagem22.equals((java.lang.Object) 100L);
        Viagem viagem27 = new Viagem(viagem22);
        double d28 = viagem22.getTempo();
        double d29 = viagem22.getPreco();
        Viagem viagem30 = viagem22.clone();
        boolean b31 = viagem12.equals((java.lang.Object) viagem30);
        Viagem viagem32 = viagem30.clone();
        boolean b33 = viagem0.equals((java.lang.Object) viagem30);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(gregorianCalendar6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str7.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 10.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d8 == 0.0d);
        org.junit.Assert.assertNotNull(coordenada9);
        org.junit.Assert.assertTrue(d10 == 0.0d);
        org.junit.Assert.assertTrue(b16 == false);
        org.junit.Assert.assertTrue(d17 == 10.0d);
        org.junit.Assert.assertTrue(d20 == 0.0d);
        org.junit.Assert.assertTrue(b26 == false);
        org.junit.Assert.assertTrue(d28 == 10.0d);
        org.junit.Assert.assertTrue(d29 == 0.0d);
        org.junit.Assert.assertNotNull(viagem30);
        org.junit.Assert.assertTrue(b31 == false);
        org.junit.Assert.assertNotNull(viagem32);
        org.junit.Assert.assertTrue(b33 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        Viagem viagem0 = new Viagem();
        java.lang.String str1 = viagem0.toString();
        viagem0.setMail("hi!");
        Coordenada coordenada4 = viagem0.getcfinal();
        double d5 = viagem0.getPreco();
        Viagem viagem6 = new Viagem();
        java.lang.String str7 = viagem6.toString();
        double d8 = viagem6.getPreco();
        Coordenada coordenada9 = viagem6.getcfinal();
        viagem6.setMail("hi!");
        int i12 = viagem0.compareTo(viagem6);
        Viagem viagem13 = new Viagem();
        java.lang.String str14 = viagem13.toString();
        Viagem viagem15 = new Viagem(viagem13);
        Coordenada coordenada16 = viagem15.getcinicial();
        Viagem viagem17 = new Viagem();
        java.lang.String str18 = viagem17.toString();
        Viagem viagem19 = viagem17.clone();
        java.lang.String str20 = viagem19.getMail();
        Viagem viagem21 = new Viagem();
        java.lang.String str22 = viagem21.toString();
        Viagem viagem23 = viagem21.clone();
        Coordenada coordenada24 = viagem21.getcinicial();
        viagem19.setcfinal(coordenada24);
        viagem15.setcfinal(coordenada24);
        viagem0.setcfinal(coordenada24);
        java.lang.String str28 = viagem0.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str1.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(coordenada4);
        org.junit.Assert.assertTrue(d5 == 0.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str7.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertTrue(d8 == 0.0d);
        org.junit.Assert.assertNotNull(coordenada9);
        org.junit.Assert.assertTrue(i12 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str14.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(coordenada16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str18.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str22.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: \nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
        org.junit.Assert.assertNotNull(viagem23);
        org.junit.Assert.assertNotNull(coordenada24);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00" + "'", str28.equals("Coordenada inicial: Coordenada X: 0 Coordenada Y: 0\nCoordenada final: Coordenada X: 0 Coordenada Y: 0\nTempo que demorou a viagem: 0.00\nMail do ator: hi!\nData da viagem: 26-11-2017\nPreço real da viagem: 0.00\nDesvio entre o valor previsto e o preço real faturado: 0.00"));
    }
}

