import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ErrorTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test001");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota7 = new Mota();
        mota7.setMatricula("");
        Mota mota10 = mota7.clone();
        mota7.setPrecoBase((double) 0L);
        Mota mota13 = new Mota();
        int i14 = mota13.getLugares();
        int i15 = mota7.compareTo((Veiculo) mota13);
        java.lang.String str16 = mota13.toString();
        Coordenada coordenada17 = mota13.getCoordenadas();
        Mota mota19 = new Mota((int) ' ', (double) 100.0f, (int) (byte) -1, "", coordenada17, false);
        mota0.setCoordenadas(coordenada17);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota10 and mota19", (mota10.compareTo(mota19) == 0) == mota10.equals(mota19));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test002");
        Mota mota8 = new Mota();
        mota8.setMatricula("");
        Mota mota11 = mota8.clone();
        mota8.setPrecoBase((double) 0L);
        Mota mota14 = new Mota();
        int i15 = mota14.getLugares();
        int i16 = mota8.compareTo((Veiculo) mota14);
        java.lang.String str17 = mota14.toString();
        Coordenada coordenada18 = mota14.getCoordenadas();
        Mota mota20 = new Mota((int) ' ', (double) 100.0f, (int) (byte) -1, "", coordenada18, false);
        Mota mota22 = new Mota(100, (double) 10, (int) (short) 100, "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, true);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota8 and mota20", (mota8.compareTo(mota20) == 0) == mota8.equals(mota20));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test003");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota3.setOcupado(true);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        mota6.setVelocidadeMedia(10);
        int i10 = mota3.compareTo((Veiculo) mota6);
        Mota mota15 = new Mota();
        mota15.setMatricula("");
        Mota mota18 = mota15.clone();
        mota15.setPrecoBase((double) 0L);
        Mota mota21 = new Mota();
        int i22 = mota21.getLugares();
        int i23 = mota15.compareTo((Veiculo) mota21);
        java.lang.String str24 = mota21.toString();
        Coordenada coordenada25 = mota21.getCoordenadas();
        Mota mota27 = new Mota((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada25, false);
        mota3.setCoordenadas(coordenada25);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota21 and mota6", (mota21.compareTo(mota6) == 0) == mota21.equals(mota6));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test004");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota3.setOcupado(true);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        mota6.setVelocidadeMedia(10);
        int i10 = mota3.compareTo((Veiculo) mota6);
        Mota mota11 = new Mota();
        mota11.setMatricula("");
        Mota mota14 = mota11.clone();
        mota11.setPrecoBase((double) 0L);
        Mota mota17 = new Mota();
        int i18 = mota17.getLugares();
        int i19 = mota11.compareTo((Veiculo) mota17);
        java.lang.String str20 = mota17.toString();
        Coordenada coordenada21 = mota17.getCoordenadas();
        mota3.setCoordenadas(coordenada21);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota6 and mota17", (mota6.compareTo(mota17) == 0) == mota6.equals(mota17));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test005");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Mota mota5 = new Mota(mota0);
        double d6 = mota0.getPrecoBase();
        boolean b7 = mota0.getOcupado();
        int i8 = mota0.getVelocidadeMedia();
        Mota mota9 = new Mota();
        mota9.setMatricula("");
        Mota mota12 = mota9.clone();
        mota12.setOcupado(true);
        Mota mota15 = new Mota();
        int i16 = mota15.getLugares();
        mota15.setVelocidadeMedia(10);
        int i19 = mota12.compareTo((Veiculo) mota15);
        Coordenada coordenada20 = mota12.getCoordenadas();
        boolean b21 = mota0.equals((java.lang.Object) coordenada20);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota12 and mota5", (mota12.compareTo(mota5) == 0) == mota12.equals(mota5));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test006");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        Mota mota4 = new Mota();
        mota4.setMatricula("");
        Mota mota7 = mota4.clone();
        mota7.setOcupado(true);
        Mota mota10 = new Mota();
        int i11 = mota10.getLugares();
        mota10.setVelocidadeMedia(10);
        int i14 = mota7.compareTo((Veiculo) mota10);
        Mota mota15 = mota7.clone();
        int i16 = mota3.compareTo((Veiculo) mota15);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota0 and mota7", (mota0.compareTo(mota7) == 0) == mota0.equals(mota7));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test007");
        Mota mota4 = new Mota();
        int i5 = mota4.getLugares();
        mota4.setVelocidadeMedia(10);
        mota4.setMatricula("n/a");
        Mota mota10 = new Mota();
        mota10.setMatricula("");
        Mota mota13 = mota10.clone();
        mota10.setPrecoBase((double) 0L);
        Mota mota16 = new Mota();
        int i17 = mota16.getLugares();
        int i18 = mota10.compareTo((Veiculo) mota16);
        java.lang.String str19 = mota16.toString();
        Coordenada coordenada20 = mota16.getCoordenadas();
        Mota mota21 = new Mota();
        int i22 = mota21.getLugares();
        Coordenada coordenada23 = mota21.getCoordenadas();
        mota16.setCoordenadas(coordenada23);
        mota4.setCoordenadas(coordenada23);
        Mota mota27 = new Mota((int) (byte) -1, (double) 1.0f, (int) '#', "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada23, false);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota4 and mota21", (mota4.compareTo(mota21) == 0) == mota4.equals(mota21));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test008");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        java.lang.String str9 = mota6.toString();
        Coordenada coordenada10 = mota6.getCoordenadas();
        Mota mota15 = new Mota();
        mota15.setMatricula("");
        Mota mota18 = mota15.clone();
        mota15.setPrecoBase((double) 0L);
        Mota mota21 = new Mota();
        int i22 = mota21.getLugares();
        int i23 = mota15.compareTo((Veiculo) mota21);
        java.lang.String str24 = mota21.toString();
        Coordenada coordenada25 = mota21.getCoordenadas();
        Mota mota27 = new Mota((int) (byte) 100, (double) '#', (int) (short) 0, "", coordenada25, false);
        mota6.setCoordenadas(coordenada25);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota15 and mota27", (mota15.compareTo(mota27) == 0) == mota15.equals(mota27));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test009");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        int i9 = mota6.getFiabilidade();
        Mota mota10 = mota6.clone();
        Mota mota11 = new Mota();
        int i12 = mota11.getLugares();
        mota11.setVelocidadeMedia(10);
        Mota mota15 = new Mota(mota11);
        Coordenada coordenada16 = mota11.getCoordenadas();
        mota10.setCoordenadas(coordenada16);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota15 and mota6", (mota15.compareTo(mota6) == 0) == mota15.equals(mota6));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test010");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        Mota mota4 = new Mota(mota3);
        int i5 = mota1.compareTo((Veiculo) mota3);
        mota1.setVelocidadeMedia((int) (short) 100);
        Mota mota8 = new Mota();
        int i9 = mota8.getLugares();
        mota8.setVelocidadeMedia(10);
        mota8.setMatricula("n/a");
        Mota mota14 = new Mota();
        mota14.setMatricula("");
        Mota mota17 = mota14.clone();
        mota14.setPrecoBase((double) 0L);
        Mota mota20 = new Mota();
        int i21 = mota20.getLugares();
        int i22 = mota14.compareTo((Veiculo) mota20);
        java.lang.String str23 = mota20.toString();
        Coordenada coordenada24 = mota20.getCoordenadas();
        Mota mota25 = new Mota();
        int i26 = mota25.getLugares();
        Coordenada coordenada27 = mota25.getCoordenadas();
        mota20.setCoordenadas(coordenada27);
        mota8.setCoordenadas(coordenada27);
        Mota mota30 = mota8.clone();
        int i31 = mota1.compareTo((Veiculo) mota8);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota20 and mota30", (mota20.compareTo(mota30) == 0) == mota20.equals(mota30));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test011");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota3.setOcupado(true);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        mota6.setVelocidadeMedia(10);
        int i10 = mota3.compareTo((Veiculo) mota6);
        Mota mota11 = mota3.clone();
        double d12 = mota3.getPrecoBase();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota11 and mota0", (mota11.compareTo(mota0) == 0) == mota11.equals(mota0));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test012");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota3.setOcupado(true);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        mota6.setVelocidadeMedia(10);
        int i10 = mota3.compareTo((Veiculo) mota6);
        Mota mota11 = mota3.clone();
        mota3.setOcupado(false);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota0 and mota11", (mota0.compareTo(mota11) == 0) == mota0.equals(mota11));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test013");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        int i4 = mota3.getLugares();
        boolean b5 = mota2.equals((java.lang.Object) mota3);
        Mota mota6 = mota3.clone();
        Mota mota7 = new Mota();
        mota7.setMatricula("");
        Mota mota10 = mota7.clone();
        mota7.setPrecoBase((double) 0L);
        Mota mota13 = new Mota();
        int i14 = mota13.getLugares();
        int i15 = mota7.compareTo((Veiculo) mota13);
        java.lang.String str16 = mota13.toString();
        int i17 = mota13.getFiabilidade();
        mota13.setPrecoBase(10.0d);
        Coordenada coordenada20 = mota13.getCoordenadas();
        mota3.setCoordenadas(coordenada20);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota2 and mota13", (mota2.compareTo(mota13) == 0) == mota2.equals(mota13));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test014");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = mota0.getCoordenadas();
        mota0.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        mota0.setFiabilidade(0);
        Mota mota10 = new Mota();
        mota10.setMatricula("");
        Mota mota13 = mota10.clone();
        mota10.setPrecoBase((double) 0L);
        Mota mota16 = new Mota(mota10);
        mota16.setPrecoBase((double) (-1.0f));
        mota16.setVelocidadeMedia((int) (short) 0);
        boolean b21 = mota0.equals((java.lang.Object) (short) 0);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota13 and mota16", (mota13.compareTo(mota16) == 0) == mota13.equals(mota16));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test015");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        java.lang.String str2 = mota0.toString();
        mota0.setFiabilidade(0);
        Mota mota9 = new Mota();
        mota9.setMatricula("");
        Mota mota12 = mota9.clone();
        Coordenada coordenada13 = mota12.getCoordenadas();
        Mota mota15 = new Mota((int) (byte) -1, (double) 0, (int) (short) 1, "", coordenada13, false);
        mota0.setCoordenadas(coordenada13);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota15 and mota12", (mota15.compareTo(mota12) == 0) == mota15.equals(mota12));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test016");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        java.lang.String str9 = mota6.toString();
        int i10 = mota6.getFiabilidade();
        mota6.setPrecoBase(10.0d);
        int i13 = mota6.getVelocidadeMedia();
        Mota mota14 = new Mota(mota6);
        Mota mota15 = new Mota();
        Mota mota16 = new Mota(mota15);
        Mota mota17 = new Mota(mota16);
        Mota mota18 = new Mota();
        int i19 = mota18.getLugares();
        boolean b20 = mota17.equals((java.lang.Object) mota18);
        Mota mota21 = mota18.clone();
        mota21.setVelocidadeMedia((int) (short) 0);
        int i24 = mota14.compareTo((Veiculo) mota21);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota16 and mota6", (mota16.compareTo(mota6) == 0) == mota16.equals(mota6));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test017");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota3.setOcupado(true);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        mota6.setVelocidadeMedia(10);
        int i10 = mota3.compareTo((Veiculo) mota6);
        mota6.setPrecoBase((double) 0L);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota3 and mota0", (mota3.compareTo(mota0) == 0) == mota3.equals(mota0));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test018");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        Mota mota8 = new Mota();
        mota8.setMatricula("");
        Mota mota11 = mota8.clone();
        mota8.setPrecoBase((double) 0L);
        Mota mota14 = new Mota();
        int i15 = mota14.getLugares();
        int i16 = mota8.compareTo((Veiculo) mota14);
        java.lang.String str17 = mota14.toString();
        Coordenada coordenada18 = mota14.getCoordenadas();
        Mota mota20 = new Mota((int) ' ', (double) 100.0f, (int) (byte) -1, "", coordenada18, false);
        boolean b21 = mota3.equals((java.lang.Object) false);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota8 and mota20", (mota8.compareTo(mota20) == 0) == mota8.equals(mota20));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test019");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = mota0.getCoordenadas();
        java.lang.String str6 = mota0.getMatricula();
        Mota mota11 = new Mota();
        mota11.setMatricula("");
        Mota mota14 = mota11.clone();
        mota11.setPrecoBase((double) 0L);
        Mota mota17 = new Mota();
        int i18 = mota17.getLugares();
        int i19 = mota11.compareTo((Veiculo) mota17);
        java.lang.String str20 = mota17.toString();
        Coordenada coordenada21 = mota17.getCoordenadas();
        Mota mota23 = new Mota((int) (byte) -1, 0.0d, (int) 'a', "", coordenada21, true);
        int i24 = mota0.compareTo((Veiculo) mota23);
        double d25 = mota0.getPrecoBase();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota14 and mota23", (mota14.compareTo(mota23) == 0) == mota14.equals(mota23));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test020");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        Mota mota9 = new Mota(mota6);
        Mota mota10 = new Mota();
        Mota mota11 = new Mota(mota10);
        Mota mota12 = new Mota(mota11);
        Mota mota13 = new Mota();
        Mota mota14 = new Mota(mota13);
        int i15 = mota11.compareTo((Veiculo) mota13);
        int i16 = mota13.getVelocidadeMedia();
        int i17 = mota9.compareTo((Veiculo) mota13);
        Mota mota18 = new Mota();
        mota18.setMatricula("");
        Mota mota21 = mota18.clone();
        mota21.setOcupado(true);
        Mota mota24 = new Mota();
        int i25 = mota24.getLugares();
        mota24.setVelocidadeMedia(10);
        int i28 = mota21.compareTo((Veiculo) mota24);
        Coordenada coordenada29 = mota21.getCoordenadas();
        mota9.setCoordenadas(coordenada29);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota12 and mota24", (mota12.compareTo(mota24) == 0) == mota12.equals(mota24));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test021");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota3.setOcupado(true);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        mota6.setVelocidadeMedia(10);
        int i10 = mota3.compareTo((Veiculo) mota6);
        Mota mota11 = mota6.clone();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota3 and mota0", (mota3.compareTo(mota0) == 0) == mota3.equals(mota0));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test022");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        java.lang.String str9 = mota6.toString();
        Coordenada coordenada10 = mota6.getCoordenadas();
        Mota mota11 = new Mota();
        int i12 = mota11.getLugares();
        Coordenada coordenada13 = mota11.getCoordenadas();
        mota6.setCoordenadas(coordenada13);
        Mota mota15 = new Mota(mota6);
        Mota mota16 = new Mota();
        int i17 = mota16.getLugares();
        mota16.setVelocidadeMedia(10);
        Mota mota20 = new Mota(mota16);
        int i21 = mota16.getVelocidadeMedia();
        java.lang.String str22 = mota16.getMatricula();
        mota16.setVelocidadeMedia((int) (byte) 1);
        Mota mota25 = new Mota(mota16);
        int i26 = mota6.compareTo((Veiculo) mota16);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota15 and mota25", (mota15.compareTo(mota25) == 0) == mota15.equals(mota25));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test023");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        mota0.setMatricula("n/a");
        Mota mota6 = new Mota();
        mota6.setMatricula("");
        Mota mota9 = mota6.clone();
        mota6.setPrecoBase((double) 0L);
        Mota mota12 = new Mota();
        int i13 = mota12.getLugares();
        int i14 = mota6.compareTo((Veiculo) mota12);
        java.lang.String str15 = mota12.toString();
        Coordenada coordenada16 = mota12.getCoordenadas();
        Mota mota17 = new Mota();
        int i18 = mota17.getLugares();
        Coordenada coordenada19 = mota17.getCoordenadas();
        mota12.setCoordenadas(coordenada19);
        mota0.setCoordenadas(coordenada19);
        Mota mota22 = mota0.clone();
        Coordenada coordenada23 = mota22.getCoordenadas();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota0 and mota17", (mota0.compareTo(mota17) == 0) == mota0.equals(mota17));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test024");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        Mota mota8 = new Mota();
        mota8.setMatricula("");
        Mota mota11 = mota8.clone();
        mota8.setPrecoBase((double) 0L);
        Mota mota14 = new Mota();
        int i15 = mota14.getLugares();
        int i16 = mota8.compareTo((Veiculo) mota14);
        java.lang.String str17 = mota14.toString();
        Coordenada coordenada18 = mota14.getCoordenadas();
        Mota mota20 = new Mota((int) (byte) 100, (double) '#', (int) (short) 0, "", coordenada18, false);
        mota0.setCoordenadas(coordenada18);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota8 and mota20", (mota8.compareTo(mota20) == 0) == mota8.equals(mota20));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test025");
        Mota mota8 = new Mota();
        mota8.setMatricula("");
        Mota mota11 = mota8.clone();
        mota8.setPrecoBase((double) 0L);
        Mota mota14 = new Mota();
        int i15 = mota14.getLugares();
        int i16 = mota8.compareTo((Veiculo) mota14);
        java.lang.String str17 = mota14.toString();
        Coordenada coordenada18 = mota14.getCoordenadas();
        Mota mota20 = new Mota((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, false);
        Mota mota22 = new Mota((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, true);
        Mota mota23 = new Mota();
        mota23.setVelocidadeMedia((int) ' ');
        java.lang.String str26 = mota23.toString();
        boolean b27 = mota22.equals((java.lang.Object) mota23);
        mota22.setFiabilidade(1);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota23 and mota14", (mota23.compareTo(mota14) == 0) == mota23.equals(mota14));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test026");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        Mota mota4 = mota0.clone();
        int i5 = mota4.getLugares();
        Mota mota6 = new Mota();
        Mota mota7 = new Mota(mota6);
        Mota mota8 = new Mota(mota7);
        Mota mota9 = new Mota();
        Mota mota10 = new Mota(mota9);
        int i11 = mota7.compareTo((Veiculo) mota9);
        Mota mota12 = new Mota();
        mota12.setMatricula("");
        boolean b16 = mota12.equals((java.lang.Object) (-1.0d));
        boolean b17 = mota7.equals((java.lang.Object) (-1.0d));
        int i18 = mota4.compareTo((Veiculo) mota7);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota9 and mota0", (mota9.compareTo(mota0) == 0) == mota9.equals(mota0));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test027");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        int i2 = mota1.getFiabilidade();
        Mota mota3 = new Mota();
        mota3.setMatricula("");
        boolean b7 = mota3.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada8 = mota3.getCoordenadas();
        int i9 = mota3.getVelocidadeMedia();
        Mota mota10 = new Mota();
        mota10.setMatricula("");
        Mota mota13 = mota10.clone();
        mota13.setOcupado(true);
        boolean b16 = mota3.equals((java.lang.Object) mota13);
        int i17 = mota1.compareTo((Veiculo) mota3);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota13 and mota10", (mota13.compareTo(mota10) == 0) == mota13.equals(mota10));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test028");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        java.lang.String str9 = mota6.toString();
        int i10 = mota6.getFiabilidade();
        Mota mota15 = new Mota();
        mota15.setMatricula("");
        Mota mota18 = mota15.clone();
        mota15.setPrecoBase((double) 0L);
        Mota mota21 = new Mota();
        int i22 = mota21.getLugares();
        int i23 = mota15.compareTo((Veiculo) mota21);
        java.lang.String str24 = mota21.toString();
        Coordenada coordenada25 = mota21.getCoordenadas();
        Mota mota27 = new Mota((int) (byte) -1, 0.0d, (int) 'a', "", coordenada25, true);
        boolean b28 = mota6.equals((java.lang.Object) 'a');
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota18 and mota27", (mota18.compareTo(mota27) == 0) == mota18.equals(mota27));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test029");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        java.lang.String str9 = mota6.toString();
        int i10 = mota6.getFiabilidade();
        mota6.setPrecoBase(10.0d);
        int i13 = mota6.getVelocidadeMedia();
        Mota mota14 = new Mota(mota6);
        mota6.setVelocidadeMedia(1);
        Mota mota17 = new Mota();
        int i18 = mota17.getLugares();
        mota17.setVelocidadeMedia(10);
        mota17.setMatricula("n/a");
        mota17.setPrecoBase((double) (-1.0f));
        boolean b25 = mota6.equals((java.lang.Object) mota17);
        mota17.setVelocidadeMedia((int) (byte) 100);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota6 and mota14", (mota6.compareTo(mota14) == 0) == mota6.equals(mota14));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test030");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        Mota mota4 = new Mota(mota3);
        int i5 = mota1.compareTo((Veiculo) mota3);
        Mota mota10 = new Mota();
        mota10.setMatricula("");
        Mota mota13 = mota10.clone();
        mota10.setPrecoBase((double) 0L);
        Mota mota16 = new Mota();
        int i17 = mota16.getLugares();
        int i18 = mota10.compareTo((Veiculo) mota16);
        java.lang.String str19 = mota16.toString();
        Coordenada coordenada20 = mota16.getCoordenadas();
        Mota mota22 = new Mota((int) ' ', (double) 100.0f, (int) (byte) -1, "", coordenada20, false);
        int i23 = mota1.compareTo((Veiculo) mota22);
        int i24 = mota1.getVelocidadeMedia();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota10 and mota22", (mota10.compareTo(mota22) == 0) == mota10.equals(mota22));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test031");
        Mota mota4 = new Mota();
        Mota mota5 = new Mota(mota4);
        Mota mota6 = new Mota(mota5);
        Mota mota7 = new Mota();
        Mota mota8 = new Mota(mota7);
        int i9 = mota5.compareTo((Veiculo) mota7);
        mota5.setVelocidadeMedia((int) (short) 100);
        Coordenada coordenada12 = mota5.getCoordenadas();
        Mota mota14 = new Mota(0, (-1.0d), 33, "hi!", coordenada12, false);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota7 and mota5", (mota7.compareTo(mota5) == 0) == mota7.equals(mota5));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test032");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota3.setOcupado(true);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        mota6.setVelocidadeMedia(10);
        int i10 = mota3.compareTo((Veiculo) mota6);
        boolean b11 = mota6.getOcupado();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota3 and mota0", (mota3.compareTo(mota0) == 0) == mota3.equals(mota0));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test033");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        java.lang.String str9 = mota6.toString();
        Coordenada coordenada10 = mota6.getCoordenadas();
        mota6.setFiabilidade((int) (byte) 1);
        Mota mota13 = new Mota();
        int i14 = mota13.getLugares();
        mota13.setVelocidadeMedia(10);
        Mota mota17 = mota13.clone();
        boolean b18 = mota6.equals((java.lang.Object) mota13);
        java.lang.String str19 = mota13.toString();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota6 and mota17", (mota6.compareTo(mota17) == 0) == mota6.equals(mota17));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test034");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        java.lang.String str9 = mota6.toString();
        Coordenada coordenada10 = mota6.getCoordenadas();
        Mota mota11 = new Mota();
        int i12 = mota11.getLugares();
        Coordenada coordenada13 = mota11.getCoordenadas();
        mota6.setCoordenadas(coordenada13);
        Mota mota15 = new Mota(mota6);
        java.lang.String str16 = mota15.toString();
        Mota mota17 = new Mota();
        int i18 = mota17.getLugares();
        mota17.setVelocidadeMedia(10);
        Mota mota21 = new Mota(mota17);
        java.lang.String str22 = mota17.toString();
        boolean b23 = mota15.equals((java.lang.Object) str22);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota6 and mota21", (mota6.compareTo(mota21) == 0) == mota6.equals(mota21));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test035");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        java.lang.String str2 = mota0.getMatricula();
        Mota mota3 = new Mota();
        int i4 = mota3.getLugares();
        mota3.setVelocidadeMedia(10);
        Mota mota7 = new Mota(mota3);
        Mota mota8 = new Mota(mota7);
        int i9 = mota8.getFiabilidade();
        Mota mota10 = mota8.clone();
        Mota mota11 = new Mota();
        mota11.setMatricula("");
        Mota mota14 = mota11.clone();
        int i15 = mota14.getVelocidadeMedia();
        Coordenada coordenada16 = mota14.getCoordenadas();
        mota10.setCoordenadas(coordenada16);
        mota0.setCoordenadas(coordenada16);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota1 and mota7", (mota1.compareTo(mota7) == 0) == mota1.equals(mota7));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test036");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        mota0.setMatricula("n/a");
        Mota mota6 = new Mota();
        mota6.setMatricula("");
        Mota mota9 = mota6.clone();
        mota6.setPrecoBase((double) 0L);
        Mota mota12 = new Mota();
        int i13 = mota12.getLugares();
        int i14 = mota6.compareTo((Veiculo) mota12);
        java.lang.String str15 = mota12.toString();
        Coordenada coordenada16 = mota12.getCoordenadas();
        Mota mota17 = new Mota();
        int i18 = mota17.getLugares();
        Coordenada coordenada19 = mota17.getCoordenadas();
        mota12.setCoordenadas(coordenada19);
        mota0.setCoordenadas(coordenada19);
        Mota mota22 = mota0.clone();
        java.lang.String str23 = mota0.getMatricula();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota17 and mota22", (mota17.compareTo(mota22) == 0) == mota17.equals(mota22));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test037");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        Mota mota4 = new Mota(mota0);
        int i5 = mota0.getVelocidadeMedia();
        java.lang.String str6 = mota0.getMatricula();
        mota0.setVelocidadeMedia((int) (byte) 1);
        Mota mota9 = new Mota(mota0);
        mota9.setVelocidadeMedia((int) (short) 0);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota0 and mota4", (mota0.compareTo(mota4) == 0) == mota0.equals(mota4));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test038");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        mota1.setVelocidadeMedia(0);
        Mota mota5 = new Mota();
        int i6 = mota5.getLugares();
        mota5.setVelocidadeMedia(10);
        Mota mota9 = new Mota(mota5);
        Coordenada coordenada10 = mota5.getCoordenadas();
        mota1.setCoordenadas(coordenada10);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota0 and mota9", (mota0.compareTo(mota9) == 0) == mota0.equals(mota9));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test039");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        java.lang.String str9 = mota6.toString();
        int i10 = mota6.getFiabilidade();
        mota6.setPrecoBase(10.0d);
        int i13 = mota6.getVelocidadeMedia();
        Mota mota14 = new Mota(mota6);
        mota6.setVelocidadeMedia(1);
        Mota mota17 = new Mota();
        int i18 = mota17.getLugares();
        mota17.setVelocidadeMedia(10);
        mota17.setMatricula("n/a");
        mota17.setPrecoBase((double) (-1.0f));
        boolean b25 = mota6.equals((java.lang.Object) mota17);
        boolean b26 = mota17.getOcupado();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota6 and mota14", (mota6.compareTo(mota14) == 0) == mota6.equals(mota14));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test040");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota3.setOcupado(true);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        mota6.setVelocidadeMedia(10);
        int i10 = mota3.compareTo((Veiculo) mota6);
        Coordenada coordenada11 = mota3.getCoordenadas();
        int i12 = mota3.getVelocidadeMedia();
        Mota mota13 = new Mota();
        int i14 = mota13.getLugares();
        mota13.setVelocidadeMedia(10);
        Mota mota17 = new Mota(mota13);
        Mota mota18 = new Mota(mota17);
        boolean b19 = mota3.equals((java.lang.Object) mota17);
        boolean b21 = mota17.equals((java.lang.Object) "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota0 and mota3", (mota0.compareTo(mota3) == 0) == mota0.equals(mota3));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test041");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        Coordenada coordenada4 = mota3.getCoordenadas();
        Mota mota5 = new Mota();
        mota5.setMatricula("");
        Mota mota8 = mota5.clone();
        mota5.setPrecoBase((double) 0L);
        Mota mota11 = new Mota();
        int i12 = mota11.getLugares();
        int i13 = mota5.compareTo((Veiculo) mota11);
        java.lang.String str14 = mota11.toString();
        Coordenada coordenada15 = mota11.getCoordenadas();
        int i16 = mota3.compareTo((Veiculo) mota11);
        Mota mota17 = new Mota();
        Mota mota18 = new Mota(mota17);
        java.lang.String str19 = mota17.toString();
        mota17.setFiabilidade(0);
        Mota mota22 = mota17.clone();
        int i23 = mota17.getLugares();
        Mota mota28 = new Mota();
        Mota mota29 = new Mota(mota28);
        Mota mota30 = new Mota(mota29);
        Mota mota31 = new Mota();
        Mota mota32 = new Mota(mota31);
        int i33 = mota29.compareTo((Veiculo) mota31);
        Mota mota34 = new Mota();
        mota34.setMatricula("");
        boolean b38 = mota34.equals((java.lang.Object) (-1.0d));
        boolean b39 = mota29.equals((java.lang.Object) (-1.0d));
        Mota mota40 = new Mota();
        mota40.setMatricula("");
        Mota mota43 = mota40.clone();
        mota40.setPrecoBase((double) 0L);
        Mota mota46 = new Mota();
        int i47 = mota46.getLugares();
        int i48 = mota40.compareTo((Veiculo) mota46);
        java.lang.String str49 = mota46.toString();
        Coordenada coordenada50 = mota46.getCoordenadas();
        mota29.setCoordenadas(coordenada50);
        Mota mota53 = new Mota((-1), 10.0d, (int) (byte) 1, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada50, true);
        mota17.setCoordenadas(coordenada50);
        mota11.setCoordenadas(coordenada50);
        Mota mota56 = new Mota();
        int i57 = mota56.getLugares();
        mota56.setVelocidadeMedia(10);
        mota56.setMatricula("n/a");
        Mota mota62 = new Mota();
        mota62.setMatricula("");
        Mota mota65 = mota62.clone();
        mota62.setPrecoBase((double) 0L);
        Mota mota68 = new Mota();
        int i69 = mota68.getLugares();
        int i70 = mota62.compareTo((Veiculo) mota68);
        java.lang.String str71 = mota68.toString();
        Coordenada coordenada72 = mota68.getCoordenadas();
        Mota mota73 = new Mota();
        int i74 = mota73.getLugares();
        Coordenada coordenada75 = mota73.getCoordenadas();
        mota68.setCoordenadas(coordenada75);
        mota56.setCoordenadas(coordenada75);
        mota11.setCoordenadas(coordenada75);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota56 and mota28", (mota56.compareTo(mota28) == 0) == mota56.equals(mota28));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test042");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        java.lang.String str2 = mota0.getMatricula();
        Mota mota3 = new Mota(mota0);
        mota0.setOcupado(true);
        java.lang.String str6 = mota0.toString();
        Mota mota7 = new Mota();
        mota7.setMatricula("");
        boolean b11 = mota7.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada12 = mota7.getCoordenadas();
        mota7.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        mota7.setFiabilidade(0);
        Mota mota17 = new Mota();
        mota17.setMatricula("");
        Mota mota20 = mota17.clone();
        mota17.setPrecoBase((double) 0L);
        Mota mota23 = new Mota(mota17);
        int i24 = mota7.compareTo((Veiculo) mota17);
        Mota mota25 = new Mota();
        Mota mota26 = new Mota(mota25);
        java.lang.String str27 = mota25.toString();
        mota25.setFiabilidade(0);
        mota25.setPrecoBase(1.0d);
        int i32 = mota7.compareTo((Veiculo) mota25);
        int i33 = mota0.compareTo((Veiculo) mota7);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota25 and mota26", (mota25.compareTo(mota26) == 0) == mota25.equals(mota26));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test043");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        java.lang.String str3 = mota0.toString();
        Mota mota4 = mota0.clone();
        Mota mota5 = new Mota();
        Mota mota6 = new Mota(mota5);
        Mota mota7 = new Mota(mota6);
        Mota mota8 = new Mota();
        Mota mota9 = new Mota(mota8);
        int i10 = mota6.compareTo((Veiculo) mota8);
        mota6.setVelocidadeMedia((int) (short) 100);
        java.lang.String str13 = mota6.getMatricula();
        double d14 = mota6.getPrecoBase();
        int i15 = mota0.compareTo((Veiculo) mota6);
        double d16 = mota0.getPrecoBase();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota5 and mota6", (mota5.compareTo(mota6) == 0) == mota5.equals(mota6));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test044");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        Mota mota4 = new Mota(mota0);
        int i5 = mota0.getVelocidadeMedia();
        java.lang.String str6 = mota0.getMatricula();
        mota0.setVelocidadeMedia((int) (byte) 1);
        Mota mota9 = new Mota(mota0);
        mota0.setMatricula("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota4 and mota9", (mota4.compareTo(mota9) == 0) == mota4.equals(mota9));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test045");
        Mota mota8 = new Mota();
        mota8.setMatricula("");
        Mota mota11 = mota8.clone();
        mota8.setPrecoBase((double) 0L);
        Mota mota14 = new Mota();
        int i15 = mota14.getLugares();
        int i16 = mota8.compareTo((Veiculo) mota14);
        java.lang.String str17 = mota14.toString();
        Coordenada coordenada18 = mota14.getCoordenadas();
        Mota mota20 = new Mota((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, false);
        Mota mota22 = new Mota((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, true);
        Mota mota23 = new Mota();
        mota23.setVelocidadeMedia((int) ' ');
        java.lang.String str26 = mota23.toString();
        boolean b27 = mota22.equals((java.lang.Object) mota23);
        Mota mota28 = new Mota();
        int i29 = mota28.getLugares();
        mota28.setVelocidadeMedia(10);
        Mota mota32 = mota28.clone();
        int i33 = mota23.compareTo((Veiculo) mota28);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota14 and mota32", (mota14.compareTo(mota32) == 0) == mota14.equals(mota32));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test046");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        java.lang.String str9 = mota6.toString();
        Mota mota10 = new Mota();
        mota10.setMatricula("");
        boolean b14 = mota10.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada15 = mota10.getCoordenadas();
        mota10.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        mota10.setFiabilidade(0);
        Mota mota20 = new Mota();
        mota20.setMatricula("");
        Mota mota23 = mota20.clone();
        mota20.setPrecoBase((double) 0L);
        Mota mota26 = new Mota(mota20);
        int i27 = mota10.compareTo((Veiculo) mota20);
        Mota mota28 = new Mota();
        Mota mota29 = new Mota(mota28);
        java.lang.String str30 = mota28.toString();
        mota28.setFiabilidade(0);
        mota28.setPrecoBase(1.0d);
        int i35 = mota10.compareTo((Veiculo) mota28);
        boolean b36 = mota6.equals((java.lang.Object) i35);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota29 and mota28", (mota29.compareTo(mota28) == 0) == mota29.equals(mota28));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test047");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota();
        mota2.setVelocidadeMedia((int) ' ');
        java.lang.String str5 = mota2.toString();
        Mota mota10 = new Mota();
        mota10.setMatricula("");
        Mota mota13 = mota10.clone();
        Coordenada coordenada14 = mota13.getCoordenadas();
        Mota mota16 = new Mota((int) (byte) 0, (double) 'a', 3, "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada14, false);
        boolean b17 = mota2.equals((java.lang.Object) 'a');
        mota2.setVelocidadeMedia((int) (byte) 100);
        Mota mota20 = new Mota();
        Mota mota21 = new Mota(mota20);
        Mota mota22 = new Mota(mota21);
        int i23 = mota22.getLugares();
        int i24 = mota2.compareTo((Veiculo) mota22);
        int i25 = mota0.compareTo((Veiculo) mota22);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota1 and mota2", (mota1.compareTo(mota2) == 0) == mota1.equals(mota2));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test048");
        Mota mota8 = new Mota();
        mota8.setMatricula("");
        Mota mota11 = mota8.clone();
        mota8.setPrecoBase((double) 0L);
        Mota mota14 = new Mota();
        int i15 = mota14.getLugares();
        int i16 = mota8.compareTo((Veiculo) mota14);
        java.lang.String str17 = mota14.toString();
        Coordenada coordenada18 = mota14.getCoordenadas();
        Mota mota20 = new Mota((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, false);
        Mota mota22 = new Mota((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, true);
        Mota mota23 = new Mota();
        mota23.setVelocidadeMedia((int) ' ');
        java.lang.String str26 = mota23.toString();
        boolean b27 = mota22.equals((java.lang.Object) mota23);
        double d28 = mota22.getPrecoBase();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota23 and mota14", (mota23.compareTo(mota14) == 0) == mota23.equals(mota14));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test049");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        mota0.setPrecoBase((double) (byte) 10);
        Mota mota4 = new Mota(mota0);
        Mota mota9 = new Mota();
        mota9.setMatricula("");
        Mota mota12 = mota9.clone();
        mota9.setPrecoBase((double) 0L);
        Mota mota15 = new Mota();
        int i16 = mota15.getLugares();
        int i17 = mota9.compareTo((Veiculo) mota15);
        java.lang.String str18 = mota15.toString();
        Coordenada coordenada19 = mota15.getCoordenadas();
        Mota mota21 = new Mota((int) ' ', (double) 100.0f, (int) (byte) -1, "", coordenada19, false);
        boolean b22 = mota4.equals((java.lang.Object) mota21);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota1 and mota0", (mota1.compareTo(mota0) == 0) == mota1.equals(mota0));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test050");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        mota0.setMatricula("n/a");
        Mota mota6 = new Mota();
        mota6.setMatricula("");
        Mota mota9 = mota6.clone();
        mota6.setPrecoBase((double) 0L);
        Mota mota12 = new Mota();
        int i13 = mota12.getLugares();
        int i14 = mota6.compareTo((Veiculo) mota12);
        java.lang.String str15 = mota12.toString();
        Coordenada coordenada16 = mota12.getCoordenadas();
        Mota mota17 = new Mota();
        int i18 = mota17.getLugares();
        Coordenada coordenada19 = mota17.getCoordenadas();
        mota12.setCoordenadas(coordenada19);
        mota0.setCoordenadas(coordenada19);
        Mota mota22 = mota0.clone();
        Mota mota27 = new Mota();
        mota27.setMatricula("");
        Mota mota30 = mota27.clone();
        Coordenada coordenada31 = mota30.getCoordenadas();
        Mota mota33 = new Mota((int) (byte) -1, (double) 0, (int) (short) 1, "", coordenada31, false);
        double d34 = mota33.getPrecoBase();
        boolean b35 = mota0.equals((java.lang.Object) mota33);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota17 and mota22", (mota17.compareTo(mota22) == 0) == mota17.equals(mota22));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test051");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        java.lang.String str3 = mota0.toString();
        Mota mota4 = new Mota();
        Mota mota5 = new Mota(mota4);
        java.lang.String str6 = mota4.toString();
        mota4.setFiabilidade(0);
        Mota mota9 = mota4.clone();
        Mota mota10 = new Mota();
        Mota mota11 = new Mota(mota10);
        Mota mota12 = new Mota(mota11);
        Mota mota13 = new Mota();
        Mota mota14 = new Mota(mota13);
        int i15 = mota11.compareTo((Veiculo) mota13);
        Mota mota16 = new Mota();
        mota16.setMatricula("");
        boolean b20 = mota16.equals((java.lang.Object) (-1.0d));
        boolean b21 = mota11.equals((java.lang.Object) (-1.0d));
        Mota mota22 = new Mota();
        mota22.setMatricula("");
        Mota mota25 = mota22.clone();
        mota22.setPrecoBase((double) 0L);
        Mota mota28 = new Mota();
        int i29 = mota28.getLugares();
        int i30 = mota22.compareTo((Veiculo) mota28);
        java.lang.String str31 = mota28.toString();
        Coordenada coordenada32 = mota28.getCoordenadas();
        mota11.setCoordenadas(coordenada32);
        mota4.setCoordenadas(coordenada32);
        mota0.setCoordenadas(coordenada32);
        Mota mota36 = new Mota();
        mota36.setMatricula("");
        Mota mota39 = mota36.clone();
        mota36.setPrecoBase((double) 0L);
        Mota mota42 = new Mota(mota36);
        int i43 = mota36.getLugares();
        Mota mota44 = new Mota();
        int i45 = mota44.getLugares();
        mota44.setVelocidadeMedia(10);
        mota44.setMatricula("n/a");
        mota44.setPrecoBase((double) 1L);
        Coordenada coordenada52 = mota44.getCoordenadas();
        mota36.setCoordenadas(coordenada52);
        mota0.setCoordenadas(coordenada52);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota44 and mota9", (mota44.compareTo(mota9) == 0) == mota44.equals(mota9));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test052");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota(mota0);
        mota6.setPrecoBase((double) (-1.0f));
        mota6.setPrecoBase((double) 10);
        Mota mota11 = new Mota();
        Mota mota12 = new Mota(mota11);
        Mota mota13 = new Mota(mota12);
        Mota mota14 = new Mota();
        Mota mota15 = new Mota(mota14);
        int i16 = mota12.compareTo((Veiculo) mota14);
        int i17 = mota14.getVelocidadeMedia();
        Mota mota18 = mota14.clone();
        int i19 = mota6.compareTo((Veiculo) mota14);
        Mota mota20 = new Mota();
        Mota mota21 = new Mota(mota20);
        Mota mota22 = new Mota(mota21);
        Mota mota23 = new Mota();
        Mota mota24 = new Mota(mota23);
        int i25 = mota21.compareTo((Veiculo) mota23);
        mota21.setVelocidadeMedia((int) (short) 100);
        int i28 = mota6.compareTo((Veiculo) mota21);
        Coordenada coordenada29 = mota21.getCoordenadas();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota0 and mota6", (mota0.compareTo(mota6) == 0) == mota0.equals(mota6));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test053");
        Mota mota8 = new Mota();
        mota8.setMatricula("");
        Mota mota11 = mota8.clone();
        mota8.setPrecoBase((double) 0L);
        Mota mota14 = new Mota();
        int i15 = mota14.getLugares();
        int i16 = mota8.compareTo((Veiculo) mota14);
        java.lang.String str17 = mota14.toString();
        Coordenada coordenada18 = mota14.getCoordenadas();
        Mota mota20 = new Mota(10, (double) (short) -1, (int) (byte) 1, "", coordenada18, false);
        Mota mota22 = new Mota((-33), 10.0d, 100, "n/a", coordenada18, true);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota11 and mota20", (mota11.compareTo(mota20) == 0) == mota11.equals(mota20));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test054");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        java.lang.String str9 = mota6.toString();
        int i10 = mota6.getFiabilidade();
        mota6.setPrecoBase(10.0d);
        int i13 = mota6.getVelocidadeMedia();
        Mota mota14 = new Mota(mota6);
        Coordenada coordenada15 = mota14.getCoordenadas();
        boolean b16 = mota14.getOcupado();
        Mota mota17 = new Mota();
        Mota mota18 = new Mota(mota17);
        java.lang.String str19 = mota17.toString();
        mota17.setFiabilidade(0);
        mota17.setPrecoBase(1.0d);
        mota17.setOcupado(false);
        boolean b26 = mota14.equals((java.lang.Object) mota17);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota18 and mota6", (mota18.compareTo(mota6) == 0) == mota18.equals(mota6));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test055");
        Mota mota4 = new Mota();
        mota4.setMatricula("");
        Mota mota7 = mota4.clone();
        mota4.setPrecoBase((double) 0L);
        Mota mota10 = new Mota();
        int i11 = mota10.getLugares();
        int i12 = mota4.compareTo((Veiculo) mota10);
        java.lang.String str13 = mota10.toString();
        Coordenada coordenada14 = mota10.getCoordenadas();
        Mota mota16 = new Mota((int) (byte) 100, (double) '#', (int) (short) 0, "", coordenada14, false);
        java.lang.Object obj17 = null;
        boolean b18 = mota16.equals(obj17);
        Mota mota19 = mota16.clone();
        java.lang.String str20 = mota16.toString();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota4 and mota19", (mota4.compareTo(mota19) == 0) == mota4.equals(mota19));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test056");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Mota mota5 = new Mota(mota0);
        double d6 = mota0.getPrecoBase();
        boolean b7 = mota0.getOcupado();
        mota0.setOcupado(false);
        Mota mota10 = new Mota();
        int i11 = mota10.getLugares();
        mota10.setVelocidadeMedia(10);
        Mota mota14 = new Mota(mota10);
        Mota mota15 = mota14.clone();
        boolean b16 = mota0.equals((java.lang.Object) mota14);
        Mota mota17 = new Mota();
        mota17.setMatricula("");
        Mota mota20 = mota17.clone();
        mota17.setPrecoBase((double) 0L);
        Mota mota23 = new Mota(mota17);
        Mota mota36 = new Mota();
        mota36.setMatricula("");
        Mota mota39 = mota36.clone();
        mota36.setPrecoBase((double) 0L);
        Mota mota42 = new Mota();
        int i43 = mota42.getLugares();
        int i44 = mota36.compareTo((Veiculo) mota42);
        java.lang.String str45 = mota42.toString();
        Coordenada coordenada46 = mota42.getCoordenadas();
        Mota mota48 = new Mota((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada46, false);
        Mota mota50 = new Mota((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada46, true);
        Mota mota52 = new Mota((int) '#', 10.0d, (-1), "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada46, true);
        mota23.setCoordenadas(coordenada46);
        mota14.setCoordenadas(coordenada46);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota10 and mota42", (mota10.compareTo(mota42) == 0) == mota10.equals(mota42));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test057");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        java.lang.String str9 = mota6.toString();
        Coordenada coordenada10 = mota6.getCoordenadas();
        mota6.setFiabilidade((int) (byte) 1);
        Mota mota13 = new Mota();
        int i14 = mota13.getLugares();
        mota13.setVelocidadeMedia(10);
        Mota mota17 = mota13.clone();
        boolean b18 = mota6.equals((java.lang.Object) mota13);
        double d19 = mota13.getPrecoBase();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota17 and mota6", (mota17.compareTo(mota6) == 0) == mota17.equals(mota6));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test058");
        Mota mota0 = new Mota();
        mota0.setVelocidadeMedia((int) ' ');
        java.lang.String str3 = mota0.toString();
        Mota mota8 = new Mota();
        mota8.setMatricula("");
        Mota mota11 = mota8.clone();
        Coordenada coordenada12 = mota11.getCoordenadas();
        Mota mota14 = new Mota((int) (byte) 0, (double) 'a', 3, "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada12, false);
        boolean b15 = mota0.equals((java.lang.Object) 'a');
        mota0.setVelocidadeMedia((int) (byte) 100);
        Mota mota18 = new Mota();
        Mota mota19 = new Mota(mota18);
        Mota mota20 = new Mota(mota19);
        int i21 = mota20.getLugares();
        int i22 = mota0.compareTo((Veiculo) mota20);
        java.lang.String str23 = mota20.toString();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota0 and mota18", (mota0.compareTo(mota18) == 0) == mota0.equals(mota18));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test059");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        mota0.setMatricula("n/a");
        mota0.setPrecoBase((double) (-1.0f));
        int i8 = mota0.getVelocidadeMedia();
        Mota mota9 = new Mota();
        mota9.setMatricula("");
        Mota mota12 = mota9.clone();
        mota9.setPrecoBase((double) 0L);
        Mota mota15 = new Mota();
        int i16 = mota15.getLugares();
        int i17 = mota9.compareTo((Veiculo) mota15);
        java.lang.String str18 = mota15.toString();
        Coordenada coordenada19 = mota15.getCoordenadas();
        Mota mota20 = new Mota();
        int i21 = mota20.getLugares();
        Coordenada coordenada22 = mota20.getCoordenadas();
        mota15.setCoordenadas(coordenada22);
        Mota mota24 = new Mota(mota15);
        java.lang.String str25 = mota24.toString();
        java.lang.Object obj26 = null;
        boolean b27 = mota24.equals(obj26);
        int i28 = mota0.compareTo((Veiculo) mota24);
        Mota mota29 = new Mota();
        mota29.setMatricula("");
        Mota mota32 = mota29.clone();
        mota32.setOcupado(true);
        Mota mota35 = new Mota();
        int i36 = mota35.getLugares();
        mota35.setVelocidadeMedia(10);
        int i39 = mota32.compareTo((Veiculo) mota35);
        Coordenada coordenada40 = mota32.getCoordenadas();
        int i41 = mota32.getVelocidadeMedia();
        Mota mota42 = new Mota();
        int i43 = mota42.getLugares();
        mota42.setVelocidadeMedia(10);
        Mota mota46 = new Mota(mota42);
        Mota mota47 = new Mota(mota46);
        boolean b48 = mota32.equals((java.lang.Object) mota46);
        int i49 = mota0.compareTo((Veiculo) mota32);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota35 and mota15", (mota35.compareTo(mota15) == 0) == mota35.equals(mota15));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test060");
        Mota mota4 = new Mota();
        mota4.setMatricula("");
        Mota mota7 = mota4.clone();
        mota4.setPrecoBase((double) 0L);
        Mota mota10 = new Mota();
        int i11 = mota10.getLugares();
        int i12 = mota4.compareTo((Veiculo) mota10);
        java.lang.String str13 = mota10.toString();
        Coordenada coordenada14 = mota10.getCoordenadas();
        Mota mota16 = new Mota(10, (double) (short) -1, (int) (byte) 1, "", coordenada14, false);
        Mota mota17 = new Mota();
        int i18 = mota17.getLugares();
        mota17.setVelocidadeMedia(10);
        Mota mota21 = new Mota(mota17);
        Mota mota22 = new Mota(mota21);
        int i23 = mota22.getFiabilidade();
        Mota mota24 = mota22.clone();
        Mota mota25 = new Mota();
        mota25.setMatricula("");
        Mota mota28 = mota25.clone();
        int i29 = mota28.getVelocidadeMedia();
        Coordenada coordenada30 = mota28.getCoordenadas();
        mota24.setCoordenadas(coordenada30);
        int i32 = mota24.getVelocidadeMedia();
        boolean b33 = mota16.equals((java.lang.Object) mota24);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota21 and mota10", (mota21.compareTo(mota10) == 0) == mota21.equals(mota10));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test061");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota(mota0);
        mota6.setPrecoBase((double) (-1.0f));
        mota6.setPrecoBase((double) 10);
        Mota mota11 = new Mota();
        Mota mota12 = new Mota(mota11);
        Mota mota13 = new Mota(mota12);
        Mota mota14 = new Mota();
        Mota mota15 = new Mota(mota14);
        int i16 = mota12.compareTo((Veiculo) mota14);
        int i17 = mota14.getVelocidadeMedia();
        Mota mota18 = mota14.clone();
        int i19 = mota6.compareTo((Veiculo) mota14);
        Mota mota20 = new Mota();
        Mota mota21 = new Mota(mota20);
        Mota mota22 = new Mota(mota21);
        Mota mota23 = new Mota();
        Mota mota24 = new Mota(mota23);
        int i25 = mota21.compareTo((Veiculo) mota23);
        mota21.setVelocidadeMedia((int) (short) 100);
        int i28 = mota6.compareTo((Veiculo) mota21);
        int i29 = mota6.getLugares();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota11 and mota21", (mota11.compareTo(mota21) == 0) == mota11.equals(mota21));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test062");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        java.lang.String str9 = mota6.toString();
        Coordenada coordenada10 = mota6.getCoordenadas();
        mota6.setFiabilidade((int) (byte) 1);
        Mota mota13 = new Mota();
        int i14 = mota13.getLugares();
        mota13.setVelocidadeMedia(10);
        Mota mota17 = mota13.clone();
        boolean b18 = mota6.equals((java.lang.Object) mota13);
        mota13.setOcupado(false);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota17 and mota6", (mota17.compareTo(mota6) == 0) == mota17.equals(mota6));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test063");
        Mota mota8 = new Mota();
        mota8.setMatricula("");
        Mota mota11 = mota8.clone();
        int i12 = mota11.getVelocidadeMedia();
        Coordenada coordenada13 = mota11.getCoordenadas();
        Mota mota15 = new Mota((-1), (double) (byte) -1, (-3), "", coordenada13, true);
        Mota mota17 = new Mota((int) (byte) 1, (double) (-33), 100, "Matrícula: Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada13, true);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota8 and mota15", (mota8.compareTo(mota15) == 0) == mota8.equals(mota15));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test064");
        Mota mota8 = new Mota();
        mota8.setMatricula("");
        Mota mota11 = mota8.clone();
        mota8.setPrecoBase((double) 0L);
        Mota mota14 = new Mota();
        int i15 = mota14.getLugares();
        int i16 = mota8.compareTo((Veiculo) mota14);
        java.lang.String str17 = mota14.toString();
        Coordenada coordenada18 = mota14.getCoordenadas();
        Mota mota20 = new Mota((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, false);
        Mota mota22 = new Mota((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, true);
        Mota mota23 = new Mota();
        mota23.setVelocidadeMedia((int) ' ');
        java.lang.String str26 = mota23.toString();
        boolean b27 = mota22.equals((java.lang.Object) mota23);
        java.lang.String str28 = mota22.toString();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota14 and mota23", (mota14.compareTo(mota23) == 0) == mota14.equals(mota23));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test065");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        int i4 = mota3.getLugares();
        boolean b5 = mota2.equals((java.lang.Object) mota3);
        mota3.setOcupado(true);
        Coordenada coordenada8 = mota3.getCoordenadas();
        mota3.setPrecoBase((double) (-1.0f));
        boolean b11 = mota3.getOcupado();
        Mota mota12 = new Mota();
        mota12.setMatricula("");
        Mota mota15 = mota12.clone();
        mota12.setPrecoBase((double) 0L);
        Mota mota18 = new Mota();
        int i19 = mota18.getLugares();
        int i20 = mota12.compareTo((Veiculo) mota18);
        java.lang.String str21 = mota18.toString();
        int i22 = mota18.getFiabilidade();
        mota18.setPrecoBase(10.0d);
        int i25 = mota18.getVelocidadeMedia();
        Mota mota26 = new Mota(mota18);
        double d27 = mota18.getPrecoBase();
        int i28 = mota3.compareTo((Veiculo) mota18);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota0 and mota26", (mota0.compareTo(mota26) == 0) == mota0.equals(mota26));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test066");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        mota0.setOcupado(false);
        mota0.setVelocidadeMedia((-1));
        int i7 = mota0.getFiabilidade();
        mota0.setVelocidadeMedia(3);
        Mota mota10 = new Mota();
        int i11 = mota10.getLugares();
        mota10.setVelocidadeMedia(10);
        mota10.setMatricula("n/a");
        Mota mota16 = new Mota();
        mota16.setMatricula("");
        Mota mota19 = mota16.clone();
        mota16.setPrecoBase((double) 0L);
        Mota mota22 = new Mota();
        int i23 = mota22.getLugares();
        int i24 = mota16.compareTo((Veiculo) mota22);
        java.lang.String str25 = mota22.toString();
        Coordenada coordenada26 = mota22.getCoordenadas();
        Mota mota27 = new Mota();
        int i28 = mota27.getLugares();
        Coordenada coordenada29 = mota27.getCoordenadas();
        mota22.setCoordenadas(coordenada29);
        mota10.setCoordenadas(coordenada29);
        mota0.setCoordenadas(coordenada29);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota10 and mota27", (mota10.compareTo(mota27) == 0) == mota10.equals(mota27));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test067");
        Mota mota4 = new Mota();
        mota4.setMatricula("");
        Mota mota7 = mota4.clone();
        mota7.setOcupado(true);
        Mota mota10 = new Mota();
        int i11 = mota10.getLugares();
        mota10.setVelocidadeMedia(10);
        int i14 = mota7.compareTo((Veiculo) mota10);
        Coordenada coordenada15 = mota7.getCoordenadas();
        Mota mota17 = new Mota((int) (byte) -1, (double) 100.0f, 3, "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada15, true);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota7 and mota4", (mota7.compareTo(mota4) == 0) == mota7.equals(mota4));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test068");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        java.lang.String str9 = mota6.toString();
        int i10 = mota6.getFiabilidade();
        mota6.setPrecoBase(10.0d);
        int i13 = mota6.getFiabilidade();
        Mota mota14 = new Mota();
        mota14.setMatricula("");
        Mota mota17 = mota14.clone();
        mota14.setPrecoBase((double) 0L);
        Mota mota20 = new Mota();
        int i21 = mota20.getLugares();
        int i22 = mota14.compareTo((Veiculo) mota20);
        java.lang.String str23 = mota20.toString();
        int i24 = mota20.getFiabilidade();
        mota20.setPrecoBase(10.0d);
        Coordenada coordenada27 = mota20.getCoordenadas();
        mota6.setCoordenadas(coordenada27);
        int i29 = mota6.getVelocidadeMedia();
        Mota mota30 = new Mota();
        mota30.setMatricula("");
        Mota mota33 = mota30.clone();
        mota33.setOcupado(true);
        int i36 = mota33.getFiabilidade();
        Mota mota37 = mota33.clone();
        int i38 = mota6.compareTo((Veiculo) mota37);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota17 and mota33", (mota17.compareTo(mota33) == 0) == mota17.equals(mota33));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test069");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = mota0.getCoordenadas();
        int i6 = mota0.getVelocidadeMedia();
        Mota mota7 = new Mota();
        mota7.setMatricula("");
        Mota mota10 = mota7.clone();
        mota10.setOcupado(true);
        boolean b13 = mota0.equals((java.lang.Object) mota10);
        mota0.setVelocidadeMedia((int) (short) 100);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota7 and mota10", (mota7.compareTo(mota10) == 0) == mota7.equals(mota10));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test070");
        Mota mota4 = new Mota();
        mota4.setMatricula("");
        Mota mota7 = mota4.clone();
        mota4.setPrecoBase((double) 0L);
        Mota mota10 = new Mota();
        int i11 = mota10.getLugares();
        int i12 = mota4.compareTo((Veiculo) mota10);
        java.lang.String str13 = mota10.toString();
        Coordenada coordenada14 = mota10.getCoordenadas();
        Mota mota16 = new Mota(10, (double) (short) -1, (int) (byte) 1, "", coordenada14, false);
        int i17 = mota16.getLugares();
        Mota mota18 = new Mota();
        int i19 = mota18.getLugares();
        mota18.setVelocidadeMedia(10);
        mota18.setMatricula("n/a");
        mota18.setPrecoBase((double) 1L);
        int i26 = mota18.getFiabilidade();
        int i27 = mota16.compareTo((Veiculo) mota18);
        java.lang.String str28 = mota16.getMatricula();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota10 and mota18", (mota10.compareTo(mota18) == 0) == mota10.equals(mota18));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test071");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota3.setOcupado(true);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        mota6.setVelocidadeMedia(10);
        int i10 = mota3.compareTo((Veiculo) mota6);
        Coordenada coordenada11 = mota3.getCoordenadas();
        int i12 = mota3.getVelocidadeMedia();
        Mota mota13 = new Mota();
        int i14 = mota13.getLugares();
        mota13.setVelocidadeMedia(10);
        Mota mota17 = new Mota(mota13);
        Mota mota18 = new Mota(mota17);
        boolean b19 = mota3.equals((java.lang.Object) mota17);
        boolean b20 = mota17.getOcupado();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota0 and mota3", (mota0.compareTo(mota3) == 0) == mota0.equals(mota3));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test072");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota3.setOcupado(true);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        mota6.setVelocidadeMedia(10);
        int i10 = mota3.compareTo((Veiculo) mota6);
        mota6.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 35\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota0 and mota3", (mota0.compareTo(mota3) == 0) == mota0.equals(mota3));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test073");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        java.lang.String str9 = mota6.toString();
        Coordenada coordenada10 = mota6.getCoordenadas();
        mota6.setFiabilidade((int) (byte) 1);
        Mota mota13 = new Mota();
        int i14 = mota13.getLugares();
        mota13.setVelocidadeMedia(10);
        Mota mota17 = mota13.clone();
        boolean b18 = mota6.equals((java.lang.Object) mota13);
        Mota mota19 = new Mota();
        mota19.setVelocidadeMedia((int) ' ');
        java.lang.String str22 = mota19.toString();
        int i23 = mota19.getVelocidadeMedia();
        boolean b24 = mota19.getOcupado();
        int i25 = mota6.compareTo((Veiculo) mota19);
        mota19.setVelocidadeMedia((int) (byte) -1);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota6 and mota17", (mota6.compareTo(mota17) == 0) == mota6.equals(mota17));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test074");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        Mota mota4 = new Mota(mota0);
        int i5 = mota0.getVelocidadeMedia();
        mota0.setMatricula("");
        Mota mota8 = mota0.clone();
        Mota mota13 = new Mota();
        Mota mota14 = new Mota(mota13);
        java.lang.String str15 = mota13.toString();
        mota13.setFiabilidade(0);
        Mota mota18 = mota13.clone();
        int i19 = mota13.getLugares();
        Mota mota24 = new Mota();
        Mota mota25 = new Mota(mota24);
        Mota mota26 = new Mota(mota25);
        Mota mota27 = new Mota();
        Mota mota28 = new Mota(mota27);
        int i29 = mota25.compareTo((Veiculo) mota27);
        Mota mota30 = new Mota();
        mota30.setMatricula("");
        boolean b34 = mota30.equals((java.lang.Object) (-1.0d));
        boolean b35 = mota25.equals((java.lang.Object) (-1.0d));
        Mota mota36 = new Mota();
        mota36.setMatricula("");
        Mota mota39 = mota36.clone();
        mota36.setPrecoBase((double) 0L);
        Mota mota42 = new Mota();
        int i43 = mota42.getLugares();
        int i44 = mota36.compareTo((Veiculo) mota42);
        java.lang.String str45 = mota42.toString();
        Coordenada coordenada46 = mota42.getCoordenadas();
        mota25.setCoordenadas(coordenada46);
        Mota mota49 = new Mota((-1), 10.0d, (int) (byte) 1, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada46, true);
        mota13.setCoordenadas(coordenada46);
        Mota mota52 = new Mota((int) (byte) 100, (double) 1.0f, (int) (short) 100, "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada46, true);
        mota8.setCoordenadas(coordenada46);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota18 and mota4", (mota18.compareTo(mota4) == 0) == mota18.equals(mota4));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test075");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota3.setOcupado(true);
        int i6 = mota3.getFiabilidade();
        Mota mota7 = mota3.clone();
        Mota mota8 = new Mota();
        int i9 = mota8.getLugares();
        mota8.setVelocidadeMedia(10);
        Mota mota12 = new Mota(mota8);
        int i13 = mota8.getVelocidadeMedia();
        Mota mota14 = mota8.clone();
        Mota mota15 = mota8.clone();
        boolean b16 = mota7.equals((java.lang.Object) mota15);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota3 and mota0", (mota3.compareTo(mota0) == 0) == mota3.equals(mota0));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test076");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Mota mota5 = new Mota(mota0);
        Mota mota6 = new Mota();
        Mota mota7 = new Mota(mota6);
        Mota mota8 = new Mota(mota7);
        Mota mota9 = new Mota();
        Mota mota10 = new Mota(mota9);
        int i11 = mota7.compareTo((Veiculo) mota9);
        Mota mota12 = new Mota();
        mota12.setMatricula("");
        boolean b16 = mota12.equals((java.lang.Object) (-1.0d));
        boolean b17 = mota7.equals((java.lang.Object) (-1.0d));
        Mota mota18 = new Mota();
        mota18.setMatricula("");
        Mota mota21 = mota18.clone();
        mota18.setPrecoBase((double) 0L);
        Mota mota24 = new Mota();
        int i25 = mota24.getLugares();
        int i26 = mota18.compareTo((Veiculo) mota24);
        java.lang.String str27 = mota24.toString();
        Coordenada coordenada28 = mota24.getCoordenadas();
        mota7.setCoordenadas(coordenada28);
        mota7.setPrecoBase((double) (short) 10);
        int i32 = mota7.getFiabilidade();
        boolean b33 = mota7.getOcupado();
        boolean b34 = mota0.equals((java.lang.Object) b33);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota9 and mota7", (mota9.compareTo(mota7) == 0) == mota9.equals(mota7));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test077");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = mota0.getCoordenadas();
        java.lang.String str6 = mota0.getMatricula();
        Mota mota11 = new Mota();
        mota11.setMatricula("");
        Mota mota14 = mota11.clone();
        mota11.setPrecoBase((double) 0L);
        Mota mota17 = new Mota();
        int i18 = mota17.getLugares();
        int i19 = mota11.compareTo((Veiculo) mota17);
        java.lang.String str20 = mota17.toString();
        Coordenada coordenada21 = mota17.getCoordenadas();
        Mota mota23 = new Mota((int) (byte) -1, 0.0d, (int) 'a', "", coordenada21, true);
        int i24 = mota0.compareTo((Veiculo) mota23);
        Mota mota25 = new Mota();
        int i26 = mota25.getLugares();
        boolean b27 = mota23.equals((java.lang.Object) mota25);
        mota25.setMatricula("Matrícula: Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: -1.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota23 and mota0", (mota23.compareTo(mota0) == 0) == mota23.equals(mota0));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test078");
        Mota mota4 = new Mota();
        mota4.setMatricula("");
        java.lang.String str7 = mota4.toString();
        Mota mota8 = mota4.clone();
        Mota mota21 = new Mota();
        mota21.setMatricula("");
        Mota mota24 = mota21.clone();
        mota21.setPrecoBase((double) 0L);
        Mota mota27 = new Mota();
        int i28 = mota27.getLugares();
        int i29 = mota21.compareTo((Veiculo) mota27);
        java.lang.String str30 = mota27.toString();
        Coordenada coordenada31 = mota27.getCoordenadas();
        Mota mota33 = new Mota((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada31, false);
        Mota mota35 = new Mota((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada31, true);
        Mota mota37 = new Mota((int) '#', 10.0d, (-1), "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada31, true);
        Coordenada coordenada38 = mota37.getCoordenadas();
        mota8.setCoordenadas(coordenada38);
        Coordenada coordenada40 = mota8.getCoordenadas();
        Mota mota42 = new Mota(0, (double) 0, (int) (short) 100, "Matrícula: Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 100km/h\nPreço Base: 10.0€\nFiabilidade: 10\nLugares: 1\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada40, true);
        Mota mota51 = new Mota();
        mota51.setMatricula("");
        java.lang.String str54 = mota51.toString();
        Mota mota55 = new Mota();
        Mota mota56 = new Mota(mota55);
        java.lang.String str57 = mota55.toString();
        mota55.setFiabilidade(0);
        Mota mota60 = mota55.clone();
        Mota mota61 = new Mota();
        Mota mota62 = new Mota(mota61);
        Mota mota63 = new Mota(mota62);
        Mota mota64 = new Mota();
        Mota mota65 = new Mota(mota64);
        int i66 = mota62.compareTo((Veiculo) mota64);
        Mota mota67 = new Mota();
        mota67.setMatricula("");
        boolean b71 = mota67.equals((java.lang.Object) (-1.0d));
        boolean b72 = mota62.equals((java.lang.Object) (-1.0d));
        Mota mota73 = new Mota();
        mota73.setMatricula("");
        Mota mota76 = mota73.clone();
        mota73.setPrecoBase((double) 0L);
        Mota mota79 = new Mota();
        int i80 = mota79.getLugares();
        int i81 = mota73.compareTo((Veiculo) mota79);
        java.lang.String str82 = mota79.toString();
        Coordenada coordenada83 = mota79.getCoordenadas();
        mota62.setCoordenadas(coordenada83);
        mota55.setCoordenadas(coordenada83);
        mota51.setCoordenadas(coordenada83);
        Mota mota88 = new Mota((int) (byte) 0, (double) 100L, (int) (byte) -1, "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada83, false);
        Mota mota90 = new Mota((int) (short) -1, (double) 10, (int) (short) 10, "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 10.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada83, true);
        mota42.setCoordenadas(coordenada83);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota35 and mota88", (mota35.compareTo(mota88) == 0) == mota35.equals(mota88));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test079");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota(mota0);
        mota6.setPrecoBase((double) (-1.0f));
        mota6.setPrecoBase((double) 10);
        Mota mota11 = new Mota();
        Mota mota12 = new Mota(mota11);
        Mota mota13 = new Mota(mota12);
        Mota mota14 = new Mota();
        Mota mota15 = new Mota(mota14);
        int i16 = mota12.compareTo((Veiculo) mota14);
        int i17 = mota14.getVelocidadeMedia();
        Mota mota18 = mota14.clone();
        int i19 = mota6.compareTo((Veiculo) mota14);
        Mota mota20 = new Mota();
        Mota mota21 = new Mota(mota20);
        Mota mota22 = new Mota(mota21);
        Mota mota23 = new Mota();
        Mota mota24 = new Mota(mota23);
        int i25 = mota21.compareTo((Veiculo) mota23);
        mota21.setVelocidadeMedia((int) (short) 100);
        int i28 = mota6.compareTo((Veiculo) mota21);
        java.lang.String str29 = mota21.getMatricula();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota6 and mota3", (mota6.compareTo(mota3) == 0) == mota6.equals(mota3));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test080");
        Mota mota4 = new Mota();
        mota4.setMatricula("");
        Mota mota7 = mota4.clone();
        mota7.setOcupado(true);
        Mota mota10 = new Mota();
        int i11 = mota10.getLugares();
        mota10.setVelocidadeMedia(10);
        int i14 = mota7.compareTo((Veiculo) mota10);
        Coordenada coordenada15 = mota7.getCoordenadas();
        Mota mota17 = new Mota((int) (short) 0, (double) 33, (int) (short) 10, "Matrícula: Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 35km/h\nPreço Base: 10.0€\nFiabilidade: -1\nLugares: 1\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n", coordenada15, true);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota7 and mota4", (mota7.compareTo(mota4) == 0) == mota7.equals(mota4));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test081");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = mota0.getCoordenadas();
        int i6 = mota0.getVelocidadeMedia();
        Mota mota7 = new Mota();
        mota7.setMatricula("");
        Mota mota10 = mota7.clone();
        mota10.setOcupado(true);
        boolean b13 = mota0.equals((java.lang.Object) mota10);
        mota0.setOcupado(false);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota7 and mota10", (mota7.compareTo(mota10) == 0) == mota7.equals(mota10));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test082");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        java.lang.String str9 = mota6.toString();
        Coordenada coordenada10 = mota6.getCoordenadas();
        mota6.setFiabilidade((int) (byte) 1);
        Mota mota13 = new Mota();
        int i14 = mota13.getLugares();
        mota13.setVelocidadeMedia(10);
        Mota mota17 = mota13.clone();
        boolean b18 = mota6.equals((java.lang.Object) mota13);
        Mota mota19 = new Mota();
        mota19.setVelocidadeMedia((int) ' ');
        java.lang.String str22 = mota19.toString();
        int i23 = mota19.getVelocidadeMedia();
        boolean b24 = mota19.getOcupado();
        int i25 = mota6.compareTo((Veiculo) mota19);
        Mota mota26 = new Mota(mota6);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota17 and mota19", (mota17.compareTo(mota19) == 0) == mota17.equals(mota19));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test083");
        Mota mota4 = new Mota();
        mota4.setVelocidadeMedia((int) ' ');
        Mota mota7 = new Mota();
        mota7.setMatricula("");
        java.lang.String str10 = mota7.toString();
        Mota mota11 = mota7.clone();
        Mota mota24 = new Mota();
        mota24.setMatricula("");
        Mota mota27 = mota24.clone();
        mota24.setPrecoBase((double) 0L);
        Mota mota30 = new Mota();
        int i31 = mota30.getLugares();
        int i32 = mota24.compareTo((Veiculo) mota30);
        java.lang.String str33 = mota30.toString();
        Coordenada coordenada34 = mota30.getCoordenadas();
        Mota mota36 = new Mota((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada34, false);
        Mota mota38 = new Mota((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada34, true);
        Mota mota40 = new Mota((int) '#', 10.0d, (-1), "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada34, true);
        Coordenada coordenada41 = mota40.getCoordenadas();
        mota11.setCoordenadas(coordenada41);
        mota4.setCoordenadas(coordenada41);
        Mota mota45 = new Mota((int) (short) -1, (double) 10L, 32, "", coordenada41, false);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota30 and mota4", (mota30.compareTo(mota4) == 0) == mota30.equals(mota4));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test084");
        Mota mota8 = new Mota();
        mota8.setMatricula("");
        Mota mota11 = mota8.clone();
        mota8.setPrecoBase((double) 0L);
        Mota mota14 = new Mota();
        int i15 = mota14.getLugares();
        int i16 = mota8.compareTo((Veiculo) mota14);
        java.lang.String str17 = mota14.toString();
        Coordenada coordenada18 = mota14.getCoordenadas();
        Mota mota20 = new Mota((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, false);
        Mota mota22 = new Mota((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, true);
        Mota mota23 = new Mota();
        mota23.setVelocidadeMedia((int) ' ');
        java.lang.String str26 = mota23.toString();
        boolean b27 = mota22.equals((java.lang.Object) mota23);
        Mota mota28 = new Mota(mota23);
        java.lang.String str29 = mota28.getMatricula();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota23 and mota14", (mota23.compareTo(mota14) == 0) == mota23.equals(mota14));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test085");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota(mota0);
        Mota mota7 = new Mota();
        Mota mota8 = new Mota(mota7);
        Mota mota9 = new Mota(mota8);
        Mota mota10 = new Mota();
        Mota mota11 = new Mota(mota10);
        int i12 = mota8.compareTo((Veiculo) mota10);
        Mota mota13 = new Mota(mota10);
        mota13.setOcupado(true);
        double d16 = mota13.getPrecoBase();
        Coordenada coordenada17 = mota13.getCoordenadas();
        mota0.setCoordenadas(coordenada17);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota8 and mota13", (mota8.compareTo(mota13) == 0) == mota8.equals(mota13));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test086");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        int i4 = mota3.getVelocidadeMedia();
        Coordenada coordenada5 = mota3.getCoordenadas();
        Mota mota6 = new Mota();
        mota6.setMatricula("");
        Mota mota9 = mota6.clone();
        mota6.setPrecoBase((double) 0L);
        Mota mota12 = new Mota();
        int i13 = mota12.getLugares();
        int i14 = mota6.compareTo((Veiculo) mota12);
        java.lang.String str15 = mota12.toString();
        java.lang.String str16 = mota12.toString();
        boolean b17 = mota3.equals((java.lang.Object) str16);
        Mota mota22 = new Mota();
        mota22.setMatricula("");
        Mota mota25 = mota22.clone();
        mota22.setPrecoBase((double) 0L);
        Mota mota28 = new Mota();
        int i29 = mota28.getLugares();
        int i30 = mota22.compareTo((Veiculo) mota28);
        java.lang.String str31 = mota28.toString();
        Coordenada coordenada32 = mota28.getCoordenadas();
        Mota mota34 = new Mota((int) ' ', (double) 100.0f, (int) (byte) -1, "", coordenada32, false);
        mota3.setCoordenadas(coordenada32);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota34 and mota22", (mota34.compareTo(mota22) == 0) == mota34.equals(mota22));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test087");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setVelocidadeMedia((int) '4');
        Mota mota6 = new Mota();
        mota6.setMatricula("");
        java.lang.String str9 = mota6.toString();
        Mota mota10 = mota6.clone();
        Mota mota23 = new Mota();
        mota23.setMatricula("");
        Mota mota26 = mota23.clone();
        mota23.setPrecoBase((double) 0L);
        Mota mota29 = new Mota();
        int i30 = mota29.getLugares();
        int i31 = mota23.compareTo((Veiculo) mota29);
        java.lang.String str32 = mota29.toString();
        Coordenada coordenada33 = mota29.getCoordenadas();
        Mota mota35 = new Mota((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada33, false);
        Mota mota37 = new Mota((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada33, true);
        Mota mota39 = new Mota((int) '#', 10.0d, (-1), "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada33, true);
        Coordenada coordenada40 = mota39.getCoordenadas();
        mota10.setCoordenadas(coordenada40);
        double d42 = mota10.getPrecoBase();
        Mota mota43 = new Mota(mota10);
        int i44 = mota0.compareTo((Veiculo) mota10);
        mota10.setFiabilidade((int) ' ');
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota23 and mota0", (mota23.compareTo(mota0) == 0) == mota23.equals(mota0));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test088");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        Mota mota4 = new Mota(mota0);
        int i5 = mota0.getVelocidadeMedia();
        java.lang.String str6 = mota0.getMatricula();
        mota0.setVelocidadeMedia((int) (byte) 1);
        Mota mota9 = new Mota(mota0);
        mota0.setMatricula("Matrícula: Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 35km/h\nPreço Base: 10.0€\nFiabilidade: -1\nLugares: 1\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n");
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota9 and mota4", (mota9.compareTo(mota4) == 0) == mota9.equals(mota4));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test089");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        Mota mota4 = new Mota(mota0);
        int i5 = mota0.getVelocidadeMedia();
        java.lang.String str6 = mota0.getMatricula();
        mota0.setFiabilidade((int) ' ');
        Mota mota9 = new Mota();
        mota9.setMatricula("");
        Mota mota12 = mota9.clone();
        mota9.setPrecoBase((double) 0L);
        Mota mota15 = new Mota(mota9);
        Mota mota16 = mota9.clone();
        Mota mota17 = new Mota(mota16);
        boolean b18 = mota0.equals((java.lang.Object) mota16);
        Coordenada coordenada19 = mota16.getCoordenadas();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota0 and mota4", (mota0.compareTo(mota4) == 0) == mota0.equals(mota4));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test090");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        Mota mota4 = new Mota(mota0);
        int i5 = mota0.getVelocidadeMedia();
        java.lang.String str6 = mota0.getMatricula();
        mota0.setFiabilidade((int) ' ');
        int i9 = mota0.getVelocidadeMedia();
        Mota mota18 = new Mota();
        mota18.setMatricula("");
        java.lang.String str21 = mota18.toString();
        Mota mota22 = new Mota();
        Mota mota23 = new Mota(mota22);
        java.lang.String str24 = mota22.toString();
        mota22.setFiabilidade(0);
        Mota mota27 = mota22.clone();
        Mota mota28 = new Mota();
        Mota mota29 = new Mota(mota28);
        Mota mota30 = new Mota(mota29);
        Mota mota31 = new Mota();
        Mota mota32 = new Mota(mota31);
        int i33 = mota29.compareTo((Veiculo) mota31);
        Mota mota34 = new Mota();
        mota34.setMatricula("");
        boolean b38 = mota34.equals((java.lang.Object) (-1.0d));
        boolean b39 = mota29.equals((java.lang.Object) (-1.0d));
        Mota mota40 = new Mota();
        mota40.setMatricula("");
        Mota mota43 = mota40.clone();
        mota40.setPrecoBase((double) 0L);
        Mota mota46 = new Mota();
        int i47 = mota46.getLugares();
        int i48 = mota40.compareTo((Veiculo) mota46);
        java.lang.String str49 = mota46.toString();
        Coordenada coordenada50 = mota46.getCoordenadas();
        mota29.setCoordenadas(coordenada50);
        mota22.setCoordenadas(coordenada50);
        mota18.setCoordenadas(coordenada50);
        Mota mota55 = new Mota((int) (byte) 0, (double) 100L, (int) (byte) -1, "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada50, false);
        Mota mota57 = new Mota((int) (byte) 10, (double) (byte) -1, (int) '#', "Matrícula: Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada50, true);
        mota0.setCoordenadas(coordenada50);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota28 and mota4", (mota28.compareTo(mota4) == 0) == mota28.equals(mota4));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test091");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        Mota mota4 = new Mota(mota0);
        int i5 = mota0.getVelocidadeMedia();
        mota0.setMatricula("");
        Mota mota8 = new Mota();
        mota8.setMatricula("");
        Mota mota11 = mota8.clone();
        mota8.setPrecoBase((double) 0L);
        Mota mota14 = new Mota(mota8);
        int i15 = mota8.getLugares();
        Mota mota16 = new Mota();
        int i17 = mota16.getLugares();
        mota16.setVelocidadeMedia(10);
        mota16.setMatricula("n/a");
        mota16.setPrecoBase((double) 1L);
        Coordenada coordenada24 = mota16.getCoordenadas();
        mota8.setCoordenadas(coordenada24);
        mota0.setCoordenadas(coordenada24);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota16 and mota4", (mota16.compareTo(mota4) == 0) == mota16.equals(mota4));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test092");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        Mota mota4 = new Mota(mota3);
        int i5 = mota1.compareTo((Veiculo) mota3);
        int i6 = mota3.getVelocidadeMedia();
        Mota mota7 = mota3.clone();
        int i8 = mota7.getFiabilidade();
        int i9 = mota7.getFiabilidade();
        Mota mota10 = new Mota(mota7);
        int i11 = mota10.getLugares();
        mota10.setFiabilidade(32);
        Mota mota18 = new Mota();
        mota18.setMatricula("");
        Mota mota21 = mota18.clone();
        mota18.setPrecoBase((double) 0L);
        Mota mota24 = new Mota();
        int i25 = mota24.getLugares();
        int i26 = mota18.compareTo((Veiculo) mota24);
        java.lang.String str27 = mota24.toString();
        Coordenada coordenada28 = mota24.getCoordenadas();
        Mota mota30 = new Mota((int) (byte) 100, (double) '#', (int) (short) 0, "", coordenada28, false);
        int i31 = mota30.getLugares();
        Coordenada coordenada32 = mota30.getCoordenadas();
        mota10.setCoordenadas(coordenada32);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota30 and mota18", (mota30.compareTo(mota18) == 0) == mota30.equals(mota18));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test093");
        Mota mota4 = new Mota();
        mota4.setMatricula("");
        Mota mota7 = mota4.clone();
        int i8 = mota7.getVelocidadeMedia();
        Coordenada coordenada9 = mota7.getCoordenadas();
        Mota mota11 = new Mota((int) (short) 10, 1.0d, (int) ' ', "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada9, false);
        Mota mota16 = new Mota();
        mota16.setMatricula("");
        Mota mota19 = mota16.clone();
        mota16.setPrecoBase((double) 0L);
        Mota mota22 = new Mota();
        int i23 = mota22.getLugares();
        int i24 = mota16.compareTo((Veiculo) mota22);
        java.lang.String str25 = mota22.toString();
        Coordenada coordenada26 = mota22.getCoordenadas();
        Mota mota28 = new Mota((int) (byte) 100, (double) '#', (int) (short) 0, "", coordenada26, false);
        mota11.setCoordenadas(coordenada26);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota16 and mota28", (mota16.compareTo(mota28) == 0) == mota16.equals(mota28));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test094");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setVelocidadeMedia((int) '4');
        Mota mota6 = new Mota();
        mota6.setMatricula("");
        java.lang.String str9 = mota6.toString();
        Mota mota10 = mota6.clone();
        Mota mota23 = new Mota();
        mota23.setMatricula("");
        Mota mota26 = mota23.clone();
        mota23.setPrecoBase((double) 0L);
        Mota mota29 = new Mota();
        int i30 = mota29.getLugares();
        int i31 = mota23.compareTo((Veiculo) mota29);
        java.lang.String str32 = mota29.toString();
        Coordenada coordenada33 = mota29.getCoordenadas();
        Mota mota35 = new Mota((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada33, false);
        Mota mota37 = new Mota((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada33, true);
        Mota mota39 = new Mota((int) '#', 10.0d, (-1), "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada33, true);
        Coordenada coordenada40 = mota39.getCoordenadas();
        mota10.setCoordenadas(coordenada40);
        double d42 = mota10.getPrecoBase();
        Mota mota43 = new Mota(mota10);
        int i44 = mota0.compareTo((Veiculo) mota10);
        java.lang.String str45 = mota10.toString();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota26 and mota0", (mota26.compareTo(mota0) == 0) == mota26.equals(mota0));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test095");
        Mota mota12 = new Mota();
        mota12.setMatricula("");
        boolean b16 = mota12.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada17 = mota12.getCoordenadas();
        mota12.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        mota12.setFiabilidade(0);
        Mota mota22 = new Mota();
        mota22.setMatricula("");
        Mota mota25 = mota22.clone();
        mota22.setPrecoBase((double) 0L);
        Mota mota28 = new Mota(mota22);
        int i29 = mota12.compareTo((Veiculo) mota22);
        Mota mota30 = new Mota(mota22);
        Coordenada coordenada31 = mota30.getCoordenadas();
        Mota mota33 = new Mota((int) (byte) 0, (double) 0L, (int) (byte) 0, "n/a", coordenada31, true);
        Mota mota35 = new Mota((int) (byte) 0, (double) (short) 100, (int) (short) 10, "Matrícula: Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada31, true);
        Mota mota37 = new Mota((int) (short) 10, (double) '4', (int) ' ', "Matrícula: Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 100.0€\nFiabilidade: 10\nLugares: 1\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada31, false);
        Mota mota38 = new Mota();
        int i39 = mota38.getLugares();
        mota38.setVelocidadeMedia(10);
        Coordenada coordenada42 = mota38.getCoordenadas();
        mota37.setCoordenadas(coordenada42);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota38 and mota33", (mota38.compareTo(mota33) == 0) == mota38.equals(mota33));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test096");
        Mota mota8 = new Mota();
        mota8.setMatricula("");
        Mota mota11 = mota8.clone();
        mota8.setPrecoBase((double) 0L);
        Mota mota14 = new Mota();
        int i15 = mota14.getLugares();
        int i16 = mota8.compareTo((Veiculo) mota14);
        java.lang.String str17 = mota14.toString();
        Coordenada coordenada18 = mota14.getCoordenadas();
        Mota mota20 = new Mota((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, false);
        Mota mota22 = new Mota((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, true);
        Mota mota23 = new Mota();
        mota23.setVelocidadeMedia((int) ' ');
        java.lang.String str26 = mota23.toString();
        boolean b27 = mota22.equals((java.lang.Object) mota23);
        Coordenada coordenada28 = mota22.getCoordenadas();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota14 and mota23", (mota14.compareTo(mota23) == 0) == mota14.equals(mota23));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test097");
        Mota mota0 = new Mota();
        mota0.setVelocidadeMedia((int) ' ');
        java.lang.String str3 = mota0.toString();
        Mota mota8 = new Mota();
        mota8.setMatricula("");
        Mota mota11 = mota8.clone();
        Coordenada coordenada12 = mota11.getCoordenadas();
        Mota mota14 = new Mota((int) (byte) 0, (double) 'a', 3, "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada12, false);
        boolean b15 = mota0.equals((java.lang.Object) 'a');
        mota0.setVelocidadeMedia((int) (byte) 100);
        Mota mota18 = new Mota();
        Mota mota19 = new Mota(mota18);
        Mota mota20 = new Mota(mota19);
        int i21 = mota20.getLugares();
        int i22 = mota0.compareTo((Veiculo) mota20);
        Mota mota23 = new Mota();
        Mota mota24 = new Mota(mota23);
        Mota mota25 = new Mota(mota24);
        Mota mota26 = new Mota();
        Mota mota27 = new Mota(mota26);
        int i28 = mota24.compareTo((Veiculo) mota26);
        mota24.setVelocidadeMedia((int) (short) 100);
        java.lang.String str31 = mota24.getMatricula();
        double d32 = mota24.getPrecoBase();
        mota24.setFiabilidade((-3));
        boolean b35 = mota20.equals((java.lang.Object) (-3));
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota18 and mota0", (mota18.compareTo(mota0) == 0) == mota18.equals(mota0));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test098");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota();
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota(mota2);
        Mota mota4 = new Mota();
        Mota mota5 = new Mota(mota4);
        int i6 = mota2.compareTo((Veiculo) mota4);
        Mota mota11 = new Mota();
        mota11.setMatricula("");
        Mota mota14 = mota11.clone();
        mota11.setPrecoBase((double) 0L);
        Mota mota17 = new Mota();
        int i18 = mota17.getLugares();
        int i19 = mota11.compareTo((Veiculo) mota17);
        java.lang.String str20 = mota17.toString();
        Coordenada coordenada21 = mota17.getCoordenadas();
        Mota mota23 = new Mota((int) ' ', (double) 100.0f, (int) (byte) -1, "", coordenada21, false);
        int i24 = mota2.compareTo((Veiculo) mota23);
        boolean b25 = mota0.equals((java.lang.Object) mota2);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota14 and mota23", (mota14.compareTo(mota23) == 0) == mota14.equals(mota23));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test099");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        java.lang.String str2 = mota0.toString();
        mota0.setFiabilidade(0);
        Mota mota5 = mota0.clone();
        mota0.setPrecoBase((double) 0.0f);
        Mota mota12 = new Mota();
        mota12.setMatricula("");
        Mota mota15 = mota12.clone();
        Coordenada coordenada16 = mota15.getCoordenadas();
        Mota mota18 = new Mota((int) (byte) -1, (double) 0, (int) (short) 1, "", coordenada16, false);
        boolean b19 = mota0.equals((java.lang.Object) (byte) -1);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota18 and mota15", (mota18.compareTo(mota15) == 0) == mota18.equals(mota15));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test100");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setVelocidadeMedia((int) '4');
        Mota mota6 = new Mota();
        mota6.setMatricula("");
        java.lang.String str9 = mota6.toString();
        Mota mota10 = mota6.clone();
        Mota mota23 = new Mota();
        mota23.setMatricula("");
        Mota mota26 = mota23.clone();
        mota23.setPrecoBase((double) 0L);
        Mota mota29 = new Mota();
        int i30 = mota29.getLugares();
        int i31 = mota23.compareTo((Veiculo) mota29);
        java.lang.String str32 = mota29.toString();
        Coordenada coordenada33 = mota29.getCoordenadas();
        Mota mota35 = new Mota((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada33, false);
        Mota mota37 = new Mota((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada33, true);
        Mota mota39 = new Mota((int) '#', 10.0d, (-1), "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada33, true);
        Coordenada coordenada40 = mota39.getCoordenadas();
        mota10.setCoordenadas(coordenada40);
        double d42 = mota10.getPrecoBase();
        Mota mota43 = new Mota(mota10);
        int i44 = mota0.compareTo((Veiculo) mota10);
        mota10.setFiabilidade(1);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota6 and mota0", (mota6.compareTo(mota0) == 0) == mota6.equals(mota0));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test101");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        Mota mota4 = new Mota(mota3);
        int i5 = mota1.compareTo((Veiculo) mota3);
        Mota mota6 = new Mota();
        mota6.setMatricula("");
        boolean b10 = mota6.equals((java.lang.Object) (-1.0d));
        boolean b11 = mota1.equals((java.lang.Object) (-1.0d));
        Mota mota12 = new Mota(mota1);
        mota1.setVelocidadeMedia((int) (byte) -1);
        mota1.setVelocidadeMedia((int) (short) 10);
        Mota mota17 = new Mota();
        int i18 = mota17.getLugares();
        mota17.setVelocidadeMedia(10);
        Mota mota21 = new Mota(mota17);
        Mota mota22 = new Mota(mota21);
        int i23 = mota1.compareTo((Veiculo) mota21);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota0 and mota17", (mota0.compareTo(mota17) == 0) == mota0.equals(mota17));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test102");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        Mota mota4 = new Mota(mota0);
        int i5 = mota0.getVelocidadeMedia();
        java.lang.String str6 = mota0.getMatricula();
        int i7 = mota0.getVelocidadeMedia();
        Mota mota8 = new Mota();
        Mota mota9 = new Mota(mota8);
        Mota mota10 = new Mota(mota9);
        Mota mota11 = new Mota();
        Mota mota12 = new Mota(mota11);
        int i13 = mota9.compareTo((Veiculo) mota11);
        java.lang.String str14 = mota11.getMatricula();
        int i15 = mota11.getLugares();
        int i16 = mota0.compareTo((Veiculo) mota11);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota9 and mota4", (mota9.compareTo(mota4) == 0) == mota9.equals(mota4));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test103");
        Mota mota8 = new Mota();
        mota8.setMatricula("");
        Mota mota11 = mota8.clone();
        mota8.setPrecoBase((double) 0L);
        Mota mota14 = new Mota();
        int i15 = mota14.getLugares();
        int i16 = mota8.compareTo((Veiculo) mota14);
        java.lang.String str17 = mota14.toString();
        Coordenada coordenada18 = mota14.getCoordenadas();
        Mota mota20 = new Mota(10, (double) (short) -1, (int) (byte) 1, "", coordenada18, false);
        Mota mota22 = new Mota(0, (double) 100L, 27, "Matrícula: Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, false);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota8 and mota20", (mota8.compareTo(mota20) == 0) == mota8.equals(mota20));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test104");
        Mota mota4 = new Mota();
        mota4.setMatricula("");
        Mota mota7 = mota4.clone();
        mota4.setPrecoBase((double) 0L);
        Mota mota10 = new Mota();
        int i11 = mota10.getLugares();
        int i12 = mota4.compareTo((Veiculo) mota10);
        java.lang.String str13 = mota10.toString();
        Coordenada coordenada14 = mota10.getCoordenadas();
        Mota mota16 = new Mota((int) 'a', (double) 3, 0, "", coordenada14, true);
        Mota mota17 = new Mota();
        Mota mota18 = new Mota(mota17);
        Mota mota19 = new Mota(mota18);
        Mota mota20 = new Mota();
        Mota mota21 = new Mota(mota20);
        int i22 = mota18.compareTo((Veiculo) mota20);
        Mota mota23 = new Mota(mota20);
        mota23.setVelocidadeMedia(32);
        Mota mota30 = new Mota();
        mota30.setMatricula("");
        Mota mota33 = mota30.clone();
        mota30.setPrecoBase((double) 0L);
        Mota mota36 = new Mota();
        int i37 = mota36.getLugares();
        int i38 = mota30.compareTo((Veiculo) mota36);
        java.lang.String str39 = mota36.toString();
        Coordenada coordenada40 = mota36.getCoordenadas();
        Mota mota42 = new Mota((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada40, false);
        mota42.setPrecoBase((double) 10.0f);
        int i45 = mota42.getVelocidadeMedia();
        int i46 = mota23.compareTo((Veiculo) mota42);
        boolean b47 = mota16.equals((java.lang.Object) mota42);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota21 and mota23", (mota21.compareTo(mota23) == 0) == mota21.equals(mota23));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test105");
        Mota mota4 = new Mota();
        Mota mota5 = new Mota(mota4);
        Mota mota6 = new Mota(mota5);
        mota5.setVelocidadeMedia(0);
        mota5.setFiabilidade(10);
        Coordenada coordenada11 = mota5.getCoordenadas();
        Mota mota13 = new Mota(0, 0.0d, (int) '#', "", coordenada11, true);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota4 and mota5", (mota4.compareTo(mota5) == 0) == mota4.equals(mota5));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test106");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        int i4 = mota3.getLugares();
        boolean b5 = mota2.equals((java.lang.Object) mota3);
        mota3.setFiabilidade(100);
        Mota mota8 = mota3.clone();
        Mota mota9 = new Mota();
        mota9.setMatricula("");
        Mota mota12 = mota9.clone();
        mota9.setPrecoBase((double) 0L);
        Mota mota15 = new Mota();
        int i16 = mota15.getLugares();
        int i17 = mota9.compareTo((Veiculo) mota15);
        java.lang.String str18 = mota15.toString();
        int i19 = mota15.getFiabilidade();
        mota15.setPrecoBase(10.0d);
        int i22 = mota15.getFiabilidade();
        Mota mota23 = new Mota();
        mota23.setMatricula("");
        Mota mota26 = mota23.clone();
        mota23.setPrecoBase((double) 0L);
        Mota mota29 = new Mota();
        int i30 = mota29.getLugares();
        int i31 = mota23.compareTo((Veiculo) mota29);
        java.lang.String str32 = mota29.toString();
        int i33 = mota29.getFiabilidade();
        mota29.setPrecoBase(10.0d);
        Coordenada coordenada36 = mota29.getCoordenadas();
        mota15.setCoordenadas(coordenada36);
        mota3.setCoordenadas(coordenada36);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota1 and mota8", (mota1.compareTo(mota8) == 0) == mota1.equals(mota8));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test107");
        Mota mota4 = new Mota();
        mota4.setMatricula("");
        boolean b8 = mota4.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada9 = mota4.getCoordenadas();
        mota4.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        mota4.setFiabilidade(0);
        Mota mota14 = new Mota();
        mota14.setMatricula("");
        Mota mota17 = mota14.clone();
        mota14.setPrecoBase((double) 0L);
        Mota mota20 = new Mota(mota14);
        int i21 = mota4.compareTo((Veiculo) mota14);
        Mota mota22 = new Mota(mota14);
        Coordenada coordenada23 = mota22.getCoordenadas();
        Mota mota25 = new Mota((int) (byte) 0, (double) 0L, (int) (byte) 0, "n/a", coordenada23, true);
        int i26 = mota25.getFiabilidade();
        Mota mota31 = new Mota();
        int i32 = mota31.getLugares();
        mota31.setVelocidadeMedia(10);
        Mota mota35 = new Mota(mota31);
        Coordenada coordenada36 = mota31.getCoordenadas();
        Mota mota38 = new Mota((int) 'a', (double) 0.0f, (int) (byte) -1, "", coordenada36, false);
        mota25.setCoordenadas(coordenada36);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota20 and mota38", (mota20.compareTo(mota38) == 0) == mota20.equals(mota38));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test108");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota(mota0);
        Mota mota7 = mota0.clone();
        Mota mota8 = new Mota();
        int i9 = mota8.getLugares();
        mota8.setVelocidadeMedia(10);
        Mota mota12 = new Mota(mota8);
        Mota mota13 = new Mota(mota12);
        boolean b14 = mota0.equals((java.lang.Object) mota12);
        Mota mota15 = new Mota();
        mota15.setMatricula("");
        Mota mota18 = mota15.clone();
        mota15.setPrecoBase((double) 0L);
        Mota mota21 = new Mota();
        int i22 = mota21.getLugares();
        int i23 = mota15.compareTo((Veiculo) mota21);
        java.lang.String str24 = mota21.toString();
        int i25 = mota21.getFiabilidade();
        mota21.setPrecoBase(10.0d);
        int i28 = mota21.getFiabilidade();
        boolean b29 = mota12.equals((java.lang.Object) mota21);
        boolean b31 = mota12.equals((java.lang.Object) "Matrícula: \nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota8 and mota21", (mota8.compareTo(mota21) == 0) == mota8.equals(mota21));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test109");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        java.lang.String str9 = mota6.toString();
        int i10 = mota6.getFiabilidade();
        mota6.setPrecoBase(10.0d);
        int i13 = mota6.getVelocidadeMedia();
        Mota mota14 = new Mota(mota6);
        mota6.setVelocidadeMedia(1);
        int i17 = mota6.getLugares();
        Mota mota18 = new Mota();
        mota18.setMatricula("");
        Mota mota21 = mota18.clone();
        mota18.setPrecoBase((double) 0L);
        double d24 = mota18.getPrecoBase();
        Mota mota25 = mota18.clone();
        Mota mota26 = new Mota();
        mota26.setMatricula("");
        boolean b30 = mota26.equals((java.lang.Object) (-1.0d));
        Mota mota31 = new Mota(mota26);
        double d32 = mota26.getPrecoBase();
        boolean b33 = mota26.getOcupado();
        mota26.setOcupado(false);
        Mota mota36 = new Mota();
        int i37 = mota36.getLugares();
        mota36.setVelocidadeMedia(10);
        Mota mota40 = new Mota(mota36);
        Mota mota41 = mota40.clone();
        boolean b42 = mota26.equals((java.lang.Object) mota40);
        int i43 = mota25.compareTo((Veiculo) mota40);
        int i44 = mota6.compareTo((Veiculo) mota25);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota40 and mota14", (mota40.compareTo(mota14) == 0) == mota40.equals(mota14));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test110");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = mota0.getCoordenadas();
        mota0.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        mota0.setFiabilidade(0);
        Mota mota10 = new Mota();
        mota10.setMatricula("");
        Mota mota13 = mota10.clone();
        mota10.setPrecoBase((double) 0L);
        Mota mota16 = new Mota(mota10);
        int i17 = mota0.compareTo((Veiculo) mota10);
        Mota mota18 = new Mota(mota10);
        mota18.setOcupado(false);
        Mota mota33 = new Mota();
        mota33.setMatricula("");
        Mota mota36 = mota33.clone();
        mota33.setPrecoBase((double) 0L);
        Mota mota39 = new Mota();
        int i40 = mota39.getLugares();
        int i41 = mota33.compareTo((Veiculo) mota39);
        java.lang.String str42 = mota39.toString();
        Coordenada coordenada43 = mota39.getCoordenadas();
        Mota mota45 = new Mota((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada43, false);
        Mota mota47 = new Mota((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada43, true);
        Mota mota49 = new Mota((int) '#', 10.0d, (-1), "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada43, true);
        mota18.setCoordenadas(coordenada43);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota0 and mota45", (mota0.compareTo(mota45) == 0) == mota0.equals(mota45));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test111");
        Mota mota0 = new Mota();
        mota0.setVelocidadeMedia((int) ' ');
        java.lang.String str3 = mota0.toString();
        int i4 = mota0.getVelocidadeMedia();
        Mota mota21 = new Mota();
        mota21.setMatricula("");
        java.lang.String str24 = mota21.toString();
        Mota mota25 = new Mota();
        Mota mota26 = new Mota(mota25);
        java.lang.String str27 = mota25.toString();
        mota25.setFiabilidade(0);
        Mota mota30 = mota25.clone();
        Mota mota31 = new Mota();
        Mota mota32 = new Mota(mota31);
        Mota mota33 = new Mota(mota32);
        Mota mota34 = new Mota();
        Mota mota35 = new Mota(mota34);
        int i36 = mota32.compareTo((Veiculo) mota34);
        Mota mota37 = new Mota();
        mota37.setMatricula("");
        boolean b41 = mota37.equals((java.lang.Object) (-1.0d));
        boolean b42 = mota32.equals((java.lang.Object) (-1.0d));
        Mota mota43 = new Mota();
        mota43.setMatricula("");
        Mota mota46 = mota43.clone();
        mota43.setPrecoBase((double) 0L);
        Mota mota49 = new Mota();
        int i50 = mota49.getLugares();
        int i51 = mota43.compareTo((Veiculo) mota49);
        java.lang.String str52 = mota49.toString();
        Coordenada coordenada53 = mota49.getCoordenadas();
        mota32.setCoordenadas(coordenada53);
        mota25.setCoordenadas(coordenada53);
        mota21.setCoordenadas(coordenada53);
        Mota mota58 = new Mota((int) (byte) 0, (double) 100L, (int) (byte) -1, "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada53, false);
        Mota mota60 = new Mota((int) (byte) 10, (double) (byte) -1, (int) '#', "Matrícula: Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada53, true);
        Mota mota62 = new Mota(1, (double) (short) -1, 0, "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada53, true);
        Mota mota64 = new Mota(10, (double) 'a', (int) (byte) 1, "n/a", coordenada53, true);
        mota0.setCoordenadas(coordenada53);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota26 and mota64", (mota26.compareTo(mota64) == 0) == mota26.equals(mota64));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test112");
        Mota mota4 = new Mota();
        mota4.setMatricula("");
        Mota mota7 = mota4.clone();
        mota4.setPrecoBase((double) 0L);
        Mota mota10 = new Mota();
        int i11 = mota10.getLugares();
        int i12 = mota4.compareTo((Veiculo) mota10);
        java.lang.String str13 = mota10.toString();
        Coordenada coordenada14 = mota10.getCoordenadas();
        Mota mota16 = new Mota((int) 'a', (double) 3, 0, "", coordenada14, true);
        Mota mota17 = new Mota();
        mota17.setMatricula("");
        boolean b21 = mota17.equals((java.lang.Object) (-1.0d));
        Mota mota22 = new Mota(mota17);
        double d23 = mota17.getPrecoBase();
        boolean b24 = mota17.getOcupado();
        int i25 = mota17.getVelocidadeMedia();
        java.lang.String str26 = mota17.getMatricula();
        mota17.setMatricula("hi!");
        int i29 = mota16.compareTo((Veiculo) mota17);
        Mota mota30 = new Mota();
        Mota mota31 = new Mota(mota30);
        Mota mota32 = new Mota(mota31);
        Mota mota33 = new Mota();
        Mota mota34 = new Mota(mota33);
        int i35 = mota31.compareTo((Veiculo) mota33);
        Mota mota36 = new Mota(mota33);
        mota36.setVelocidadeMedia(32);
        boolean b39 = mota17.equals((java.lang.Object) mota36);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota4 and mota16", (mota4.compareTo(mota16) == 0) == mota4.equals(mota16));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test113");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        int i9 = mota6.getFiabilidade();
        Mota mota10 = mota6.clone();
        Mota mota11 = new Mota();
        mota11.setVelocidadeMedia((int) ' ');
        java.lang.String str14 = mota11.toString();
        int i15 = mota11.getVelocidadeMedia();
        boolean b16 = mota11.getOcupado();
        java.lang.String str17 = mota11.toString();
        Mota mota18 = new Mota();
        mota18.setMatricula("");
        boolean b22 = mota18.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada23 = mota18.getCoordenadas();
        java.lang.String str24 = mota18.toString();
        double d25 = mota18.getPrecoBase();
        mota18.setFiabilidade((int) ' ');
        int i28 = mota11.compareTo((Veiculo) mota18);
        boolean b29 = mota6.equals((java.lang.Object) mota18);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota10 and mota11", (mota10.compareTo(mota11) == 0) == mota10.equals(mota11));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test114");
        Mota mota4 = new Mota();
        mota4.setMatricula("");
        int i7 = mota4.getVelocidadeMedia();
        mota4.setPrecoBase((double) (-3));
        java.lang.String str10 = mota4.toString();
        Mota mota15 = new Mota();
        mota15.setMatricula("");
        java.lang.String str18 = mota15.toString();
        Mota mota19 = new Mota();
        Mota mota20 = new Mota(mota19);
        java.lang.String str21 = mota19.toString();
        mota19.setFiabilidade(0);
        Mota mota24 = mota19.clone();
        Mota mota25 = new Mota();
        Mota mota26 = new Mota(mota25);
        Mota mota27 = new Mota(mota26);
        Mota mota28 = new Mota();
        Mota mota29 = new Mota(mota28);
        int i30 = mota26.compareTo((Veiculo) mota28);
        Mota mota31 = new Mota();
        mota31.setMatricula("");
        boolean b35 = mota31.equals((java.lang.Object) (-1.0d));
        boolean b36 = mota26.equals((java.lang.Object) (-1.0d));
        Mota mota37 = new Mota();
        mota37.setMatricula("");
        Mota mota40 = mota37.clone();
        mota37.setPrecoBase((double) 0L);
        Mota mota43 = new Mota();
        int i44 = mota43.getLugares();
        int i45 = mota37.compareTo((Veiculo) mota43);
        java.lang.String str46 = mota43.toString();
        Coordenada coordenada47 = mota43.getCoordenadas();
        mota26.setCoordenadas(coordenada47);
        mota19.setCoordenadas(coordenada47);
        mota15.setCoordenadas(coordenada47);
        Mota mota52 = new Mota((-33), (double) (short) 100, (int) (short) -1, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada47, false);
        mota4.setCoordenadas(coordenada47);
        Mota mota55 = new Mota(32, (double) (byte) 0, (int) '4', "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n", coordenada47, true);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota37 and mota4", (mota37.compareTo(mota4) == 0) == mota37.equals(mota4));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test115");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        java.lang.String str9 = mota6.toString();
        int i10 = mota6.getFiabilidade();
        mota6.setPrecoBase(10.0d);
        int i13 = mota6.getVelocidadeMedia();
        Mota mota14 = new Mota(mota6);
        int i15 = mota14.getVelocidadeMedia();
        Mota mota16 = new Mota();
        Mota mota17 = new Mota(mota16);
        java.lang.String str18 = mota16.toString();
        mota16.setFiabilidade(0);
        mota16.setOcupado(true);
        boolean b23 = mota16.getOcupado();
        mota16.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        int i26 = mota14.compareTo((Veiculo) mota16);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota17 and mota6", (mota17.compareTo(mota6) == 0) == mota17.equals(mota6));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test116");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        Mota mota4 = new Mota(mota3);
        int i5 = mota1.compareTo((Veiculo) mota3);
        int i6 = mota3.getVelocidadeMedia();
        Mota mota7 = mota3.clone();
        int i8 = mota7.getFiabilidade();
        int i9 = mota7.getFiabilidade();
        Mota mota10 = new Mota(mota7);
        int i11 = mota10.getFiabilidade();
        Mota mota16 = new Mota();
        mota16.setMatricula("");
        Mota mota19 = mota16.clone();
        mota16.setPrecoBase((double) 0L);
        Mota mota22 = new Mota();
        int i23 = mota22.getLugares();
        int i24 = mota16.compareTo((Veiculo) mota22);
        java.lang.String str25 = mota22.toString();
        Coordenada coordenada26 = mota22.getCoordenadas();
        Mota mota28 = new Mota((int) (byte) -1, 0.0d, (int) 'a', "", coordenada26, true);
        mota10.setCoordenadas(coordenada26);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota16 and mota28", (mota16.compareTo(mota28) == 0) == mota16.equals(mota28));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test117");
        Mota mota4 = new Mota();
        mota4.setMatricula("");
        Mota mota7 = mota4.clone();
        mota4.setPrecoBase((double) 0L);
        Mota mota10 = new Mota();
        int i11 = mota10.getLugares();
        int i12 = mota4.compareTo((Veiculo) mota10);
        java.lang.String str13 = mota10.toString();
        Coordenada coordenada14 = mota10.getCoordenadas();
        Mota mota16 = new Mota((int) (byte) 100, (double) '#', (int) (short) 0, "", coordenada14, false);
        int i17 = mota16.getLugares();
        Mota mota18 = new Mota();
        mota18.setMatricula("");
        Mota mota21 = mota18.clone();
        mota18.setPrecoBase((double) 0L);
        Mota mota24 = new Mota();
        int i25 = mota24.getLugares();
        int i26 = mota18.compareTo((Veiculo) mota24);
        java.lang.String str27 = mota24.toString();
        int i28 = mota24.getFiabilidade();
        mota24.setPrecoBase(10.0d);
        Mota mota31 = mota24.clone();
        int i32 = mota24.getFiabilidade();
        Coordenada coordenada33 = mota24.getCoordenadas();
        mota16.setCoordenadas(coordenada33);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota24 and mota10", (mota24.compareTo(mota10) == 0) == mota24.equals(mota10));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test118");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        int i4 = mota3.getLugares();
        boolean b5 = mota2.equals((java.lang.Object) mota3);
        Mota mota6 = mota3.clone();
        mota6.setVelocidadeMedia((int) (short) 0);
        java.lang.String str9 = mota6.toString();
        Mota mota10 = new Mota();
        mota10.setVelocidadeMedia((int) ' ');
        java.lang.String str13 = mota10.toString();
        int i14 = mota10.getVelocidadeMedia();
        boolean b15 = mota10.getOcupado();
        java.lang.String str16 = mota10.toString();
        Mota mota17 = new Mota();
        mota17.setMatricula("");
        boolean b21 = mota17.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada22 = mota17.getCoordenadas();
        java.lang.String str23 = mota17.toString();
        double d24 = mota17.getPrecoBase();
        mota17.setFiabilidade((int) ' ');
        int i27 = mota10.compareTo((Veiculo) mota17);
        boolean b28 = mota6.equals((java.lang.Object) mota10);
        Mota mota29 = new Mota();
        int i30 = mota29.getLugares();
        mota29.setVelocidadeMedia(10);
        Mota mota33 = new Mota(mota29);
        Coordenada coordenada34 = mota29.getCoordenadas();
        boolean b35 = mota10.equals((java.lang.Object) mota29);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota33 and mota1", (mota33.compareTo(mota1) == 0) == mota33.equals(mota1));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test119");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        Mota mota4 = new Mota(mota0);
        int i5 = mota0.getVelocidadeMedia();
        java.lang.String str6 = mota0.getMatricula();
        mota0.setFiabilidade((int) ' ');
        Mota mota9 = new Mota();
        mota9.setMatricula("");
        Mota mota12 = mota9.clone();
        mota9.setPrecoBase((double) 0L);
        Mota mota15 = new Mota(mota9);
        Mota mota16 = mota9.clone();
        Mota mota17 = new Mota(mota16);
        boolean b18 = mota0.equals((java.lang.Object) mota16);
        boolean b19 = mota16.getOcupado();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on mota0 and mota4", (mota0.compareTo(mota4) == 0) == mota0.equals(mota4));
    }
}

