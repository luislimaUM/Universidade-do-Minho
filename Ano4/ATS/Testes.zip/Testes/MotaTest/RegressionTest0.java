import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        Coordenada coordenada4 = null;
        try {
            Mota mota6 = new Mota((int) (short) -1, (double) (short) 100, (int) '4', "hi!", coordenada4, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        Coordenada coordenada4 = null;
        try {
            Mota mota6 = new Mota(1, 100.0d, (int) (byte) 0, "hi!", coordenada4, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        Coordenada coordenada4 = null;
        try {
            Mota mota6 = new Mota((int) 'a', (double) 10, 100, "hi!", coordenada4, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        Coordenada coordenada4 = null;
        try {
            Mota mota6 = new Mota(0, (double) 100, 100, "", coordenada4, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        Coordenada coordenada4 = null;
        try {
            Mota mota6 = new Mota((int) (byte) -1, (double) 1.0f, 10, "", coordenada4, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Coordenada coordenada3 = null;
        try {
            mota2.setCoordenadas(coordenada3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        java.lang.String str2 = mota0.toString();
        mota0.setFiabilidade(0);
        Mota mota5 = mota0.clone();
        int i6 = mota0.getLugares();
        java.lang.Object obj7 = new java.lang.Object();
        boolean b8 = mota0.equals(obj7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(mota5);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertTrue(b8 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        Mota mota4 = new Mota(mota0);
        Mota mota5 = new Mota(mota4);
        mota4.setFiabilidade((int) '4');
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        int i4 = mota3.getLugares();
        boolean b5 = mota2.equals((java.lang.Object) mota3);
        mota3.setOcupado(true);
        int i8 = mota3.getVelocidadeMedia();
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue(b5 == true);
        org.junit.Assert.assertTrue(i8 == 0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        mota0.setFiabilidade((int) (byte) 0);
        Veiculo veiculo6 = null;
        try {
            int i7 = mota0.compareTo(veiculo6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        mota0.setPrecoBase((double) (byte) 10);
        java.lang.String str4 = mota0.getMatricula();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "n/a" + "'", str4.equals("n/a"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        int i4 = mota3.getLugares();
        boolean b5 = mota2.equals((java.lang.Object) mota3);
        Mota mota6 = mota3.clone();
        mota6.setOcupado(true);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue(b5 == true);
        org.junit.Assert.assertNotNull(mota6);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        int i4 = mota3.getLugares();
        boolean b5 = mota2.equals((java.lang.Object) mota3);
        mota3.setPrecoBase(0.0d);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue(b5 == true);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        java.lang.String str9 = mota6.toString();
        int i10 = mota6.getFiabilidade();
        mota6.setPrecoBase(10.0d);
        int i13 = mota6.getVelocidadeMedia();
        Mota mota14 = new Mota(mota6);
        boolean b15 = mota14.getOcupado();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(b15 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        Mota mota9 = new Mota(mota6);
        mota6.setOcupado(false);
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        mota0.setMatricula("n/a");
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        Coordenada coordenada8 = mota6.getCoordenadas();
        boolean b9 = mota0.equals((java.lang.Object) coordenada8);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertNotNull(coordenada8);
        org.junit.Assert.assertTrue(b9 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Mota mota5 = new Mota(mota0);
        double d6 = mota0.getPrecoBase();
        java.lang.String str7 = mota0.toString();
        int i8 = mota0.getVelocidadeMedia();
        int i9 = mota0.getVelocidadeMedia();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str7.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue(i9 == 0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Mota mota5 = new Mota(mota0);
        double d6 = mota0.getPrecoBase();
        boolean b7 = mota0.getOcupado();
        int i8 = mota0.getVelocidadeMedia();
        Mota mota9 = mota0.clone();
        int i10 = mota0.getLugares();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(b7 == false);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertNotNull(mota9);
        org.junit.Assert.assertTrue(i10 == 0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        Coordenada coordenada4 = null;
        try {
            Mota mota6 = new Mota(3, (-1.0d), (int) (short) -1, "", coordenada4, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        java.lang.String str6 = mota0.getMatricula();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        Coordenada coordenada4 = mota3.getCoordenadas();
        Mota mota5 = new Mota();
        mota5.setMatricula("");
        Mota mota8 = mota5.clone();
        mota5.setPrecoBase((double) 0L);
        Mota mota11 = new Mota();
        int i12 = mota11.getLugares();
        int i13 = mota5.compareTo((Veiculo) mota11);
        java.lang.String str14 = mota11.toString();
        Coordenada coordenada15 = mota11.getCoordenadas();
        int i16 = mota3.compareTo((Veiculo) mota11);
        java.lang.String str17 = mota3.getMatricula();
        mota3.setMatricula("");
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertNotNull(coordenada4);
        org.junit.Assert.assertNotNull(mota8);
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertTrue(i13 == 3);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str14.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada15);
        org.junit.Assert.assertTrue(i16 == 3);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        mota0.setVelocidadeMedia((int) (short) -1);
        org.junit.Assert.assertTrue(b4 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Mota mota5 = new Mota(mota0);
        double d6 = mota0.getPrecoBase();
        boolean b7 = mota0.getOcupado();
        int i8 = mota0.getVelocidadeMedia();
        Mota mota9 = mota0.clone();
        mota9.setFiabilidade((int) (byte) 10);
        mota9.setFiabilidade((int) (short) -1);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(b7 == false);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertNotNull(mota9);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        java.lang.String str2 = mota0.toString();
        mota0.setFiabilidade(0);
        Mota mota5 = mota0.clone();
        mota0.setFiabilidade((int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(mota5);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota3.setOcupado(true);
        int i6 = mota3.getFiabilidade();
        int i7 = mota3.getFiabilidade();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertTrue(i7 == 0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        Mota mota0 = null;
        try {
            Mota mota1 = new Mota(mota0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        Mota mota4 = new Mota();
        Mota mota5 = new Mota(mota4);
        Mota mota6 = new Mota(mota5);
        Mota mota7 = new Mota();
        Mota mota8 = new Mota(mota7);
        int i9 = mota5.compareTo((Veiculo) mota7);
        Mota mota10 = new Mota();
        mota10.setMatricula("");
        boolean b14 = mota10.equals((java.lang.Object) (-1.0d));
        boolean b15 = mota5.equals((java.lang.Object) (-1.0d));
        Mota mota16 = new Mota();
        mota16.setMatricula("");
        Mota mota19 = mota16.clone();
        mota16.setPrecoBase((double) 0L);
        Mota mota22 = new Mota();
        int i23 = mota22.getLugares();
        int i24 = mota16.compareTo((Veiculo) mota22);
        java.lang.String str25 = mota22.toString();
        Coordenada coordenada26 = mota22.getCoordenadas();
        mota5.setCoordenadas(coordenada26);
        Mota mota29 = new Mota((-1), 10.0d, (int) (byte) 1, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada26, true);
        Veiculo veiculo30 = null;
        try {
            int i31 = mota29.compareTo(veiculo30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertNotNull(mota19);
        org.junit.Assert.assertTrue(i23 == 0);
        org.junit.Assert.assertTrue(i24 == 3);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str25.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada26);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        Mota mota4 = new Mota(mota0);
        int i5 = mota0.getVelocidadeMedia();
        java.lang.String str6 = mota0.getMatricula();
        boolean b7 = mota0.getOcupado();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i5 == 10);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "n/a" + "'", str6.equals("n/a"));
        org.junit.Assert.assertTrue(b7 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Mota mota5 = new Mota(mota0);
        double d6 = mota0.getPrecoBase();
        java.lang.String str7 = mota0.toString();
        int i8 = mota0.getVelocidadeMedia();
        double d9 = mota0.getPrecoBase();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str7.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue(d9 == 0.0d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        java.lang.String str2 = mota0.toString();
        mota0.setFiabilidade(0);
        Mota mota5 = mota0.clone();
        Mota mota6 = new Mota(mota0);
        Mota mota7 = new Mota();
        mota7.setMatricula("");
        Mota mota10 = mota7.clone();
        Coordenada coordenada11 = mota10.getCoordenadas();
        mota6.setCoordenadas(coordenada11);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(mota5);
        org.junit.Assert.assertNotNull(mota10);
        org.junit.Assert.assertNotNull(coordenada11);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        java.lang.String str9 = mota6.toString();
        int i10 = mota6.getFiabilidade();
        mota6.setPrecoBase(10.0d);
        int i13 = mota6.getVelocidadeMedia();
        Mota mota14 = new Mota(mota6);
        mota14.setFiabilidade((int) (short) 10);
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i13 == 0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        Mota mota9 = new Mota(mota6);
        int i10 = mota9.getLugares();
        mota9.setPrecoBase((double) (-1));
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue(i10 == 0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        java.lang.String str2 = mota0.getMatricula();
        Mota mota3 = new Mota(mota0);
        mota0.setOcupado(true);
        java.lang.String str6 = mota0.toString();
        Mota mota7 = new Mota();
        int i8 = mota7.getLugares();
        java.lang.String str9 = mota7.getMatricula();
        Mota mota10 = new Mota(mota7);
        int i11 = mota10.getFiabilidade();
        boolean b12 = mota0.equals((java.lang.Object) i11);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "n/a" + "'", str2.equals("n/a"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n" + "'", str6.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n"));
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "n/a" + "'", str9.equals("n/a"));
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(b12 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = mota0.getCoordenadas();
        java.lang.String str6 = mota0.toString();
        double d7 = mota0.getPrecoBase();
        Mota mota12 = new Mota();
        mota12.setMatricula("");
        boolean b16 = mota12.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada17 = mota12.getCoordenadas();
        mota12.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        mota12.setFiabilidade(0);
        Mota mota22 = new Mota();
        mota22.setMatricula("");
        Mota mota25 = mota22.clone();
        mota22.setPrecoBase((double) 0L);
        Mota mota28 = new Mota(mota22);
        int i29 = mota12.compareTo((Veiculo) mota22);
        Mota mota30 = new Mota(mota22);
        Coordenada coordenada31 = mota30.getCoordenadas();
        Mota mota33 = new Mota((int) (byte) 0, (double) 0L, (int) (byte) 0, "n/a", coordenada31, true);
        boolean b34 = mota0.equals((java.lang.Object) (byte) 0);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str6.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(d7 == 0.0d);
        org.junit.Assert.assertTrue(b16 == false);
        org.junit.Assert.assertNotNull(coordenada17);
        org.junit.Assert.assertNotNull(mota25);
        org.junit.Assert.assertTrue(i29 == (-142));
        org.junit.Assert.assertNotNull(coordenada31);
        org.junit.Assert.assertTrue(b34 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = mota0.getCoordenadas();
        boolean b6 = mota0.getOcupado();
        java.lang.String str7 = mota0.getMatricula();
        Mota mota12 = new Mota();
        mota12.setMatricula("");
        Mota mota15 = mota12.clone();
        mota12.setPrecoBase((double) 0L);
        Mota mota18 = new Mota();
        int i19 = mota18.getLugares();
        int i20 = mota12.compareTo((Veiculo) mota18);
        java.lang.String str21 = mota18.toString();
        Coordenada coordenada22 = mota18.getCoordenadas();
        Mota mota24 = new Mota((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada22, false);
        mota0.setCoordenadas(coordenada22);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(b6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(mota15);
        org.junit.Assert.assertTrue(i19 == 0);
        org.junit.Assert.assertTrue(i20 == 3);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str21.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada22);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        java.lang.String str2 = mota0.toString();
        mota0.setFiabilidade(0);
        Mota mota5 = mota0.clone();
        Mota mota6 = new Mota();
        Mota mota7 = new Mota(mota6);
        Mota mota8 = new Mota(mota7);
        Mota mota9 = new Mota();
        Mota mota10 = new Mota(mota9);
        int i11 = mota7.compareTo((Veiculo) mota9);
        Mota mota12 = new Mota();
        mota12.setMatricula("");
        boolean b16 = mota12.equals((java.lang.Object) (-1.0d));
        boolean b17 = mota7.equals((java.lang.Object) (-1.0d));
        Mota mota18 = new Mota();
        mota18.setMatricula("");
        Mota mota21 = mota18.clone();
        mota18.setPrecoBase((double) 0L);
        Mota mota24 = new Mota();
        int i25 = mota24.getLugares();
        int i26 = mota18.compareTo((Veiculo) mota24);
        java.lang.String str27 = mota24.toString();
        Coordenada coordenada28 = mota24.getCoordenadas();
        mota7.setCoordenadas(coordenada28);
        mota0.setCoordenadas(coordenada28);
        mota0.setMatricula("hi!");
        boolean b33 = mota0.getOcupado();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(mota5);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(b16 == false);
        org.junit.Assert.assertTrue(b17 == false);
        org.junit.Assert.assertNotNull(mota21);
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue(i26 == 3);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str27.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada28);
        org.junit.Assert.assertTrue(b33 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = mota0.getCoordenadas();
        int i6 = mota0.getVelocidadeMedia();
        Mota mota7 = new Mota();
        mota7.setMatricula("");
        Mota mota10 = mota7.clone();
        mota10.setOcupado(true);
        boolean b13 = mota0.equals((java.lang.Object) mota10);
        mota10.setMatricula("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        boolean b16 = mota10.getOcupado();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertNotNull(mota10);
        org.junit.Assert.assertTrue(b13 == false);
        org.junit.Assert.assertTrue(b16 == true);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        mota0.setPrecoBase((double) (byte) 10);
        Mota mota4 = mota0.clone();
        org.junit.Assert.assertNotNull(mota4);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        Mota mota4 = new Mota();
        mota4.setMatricula("");
        boolean b8 = mota4.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada9 = mota4.getCoordenadas();
        mota4.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        mota4.setFiabilidade(0);
        Mota mota14 = new Mota();
        mota14.setMatricula("");
        Mota mota17 = mota14.clone();
        mota14.setPrecoBase((double) 0L);
        Mota mota20 = new Mota(mota14);
        int i21 = mota4.compareTo((Veiculo) mota14);
        Mota mota22 = new Mota(mota14);
        Coordenada coordenada23 = mota22.getCoordenadas();
        Mota mota25 = new Mota((int) (byte) 0, (double) 0L, (int) (byte) 0, "n/a", coordenada23, true);
        mota25.setOcupado(true);
        org.junit.Assert.assertTrue(b8 == false);
        org.junit.Assert.assertNotNull(coordenada9);
        org.junit.Assert.assertNotNull(mota17);
        org.junit.Assert.assertTrue(i21 == (-142));
        org.junit.Assert.assertNotNull(coordenada23);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        Mota mota4 = new Mota(mota0);
        Mota mota5 = mota4.clone();
        mota4.setVelocidadeMedia(32);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(mota5);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        java.lang.String str2 = mota0.toString();
        mota0.setFiabilidade(0);
        mota0.setPrecoBase(1.0d);
        int i7 = mota0.getFiabilidade();
        java.lang.String str8 = mota0.getMatricula();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "n/a" + "'", str8.equals("n/a"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Mota mota5 = new Mota(mota0);
        double d6 = mota0.getPrecoBase();
        boolean b7 = mota0.getOcupado();
        int i8 = mota0.getVelocidadeMedia();
        java.lang.String str9 = mota0.getMatricula();
        mota0.setMatricula("hi!");
        mota0.setVelocidadeMedia((int) (byte) 1);
        mota0.setVelocidadeMedia((int) (short) 10);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(b7 == false);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        java.lang.String str2 = mota0.toString();
        mota0.setFiabilidade(0);
        Mota mota5 = mota0.clone();
        Mota mota6 = new Mota();
        Mota mota7 = new Mota(mota6);
        Mota mota8 = new Mota(mota7);
        Mota mota9 = new Mota();
        Mota mota10 = new Mota(mota9);
        int i11 = mota7.compareTo((Veiculo) mota9);
        Mota mota12 = new Mota();
        mota12.setMatricula("");
        boolean b16 = mota12.equals((java.lang.Object) (-1.0d));
        boolean b17 = mota7.equals((java.lang.Object) (-1.0d));
        Mota mota18 = new Mota();
        mota18.setMatricula("");
        Mota mota21 = mota18.clone();
        mota18.setPrecoBase((double) 0L);
        Mota mota24 = new Mota();
        int i25 = mota24.getLugares();
        int i26 = mota18.compareTo((Veiculo) mota24);
        java.lang.String str27 = mota24.toString();
        Coordenada coordenada28 = mota24.getCoordenadas();
        mota7.setCoordenadas(coordenada28);
        mota0.setCoordenadas(coordenada28);
        mota0.setMatricula("hi!");
        mota0.setOcupado(true);
        java.lang.String str35 = mota0.getMatricula();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(mota5);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(b16 == false);
        org.junit.Assert.assertTrue(b17 == false);
        org.junit.Assert.assertNotNull(mota21);
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue(i26 == 3);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str27.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada28);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!" + "'", str35.equals("hi!"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        java.lang.String str2 = mota0.getMatricula();
        Mota mota3 = new Mota(mota0);
        int i4 = mota0.getLugares();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "n/a" + "'", str2.equals("n/a"));
        org.junit.Assert.assertTrue(i4 == 0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        java.lang.String str4 = mota0.toString();
        int i5 = mota0.getLugares();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str4.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i5 == 0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota3.setOcupado(true);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        mota6.setVelocidadeMedia(10);
        int i10 = mota3.compareTo((Veiculo) mota6);
        mota3.setOcupado(true);
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i10 == 3);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        Mota mota0 = new Mota();
        mota0.setOcupado(true);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Mota mota5 = new Mota(mota0);
        double d6 = mota0.getPrecoBase();
        boolean b7 = mota0.getOcupado();
        int i8 = mota0.getVelocidadeMedia();
        java.lang.String str9 = mota0.getMatricula();
        mota0.setMatricula("hi!");
        mota0.setFiabilidade((int) '4');
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(b7 == false);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = mota0.getCoordenadas();
        mota0.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        mota0.setFiabilidade(0);
        int i10 = mota0.getVelocidadeMedia();
        Mota mota11 = new Mota();
        mota11.setMatricula("");
        boolean b14 = mota0.equals((java.lang.Object) "");
        java.lang.String str15 = mota0.toString();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Matrícula: Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str15.equals("Matrícula: Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        int i4 = mota3.getLugares();
        boolean b5 = mota2.equals((java.lang.Object) mota3);
        mota3.setOcupado(true);
        Coordenada coordenada8 = mota3.getCoordenadas();
        int i9 = mota3.getVelocidadeMedia();
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue(b5 == true);
        org.junit.Assert.assertNotNull(coordenada8);
        org.junit.Assert.assertTrue(i9 == 0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        Mota mota4 = new Mota();
        mota4.setMatricula("");
        Mota mota7 = mota4.clone();
        Coordenada coordenada8 = mota7.getCoordenadas();
        Mota mota10 = new Mota(10, (double) (byte) 0, (int) 'a', "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada8, true);
        org.junit.Assert.assertNotNull(mota7);
        org.junit.Assert.assertNotNull(coordenada8);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        Mota mota4 = new Mota(mota3);
        int i5 = mota1.compareTo((Veiculo) mota3);
        mota3.setMatricula("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        int i8 = mota3.getFiabilidade();
        Mota mota9 = new Mota();
        mota9.setMatricula("");
        Mota mota12 = mota9.clone();
        Coordenada coordenada13 = mota12.getCoordenadas();
        mota3.setCoordenadas(coordenada13);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertNotNull(mota12);
        org.junit.Assert.assertNotNull(coordenada13);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        Mota mota0 = new Mota();
        mota0.setVelocidadeMedia((int) ' ');
        java.lang.String str3 = mota0.toString();
        int i4 = mota0.getVelocidadeMedia();
        java.lang.String str5 = mota0.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i4 == 32);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str5.equals("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        Mota mota9 = new Mota(mota6);
        int i10 = mota9.getLugares();
        mota9.setPrecoBase(100.0d);
        java.lang.String str13 = mota9.toString();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 100.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str13.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 100.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = mota0.getCoordenadas();
        java.lang.String str6 = mota0.toString();
        double d7 = mota0.getPrecoBase();
        mota0.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 100.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str6.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(d7 == 0.0d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        java.lang.String str2 = mota0.toString();
        mota0.setFiabilidade(0);
        mota0.setPrecoBase(1.0d);
        int i7 = mota0.getFiabilidade();
        Veiculo veiculo8 = null;
        try {
            int i9 = mota0.compareTo(veiculo8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i7 == 0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota(mota0);
        mota6.setPrecoBase((double) (-1.0f));
        mota6.setVelocidadeMedia((int) (short) 0);
        mota6.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        java.lang.String str13 = mota6.toString();
        java.lang.String str14 = mota6.getMatricula();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Matrícula: Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: -1.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str13.equals("Matrícula: Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: -1.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str14.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        java.lang.String str9 = mota6.toString();
        Coordenada coordenada10 = mota6.getCoordenadas();
        java.lang.String str11 = mota6.toString();
        Veiculo veiculo12 = null;
        try {
            int i13 = mota6.compareTo(veiculo12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str11.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        Coordenada coordenada2 = mota0.getCoordenadas();
        mota0.setFiabilidade(3);
        int i5 = mota0.getFiabilidade();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(coordenada2);
        org.junit.Assert.assertTrue(i5 == 3);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        Mota mota4 = new Mota(mota0);
        java.lang.String str5 = mota4.toString();
        mota4.setFiabilidade(3);
        int i8 = mota4.getLugares();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str5.equals("Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i8 == 0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        java.lang.String str9 = mota6.toString();
        int i10 = mota6.getFiabilidade();
        mota6.setPrecoBase(10.0d);
        int i13 = mota6.getFiabilidade();
        mota6.setFiabilidade(3);
        mota6.setPrecoBase((double) 0L);
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i13 == 0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        java.lang.String str2 = mota0.getMatricula();
        Mota mota3 = new Mota(mota0);
        int i4 = mota3.getLugares();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "n/a" + "'", str2.equals("n/a"));
        org.junit.Assert.assertTrue(i4 == 0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        java.lang.String str2 = mota0.toString();
        double d3 = mota0.getPrecoBase();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(d3 == 0.0d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota3.setOcupado(true);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        mota6.setVelocidadeMedia(10);
        int i10 = mota3.compareTo((Veiculo) mota6);
        Coordenada coordenada11 = mota3.getCoordenadas();
        mota3.setOcupado(false);
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i10 == 3);
        org.junit.Assert.assertNotNull(coordenada11);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        Mota mota4 = new Mota();
        int i5 = mota4.getLugares();
        Coordenada coordenada6 = mota4.getCoordenadas();
        Mota mota8 = new Mota((int) (short) -1, (double) (byte) -1, (int) '4', "", coordenada6, true);
        int i9 = mota8.getLugares();
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertNotNull(coordenada6);
        org.junit.Assert.assertTrue(i9 == 1);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setMatricula("");
        int i6 = mota0.getFiabilidade();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i6 == 0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        Mota mota8 = new Mota();
        Mota mota9 = new Mota(mota8);
        Mota mota10 = new Mota(mota9);
        Mota mota11 = new Mota();
        Mota mota12 = new Mota(mota11);
        int i13 = mota9.compareTo((Veiculo) mota11);
        Mota mota14 = new Mota();
        mota14.setMatricula("");
        boolean b18 = mota14.equals((java.lang.Object) (-1.0d));
        boolean b19 = mota9.equals((java.lang.Object) (-1.0d));
        Mota mota20 = new Mota();
        mota20.setMatricula("");
        Mota mota23 = mota20.clone();
        mota20.setPrecoBase((double) 0L);
        Mota mota26 = new Mota();
        int i27 = mota26.getLugares();
        int i28 = mota20.compareTo((Veiculo) mota26);
        java.lang.String str29 = mota26.toString();
        Coordenada coordenada30 = mota26.getCoordenadas();
        mota9.setCoordenadas(coordenada30);
        Mota mota33 = new Mota((-1), 10.0d, (int) (byte) 1, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada30, true);
        Mota mota35 = new Mota((int) (byte) 0, (double) (byte) -1, (-33), "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 100.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada30, true);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(b18 == false);
        org.junit.Assert.assertTrue(b19 == false);
        org.junit.Assert.assertNotNull(mota23);
        org.junit.Assert.assertTrue(i27 == 0);
        org.junit.Assert.assertTrue(i28 == 3);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str29.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada30);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        int i3 = mota0.getVelocidadeMedia();
        Mota mota4 = new Mota();
        mota4.setMatricula("");
        Mota mota7 = mota4.clone();
        mota4.setPrecoBase((double) 0L);
        Mota mota10 = new Mota(mota4);
        mota10.setPrecoBase((double) (-1.0f));
        mota10.setVelocidadeMedia((int) (short) 0);
        mota10.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Mota mota17 = new Mota(mota10);
        double d18 = mota17.getPrecoBase();
        boolean b19 = mota0.equals((java.lang.Object) mota17);
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertNotNull(mota7);
        org.junit.Assert.assertTrue(d18 == (-1.0d));
        org.junit.Assert.assertTrue(b19 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        mota0.setOcupado(false);
        mota0.setPrecoBase((double) (short) 100);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        java.lang.String str2 = mota0.getMatricula();
        mota0.setVelocidadeMedia((-1));
        Mota mota5 = mota0.clone();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "n/a" + "'", str2.equals("n/a"));
        org.junit.Assert.assertNotNull(mota5);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota(mota0);
        mota6.setPrecoBase((double) (-1.0f));
        mota6.setVelocidadeMedia((int) (short) 0);
        mota6.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Mota mota13 = new Mota(mota6);
        Mota mota14 = new Mota();
        mota14.setMatricula("");
        Mota mota17 = mota14.clone();
        mota14.setPrecoBase((double) 0L);
        Mota mota20 = new Mota();
        int i21 = mota20.getLugares();
        int i22 = mota14.compareTo((Veiculo) mota20);
        int i23 = mota20.getFiabilidade();
        boolean b24 = mota6.equals((java.lang.Object) i23);
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertNotNull(mota17);
        org.junit.Assert.assertTrue(i21 == 0);
        org.junit.Assert.assertTrue(i22 == 3);
        org.junit.Assert.assertTrue(i23 == 0);
        org.junit.Assert.assertTrue(b24 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        Mota mota4 = new Mota(mota3);
        int i5 = mota1.compareTo((Veiculo) mota3);
        Mota mota6 = new Mota();
        mota6.setMatricula("");
        boolean b10 = mota6.equals((java.lang.Object) (-1.0d));
        boolean b11 = mota1.equals((java.lang.Object) (-1.0d));
        Mota mota12 = new Mota();
        mota12.setMatricula("");
        Mota mota15 = mota12.clone();
        mota12.setPrecoBase((double) 0L);
        Mota mota18 = new Mota();
        int i19 = mota18.getLugares();
        int i20 = mota12.compareTo((Veiculo) mota18);
        java.lang.String str21 = mota18.toString();
        Coordenada coordenada22 = mota18.getCoordenadas();
        mota1.setCoordenadas(coordenada22);
        mota1.setPrecoBase((double) (short) 10);
        mota1.setFiabilidade((-1));
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertNotNull(mota15);
        org.junit.Assert.assertTrue(i19 == 0);
        org.junit.Assert.assertTrue(i20 == 3);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str21.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada22);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        Mota mota4 = new Mota();
        mota4.setMatricula("");
        java.lang.String str7 = mota4.toString();
        Mota mota8 = new Mota();
        Mota mota9 = new Mota(mota8);
        java.lang.String str10 = mota8.toString();
        mota8.setFiabilidade(0);
        Mota mota13 = mota8.clone();
        Mota mota14 = new Mota();
        Mota mota15 = new Mota(mota14);
        Mota mota16 = new Mota(mota15);
        Mota mota17 = new Mota();
        Mota mota18 = new Mota(mota17);
        int i19 = mota15.compareTo((Veiculo) mota17);
        Mota mota20 = new Mota();
        mota20.setMatricula("");
        boolean b24 = mota20.equals((java.lang.Object) (-1.0d));
        boolean b25 = mota15.equals((java.lang.Object) (-1.0d));
        Mota mota26 = new Mota();
        mota26.setMatricula("");
        Mota mota29 = mota26.clone();
        mota26.setPrecoBase((double) 0L);
        Mota mota32 = new Mota();
        int i33 = mota32.getLugares();
        int i34 = mota26.compareTo((Veiculo) mota32);
        java.lang.String str35 = mota32.toString();
        Coordenada coordenada36 = mota32.getCoordenadas();
        mota15.setCoordenadas(coordenada36);
        mota8.setCoordenadas(coordenada36);
        mota4.setCoordenadas(coordenada36);
        Mota mota41 = new Mota((int) (byte) 0, (double) 100L, (int) (byte) -1, "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada36, false);
        int i42 = mota41.getFiabilidade();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str7.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str10.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(mota13);
        org.junit.Assert.assertTrue(i19 == 0);
        org.junit.Assert.assertTrue(b24 == false);
        org.junit.Assert.assertTrue(b25 == false);
        org.junit.Assert.assertNotNull(mota29);
        org.junit.Assert.assertTrue(i33 == 0);
        org.junit.Assert.assertTrue(i34 == 3);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str35.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada36);
        org.junit.Assert.assertTrue(i42 == (-1));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        java.lang.String str3 = mota0.toString();
        boolean b4 = mota0.getOcupado();
        boolean b6 = mota0.equals((java.lang.Object) "n/a");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(b6 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = mota0.getCoordenadas();
        mota0.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        mota0.setFiabilidade(0);
        int i10 = mota0.getVelocidadeMedia();
        Mota mota11 = new Mota();
        mota11.setMatricula("");
        boolean b14 = mota0.equals((java.lang.Object) "");
        int i15 = mota0.getLugares();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertTrue(i15 == 0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota(mota0);
        mota6.setPrecoBase((double) (-1.0f));
        double d9 = mota6.getPrecoBase();
        Mota mota10 = new Mota();
        int i11 = mota10.getLugares();
        mota10.setVelocidadeMedia(10);
        mota10.setFiabilidade((int) (byte) 0);
        int i16 = mota10.getLugares();
        boolean b17 = mota6.equals((java.lang.Object) i16);
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(d9 == (-1.0d));
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue(b17 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota(mota0);
        mota6.setPrecoBase((double) (-1.0f));
        mota6.setVelocidadeMedia((int) (short) 0);
        mota6.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Mota mota13 = new Mota(mota6);
        java.lang.String str14 = mota13.toString();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Matrícula: Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: -1.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str14.equals("Matrícula: Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: -1.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota(mota0);
        mota6.setFiabilidade((int) '#');
        mota6.setOcupado(false);
        org.junit.Assert.assertNotNull(mota3);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        int i9 = mota6.getFiabilidade();
        Mota mota10 = mota6.clone();
        java.lang.String str11 = mota6.toString();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertNotNull(mota10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str11.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        Mota mota4 = new Mota(mota3);
        int i5 = mota1.compareTo((Veiculo) mota3);
        Mota mota6 = new Mota();
        mota6.setMatricula("");
        boolean b10 = mota6.equals((java.lang.Object) (-1.0d));
        boolean b11 = mota1.equals((java.lang.Object) (-1.0d));
        Mota mota12 = new Mota();
        mota12.setMatricula("");
        Mota mota15 = mota12.clone();
        mota12.setPrecoBase((double) 0L);
        Mota mota18 = new Mota();
        int i19 = mota18.getLugares();
        int i20 = mota12.compareTo((Veiculo) mota18);
        java.lang.String str21 = mota18.toString();
        Coordenada coordenada22 = mota18.getCoordenadas();
        mota1.setCoordenadas(coordenada22);
        mota1.setPrecoBase((double) (short) 10);
        int i26 = mota1.getLugares();
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertNotNull(mota15);
        org.junit.Assert.assertTrue(i19 == 0);
        org.junit.Assert.assertTrue(i20 == 3);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str21.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada22);
        org.junit.Assert.assertTrue(i26 == 0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        Mota mota0 = new Mota();
        java.lang.String str1 = mota0.toString();
        Mota mota2 = mota0.clone();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str1.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(mota2);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        Mota mota4 = new Mota(mota0);
        Coordenada coordenada5 = mota0.getCoordenadas();
        double d6 = mota0.getPrecoBase();
        java.lang.String str7 = mota0.getMatricula();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "n/a" + "'", str7.equals("n/a"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        java.lang.String str3 = mota0.toString();
        Mota mota4 = mota0.clone();
        java.lang.String str5 = mota0.toString();
        Mota mota6 = new Mota(mota0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(mota4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str5.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        Mota mota12 = new Mota();
        mota12.setMatricula("");
        Mota mota15 = mota12.clone();
        mota12.setPrecoBase((double) 0L);
        Mota mota18 = new Mota();
        int i19 = mota18.getLugares();
        int i20 = mota12.compareTo((Veiculo) mota18);
        java.lang.String str21 = mota18.toString();
        Coordenada coordenada22 = mota18.getCoordenadas();
        Mota mota24 = new Mota((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada22, false);
        Mota mota26 = new Mota((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada22, true);
        Mota mota28 = new Mota((int) '#', 10.0d, (-1), "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada22, true);
        Coordenada coordenada29 = mota28.getCoordenadas();
        Mota mota30 = new Mota();
        mota30.setMatricula("");
        java.lang.String str33 = mota30.toString();
        boolean b34 = mota30.getOcupado();
        boolean b35 = mota28.equals((java.lang.Object) mota30);
        boolean b36 = mota28.getOcupado();
        org.junit.Assert.assertNotNull(mota15);
        org.junit.Assert.assertTrue(i19 == 0);
        org.junit.Assert.assertTrue(i20 == 3);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str21.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada22);
        org.junit.Assert.assertNotNull(coordenada29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str33.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(b34 == false);
        org.junit.Assert.assertTrue(b35 == false);
        org.junit.Assert.assertTrue(b36 == true);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Mota mota5 = new Mota(mota0);
        double d6 = mota0.getPrecoBase();
        boolean b7 = mota0.getOcupado();
        int i8 = mota0.getVelocidadeMedia();
        java.lang.String str9 = mota0.getMatricula();
        mota0.setMatricula("hi!");
        mota0.setVelocidadeMedia((int) (byte) 1);
        boolean b14 = mota0.getOcupado();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(b7 == false);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue(b14 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        Mota mota4 = new Mota();
        mota4.setMatricula("");
        Mota mota7 = mota4.clone();
        mota4.setPrecoBase((double) 0L);
        Mota mota10 = new Mota();
        int i11 = mota10.getLugares();
        int i12 = mota4.compareTo((Veiculo) mota10);
        java.lang.String str13 = mota10.toString();
        Coordenada coordenada14 = mota10.getCoordenadas();
        Mota mota16 = new Mota((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada14, false);
        mota16.setPrecoBase((double) 10.0f);
        Coordenada coordenada19 = mota16.getCoordenadas();
        java.lang.String str20 = mota16.toString();
        org.junit.Assert.assertNotNull(mota7);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(i12 == 3);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str13.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada14);
        org.junit.Assert.assertNotNull(coordenada19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Matrícula: Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 100km/h\nPreço Base: 10.0€\nFiabilidade: 10\nLugares: 1\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str20.equals("Matrícula: Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 100km/h\nPreço Base: 10.0€\nFiabilidade: 10\nLugares: 1\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        Mota mota4 = new Mota(mota0);
        java.lang.String str5 = mota4.toString();
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        mota6.setVelocidadeMedia(10);
        Mota mota10 = new Mota(mota6);
        int i11 = mota6.getVelocidadeMedia();
        Mota mota12 = mota6.clone();
        int i13 = mota4.compareTo((Veiculo) mota6);
        java.lang.String str14 = mota4.toString();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str5.equals("Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i11 == 10);
        org.junit.Assert.assertNotNull(mota12);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str14.equals("Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        int i4 = mota3.getLugares();
        boolean b5 = mota2.equals((java.lang.Object) mota3);
        Mota mota6 = mota3.clone();
        mota6.setVelocidadeMedia((int) (short) 0);
        mota6.setPrecoBase(1.0d);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue(b5 == true);
        org.junit.Assert.assertNotNull(mota6);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Mota mota5 = new Mota(mota0);
        double d6 = mota0.getPrecoBase();
        boolean b7 = mota0.getOcupado();
        int i8 = mota0.getVelocidadeMedia();
        java.lang.String str9 = mota0.getMatricula();
        mota0.setMatricula("hi!");
        double d12 = mota0.getPrecoBase();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(b7 == false);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue(d12 == 0.0d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        Mota mota4 = new Mota();
        mota4.setMatricula("");
        Mota mota7 = mota4.clone();
        Coordenada coordenada8 = mota7.getCoordenadas();
        Mota mota10 = new Mota((int) (byte) 0, (double) 'a', 3, "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada8, false);
        java.lang.Object obj11 = null;
        boolean b12 = mota10.equals(obj11);
        boolean b13 = mota10.getOcupado();
        boolean b15 = mota10.equals((java.lang.Object) "n/a");
        org.junit.Assert.assertNotNull(mota7);
        org.junit.Assert.assertNotNull(coordenada8);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertTrue(b13 == false);
        org.junit.Assert.assertTrue(b15 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        Coordenada coordenada2 = mota0.getCoordenadas();
        Mota mota3 = new Mota();
        Mota mota4 = new Mota(mota3);
        java.lang.String str5 = mota3.toString();
        mota3.setFiabilidade(0);
        Mota mota8 = mota3.clone();
        int i9 = mota3.getLugares();
        Mota mota14 = new Mota();
        Mota mota15 = new Mota(mota14);
        Mota mota16 = new Mota(mota15);
        Mota mota17 = new Mota();
        Mota mota18 = new Mota(mota17);
        int i19 = mota15.compareTo((Veiculo) mota17);
        Mota mota20 = new Mota();
        mota20.setMatricula("");
        boolean b24 = mota20.equals((java.lang.Object) (-1.0d));
        boolean b25 = mota15.equals((java.lang.Object) (-1.0d));
        Mota mota26 = new Mota();
        mota26.setMatricula("");
        Mota mota29 = mota26.clone();
        mota26.setPrecoBase((double) 0L);
        Mota mota32 = new Mota();
        int i33 = mota32.getLugares();
        int i34 = mota26.compareTo((Veiculo) mota32);
        java.lang.String str35 = mota32.toString();
        Coordenada coordenada36 = mota32.getCoordenadas();
        mota15.setCoordenadas(coordenada36);
        Mota mota39 = new Mota((-1), 10.0d, (int) (byte) 1, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada36, true);
        mota3.setCoordenadas(coordenada36);
        int i41 = mota0.compareTo((Veiculo) mota3);
        Coordenada coordenada42 = mota0.getCoordenadas();
        Mota mota43 = mota0.clone();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(coordenada2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str5.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(mota8);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertTrue(i19 == 0);
        org.junit.Assert.assertTrue(b24 == false);
        org.junit.Assert.assertTrue(b25 == false);
        org.junit.Assert.assertNotNull(mota29);
        org.junit.Assert.assertTrue(i33 == 0);
        org.junit.Assert.assertTrue(i34 == 3);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str35.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada36);
        org.junit.Assert.assertTrue(i41 == 0);
        org.junit.Assert.assertNotNull(coordenada42);
        org.junit.Assert.assertNotNull(mota43);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        java.lang.String str2 = mota0.toString();
        mota0.setFiabilidade(0);
        Mota mota5 = mota0.clone();
        Mota mota6 = new Mota();
        Mota mota7 = new Mota(mota6);
        Mota mota8 = new Mota(mota7);
        Mota mota9 = new Mota();
        Mota mota10 = new Mota(mota9);
        int i11 = mota7.compareTo((Veiculo) mota9);
        Mota mota12 = new Mota();
        mota12.setMatricula("");
        boolean b16 = mota12.equals((java.lang.Object) (-1.0d));
        boolean b17 = mota7.equals((java.lang.Object) (-1.0d));
        Mota mota18 = new Mota();
        mota18.setMatricula("");
        Mota mota21 = mota18.clone();
        mota18.setPrecoBase((double) 0L);
        Mota mota24 = new Mota();
        int i25 = mota24.getLugares();
        int i26 = mota18.compareTo((Veiculo) mota24);
        java.lang.String str27 = mota24.toString();
        Coordenada coordenada28 = mota24.getCoordenadas();
        mota7.setCoordenadas(coordenada28);
        mota0.setCoordenadas(coordenada28);
        mota0.setPrecoBase(100.0d);
        mota0.setMatricula("");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(mota5);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(b16 == false);
        org.junit.Assert.assertTrue(b17 == false);
        org.junit.Assert.assertNotNull(mota21);
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue(i26 == 3);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str27.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada28);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        Mota mota4 = new Mota(mota0);
        Mota mota5 = mota4.clone();
        boolean b6 = mota4.getOcupado();
        mota4.setFiabilidade((int) (short) 0);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(mota5);
        org.junit.Assert.assertTrue(b6 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota(mota0);
        mota6.setPrecoBase((double) (-1.0f));
        mota6.setVelocidadeMedia((int) (short) 0);
        mota6.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        java.lang.String str13 = mota6.getMatricula();
        mota6.setPrecoBase(10.0d);
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str13.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = mota0.getCoordenadas();
        int i6 = mota0.getVelocidadeMedia();
        int i7 = mota0.getLugares();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertTrue(i7 == 0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        java.lang.String str2 = mota0.toString();
        mota0.setFiabilidade(0);
        Mota mota5 = mota0.clone();
        Mota mota6 = new Mota(mota0);
        double d7 = mota6.getPrecoBase();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(mota5);
        org.junit.Assert.assertTrue(d7 == 0.0d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        java.lang.String str9 = mota6.toString();
        int i10 = mota6.getFiabilidade();
        mota6.setPrecoBase(10.0d);
        Mota mota13 = mota6.clone();
        int i14 = mota6.getFiabilidade();
        mota6.setVelocidadeMedia(0);
        boolean b17 = mota6.getOcupado();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertNotNull(mota13);
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(b17 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        Mota mota4 = new Mota(mota0);
        java.lang.String str5 = mota0.toString();
        double d6 = mota0.getPrecoBase();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str5.equals("Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(d6 == 0.0d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = mota0.getCoordenadas();
        mota0.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        mota0.setFiabilidade(0);
        mota0.setVelocidadeMedia((-1));
        Mota mota12 = mota0.clone();
        mota12.setFiabilidade((int) (short) -1);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertNotNull(mota12);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        java.lang.String str9 = mota6.toString();
        int i10 = mota6.getFiabilidade();
        mota6.setPrecoBase(10.0d);
        Mota mota13 = mota6.clone();
        mota6.setVelocidadeMedia((int) (byte) 100);
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertNotNull(mota13);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        Mota mota4 = new Mota(mota3);
        int i5 = mota1.compareTo((Veiculo) mota3);
        mota1.setOcupado(false);
        org.junit.Assert.assertTrue(i5 == 0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = mota0.getCoordenadas();
        boolean b6 = mota0.getOcupado();
        java.lang.String str7 = mota0.getMatricula();
        int i8 = mota0.getFiabilidade();
        mota0.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(b6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        double d6 = mota0.getPrecoBase();
        int i7 = mota0.getVelocidadeMedia();
        mota0.setMatricula("Matrícula: Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: -1.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(i7 == 0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota(mota0);
        mota6.setPrecoBase((double) (-1.0f));
        mota6.setVelocidadeMedia((int) (short) 0);
        mota6.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        java.lang.String str13 = mota6.getMatricula();
        int i14 = mota6.getVelocidadeMedia();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str13.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i14 == 0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        Mota mota4 = new Mota();
        mota4.setMatricula("");
        boolean b8 = mota4.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada9 = mota4.getCoordenadas();
        Mota mota11 = new Mota((int) (byte) 0, (double) (short) 100, (int) (byte) 10, "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada9, false);
        mota11.setOcupado(true);
        Mota mota14 = new Mota();
        Mota mota15 = new Mota(mota14);
        java.lang.String str16 = mota14.toString();
        mota14.setFiabilidade(0);
        Mota mota19 = mota14.clone();
        int i20 = mota11.compareTo((Veiculo) mota14);
        java.lang.String str21 = mota14.toString();
        org.junit.Assert.assertTrue(b8 == false);
        org.junit.Assert.assertNotNull(coordenada9);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str16.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(mota19);
        org.junit.Assert.assertTrue(i20 == 33);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str21.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        mota1.setVelocidadeMedia(0);
        int i5 = mota1.getFiabilidade();
        org.junit.Assert.assertTrue(i5 == 0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        Mota mota4 = new Mota(mota0);
        int i5 = mota0.getVelocidadeMedia();
        Mota mota6 = mota0.clone();
        mota6.setMatricula("Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        double d9 = mota6.getPrecoBase();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i5 == 10);
        org.junit.Assert.assertNotNull(mota6);
        org.junit.Assert.assertTrue(d9 == 0.0d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        java.lang.String str9 = mota6.toString();
        int i10 = mota6.getVelocidadeMedia();
        Mota mota11 = mota6.clone();
        java.lang.String str12 = mota6.getMatricula();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertNotNull(mota11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "n/a" + "'", str12.equals("n/a"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        java.lang.String str9 = mota6.toString();
        int i10 = mota6.getFiabilidade();
        mota6.setPrecoBase(10.0d);
        int i13 = mota6.getFiabilidade();
        java.lang.String str14 = mota6.toString();
        Mota mota15 = mota6.clone();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 10.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str14.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 10.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(mota15);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        java.lang.Object obj4 = null;
        boolean b5 = mota0.equals(obj4);
        mota0.setPrecoBase((double) (byte) 100);
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(b5 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        Coordenada coordenada4 = mota3.getCoordenadas();
        Mota mota5 = new Mota();
        mota5.setMatricula("");
        Mota mota8 = mota5.clone();
        mota5.setPrecoBase((double) 0L);
        Mota mota11 = new Mota();
        int i12 = mota11.getLugares();
        int i13 = mota5.compareTo((Veiculo) mota11);
        java.lang.String str14 = mota11.toString();
        Coordenada coordenada15 = mota11.getCoordenadas();
        int i16 = mota3.compareTo((Veiculo) mota11);
        java.lang.String str17 = mota3.getMatricula();
        mota3.setPrecoBase((double) 10);
        int i20 = mota3.getFiabilidade();
        java.lang.String str21 = mota3.getMatricula();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertNotNull(coordenada4);
        org.junit.Assert.assertNotNull(mota8);
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertTrue(i13 == 3);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str14.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada15);
        org.junit.Assert.assertTrue(i16 == 3);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue(i20 == 0);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        Mota mota4 = new Mota(mota3);
        int i5 = mota1.compareTo((Veiculo) mota3);
        Mota mota6 = new Mota();
        mota6.setMatricula("");
        boolean b10 = mota6.equals((java.lang.Object) (-1.0d));
        boolean b11 = mota1.equals((java.lang.Object) (-1.0d));
        Mota mota12 = new Mota(mota1);
        int i13 = mota12.getVelocidadeMedia();
        Mota mota18 = new Mota();
        mota18.setMatricula("");
        Mota mota21 = mota18.clone();
        int i22 = mota21.getVelocidadeMedia();
        Coordenada coordenada23 = mota21.getCoordenadas();
        Mota mota25 = new Mota((int) (short) 10, 1.0d, (int) ' ', "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada23, false);
        mota12.setCoordenadas(coordenada23);
        java.lang.String str27 = mota12.getMatricula();
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertNotNull(mota21);
        org.junit.Assert.assertTrue(i22 == 0);
        org.junit.Assert.assertNotNull(coordenada23);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "n/a" + "'", str27.equals("n/a"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = mota0.getCoordenadas();
        java.lang.String str6 = mota0.toString();
        double d7 = mota0.getPrecoBase();
        mota0.setFiabilidade((int) ' ');
        mota0.setPrecoBase(0.0d);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str6.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(d7 == 0.0d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota(mota0);
        mota6.setPrecoBase((double) (-1.0f));
        mota6.setVelocidadeMedia((int) (short) 0);
        mota6.setMatricula("hi!");
        org.junit.Assert.assertNotNull(mota3);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        Mota mota4 = new Mota(mota0);
        int i5 = mota0.getVelocidadeMedia();
        java.lang.String str6 = mota0.getMatricula();
        mota0.setVelocidadeMedia((int) (byte) 1);
        mota0.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 100.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        boolean b11 = mota0.getOcupado();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i5 == 10);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "n/a" + "'", str6.equals("n/a"));
        org.junit.Assert.assertTrue(b11 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Mota mota5 = new Mota(mota0);
        double d6 = mota0.getPrecoBase();
        boolean b7 = mota0.getOcupado();
        int i8 = mota0.getVelocidadeMedia();
        Mota mota9 = mota0.clone();
        mota9.setFiabilidade((int) (byte) 10);
        java.lang.String str12 = mota9.getMatricula();
        Coordenada coordenada13 = mota9.getCoordenadas();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(b7 == false);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertNotNull(mota9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNotNull(coordenada13);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        Mota mota4 = new Mota();
        mota4.setMatricula("");
        Mota mota7 = mota4.clone();
        mota4.setPrecoBase((double) 0L);
        Mota mota10 = new Mota();
        int i11 = mota10.getLugares();
        int i12 = mota4.compareTo((Veiculo) mota10);
        java.lang.String str13 = mota10.toString();
        Coordenada coordenada14 = mota10.getCoordenadas();
        Mota mota16 = new Mota((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada14, false);
        mota16.setPrecoBase((double) 10.0f);
        Coordenada coordenada19 = mota16.getCoordenadas();
        mota16.setVelocidadeMedia((-33));
        org.junit.Assert.assertNotNull(mota7);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(i12 == 3);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str13.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada14);
        org.junit.Assert.assertNotNull(coordenada19);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota(mota0);
        mota6.setPrecoBase((double) (-1.0f));
        mota6.setPrecoBase((double) 10);
        Mota mota11 = new Mota();
        Mota mota12 = new Mota(mota11);
        Mota mota13 = new Mota(mota12);
        Mota mota14 = new Mota();
        Mota mota15 = new Mota(mota14);
        int i16 = mota12.compareTo((Veiculo) mota14);
        int i17 = mota14.getVelocidadeMedia();
        Mota mota18 = mota14.clone();
        int i19 = mota6.compareTo((Veiculo) mota14);
        boolean b20 = mota6.getOcupado();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue(i17 == 0);
        org.junit.Assert.assertNotNull(mota18);
        org.junit.Assert.assertTrue(i19 == 3);
        org.junit.Assert.assertTrue(b20 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        Coordenada coordenada4 = mota3.getCoordenadas();
        Mota mota5 = new Mota();
        mota5.setMatricula("");
        Mota mota8 = mota5.clone();
        mota5.setPrecoBase((double) 0L);
        Mota mota11 = new Mota();
        int i12 = mota11.getLugares();
        int i13 = mota5.compareTo((Veiculo) mota11);
        java.lang.String str14 = mota11.toString();
        Coordenada coordenada15 = mota11.getCoordenadas();
        int i16 = mota3.compareTo((Veiculo) mota11);
        java.lang.String str17 = mota3.getMatricula();
        mota3.setPrecoBase((double) 10);
        mota3.setFiabilidade((int) (byte) -1);
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertNotNull(coordenada4);
        org.junit.Assert.assertNotNull(mota8);
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertTrue(i13 == 3);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str14.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada15);
        org.junit.Assert.assertTrue(i16 == 3);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        Mota mota4 = new Mota();
        int i5 = mota4.getLugares();
        mota4.setVelocidadeMedia(10);
        Mota mota8 = new Mota(mota4);
        Mota mota9 = new Mota(mota8);
        int i10 = mota9.getFiabilidade();
        Mota mota11 = mota9.clone();
        Mota mota12 = new Mota();
        mota12.setMatricula("");
        Mota mota15 = mota12.clone();
        int i16 = mota15.getVelocidadeMedia();
        Coordenada coordenada17 = mota15.getCoordenadas();
        mota11.setCoordenadas(coordenada17);
        Mota mota20 = new Mota((int) (short) -1, (double) (short) 10, (-142), "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n", coordenada17, true);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertNotNull(mota11);
        org.junit.Assert.assertNotNull(mota15);
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertNotNull(coordenada17);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Mota mota5 = new Mota(mota0);
        double d6 = mota0.getPrecoBase();
        mota0.setFiabilidade((int) (short) 0);
        Mota mota9 = new Mota(mota0);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        Mota mota4 = new Mota(mota3);
        int i5 = mota1.compareTo((Veiculo) mota3);
        mota1.setVelocidadeMedia((int) (short) 100);
        Veiculo veiculo8 = null;
        try {
            int i9 = mota1.compareTo(veiculo8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i5 == 0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        Mota mota0 = new Mota();
        mota0.setVelocidadeMedia((int) ' ');
        java.lang.String str3 = mota0.toString();
        int i4 = mota0.getVelocidadeMedia();
        boolean b5 = mota0.getOcupado();
        Mota mota6 = new Mota();
        mota6.setMatricula("");
        Mota mota9 = mota6.clone();
        int i10 = mota9.getVelocidadeMedia();
        Coordenada coordenada11 = mota9.getCoordenadas();
        Mota mota12 = new Mota();
        mota12.setMatricula("");
        Mota mota15 = mota12.clone();
        mota12.setPrecoBase((double) 0L);
        Mota mota18 = new Mota();
        int i19 = mota18.getLugares();
        int i20 = mota12.compareTo((Veiculo) mota18);
        java.lang.String str21 = mota18.toString();
        java.lang.String str22 = mota18.toString();
        boolean b23 = mota9.equals((java.lang.Object) str22);
        mota9.setFiabilidade((int) (byte) 0);
        boolean b26 = mota0.equals((java.lang.Object) (byte) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i4 == 32);
        org.junit.Assert.assertTrue(b5 == false);
        org.junit.Assert.assertNotNull(mota9);
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertNotNull(coordenada11);
        org.junit.Assert.assertNotNull(mota15);
        org.junit.Assert.assertTrue(i19 == 0);
        org.junit.Assert.assertTrue(i20 == 3);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str21.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str22.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(b23 == false);
        org.junit.Assert.assertTrue(b26 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        java.lang.String str9 = mota6.toString();
        int i10 = mota6.getFiabilidade();
        mota6.setPrecoBase(10.0d);
        int i13 = mota6.getVelocidadeMedia();
        Mota mota14 = new Mota(mota6);
        Coordenada coordenada15 = mota14.getCoordenadas();
        boolean b16 = mota14.getOcupado();
        java.lang.String str17 = mota14.getMatricula();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertNotNull(coordenada15);
        org.junit.Assert.assertTrue(b16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "n/a" + "'", str17.equals("n/a"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        Mota mota4 = new Mota();
        int i5 = mota4.getLugares();
        mota4.setVelocidadeMedia(10);
        Mota mota8 = new Mota(mota4);
        Coordenada coordenada9 = mota4.getCoordenadas();
        Mota mota11 = new Mota((int) (short) -1, (double) 32, (int) (byte) 1, "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n", coordenada9, false);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertNotNull(coordenada9);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        int i9 = mota6.getFiabilidade();
        Mota mota10 = mota6.clone();
        int i11 = mota10.getFiabilidade();
        Mota mota12 = mota10.clone();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertNotNull(mota10);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertNotNull(mota12);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        Mota mota4 = new Mota(mota3);
        int i5 = mota1.compareTo((Veiculo) mota3);
        Mota mota6 = new Mota(mota3);
        mota6.setOcupado(true);
        double d9 = mota6.getPrecoBase();
        mota6.setPrecoBase((double) (-33));
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(d9 == 0.0d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        java.lang.String str9 = mota6.toString();
        int i10 = mota6.getFiabilidade();
        mota6.setPrecoBase(10.0d);
        boolean b14 = mota6.equals((java.lang.Object) 100);
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(b14 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Mota mota5 = new Mota(mota0);
        double d6 = mota0.getPrecoBase();
        boolean b7 = mota0.getOcupado();
        int i8 = mota0.getVelocidadeMedia();
        Mota mota9 = mota0.clone();
        mota9.setFiabilidade((int) (byte) 10);
        mota9.setMatricula("Matrícula: Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(b7 == false);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertNotNull(mota9);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        int i2 = mota1.getFiabilidade();
        Coordenada coordenada3 = mota1.getCoordenadas();
        int i4 = mota1.getFiabilidade();
        org.junit.Assert.assertTrue(i2 == 0);
        org.junit.Assert.assertNotNull(coordenada3);
        org.junit.Assert.assertTrue(i4 == 0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota(mota0);
        mota6.setPrecoBase((double) (-1.0f));
        mota6.setVelocidadeMedia((int) (short) 0);
        mota6.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Mota mota13 = new Mota(mota6);
        Mota mota14 = mota6.clone();
        mota14.setVelocidadeMedia((int) (byte) 0);
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertNotNull(mota14);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota(mota0);
        mota6.setFiabilidade((int) '#');
        java.lang.String str9 = mota6.toString();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 35\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 35\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        Coordenada coordenada4 = mota3.getCoordenadas();
        Mota mota5 = new Mota();
        mota5.setMatricula("");
        Mota mota8 = mota5.clone();
        mota5.setPrecoBase((double) 0L);
        Mota mota11 = new Mota();
        int i12 = mota11.getLugares();
        int i13 = mota5.compareTo((Veiculo) mota11);
        java.lang.String str14 = mota11.toString();
        Coordenada coordenada15 = mota11.getCoordenadas();
        int i16 = mota3.compareTo((Veiculo) mota11);
        java.lang.String str17 = mota11.toString();
        int i18 = mota11.getVelocidadeMedia();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertNotNull(coordenada4);
        org.junit.Assert.assertNotNull(mota8);
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertTrue(i13 == 3);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str14.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada15);
        org.junit.Assert.assertTrue(i16 == 3);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str17.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i18 == 0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        int i4 = mota3.getVelocidadeMedia();
        Coordenada coordenada5 = mota3.getCoordenadas();
        Mota mota18 = new Mota();
        mota18.setMatricula("");
        Mota mota21 = mota18.clone();
        mota18.setPrecoBase((double) 0L);
        Mota mota24 = new Mota();
        int i25 = mota24.getLugares();
        int i26 = mota18.compareTo((Veiculo) mota24);
        java.lang.String str27 = mota24.toString();
        Coordenada coordenada28 = mota24.getCoordenadas();
        Mota mota30 = new Mota((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada28, false);
        Mota mota32 = new Mota((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada28, true);
        Mota mota34 = new Mota((int) '#', 10.0d, (-1), "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada28, true);
        Coordenada coordenada35 = mota34.getCoordenadas();
        Mota mota36 = new Mota();
        mota36.setMatricula("");
        java.lang.String str39 = mota36.toString();
        boolean b40 = mota36.getOcupado();
        boolean b41 = mota34.equals((java.lang.Object) mota36);
        boolean b42 = mota3.equals((java.lang.Object) b41);
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertNotNull(mota21);
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue(i26 == 3);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str27.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada28);
        org.junit.Assert.assertNotNull(coordenada35);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str39.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(b40 == false);
        org.junit.Assert.assertTrue(b41 == false);
        org.junit.Assert.assertTrue(b42 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        Mota mota4 = new Mota(mota0);
        Mota mota5 = new Mota(mota4);
        int i6 = mota5.getFiabilidade();
        Mota mota7 = mota5.clone();
        Mota mota8 = new Mota();
        mota8.setMatricula("");
        Mota mota11 = mota8.clone();
        int i12 = mota11.getVelocidadeMedia();
        Coordenada coordenada13 = mota11.getCoordenadas();
        mota7.setCoordenadas(coordenada13);
        int i15 = mota7.getVelocidadeMedia();
        mota7.setOcupado(false);
        int i18 = mota7.getVelocidadeMedia();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertNotNull(mota7);
        org.junit.Assert.assertNotNull(mota11);
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertNotNull(coordenada13);
        org.junit.Assert.assertTrue(i15 == 10);
        org.junit.Assert.assertTrue(i18 == 10);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        int i4 = mota3.getLugares();
        boolean b5 = mota2.equals((java.lang.Object) mota3);
        mota3.setFiabilidade(100);
        int i8 = mota3.getLugares();
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue(b5 == true);
        org.junit.Assert.assertTrue(i8 == 0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        Mota mota4 = new Mota();
        mota4.setMatricula("");
        Mota mota7 = mota4.clone();
        Coordenada coordenada8 = mota7.getCoordenadas();
        Mota mota10 = new Mota((int) (byte) -1, (double) 0, (int) (short) 1, "", coordenada8, false);
        int i11 = mota10.getFiabilidade();
        Mota mota12 = mota10.clone();
        org.junit.Assert.assertNotNull(mota7);
        org.junit.Assert.assertNotNull(coordenada8);
        org.junit.Assert.assertTrue(i11 == 1);
        org.junit.Assert.assertNotNull(mota12);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        java.lang.String str2 = mota0.toString();
        mota0.setFiabilidade(0);
        mota0.setPrecoBase(1.0d);
        mota0.setOcupado(false);
        boolean b9 = mota0.getOcupado();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(b9 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        Mota mota4 = new Mota(mota3);
        int i5 = mota1.compareTo((Veiculo) mota3);
        int i6 = mota3.getVelocidadeMedia();
        Mota mota7 = mota3.clone();
        int i8 = mota7.getFiabilidade();
        int i9 = mota7.getFiabilidade();
        Mota mota10 = new Mota(mota7);
        int i11 = mota10.getLugares();
        mota10.setFiabilidade(32);
        Mota mota14 = new Mota();
        int i15 = mota14.getLugares();
        java.lang.String str16 = mota14.getMatricula();
        Mota mota17 = new Mota(mota14);
        int i18 = mota17.getFiabilidade();
        boolean b19 = mota17.getOcupado();
        int i20 = mota10.compareTo((Veiculo) mota17);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertNotNull(mota7);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(i15 == 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "n/a" + "'", str16.equals("n/a"));
        org.junit.Assert.assertTrue(i18 == 0);
        org.junit.Assert.assertTrue(b19 == false);
        org.junit.Assert.assertTrue(i20 == 0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = mota0.getCoordenadas();
        boolean b6 = mota0.getOcupado();
        java.lang.String str7 = mota0.getMatricula();
        mota0.setVelocidadeMedia(3);
        java.lang.String str10 = mota0.getMatricula();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(b6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        int i4 = mota3.getFiabilidade();
        Coordenada coordenada5 = mota3.getCoordenadas();
        int i6 = mota3.getFiabilidade();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(i6 == 0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        int i3 = mota0.getVelocidadeMedia();
        Mota mota4 = new Mota(mota0);
        int i5 = mota4.getFiabilidade();
        mota4.setMatricula("Matrícula: Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i5 == 0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        int i2 = mota1.getFiabilidade();
        mota1.setFiabilidade((-1));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        Mota mota4 = new Mota(mota0);
        Mota mota5 = new Mota(mota4);
        int i6 = mota5.getFiabilidade();
        Mota mota7 = mota5.clone();
        Coordenada coordenada8 = mota7.getCoordenadas();
        java.lang.String str9 = mota7.getMatricula();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertNotNull(mota7);
        org.junit.Assert.assertNotNull(coordenada8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "n/a" + "'", str9.equals("n/a"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota3.setOcupado(true);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        mota6.setVelocidadeMedia(10);
        int i10 = mota3.compareTo((Veiculo) mota6);
        Coordenada coordenada11 = mota3.getCoordenadas();
        int i12 = mota3.getVelocidadeMedia();
        Mota mota13 = new Mota();
        int i14 = mota13.getLugares();
        mota13.setVelocidadeMedia(10);
        Mota mota17 = new Mota(mota13);
        Mota mota18 = new Mota(mota17);
        boolean b19 = mota3.equals((java.lang.Object) mota17);
        mota3.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 35\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i10 == 3);
        org.junit.Assert.assertNotNull(coordenada11);
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(b19 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        java.lang.String str9 = mota6.toString();
        Coordenada coordenada10 = mota6.getCoordenadas();
        mota6.setFiabilidade((int) (byte) 1);
        int i13 = mota6.getVelocidadeMedia();
        java.lang.String str14 = mota6.toString();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 1\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str14.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 1\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        java.lang.String str2 = mota0.toString();
        mota0.setFiabilidade(0);
        Mota mota5 = mota0.clone();
        int i6 = mota0.getLugares();
        Mota mota11 = new Mota();
        Mota mota12 = new Mota(mota11);
        Mota mota13 = new Mota(mota12);
        Mota mota14 = new Mota();
        Mota mota15 = new Mota(mota14);
        int i16 = mota12.compareTo((Veiculo) mota14);
        Mota mota17 = new Mota();
        mota17.setMatricula("");
        boolean b21 = mota17.equals((java.lang.Object) (-1.0d));
        boolean b22 = mota12.equals((java.lang.Object) (-1.0d));
        Mota mota23 = new Mota();
        mota23.setMatricula("");
        Mota mota26 = mota23.clone();
        mota23.setPrecoBase((double) 0L);
        Mota mota29 = new Mota();
        int i30 = mota29.getLugares();
        int i31 = mota23.compareTo((Veiculo) mota29);
        java.lang.String str32 = mota29.toString();
        Coordenada coordenada33 = mota29.getCoordenadas();
        mota12.setCoordenadas(coordenada33);
        Mota mota36 = new Mota((-1), 10.0d, (int) (byte) 1, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada33, true);
        mota0.setCoordenadas(coordenada33);
        int i38 = mota0.getVelocidadeMedia();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(mota5);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue(b21 == false);
        org.junit.Assert.assertTrue(b22 == false);
        org.junit.Assert.assertNotNull(mota26);
        org.junit.Assert.assertTrue(i30 == 0);
        org.junit.Assert.assertTrue(i31 == 3);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str32.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada33);
        org.junit.Assert.assertTrue(i38 == 0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        Mota mota4 = new Mota();
        mota4.setMatricula("");
        Mota mota7 = mota4.clone();
        mota4.setPrecoBase((double) 0L);
        Mota mota10 = new Mota();
        int i11 = mota10.getLugares();
        int i12 = mota4.compareTo((Veiculo) mota10);
        java.lang.String str13 = mota10.toString();
        int i14 = mota10.getFiabilidade();
        mota10.setPrecoBase(10.0d);
        Coordenada coordenada17 = mota10.getCoordenadas();
        Mota mota19 = new Mota((int) (byte) 10, (double) (byte) 0, 33, "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n", coordenada17, false);
        java.lang.String str20 = mota19.toString();
        org.junit.Assert.assertNotNull(mota7);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(i12 == 3);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str13.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertNotNull(coordenada17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Matrícula: Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 33\nLugares: 1\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str20.equals("Matrícula: Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 33\nLugares: 1\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        mota0.setOcupado(false);
        mota0.setVelocidadeMedia((-1));
        int i7 = mota0.getFiabilidade();
        mota0.setVelocidadeMedia(3);
        mota0.setOcupado(true);
        org.junit.Assert.assertTrue(i7 == 0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = mota0.getCoordenadas();
        java.lang.String str6 = mota0.getMatricula();
        Mota mota11 = new Mota();
        mota11.setMatricula("");
        Mota mota14 = mota11.clone();
        mota11.setPrecoBase((double) 0L);
        Mota mota17 = new Mota();
        int i18 = mota17.getLugares();
        int i19 = mota11.compareTo((Veiculo) mota17);
        java.lang.String str20 = mota17.toString();
        Coordenada coordenada21 = mota17.getCoordenadas();
        Mota mota23 = new Mota((int) (byte) -1, 0.0d, (int) 'a', "", coordenada21, true);
        int i24 = mota0.compareTo((Veiculo) mota23);
        mota23.setVelocidadeMedia((-142));
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(mota14);
        org.junit.Assert.assertTrue(i18 == 0);
        org.junit.Assert.assertTrue(i19 == 3);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str20.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada21);
        org.junit.Assert.assertTrue(i24 == 0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        Mota mota0 = new Mota();
        mota0.setVelocidadeMedia((int) ' ');
        java.lang.String str3 = mota0.toString();
        Mota mota8 = new Mota();
        mota8.setMatricula("");
        Mota mota11 = mota8.clone();
        Coordenada coordenada12 = mota11.getCoordenadas();
        Mota mota14 = new Mota((int) (byte) 0, (double) 'a', 3, "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada12, false);
        boolean b15 = mota0.equals((java.lang.Object) 'a');
        mota0.setVelocidadeMedia((int) (byte) 100);
        Mota mota18 = new Mota();
        Mota mota19 = new Mota(mota18);
        Mota mota20 = new Mota(mota19);
        int i21 = mota20.getLugares();
        int i22 = mota0.compareTo((Veiculo) mota20);
        Coordenada coordenada23 = mota0.getCoordenadas();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(mota11);
        org.junit.Assert.assertNotNull(coordenada12);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertTrue(i21 == 0);
        org.junit.Assert.assertTrue(i22 == 0);
        org.junit.Assert.assertNotNull(coordenada23);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        Mota mota12 = new Mota();
        mota12.setMatricula("");
        Mota mota15 = mota12.clone();
        mota12.setPrecoBase((double) 0L);
        Mota mota18 = new Mota();
        int i19 = mota18.getLugares();
        int i20 = mota12.compareTo((Veiculo) mota18);
        java.lang.String str21 = mota18.toString();
        Coordenada coordenada22 = mota18.getCoordenadas();
        Mota mota24 = new Mota((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada22, false);
        Mota mota26 = new Mota((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada22, true);
        Mota mota28 = new Mota((int) '#', 10.0d, (-1), "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada22, true);
        java.lang.String str29 = mota28.toString();
        org.junit.Assert.assertNotNull(mota15);
        org.junit.Assert.assertTrue(i19 == 0);
        org.junit.Assert.assertTrue(i20 == 3);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str21.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada22);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Matrícula: Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 35km/h\nPreço Base: 10.0€\nFiabilidade: -1\nLugares: 1\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n" + "'", str29.equals("Matrícula: Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 35km/h\nPreço Base: 10.0€\nFiabilidade: -1\nLugares: 1\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        java.lang.String str2 = mota0.toString();
        mota0.setFiabilidade(0);
        Mota mota5 = mota0.clone();
        Mota mota10 = new Mota();
        mota10.setMatricula("");
        boolean b14 = mota10.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada15 = mota10.getCoordenadas();
        Mota mota17 = new Mota((int) (byte) 0, (double) (short) 100, (int) (byte) 10, "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada15, false);
        boolean b18 = mota5.equals((java.lang.Object) coordenada15);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(mota5);
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertNotNull(coordenada15);
        org.junit.Assert.assertTrue(b18 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        Mota mota4 = new Mota();
        mota4.setMatricula("");
        Mota mota7 = mota4.clone();
        mota4.setPrecoBase((double) 0L);
        Mota mota10 = new Mota();
        int i11 = mota10.getLugares();
        int i12 = mota4.compareTo((Veiculo) mota10);
        java.lang.String str13 = mota10.toString();
        Coordenada coordenada14 = mota10.getCoordenadas();
        Mota mota16 = new Mota((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada14, false);
        mota16.setPrecoBase((double) 10.0f);
        Coordenada coordenada19 = mota16.getCoordenadas();
        mota16.setVelocidadeMedia((int) (byte) 0);
        org.junit.Assert.assertNotNull(mota7);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(i12 == 3);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str13.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada14);
        org.junit.Assert.assertNotNull(coordenada19);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        java.lang.String str2 = mota0.toString();
        mota0.setFiabilidade(0);
        Mota mota5 = mota0.clone();
        Mota mota6 = new Mota();
        Mota mota7 = new Mota(mota6);
        Mota mota8 = new Mota(mota7);
        Mota mota9 = new Mota();
        Mota mota10 = new Mota(mota9);
        int i11 = mota7.compareTo((Veiculo) mota9);
        Mota mota12 = new Mota();
        mota12.setMatricula("");
        boolean b16 = mota12.equals((java.lang.Object) (-1.0d));
        boolean b17 = mota7.equals((java.lang.Object) (-1.0d));
        Mota mota18 = new Mota();
        mota18.setMatricula("");
        Mota mota21 = mota18.clone();
        mota18.setPrecoBase((double) 0L);
        Mota mota24 = new Mota();
        int i25 = mota24.getLugares();
        int i26 = mota18.compareTo((Veiculo) mota24);
        java.lang.String str27 = mota24.toString();
        Coordenada coordenada28 = mota24.getCoordenadas();
        mota7.setCoordenadas(coordenada28);
        mota0.setCoordenadas(coordenada28);
        boolean b31 = mota0.getOcupado();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(mota5);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(b16 == false);
        org.junit.Assert.assertTrue(b17 == false);
        org.junit.Assert.assertNotNull(mota21);
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue(i26 == 3);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str27.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada28);
        org.junit.Assert.assertTrue(b31 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        int i6 = mota0.getVelocidadeMedia();
        mota0.setOcupado(false);
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i6 == 0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Mota mota5 = new Mota(mota0);
        double d6 = mota0.getPrecoBase();
        java.lang.String str7 = mota0.toString();
        Mota mota8 = new Mota();
        Mota mota9 = new Mota(mota8);
        Mota mota10 = new Mota(mota9);
        Mota mota11 = new Mota();
        Mota mota12 = new Mota(mota11);
        int i13 = mota9.compareTo((Veiculo) mota11);
        Mota mota14 = new Mota();
        mota14.setMatricula("");
        boolean b18 = mota14.equals((java.lang.Object) (-1.0d));
        boolean b19 = mota9.equals((java.lang.Object) (-1.0d));
        Mota mota20 = new Mota();
        mota20.setMatricula("");
        Mota mota23 = mota20.clone();
        mota20.setPrecoBase((double) 0L);
        Mota mota26 = new Mota();
        int i27 = mota26.getLugares();
        int i28 = mota20.compareTo((Veiculo) mota26);
        java.lang.String str29 = mota26.toString();
        Coordenada coordenada30 = mota26.getCoordenadas();
        mota9.setCoordenadas(coordenada30);
        mota0.setCoordenadas(coordenada30);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str7.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(b18 == false);
        org.junit.Assert.assertTrue(b19 == false);
        org.junit.Assert.assertNotNull(mota23);
        org.junit.Assert.assertTrue(i27 == 0);
        org.junit.Assert.assertTrue(i28 == 3);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str29.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada30);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        Coordenada coordenada4 = mota3.getCoordenadas();
        Mota mota5 = new Mota();
        mota5.setMatricula("");
        Mota mota8 = mota5.clone();
        mota5.setPrecoBase((double) 0L);
        Mota mota11 = new Mota();
        int i12 = mota11.getLugares();
        int i13 = mota5.compareTo((Veiculo) mota11);
        java.lang.String str14 = mota11.toString();
        Coordenada coordenada15 = mota11.getCoordenadas();
        int i16 = mota3.compareTo((Veiculo) mota11);
        java.lang.String str17 = mota3.getMatricula();
        mota3.setPrecoBase((double) 10);
        int i20 = mota3.getFiabilidade();
        Mota mota21 = new Mota();
        Mota mota22 = new Mota(mota21);
        Mota mota23 = new Mota(mota22);
        Mota mota24 = new Mota();
        Mota mota25 = new Mota(mota24);
        int i26 = mota22.compareTo((Veiculo) mota24);
        int i27 = mota24.getVelocidadeMedia();
        Mota mota28 = mota24.clone();
        int i29 = mota28.getFiabilidade();
        int i30 = mota3.compareTo((Veiculo) mota28);
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertNotNull(coordenada4);
        org.junit.Assert.assertNotNull(mota8);
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertTrue(i13 == 3);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str14.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada15);
        org.junit.Assert.assertTrue(i16 == 3);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue(i20 == 0);
        org.junit.Assert.assertTrue(i26 == 0);
        org.junit.Assert.assertTrue(i27 == 0);
        org.junit.Assert.assertNotNull(mota28);
        org.junit.Assert.assertTrue(i29 == 0);
        org.junit.Assert.assertTrue(i30 == 3);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        Mota mota4 = new Mota();
        mota4.setMatricula("");
        Mota mota7 = mota4.clone();
        mota4.setPrecoBase((double) 0L);
        Mota mota10 = new Mota();
        int i11 = mota10.getLugares();
        int i12 = mota4.compareTo((Veiculo) mota10);
        java.lang.String str13 = mota10.toString();
        Coordenada coordenada14 = mota10.getCoordenadas();
        Mota mota16 = new Mota((int) (byte) 100, (double) '#', (int) (short) 0, "", coordenada14, false);
        java.lang.Object obj17 = null;
        boolean b18 = mota16.equals(obj17);
        mota16.setMatricula("");
        mota16.setMatricula("Matrícula: Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 33\nLugares: 1\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        org.junit.Assert.assertNotNull(mota7);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(i12 == 3);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str13.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada14);
        org.junit.Assert.assertTrue(b18 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        mota0.setPrecoBase(10.0d);
        mota0.setPrecoBase((-1.0d));
        mota0.setFiabilidade((-142));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        Mota mota9 = new Mota(mota6);
        int i10 = mota9.getFiabilidade();
        mota9.setFiabilidade(1);
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue(i10 == 0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        java.lang.String str9 = mota6.toString();
        int i10 = mota6.getFiabilidade();
        mota6.setPrecoBase(10.0d);
        Mota mota13 = mota6.clone();
        mota6.setPrecoBase(100.0d);
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertNotNull(mota13);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota(mota0);
        Mota mota7 = mota0.clone();
        Mota mota8 = new Mota();
        int i9 = mota8.getLugares();
        mota8.setVelocidadeMedia(10);
        Mota mota12 = new Mota(mota8);
        Mota mota13 = new Mota(mota12);
        boolean b14 = mota0.equals((java.lang.Object) mota12);
        Mota mota15 = new Mota();
        mota15.setMatricula("");
        boolean b19 = mota15.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada20 = mota15.getCoordenadas();
        mota15.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        mota15.setFiabilidade(0);
        Mota mota25 = new Mota();
        mota25.setMatricula("");
        Mota mota28 = mota25.clone();
        mota25.setPrecoBase((double) 0L);
        Mota mota31 = new Mota(mota25);
        int i32 = mota15.compareTo((Veiculo) mota25);
        Mota mota33 = new Mota(mota25);
        int i34 = mota33.getVelocidadeMedia();
        boolean b35 = mota0.equals((java.lang.Object) mota33);
        mota0.setOcupado(true);
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertNotNull(mota7);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertTrue(b19 == false);
        org.junit.Assert.assertNotNull(coordenada20);
        org.junit.Assert.assertNotNull(mota28);
        org.junit.Assert.assertTrue(i32 == (-142));
        org.junit.Assert.assertTrue(i34 == 0);
        org.junit.Assert.assertTrue(b35 == true);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        java.lang.String str2 = mota0.getMatricula();
        Mota mota3 = new Mota(mota0);
        Mota mota4 = new Mota();
        mota4.setMatricula("");
        Mota mota7 = mota4.clone();
        Coordenada coordenada8 = mota7.getCoordenadas();
        Mota mota9 = new Mota();
        mota9.setMatricula("");
        Mota mota12 = mota9.clone();
        mota9.setPrecoBase((double) 0L);
        Mota mota15 = new Mota();
        int i16 = mota15.getLugares();
        int i17 = mota9.compareTo((Veiculo) mota15);
        java.lang.String str18 = mota15.toString();
        Coordenada coordenada19 = mota15.getCoordenadas();
        int i20 = mota7.compareTo((Veiculo) mota15);
        Mota mota21 = new Mota();
        Mota mota22 = new Mota(mota21);
        java.lang.String str23 = mota21.toString();
        mota21.setFiabilidade(0);
        Mota mota26 = mota21.clone();
        int i27 = mota21.getLugares();
        Mota mota32 = new Mota();
        Mota mota33 = new Mota(mota32);
        Mota mota34 = new Mota(mota33);
        Mota mota35 = new Mota();
        Mota mota36 = new Mota(mota35);
        int i37 = mota33.compareTo((Veiculo) mota35);
        Mota mota38 = new Mota();
        mota38.setMatricula("");
        boolean b42 = mota38.equals((java.lang.Object) (-1.0d));
        boolean b43 = mota33.equals((java.lang.Object) (-1.0d));
        Mota mota44 = new Mota();
        mota44.setMatricula("");
        Mota mota47 = mota44.clone();
        mota44.setPrecoBase((double) 0L);
        Mota mota50 = new Mota();
        int i51 = mota50.getLugares();
        int i52 = mota44.compareTo((Veiculo) mota50);
        java.lang.String str53 = mota50.toString();
        Coordenada coordenada54 = mota50.getCoordenadas();
        mota33.setCoordenadas(coordenada54);
        Mota mota57 = new Mota((-1), 10.0d, (int) (byte) 1, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada54, true);
        mota21.setCoordenadas(coordenada54);
        mota15.setCoordenadas(coordenada54);
        mota0.setCoordenadas(coordenada54);
        Mota mota61 = mota0.clone();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "n/a" + "'", str2.equals("n/a"));
        org.junit.Assert.assertNotNull(mota7);
        org.junit.Assert.assertNotNull(coordenada8);
        org.junit.Assert.assertNotNull(mota12);
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue(i17 == 3);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str18.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada19);
        org.junit.Assert.assertTrue(i20 == 3);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str23.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(mota26);
        org.junit.Assert.assertTrue(i27 == 0);
        org.junit.Assert.assertTrue(i37 == 0);
        org.junit.Assert.assertTrue(b42 == false);
        org.junit.Assert.assertTrue(b43 == false);
        org.junit.Assert.assertNotNull(mota47);
        org.junit.Assert.assertTrue(i51 == 0);
        org.junit.Assert.assertTrue(i52 == 3);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str53.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada54);
        org.junit.Assert.assertNotNull(mota61);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        Mota mota4 = new Mota(mota3);
        int i5 = mota1.compareTo((Veiculo) mota3);
        Mota mota6 = new Mota();
        mota6.setMatricula("");
        boolean b10 = mota6.equals((java.lang.Object) (-1.0d));
        boolean b11 = mota1.equals((java.lang.Object) (-1.0d));
        Mota mota12 = new Mota(mota1);
        mota12.setOcupado(false);
        int i15 = mota12.getLugares();
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertTrue(i15 == 0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        Mota mota4 = new Mota();
        int i5 = mota4.getLugares();
        mota4.setVelocidadeMedia(10);
        Mota mota8 = new Mota(mota4);
        Coordenada coordenada9 = mota4.getCoordenadas();
        Mota mota11 = new Mota((int) 'a', (double) (byte) 100, 10, "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n", coordenada9, false);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertNotNull(coordenada9);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        Mota mota12 = new Mota();
        mota12.setMatricula("");
        Mota mota15 = mota12.clone();
        mota12.setPrecoBase((double) 0L);
        Mota mota18 = new Mota();
        int i19 = mota18.getLugares();
        int i20 = mota12.compareTo((Veiculo) mota18);
        java.lang.String str21 = mota18.toString();
        Coordenada coordenada22 = mota18.getCoordenadas();
        Mota mota24 = new Mota((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada22, false);
        Mota mota26 = new Mota((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada22, true);
        Mota mota28 = new Mota((int) '#', 10.0d, (-1), "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada22, true);
        Coordenada coordenada29 = mota28.getCoordenadas();
        Mota mota30 = new Mota();
        mota30.setMatricula("");
        java.lang.String str33 = mota30.toString();
        boolean b34 = mota30.getOcupado();
        boolean b35 = mota28.equals((java.lang.Object) mota30);
        int i36 = mota30.getFiabilidade();
        org.junit.Assert.assertNotNull(mota15);
        org.junit.Assert.assertTrue(i19 == 0);
        org.junit.Assert.assertTrue(i20 == 3);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str21.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada22);
        org.junit.Assert.assertNotNull(coordenada29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str33.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(b34 == false);
        org.junit.Assert.assertTrue(b35 == false);
        org.junit.Assert.assertTrue(i36 == 0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        int i2 = mota1.getFiabilidade();
        Coordenada coordenada3 = mota1.getCoordenadas();
        Mota mota4 = new Mota(mota1);
        org.junit.Assert.assertTrue(i2 == 0);
        org.junit.Assert.assertNotNull(coordenada3);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        Mota mota4 = new Mota();
        mota4.setMatricula("");
        Mota mota7 = mota4.clone();
        mota4.setPrecoBase((double) 0L);
        Mota mota10 = new Mota();
        int i11 = mota10.getLugares();
        int i12 = mota4.compareTo((Veiculo) mota10);
        java.lang.String str13 = mota10.toString();
        int i14 = mota10.getFiabilidade();
        mota10.setPrecoBase(10.0d);
        Coordenada coordenada17 = mota10.getCoordenadas();
        Mota mota19 = new Mota((int) (byte) 10, (double) 1L, (int) ' ', "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada17, false);
        org.junit.Assert.assertNotNull(mota7);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(i12 == 3);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str13.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertNotNull(coordenada17);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        int i4 = mota3.getLugares();
        boolean b5 = mota2.equals((java.lang.Object) mota3);
        Mota mota6 = mota3.clone();
        double d7 = mota3.getPrecoBase();
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue(b5 == true);
        org.junit.Assert.assertNotNull(mota6);
        org.junit.Assert.assertTrue(d7 == 0.0d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = mota0.getCoordenadas();
        java.lang.String str6 = mota0.toString();
        double d7 = mota0.getPrecoBase();
        int i8 = mota0.getFiabilidade();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str6.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(d7 == 0.0d);
        org.junit.Assert.assertTrue(i8 == 0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        java.lang.String str2 = mota0.toString();
        mota0.setFiabilidade(0);
        mota0.setOcupado(true);
        boolean b7 = mota0.getOcupado();
        int i8 = mota0.getVelocidadeMedia();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(b7 == true);
        org.junit.Assert.assertTrue(i8 == 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        double d6 = mota0.getPrecoBase();
        Mota mota7 = mota0.clone();
        java.lang.String str8 = mota7.getMatricula();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertNotNull(mota7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        Mota mota4 = new Mota(mota3);
        int i5 = mota1.compareTo((Veiculo) mota3);
        mota1.setFiabilidade(3);
        Mota mota8 = mota1.clone();
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertNotNull(mota8);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        Mota mota4 = new Mota(mota3);
        int i5 = mota1.compareTo((Veiculo) mota3);
        int i6 = mota3.getVelocidadeMedia();
        Mota mota7 = mota3.clone();
        int i8 = mota7.getFiabilidade();
        int i9 = mota7.getFiabilidade();
        mota7.setVelocidadeMedia((int) (byte) 0);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertNotNull(mota7);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue(i9 == 0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Mota mota5 = new Mota(mota0);
        double d6 = mota0.getPrecoBase();
        mota0.setFiabilidade((int) (short) 0);
        Mota mota9 = new Mota();
        mota9.setMatricula("");
        int i12 = mota9.getVelocidadeMedia();
        Mota mota13 = new Mota(mota9);
        boolean b14 = mota0.equals((java.lang.Object) mota9);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertTrue(b14 == true);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        Mota mota4 = new Mota(mota0);
        Mota mota5 = new Mota(mota4);
        int i6 = mota5.getFiabilidade();
        Mota mota7 = mota5.clone();
        Mota mota8 = new Mota();
        mota8.setMatricula("");
        Mota mota11 = mota8.clone();
        int i12 = mota11.getVelocidadeMedia();
        Coordenada coordenada13 = mota11.getCoordenadas();
        mota7.setCoordenadas(coordenada13);
        int i15 = mota7.getVelocidadeMedia();
        double d16 = mota7.getPrecoBase();
        boolean b18 = mota7.equals((java.lang.Object) (byte) 1);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertNotNull(mota7);
        org.junit.Assert.assertNotNull(mota11);
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertNotNull(coordenada13);
        org.junit.Assert.assertTrue(i15 == 10);
        org.junit.Assert.assertTrue(d16 == 0.0d);
        org.junit.Assert.assertTrue(b18 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        int i4 = mota3.getFiabilidade();
        java.lang.String str5 = mota3.getMatricula();
        int i6 = mota3.getVelocidadeMedia();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue(i6 == 0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        java.lang.String str2 = mota0.getMatricula();
        Mota mota3 = new Mota(mota0);
        int i4 = mota3.getFiabilidade();
        mota3.setFiabilidade((int) (short) 1);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "n/a" + "'", str2.equals("n/a"));
        org.junit.Assert.assertTrue(i4 == 0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        Mota mota4 = new Mota();
        mota4.setMatricula("");
        boolean b8 = mota4.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada9 = mota4.getCoordenadas();
        Mota mota11 = new Mota((int) (byte) 0, (double) (short) 100, (int) (byte) 10, "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada9, false);
        java.lang.String str12 = mota11.toString();
        org.junit.Assert.assertTrue(b8 == false);
        org.junit.Assert.assertNotNull(coordenada9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Matrícula: Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 100.0€\nFiabilidade: 10\nLugares: 1\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str12.equals("Matrícula: Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 100.0€\nFiabilidade: 10\nLugares: 1\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        Mota mota8 = new Mota();
        mota8.setMatricula("");
        Mota mota11 = mota8.clone();
        Coordenada coordenada12 = mota11.getCoordenadas();
        Mota mota14 = new Mota((int) (byte) 0, (double) 'a', 3, "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada12, false);
        Mota mota16 = new Mota(1, (double) (short) 10, 0, "Matrícula: Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada12, true);
        org.junit.Assert.assertNotNull(mota11);
        org.junit.Assert.assertNotNull(coordenada12);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        Mota mota4 = new Mota(mota0);
        int i5 = mota0.getVelocidadeMedia();
        java.lang.String str6 = mota0.getMatricula();
        Mota mota7 = new Mota(mota0);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i5 == 10);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "n/a" + "'", str6.equals("n/a"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        Mota mota8 = new Mota();
        Mota mota9 = new Mota(mota8);
        Mota mota10 = new Mota(mota9);
        Mota mota11 = new Mota();
        Mota mota12 = new Mota(mota11);
        int i13 = mota9.compareTo((Veiculo) mota11);
        Mota mota14 = new Mota();
        mota14.setMatricula("");
        boolean b18 = mota14.equals((java.lang.Object) (-1.0d));
        boolean b19 = mota9.equals((java.lang.Object) (-1.0d));
        Mota mota20 = new Mota();
        mota20.setMatricula("");
        Mota mota23 = mota20.clone();
        mota20.setPrecoBase((double) 0L);
        Mota mota26 = new Mota();
        int i27 = mota26.getLugares();
        int i28 = mota20.compareTo((Veiculo) mota26);
        java.lang.String str29 = mota26.toString();
        Coordenada coordenada30 = mota26.getCoordenadas();
        mota9.setCoordenadas(coordenada30);
        Mota mota33 = new Mota((-1), 10.0d, (int) (byte) 1, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada30, true);
        Mota mota35 = new Mota((int) (byte) 10, (double) 10, (-33), "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada30, true);
        int i36 = mota35.getVelocidadeMedia();
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(b18 == false);
        org.junit.Assert.assertTrue(b19 == false);
        org.junit.Assert.assertNotNull(mota23);
        org.junit.Assert.assertTrue(i27 == 0);
        org.junit.Assert.assertTrue(i28 == 3);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str29.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada30);
        org.junit.Assert.assertTrue(i36 == 10);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        java.lang.String str2 = mota0.toString();
        mota0.setFiabilidade(0);
        int i5 = mota0.getFiabilidade();
        Mota mota6 = new Mota(mota0);
        int i7 = mota6.getFiabilidade();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(i7 == 0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        Coordenada coordenada4 = mota3.getCoordenadas();
        Mota mota5 = new Mota();
        mota5.setMatricula("");
        Mota mota8 = mota5.clone();
        mota5.setPrecoBase((double) 0L);
        Mota mota11 = new Mota();
        int i12 = mota11.getLugares();
        int i13 = mota5.compareTo((Veiculo) mota11);
        java.lang.String str14 = mota11.toString();
        Coordenada coordenada15 = mota11.getCoordenadas();
        int i16 = mota3.compareTo((Veiculo) mota11);
        java.lang.String str17 = mota3.getMatricula();
        mota3.setPrecoBase((double) 10);
        int i20 = mota3.getFiabilidade();
        mota3.setPrecoBase((double) (short) 10);
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertNotNull(coordenada4);
        org.junit.Assert.assertNotNull(mota8);
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertTrue(i13 == 3);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str14.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada15);
        org.junit.Assert.assertTrue(i16 == 3);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue(i20 == 0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        Mota mota4 = new Mota(mota0);
        int i5 = mota0.getVelocidadeMedia();
        mota0.setMatricula("");
        mota0.setPrecoBase((double) (byte) 1);
        mota0.setFiabilidade(33);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i5 == 10);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        mota1.setVelocidadeMedia(0);
        mota1.setPrecoBase((double) 10L);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        int i4 = mota3.getLugares();
        boolean b5 = mota2.equals((java.lang.Object) mota3);
        mota3.setOcupado(true);
        boolean b8 = mota3.getOcupado();
        int i9 = mota3.getVelocidadeMedia();
        int i10 = mota3.getVelocidadeMedia();
        mota3.setPrecoBase((double) 10.0f);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue(b5 == true);
        org.junit.Assert.assertTrue(b8 == true);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertTrue(i10 == 0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        int i9 = mota6.getFiabilidade();
        Mota mota10 = new Mota(mota6);
        java.lang.String str11 = mota10.getMatricula();
        int i12 = mota10.getFiabilidade();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "n/a" + "'", str11.equals("n/a"));
        org.junit.Assert.assertTrue(i12 == 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        Coordenada coordenada2 = mota0.getCoordenadas();
        mota0.setFiabilidade(3);
        java.lang.String str5 = mota0.getMatricula();
        double d6 = mota0.getPrecoBase();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(coordenada2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "n/a" + "'", str5.equals("n/a"));
        org.junit.Assert.assertTrue(d6 == 0.0d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        boolean b6 = mota0.getOcupado();
        int i7 = mota0.getLugares();
        Mota mota8 = new Mota();
        mota8.setMatricula("");
        Mota mota11 = mota8.clone();
        mota8.setPrecoBase((double) 0L);
        Mota mota14 = new Mota(mota8);
        int i15 = mota8.getLugares();
        Mota mota16 = new Mota();
        int i17 = mota16.getLugares();
        mota16.setVelocidadeMedia(10);
        mota16.setMatricula("n/a");
        mota16.setPrecoBase((double) 1L);
        Coordenada coordenada24 = mota16.getCoordenadas();
        mota8.setCoordenadas(coordenada24);
        mota0.setCoordenadas(coordenada24);
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(b6 == false);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertNotNull(mota11);
        org.junit.Assert.assertTrue(i15 == 0);
        org.junit.Assert.assertTrue(i17 == 0);
        org.junit.Assert.assertNotNull(coordenada24);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota(mota0);
        mota6.setPrecoBase((double) (-1.0f));
        mota6.setPrecoBase((double) 10);
        Mota mota11 = mota6.clone();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertNotNull(mota11);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = mota0.getCoordenadas();
        boolean b6 = mota0.getOcupado();
        java.lang.String str7 = mota0.getMatricula();
        int i8 = mota0.getFiabilidade();
        boolean b9 = mota0.getOcupado();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(b6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue(b9 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Mota mota5 = new Mota(mota0);
        double d6 = mota0.getPrecoBase();
        boolean b7 = mota0.getOcupado();
        int i8 = mota0.getVelocidadeMedia();
        java.lang.String str9 = mota0.getMatricula();
        java.lang.String str10 = mota0.getMatricula();
        mota0.setFiabilidade((int) (short) -1);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(b7 == false);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        mota1.setPrecoBase((double) 10.0f);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        Mota mota4 = new Mota();
        mota4.setMatricula("");
        Mota mota7 = mota4.clone();
        mota4.setPrecoBase((double) 0L);
        Mota mota10 = new Mota();
        int i11 = mota10.getLugares();
        int i12 = mota4.compareTo((Veiculo) mota10);
        java.lang.String str13 = mota10.toString();
        Coordenada coordenada14 = mota10.getCoordenadas();
        Mota mota16 = new Mota((int) ' ', (double) 100.0f, (int) (byte) -1, "", coordenada14, false);
        Mota mota17 = new Mota();
        mota17.setMatricula("");
        java.lang.String str20 = mota17.toString();
        Mota mota21 = mota17.clone();
        java.lang.String str22 = mota17.toString();
        Coordenada coordenada23 = mota17.getCoordenadas();
        mota16.setCoordenadas(coordenada23);
        org.junit.Assert.assertNotNull(mota7);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(i12 == 3);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str13.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str20.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(mota21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str22.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada23);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        java.lang.String str2 = mota0.toString();
        mota0.setFiabilidade(0);
        mota0.setOcupado(true);
        mota0.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = mota0.getCoordenadas();
        int i6 = mota0.getVelocidadeMedia();
        Mota mota7 = new Mota();
        mota7.setMatricula("");
        Mota mota10 = mota7.clone();
        mota10.setOcupado(true);
        boolean b13 = mota0.equals((java.lang.Object) mota10);
        mota10.setMatricula("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Mota mota16 = new Mota(mota10);
        int i17 = mota10.getLugares();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertNotNull(mota10);
        org.junit.Assert.assertTrue(b13 == false);
        org.junit.Assert.assertTrue(i17 == 0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        int i2 = mota1.getFiabilidade();
        Coordenada coordenada3 = mota1.getCoordenadas();
        mota1.setMatricula("Matrícula: Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 100.0€\nFiabilidade: 10\nLugares: 1\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        org.junit.Assert.assertTrue(i2 == 0);
        org.junit.Assert.assertNotNull(coordenada3);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Mota mota5 = new Mota(mota0);
        double d6 = mota0.getPrecoBase();
        boolean b7 = mota0.getOcupado();
        mota0.setOcupado(false);
        Mota mota10 = new Mota();
        int i11 = mota10.getLugares();
        mota10.setVelocidadeMedia(10);
        Mota mota14 = new Mota(mota10);
        Mota mota15 = mota14.clone();
        int i16 = mota0.compareTo((Veiculo) mota15);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(b7 == false);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertNotNull(mota15);
        org.junit.Assert.assertTrue(i16 == 3);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota3.setOcupado(true);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        mota6.setVelocidadeMedia(10);
        int i10 = mota3.compareTo((Veiculo) mota6);
        Coordenada coordenada11 = mota3.getCoordenadas();
        int i12 = mota3.getLugares();
        mota3.setOcupado(true);
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i10 == 3);
        org.junit.Assert.assertNotNull(coordenada11);
        org.junit.Assert.assertTrue(i12 == 0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        Mota mota4 = new Mota();
        mota4.setMatricula("");
        Mota mota7 = mota4.clone();
        Coordenada coordenada8 = mota7.getCoordenadas();
        Mota mota10 = new Mota((int) (byte) 0, (double) 'a', 3, "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada8, false);
        java.lang.Object obj11 = null;
        boolean b12 = mota10.equals(obj11);
        boolean b13 = mota10.getOcupado();
        Mota mota18 = new Mota();
        mota18.setMatricula("");
        Mota mota21 = mota18.clone();
        Coordenada coordenada22 = mota21.getCoordenadas();
        Mota mota24 = new Mota((int) (byte) 0, (double) 'a', 3, "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada22, false);
        java.lang.Object obj25 = null;
        boolean b26 = mota24.equals(obj25);
        boolean b27 = mota24.getOcupado();
        int i28 = mota10.compareTo((Veiculo) mota24);
        Coordenada coordenada29 = null;
        try {
            mota24.setCoordenadas(coordenada29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(mota7);
        org.junit.Assert.assertNotNull(coordenada8);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertTrue(b13 == false);
        org.junit.Assert.assertNotNull(mota21);
        org.junit.Assert.assertNotNull(coordenada22);
        org.junit.Assert.assertTrue(b26 == false);
        org.junit.Assert.assertTrue(b27 == false);
        org.junit.Assert.assertTrue(i28 == 0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        int i4 = mota3.getFiabilidade();
        java.lang.String str5 = mota3.toString();
        mota3.setPrecoBase((double) '4');
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str5.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        java.lang.String str2 = mota0.getMatricula();
        mota0.setVelocidadeMedia((-1));
        java.lang.String str5 = mota0.toString();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "n/a" + "'", str2.equals("n/a"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: -1km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str5.equals("Matrícula: n/a\nVelocidade Média/km: -1km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        Mota mota4 = new Mota(mota3);
        int i5 = mota1.compareTo((Veiculo) mota3);
        Mota mota6 = new Mota();
        mota6.setMatricula("");
        boolean b10 = mota6.equals((java.lang.Object) (-1.0d));
        boolean b11 = mota1.equals((java.lang.Object) (-1.0d));
        Mota mota12 = new Mota();
        mota12.setMatricula("");
        Mota mota15 = mota12.clone();
        mota12.setPrecoBase((double) 0L);
        Mota mota18 = new Mota();
        int i19 = mota18.getLugares();
        int i20 = mota12.compareTo((Veiculo) mota18);
        java.lang.String str21 = mota18.toString();
        Coordenada coordenada22 = mota18.getCoordenadas();
        mota1.setCoordenadas(coordenada22);
        mota1.setPrecoBase((double) (short) 10);
        java.lang.String str26 = mota1.getMatricula();
        mota1.setMatricula("hi!");
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertNotNull(mota15);
        org.junit.Assert.assertTrue(i19 == 0);
        org.junit.Assert.assertTrue(i20 == 3);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str21.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada22);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "n/a" + "'", str26.equals("n/a"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        Mota mota4 = new Mota();
        mota4.setMatricula("");
        Mota mota7 = mota4.clone();
        mota4.setPrecoBase((double) 0L);
        Mota mota10 = new Mota();
        int i11 = mota10.getLugares();
        int i12 = mota4.compareTo((Veiculo) mota10);
        java.lang.String str13 = mota10.toString();
        Coordenada coordenada14 = mota10.getCoordenadas();
        Mota mota16 = new Mota((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada14, false);
        mota16.setPrecoBase((double) 10.0f);
        mota16.setOcupado(false);
        mota16.setOcupado(true);
        org.junit.Assert.assertNotNull(mota7);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(i12 == 3);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str13.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada14);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        int i4 = mota3.getVelocidadeMedia();
        Coordenada coordenada5 = mota3.getCoordenadas();
        Mota mota6 = new Mota();
        mota6.setMatricula("");
        Mota mota9 = mota6.clone();
        mota6.setPrecoBase((double) 0L);
        Mota mota12 = new Mota();
        int i13 = mota12.getLugares();
        int i14 = mota6.compareTo((Veiculo) mota12);
        java.lang.String str15 = mota12.toString();
        java.lang.String str16 = mota12.toString();
        boolean b17 = mota3.equals((java.lang.Object) str16);
        mota3.setFiabilidade((int) (byte) 0);
        int i20 = mota3.getLugares();
        boolean b21 = mota3.getOcupado();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertNotNull(mota9);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(i14 == 3);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str15.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str16.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(b17 == false);
        org.junit.Assert.assertTrue(i20 == 0);
        org.junit.Assert.assertTrue(b21 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        Mota mota4 = new Mota(mota3);
        int i5 = mota1.compareTo((Veiculo) mota3);
        int i6 = mota3.getVelocidadeMedia();
        Mota mota7 = mota3.clone();
        Mota mota8 = new Mota(mota7);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertNotNull(mota7);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        Mota mota9 = new Mota(mota6);
        Mota mota10 = new Mota();
        Mota mota11 = new Mota(mota10);
        Mota mota12 = new Mota(mota11);
        Mota mota13 = new Mota();
        Mota mota14 = new Mota(mota13);
        int i15 = mota11.compareTo((Veiculo) mota13);
        int i16 = mota13.getVelocidadeMedia();
        int i17 = mota9.compareTo((Veiculo) mota13);
        Mota mota18 = new Mota();
        mota18.setMatricula("");
        boolean b22 = mota18.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada23 = mota18.getCoordenadas();
        mota18.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        mota18.setFiabilidade(0);
        mota18.setVelocidadeMedia((-1));
        Coordenada coordenada30 = mota18.getCoordenadas();
        mota9.setCoordenadas(coordenada30);
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue(i15 == 0);
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue(i17 == 0);
        org.junit.Assert.assertTrue(b22 == false);
        org.junit.Assert.assertNotNull(coordenada23);
        org.junit.Assert.assertNotNull(coordenada30);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        double d6 = mota0.getPrecoBase();
        int i7 = mota0.getVelocidadeMedia();
        mota0.setMatricula("");
        mota0.setPrecoBase((double) (-33));
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(i7 == 0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        Coordenada coordenada4 = mota3.getCoordenadas();
        int i5 = mota3.getVelocidadeMedia();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertNotNull(coordenada4);
        org.junit.Assert.assertTrue(i5 == 0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        java.lang.String str3 = mota0.toString();
        Mota mota4 = mota0.clone();
        Mota mota17 = new Mota();
        mota17.setMatricula("");
        Mota mota20 = mota17.clone();
        mota17.setPrecoBase((double) 0L);
        Mota mota23 = new Mota();
        int i24 = mota23.getLugares();
        int i25 = mota17.compareTo((Veiculo) mota23);
        java.lang.String str26 = mota23.toString();
        Coordenada coordenada27 = mota23.getCoordenadas();
        Mota mota29 = new Mota((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada27, false);
        Mota mota31 = new Mota((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada27, true);
        Mota mota33 = new Mota((int) '#', 10.0d, (-1), "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada27, true);
        Coordenada coordenada34 = mota33.getCoordenadas();
        mota4.setCoordenadas(coordenada34);
        double d36 = mota4.getPrecoBase();
        double d37 = mota4.getPrecoBase();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(mota4);
        org.junit.Assert.assertNotNull(mota20);
        org.junit.Assert.assertTrue(i24 == 0);
        org.junit.Assert.assertTrue(i25 == 3);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str26.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada27);
        org.junit.Assert.assertNotNull(coordenada34);
        org.junit.Assert.assertTrue(d36 == 0.0d);
        org.junit.Assert.assertTrue(d37 == 0.0d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        java.lang.String str9 = mota6.toString();
        int i10 = mota6.getFiabilidade();
        mota6.setPrecoBase(10.0d);
        int i13 = mota6.getVelocidadeMedia();
        Mota mota14 = new Mota(mota6);
        Coordenada coordenada15 = mota14.getCoordenadas();
        double d16 = mota14.getPrecoBase();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertNotNull(coordenada15);
        org.junit.Assert.assertTrue(d16 == 10.0d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        java.lang.String str2 = mota0.getMatricula();
        Coordenada coordenada3 = mota0.getCoordenadas();
        int i4 = mota0.getFiabilidade();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "n/a" + "'", str2.equals("n/a"));
        org.junit.Assert.assertNotNull(coordenada3);
        org.junit.Assert.assertTrue(i4 == 0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        java.lang.String str9 = mota6.toString();
        int i10 = mota6.getFiabilidade();
        mota6.setPrecoBase(10.0d);
        Mota mota13 = mota6.clone();
        int i14 = mota6.getFiabilidade();
        mota6.setVelocidadeMedia(0);
        mota6.setPrecoBase((double) 1.0f);
        mota6.setPrecoBase((double) (-1L));
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertNotNull(mota13);
        org.junit.Assert.assertTrue(i14 == 0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        Mota mota0 = new Mota();
        java.lang.String str1 = mota0.toString();
        double d2 = mota0.getPrecoBase();
        java.lang.String str3 = mota0.getMatricula();
        int i4 = mota0.getFiabilidade();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str1.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(d2 == 0.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "n/a" + "'", str3.equals("n/a"));
        org.junit.Assert.assertTrue(i4 == 0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        Mota mota4 = new Mota(mota0);
        boolean b5 = mota0.getOcupado();
        double d6 = mota0.getPrecoBase();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(b5 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        int i3 = mota0.getVelocidadeMedia();
        Mota mota4 = new Mota(mota0);
        boolean b5 = mota4.getOcupado();
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(b5 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        Mota mota4 = new Mota();
        Mota mota5 = new Mota(mota4);
        int i6 = mota5.getFiabilidade();
        Coordenada coordenada7 = mota5.getCoordenadas();
        Mota mota9 = new Mota(0, (double) 32, (-3), "Matrícula: Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 100.0€\nFiabilidade: 10\nLugares: 1\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada7, true);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertNotNull(coordenada7);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        Mota mota4 = new Mota();
        mota4.setMatricula("");
        Mota mota7 = mota4.clone();
        mota4.setPrecoBase((double) 0L);
        Mota mota10 = new Mota();
        int i11 = mota10.getLugares();
        int i12 = mota4.compareTo((Veiculo) mota10);
        java.lang.String str13 = mota10.toString();
        Coordenada coordenada14 = mota10.getCoordenadas();
        Mota mota16 = new Mota(0, (double) 0L, 0, "hi!", coordenada14, true);
        mota16.setPrecoBase((double) '#');
        Mota mota19 = new Mota(mota16);
        org.junit.Assert.assertNotNull(mota7);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(i12 == 3);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str13.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada14);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        java.lang.String str3 = mota0.toString();
        Mota mota4 = new Mota();
        Mota mota5 = new Mota(mota4);
        java.lang.String str6 = mota4.toString();
        mota4.setFiabilidade(0);
        Mota mota9 = mota4.clone();
        Mota mota10 = new Mota();
        Mota mota11 = new Mota(mota10);
        Mota mota12 = new Mota(mota11);
        Mota mota13 = new Mota();
        Mota mota14 = new Mota(mota13);
        int i15 = mota11.compareTo((Veiculo) mota13);
        Mota mota16 = new Mota();
        mota16.setMatricula("");
        boolean b20 = mota16.equals((java.lang.Object) (-1.0d));
        boolean b21 = mota11.equals((java.lang.Object) (-1.0d));
        Mota mota22 = new Mota();
        mota22.setMatricula("");
        Mota mota25 = mota22.clone();
        mota22.setPrecoBase((double) 0L);
        Mota mota28 = new Mota();
        int i29 = mota28.getLugares();
        int i30 = mota22.compareTo((Veiculo) mota28);
        java.lang.String str31 = mota28.toString();
        Coordenada coordenada32 = mota28.getCoordenadas();
        mota11.setCoordenadas(coordenada32);
        mota4.setCoordenadas(coordenada32);
        mota0.setCoordenadas(coordenada32);
        int i36 = mota0.getFiabilidade();
        java.lang.String str37 = mota0.getMatricula();
        java.lang.String str38 = mota0.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str6.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(mota9);
        org.junit.Assert.assertTrue(i15 == 0);
        org.junit.Assert.assertTrue(b20 == false);
        org.junit.Assert.assertTrue(b21 == false);
        org.junit.Assert.assertNotNull(mota25);
        org.junit.Assert.assertTrue(i29 == 0);
        org.junit.Assert.assertTrue(i30 == 3);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str31.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada32);
        org.junit.Assert.assertTrue(i36 == 0);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "" + "'", str37.equals(""));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str38.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        java.lang.String str9 = mota6.toString();
        Coordenada coordenada10 = mota6.getCoordenadas();
        Mota mota11 = new Mota();
        int i12 = mota11.getLugares();
        Coordenada coordenada13 = mota11.getCoordenadas();
        mota6.setCoordenadas(coordenada13);
        int i15 = mota6.getFiabilidade();
        java.lang.String str16 = mota6.toString();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertNotNull(coordenada13);
        org.junit.Assert.assertTrue(i15 == 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str16.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        java.lang.String str9 = mota6.toString();
        Coordenada coordenada10 = mota6.getCoordenadas();
        Mota mota11 = mota6.clone();
        Mota mota12 = new Mota();
        mota12.setMatricula("");
        boolean b16 = mota12.equals((java.lang.Object) (-1.0d));
        Mota mota17 = new Mota(mota12);
        double d18 = mota12.getPrecoBase();
        java.lang.String str19 = mota12.toString();
        int i20 = mota12.getVelocidadeMedia();
        boolean b21 = mota11.equals((java.lang.Object) mota12);
        double d22 = mota12.getPrecoBase();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertNotNull(mota11);
        org.junit.Assert.assertTrue(b16 == false);
        org.junit.Assert.assertTrue(d18 == 0.0d);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str19.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i20 == 0);
        org.junit.Assert.assertTrue(b21 == false);
        org.junit.Assert.assertTrue(d22 == 0.0d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        Mota mota4 = new Mota();
        mota4.setMatricula("");
        java.lang.String str7 = mota4.toString();
        Mota mota8 = mota4.clone();
        Mota mota21 = new Mota();
        mota21.setMatricula("");
        Mota mota24 = mota21.clone();
        mota21.setPrecoBase((double) 0L);
        Mota mota27 = new Mota();
        int i28 = mota27.getLugares();
        int i29 = mota21.compareTo((Veiculo) mota27);
        java.lang.String str30 = mota27.toString();
        Coordenada coordenada31 = mota27.getCoordenadas();
        Mota mota33 = new Mota((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada31, false);
        Mota mota35 = new Mota((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada31, true);
        Mota mota37 = new Mota((int) '#', 10.0d, (-1), "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada31, true);
        Coordenada coordenada38 = mota37.getCoordenadas();
        mota8.setCoordenadas(coordenada38);
        Mota mota41 = new Mota(0, (double) 0L, 100, "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada38, true);
        mota41.setOcupado(false);
        boolean b44 = mota41.getOcupado();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str7.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(mota8);
        org.junit.Assert.assertNotNull(mota24);
        org.junit.Assert.assertTrue(i28 == 0);
        org.junit.Assert.assertTrue(i29 == 3);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str30.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada31);
        org.junit.Assert.assertNotNull(coordenada38);
        org.junit.Assert.assertTrue(b44 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        Mota mota4 = new Mota(mota0);
        int i5 = mota0.getVelocidadeMedia();
        mota0.setMatricula("");
        int i8 = mota0.getLugares();
        Mota mota9 = new Mota();
        mota9.setMatricula("");
        Mota mota12 = mota9.clone();
        mota12.setOcupado(true);
        mota12.setFiabilidade(0);
        mota12.setMatricula("Matrícula: Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        boolean b19 = mota0.equals((java.lang.Object) "Matrícula: Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        java.lang.String str20 = mota0.toString();
        Coordenada coordenada21 = mota0.getCoordenadas();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i5 == 10);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertNotNull(mota12);
        org.junit.Assert.assertTrue(b19 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Matrícula: \nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str20.equals("Matrícula: \nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada21);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        Coordenada coordenada4 = mota3.getCoordenadas();
        Mota mota5 = new Mota();
        mota5.setMatricula("");
        Mota mota8 = mota5.clone();
        mota5.setPrecoBase((double) 0L);
        Mota mota11 = new Mota();
        int i12 = mota11.getLugares();
        int i13 = mota5.compareTo((Veiculo) mota11);
        java.lang.String str14 = mota11.toString();
        Coordenada coordenada15 = mota11.getCoordenadas();
        int i16 = mota3.compareTo((Veiculo) mota11);
        java.lang.String str17 = mota3.getMatricula();
        int i18 = mota3.getLugares();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertNotNull(coordenada4);
        org.junit.Assert.assertNotNull(mota8);
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertTrue(i13 == 3);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str14.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada15);
        org.junit.Assert.assertTrue(i16 == 3);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue(i18 == 0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        Mota mota4 = new Mota(mota0);
        int i5 = mota0.getVelocidadeMedia();
        java.lang.String str6 = mota0.getMatricula();
        mota0.setVelocidadeMedia((int) (byte) 1);
        mota0.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 100.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        int i11 = mota0.getVelocidadeMedia();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i5 == 10);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "n/a" + "'", str6.equals("n/a"));
        org.junit.Assert.assertTrue(i11 == 1);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        Mota mota4 = new Mota(mota3);
        int i5 = mota1.compareTo((Veiculo) mota3);
        mota3.setMatricula("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        int i8 = mota3.getFiabilidade();
        Mota mota9 = mota3.clone();
        Coordenada coordenada10 = mota9.getCoordenadas();
        boolean b11 = mota9.getOcupado();
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertNotNull(mota9);
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertTrue(b11 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        Mota mota4 = new Mota(mota3);
        int i5 = mota1.compareTo((Veiculo) mota3);
        Mota mota6 = new Mota();
        mota6.setMatricula("");
        boolean b10 = mota6.equals((java.lang.Object) (-1.0d));
        boolean b11 = mota1.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada12 = mota1.getCoordenadas();
        mota1.setOcupado(false);
        int i15 = mota1.getFiabilidade();
        mota1.setOcupado(false);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertNotNull(coordenada12);
        org.junit.Assert.assertTrue(i15 == 0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        Mota mota4 = new Mota(mota3);
        int i5 = mota1.compareTo((Veiculo) mota3);
        Mota mota6 = new Mota(mota3);
        mota6.setOcupado(true);
        mota6.setFiabilidade((int) (short) 0);
        org.junit.Assert.assertTrue(i5 == 0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        Mota mota4 = new Mota();
        mota4.setMatricula("");
        Mota mota7 = mota4.clone();
        Coordenada coordenada8 = mota7.getCoordenadas();
        Mota mota10 = new Mota((int) (byte) 0, (double) 'a', 3, "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada8, false);
        java.lang.Object obj11 = null;
        boolean b12 = mota10.equals(obj11);
        boolean b13 = mota10.getOcupado();
        boolean b14 = mota10.getOcupado();
        org.junit.Assert.assertNotNull(mota7);
        org.junit.Assert.assertNotNull(coordenada8);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertTrue(b13 == false);
        org.junit.Assert.assertTrue(b14 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota3.setOcupado(true);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        mota6.setVelocidadeMedia(10);
        int i10 = mota3.compareTo((Veiculo) mota6);
        Coordenada coordenada11 = mota3.getCoordenadas();
        mota3.setVelocidadeMedia(0);
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i10 == 3);
        org.junit.Assert.assertNotNull(coordenada11);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        Mota mota4 = new Mota(mota0);
        Mota mota5 = new Mota(mota4);
        int i6 = mota5.getFiabilidade();
        boolean b7 = mota5.getOcupado();
        java.lang.String str8 = mota5.toString();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertTrue(b7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str8.equals("Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        mota0.setMatricula("n/a");
        double d11 = mota0.getPrecoBase();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue(d11 == 0.0d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        Mota mota4 = mota0.clone();
        mota0.setMatricula("Matrícula: Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        int i7 = mota0.getLugares();
        Mota mota8 = new Mota();
        mota8.setMatricula("");
        boolean b12 = mota8.equals((java.lang.Object) (-1.0d));
        Mota mota13 = new Mota(mota8);
        double d14 = mota8.getPrecoBase();
        boolean b15 = mota8.getOcupado();
        int i16 = mota8.getVelocidadeMedia();
        java.lang.String str17 = mota8.getMatricula();
        mota8.setMatricula("hi!");
        mota8.setVelocidadeMedia((int) (byte) 1);
        Coordenada coordenada22 = mota8.getCoordenadas();
        int i23 = mota0.compareTo((Veiculo) mota8);
        mota0.setMatricula("Matrícula: Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: -1.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(mota4);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertTrue(d14 == 0.0d);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(coordenada22);
        org.junit.Assert.assertTrue(i23 == 27);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        Mota mota8 = new Mota();
        Mota mota9 = new Mota(mota8);
        Mota mota10 = new Mota(mota9);
        Mota mota11 = new Mota();
        Mota mota12 = new Mota(mota11);
        int i13 = mota9.compareTo((Veiculo) mota11);
        Mota mota14 = new Mota();
        mota14.setMatricula("");
        boolean b18 = mota14.equals((java.lang.Object) (-1.0d));
        boolean b19 = mota9.equals((java.lang.Object) (-1.0d));
        Mota mota20 = new Mota();
        mota20.setMatricula("");
        Mota mota23 = mota20.clone();
        mota20.setPrecoBase((double) 0L);
        Mota mota26 = new Mota();
        int i27 = mota26.getLugares();
        int i28 = mota20.compareTo((Veiculo) mota26);
        java.lang.String str29 = mota26.toString();
        Coordenada coordenada30 = mota26.getCoordenadas();
        mota9.setCoordenadas(coordenada30);
        Mota mota33 = new Mota((-1), 10.0d, (int) (byte) 1, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada30, true);
        Mota mota35 = new Mota((int) (byte) 10, (double) 10, (-33), "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada30, true);
        int i36 = mota35.getLugares();
        java.lang.String str37 = mota35.getMatricula();
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(b18 == false);
        org.junit.Assert.assertTrue(b19 == false);
        org.junit.Assert.assertNotNull(mota23);
        org.junit.Assert.assertTrue(i27 == 0);
        org.junit.Assert.assertTrue(i28 == 3);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str29.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada30);
        org.junit.Assert.assertTrue(i36 == 1);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str37.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        Mota mota4 = new Mota();
        Mota mota5 = new Mota(mota4);
        Mota mota6 = new Mota(mota5);
        Mota mota7 = new Mota();
        Mota mota8 = new Mota(mota7);
        int i9 = mota5.compareTo((Veiculo) mota7);
        Mota mota10 = new Mota();
        mota10.setMatricula("");
        boolean b14 = mota10.equals((java.lang.Object) (-1.0d));
        boolean b15 = mota5.equals((java.lang.Object) (-1.0d));
        Mota mota16 = new Mota();
        mota16.setMatricula("");
        Mota mota19 = mota16.clone();
        mota16.setPrecoBase((double) 0L);
        Mota mota22 = new Mota();
        int i23 = mota22.getLugares();
        int i24 = mota16.compareTo((Veiculo) mota22);
        java.lang.String str25 = mota22.toString();
        Coordenada coordenada26 = mota22.getCoordenadas();
        mota5.setCoordenadas(coordenada26);
        Mota mota29 = new Mota(100, (double) 100, 100, "Matrícula: Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada26, true);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertNotNull(mota19);
        org.junit.Assert.assertTrue(i23 == 0);
        org.junit.Assert.assertTrue(i24 == 3);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str25.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada26);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        Mota mota4 = new Mota(mota3);
        int i5 = mota1.compareTo((Veiculo) mota3);
        int i6 = mota3.getVelocidadeMedia();
        Mota mota7 = mota3.clone();
        int i8 = mota7.getFiabilidade();
        Mota mota9 = new Mota();
        mota9.setMatricula("");
        boolean b13 = mota9.equals((java.lang.Object) (-1.0d));
        Mota mota14 = new Mota(mota9);
        double d15 = mota9.getPrecoBase();
        boolean b16 = mota9.getOcupado();
        mota9.setOcupado(false);
        int i19 = mota7.compareTo((Veiculo) mota9);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertNotNull(mota7);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue(b13 == false);
        org.junit.Assert.assertTrue(d15 == 0.0d);
        org.junit.Assert.assertTrue(b16 == false);
        org.junit.Assert.assertTrue(i19 == (-3));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        int i9 = mota6.getFiabilidade();
        Mota mota10 = mota6.clone();
        Mota mota11 = mota10.clone();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertNotNull(mota10);
        org.junit.Assert.assertNotNull(mota11);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        java.lang.String str9 = mota6.toString();
        int i10 = mota6.getFiabilidade();
        mota6.setPrecoBase(10.0d);
        int i13 = mota6.getFiabilidade();
        java.lang.String str14 = mota6.toString();
        boolean b16 = mota6.equals((java.lang.Object) "Matrícula: Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 100.0€\nFiabilidade: 10\nLugares: 1\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 10.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str14.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 10.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(b16 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        Mota mota4 = new Mota();
        mota4.setMatricula("");
        Mota mota7 = mota4.clone();
        mota4.setPrecoBase((double) 0L);
        Mota mota10 = new Mota();
        int i11 = mota10.getLugares();
        int i12 = mota4.compareTo((Veiculo) mota10);
        java.lang.String str13 = mota10.toString();
        int i14 = mota10.getFiabilidade();
        mota10.setPrecoBase(10.0d);
        int i17 = mota10.getFiabilidade();
        Mota mota18 = new Mota();
        mota18.setMatricula("");
        Mota mota21 = mota18.clone();
        mota18.setPrecoBase((double) 0L);
        Mota mota24 = new Mota();
        int i25 = mota24.getLugares();
        int i26 = mota18.compareTo((Veiculo) mota24);
        java.lang.String str27 = mota24.toString();
        int i28 = mota24.getFiabilidade();
        mota24.setPrecoBase(10.0d);
        Coordenada coordenada31 = mota24.getCoordenadas();
        mota10.setCoordenadas(coordenada31);
        Mota mota34 = new Mota((int) (short) -1, (double) 1L, (int) '4', "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 1\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada31, false);
        org.junit.Assert.assertNotNull(mota7);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(i12 == 3);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str13.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(i17 == 0);
        org.junit.Assert.assertNotNull(mota21);
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue(i26 == 3);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str27.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i28 == 0);
        org.junit.Assert.assertNotNull(coordenada31);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        Mota mota4 = new Mota(mota3);
        Mota mota5 = new Mota(mota4);
        Mota mota6 = new Mota();
        Mota mota7 = new Mota(mota6);
        int i8 = mota4.compareTo((Veiculo) mota6);
        Mota mota9 = new Mota();
        mota9.setMatricula("");
        boolean b13 = mota9.equals((java.lang.Object) (-1.0d));
        boolean b14 = mota4.equals((java.lang.Object) (-1.0d));
        Mota mota15 = new Mota();
        mota15.setMatricula("");
        Mota mota18 = mota15.clone();
        mota15.setPrecoBase((double) 0L);
        Mota mota21 = new Mota();
        int i22 = mota21.getLugares();
        int i23 = mota15.compareTo((Veiculo) mota21);
        java.lang.String str24 = mota21.toString();
        Coordenada coordenada25 = mota21.getCoordenadas();
        mota4.setCoordenadas(coordenada25);
        mota4.setPrecoBase((double) (short) 10);
        int i29 = mota4.getFiabilidade();
        int i30 = mota2.compareTo((Veiculo) mota4);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue(b13 == false);
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertNotNull(mota18);
        org.junit.Assert.assertTrue(i22 == 0);
        org.junit.Assert.assertTrue(i23 == 3);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str24.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada25);
        org.junit.Assert.assertTrue(i29 == 0);
        org.junit.Assert.assertTrue(i30 == 0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        java.lang.String str3 = mota0.toString();
        Mota mota4 = mota0.clone();
        Mota mota17 = new Mota();
        mota17.setMatricula("");
        Mota mota20 = mota17.clone();
        mota17.setPrecoBase((double) 0L);
        Mota mota23 = new Mota();
        int i24 = mota23.getLugares();
        int i25 = mota17.compareTo((Veiculo) mota23);
        java.lang.String str26 = mota23.toString();
        Coordenada coordenada27 = mota23.getCoordenadas();
        Mota mota29 = new Mota((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada27, false);
        Mota mota31 = new Mota((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada27, true);
        Mota mota33 = new Mota((int) '#', 10.0d, (-1), "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada27, true);
        Coordenada coordenada34 = mota33.getCoordenadas();
        mota4.setCoordenadas(coordenada34);
        double d36 = mota4.getPrecoBase();
        Mota mota37 = new Mota(mota4);
        Mota mota38 = new Mota(mota37);
        Coordenada coordenada39 = mota37.getCoordenadas();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(mota4);
        org.junit.Assert.assertNotNull(mota20);
        org.junit.Assert.assertTrue(i24 == 0);
        org.junit.Assert.assertTrue(i25 == 3);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str26.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada27);
        org.junit.Assert.assertNotNull(coordenada34);
        org.junit.Assert.assertTrue(d36 == 0.0d);
        org.junit.Assert.assertNotNull(coordenada39);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        Coordenada coordenada4 = mota3.getCoordenadas();
        Mota mota5 = new Mota();
        mota5.setMatricula("");
        Mota mota8 = mota5.clone();
        mota5.setPrecoBase((double) 0L);
        Mota mota11 = new Mota();
        int i12 = mota11.getLugares();
        int i13 = mota5.compareTo((Veiculo) mota11);
        java.lang.String str14 = mota11.toString();
        Coordenada coordenada15 = mota11.getCoordenadas();
        int i16 = mota3.compareTo((Veiculo) mota11);
        java.lang.String str17 = mota11.toString();
        int i18 = mota11.getLugares();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertNotNull(coordenada4);
        org.junit.Assert.assertNotNull(mota8);
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertTrue(i13 == 3);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str14.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada15);
        org.junit.Assert.assertTrue(i16 == 3);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str17.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i18 == 0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = mota0.getCoordenadas();
        mota0.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        mota0.setFiabilidade(0);
        int i10 = mota0.getFiabilidade();
        int i11 = mota0.getVelocidadeMedia();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i11 == 0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        Mota mota4 = new Mota(mota0);
        int i5 = mota0.getVelocidadeMedia();
        Mota mota6 = mota0.clone();
        Mota mota7 = mota0.clone();
        Coordenada coordenada8 = mota0.getCoordenadas();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i5 == 10);
        org.junit.Assert.assertNotNull(mota6);
        org.junit.Assert.assertNotNull(mota7);
        org.junit.Assert.assertNotNull(coordenada8);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        java.lang.String str2 = mota0.toString();
        int i3 = mota0.getLugares();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i3 == 0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        Coordenada coordenada4 = mota3.getCoordenadas();
        Mota mota5 = new Mota();
        mota5.setMatricula("");
        Mota mota8 = mota5.clone();
        mota5.setPrecoBase((double) 0L);
        Mota mota11 = new Mota();
        int i12 = mota11.getLugares();
        int i13 = mota5.compareTo((Veiculo) mota11);
        java.lang.String str14 = mota11.toString();
        Coordenada coordenada15 = mota11.getCoordenadas();
        int i16 = mota3.compareTo((Veiculo) mota11);
        java.lang.String str17 = mota3.getMatricula();
        mota3.setPrecoBase((double) 10);
        int i20 = mota3.getFiabilidade();
        double d21 = mota3.getPrecoBase();
        Mota mota22 = new Mota(mota3);
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertNotNull(coordenada4);
        org.junit.Assert.assertNotNull(mota8);
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertTrue(i13 == 3);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str14.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada15);
        org.junit.Assert.assertTrue(i16 == 3);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue(i20 == 0);
        org.junit.Assert.assertTrue(d21 == 10.0d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = mota0.getCoordenadas();
        mota0.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        mota0.setFiabilidade(0);
        Mota mota10 = new Mota();
        mota10.setMatricula("");
        Mota mota13 = mota10.clone();
        mota10.setPrecoBase((double) 0L);
        Mota mota16 = new Mota(mota10);
        int i17 = mota0.compareTo((Veiculo) mota10);
        Mota mota18 = new Mota(mota10);
        Coordenada coordenada19 = mota18.getCoordenadas();
        mota18.setVelocidadeMedia(27);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertNotNull(mota13);
        org.junit.Assert.assertTrue(i17 == (-142));
        org.junit.Assert.assertNotNull(coordenada19);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = mota0.getCoordenadas();
        mota0.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        mota0.setFiabilidade(0);
        Mota mota10 = new Mota();
        mota10.setMatricula("");
        Mota mota13 = mota10.clone();
        mota10.setPrecoBase((double) 0L);
        Mota mota16 = new Mota(mota10);
        int i17 = mota0.compareTo((Veiculo) mota10);
        Mota mota18 = new Mota();
        int i19 = mota18.getLugares();
        mota18.setVelocidadeMedia(10);
        Mota mota22 = new Mota(mota18);
        Mota mota23 = mota22.clone();
        boolean b24 = mota22.getOcupado();
        boolean b25 = mota10.equals((java.lang.Object) mota22);
        mota22.setFiabilidade((-33));
        mota22.setPrecoBase((double) (byte) 10);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertNotNull(mota13);
        org.junit.Assert.assertTrue(i17 == (-142));
        org.junit.Assert.assertTrue(i19 == 0);
        org.junit.Assert.assertNotNull(mota23);
        org.junit.Assert.assertTrue(b24 == false);
        org.junit.Assert.assertTrue(b25 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        int i4 = mota3.getVelocidadeMedia();
        Coordenada coordenada5 = mota3.getCoordenadas();
        Mota mota6 = mota3.clone();
        Coordenada coordenada7 = mota3.getCoordenadas();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertNotNull(mota6);
        org.junit.Assert.assertNotNull(coordenada7);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = mota0.getCoordenadas();
        mota0.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        mota0.setFiabilidade(0);
        Mota mota10 = new Mota();
        mota10.setMatricula("");
        Mota mota13 = mota10.clone();
        mota10.setPrecoBase((double) 0L);
        Mota mota16 = new Mota(mota10);
        int i17 = mota0.compareTo((Veiculo) mota10);
        Mota mota18 = new Mota();
        int i19 = mota18.getLugares();
        mota18.setVelocidadeMedia(10);
        Mota mota22 = new Mota(mota18);
        Mota mota23 = mota22.clone();
        boolean b24 = mota22.getOcupado();
        boolean b25 = mota10.equals((java.lang.Object) mota22);
        java.lang.String str26 = mota22.toString();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertNotNull(mota13);
        org.junit.Assert.assertTrue(i17 == (-142));
        org.junit.Assert.assertTrue(i19 == 0);
        org.junit.Assert.assertNotNull(mota23);
        org.junit.Assert.assertTrue(b24 == false);
        org.junit.Assert.assertTrue(b25 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str26.equals("Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        Mota mota4 = new Mota(mota0);
        int i5 = mota0.getVelocidadeMedia();
        mota0.setMatricula("");
        mota0.setPrecoBase((double) (byte) 1);
        Coordenada coordenada10 = mota0.getCoordenadas();
        int i11 = mota0.getFiabilidade();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i5 == 10);
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertTrue(i11 == 0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        Mota mota4 = new Mota();
        mota4.setMatricula("");
        boolean b8 = mota4.equals((java.lang.Object) (-1.0d));
        Mota mota9 = new Mota(mota4);
        double d10 = mota4.getPrecoBase();
        boolean b11 = mota4.getOcupado();
        int i12 = mota4.getVelocidadeMedia();
        java.lang.String str13 = mota4.getMatricula();
        mota4.setMatricula("hi!");
        mota4.setVelocidadeMedia((int) (byte) 1);
        Coordenada coordenada18 = mota4.getCoordenadas();
        Mota mota20 = new Mota(0, (double) 10, (int) (short) -1, "Matrícula: Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 35km/h\nPreço Base: 10.0€\nFiabilidade: -1\nLugares: 1\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n", coordenada18, true);
        org.junit.Assert.assertTrue(b8 == false);
        org.junit.Assert.assertTrue(d10 == 0.0d);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(coordenada18);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        java.lang.String str2 = mota0.toString();
        mota0.setFiabilidade(0);
        mota0.setOcupado(true);
        boolean b7 = mota0.getOcupado();
        mota0.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        mota0.setVelocidadeMedia((int) (byte) 0);
        mota0.setOcupado(true);
        Mota mota14 = mota0.clone();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(b7 == true);
        org.junit.Assert.assertNotNull(mota14);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota(mota0);
        Mota mota7 = mota0.clone();
        Mota mota8 = new Mota(mota7);
        Mota mota13 = new Mota();
        mota13.setMatricula("");
        Mota mota16 = mota13.clone();
        mota13.setPrecoBase((double) 0L);
        Mota mota19 = new Mota();
        int i20 = mota19.getLugares();
        int i21 = mota13.compareTo((Veiculo) mota19);
        java.lang.String str22 = mota19.toString();
        Coordenada coordenada23 = mota19.getCoordenadas();
        Mota mota25 = new Mota((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada23, false);
        mota25.setPrecoBase((double) 10.0f);
        mota25.setOcupado(false);
        boolean b30 = mota8.equals((java.lang.Object) mota25);
        boolean b31 = mota8.getOcupado();
        mota8.setFiabilidade(32);
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertNotNull(mota7);
        org.junit.Assert.assertNotNull(mota16);
        org.junit.Assert.assertTrue(i20 == 0);
        org.junit.Assert.assertTrue(i21 == 3);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str22.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada23);
        org.junit.Assert.assertTrue(b30 == false);
        org.junit.Assert.assertTrue(b31 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        Mota mota4 = new Mota(mota3);
        int i5 = mota1.compareTo((Veiculo) mota3);
        Mota mota10 = new Mota();
        mota10.setMatricula("");
        Mota mota13 = mota10.clone();
        mota10.setPrecoBase((double) 0L);
        Mota mota16 = new Mota();
        int i17 = mota16.getLugares();
        int i18 = mota10.compareTo((Veiculo) mota16);
        java.lang.String str19 = mota16.toString();
        Coordenada coordenada20 = mota16.getCoordenadas();
        Mota mota22 = new Mota((int) ' ', (double) 100.0f, (int) (byte) -1, "", coordenada20, false);
        int i23 = mota1.compareTo((Veiculo) mota22);
        Mota mota24 = new Mota(mota22);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertNotNull(mota13);
        org.junit.Assert.assertTrue(i17 == 0);
        org.junit.Assert.assertTrue(i18 == 3);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str19.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada20);
        org.junit.Assert.assertTrue(i23 == (-3));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        int i6 = mota0.getVelocidadeMedia();
        mota0.setVelocidadeMedia((int) (short) 100);
        int i9 = mota0.getVelocidadeMedia();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertTrue(i9 == 100);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        java.lang.String str2 = mota0.toString();
        mota0.setFiabilidade(0);
        mota0.setPrecoBase(1.0d);
        int i7 = mota0.getFiabilidade();
        Mota mota8 = mota0.clone();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertNotNull(mota8);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        Mota mota4 = new Mota(mota0);
        java.lang.String str5 = mota4.toString();
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        mota6.setVelocidadeMedia(10);
        Mota mota10 = new Mota(mota6);
        int i11 = mota6.getVelocidadeMedia();
        Mota mota12 = mota6.clone();
        int i13 = mota4.compareTo((Veiculo) mota6);
        int i14 = mota6.getLugares();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str5.equals("Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i11 == 10);
        org.junit.Assert.assertNotNull(mota12);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(i14 == 0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        mota0.setMatricula("n/a");
        Mota mota6 = new Mota();
        mota6.setMatricula("");
        Mota mota9 = mota6.clone();
        mota6.setPrecoBase((double) 0L);
        Mota mota12 = new Mota();
        int i13 = mota12.getLugares();
        int i14 = mota6.compareTo((Veiculo) mota12);
        java.lang.String str15 = mota12.toString();
        Coordenada coordenada16 = mota12.getCoordenadas();
        Mota mota17 = new Mota();
        int i18 = mota17.getLugares();
        Coordenada coordenada19 = mota17.getCoordenadas();
        mota12.setCoordenadas(coordenada19);
        mota0.setCoordenadas(coordenada19);
        mota0.setFiabilidade(1);
        mota0.setOcupado(false);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(mota9);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(i14 == 3);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str15.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada16);
        org.junit.Assert.assertTrue(i18 == 0);
        org.junit.Assert.assertNotNull(coordenada19);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota(mota0);
        mota6.setPrecoBase((double) (-1.0f));
        boolean b9 = mota6.getOcupado();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(b9 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        java.lang.String str9 = mota6.toString();
        Coordenada coordenada10 = mota6.getCoordenadas();
        Mota mota11 = new Mota();
        int i12 = mota11.getLugares();
        Coordenada coordenada13 = mota11.getCoordenadas();
        mota6.setCoordenadas(coordenada13);
        Mota mota15 = new Mota(mota6);
        java.lang.String str16 = mota15.toString();
        java.lang.Object obj17 = null;
        boolean b18 = mota15.equals(obj17);
        boolean b19 = mota15.getOcupado();
        int i20 = mota15.getFiabilidade();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertNotNull(coordenada13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str16.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(b18 == false);
        org.junit.Assert.assertTrue(b19 == false);
        org.junit.Assert.assertTrue(i20 == 0);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        Mota mota4 = new Mota(mota0);
        int i5 = mota0.getVelocidadeMedia();
        int i6 = mota0.getVelocidadeMedia();
        Coordenada coordenada7 = mota0.getCoordenadas();
        int i8 = mota0.getVelocidadeMedia();
        int i9 = mota0.getLugares();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i5 == 10);
        org.junit.Assert.assertTrue(i6 == 10);
        org.junit.Assert.assertNotNull(coordenada7);
        org.junit.Assert.assertTrue(i8 == 10);
        org.junit.Assert.assertTrue(i9 == 0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        Mota mota4 = new Mota(mota3);
        int i5 = mota1.compareTo((Veiculo) mota3);
        Mota mota6 = new Mota(mota3);
        int i7 = mota3.getFiabilidade();
        int i8 = mota3.getFiabilidade();
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        Mota mota2 = new Mota();
        int i3 = mota2.getLugares();
        Coordenada coordenada4 = mota2.getCoordenadas();
        int i5 = mota0.compareTo((Veiculo) mota2);
        Mota mota6 = mota0.clone();
        mota6.setPrecoBase((double) (byte) -1);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertNotNull(coordenada4);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertNotNull(mota6);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        Mota mota4 = new Mota(mota0);
        Mota mota5 = mota4.clone();
        boolean b6 = mota4.getOcupado();
        double d7 = mota4.getPrecoBase();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(mota5);
        org.junit.Assert.assertTrue(b6 == false);
        org.junit.Assert.assertTrue(d7 == 0.0d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        Mota mota8 = new Mota();
        mota8.setMatricula("");
        java.lang.String str11 = mota8.toString();
        Mota mota12 = mota8.clone();
        Mota mota25 = new Mota();
        mota25.setMatricula("");
        Mota mota28 = mota25.clone();
        mota25.setPrecoBase((double) 0L);
        Mota mota31 = new Mota();
        int i32 = mota31.getLugares();
        int i33 = mota25.compareTo((Veiculo) mota31);
        java.lang.String str34 = mota31.toString();
        Coordenada coordenada35 = mota31.getCoordenadas();
        Mota mota37 = new Mota((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada35, false);
        Mota mota39 = new Mota((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada35, true);
        Mota mota41 = new Mota((int) '#', 10.0d, (-1), "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada35, true);
        Coordenada coordenada42 = mota41.getCoordenadas();
        mota12.setCoordenadas(coordenada42);
        Coordenada coordenada44 = mota12.getCoordenadas();
        Mota mota46 = new Mota(0, (double) 0, (int) (short) 100, "Matrícula: Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 100km/h\nPreço Base: 10.0€\nFiabilidade: 10\nLugares: 1\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada44, true);
        Mota mota48 = new Mota((int) '4', (double) (short) 10, 33, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 35\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada44, true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str11.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(mota12);
        org.junit.Assert.assertNotNull(mota28);
        org.junit.Assert.assertTrue(i32 == 0);
        org.junit.Assert.assertTrue(i33 == 3);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str34.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada35);
        org.junit.Assert.assertNotNull(coordenada42);
        org.junit.Assert.assertNotNull(coordenada44);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        java.lang.String str3 = mota0.toString();
        Mota mota4 = new Mota();
        Mota mota5 = new Mota(mota4);
        java.lang.String str6 = mota4.toString();
        mota4.setFiabilidade(0);
        Mota mota9 = mota4.clone();
        Mota mota10 = new Mota();
        Mota mota11 = new Mota(mota10);
        Mota mota12 = new Mota(mota11);
        Mota mota13 = new Mota();
        Mota mota14 = new Mota(mota13);
        int i15 = mota11.compareTo((Veiculo) mota13);
        Mota mota16 = new Mota();
        mota16.setMatricula("");
        boolean b20 = mota16.equals((java.lang.Object) (-1.0d));
        boolean b21 = mota11.equals((java.lang.Object) (-1.0d));
        Mota mota22 = new Mota();
        mota22.setMatricula("");
        Mota mota25 = mota22.clone();
        mota22.setPrecoBase((double) 0L);
        Mota mota28 = new Mota();
        int i29 = mota28.getLugares();
        int i30 = mota22.compareTo((Veiculo) mota28);
        java.lang.String str31 = mota28.toString();
        Coordenada coordenada32 = mota28.getCoordenadas();
        mota11.setCoordenadas(coordenada32);
        mota4.setCoordenadas(coordenada32);
        mota4.setMatricula("hi!");
        int i37 = mota4.getFiabilidade();
        int i38 = mota0.compareTo((Veiculo) mota4);
        boolean b39 = mota4.getOcupado();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str6.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(mota9);
        org.junit.Assert.assertTrue(i15 == 0);
        org.junit.Assert.assertTrue(b20 == false);
        org.junit.Assert.assertTrue(b21 == false);
        org.junit.Assert.assertNotNull(mota25);
        org.junit.Assert.assertTrue(i29 == 0);
        org.junit.Assert.assertTrue(i30 == 3);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str31.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada32);
        org.junit.Assert.assertTrue(i37 == 0);
        org.junit.Assert.assertTrue(i38 == 3);
        org.junit.Assert.assertTrue(b39 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        Mota mota4 = new Mota();
        mota4.setMatricula("");
        Mota mota7 = mota4.clone();
        mota4.setPrecoBase((double) 0L);
        Mota mota10 = new Mota();
        int i11 = mota10.getLugares();
        int i12 = mota4.compareTo((Veiculo) mota10);
        java.lang.String str13 = mota10.toString();
        Coordenada coordenada14 = mota10.getCoordenadas();
        Mota mota16 = new Mota((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada14, false);
        mota16.setPrecoBase((double) 10.0f);
        mota16.setMatricula("hi!");
        Mota mota21 = new Mota(mota16);
        org.junit.Assert.assertNotNull(mota7);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(i12 == 3);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str13.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada14);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        double d9 = mota0.getPrecoBase();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue(d9 == 0.0d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        Mota mota4 = new Mota();
        mota4.setMatricula("");
        Mota mota7 = mota4.clone();
        mota4.setPrecoBase((double) 0L);
        Mota mota10 = new Mota();
        int i11 = mota10.getLugares();
        int i12 = mota4.compareTo((Veiculo) mota10);
        java.lang.String str13 = mota10.toString();
        Coordenada coordenada14 = mota10.getCoordenadas();
        Mota mota16 = new Mota((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada14, false);
        mota16.setPrecoBase((double) 10.0f);
        mota16.setOcupado(false);
        double d21 = mota16.getPrecoBase();
        org.junit.Assert.assertNotNull(mota7);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(i12 == 3);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str13.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada14);
        org.junit.Assert.assertTrue(d21 == 10.0d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        mota0.setMatricula("n/a");
        Mota mota11 = new Mota(mota0);
        mota11.setOcupado(true);
        mota11.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 100.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota(mota0);
        Mota mota7 = mota0.clone();
        Mota mota8 = mota7.clone();
        Coordenada coordenada9 = mota8.getCoordenadas();
        mota8.setVelocidadeMedia((-1));
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertNotNull(mota7);
        org.junit.Assert.assertNotNull(mota8);
        org.junit.Assert.assertNotNull(coordenada9);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        mota0.setOcupado(false);
        mota0.setMatricula("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        java.lang.String str7 = mota0.toString();
        int i8 = mota0.getVelocidadeMedia();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Matrícula: Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str7.equals("Matrícula: Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i8 == 0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        Mota mota4 = new Mota(mota3);
        int i5 = mota1.compareTo((Veiculo) mota3);
        int i6 = mota3.getVelocidadeMedia();
        Mota mota7 = mota3.clone();
        int i8 = mota7.getFiabilidade();
        int i9 = mota7.getFiabilidade();
        Mota mota10 = new Mota(mota7);
        mota10.setFiabilidade((int) (byte) -1);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertNotNull(mota7);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue(i9 == 0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota(mota0);
        Mota mota7 = mota0.clone();
        Mota mota8 = new Mota();
        int i9 = mota8.getLugares();
        mota8.setVelocidadeMedia(10);
        Mota mota12 = new Mota(mota8);
        Mota mota13 = new Mota(mota12);
        boolean b14 = mota0.equals((java.lang.Object) mota12);
        Mota mota15 = new Mota();
        mota15.setMatricula("");
        boolean b19 = mota15.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada20 = mota15.getCoordenadas();
        mota15.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        mota15.setFiabilidade(0);
        Mota mota25 = new Mota();
        mota25.setMatricula("");
        Mota mota28 = mota25.clone();
        mota25.setPrecoBase((double) 0L);
        Mota mota31 = new Mota(mota25);
        int i32 = mota15.compareTo((Veiculo) mota25);
        Mota mota33 = new Mota(mota25);
        int i34 = mota33.getVelocidadeMedia();
        boolean b35 = mota0.equals((java.lang.Object) mota33);
        int i36 = mota0.getFiabilidade();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertNotNull(mota7);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertTrue(b19 == false);
        org.junit.Assert.assertNotNull(coordenada20);
        org.junit.Assert.assertNotNull(mota28);
        org.junit.Assert.assertTrue(i32 == (-142));
        org.junit.Assert.assertTrue(i34 == 0);
        org.junit.Assert.assertTrue(b35 == true);
        org.junit.Assert.assertTrue(i36 == 0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota(mota0);
        Mota mota7 = mota0.clone();
        Mota mota8 = new Mota();
        int i9 = mota8.getLugares();
        mota8.setVelocidadeMedia(10);
        Mota mota12 = new Mota(mota8);
        Mota mota13 = new Mota(mota12);
        boolean b14 = mota0.equals((java.lang.Object) mota12);
        Mota mota15 = new Mota(mota12);
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertNotNull(mota7);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertTrue(b14 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        Mota mota8 = new Mota();
        mota8.setMatricula("");
        Mota mota11 = mota8.clone();
        mota8.setPrecoBase((double) 0L);
        Mota mota14 = new Mota();
        int i15 = mota14.getLugares();
        int i16 = mota8.compareTo((Veiculo) mota14);
        java.lang.String str17 = mota14.toString();
        Coordenada coordenada18 = mota14.getCoordenadas();
        Mota mota20 = new Mota((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, false);
        Mota mota22 = new Mota((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, true);
        java.lang.String str23 = mota22.getMatricula();
        org.junit.Assert.assertNotNull(mota11);
        org.junit.Assert.assertTrue(i15 == 0);
        org.junit.Assert.assertTrue(i16 == 3);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str17.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada18);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str23.equals("Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = mota0.clone();
        org.junit.Assert.assertNotNull(mota2);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        Mota mota8 = new Mota();
        Mota mota9 = new Mota();
        Mota mota10 = new Mota(mota9);
        int i11 = mota10.getFiabilidade();
        Coordenada coordenada12 = mota10.getCoordenadas();
        mota8.setCoordenadas(coordenada12);
        Mota mota15 = new Mota((int) (byte) 0, (double) (byte) 100, 0, "", coordenada12, false);
        Mota mota17 = new Mota((int) (byte) 100, 100.0d, (int) (byte) 1, "Matrícula: Matrícula: Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 10km/h\nPreço Base: -1.0€\nFiabilidade: 35\nLugares: 1\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n", coordenada12, true);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertNotNull(coordenada12);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota3.setOcupado(true);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        mota6.setVelocidadeMedia(10);
        int i10 = mota3.compareTo((Veiculo) mota6);
        Coordenada coordenada11 = mota3.getCoordenadas();
        mota3.setOcupado(true);
        mota3.setOcupado(true);
        mota3.setPrecoBase((double) (short) 10);
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i10 == 3);
        org.junit.Assert.assertNotNull(coordenada11);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        java.lang.String str3 = mota0.toString();
        int i4 = mota0.getFiabilidade();
        int i5 = mota0.getLugares();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue(i5 == 0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        int i9 = mota6.getFiabilidade();
        Mota mota10 = new Mota(mota6);
        double d11 = mota6.getPrecoBase();
        Coordenada coordenada12 = mota6.getCoordenadas();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertTrue(d11 == 0.0d);
        org.junit.Assert.assertNotNull(coordenada12);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        int i9 = mota6.getFiabilidade();
        Mota mota10 = mota6.clone();
        int i11 = mota6.getFiabilidade();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertNotNull(mota10);
        org.junit.Assert.assertTrue(i11 == 0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        java.lang.String str9 = mota6.toString();
        Coordenada coordenada10 = mota6.getCoordenadas();
        java.lang.String str11 = mota6.toString();
        mota6.setPrecoBase((double) 3);
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str11.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        int i9 = mota6.getVelocidadeMedia();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue(i9 == 0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        Mota mota4 = new Mota();
        mota4.setMatricula("");
        Mota mota7 = mota4.clone();
        mota4.setPrecoBase((double) 0L);
        Mota mota10 = new Mota();
        int i11 = mota10.getLugares();
        int i12 = mota4.compareTo((Veiculo) mota10);
        java.lang.String str13 = mota10.toString();
        Coordenada coordenada14 = mota10.getCoordenadas();
        Mota mota16 = new Mota((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada14, false);
        mota16.setPrecoBase((double) 10.0f);
        int i19 = mota16.getVelocidadeMedia();
        Coordenada coordenada20 = null;
        try {
            mota16.setCoordenadas(coordenada20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(mota7);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(i12 == 3);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str13.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada14);
        org.junit.Assert.assertTrue(i19 == 100);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        int i4 = mota3.getLugares();
        boolean b5 = mota2.equals((java.lang.Object) mota3);
        double d6 = mota2.getPrecoBase();
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue(b5 == true);
        org.junit.Assert.assertTrue(d6 == 0.0d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota(mota0);
        Mota mota7 = mota0.clone();
        Mota mota8 = mota7.clone();
        Mota mota9 = new Mota(mota7);
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertNotNull(mota7);
        org.junit.Assert.assertNotNull(mota8);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        Mota mota4 = new Mota(mota3);
        int i5 = mota1.compareTo((Veiculo) mota3);
        Mota mota6 = new Mota();
        mota6.setMatricula("");
        boolean b10 = mota6.equals((java.lang.Object) (-1.0d));
        boolean b11 = mota1.equals((java.lang.Object) (-1.0d));
        Mota mota12 = new Mota();
        mota12.setMatricula("");
        Mota mota15 = mota12.clone();
        mota12.setPrecoBase((double) 0L);
        Mota mota18 = new Mota();
        int i19 = mota18.getLugares();
        int i20 = mota12.compareTo((Veiculo) mota18);
        java.lang.String str21 = mota18.toString();
        Coordenada coordenada22 = mota18.getCoordenadas();
        mota1.setCoordenadas(coordenada22);
        mota1.setPrecoBase((double) (short) 10);
        int i26 = mota1.getFiabilidade();
        mota1.setPrecoBase((double) (byte) 100);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertNotNull(mota15);
        org.junit.Assert.assertTrue(i19 == 0);
        org.junit.Assert.assertTrue(i20 == 3);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str21.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada22);
        org.junit.Assert.assertTrue(i26 == 0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        Mota mota4 = new Mota();
        mota4.setMatricula("");
        boolean b8 = mota4.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada9 = mota4.getCoordenadas();
        Mota mota11 = new Mota((int) (byte) 0, (double) (short) 100, (int) (byte) 10, "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada9, false);
        mota11.setOcupado(true);
        Mota mota14 = new Mota();
        mota14.setMatricula("");
        boolean b18 = mota14.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada19 = mota14.getCoordenadas();
        mota14.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        mota14.setFiabilidade(0);
        Mota mota24 = new Mota();
        mota24.setMatricula("");
        Mota mota27 = mota24.clone();
        mota24.setPrecoBase((double) 0L);
        Mota mota30 = new Mota(mota24);
        int i31 = mota14.compareTo((Veiculo) mota24);
        Mota mota32 = new Mota();
        int i33 = mota32.getLugares();
        mota32.setVelocidadeMedia(10);
        Mota mota36 = new Mota(mota32);
        Mota mota37 = mota36.clone();
        boolean b38 = mota36.getOcupado();
        boolean b39 = mota24.equals((java.lang.Object) mota36);
        int i40 = mota11.compareTo((Veiculo) mota36);
        Coordenada coordenada41 = mota36.getCoordenadas();
        org.junit.Assert.assertTrue(b8 == false);
        org.junit.Assert.assertNotNull(coordenada9);
        org.junit.Assert.assertTrue(b18 == false);
        org.junit.Assert.assertNotNull(coordenada19);
        org.junit.Assert.assertNotNull(mota27);
        org.junit.Assert.assertTrue(i31 == (-142));
        org.junit.Assert.assertTrue(i33 == 0);
        org.junit.Assert.assertNotNull(mota37);
        org.junit.Assert.assertTrue(b38 == false);
        org.junit.Assert.assertTrue(b39 == false);
        org.junit.Assert.assertTrue(i40 == 33);
        org.junit.Assert.assertNotNull(coordenada41);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        Mota mota4 = new Mota();
        mota4.setMatricula("");
        Mota mota7 = mota4.clone();
        mota4.setPrecoBase((double) 0L);
        Mota mota10 = new Mota();
        int i11 = mota10.getLugares();
        int i12 = mota4.compareTo((Veiculo) mota10);
        java.lang.String str13 = mota10.toString();
        Coordenada coordenada14 = mota10.getCoordenadas();
        Mota mota16 = new Mota((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada14, false);
        boolean b17 = mota16.getOcupado();
        double d18 = mota16.getPrecoBase();
        org.junit.Assert.assertNotNull(mota7);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(i12 == 3);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str13.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada14);
        org.junit.Assert.assertTrue(b17 == false);
        org.junit.Assert.assertTrue(d18 == 1.0d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        Mota mota4 = new Mota(mota3);
        int i5 = mota1.compareTo((Veiculo) mota3);
        int i6 = mota3.getVelocidadeMedia();
        Mota mota7 = mota3.clone();
        int i8 = mota7.getFiabilidade();
        int i9 = mota7.getFiabilidade();
        Mota mota10 = new Mota(mota7);
        mota10.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 10.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertNotNull(mota7);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue(i9 == 0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        Mota mota4 = new Mota();
        mota4.setMatricula("");
        Mota mota7 = mota4.clone();
        mota4.setPrecoBase((double) 0L);
        Mota mota10 = new Mota();
        int i11 = mota10.getLugares();
        int i12 = mota4.compareTo((Veiculo) mota10);
        java.lang.String str13 = mota10.toString();
        Coordenada coordenada14 = mota10.getCoordenadas();
        Mota mota16 = new Mota((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada14, false);
        mota16.setPrecoBase((double) 10.0f);
        mota16.setMatricula("hi!");
        Mota mota21 = new Mota();
        int i22 = mota21.getLugares();
        mota21.setVelocidadeMedia(10);
        Coordenada coordenada25 = mota21.getCoordenadas();
        boolean b26 = mota16.equals((java.lang.Object) mota21);
        mota21.setOcupado(false);
        org.junit.Assert.assertNotNull(mota7);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(i12 == 3);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str13.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada14);
        org.junit.Assert.assertTrue(i22 == 0);
        org.junit.Assert.assertNotNull(coordenada25);
        org.junit.Assert.assertTrue(b26 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setVelocidadeMedia((int) '4');
        Mota mota6 = new Mota(mota0);
        org.junit.Assert.assertNotNull(mota3);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        java.lang.String str9 = mota6.toString();
        int i10 = mota6.getFiabilidade();
        mota6.setPrecoBase(10.0d);
        int i13 = mota6.getVelocidadeMedia();
        Mota mota14 = new Mota(mota6);
        mota6.setVelocidadeMedia(1);
        int i17 = mota6.getLugares();
        int i18 = mota6.getLugares();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(i17 == 0);
        org.junit.Assert.assertTrue(i18 == 0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        int i4 = mota3.getLugares();
        boolean b5 = mota2.equals((java.lang.Object) mota3);
        mota3.setOcupado(true);
        Coordenada coordenada8 = mota3.getCoordenadas();
        mota3.setPrecoBase((double) (-1.0f));
        boolean b11 = mota3.getOcupado();
        Mota mota16 = new Mota();
        mota16.setMatricula("");
        Mota mota19 = mota16.clone();
        Coordenada coordenada20 = mota19.getCoordenadas();
        Mota mota22 = new Mota((int) (byte) 0, (double) 'a', 3, "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada20, false);
        mota3.setCoordenadas(coordenada20);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue(b5 == true);
        org.junit.Assert.assertNotNull(coordenada8);
        org.junit.Assert.assertTrue(b11 == true);
        org.junit.Assert.assertNotNull(mota19);
        org.junit.Assert.assertNotNull(coordenada20);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        Mota mota4 = mota0.clone();
        mota0.setMatricula("Matrícula: Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        int i7 = mota0.getLugares();
        mota0.setPrecoBase((double) 1L);
        java.lang.String str10 = mota0.getMatricula();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(mota4);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Matrícula: Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str10.equals("Matrícula: Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        Mota mota4 = new Mota();
        mota4.setMatricula("");
        Mota mota7 = mota4.clone();
        Coordenada coordenada8 = mota7.getCoordenadas();
        Mota mota10 = new Mota((int) (byte) -1, (double) 0, (int) (short) 1, "", coordenada8, false);
        mota10.setOcupado(false);
        org.junit.Assert.assertNotNull(mota7);
        org.junit.Assert.assertNotNull(coordenada8);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        Mota mota12 = new Mota();
        mota12.setMatricula("");
        boolean b16 = mota12.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada17 = mota12.getCoordenadas();
        mota12.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        mota12.setFiabilidade(0);
        Mota mota22 = new Mota();
        mota22.setMatricula("");
        Mota mota25 = mota22.clone();
        mota22.setPrecoBase((double) 0L);
        Mota mota28 = new Mota(mota22);
        int i29 = mota12.compareTo((Veiculo) mota22);
        Mota mota30 = new Mota(mota22);
        Coordenada coordenada31 = mota30.getCoordenadas();
        Mota mota33 = new Mota((int) (byte) 0, (double) 0L, (int) (byte) 0, "n/a", coordenada31, true);
        Mota mota35 = new Mota((int) (byte) 0, (double) (short) 100, (int) (short) 10, "Matrícula: Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada31, true);
        Mota mota37 = new Mota(100, (double) (short) 1, (-33), "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: -3.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada31, false);
        boolean b38 = mota37.getOcupado();
        org.junit.Assert.assertTrue(b16 == false);
        org.junit.Assert.assertNotNull(coordenada17);
        org.junit.Assert.assertNotNull(mota25);
        org.junit.Assert.assertTrue(i29 == (-142));
        org.junit.Assert.assertNotNull(coordenada31);
        org.junit.Assert.assertTrue(b38 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        java.lang.String str2 = mota0.toString();
        mota0.setFiabilidade(0);
        int i5 = mota0.getFiabilidade();
        Mota mota6 = new Mota(mota0);
        Mota mota7 = mota0.clone();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertNotNull(mota7);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        int i4 = mota3.getLugares();
        boolean b5 = mota2.equals((java.lang.Object) mota3);
        mota3.setOcupado(true);
        Coordenada coordenada8 = mota3.getCoordenadas();
        mota3.setPrecoBase((double) (-1.0f));
        boolean b11 = mota3.getOcupado();
        int i12 = mota3.getVelocidadeMedia();
        int i13 = mota3.getVelocidadeMedia();
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue(b5 == true);
        org.junit.Assert.assertNotNull(coordenada8);
        org.junit.Assert.assertTrue(b11 == true);
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertTrue(i13 == 0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota(mota0);
        Mota mota7 = mota0.clone();
        Mota mota8 = mota7.clone();
        int i9 = mota7.getFiabilidade();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertNotNull(mota7);
        org.junit.Assert.assertNotNull(mota8);
        org.junit.Assert.assertTrue(i9 == 0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        int i9 = mota6.getFiabilidade();
        Mota mota10 = mota6.clone();
        int i11 = mota10.getFiabilidade();
        java.lang.String str12 = mota10.toString();
        int i13 = mota10.getLugares();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertNotNull(mota10);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str12.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i13 == 0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        Mota mota0 = new Mota();
        int i1 = mota0.getFiabilidade();
        int i2 = mota0.getFiabilidade();
        java.lang.String str3 = mota0.getMatricula();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i2 == 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "n/a" + "'", str3.equals("n/a"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        java.lang.String str9 = mota6.toString();
        int i10 = mota6.getVelocidadeMedia();
        Mota mota11 = mota6.clone();
        java.lang.String str12 = mota11.toString();
        java.lang.String str13 = mota11.getMatricula();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertNotNull(mota11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str12.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "n/a" + "'", str13.equals("n/a"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = new Mota();
        java.lang.String str4 = mota3.toString();
        boolean b5 = mota3.getOcupado();
        int i6 = mota0.compareTo((Veiculo) mota3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str4.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(b5 == false);
        org.junit.Assert.assertTrue(i6 == 3);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        Mota mota4 = new Mota(mota3);
        int i5 = mota1.compareTo((Veiculo) mota3);
        double d6 = mota3.getPrecoBase();
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(d6 == 0.0d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        Mota mota4 = new Mota(mota3);
        int i5 = mota1.compareTo((Veiculo) mota3);
        mota3.setMatricula("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        int i8 = mota3.getFiabilidade();
        Mota mota9 = mota3.clone();
        Coordenada coordenada10 = mota9.getCoordenadas();
        Mota mota11 = mota9.clone();
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertNotNull(mota9);
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertNotNull(mota11);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        Mota mota9 = new Mota(mota6);
        Mota mota10 = new Mota();
        Mota mota11 = new Mota(mota10);
        Mota mota12 = new Mota(mota11);
        Mota mota13 = new Mota();
        Mota mota14 = new Mota(mota13);
        int i15 = mota11.compareTo((Veiculo) mota13);
        int i16 = mota13.getVelocidadeMedia();
        int i17 = mota9.compareTo((Veiculo) mota13);
        int i18 = mota9.getFiabilidade();
        mota9.setPrecoBase(0.0d);
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue(i15 == 0);
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue(i17 == 0);
        org.junit.Assert.assertTrue(i18 == 0);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        int i3 = mota0.getVelocidadeMedia();
        Mota mota4 = new Mota(mota0);
        int i5 = mota4.getFiabilidade();
        mota4.setOcupado(false);
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i5 == 0);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Coordenada coordenada6 = mota0.getCoordenadas();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertNotNull(coordenada6);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = mota0.getCoordenadas();
        mota0.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        mota0.setFiabilidade(0);
        Mota mota10 = new Mota();
        mota10.setMatricula("");
        Mota mota13 = mota10.clone();
        mota10.setPrecoBase((double) 0L);
        Mota mota16 = new Mota(mota10);
        int i17 = mota0.compareTo((Veiculo) mota10);
        Mota mota18 = new Mota();
        int i19 = mota18.getLugares();
        mota18.setVelocidadeMedia(10);
        Mota mota22 = new Mota(mota18);
        Mota mota23 = mota22.clone();
        boolean b24 = mota22.getOcupado();
        boolean b25 = mota10.equals((java.lang.Object) mota22);
        mota22.setFiabilidade((-33));
        mota22.setMatricula("Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertNotNull(mota13);
        org.junit.Assert.assertTrue(i17 == (-142));
        org.junit.Assert.assertTrue(i19 == 0);
        org.junit.Assert.assertNotNull(mota23);
        org.junit.Assert.assertTrue(b24 == false);
        org.junit.Assert.assertTrue(b25 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota(mota0);
        Mota mota7 = mota0.clone();
        mota0.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 10.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertNotNull(mota7);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        java.lang.String str2 = mota0.getMatricula();
        mota0.setMatricula("");
        mota0.setVelocidadeMedia((int) ' ');
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "n/a" + "'", str2.equals("n/a"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota(mota0);
        Mota mota7 = mota0.clone();
        Mota mota8 = new Mota();
        int i9 = mota8.getLugares();
        mota8.setVelocidadeMedia(10);
        Mota mota12 = new Mota(mota8);
        Mota mota13 = new Mota(mota12);
        boolean b14 = mota0.equals((java.lang.Object) mota12);
        Mota mota15 = new Mota();
        mota15.setMatricula("");
        Mota mota18 = mota15.clone();
        mota15.setPrecoBase((double) 0L);
        Mota mota21 = new Mota();
        int i22 = mota21.getLugares();
        int i23 = mota15.compareTo((Veiculo) mota21);
        java.lang.String str24 = mota21.toString();
        int i25 = mota21.getFiabilidade();
        mota21.setPrecoBase(10.0d);
        int i28 = mota21.getFiabilidade();
        boolean b29 = mota12.equals((java.lang.Object) mota21);
        Mota mota30 = mota21.clone();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertNotNull(mota7);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertNotNull(mota18);
        org.junit.Assert.assertTrue(i22 == 0);
        org.junit.Assert.assertTrue(i23 == 3);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str24.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue(i28 == 0);
        org.junit.Assert.assertTrue(b29 == false);
        org.junit.Assert.assertNotNull(mota30);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota();
        Mota mota2 = new Mota(mota1);
        int i3 = mota2.getFiabilidade();
        Coordenada coordenada4 = mota2.getCoordenadas();
        mota0.setCoordenadas(coordenada4);
        int i6 = mota0.getVelocidadeMedia();
        mota0.setOcupado(false);
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertNotNull(coordenada4);
        org.junit.Assert.assertTrue(i6 == 0);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        Mota mota9 = new Mota(mota6);
        int i10 = mota9.getLugares();
        java.lang.String str11 = mota9.toString();
        boolean b12 = mota9.getOcupado();
        mota9.setVelocidadeMedia((int) (short) -1);
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str11.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(b12 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        int i6 = mota0.getVelocidadeMedia();
        Mota mota7 = new Mota();
        mota7.setMatricula("");
        java.lang.String str10 = mota7.toString();
        Mota mota11 = mota7.clone();
        Mota mota24 = new Mota();
        mota24.setMatricula("");
        Mota mota27 = mota24.clone();
        mota24.setPrecoBase((double) 0L);
        Mota mota30 = new Mota();
        int i31 = mota30.getLugares();
        int i32 = mota24.compareTo((Veiculo) mota30);
        java.lang.String str33 = mota30.toString();
        Coordenada coordenada34 = mota30.getCoordenadas();
        Mota mota36 = new Mota((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada34, false);
        Mota mota38 = new Mota((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada34, true);
        Mota mota40 = new Mota((int) '#', 10.0d, (-1), "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada34, true);
        Coordenada coordenada41 = mota40.getCoordenadas();
        mota11.setCoordenadas(coordenada41);
        mota0.setCoordenadas(coordenada41);
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str10.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(mota11);
        org.junit.Assert.assertNotNull(mota27);
        org.junit.Assert.assertTrue(i31 == 0);
        org.junit.Assert.assertTrue(i32 == 3);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str33.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada34);
        org.junit.Assert.assertNotNull(coordenada41);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        java.lang.String str2 = mota0.toString();
        mota0.setFiabilidade(0);
        java.lang.String str5 = mota0.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str5.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        Mota mota4 = new Mota(mota0);
        Mota mota5 = new Mota(mota4);
        double d6 = mota5.getPrecoBase();
        java.lang.String str7 = mota5.getMatricula();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "n/a" + "'", str7.equals("n/a"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        int i3 = mota2.getLugares();
        mota2.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 1\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        org.junit.Assert.assertTrue(i3 == 0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = mota0.getCoordenadas();
        mota0.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        mota0.setFiabilidade(0);
        mota0.setVelocidadeMedia((-1));
        Mota mota12 = mota0.clone();
        Mota mota13 = new Mota(mota12);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertNotNull(mota12);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        java.lang.String str3 = mota0.toString();
        Mota mota4 = mota0.clone();
        Mota mota17 = new Mota();
        mota17.setMatricula("");
        Mota mota20 = mota17.clone();
        mota17.setPrecoBase((double) 0L);
        Mota mota23 = new Mota();
        int i24 = mota23.getLugares();
        int i25 = mota17.compareTo((Veiculo) mota23);
        java.lang.String str26 = mota23.toString();
        Coordenada coordenada27 = mota23.getCoordenadas();
        Mota mota29 = new Mota((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada27, false);
        Mota mota31 = new Mota((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada27, true);
        Mota mota33 = new Mota((int) '#', 10.0d, (-1), "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada27, true);
        Coordenada coordenada34 = mota33.getCoordenadas();
        mota4.setCoordenadas(coordenada34);
        double d36 = mota4.getPrecoBase();
        Mota mota37 = new Mota(mota4);
        Mota mota38 = new Mota(mota37);
        int i39 = mota38.getVelocidadeMedia();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(mota4);
        org.junit.Assert.assertNotNull(mota20);
        org.junit.Assert.assertTrue(i24 == 0);
        org.junit.Assert.assertTrue(i25 == 3);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str26.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada27);
        org.junit.Assert.assertNotNull(coordenada34);
        org.junit.Assert.assertTrue(d36 == 0.0d);
        org.junit.Assert.assertTrue(i39 == 0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        Mota mota4 = new Mota(mota0);
        Mota mota5 = new Mota(mota4);
        int i6 = mota5.getFiabilidade();
        Mota mota7 = mota5.clone();
        Coordenada coordenada8 = mota7.getCoordenadas();
        mota7.setVelocidadeMedia((int) (byte) -1);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertNotNull(mota7);
        org.junit.Assert.assertNotNull(coordenada8);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        int i4 = mota3.getFiabilidade();
        mota3.setOcupado(false);
        mota3.setPrecoBase(0.0d);
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i4 == 0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        mota1.setPrecoBase((double) (byte) 10);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        mota0.setFiabilidade((int) (byte) 0);
        Mota mota6 = new Mota(mota0);
        int i7 = mota6.getLugares();
        mota6.setFiabilidade(0);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i7 == 0);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        Mota mota4 = new Mota(mota0);
        Mota mota5 = new Mota(mota4);
        java.lang.String str6 = mota4.getMatricula();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "n/a" + "'", str6.equals("n/a"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota(mota0);
        mota6.setPrecoBase((double) (-1.0f));
        mota6.setVelocidadeMedia((int) (short) 0);
        mota6.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Mota mota13 = new Mota(mota6);
        Mota mota14 = mota6.clone();
        mota6.setFiabilidade((int) (byte) -1);
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertNotNull(mota14);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        Mota mota4 = new Mota(mota3);
        int i5 = mota1.compareTo((Veiculo) mota3);
        Mota mota6 = new Mota();
        mota6.setMatricula("");
        boolean b10 = mota6.equals((java.lang.Object) (-1.0d));
        boolean b11 = mota1.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada12 = mota1.getCoordenadas();
        mota1.setOcupado(false);
        mota1.setVelocidadeMedia((int) 'a');
        double d17 = mota1.getPrecoBase();
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertNotNull(coordenada12);
        org.junit.Assert.assertTrue(d17 == 0.0d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        boolean b6 = mota0.getOcupado();
        int i7 = mota0.getLugares();
        int i8 = mota0.getFiabilidade();
        int i9 = mota0.getLugares();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(b6 == false);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue(i9 == 0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = mota0.getCoordenadas();
        mota0.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        mota0.setFiabilidade(0);
        mota0.setVelocidadeMedia((-1));
        Mota mota12 = mota0.clone();
        java.lang.String str13 = mota0.toString();
        mota0.setFiabilidade((-3));
        Mota mota16 = mota0.clone();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertNotNull(mota12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Matrícula: Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: -1km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str13.equals("Matrícula: Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: -1km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(mota16);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        java.lang.String str4 = mota0.toString();
        int i5 = mota0.getFiabilidade();
        double d6 = mota0.getPrecoBase();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str4.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(d6 == 0.0d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        int i4 = mota3.getVelocidadeMedia();
        Coordenada coordenada5 = mota3.getCoordenadas();
        Mota mota6 = new Mota();
        mota6.setMatricula("");
        Mota mota9 = mota6.clone();
        mota6.setPrecoBase((double) 0L);
        Mota mota12 = new Mota();
        int i13 = mota12.getLugares();
        int i14 = mota6.compareTo((Veiculo) mota12);
        java.lang.String str15 = mota12.toString();
        java.lang.String str16 = mota12.toString();
        boolean b17 = mota3.equals((java.lang.Object) str16);
        mota3.setFiabilidade((int) (byte) 0);
        int i20 = mota3.getLugares();
        Mota mota21 = mota3.clone();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertNotNull(mota9);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(i14 == 3);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str15.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str16.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(b17 == false);
        org.junit.Assert.assertTrue(i20 == 0);
        org.junit.Assert.assertNotNull(mota21);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota(mota0);
        Mota mota7 = mota0.clone();
        Mota mota8 = new Mota(mota7);
        java.lang.String str9 = mota8.getMatricula();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertNotNull(mota7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        int i4 = mota3.getFiabilidade();
        java.lang.String str5 = mota3.toString();
        mota3.setPrecoBase(0.0d);
        double d8 = mota3.getPrecoBase();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str5.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(d8 == 0.0d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        Mota mota4 = new Mota();
        mota4.setMatricula("");
        Mota mota7 = mota4.clone();
        mota4.setPrecoBase((double) 0L);
        Mota mota10 = new Mota();
        int i11 = mota10.getLugares();
        int i12 = mota4.compareTo((Veiculo) mota10);
        java.lang.String str13 = mota10.toString();
        Coordenada coordenada14 = mota10.getCoordenadas();
        Mota mota16 = new Mota(0, (double) 0L, 0, "hi!", coordenada14, true);
        mota16.setPrecoBase((double) '#');
        Mota mota19 = new Mota();
        mota19.setMatricula("");
        boolean b23 = mota19.equals((java.lang.Object) (-1.0d));
        Mota mota24 = new Mota(mota19);
        Coordenada coordenada25 = mota24.getCoordenadas();
        mota16.setCoordenadas(coordenada25);
        Mota mota27 = new Mota(mota16);
        double d28 = mota27.getPrecoBase();
        org.junit.Assert.assertNotNull(mota7);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(i12 == 3);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str13.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada14);
        org.junit.Assert.assertTrue(b23 == false);
        org.junit.Assert.assertNotNull(coordenada25);
        org.junit.Assert.assertTrue(d28 == 35.0d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        mota3.setMatricula("");
        Mota mota6 = mota3.clone();
        mota3.setPrecoBase((double) 0L);
        Mota mota9 = new Mota();
        int i10 = mota9.getLugares();
        int i11 = mota3.compareTo((Veiculo) mota9);
        java.lang.String str12 = mota9.toString();
        Coordenada coordenada13 = mota9.getCoordenadas();
        mota2.setCoordenadas(coordenada13);
        org.junit.Assert.assertNotNull(mota6);
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i11 == 3);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str12.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada13);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        java.lang.String str9 = mota6.toString();
        int i10 = mota6.getFiabilidade();
        mota6.setPrecoBase(10.0d);
        int i13 = mota6.getVelocidadeMedia();
        Mota mota14 = new Mota(mota6);
        mota6.setVelocidadeMedia(1);
        int i17 = mota6.getLugares();
        double d18 = mota6.getPrecoBase();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(i17 == 0);
        org.junit.Assert.assertTrue(d18 == 10.0d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        mota0.setMatricula("n/a");
        Mota mota6 = new Mota();
        mota6.setMatricula("");
        Mota mota9 = mota6.clone();
        mota6.setPrecoBase((double) 0L);
        Mota mota12 = new Mota();
        int i13 = mota12.getLugares();
        int i14 = mota6.compareTo((Veiculo) mota12);
        java.lang.String str15 = mota12.toString();
        Coordenada coordenada16 = mota12.getCoordenadas();
        Mota mota17 = new Mota();
        int i18 = mota17.getLugares();
        Coordenada coordenada19 = mota17.getCoordenadas();
        mota12.setCoordenadas(coordenada19);
        mota0.setCoordenadas(coordenada19);
        mota0.setFiabilidade(1);
        mota0.setOcupado(true);
        int i26 = mota0.getVelocidadeMedia();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(mota9);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(i14 == 3);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str15.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada16);
        org.junit.Assert.assertTrue(i18 == 0);
        org.junit.Assert.assertNotNull(coordenada19);
        org.junit.Assert.assertTrue(i26 == 10);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        Mota mota9 = new Mota(mota6);
        int i10 = mota9.getLugares();
        java.lang.String str11 = mota9.toString();
        boolean b12 = mota9.getOcupado();
        mota9.setPrecoBase(0.0d);
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str11.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(b12 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        Mota mota4 = new Mota(mota3);
        int i5 = mota1.compareTo((Veiculo) mota3);
        int i6 = mota3.getVelocidadeMedia();
        Mota mota7 = mota3.clone();
        int i8 = mota7.getFiabilidade();
        int i9 = mota7.getFiabilidade();
        Mota mota10 = new Mota(mota7);
        boolean b12 = mota10.equals((java.lang.Object) (-1L));
        mota10.setVelocidadeMedia(1);
        Mota mota15 = new Mota();
        Mota mota16 = new Mota(mota15);
        java.lang.String str17 = mota15.toString();
        mota15.setFiabilidade(0);
        Mota mota20 = mota15.clone();
        int i21 = mota15.getLugares();
        Mota mota26 = new Mota();
        Mota mota27 = new Mota(mota26);
        Mota mota28 = new Mota(mota27);
        Mota mota29 = new Mota();
        Mota mota30 = new Mota(mota29);
        int i31 = mota27.compareTo((Veiculo) mota29);
        Mota mota32 = new Mota();
        mota32.setMatricula("");
        boolean b36 = mota32.equals((java.lang.Object) (-1.0d));
        boolean b37 = mota27.equals((java.lang.Object) (-1.0d));
        Mota mota38 = new Mota();
        mota38.setMatricula("");
        Mota mota41 = mota38.clone();
        mota38.setPrecoBase((double) 0L);
        Mota mota44 = new Mota();
        int i45 = mota44.getLugares();
        int i46 = mota38.compareTo((Veiculo) mota44);
        java.lang.String str47 = mota44.toString();
        Coordenada coordenada48 = mota44.getCoordenadas();
        mota27.setCoordenadas(coordenada48);
        Mota mota51 = new Mota((-1), 10.0d, (int) (byte) 1, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada48, true);
        mota15.setCoordenadas(coordenada48);
        mota10.setCoordenadas(coordenada48);
        Mota mota54 = new Mota(mota10);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertNotNull(mota7);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str17.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(mota20);
        org.junit.Assert.assertTrue(i21 == 0);
        org.junit.Assert.assertTrue(i31 == 0);
        org.junit.Assert.assertTrue(b36 == false);
        org.junit.Assert.assertTrue(b37 == false);
        org.junit.Assert.assertNotNull(mota41);
        org.junit.Assert.assertTrue(i45 == 0);
        org.junit.Assert.assertTrue(i46 == 3);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str47.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada48);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        Mota mota4 = new Mota(mota3);
        int i5 = mota1.compareTo((Veiculo) mota3);
        Mota mota6 = new Mota();
        mota6.setMatricula("");
        boolean b10 = mota6.equals((java.lang.Object) (-1.0d));
        boolean b11 = mota1.equals((java.lang.Object) (-1.0d));
        Mota mota12 = new Mota(mota1);
        int i13 = mota12.getVelocidadeMedia();
        Mota mota18 = new Mota();
        mota18.setMatricula("");
        Mota mota21 = mota18.clone();
        int i22 = mota21.getVelocidadeMedia();
        Coordenada coordenada23 = mota21.getCoordenadas();
        Mota mota25 = new Mota((int) (short) 10, 1.0d, (int) ' ', "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada23, false);
        mota12.setCoordenadas(coordenada23);
        mota12.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        java.lang.String str29 = mota12.toString();
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertNotNull(mota21);
        org.junit.Assert.assertTrue(i22 == 0);
        org.junit.Assert.assertNotNull(coordenada23);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Matrícula: Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str29.equals("Matrícula: Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        Mota mota4 = new Mota(mota0);
        mota4.setOcupado(false);
        int i7 = mota4.getLugares();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i7 == 0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        int i4 = mota3.getVelocidadeMedia();
        Coordenada coordenada5 = mota3.getCoordenadas();
        Mota mota6 = mota3.clone();
        Mota mota7 = new Mota(mota3);
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertNotNull(mota6);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        mota0.setMatricula("n/a");
        mota0.setPrecoBase((double) 1L);
        Coordenada coordenada8 = mota0.getCoordenadas();
        mota0.setFiabilidade((int) ' ');
        boolean b11 = mota0.getOcupado();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(coordenada8);
        org.junit.Assert.assertTrue(b11 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        Mota mota0 = new Mota();
        java.lang.String str1 = mota0.toString();
        double d2 = mota0.getPrecoBase();
        java.lang.String str3 = mota0.getMatricula();
        boolean b4 = mota0.getOcupado();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str1.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(d2 == 0.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "n/a" + "'", str3.equals("n/a"));
        org.junit.Assert.assertTrue(b4 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        java.lang.String str9 = mota6.toString();
        int i10 = mota6.getFiabilidade();
        mota6.setPrecoBase(10.0d);
        int i13 = mota6.getVelocidadeMedia();
        int i14 = mota6.getFiabilidade();
        java.lang.String str15 = mota6.getMatricula();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "n/a" + "'", str15.equals("n/a"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = mota0.getCoordenadas();
        mota0.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        mota0.setFiabilidade(0);
        Mota mota10 = new Mota();
        mota10.setMatricula("");
        Mota mota13 = mota10.clone();
        mota10.setPrecoBase((double) 0L);
        Mota mota16 = new Mota(mota10);
        int i17 = mota0.compareTo((Veiculo) mota10);
        Mota mota18 = new Mota(mota10);
        Mota mota19 = mota10.clone();
        mota10.setPrecoBase((double) ' ');
        double d22 = mota10.getPrecoBase();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertNotNull(mota13);
        org.junit.Assert.assertTrue(i17 == (-142));
        org.junit.Assert.assertNotNull(mota19);
        org.junit.Assert.assertTrue(d22 == 32.0d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        Mota mota8 = new Mota();
        mota8.setMatricula("");
        Mota mota11 = mota8.clone();
        mota8.setPrecoBase((double) 0L);
        Mota mota14 = new Mota();
        int i15 = mota14.getLugares();
        int i16 = mota8.compareTo((Veiculo) mota14);
        java.lang.String str17 = mota14.toString();
        Coordenada coordenada18 = mota14.getCoordenadas();
        Mota mota20 = new Mota((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, false);
        Mota mota22 = new Mota(1, 100.0d, 0, "hi!", coordenada18, true);
        Mota mota23 = new Mota();
        Mota mota24 = new Mota(mota23);
        Mota mota25 = new Mota(mota24);
        Mota mota26 = new Mota();
        Mota mota27 = new Mota(mota26);
        int i28 = mota24.compareTo((Veiculo) mota26);
        int i29 = mota26.getVelocidadeMedia();
        Mota mota30 = mota26.clone();
        int i31 = mota30.getFiabilidade();
        int i32 = mota30.getFiabilidade();
        Mota mota33 = new Mota(mota30);
        int i34 = mota33.getLugares();
        boolean b35 = mota22.equals((java.lang.Object) mota33);
        org.junit.Assert.assertNotNull(mota11);
        org.junit.Assert.assertTrue(i15 == 0);
        org.junit.Assert.assertTrue(i16 == 3);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str17.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada18);
        org.junit.Assert.assertTrue(i28 == 0);
        org.junit.Assert.assertTrue(i29 == 0);
        org.junit.Assert.assertNotNull(mota30);
        org.junit.Assert.assertTrue(i31 == 0);
        org.junit.Assert.assertTrue(i32 == 0);
        org.junit.Assert.assertTrue(i34 == 0);
        org.junit.Assert.assertTrue(b35 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        java.lang.String str2 = mota0.toString();
        mota0.setFiabilidade(0);
        int i5 = mota0.getFiabilidade();
        mota0.setFiabilidade((int) (byte) 0);
        mota0.setOcupado(true);
        mota0.setFiabilidade((int) 'a');
        Mota mota12 = new Mota(mota0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i5 == 0);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        Mota mota4 = new Mota(mota0);
        int i5 = mota0.getVelocidadeMedia();
        java.lang.String str6 = mota0.getMatricula();
        mota0.setVelocidadeMedia((int) (byte) 1);
        mota0.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 100.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Coordenada coordenada11 = mota0.getCoordenadas();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i5 == 10);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "n/a" + "'", str6.equals("n/a"));
        org.junit.Assert.assertNotNull(coordenada11);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        java.lang.String str2 = mota0.toString();
        mota0.setMatricula("hi!");
        Mota mota9 = new Mota();
        mota9.setMatricula("");
        java.lang.String str12 = mota9.toString();
        Mota mota13 = new Mota();
        Mota mota14 = new Mota(mota13);
        java.lang.String str15 = mota13.toString();
        mota13.setFiabilidade(0);
        Mota mota18 = mota13.clone();
        Mota mota19 = new Mota();
        Mota mota20 = new Mota(mota19);
        Mota mota21 = new Mota(mota20);
        Mota mota22 = new Mota();
        Mota mota23 = new Mota(mota22);
        int i24 = mota20.compareTo((Veiculo) mota22);
        Mota mota25 = new Mota();
        mota25.setMatricula("");
        boolean b29 = mota25.equals((java.lang.Object) (-1.0d));
        boolean b30 = mota20.equals((java.lang.Object) (-1.0d));
        Mota mota31 = new Mota();
        mota31.setMatricula("");
        Mota mota34 = mota31.clone();
        mota31.setPrecoBase((double) 0L);
        Mota mota37 = new Mota();
        int i38 = mota37.getLugares();
        int i39 = mota31.compareTo((Veiculo) mota37);
        java.lang.String str40 = mota37.toString();
        Coordenada coordenada41 = mota37.getCoordenadas();
        mota20.setCoordenadas(coordenada41);
        mota13.setCoordenadas(coordenada41);
        mota9.setCoordenadas(coordenada41);
        Mota mota46 = new Mota((-33), (double) (short) 100, (int) (short) -1, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada41, false);
        mota0.setCoordenadas(coordenada41);
        double d48 = mota0.getPrecoBase();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str12.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str15.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(mota18);
        org.junit.Assert.assertTrue(i24 == 0);
        org.junit.Assert.assertTrue(b29 == false);
        org.junit.Assert.assertTrue(b30 == false);
        org.junit.Assert.assertNotNull(mota34);
        org.junit.Assert.assertTrue(i38 == 0);
        org.junit.Assert.assertTrue(i39 == 3);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str40.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada41);
        org.junit.Assert.assertTrue(d48 == 0.0d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        Mota mota4 = new Mota(mota3);
        int i5 = mota1.compareTo((Veiculo) mota3);
        Mota mota6 = new Mota(mota3);
        mota6.setVelocidadeMedia(32);
        Mota mota9 = new Mota();
        mota9.setMatricula("");
        mota9.setPrecoBase(10.0d);
        int i14 = mota6.compareTo((Veiculo) mota9);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(i14 == (-3));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Mota mota5 = new Mota(mota0);
        int i6 = mota5.getVelocidadeMedia();
        Mota mota7 = new Mota();
        Mota mota8 = new Mota(mota7);
        Mota mota9 = new Mota(mota8);
        Mota mota10 = new Mota();
        Mota mota11 = new Mota(mota10);
        int i12 = mota8.compareTo((Veiculo) mota10);
        Mota mota13 = new Mota();
        mota13.setMatricula("");
        boolean b17 = mota13.equals((java.lang.Object) (-1.0d));
        boolean b18 = mota8.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada19 = mota8.getCoordenadas();
        mota5.setCoordenadas(coordenada19);
        Coordenada coordenada21 = mota5.getCoordenadas();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertTrue(b17 == false);
        org.junit.Assert.assertTrue(b18 == false);
        org.junit.Assert.assertNotNull(coordenada19);
        org.junit.Assert.assertNotNull(coordenada21);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        Mota mota4 = new Mota(mota0);
        mota4.setFiabilidade((int) (short) 100);
        mota4.setFiabilidade((int) (short) 0);
        int i9 = mota4.getLugares();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i9 == 0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        Mota mota0 = new Mota();
        java.lang.String str1 = mota0.getMatricula();
        double d2 = mota0.getPrecoBase();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "n/a" + "'", str1.equals("n/a"));
        org.junit.Assert.assertTrue(d2 == 0.0d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        java.lang.String str3 = mota0.toString();
        Mota mota4 = mota0.clone();
        java.lang.String str5 = mota4.getMatricula();
        mota4.setOcupado(true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(mota4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        int i9 = mota6.getFiabilidade();
        double d10 = mota6.getPrecoBase();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertTrue(d10 == 0.0d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        int i4 = mota3.getLugares();
        boolean b5 = mota2.equals((java.lang.Object) mota3);
        mota3.setOcupado(true);
        boolean b8 = mota3.getOcupado();
        Mota mota9 = mota3.clone();
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue(b5 == true);
        org.junit.Assert.assertTrue(b8 == true);
        org.junit.Assert.assertNotNull(mota9);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        Mota mota4 = new Mota(mota0);
        Mota mota5 = new Mota(mota4);
        int i6 = mota5.getFiabilidade();
        Mota mota7 = mota5.clone();
        mota5.setPrecoBase((double) (byte) 0);
        int i10 = mota5.getLugares();
        Mota mota11 = new Mota(mota5);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertNotNull(mota7);
        org.junit.Assert.assertTrue(i10 == 0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        Mota mota4 = new Mota(mota0);
        int i5 = mota0.getVelocidadeMedia();
        mota0.setMatricula("");
        mota0.setPrecoBase((double) (byte) 1);
        Mota mota10 = new Mota();
        int i11 = mota10.getLugares();
        Coordenada coordenada12 = mota10.getCoordenadas();
        boolean b13 = mota0.equals((java.lang.Object) mota10);
        boolean b14 = mota10.getOcupado();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i5 == 10);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertNotNull(coordenada12);
        org.junit.Assert.assertTrue(b13 == false);
        org.junit.Assert.assertTrue(b14 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        Mota mota4 = new Mota(mota0);
        int i5 = mota0.getVelocidadeMedia();
        java.lang.String str6 = mota0.getMatricula();
        mota0.setFiabilidade((int) ' ');
        Mota mota9 = new Mota();
        mota9.setMatricula("");
        Mota mota12 = mota9.clone();
        mota9.setPrecoBase((double) 0L);
        Mota mota15 = new Mota(mota9);
        Mota mota16 = mota9.clone();
        Mota mota17 = new Mota(mota16);
        boolean b18 = mota0.equals((java.lang.Object) mota16);
        mota0.setPrecoBase((double) 100L);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i5 == 10);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "n/a" + "'", str6.equals("n/a"));
        org.junit.Assert.assertNotNull(mota12);
        org.junit.Assert.assertNotNull(mota16);
        org.junit.Assert.assertTrue(b18 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        int i3 = mota2.getVelocidadeMedia();
        org.junit.Assert.assertTrue(i3 == 0);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        Mota mota4 = new Mota(mota3);
        int i5 = mota1.compareTo((Veiculo) mota3);
        Mota mota6 = new Mota();
        mota6.setMatricula("");
        boolean b10 = mota6.equals((java.lang.Object) (-1.0d));
        boolean b11 = mota1.equals((java.lang.Object) (-1.0d));
        Mota mota12 = new Mota(mota1);
        mota1.setVelocidadeMedia((-3));
        mota1.setPrecoBase((double) (short) 100);
        Mota mota21 = new Mota();
        mota21.setMatricula("");
        boolean b25 = mota21.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada26 = mota21.getCoordenadas();
        mota21.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        mota21.setFiabilidade(0);
        Mota mota31 = new Mota();
        mota31.setMatricula("");
        Mota mota34 = mota31.clone();
        mota31.setPrecoBase((double) 0L);
        Mota mota37 = new Mota(mota31);
        int i38 = mota21.compareTo((Veiculo) mota31);
        Mota mota39 = new Mota(mota31);
        Coordenada coordenada40 = mota39.getCoordenadas();
        Mota mota42 = new Mota((int) (byte) 0, (double) 0L, (int) (byte) 0, "n/a", coordenada40, true);
        int i43 = mota42.getFiabilidade();
        int i44 = mota1.compareTo((Veiculo) mota42);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertTrue(b25 == false);
        org.junit.Assert.assertNotNull(coordenada26);
        org.junit.Assert.assertNotNull(mota34);
        org.junit.Assert.assertTrue(i38 == (-142));
        org.junit.Assert.assertNotNull(coordenada40);
        org.junit.Assert.assertTrue(i43 == 0);
        org.junit.Assert.assertTrue(i44 == 0);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota(mota0);
        mota6.setPrecoBase((double) (-1.0f));
        mota6.setOcupado(false);
        mota6.setFiabilidade(27);
        org.junit.Assert.assertNotNull(mota3);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        int i4 = mota3.getVelocidadeMedia();
        Coordenada coordenada5 = mota3.getCoordenadas();
        Mota mota6 = mota3.clone();
        Mota mota11 = new Mota();
        mota11.setMatricula("");
        Mota mota14 = mota11.clone();
        mota11.setPrecoBase((double) 0L);
        Mota mota17 = new Mota();
        int i18 = mota17.getLugares();
        int i19 = mota11.compareTo((Veiculo) mota17);
        java.lang.String str20 = mota17.toString();
        Coordenada coordenada21 = mota17.getCoordenadas();
        Mota mota23 = new Mota(0, (double) 0L, 0, "hi!", coordenada21, true);
        mota23.setPrecoBase((double) '#');
        int i26 = mota3.compareTo((Veiculo) mota23);
        double d27 = mota3.getPrecoBase();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertNotNull(mota6);
        org.junit.Assert.assertNotNull(mota14);
        org.junit.Assert.assertTrue(i18 == 0);
        org.junit.Assert.assertTrue(i19 == 3);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str20.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada21);
        org.junit.Assert.assertTrue(i26 == 3);
        org.junit.Assert.assertTrue(d27 == 0.0d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        java.lang.String str9 = mota6.toString();
        int i10 = mota6.getFiabilidade();
        mota6.setPrecoBase(10.0d);
        int i13 = mota6.getVelocidadeMedia();
        Mota mota14 = new Mota(mota6);
        mota6.setVelocidadeMedia(1);
        int i17 = mota6.getLugares();
        java.lang.String str18 = mota6.getMatricula();
        mota6.setFiabilidade((-3));
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(i17 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "n/a" + "'", str18.equals("n/a"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        java.lang.String str2 = mota0.getMatricula();
        mota0.setVelocidadeMedia((-1));
        double d5 = mota0.getPrecoBase();
        double d6 = mota0.getPrecoBase();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "n/a" + "'", str2.equals("n/a"));
        org.junit.Assert.assertTrue(d5 == 0.0d);
        org.junit.Assert.assertTrue(d6 == 0.0d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        java.lang.String str9 = mota6.toString();
        int i10 = mota6.getFiabilidade();
        mota6.setPrecoBase(10.0d);
        Mota mota13 = mota6.clone();
        java.lang.String str14 = mota13.toString();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertNotNull(mota13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 10.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str14.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 10.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        Mota mota0 = new Mota();
        java.lang.String str1 = mota0.toString();
        int i2 = mota0.getFiabilidade();
        java.lang.String str3 = mota0.getMatricula();
        int i4 = mota0.getVelocidadeMedia();
        mota0.setFiabilidade((int) (short) 0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str1.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i2 == 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "n/a" + "'", str3.equals("n/a"));
        org.junit.Assert.assertTrue(i4 == 0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = mota0.getCoordenadas();
        mota0.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        mota0.setFiabilidade(0);
        mota0.setVelocidadeMedia((-1));
        Mota mota12 = mota0.clone();
        double d13 = mota0.getPrecoBase();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertNotNull(mota12);
        org.junit.Assert.assertTrue(d13 == 0.0d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        java.lang.String str2 = mota0.toString();
        mota0.setFiabilidade(0);
        Mota mota5 = mota0.clone();
        Mota mota6 = new Mota();
        Mota mota7 = new Mota(mota6);
        Mota mota8 = new Mota(mota7);
        Mota mota9 = new Mota();
        Mota mota10 = new Mota(mota9);
        int i11 = mota7.compareTo((Veiculo) mota9);
        Mota mota12 = new Mota();
        mota12.setMatricula("");
        boolean b16 = mota12.equals((java.lang.Object) (-1.0d));
        boolean b17 = mota7.equals((java.lang.Object) (-1.0d));
        Mota mota18 = new Mota();
        mota18.setMatricula("");
        Mota mota21 = mota18.clone();
        mota18.setPrecoBase((double) 0L);
        Mota mota24 = new Mota();
        int i25 = mota24.getLugares();
        int i26 = mota18.compareTo((Veiculo) mota24);
        java.lang.String str27 = mota24.toString();
        Coordenada coordenada28 = mota24.getCoordenadas();
        mota7.setCoordenadas(coordenada28);
        mota0.setCoordenadas(coordenada28);
        mota0.setPrecoBase(100.0d);
        mota0.setMatricula("Matrícula: Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(mota5);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(b16 == false);
        org.junit.Assert.assertTrue(b17 == false);
        org.junit.Assert.assertNotNull(mota21);
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue(i26 == 3);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str27.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada28);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        java.lang.String str9 = mota6.toString();
        int i10 = mota6.getFiabilidade();
        mota6.setPrecoBase(10.0d);
        int i13 = mota6.getFiabilidade();
        Mota mota14 = new Mota();
        mota14.setMatricula("");
        Mota mota17 = mota14.clone();
        mota14.setPrecoBase((double) 0L);
        Mota mota20 = new Mota();
        int i21 = mota20.getLugares();
        int i22 = mota14.compareTo((Veiculo) mota20);
        java.lang.String str23 = mota20.toString();
        int i24 = mota20.getFiabilidade();
        mota20.setPrecoBase(10.0d);
        Coordenada coordenada27 = mota20.getCoordenadas();
        mota6.setCoordenadas(coordenada27);
        int i29 = mota6.getVelocidadeMedia();
        java.lang.String str30 = mota6.getMatricula();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertNotNull(mota17);
        org.junit.Assert.assertTrue(i21 == 0);
        org.junit.Assert.assertTrue(i22 == 3);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str23.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i24 == 0);
        org.junit.Assert.assertNotNull(coordenada27);
        org.junit.Assert.assertTrue(i29 == 0);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "n/a" + "'", str30.equals("n/a"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = mota0.getCoordenadas();
        mota0.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        mota0.setFiabilidade(0);
        int i10 = mota0.getFiabilidade();
        int i11 = mota0.getFiabilidade();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i11 == 0);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        int i4 = mota3.getLugares();
        boolean b5 = mota2.equals((java.lang.Object) mota3);
        Mota mota6 = mota3.clone();
        mota6.setVelocidadeMedia((int) (short) 0);
        Mota mota13 = new Mota();
        mota13.setMatricula("");
        Mota mota16 = mota13.clone();
        mota13.setPrecoBase((double) 0L);
        Mota mota19 = new Mota();
        int i20 = mota19.getLugares();
        int i21 = mota13.compareTo((Veiculo) mota19);
        java.lang.String str22 = mota19.toString();
        Coordenada coordenada23 = mota19.getCoordenadas();
        Mota mota25 = new Mota((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada23, false);
        int i26 = mota6.compareTo((Veiculo) mota25);
        Coordenada coordenada27 = mota25.getCoordenadas();
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue(b5 == true);
        org.junit.Assert.assertNotNull(mota6);
        org.junit.Assert.assertNotNull(mota16);
        org.junit.Assert.assertTrue(i20 == 0);
        org.junit.Assert.assertTrue(i21 == 3);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str22.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada23);
        org.junit.Assert.assertTrue(i26 == (-33));
        org.junit.Assert.assertNotNull(coordenada27);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        Mota mota4 = new Mota(mota0);
        mota4.setOcupado(false);
        mota4.setFiabilidade((int) '#');
        Mota mota9 = mota4.clone();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(mota9);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        mota0.setMatricula("n/a");
        Mota mota6 = new Mota();
        mota6.setMatricula("");
        Mota mota9 = mota6.clone();
        mota6.setPrecoBase((double) 0L);
        Mota mota12 = new Mota();
        int i13 = mota12.getLugares();
        int i14 = mota6.compareTo((Veiculo) mota12);
        java.lang.String str15 = mota12.toString();
        Coordenada coordenada16 = mota12.getCoordenadas();
        Mota mota17 = new Mota();
        int i18 = mota17.getLugares();
        Coordenada coordenada19 = mota17.getCoordenadas();
        mota12.setCoordenadas(coordenada19);
        mota0.setCoordenadas(coordenada19);
        Mota mota22 = new Mota();
        mota22.setMatricula("");
        boolean b26 = mota22.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada27 = mota22.getCoordenadas();
        mota0.setCoordenadas(coordenada27);
        int i29 = mota0.getFiabilidade();
        Mota mota30 = mota0.clone();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(mota9);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(i14 == 3);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str15.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada16);
        org.junit.Assert.assertTrue(i18 == 0);
        org.junit.Assert.assertNotNull(coordenada19);
        org.junit.Assert.assertTrue(b26 == false);
        org.junit.Assert.assertNotNull(coordenada27);
        org.junit.Assert.assertTrue(i29 == 0);
        org.junit.Assert.assertNotNull(mota30);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = mota0.getCoordenadas();
        mota0.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        mota0.setFiabilidade(0);
        Mota mota10 = new Mota();
        mota10.setMatricula("");
        Mota mota13 = mota10.clone();
        mota10.setPrecoBase((double) 0L);
        Mota mota16 = new Mota(mota10);
        int i17 = mota0.compareTo((Veiculo) mota10);
        Mota mota18 = new Mota(mota10);
        Mota mota19 = mota10.clone();
        mota10.setPrecoBase((double) ' ');
        int i22 = mota10.getFiabilidade();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertNotNull(mota13);
        org.junit.Assert.assertTrue(i17 == (-142));
        org.junit.Assert.assertNotNull(mota19);
        org.junit.Assert.assertTrue(i22 == 0);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        Mota mota8 = new Mota();
        mota8.setMatricula("");
        Mota mota11 = mota8.clone();
        mota8.setPrecoBase((double) 0L);
        Mota mota14 = new Mota();
        int i15 = mota14.getLugares();
        int i16 = mota8.compareTo((Veiculo) mota14);
        java.lang.String str17 = mota14.toString();
        Coordenada coordenada18 = mota14.getCoordenadas();
        Mota mota20 = new Mota((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, false);
        Mota mota22 = new Mota(1, 100.0d, 0, "hi!", coordenada18, true);
        mota22.setPrecoBase((double) '#');
        org.junit.Assert.assertNotNull(mota11);
        org.junit.Assert.assertTrue(i15 == 0);
        org.junit.Assert.assertTrue(i16 == 3);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str17.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada18);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        double d6 = mota0.getPrecoBase();
        int i7 = mota0.getVelocidadeMedia();
        mota0.setMatricula("");
        mota0.setOcupado(false);
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(i7 == 0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Mota mota5 = new Mota(mota0);
        double d6 = mota0.getPrecoBase();
        boolean b7 = mota0.getOcupado();
        mota0.setPrecoBase((double) ' ');
        int i10 = mota0.getFiabilidade();
        mota0.setFiabilidade((int) (byte) -1);
        java.lang.String str13 = mota0.toString();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(b7 == false);
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 32.0€\nFiabilidade: -1\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str13.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 32.0€\nFiabilidade: -1\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        Mota mota12 = new Mota();
        mota12.setMatricula("");
        java.lang.String str15 = mota12.toString();
        Mota mota16 = new Mota();
        Mota mota17 = new Mota(mota16);
        java.lang.String str18 = mota16.toString();
        mota16.setFiabilidade(0);
        Mota mota21 = mota16.clone();
        Mota mota22 = new Mota();
        Mota mota23 = new Mota(mota22);
        Mota mota24 = new Mota(mota23);
        Mota mota25 = new Mota();
        Mota mota26 = new Mota(mota25);
        int i27 = mota23.compareTo((Veiculo) mota25);
        Mota mota28 = new Mota();
        mota28.setMatricula("");
        boolean b32 = mota28.equals((java.lang.Object) (-1.0d));
        boolean b33 = mota23.equals((java.lang.Object) (-1.0d));
        Mota mota34 = new Mota();
        mota34.setMatricula("");
        Mota mota37 = mota34.clone();
        mota34.setPrecoBase((double) 0L);
        Mota mota40 = new Mota();
        int i41 = mota40.getLugares();
        int i42 = mota34.compareTo((Veiculo) mota40);
        java.lang.String str43 = mota40.toString();
        Coordenada coordenada44 = mota40.getCoordenadas();
        mota23.setCoordenadas(coordenada44);
        mota16.setCoordenadas(coordenada44);
        mota12.setCoordenadas(coordenada44);
        Mota mota49 = new Mota((int) (byte) 0, (double) 100L, (int) (byte) -1, "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada44, false);
        Mota mota51 = new Mota((int) (byte) 10, (double) (byte) -1, (int) '#', "Matrícula: Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada44, true);
        Mota mota53 = new Mota(27, (double) 0.0f, (int) (byte) 0, "", coordenada44, true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str15.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str18.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(mota21);
        org.junit.Assert.assertTrue(i27 == 0);
        org.junit.Assert.assertTrue(b32 == false);
        org.junit.Assert.assertTrue(b33 == false);
        org.junit.Assert.assertNotNull(mota37);
        org.junit.Assert.assertTrue(i41 == 0);
        org.junit.Assert.assertTrue(i42 == 3);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str43.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada44);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = mota0.getCoordenadas();
        mota0.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        mota0.setFiabilidade(0);
        int i10 = mota0.getVelocidadeMedia();
        Mota mota11 = new Mota();
        mota11.setMatricula("");
        boolean b14 = mota0.equals((java.lang.Object) "");
        Coordenada coordenada15 = mota0.getCoordenadas();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertNotNull(coordenada15);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        Mota mota4 = mota0.clone();
        mota0.setMatricula("Matrícula: Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        int i7 = mota0.getLugares();
        Mota mota8 = new Mota();
        mota8.setMatricula("");
        boolean b12 = mota8.equals((java.lang.Object) (-1.0d));
        Mota mota13 = new Mota(mota8);
        double d14 = mota8.getPrecoBase();
        boolean b15 = mota8.getOcupado();
        int i16 = mota8.getVelocidadeMedia();
        java.lang.String str17 = mota8.getMatricula();
        mota8.setMatricula("hi!");
        mota8.setVelocidadeMedia((int) (byte) 1);
        Coordenada coordenada22 = mota8.getCoordenadas();
        int i23 = mota0.compareTo((Veiculo) mota8);
        int i24 = mota8.getLugares();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(mota4);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertTrue(d14 == 0.0d);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(coordenada22);
        org.junit.Assert.assertTrue(i23 == 27);
        org.junit.Assert.assertTrue(i24 == 0);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        double d6 = mota0.getPrecoBase();
        Mota mota7 = mota0.clone();
        mota7.setVelocidadeMedia((int) (byte) -1);
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertNotNull(mota7);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        mota0.setOcupado(false);
        mota0.setVelocidadeMedia((-1));
        mota0.setPrecoBase(0.0d);
        mota0.setMatricula("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        int i11 = mota0.getLugares();
        org.junit.Assert.assertTrue(i11 == 0);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        Mota mota8 = new Mota();
        mota8.setMatricula("");
        Mota mota11 = mota8.clone();
        Coordenada coordenada12 = mota11.getCoordenadas();
        Mota mota14 = new Mota((int) (byte) 0, (double) 'a', 3, "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada12, false);
        Mota mota16 = new Mota((int) (short) 10, (double) 1L, (int) '4', "Matrícula: n/a\nVelocidade Média/km: -1km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada12, true);
        org.junit.Assert.assertNotNull(mota11);
        org.junit.Assert.assertNotNull(coordenada12);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        java.lang.String str3 = mota0.toString();
        int i4 = mota0.getFiabilidade();
        mota0.setVelocidadeMedia((-1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i4 == 0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        Mota mota4 = new Mota();
        Mota mota5 = new Mota(mota4);
        Mota mota6 = new Mota(mota5);
        Mota mota7 = new Mota();
        Mota mota8 = new Mota(mota7);
        int i9 = mota5.compareTo((Veiculo) mota7);
        Coordenada coordenada10 = mota7.getCoordenadas();
        Mota mota15 = new Mota();
        mota15.setMatricula("");
        Mota mota18 = mota15.clone();
        mota15.setPrecoBase((double) 0L);
        Mota mota21 = new Mota();
        int i22 = mota21.getLugares();
        int i23 = mota15.compareTo((Veiculo) mota21);
        int i24 = mota21.getFiabilidade();
        Mota mota25 = mota21.clone();
        Coordenada coordenada26 = mota25.getCoordenadas();
        Mota mota28 = new Mota((-142), (double) (byte) 1, (int) (short) 1, "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 1\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada26, true);
        mota7.setCoordenadas(coordenada26);
        Mota mota31 = new Mota((int) (short) 100, (double) (byte) 1, (-3), "Matrícula: Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 33\nLugares: 1\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada26, true);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertNotNull(mota18);
        org.junit.Assert.assertTrue(i22 == 0);
        org.junit.Assert.assertTrue(i23 == 3);
        org.junit.Assert.assertTrue(i24 == 0);
        org.junit.Assert.assertNotNull(mota25);
        org.junit.Assert.assertNotNull(coordenada26);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Mota mota5 = new Mota(mota0);
        double d6 = mota0.getPrecoBase();
        boolean b7 = mota0.getOcupado();
        int i8 = mota0.getVelocidadeMedia();
        Mota mota9 = mota0.clone();
        mota9.setFiabilidade((int) (byte) 10);
        mota9.setVelocidadeMedia((int) ' ');
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(b7 == false);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertNotNull(mota9);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        int i3 = mota0.getVelocidadeMedia();
        Mota mota4 = new Mota(mota0);
        int i5 = mota4.getFiabilidade();
        int i6 = mota4.getVelocidadeMedia();
        mota4.setFiabilidade((-3));
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(i6 == 0);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Mota mota5 = new Mota(mota0);
        Mota mota6 = new Mota();
        mota6.setMatricula("");
        Mota mota9 = mota6.clone();
        Coordenada coordenada10 = mota9.getCoordenadas();
        mota5.setCoordenadas(coordenada10);
        java.lang.String str12 = mota5.getMatricula();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(mota9);
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        Mota mota4 = new Mota(mota3);
        int i5 = mota1.compareTo((Veiculo) mota3);
        Mota mota6 = new Mota();
        mota6.setMatricula("");
        boolean b10 = mota6.equals((java.lang.Object) (-1.0d));
        boolean b11 = mota1.equals((java.lang.Object) (-1.0d));
        Mota mota12 = new Mota();
        mota12.setMatricula("");
        Mota mota15 = mota12.clone();
        mota12.setPrecoBase((double) 0L);
        Mota mota18 = new Mota();
        int i19 = mota18.getLugares();
        int i20 = mota12.compareTo((Veiculo) mota18);
        java.lang.String str21 = mota18.toString();
        Coordenada coordenada22 = mota18.getCoordenadas();
        mota1.setCoordenadas(coordenada22);
        mota1.setMatricula("");
        Coordenada coordenada26 = null;
        try {
            mota1.setCoordenadas(coordenada26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertNotNull(mota15);
        org.junit.Assert.assertTrue(i19 == 0);
        org.junit.Assert.assertTrue(i20 == 3);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str21.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada22);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota(mota0);
        Mota mota7 = mota0.clone();
        Mota mota8 = mota7.clone();
        mota8.setMatricula("");
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertNotNull(mota7);
        org.junit.Assert.assertNotNull(mota8);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        Mota mota0 = new Mota();
        mota0.setVelocidadeMedia((int) ' ');
        java.lang.String str3 = mota0.toString();
        Mota mota8 = new Mota();
        mota8.setMatricula("");
        Mota mota11 = mota8.clone();
        Coordenada coordenada12 = mota11.getCoordenadas();
        Mota mota14 = new Mota((int) (byte) 0, (double) 'a', 3, "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada12, false);
        boolean b15 = mota0.equals((java.lang.Object) 'a');
        mota0.setVelocidadeMedia((int) (byte) 100);
        mota0.setOcupado(true);
        int i20 = mota0.getFiabilidade();
        java.lang.String str21 = mota0.getMatricula();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(mota11);
        org.junit.Assert.assertNotNull(coordenada12);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertTrue(i20 == 0);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "n/a" + "'", str21.equals("n/a"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        int i4 = mota3.getLugares();
        boolean b5 = mota2.equals((java.lang.Object) mota3);
        Mota mota6 = mota3.clone();
        Mota mota7 = new Mota(mota6);
        java.lang.String str8 = mota6.toString();
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue(b5 == true);
        org.junit.Assert.assertNotNull(mota6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str8.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        Mota mota4 = new Mota();
        mota4.setMatricula("");
        Mota mota7 = mota4.clone();
        mota4.setPrecoBase((double) 0L);
        Mota mota10 = new Mota();
        int i11 = mota10.getLugares();
        int i12 = mota4.compareTo((Veiculo) mota10);
        java.lang.String str13 = mota10.toString();
        Coordenada coordenada14 = mota10.getCoordenadas();
        Mota mota16 = new Mota(0, (double) 0L, 0, "hi!", coordenada14, true);
        mota16.setPrecoBase((double) '#');
        Mota mota19 = new Mota();
        mota19.setMatricula("");
        boolean b23 = mota19.equals((java.lang.Object) (-1.0d));
        Mota mota24 = new Mota(mota19);
        Coordenada coordenada25 = mota24.getCoordenadas();
        mota16.setCoordenadas(coordenada25);
        Coordenada coordenada27 = mota16.getCoordenadas();
        int i28 = mota16.getVelocidadeMedia();
        org.junit.Assert.assertNotNull(mota7);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(i12 == 3);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str13.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada14);
        org.junit.Assert.assertTrue(b23 == false);
        org.junit.Assert.assertNotNull(coordenada25);
        org.junit.Assert.assertNotNull(coordenada27);
        org.junit.Assert.assertTrue(i28 == 0);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        java.lang.String str3 = mota0.toString();
        Mota mota4 = mota0.clone();
        java.lang.String str5 = mota0.toString();
        Coordenada coordenada6 = mota0.getCoordenadas();
        java.lang.String str7 = mota0.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(mota4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str5.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str7.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        Mota mota8 = new Mota();
        mota8.setMatricula("");
        java.lang.String str11 = mota8.toString();
        Mota mota12 = new Mota();
        Mota mota13 = new Mota(mota12);
        java.lang.String str14 = mota12.toString();
        mota12.setFiabilidade(0);
        Mota mota17 = mota12.clone();
        Mota mota18 = new Mota();
        Mota mota19 = new Mota(mota18);
        Mota mota20 = new Mota(mota19);
        Mota mota21 = new Mota();
        Mota mota22 = new Mota(mota21);
        int i23 = mota19.compareTo((Veiculo) mota21);
        Mota mota24 = new Mota();
        mota24.setMatricula("");
        boolean b28 = mota24.equals((java.lang.Object) (-1.0d));
        boolean b29 = mota19.equals((java.lang.Object) (-1.0d));
        Mota mota30 = new Mota();
        mota30.setMatricula("");
        Mota mota33 = mota30.clone();
        mota30.setPrecoBase((double) 0L);
        Mota mota36 = new Mota();
        int i37 = mota36.getLugares();
        int i38 = mota30.compareTo((Veiculo) mota36);
        java.lang.String str39 = mota36.toString();
        Coordenada coordenada40 = mota36.getCoordenadas();
        mota19.setCoordenadas(coordenada40);
        mota12.setCoordenadas(coordenada40);
        mota8.setCoordenadas(coordenada40);
        Mota mota45 = new Mota((int) (byte) 0, (double) 100L, (int) (byte) -1, "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada40, false);
        Mota mota47 = new Mota((int) (byte) 10, (double) (byte) -1, (int) '#', "Matrícula: Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada40, true);
        java.lang.String str48 = mota47.toString();
        mota47.setVelocidadeMedia((int) (byte) 10);
        boolean b51 = mota47.getOcupado();
        boolean b52 = mota47.getOcupado();
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str11.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str14.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(mota17);
        org.junit.Assert.assertTrue(i23 == 0);
        org.junit.Assert.assertTrue(b28 == false);
        org.junit.Assert.assertTrue(b29 == false);
        org.junit.Assert.assertNotNull(mota33);
        org.junit.Assert.assertTrue(i37 == 0);
        org.junit.Assert.assertTrue(i38 == 3);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str39.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada40);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "Matrícula: Matrícula: Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 10km/h\nPreço Base: -1.0€\nFiabilidade: 35\nLugares: 1\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n" + "'", str48.equals("Matrícula: Matrícula: Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 10km/h\nPreço Base: -1.0€\nFiabilidade: 35\nLugares: 1\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n"));
        org.junit.Assert.assertTrue(b51 == true);
        org.junit.Assert.assertTrue(b52 == true);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        Mota mota4 = new Mota(mota0);
        Mota mota5 = new Mota(mota4);
        int i6 = mota5.getFiabilidade();
        Mota mota7 = mota5.clone();
        Mota mota8 = new Mota();
        mota8.setMatricula("");
        Mota mota11 = mota8.clone();
        int i12 = mota11.getVelocidadeMedia();
        Coordenada coordenada13 = mota11.getCoordenadas();
        mota7.setCoordenadas(coordenada13);
        int i15 = mota7.getVelocidadeMedia();
        mota7.setOcupado(false);
        Mota mota18 = new Mota(mota7);
        Mota mota19 = new Mota();
        mota19.setMatricula("");
        mota19.setVelocidadeMedia(32);
        int i24 = mota7.compareTo((Veiculo) mota19);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertNotNull(mota7);
        org.junit.Assert.assertNotNull(mota11);
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertNotNull(coordenada13);
        org.junit.Assert.assertTrue(i15 == 10);
        org.junit.Assert.assertTrue(i24 == (-3));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Mota mota5 = new Mota(mota0);
        double d6 = mota0.getPrecoBase();
        boolean b7 = mota0.getOcupado();
        mota0.setPrecoBase((double) ' ');
        int i10 = mota0.getFiabilidade();
        mota0.setFiabilidade((int) (byte) -1);
        int i13 = mota0.getVelocidadeMedia();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(b7 == false);
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i13 == 0);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = mota0.getCoordenadas();
        mota0.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        mota0.setFiabilidade(0);
        Mota mota10 = new Mota();
        mota10.setMatricula("");
        Mota mota13 = mota10.clone();
        mota10.setPrecoBase((double) 0L);
        Mota mota16 = new Mota(mota10);
        int i17 = mota0.compareTo((Veiculo) mota10);
        Mota mota18 = new Mota();
        Mota mota19 = new Mota(mota18);
        java.lang.String str20 = mota18.toString();
        mota18.setFiabilidade(0);
        mota18.setPrecoBase(1.0d);
        int i25 = mota0.compareTo((Veiculo) mota18);
        mota18.setFiabilidade((int) (byte) 100);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertNotNull(mota13);
        org.junit.Assert.assertTrue(i17 == (-142));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str20.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i25 == 33);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        Coordenada coordenada4 = mota3.getCoordenadas();
        Mota mota5 = new Mota();
        mota5.setMatricula("");
        Mota mota8 = mota5.clone();
        mota5.setPrecoBase((double) 0L);
        Mota mota11 = new Mota();
        int i12 = mota11.getLugares();
        int i13 = mota5.compareTo((Veiculo) mota11);
        java.lang.String str14 = mota11.toString();
        Coordenada coordenada15 = mota11.getCoordenadas();
        int i16 = mota3.compareTo((Veiculo) mota11);
        double d17 = mota11.getPrecoBase();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertNotNull(coordenada4);
        org.junit.Assert.assertNotNull(mota8);
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertTrue(i13 == 3);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str14.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada15);
        org.junit.Assert.assertTrue(i16 == 3);
        org.junit.Assert.assertTrue(d17 == 0.0d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        int i4 = mota3.getVelocidadeMedia();
        Coordenada coordenada5 = mota3.getCoordenadas();
        Mota mota6 = new Mota();
        mota6.setMatricula("");
        Mota mota9 = mota6.clone();
        mota6.setPrecoBase((double) 0L);
        Mota mota12 = new Mota();
        int i13 = mota12.getLugares();
        int i14 = mota6.compareTo((Veiculo) mota12);
        java.lang.String str15 = mota12.toString();
        java.lang.String str16 = mota12.toString();
        boolean b17 = mota3.equals((java.lang.Object) str16);
        mota3.setFiabilidade((int) (byte) 0);
        int i20 = mota3.getLugares();
        Mota mota21 = new Mota();
        mota21.setMatricula("");
        Mota mota24 = mota21.clone();
        mota21.setPrecoBase((double) 0L);
        Mota mota27 = new Mota(mota21);
        Mota mota40 = new Mota();
        mota40.setMatricula("");
        Mota mota43 = mota40.clone();
        mota40.setPrecoBase((double) 0L);
        Mota mota46 = new Mota();
        int i47 = mota46.getLugares();
        int i48 = mota40.compareTo((Veiculo) mota46);
        java.lang.String str49 = mota46.toString();
        Coordenada coordenada50 = mota46.getCoordenadas();
        Mota mota52 = new Mota((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada50, false);
        Mota mota54 = new Mota((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada50, true);
        Mota mota56 = new Mota((int) '#', 10.0d, (-1), "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada50, true);
        mota27.setCoordenadas(coordenada50);
        boolean b58 = mota3.equals((java.lang.Object) mota27);
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertNotNull(mota9);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(i14 == 3);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str15.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str16.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(b17 == false);
        org.junit.Assert.assertTrue(i20 == 0);
        org.junit.Assert.assertNotNull(mota24);
        org.junit.Assert.assertNotNull(mota43);
        org.junit.Assert.assertTrue(i47 == 0);
        org.junit.Assert.assertTrue(i48 == 3);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str49.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada50);
        org.junit.Assert.assertTrue(b58 == true);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        double d6 = mota0.getPrecoBase();
        mota0.setMatricula("Matrícula: Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 35km/h\nPreço Base: 10.0€\nFiabilidade: -1\nLugares: 1\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n");
        Coordenada coordenada9 = mota0.getCoordenadas();
        mota0.setVelocidadeMedia((int) (short) 0);
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertNotNull(coordenada9);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        java.lang.String str3 = mota0.toString();
        Mota mota4 = new Mota();
        Mota mota5 = new Mota(mota4);
        java.lang.String str6 = mota4.toString();
        mota4.setFiabilidade(0);
        Mota mota9 = mota4.clone();
        Mota mota10 = new Mota();
        Mota mota11 = new Mota(mota10);
        Mota mota12 = new Mota(mota11);
        Mota mota13 = new Mota();
        Mota mota14 = new Mota(mota13);
        int i15 = mota11.compareTo((Veiculo) mota13);
        Mota mota16 = new Mota();
        mota16.setMatricula("");
        boolean b20 = mota16.equals((java.lang.Object) (-1.0d));
        boolean b21 = mota11.equals((java.lang.Object) (-1.0d));
        Mota mota22 = new Mota();
        mota22.setMatricula("");
        Mota mota25 = mota22.clone();
        mota22.setPrecoBase((double) 0L);
        Mota mota28 = new Mota();
        int i29 = mota28.getLugares();
        int i30 = mota22.compareTo((Veiculo) mota28);
        java.lang.String str31 = mota28.toString();
        Coordenada coordenada32 = mota28.getCoordenadas();
        mota11.setCoordenadas(coordenada32);
        mota4.setCoordenadas(coordenada32);
        mota4.setMatricula("hi!");
        int i37 = mota4.getFiabilidade();
        int i38 = mota0.compareTo((Veiculo) mota4);
        Mota mota39 = mota4.clone();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str6.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(mota9);
        org.junit.Assert.assertTrue(i15 == 0);
        org.junit.Assert.assertTrue(b20 == false);
        org.junit.Assert.assertTrue(b21 == false);
        org.junit.Assert.assertNotNull(mota25);
        org.junit.Assert.assertTrue(i29 == 0);
        org.junit.Assert.assertTrue(i30 == 3);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str31.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada32);
        org.junit.Assert.assertTrue(i37 == 0);
        org.junit.Assert.assertTrue(i38 == 3);
        org.junit.Assert.assertNotNull(mota39);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        Mota mota4 = new Mota();
        mota4.setMatricula("");
        Mota mota7 = mota4.clone();
        mota4.setPrecoBase((double) 0L);
        Mota mota10 = new Mota();
        int i11 = mota10.getLugares();
        int i12 = mota4.compareTo((Veiculo) mota10);
        java.lang.String str13 = mota10.toString();
        Coordenada coordenada14 = mota10.getCoordenadas();
        Mota mota16 = new Mota((int) (byte) 100, (double) '#', (int) (short) 0, "", coordenada14, false);
        java.lang.Object obj17 = null;
        boolean b18 = mota16.equals(obj17);
        mota16.setMatricula("");
        java.lang.String str21 = mota16.toString();
        org.junit.Assert.assertNotNull(mota7);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(i12 == 3);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str13.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada14);
        org.junit.Assert.assertTrue(b18 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Matrícula: \nVelocidade Média/km: 100km/h\nPreço Base: 35.0€\nFiabilidade: 0\nLugares: 1\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str21.equals("Matrícula: \nVelocidade Média/km: 100km/h\nPreço Base: 35.0€\nFiabilidade: 0\nLugares: 1\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota(mota0);
        mota6.setPrecoBase((double) (-1.0f));
        mota6.setVelocidadeMedia((int) (short) 0);
        mota6.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Mota mota13 = new Mota(mota6);
        Mota mota14 = mota6.clone();
        Mota mota15 = new Mota();
        int i16 = mota15.getLugares();
        java.lang.String str17 = mota15.getMatricula();
        Mota mota18 = new Mota(mota15);
        Mota mota19 = new Mota();
        mota19.setMatricula("");
        Mota mota22 = mota19.clone();
        Coordenada coordenada23 = mota22.getCoordenadas();
        Mota mota24 = new Mota();
        mota24.setMatricula("");
        Mota mota27 = mota24.clone();
        mota24.setPrecoBase((double) 0L);
        Mota mota30 = new Mota();
        int i31 = mota30.getLugares();
        int i32 = mota24.compareTo((Veiculo) mota30);
        java.lang.String str33 = mota30.toString();
        Coordenada coordenada34 = mota30.getCoordenadas();
        int i35 = mota22.compareTo((Veiculo) mota30);
        Mota mota36 = new Mota();
        Mota mota37 = new Mota(mota36);
        java.lang.String str38 = mota36.toString();
        mota36.setFiabilidade(0);
        Mota mota41 = mota36.clone();
        int i42 = mota36.getLugares();
        Mota mota47 = new Mota();
        Mota mota48 = new Mota(mota47);
        Mota mota49 = new Mota(mota48);
        Mota mota50 = new Mota();
        Mota mota51 = new Mota(mota50);
        int i52 = mota48.compareTo((Veiculo) mota50);
        Mota mota53 = new Mota();
        mota53.setMatricula("");
        boolean b57 = mota53.equals((java.lang.Object) (-1.0d));
        boolean b58 = mota48.equals((java.lang.Object) (-1.0d));
        Mota mota59 = new Mota();
        mota59.setMatricula("");
        Mota mota62 = mota59.clone();
        mota59.setPrecoBase((double) 0L);
        Mota mota65 = new Mota();
        int i66 = mota65.getLugares();
        int i67 = mota59.compareTo((Veiculo) mota65);
        java.lang.String str68 = mota65.toString();
        Coordenada coordenada69 = mota65.getCoordenadas();
        mota48.setCoordenadas(coordenada69);
        Mota mota72 = new Mota((-1), 10.0d, (int) (byte) 1, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada69, true);
        mota36.setCoordenadas(coordenada69);
        mota30.setCoordenadas(coordenada69);
        mota15.setCoordenadas(coordenada69);
        mota6.setCoordenadas(coordenada69);
        int i77 = mota6.getVelocidadeMedia();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertNotNull(mota14);
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "n/a" + "'", str17.equals("n/a"));
        org.junit.Assert.assertNotNull(mota22);
        org.junit.Assert.assertNotNull(coordenada23);
        org.junit.Assert.assertNotNull(mota27);
        org.junit.Assert.assertTrue(i31 == 0);
        org.junit.Assert.assertTrue(i32 == 3);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str33.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada34);
        org.junit.Assert.assertTrue(i35 == 3);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str38.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(mota41);
        org.junit.Assert.assertTrue(i42 == 0);
        org.junit.Assert.assertTrue(i52 == 0);
        org.junit.Assert.assertTrue(b57 == false);
        org.junit.Assert.assertTrue(b58 == false);
        org.junit.Assert.assertNotNull(mota62);
        org.junit.Assert.assertTrue(i66 == 0);
        org.junit.Assert.assertTrue(i67 == 3);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str68.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada69);
        org.junit.Assert.assertTrue(i77 == 0);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        java.lang.String str2 = mota0.toString();
        mota0.setFiabilidade(0);
        int i5 = mota0.getFiabilidade();
        Mota mota6 = new Mota(mota0);
        mota0.setOcupado(true);
        mota0.setOcupado(true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i5 == 0);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        mota0.setVelocidadeMedia(32);
        int i5 = mota0.getLugares();
        org.junit.Assert.assertTrue(i5 == 0);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = mota0.getCoordenadas();
        int i6 = mota0.getVelocidadeMedia();
        Mota mota7 = new Mota();
        mota7.setMatricula("");
        Mota mota10 = mota7.clone();
        mota10.setOcupado(true);
        boolean b13 = mota0.equals((java.lang.Object) mota10);
        mota10.setMatricula("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Mota mota16 = new Mota(mota10);
        Mota mota17 = new Mota();
        Mota mota18 = new Mota(mota17);
        Mota mota19 = new Mota(mota18);
        Mota mota20 = new Mota();
        Mota mota21 = new Mota(mota20);
        int i22 = mota18.compareTo((Veiculo) mota20);
        Mota mota23 = new Mota();
        mota23.setMatricula("");
        boolean b27 = mota23.equals((java.lang.Object) (-1.0d));
        boolean b28 = mota18.equals((java.lang.Object) (-1.0d));
        int i29 = mota10.compareTo((Veiculo) mota18);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertNotNull(mota10);
        org.junit.Assert.assertTrue(b13 == false);
        org.junit.Assert.assertTrue(i22 == 0);
        org.junit.Assert.assertTrue(b27 == false);
        org.junit.Assert.assertTrue(b28 == false);
        org.junit.Assert.assertTrue(i29 == 33);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        Mota mota8 = new Mota();
        mota8.setMatricula("");
        java.lang.String str11 = mota8.toString();
        Mota mota12 = new Mota();
        Mota mota13 = new Mota(mota12);
        java.lang.String str14 = mota12.toString();
        mota12.setFiabilidade(0);
        Mota mota17 = mota12.clone();
        Mota mota18 = new Mota();
        Mota mota19 = new Mota(mota18);
        Mota mota20 = new Mota(mota19);
        Mota mota21 = new Mota();
        Mota mota22 = new Mota(mota21);
        int i23 = mota19.compareTo((Veiculo) mota21);
        Mota mota24 = new Mota();
        mota24.setMatricula("");
        boolean b28 = mota24.equals((java.lang.Object) (-1.0d));
        boolean b29 = mota19.equals((java.lang.Object) (-1.0d));
        Mota mota30 = new Mota();
        mota30.setMatricula("");
        Mota mota33 = mota30.clone();
        mota30.setPrecoBase((double) 0L);
        Mota mota36 = new Mota();
        int i37 = mota36.getLugares();
        int i38 = mota30.compareTo((Veiculo) mota36);
        java.lang.String str39 = mota36.toString();
        Coordenada coordenada40 = mota36.getCoordenadas();
        mota19.setCoordenadas(coordenada40);
        mota12.setCoordenadas(coordenada40);
        mota8.setCoordenadas(coordenada40);
        Mota mota45 = new Mota((-33), (double) (short) 100, (int) (short) -1, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada40, false);
        Mota mota47 = new Mota((int) (short) 1, (double) 0.0f, (int) (short) 10, "Matrícula: Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 100.0€\nFiabilidade: 10\nLugares: 1\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada40, false);
        mota47.setOcupado(false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str11.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str14.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(mota17);
        org.junit.Assert.assertTrue(i23 == 0);
        org.junit.Assert.assertTrue(b28 == false);
        org.junit.Assert.assertTrue(b29 == false);
        org.junit.Assert.assertNotNull(mota33);
        org.junit.Assert.assertTrue(i37 == 0);
        org.junit.Assert.assertTrue(i38 == 3);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str39.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada40);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        int i3 = mota0.getVelocidadeMedia();
        Mota mota4 = new Mota(mota0);
        double d5 = mota0.getPrecoBase();
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue(d5 == 0.0d);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        Mota mota4 = new Mota();
        Mota mota5 = new Mota(mota4);
        java.lang.String str6 = mota4.toString();
        mota4.setFiabilidade(0);
        Mota mota9 = mota4.clone();
        Mota mota10 = new Mota();
        Mota mota11 = new Mota(mota10);
        Mota mota12 = new Mota(mota11);
        Mota mota13 = new Mota();
        Mota mota14 = new Mota(mota13);
        int i15 = mota11.compareTo((Veiculo) mota13);
        Mota mota16 = new Mota();
        mota16.setMatricula("");
        boolean b20 = mota16.equals((java.lang.Object) (-1.0d));
        boolean b21 = mota11.equals((java.lang.Object) (-1.0d));
        Mota mota22 = new Mota();
        mota22.setMatricula("");
        Mota mota25 = mota22.clone();
        mota22.setPrecoBase((double) 0L);
        Mota mota28 = new Mota();
        int i29 = mota28.getLugares();
        int i30 = mota22.compareTo((Veiculo) mota28);
        java.lang.String str31 = mota28.toString();
        Coordenada coordenada32 = mota28.getCoordenadas();
        mota11.setCoordenadas(coordenada32);
        mota4.setCoordenadas(coordenada32);
        Mota mota36 = new Mota((int) (byte) 10, (double) (short) -1, 0, "Matrícula: Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada32, false);
        double d37 = mota36.getPrecoBase();
        int i38 = mota36.getLugares();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str6.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(mota9);
        org.junit.Assert.assertTrue(i15 == 0);
        org.junit.Assert.assertTrue(b20 == false);
        org.junit.Assert.assertTrue(b21 == false);
        org.junit.Assert.assertNotNull(mota25);
        org.junit.Assert.assertTrue(i29 == 0);
        org.junit.Assert.assertTrue(i30 == 3);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str31.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada32);
        org.junit.Assert.assertTrue(d37 == (-1.0d));
        org.junit.Assert.assertTrue(i38 == 1);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        Mota mota4 = new Mota();
        mota4.setMatricula("");
        Mota mota7 = mota4.clone();
        mota4.setPrecoBase((double) 0L);
        Mota mota10 = new Mota();
        int i11 = mota10.getLugares();
        int i12 = mota4.compareTo((Veiculo) mota10);
        java.lang.String str13 = mota10.toString();
        Coordenada coordenada14 = mota10.getCoordenadas();
        Mota mota16 = new Mota(0, (double) 0L, 0, "hi!", coordenada14, true);
        mota16.setPrecoBase((double) '#');
        Mota mota19 = new Mota();
        mota19.setMatricula("");
        boolean b23 = mota19.equals((java.lang.Object) (-1.0d));
        Mota mota24 = new Mota(mota19);
        Coordenada coordenada25 = mota24.getCoordenadas();
        mota16.setCoordenadas(coordenada25);
        Mota mota27 = new Mota(mota16);
        java.lang.String str28 = mota16.toString();
        org.junit.Assert.assertNotNull(mota7);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(i12 == 3);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str13.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada14);
        org.junit.Assert.assertTrue(b23 == false);
        org.junit.Assert.assertNotNull(coordenada25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Matrícula: hi!\nVelocidade Média/km: 0km/h\nPreço Base: 35.0€\nFiabilidade: 0\nLugares: 1\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n" + "'", str28.equals("Matrícula: hi!\nVelocidade Média/km: 0km/h\nPreço Base: 35.0€\nFiabilidade: 0\nLugares: 1\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        java.lang.String str3 = mota0.toString();
        Mota mota4 = mota0.clone();
        mota4.setFiabilidade((int) (short) 100);
        Mota mota7 = new Mota();
        mota7.setMatricula("");
        Mota mota10 = mota7.clone();
        Coordenada coordenada11 = mota10.getCoordenadas();
        Mota mota12 = new Mota();
        mota12.setMatricula("");
        Mota mota15 = mota12.clone();
        mota12.setPrecoBase((double) 0L);
        Mota mota18 = new Mota();
        int i19 = mota18.getLugares();
        int i20 = mota12.compareTo((Veiculo) mota18);
        java.lang.String str21 = mota18.toString();
        Coordenada coordenada22 = mota18.getCoordenadas();
        int i23 = mota10.compareTo((Veiculo) mota18);
        java.lang.String str24 = mota10.getMatricula();
        mota10.setPrecoBase((double) 10);
        int i27 = mota10.getFiabilidade();
        int i28 = mota4.compareTo((Veiculo) mota10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(mota4);
        org.junit.Assert.assertNotNull(mota10);
        org.junit.Assert.assertNotNull(coordenada11);
        org.junit.Assert.assertNotNull(mota15);
        org.junit.Assert.assertTrue(i19 == 0);
        org.junit.Assert.assertTrue(i20 == 3);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str21.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada22);
        org.junit.Assert.assertTrue(i23 == 3);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertTrue(i27 == 0);
        org.junit.Assert.assertTrue(i28 == 0);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        int i4 = mota3.getLugares();
        boolean b5 = mota2.equals((java.lang.Object) mota3);
        mota3.setOcupado(true);
        Coordenada coordenada8 = mota3.getCoordenadas();
        mota3.setPrecoBase((double) 0L);
        Mota mota11 = mota3.clone();
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue(b5 == true);
        org.junit.Assert.assertNotNull(coordenada8);
        org.junit.Assert.assertNotNull(mota11);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        Mota mota4 = new Mota();
        mota4.setMatricula("");
        java.lang.String str7 = mota4.toString();
        Mota mota8 = mota4.clone();
        Mota mota21 = new Mota();
        mota21.setMatricula("");
        Mota mota24 = mota21.clone();
        mota21.setPrecoBase((double) 0L);
        Mota mota27 = new Mota();
        int i28 = mota27.getLugares();
        int i29 = mota21.compareTo((Veiculo) mota27);
        java.lang.String str30 = mota27.toString();
        Coordenada coordenada31 = mota27.getCoordenadas();
        Mota mota33 = new Mota((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada31, false);
        Mota mota35 = new Mota((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada31, true);
        Mota mota37 = new Mota((int) '#', 10.0d, (-1), "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada31, true);
        Coordenada coordenada38 = mota37.getCoordenadas();
        mota8.setCoordenadas(coordenada38);
        Coordenada coordenada40 = mota8.getCoordenadas();
        Mota mota42 = new Mota(0, (double) 0, (int) (short) 100, "Matrícula: Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 100km/h\nPreço Base: 10.0€\nFiabilidade: 10\nLugares: 1\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada40, true);
        Mota mota43 = mota42.clone();
        mota43.setPrecoBase(35.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str7.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(mota8);
        org.junit.Assert.assertNotNull(mota24);
        org.junit.Assert.assertTrue(i28 == 0);
        org.junit.Assert.assertTrue(i29 == 3);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str30.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada31);
        org.junit.Assert.assertNotNull(coordenada38);
        org.junit.Assert.assertNotNull(coordenada40);
        org.junit.Assert.assertNotNull(mota43);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        java.lang.String str2 = mota0.toString();
        mota0.setFiabilidade(0);
        Mota mota5 = mota0.clone();
        Mota mota6 = new Mota();
        Mota mota7 = new Mota(mota6);
        Mota mota8 = new Mota(mota7);
        Mota mota9 = new Mota();
        Mota mota10 = new Mota(mota9);
        int i11 = mota7.compareTo((Veiculo) mota9);
        Mota mota12 = new Mota();
        mota12.setMatricula("");
        boolean b16 = mota12.equals((java.lang.Object) (-1.0d));
        boolean b17 = mota7.equals((java.lang.Object) (-1.0d));
        Mota mota18 = new Mota();
        mota18.setMatricula("");
        Mota mota21 = mota18.clone();
        mota18.setPrecoBase((double) 0L);
        Mota mota24 = new Mota();
        int i25 = mota24.getLugares();
        int i26 = mota18.compareTo((Veiculo) mota24);
        java.lang.String str27 = mota24.toString();
        Coordenada coordenada28 = mota24.getCoordenadas();
        mota7.setCoordenadas(coordenada28);
        mota0.setCoordenadas(coordenada28);
        mota0.setPrecoBase(100.0d);
        double d33 = mota0.getPrecoBase();
        java.lang.String str34 = mota0.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(mota5);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(b16 == false);
        org.junit.Assert.assertTrue(b17 == false);
        org.junit.Assert.assertNotNull(mota21);
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue(i26 == 3);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str27.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada28);
        org.junit.Assert.assertTrue(d33 == 100.0d);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 100.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str34.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 100.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        java.lang.String str9 = mota6.toString();
        int i10 = mota6.getFiabilidade();
        mota6.setPrecoBase(10.0d);
        int i13 = mota6.getVelocidadeMedia();
        Mota mota14 = new Mota(mota6);
        mota6.setVelocidadeMedia(1);
        int i17 = mota6.getLugares();
        mota6.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n");
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(i17 == 0);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        Mota mota4 = new Mota();
        mota4.setMatricula("");
        Mota mota7 = mota4.clone();
        mota4.setPrecoBase((double) 0L);
        Mota mota10 = new Mota();
        int i11 = mota10.getLugares();
        int i12 = mota4.compareTo((Veiculo) mota10);
        java.lang.String str13 = mota10.toString();
        int i14 = mota10.getFiabilidade();
        mota10.setPrecoBase(10.0d);
        Mota mota17 = mota10.clone();
        int i18 = mota10.getFiabilidade();
        Coordenada coordenada19 = mota10.getCoordenadas();
        Mota mota21 = new Mota(10, (double) ' ', (int) (short) 100, "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 1\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada19, false);
        org.junit.Assert.assertNotNull(mota7);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(i12 == 3);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str13.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertNotNull(mota17);
        org.junit.Assert.assertTrue(i18 == 0);
        org.junit.Assert.assertNotNull(coordenada19);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        Mota mota0 = new Mota();
        mota0.setVelocidadeMedia((int) ' ');
        java.lang.String str3 = mota0.toString();
        Mota mota8 = new Mota();
        mota8.setMatricula("");
        Mota mota11 = mota8.clone();
        Coordenada coordenada12 = mota11.getCoordenadas();
        Mota mota14 = new Mota((int) (byte) 0, (double) 'a', 3, "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada12, false);
        boolean b15 = mota0.equals((java.lang.Object) 'a');
        mota0.setVelocidadeMedia((int) (byte) 100);
        mota0.setOcupado(true);
        int i20 = mota0.getFiabilidade();
        boolean b21 = mota0.getOcupado();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(mota11);
        org.junit.Assert.assertNotNull(coordenada12);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertTrue(i20 == 0);
        org.junit.Assert.assertTrue(b21 == true);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        java.lang.String str9 = mota6.toString();
        Coordenada coordenada10 = mota6.getCoordenadas();
        mota6.setMatricula("hi!");
        mota6.setOcupado(false);
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada10);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Mota mota5 = new Mota(mota0);
        double d6 = mota0.getPrecoBase();
        boolean b7 = mota0.getOcupado();
        int i8 = mota0.getVelocidadeMedia();
        Mota mota9 = mota0.clone();
        int i10 = mota9.getFiabilidade();
        int i11 = mota9.getLugares();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(b7 == false);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertNotNull(mota9);
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i11 == 0);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        Mota mota4 = new Mota(mota3);
        int i5 = mota1.compareTo((Veiculo) mota3);
        java.lang.String str6 = mota3.getMatricula();
        int i7 = mota3.getLugares();
        Mota mota8 = new Mota();
        mota8.setMatricula("");
        boolean b12 = mota8.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada13 = mota8.getCoordenadas();
        mota8.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        boolean b16 = mota3.equals((java.lang.Object) mota8);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "n/a" + "'", str6.equals("n/a"));
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertNotNull(coordenada13);
        org.junit.Assert.assertTrue(b16 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        Mota mota4 = new Mota();
        Mota mota5 = new Mota(mota4);
        Mota mota6 = new Mota(mota5);
        Mota mota7 = new Mota();
        Mota mota8 = new Mota(mota7);
        int i9 = mota5.compareTo((Veiculo) mota7);
        Mota mota10 = new Mota();
        mota10.setMatricula("");
        boolean b14 = mota10.equals((java.lang.Object) (-1.0d));
        boolean b15 = mota5.equals((java.lang.Object) (-1.0d));
        Mota mota16 = new Mota();
        mota16.setMatricula("");
        Mota mota19 = mota16.clone();
        mota16.setPrecoBase((double) 0L);
        Mota mota22 = new Mota();
        int i23 = mota22.getLugares();
        int i24 = mota16.compareTo((Veiculo) mota22);
        java.lang.String str25 = mota22.toString();
        Coordenada coordenada26 = mota22.getCoordenadas();
        mota5.setCoordenadas(coordenada26);
        Mota mota29 = new Mota((int) (short) -1, (double) (byte) 10, (int) 'a', "Matrícula: Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada26, false);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertNotNull(mota19);
        org.junit.Assert.assertTrue(i23 == 0);
        org.junit.Assert.assertTrue(i24 == 3);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str25.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada26);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        boolean b4 = mota0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = mota0.getCoordenadas();
        java.lang.String str6 = mota0.getMatricula();
        Mota mota7 = new Mota(mota0);
        int i8 = mota0.getVelocidadeMedia();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue(i8 == 0);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        Mota mota4 = new Mota();
        int i5 = mota4.getLugares();
        mota4.setVelocidadeMedia(10);
        Mota mota8 = new Mota(mota4);
        Mota mota9 = new Mota(mota8);
        Mota mota10 = new Mota();
        mota10.setMatricula("");
        Mota mota13 = mota10.clone();
        int i14 = mota13.getFiabilidade();
        Coordenada coordenada15 = mota13.getCoordenadas();
        mota9.setCoordenadas(coordenada15);
        Mota mota18 = new Mota(100, (double) (byte) 1, 27, "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 1\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada15, true);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertNotNull(mota13);
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertNotNull(coordenada15);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        Mota mota4 = new Mota(mota0);
        int i5 = mota0.getVelocidadeMedia();
        mota0.setMatricula("");
        int i8 = mota0.getLugares();
        Mota mota9 = new Mota();
        mota9.setMatricula("");
        Mota mota12 = mota9.clone();
        mota12.setOcupado(true);
        mota12.setFiabilidade(0);
        mota12.setMatricula("Matrícula: Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        boolean b19 = mota0.equals((java.lang.Object) "Matrícula: Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Mota mota20 = mota0.clone();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i5 == 10);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertNotNull(mota12);
        org.junit.Assert.assertTrue(b19 == false);
        org.junit.Assert.assertNotNull(mota20);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        Mota mota4 = new Mota(mota3);
        int i5 = mota1.compareTo((Veiculo) mota3);
        Mota mota6 = new Mota();
        mota6.setMatricula("");
        boolean b10 = mota6.equals((java.lang.Object) (-1.0d));
        boolean b11 = mota1.equals((java.lang.Object) (-1.0d));
        Mota mota12 = new Mota(mota1);
        java.lang.String str13 = mota1.getMatricula();
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "n/a" + "'", str13.equals("n/a"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        Mota mota4 = new Mota();
        mota4.setMatricula("");
        Mota mota7 = mota4.clone();
        mota4.setPrecoBase((double) 0L);
        Mota mota10 = new Mota(mota4);
        int i11 = mota4.getLugares();
        Mota mota12 = new Mota();
        int i13 = mota12.getLugares();
        mota12.setVelocidadeMedia(10);
        mota12.setMatricula("n/a");
        mota12.setPrecoBase((double) 1L);
        Coordenada coordenada20 = mota12.getCoordenadas();
        mota4.setCoordenadas(coordenada20);
        Mota mota23 = new Mota((int) (short) 1, (double) '4', (int) (byte) 100, "Matrícula: Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: -1km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada20, true);
        org.junit.Assert.assertNotNull(mota7);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertNotNull(coordenada20);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        mota0.setMatricula("n/a");
        Mota mota6 = new Mota();
        mota6.setMatricula("");
        Mota mota9 = mota6.clone();
        mota6.setPrecoBase((double) 0L);
        Mota mota12 = new Mota();
        int i13 = mota12.getLugares();
        int i14 = mota6.compareTo((Veiculo) mota12);
        java.lang.String str15 = mota12.toString();
        Coordenada coordenada16 = mota12.getCoordenadas();
        Mota mota17 = new Mota();
        int i18 = mota17.getLugares();
        Coordenada coordenada19 = mota17.getCoordenadas();
        mota12.setCoordenadas(coordenada19);
        mota0.setCoordenadas(coordenada19);
        Mota mota22 = new Mota();
        mota22.setMatricula("");
        boolean b26 = mota22.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada27 = mota22.getCoordenadas();
        mota0.setCoordenadas(coordenada27);
        Mota mota29 = mota0.clone();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(mota9);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(i14 == 3);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str15.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada16);
        org.junit.Assert.assertTrue(i18 == 0);
        org.junit.Assert.assertNotNull(coordenada19);
        org.junit.Assert.assertTrue(b26 == false);
        org.junit.Assert.assertNotNull(coordenada27);
        org.junit.Assert.assertNotNull(mota29);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        Mota mota4 = new Mota(mota0);
        int i5 = mota0.getVelocidadeMedia();
        java.lang.String str6 = mota0.getMatricula();
        mota0.setFiabilidade((int) ' ');
        Mota mota9 = new Mota();
        mota9.setMatricula("");
        boolean b13 = mota9.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada14 = mota9.getCoordenadas();
        mota9.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        mota9.setFiabilidade(0);
        Mota mota19 = new Mota();
        mota19.setMatricula("");
        Mota mota22 = mota19.clone();
        mota19.setPrecoBase((double) 0L);
        Mota mota25 = new Mota(mota19);
        int i26 = mota9.compareTo((Veiculo) mota19);
        Mota mota27 = new Mota(mota19);
        mota27.setOcupado(false);
        java.lang.String str30 = mota27.getMatricula();
        Mota mota31 = new Mota(mota27);
        boolean b32 = mota0.equals((java.lang.Object) mota27);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i5 == 10);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "n/a" + "'", str6.equals("n/a"));
        org.junit.Assert.assertTrue(b13 == false);
        org.junit.Assert.assertNotNull(coordenada14);
        org.junit.Assert.assertNotNull(mota22);
        org.junit.Assert.assertTrue(i26 == (-142));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "" + "'", str30.equals(""));
        org.junit.Assert.assertTrue(b32 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        Mota mota4 = new Mota(mota0);
        int i5 = mota0.getVelocidadeMedia();
        java.lang.String str6 = mota0.getMatricula();
        mota0.setVelocidadeMedia((int) (byte) 1);
        double d9 = mota0.getPrecoBase();
        double d10 = mota0.getPrecoBase();
        Mota mota11 = mota0.clone();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i5 == 10);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "n/a" + "'", str6.equals("n/a"));
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue(d10 == 0.0d);
        org.junit.Assert.assertNotNull(mota11);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        Mota mota4 = new Mota();
        mota4.setVelocidadeMedia((int) ' ');
        java.lang.String str7 = mota4.toString();
        int i8 = mota4.getVelocidadeMedia();
        boolean b9 = mota4.getOcupado();
        java.lang.String str10 = mota4.toString();
        Mota mota11 = new Mota();
        mota11.setMatricula("");
        boolean b15 = mota11.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada16 = mota11.getCoordenadas();
        java.lang.String str17 = mota11.toString();
        double d18 = mota11.getPrecoBase();
        mota11.setFiabilidade((int) ' ');
        int i21 = mota4.compareTo((Veiculo) mota11);
        Coordenada coordenada22 = mota4.getCoordenadas();
        Mota mota24 = new Mota((int) (short) 0, (double) (-33), 1, "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 1\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada22, false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str7.equals("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i8 == 32);
        org.junit.Assert.assertTrue(b9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str10.equals("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertNotNull(coordenada16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str17.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(d18 == 0.0d);
        org.junit.Assert.assertTrue(i21 == (-3));
        org.junit.Assert.assertNotNull(coordenada22);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        java.lang.String str2 = mota0.getMatricula();
        Mota mota3 = new Mota(mota0);
        Mota mota4 = new Mota(mota3);
        Mota mota5 = new Mota();
        int i6 = mota5.getLugares();
        java.lang.String str7 = mota5.getMatricula();
        mota5.setVelocidadeMedia((-1));
        double d10 = mota5.getPrecoBase();
        boolean b11 = mota3.equals((java.lang.Object) mota5);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "n/a" + "'", str2.equals("n/a"));
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "n/a" + "'", str7.equals("n/a"));
        org.junit.Assert.assertTrue(d10 == 0.0d);
        org.junit.Assert.assertTrue(b11 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        int i9 = mota6.getFiabilidade();
        Mota mota10 = new Mota(mota6);
        int i11 = mota10.getLugares();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertTrue(i11 == 0);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        Mota mota0 = new Mota();
        Mota mota1 = new Mota(mota0);
        Mota mota2 = new Mota(mota1);
        Mota mota3 = new Mota();
        Mota mota4 = new Mota(mota3);
        int i5 = mota1.compareTo((Veiculo) mota3);
        mota3.setMatricula("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        int i8 = mota3.getFiabilidade();
        Mota mota9 = mota3.clone();
        Coordenada coordenada10 = mota9.getCoordenadas();
        mota9.setVelocidadeMedia((-3));
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertNotNull(mota9);
        org.junit.Assert.assertNotNull(coordenada10);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        java.lang.String str9 = mota6.toString();
        Coordenada coordenada10 = mota6.getCoordenadas();
        java.lang.String str11 = mota6.toString();
        mota6.setFiabilidade((int) (short) 100);
        boolean b14 = mota6.getOcupado();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str11.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(b14 == false);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        Mota mota4 = new Mota();
        mota4.setMatricula("");
        Mota mota7 = mota4.clone();
        mota4.setPrecoBase((double) 0L);
        Mota mota10 = new Mota();
        int i11 = mota10.getLugares();
        int i12 = mota4.compareTo((Veiculo) mota10);
        java.lang.String str13 = mota10.toString();
        Coordenada coordenada14 = mota10.getCoordenadas();
        Mota mota16 = new Mota((int) (byte) 100, (double) '#', (int) (short) 0, "", coordenada14, false);
        java.lang.Object obj17 = null;
        boolean b18 = mota16.equals(obj17);
        int i19 = mota16.getFiabilidade();
        org.junit.Assert.assertNotNull(mota7);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(i12 == 3);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str13.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada14);
        org.junit.Assert.assertTrue(b18 == false);
        org.junit.Assert.assertTrue(i19 == 0);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        java.lang.String str3 = mota0.toString();
        Mota mota4 = mota0.clone();
        Mota mota5 = new Mota();
        int i6 = mota5.getLugares();
        mota5.setVelocidadeMedia(10);
        Mota mota9 = new Mota(mota5);
        java.lang.String str10 = mota5.toString();
        boolean b11 = mota0.equals((java.lang.Object) str10);
        mota0.setVelocidadeMedia((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(mota4);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str10.equals("Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(b11 == false);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        Mota mota4 = new Mota();
        mota4.setMatricula("");
        boolean b8 = mota4.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada9 = mota4.getCoordenadas();
        mota4.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        mota4.setFiabilidade(0);
        Mota mota14 = new Mota();
        mota14.setMatricula("");
        Mota mota17 = mota14.clone();
        mota14.setPrecoBase((double) 0L);
        Mota mota20 = new Mota(mota14);
        int i21 = mota4.compareTo((Veiculo) mota14);
        Mota mota22 = new Mota(mota14);
        Coordenada coordenada23 = mota22.getCoordenadas();
        Mota mota25 = new Mota((int) (byte) 0, (double) 0L, (int) (byte) 0, "n/a", coordenada23, true);
        int i26 = mota25.getFiabilidade();
        int i27 = mota25.getFiabilidade();
        org.junit.Assert.assertTrue(b8 == false);
        org.junit.Assert.assertNotNull(coordenada9);
        org.junit.Assert.assertNotNull(mota17);
        org.junit.Assert.assertTrue(i21 == (-142));
        org.junit.Assert.assertNotNull(coordenada23);
        org.junit.Assert.assertTrue(i26 == 0);
        org.junit.Assert.assertTrue(i27 == 0);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota0.setPrecoBase((double) 0L);
        Mota mota6 = new Mota();
        int i7 = mota6.getLugares();
        int i8 = mota0.compareTo((Veiculo) mota6);
        java.lang.String str9 = mota6.toString();
        Coordenada coordenada10 = mota6.getCoordenadas();
        Mota mota11 = new Mota();
        int i12 = mota11.getLugares();
        Coordenada coordenada13 = mota11.getCoordenadas();
        mota6.setCoordenadas(coordenada13);
        Mota mota15 = new Mota(mota6);
        Mota mota16 = new Mota(mota6);
        mota16.setOcupado(false);
        mota16.setFiabilidade(1);
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertNotNull(coordenada13);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        Mota mota0 = new Mota();
        int i1 = mota0.getLugares();
        mota0.setVelocidadeMedia(10);
        Mota mota4 = new Mota(mota0);
        Mota mota5 = mota4.clone();
        Mota mota6 = mota4.clone();
        Mota mota7 = new Mota(mota6);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(mota5);
        org.junit.Assert.assertNotNull(mota6);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        Mota mota0 = new Mota();
        mota0.setMatricula("");
        Mota mota3 = mota0.clone();
        mota3.setOcupado(true);
        int i6 = mota3.getFiabilidade();
        int i7 = mota3.getLugares();
        org.junit.Assert.assertNotNull(mota3);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertTrue(i7 == 0);
    }
}

