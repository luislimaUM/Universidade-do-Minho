import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        Coordenada coordenada4 = null;
        try {
            Carrinha carrinha6 = new Carrinha((int) (short) -1, (double) (short) 100, (int) '4', "hi!", coordenada4, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        Coordenada coordenada4 = null;
        try {
            Carrinha carrinha6 = new Carrinha(1, 100.0d, (int) (byte) 0, "hi!", coordenada4, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        Coordenada coordenada4 = null;
        try {
            Carrinha carrinha6 = new Carrinha((int) 'a', (double) 10, 100, "hi!", coordenada4, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        Coordenada coordenada4 = null;
        try {
            Carrinha carrinha6 = new Carrinha(0, (double) 100, 100, "", coordenada4, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        Coordenada coordenada4 = null;
        try {
            Carrinha carrinha6 = new Carrinha((int) (byte) -1, (double) 1.0f, 10, "", coordenada4, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Coordenada coordenada3 = null;
        try {
            carrinha2.setCoordenadas(coordenada3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        Carrinha carrinha4 = new Carrinha();
        carrinha4.setMatricula("");
        Carrinha carrinha7 = carrinha4.clone();
        Coordenada coordenada8 = carrinha7.getCoordenadas();
        Carrinha carrinha10 = new Carrinha((int) (byte) 0, (double) 'a', 3, "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada8, false);
        java.lang.Object obj11 = null;
        boolean b12 = carrinha10.equals(obj11);
        org.junit.Assert.assertNotNull(carrinha7);
        org.junit.Assert.assertNotNull(coordenada8);
        org.junit.Assert.assertTrue(b12 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        carrinha0.setFiabilidade((int) (byte) 0);
        Veiculo veiculo6 = null;
        try {
            int i7 = carrinha0.compareTo(veiculo6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        int i4 = carrinha3.getLugares();
        boolean b5 = carrinha2.equals((java.lang.Object) carrinha3);
        carrinha3.setOcupado(true);
        boolean b8 = carrinha3.getOcupado();
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue(b5 == true);
        org.junit.Assert.assertTrue(b8 == true);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        carrinha0.setPrecoBase((double) (byte) 10);
        java.lang.String str4 = carrinha0.getMatricula();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "n/a" + "'", str4.equals("n/a"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha(carrinha0);
        carrinha6.setPrecoBase((double) (-1.0f));
        carrinha6.setVelocidadeMedia((int) (short) 0);
        carrinha6.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        java.lang.String str13 = carrinha6.getMatricula();
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str13.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        carrinha0.setOcupado(false);
        carrinha0.setMatricula("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        Carrinha carrinha0 = new Carrinha();
        java.lang.String str1 = carrinha0.toString();
        int i2 = carrinha0.getFiabilidade();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str1.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha5 = new Carrinha(carrinha0);
        double d6 = carrinha0.getPrecoBase();
        boolean b7 = carrinha0.getOcupado();
        int i8 = carrinha0.getVelocidadeMedia();
        Carrinha carrinha9 = carrinha0.clone();
        int i10 = carrinha0.getLugares();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(b7 == false);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertNotNull(carrinha9);
        org.junit.Assert.assertTrue(i10 == 0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        Coordenada coordenada4 = null;
        try {
            Carrinha carrinha6 = new Carrinha(3, (-1.0d), (int) (short) -1, "", coordenada4, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        java.lang.String str2 = carrinha0.toString();
        carrinha0.setFiabilidade(0);
        Carrinha carrinha5 = carrinha0.clone();
        Carrinha carrinha6 = new Carrinha();
        Carrinha carrinha7 = new Carrinha(carrinha6);
        Carrinha carrinha8 = new Carrinha(carrinha7);
        Carrinha carrinha9 = new Carrinha();
        Carrinha carrinha10 = new Carrinha(carrinha9);
        int i11 = carrinha7.compareTo((Veiculo) carrinha9);
        Carrinha carrinha12 = new Carrinha();
        carrinha12.setMatricula("");
        boolean b16 = carrinha12.equals((java.lang.Object) (-1.0d));
        boolean b17 = carrinha7.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha18 = new Carrinha();
        carrinha18.setMatricula("");
        Carrinha carrinha21 = carrinha18.clone();
        carrinha18.setPrecoBase((double) 0L);
        Carrinha carrinha24 = new Carrinha();
        int i25 = carrinha24.getLugares();
        int i26 = carrinha18.compareTo((Veiculo) carrinha24);
        java.lang.String str27 = carrinha24.toString();
        Coordenada coordenada28 = carrinha24.getCoordenadas();
        carrinha7.setCoordenadas(coordenada28);
        carrinha0.setCoordenadas(coordenada28);
        carrinha0.setMatricula("hi!");
        carrinha0.setOcupado(true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha5);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(b16 == false);
        org.junit.Assert.assertTrue(b17 == false);
        org.junit.Assert.assertNotNull(carrinha21);
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue(i26 == 3);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str27.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada28);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        Coordenada coordenada4 = carrinha3.getCoordenadas();
        Carrinha carrinha5 = new Carrinha();
        carrinha5.setMatricula("");
        Carrinha carrinha8 = carrinha5.clone();
        carrinha5.setPrecoBase((double) 0L);
        Carrinha carrinha11 = new Carrinha();
        int i12 = carrinha11.getLugares();
        int i13 = carrinha5.compareTo((Veiculo) carrinha11);
        java.lang.String str14 = carrinha11.toString();
        Coordenada coordenada15 = carrinha11.getCoordenadas();
        int i16 = carrinha3.compareTo((Veiculo) carrinha11);
        java.lang.String str17 = carrinha3.getMatricula();
        carrinha3.setMatricula("");
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertNotNull(coordenada4);
        org.junit.Assert.assertNotNull(carrinha8);
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertTrue(i13 == 3);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str14.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada15);
        org.junit.Assert.assertTrue(i16 == 3);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        Carrinha carrinha0 = new Carrinha();
        java.lang.String str1 = carrinha0.toString();
        double d2 = carrinha0.getPrecoBase();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str1.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(d2 == 0.0d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        java.lang.String str2 = carrinha0.getMatricula();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "n/a" + "'", str2.equals("n/a"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        java.lang.String str2 = carrinha0.toString();
        carrinha0.setFiabilidade(0);
        Carrinha carrinha5 = carrinha0.clone();
        Carrinha carrinha6 = new Carrinha();
        Carrinha carrinha7 = new Carrinha(carrinha6);
        Carrinha carrinha8 = new Carrinha(carrinha7);
        Carrinha carrinha9 = new Carrinha();
        Carrinha carrinha10 = new Carrinha(carrinha9);
        int i11 = carrinha7.compareTo((Veiculo) carrinha9);
        Carrinha carrinha12 = new Carrinha();
        carrinha12.setMatricula("");
        boolean b16 = carrinha12.equals((java.lang.Object) (-1.0d));
        boolean b17 = carrinha7.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha18 = new Carrinha();
        carrinha18.setMatricula("");
        Carrinha carrinha21 = carrinha18.clone();
        carrinha18.setPrecoBase((double) 0L);
        Carrinha carrinha24 = new Carrinha();
        int i25 = carrinha24.getLugares();
        int i26 = carrinha18.compareTo((Veiculo) carrinha24);
        java.lang.String str27 = carrinha24.toString();
        Coordenada coordenada28 = carrinha24.getCoordenadas();
        carrinha7.setCoordenadas(coordenada28);
        carrinha0.setCoordenadas(coordenada28);
        carrinha0.setPrecoBase(100.0d);
        double d33 = carrinha0.getPrecoBase();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha5);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(b16 == false);
        org.junit.Assert.assertTrue(b17 == false);
        org.junit.Assert.assertNotNull(carrinha21);
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue(i26 == 3);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str27.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada28);
        org.junit.Assert.assertTrue(d33 == 100.0d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        Carrinha carrinha4 = new Carrinha(carrinha0);
        java.lang.String str5 = carrinha4.toString();
        carrinha4.setFiabilidade(3);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str5.equals("Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        Coordenada coordenada4 = carrinha3.getCoordenadas();
        Carrinha carrinha5 = new Carrinha();
        carrinha5.setMatricula("");
        Carrinha carrinha8 = carrinha5.clone();
        carrinha5.setPrecoBase((double) 0L);
        Carrinha carrinha11 = new Carrinha();
        int i12 = carrinha11.getLugares();
        int i13 = carrinha5.compareTo((Veiculo) carrinha11);
        java.lang.String str14 = carrinha11.toString();
        Coordenada coordenada15 = carrinha11.getCoordenadas();
        int i16 = carrinha3.compareTo((Veiculo) carrinha11);
        Carrinha carrinha17 = new Carrinha();
        Carrinha carrinha18 = new Carrinha(carrinha17);
        java.lang.String str19 = carrinha17.toString();
        carrinha17.setFiabilidade(0);
        Carrinha carrinha22 = carrinha17.clone();
        int i23 = carrinha17.getLugares();
        Carrinha carrinha28 = new Carrinha();
        Carrinha carrinha29 = new Carrinha(carrinha28);
        Carrinha carrinha30 = new Carrinha(carrinha29);
        Carrinha carrinha31 = new Carrinha();
        Carrinha carrinha32 = new Carrinha(carrinha31);
        int i33 = carrinha29.compareTo((Veiculo) carrinha31);
        Carrinha carrinha34 = new Carrinha();
        carrinha34.setMatricula("");
        boolean b38 = carrinha34.equals((java.lang.Object) (-1.0d));
        boolean b39 = carrinha29.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha40 = new Carrinha();
        carrinha40.setMatricula("");
        Carrinha carrinha43 = carrinha40.clone();
        carrinha40.setPrecoBase((double) 0L);
        Carrinha carrinha46 = new Carrinha();
        int i47 = carrinha46.getLugares();
        int i48 = carrinha40.compareTo((Veiculo) carrinha46);
        java.lang.String str49 = carrinha46.toString();
        Coordenada coordenada50 = carrinha46.getCoordenadas();
        carrinha29.setCoordenadas(coordenada50);
        Carrinha carrinha53 = new Carrinha((-1), 10.0d, (int) (byte) 1, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada50, true);
        carrinha17.setCoordenadas(coordenada50);
        carrinha11.setCoordenadas(coordenada50);
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertNotNull(coordenada4);
        org.junit.Assert.assertNotNull(carrinha8);
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertTrue(i13 == 3);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str14.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada15);
        org.junit.Assert.assertTrue(i16 == 3);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str19.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha22);
        org.junit.Assert.assertTrue(i23 == 0);
        org.junit.Assert.assertTrue(i33 == 0);
        org.junit.Assert.assertTrue(b38 == false);
        org.junit.Assert.assertTrue(b39 == false);
        org.junit.Assert.assertNotNull(carrinha43);
        org.junit.Assert.assertTrue(i47 == 0);
        org.junit.Assert.assertTrue(i48 == 3);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str49.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada50);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        java.lang.String str9 = carrinha6.toString();
        Coordenada coordenada10 = carrinha6.getCoordenadas();
        Carrinha carrinha11 = new Carrinha();
        int i12 = carrinha11.getLugares();
        Coordenada coordenada13 = carrinha11.getCoordenadas();
        carrinha6.setCoordenadas(coordenada13);
        Carrinha carrinha15 = new Carrinha(carrinha6);
        java.lang.String str16 = carrinha15.toString();
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertNotNull(coordenada13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str16.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        java.lang.String str2 = carrinha0.toString();
        carrinha0.setFiabilidade(0);
        Carrinha carrinha5 = carrinha0.clone();
        carrinha0.setFiabilidade((int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha5);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        Carrinha carrinha0 = null;
        try {
            Carrinha carrinha1 = new Carrinha(carrinha0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        int i3 = carrinha2.getLugares();
        org.junit.Assert.assertTrue(i3 == 0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        Carrinha carrinha4 = new Carrinha();
        Carrinha carrinha5 = new Carrinha(carrinha4);
        Carrinha carrinha6 = new Carrinha(carrinha5);
        Carrinha carrinha7 = new Carrinha();
        Carrinha carrinha8 = new Carrinha(carrinha7);
        int i9 = carrinha5.compareTo((Veiculo) carrinha7);
        Carrinha carrinha10 = new Carrinha();
        carrinha10.setMatricula("");
        boolean b14 = carrinha10.equals((java.lang.Object) (-1.0d));
        boolean b15 = carrinha5.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha16 = new Carrinha();
        carrinha16.setMatricula("");
        Carrinha carrinha19 = carrinha16.clone();
        carrinha16.setPrecoBase((double) 0L);
        Carrinha carrinha22 = new Carrinha();
        int i23 = carrinha22.getLugares();
        int i24 = carrinha16.compareTo((Veiculo) carrinha22);
        java.lang.String str25 = carrinha22.toString();
        Coordenada coordenada26 = carrinha22.getCoordenadas();
        carrinha5.setCoordenadas(coordenada26);
        Carrinha carrinha29 = new Carrinha((-1), 10.0d, (int) (byte) 1, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada26, true);
        Veiculo veiculo30 = null;
        try {
            int i31 = carrinha29.compareTo(veiculo30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertNotNull(carrinha19);
        org.junit.Assert.assertTrue(i23 == 0);
        org.junit.Assert.assertTrue(i24 == 3);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str25.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada26);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        java.lang.String str2 = carrinha0.toString();
        carrinha0.setFiabilidade(0);
        Carrinha carrinha5 = carrinha0.clone();
        Carrinha carrinha6 = new Carrinha(carrinha0);
        Carrinha carrinha7 = new Carrinha();
        carrinha7.setMatricula("");
        Carrinha carrinha10 = carrinha7.clone();
        Coordenada coordenada11 = carrinha10.getCoordenadas();
        carrinha6.setCoordenadas(coordenada11);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha5);
        org.junit.Assert.assertNotNull(carrinha10);
        org.junit.Assert.assertNotNull(coordenada11);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        Carrinha carrinha4 = new Carrinha(carrinha3);
        int i5 = carrinha1.compareTo((Veiculo) carrinha3);
        Carrinha carrinha6 = new Carrinha(carrinha3);
        carrinha6.setOcupado(true);
        org.junit.Assert.assertTrue(i5 == 0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carrinha0.getCoordenadas();
        boolean b6 = carrinha0.getOcupado();
        java.lang.String str7 = carrinha0.getMatricula();
        int i8 = carrinha0.getFiabilidade();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(b6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        Carrinha carrinha4 = new Carrinha();
        carrinha4.setMatricula("");
        Carrinha carrinha7 = carrinha4.clone();
        carrinha4.setPrecoBase((double) 0L);
        Carrinha carrinha10 = new Carrinha();
        int i11 = carrinha10.getLugares();
        int i12 = carrinha4.compareTo((Veiculo) carrinha10);
        java.lang.String str13 = carrinha10.toString();
        Coordenada coordenada14 = carrinha10.getCoordenadas();
        Carrinha carrinha16 = new Carrinha(10, (double) (short) -1, (int) (byte) 1, "", coordenada14, false);
        int i17 = carrinha16.getLugares();
        org.junit.Assert.assertNotNull(carrinha7);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(i12 == 3);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str13.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada14);
        org.junit.Assert.assertTrue(i17 == 9);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        java.lang.String str2 = carrinha0.toString();
        carrinha0.setFiabilidade(0);
        Carrinha carrinha5 = carrinha0.clone();
        Carrinha carrinha6 = new Carrinha();
        Carrinha carrinha7 = new Carrinha(carrinha6);
        Carrinha carrinha8 = new Carrinha(carrinha7);
        Carrinha carrinha9 = new Carrinha();
        Carrinha carrinha10 = new Carrinha(carrinha9);
        int i11 = carrinha7.compareTo((Veiculo) carrinha9);
        Carrinha carrinha12 = new Carrinha();
        carrinha12.setMatricula("");
        boolean b16 = carrinha12.equals((java.lang.Object) (-1.0d));
        boolean b17 = carrinha7.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha18 = new Carrinha();
        carrinha18.setMatricula("");
        Carrinha carrinha21 = carrinha18.clone();
        carrinha18.setPrecoBase((double) 0L);
        Carrinha carrinha24 = new Carrinha();
        int i25 = carrinha24.getLugares();
        int i26 = carrinha18.compareTo((Veiculo) carrinha24);
        java.lang.String str27 = carrinha24.toString();
        Coordenada coordenada28 = carrinha24.getCoordenadas();
        carrinha7.setCoordenadas(coordenada28);
        carrinha0.setCoordenadas(coordenada28);
        carrinha0.setMatricula("hi!");
        boolean b33 = carrinha0.getOcupado();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha5);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(b16 == false);
        org.junit.Assert.assertTrue(b17 == false);
        org.junit.Assert.assertNotNull(carrinha21);
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue(i26 == 3);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str27.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada28);
        org.junit.Assert.assertTrue(b33 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        Carrinha carrinha4 = new Carrinha(carrinha0);
        Carrinha carrinha5 = carrinha4.clone();
        boolean b6 = carrinha4.getOcupado();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(carrinha5);
        org.junit.Assert.assertTrue(b6 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carrinha0.getCoordenadas();
        int i6 = carrinha0.getVelocidadeMedia();
        Carrinha carrinha7 = new Carrinha();
        carrinha7.setMatricula("");
        Carrinha carrinha10 = carrinha7.clone();
        carrinha10.setOcupado(true);
        boolean b13 = carrinha0.equals((java.lang.Object) carrinha10);
        carrinha10.setMatricula("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        boolean b16 = carrinha10.getOcupado();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertNotNull(carrinha10);
        org.junit.Assert.assertTrue(b13 == false);
        org.junit.Assert.assertTrue(b16 == true);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        Carrinha carrinha4 = new Carrinha(carrinha3);
        int i5 = carrinha1.compareTo((Veiculo) carrinha3);
        Carrinha carrinha6 = new Carrinha(carrinha3);
        int i7 = carrinha3.getFiabilidade();
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(i7 == 0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        Carrinha carrinha9 = new Carrinha(carrinha6);
        Carrinha carrinha10 = new Carrinha();
        Carrinha carrinha11 = new Carrinha(carrinha10);
        Carrinha carrinha12 = new Carrinha(carrinha11);
        Carrinha carrinha13 = new Carrinha();
        Carrinha carrinha14 = new Carrinha(carrinha13);
        int i15 = carrinha11.compareTo((Veiculo) carrinha13);
        int i16 = carrinha13.getVelocidadeMedia();
        int i17 = carrinha9.compareTo((Veiculo) carrinha13);
        int i18 = carrinha13.getLugares();
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue(i15 == 0);
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue(i17 == 0);
        org.junit.Assert.assertTrue(i18 == 0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carrinha0.getCoordenadas();
        java.lang.String str6 = carrinha0.getMatricula();
        Carrinha carrinha11 = new Carrinha();
        carrinha11.setMatricula("");
        Carrinha carrinha14 = carrinha11.clone();
        carrinha11.setPrecoBase((double) 0L);
        Carrinha carrinha17 = new Carrinha();
        int i18 = carrinha17.getLugares();
        int i19 = carrinha11.compareTo((Veiculo) carrinha17);
        java.lang.String str20 = carrinha17.toString();
        Coordenada coordenada21 = carrinha17.getCoordenadas();
        Carrinha carrinha23 = new Carrinha((int) (byte) -1, 0.0d, (int) 'a', "", coordenada21, true);
        int i24 = carrinha0.compareTo((Veiculo) carrinha23);
        int i25 = carrinha23.getLugares();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(carrinha14);
        org.junit.Assert.assertTrue(i18 == 0);
        org.junit.Assert.assertTrue(i19 == 3);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str20.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada21);
        org.junit.Assert.assertTrue(i24 == 0);
        org.junit.Assert.assertTrue(i25 == 9);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        carrinha0.setVelocidadeMedia((int) ' ');
        org.junit.Assert.assertNotNull(carrinha3);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        Carrinha carrinha4 = new Carrinha(carrinha3);
        int i5 = carrinha1.compareTo((Veiculo) carrinha3);
        int i6 = carrinha3.getVelocidadeMedia();
        Carrinha carrinha7 = carrinha3.clone();
        int i8 = carrinha7.getFiabilidade();
        int i9 = carrinha7.getFiabilidade();
        Carrinha carrinha10 = new Carrinha(carrinha7);
        carrinha10.setOcupado(false);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertNotNull(carrinha7);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue(i9 == 0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        int i4 = carrinha3.getLugares();
        boolean b5 = carrinha2.equals((java.lang.Object) carrinha3);
        boolean b6 = carrinha3.getOcupado();
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue(b5 == true);
        org.junit.Assert.assertTrue(b6 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha5 = new Carrinha(carrinha0);
        double d6 = carrinha0.getPrecoBase();
        carrinha0.setVelocidadeMedia((int) (byte) 100);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        Carrinha carrinha4 = new Carrinha(carrinha0);
        Carrinha carrinha5 = carrinha4.clone();
        int i6 = carrinha4.getLugares();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(carrinha5);
        org.junit.Assert.assertTrue(i6 == 0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        java.lang.String str9 = carrinha6.toString();
        int i10 = carrinha6.getFiabilidade();
        Carrinha carrinha11 = new Carrinha();
        Carrinha carrinha12 = new Carrinha(carrinha11);
        Carrinha carrinha13 = new Carrinha(carrinha12);
        Carrinha carrinha14 = new Carrinha();
        Carrinha carrinha15 = new Carrinha(carrinha14);
        int i16 = carrinha12.compareTo((Veiculo) carrinha14);
        Carrinha carrinha17 = new Carrinha();
        carrinha17.setMatricula("");
        boolean b21 = carrinha17.equals((java.lang.Object) (-1.0d));
        boolean b22 = carrinha12.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha23 = new Carrinha();
        carrinha23.setMatricula("");
        Carrinha carrinha26 = carrinha23.clone();
        carrinha23.setPrecoBase((double) 0L);
        Carrinha carrinha29 = new Carrinha();
        int i30 = carrinha29.getLugares();
        int i31 = carrinha23.compareTo((Veiculo) carrinha29);
        java.lang.String str32 = carrinha29.toString();
        Coordenada coordenada33 = carrinha29.getCoordenadas();
        carrinha12.setCoordenadas(coordenada33);
        boolean b35 = carrinha6.equals((java.lang.Object) carrinha12);
        int i36 = carrinha6.getLugares();
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue(b21 == false);
        org.junit.Assert.assertTrue(b22 == false);
        org.junit.Assert.assertNotNull(carrinha26);
        org.junit.Assert.assertTrue(i30 == 0);
        org.junit.Assert.assertTrue(i31 == 3);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str32.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada33);
        org.junit.Assert.assertTrue(b35 == true);
        org.junit.Assert.assertTrue(i36 == 0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carrinha0.getCoordenadas();
        carrinha0.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carrinha0.setFiabilidade(0);
        Carrinha carrinha10 = new Carrinha();
        carrinha10.setMatricula("");
        Carrinha carrinha13 = carrinha10.clone();
        carrinha10.setPrecoBase((double) 0L);
        Carrinha carrinha16 = new Carrinha(carrinha10);
        int i17 = carrinha0.compareTo((Veiculo) carrinha10);
        Carrinha carrinha18 = new Carrinha(carrinha10);
        Coordenada coordenada19 = carrinha10.getCoordenadas();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertNotNull(carrinha13);
        org.junit.Assert.assertTrue(i17 == (-142));
        org.junit.Assert.assertNotNull(coordenada19);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        java.lang.String str9 = carrinha6.toString();
        Coordenada coordenada10 = carrinha6.getCoordenadas();
        carrinha6.setFiabilidade((int) (byte) 1);
        Carrinha carrinha13 = new Carrinha();
        int i14 = carrinha13.getLugares();
        carrinha13.setVelocidadeMedia(10);
        Carrinha carrinha17 = carrinha13.clone();
        boolean b18 = carrinha6.equals((java.lang.Object) carrinha13);
        carrinha6.setOcupado(true);
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertNotNull(carrinha17);
        org.junit.Assert.assertTrue(b18 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        java.lang.String str2 = carrinha0.getMatricula();
        Carrinha carrinha3 = new Carrinha(carrinha0);
        Veiculo veiculo4 = null;
        try {
            int i5 = carrinha0.compareTo(veiculo4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "n/a" + "'", str2.equals("n/a"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        Carrinha carrinha8 = new Carrinha();
        carrinha8.setMatricula("");
        Carrinha carrinha11 = carrinha8.clone();
        carrinha8.setPrecoBase((double) 0L);
        Carrinha carrinha14 = new Carrinha();
        int i15 = carrinha14.getLugares();
        int i16 = carrinha8.compareTo((Veiculo) carrinha14);
        java.lang.String str17 = carrinha14.toString();
        Coordenada coordenada18 = carrinha14.getCoordenadas();
        Carrinha carrinha20 = new Carrinha((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, false);
        Carrinha carrinha22 = new Carrinha((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, true);
        int i23 = carrinha22.getVelocidadeMedia();
        org.junit.Assert.assertNotNull(carrinha11);
        org.junit.Assert.assertTrue(i15 == 0);
        org.junit.Assert.assertTrue(i16 == 3);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str17.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada18);
        org.junit.Assert.assertTrue(i23 == (-142));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        java.lang.String str9 = carrinha6.toString();
        Coordenada coordenada10 = carrinha6.getCoordenadas();
        carrinha6.setMatricula("hi!");
        carrinha6.setPrecoBase((double) (-1.0f));
        double d15 = carrinha6.getPrecoBase();
        carrinha6.setPrecoBase((double) 0);
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertTrue(d15 == (-1.0d));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        Coordenada coordenada2 = carrinha0.getCoordenadas();
        int i3 = carrinha0.getLugares();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(coordenada2);
        org.junit.Assert.assertTrue(i3 == 0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        int i4 = carrinha3.getLugares();
        boolean b5 = carrinha2.equals((java.lang.Object) carrinha3);
        carrinha3.setPrecoBase(0.0d);
        int i8 = carrinha3.getLugares();
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue(b5 == true);
        org.junit.Assert.assertTrue(i8 == 0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        java.lang.String str9 = carrinha6.toString();
        Coordenada coordenada10 = carrinha6.getCoordenadas();
        carrinha6.setFiabilidade((int) (byte) 1);
        int i13 = carrinha6.getFiabilidade();
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertTrue(i13 == 1);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        int i4 = carrinha3.getLugares();
        boolean b5 = carrinha2.equals((java.lang.Object) carrinha3);
        Carrinha carrinha6 = carrinha3.clone();
        carrinha6.setVelocidadeMedia((int) (short) 0);
        Carrinha carrinha9 = new Carrinha();
        Carrinha carrinha10 = new Carrinha(carrinha9);
        Carrinha carrinha11 = new Carrinha(carrinha10);
        Carrinha carrinha12 = new Carrinha();
        int i13 = carrinha12.getLugares();
        boolean b14 = carrinha11.equals((java.lang.Object) carrinha12);
        Carrinha carrinha15 = carrinha12.clone();
        carrinha15.setOcupado(true);
        boolean b18 = carrinha6.equals((java.lang.Object) carrinha15);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue(b5 == true);
        org.junit.Assert.assertNotNull(carrinha6);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(b14 == true);
        org.junit.Assert.assertNotNull(carrinha15);
        org.junit.Assert.assertTrue(b18 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha5 = new Carrinha(carrinha0);
        double d6 = carrinha0.getPrecoBase();
        java.lang.String str7 = carrinha0.toString();
        int i8 = carrinha0.getVelocidadeMedia();
        int i9 = carrinha0.getVelocidadeMedia();
        carrinha0.setMatricula("n/a");
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str7.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue(i9 == 0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha5 = new Carrinha(carrinha0);
        int i6 = carrinha5.getVelocidadeMedia();
        double d7 = carrinha5.getPrecoBase();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertTrue(d7 == 0.0d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        java.lang.String str2 = carrinha0.toString();
        carrinha0.setFiabilidade(0);
        Carrinha carrinha5 = carrinha0.clone();
        Carrinha carrinha6 = new Carrinha();
        Carrinha carrinha7 = new Carrinha(carrinha6);
        Carrinha carrinha8 = new Carrinha(carrinha7);
        Carrinha carrinha9 = new Carrinha();
        Carrinha carrinha10 = new Carrinha(carrinha9);
        int i11 = carrinha7.compareTo((Veiculo) carrinha9);
        Carrinha carrinha12 = new Carrinha();
        carrinha12.setMatricula("");
        boolean b16 = carrinha12.equals((java.lang.Object) (-1.0d));
        boolean b17 = carrinha7.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha18 = new Carrinha();
        carrinha18.setMatricula("");
        Carrinha carrinha21 = carrinha18.clone();
        carrinha18.setPrecoBase((double) 0L);
        Carrinha carrinha24 = new Carrinha();
        int i25 = carrinha24.getLugares();
        int i26 = carrinha18.compareTo((Veiculo) carrinha24);
        java.lang.String str27 = carrinha24.toString();
        Coordenada coordenada28 = carrinha24.getCoordenadas();
        carrinha7.setCoordenadas(coordenada28);
        carrinha0.setCoordenadas(coordenada28);
        carrinha0.setPrecoBase(100.0d);
        carrinha0.setMatricula("Matrícula: Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: -1.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        java.lang.String str35 = carrinha0.getMatricula();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha5);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(b16 == false);
        org.junit.Assert.assertTrue(b17 == false);
        org.junit.Assert.assertNotNull(carrinha21);
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue(i26 == 3);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str27.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada28);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Matrícula: Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: -1.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str35.equals("Matrícula: Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: -1.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha5 = new Carrinha(carrinha0);
        double d6 = carrinha0.getPrecoBase();
        boolean b7 = carrinha0.getOcupado();
        carrinha0.setVelocidadeMedia(10);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(b7 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        Carrinha carrinha4 = new Carrinha(carrinha3);
        int i5 = carrinha1.compareTo((Veiculo) carrinha3);
        Carrinha carrinha6 = new Carrinha();
        carrinha6.setMatricula("");
        boolean b10 = carrinha6.equals((java.lang.Object) (-1.0d));
        boolean b11 = carrinha1.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada12 = carrinha1.getCoordenadas();
        carrinha1.setPrecoBase((double) 1L);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertNotNull(coordenada12);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        java.lang.String str4 = carrinha0.getMatricula();
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        java.lang.String str9 = carrinha6.toString();
        Coordenada coordenada10 = carrinha6.getCoordenadas();
        carrinha6.setFiabilidade((int) (byte) 1);
        Carrinha carrinha13 = new Carrinha();
        int i14 = carrinha13.getLugares();
        carrinha13.setVelocidadeMedia(10);
        Carrinha carrinha17 = carrinha13.clone();
        boolean b18 = carrinha6.equals((java.lang.Object) carrinha13);
        carrinha6.setVelocidadeMedia((-1));
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertNotNull(carrinha17);
        org.junit.Assert.assertTrue(b18 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        Carrinha carrinha4 = new Carrinha(carrinha3);
        int i5 = carrinha1.compareTo((Veiculo) carrinha3);
        Carrinha carrinha6 = new Carrinha();
        carrinha6.setMatricula("");
        boolean b10 = carrinha6.equals((java.lang.Object) (-1.0d));
        boolean b11 = carrinha1.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha12 = new Carrinha();
        carrinha12.setMatricula("");
        Carrinha carrinha15 = carrinha12.clone();
        carrinha12.setPrecoBase((double) 0L);
        Carrinha carrinha18 = new Carrinha();
        int i19 = carrinha18.getLugares();
        int i20 = carrinha12.compareTo((Veiculo) carrinha18);
        java.lang.String str21 = carrinha18.toString();
        Coordenada coordenada22 = carrinha18.getCoordenadas();
        carrinha1.setCoordenadas(coordenada22);
        java.lang.String str24 = carrinha1.getMatricula();
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertNotNull(carrinha15);
        org.junit.Assert.assertTrue(i19 == 0);
        org.junit.Assert.assertTrue(i20 == 3);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str21.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "n/a" + "'", str24.equals("n/a"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        int i4 = carrinha3.getVelocidadeMedia();
        int i5 = carrinha3.getVelocidadeMedia();
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue(i5 == 0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha(carrinha0);
        int i7 = carrinha0.getFiabilidade();
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        java.lang.String str9 = carrinha6.toString();
        int i10 = carrinha6.getFiabilidade();
        Carrinha carrinha11 = new Carrinha();
        Carrinha carrinha12 = new Carrinha(carrinha11);
        Carrinha carrinha13 = new Carrinha(carrinha12);
        Carrinha carrinha14 = new Carrinha();
        Carrinha carrinha15 = new Carrinha(carrinha14);
        int i16 = carrinha12.compareTo((Veiculo) carrinha14);
        Carrinha carrinha17 = new Carrinha();
        carrinha17.setMatricula("");
        boolean b21 = carrinha17.equals((java.lang.Object) (-1.0d));
        boolean b22 = carrinha12.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha23 = new Carrinha();
        carrinha23.setMatricula("");
        Carrinha carrinha26 = carrinha23.clone();
        carrinha23.setPrecoBase((double) 0L);
        Carrinha carrinha29 = new Carrinha();
        int i30 = carrinha29.getLugares();
        int i31 = carrinha23.compareTo((Veiculo) carrinha29);
        java.lang.String str32 = carrinha29.toString();
        Coordenada coordenada33 = carrinha29.getCoordenadas();
        carrinha12.setCoordenadas(coordenada33);
        boolean b35 = carrinha6.equals((java.lang.Object) carrinha12);
        boolean b37 = carrinha6.equals((java.lang.Object) "n/a");
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue(b21 == false);
        org.junit.Assert.assertTrue(b22 == false);
        org.junit.Assert.assertNotNull(carrinha26);
        org.junit.Assert.assertTrue(i30 == 0);
        org.junit.Assert.assertTrue(i31 == 3);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str32.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada33);
        org.junit.Assert.assertTrue(b35 == true);
        org.junit.Assert.assertTrue(b37 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        java.lang.String str3 = carrinha0.toString();
        java.lang.Object obj4 = null;
        boolean b5 = carrinha0.equals(obj4);
        double d6 = carrinha0.getPrecoBase();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(b5 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        Carrinha carrinha4 = new Carrinha(carrinha3);
        int i5 = carrinha1.compareTo((Veiculo) carrinha3);
        int i6 = carrinha3.getVelocidadeMedia();
        Carrinha carrinha7 = carrinha3.clone();
        carrinha7.setVelocidadeMedia(32);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertNotNull(carrinha7);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        double d6 = carrinha0.getPrecoBase();
        carrinha0.setFiabilidade((int) ' ');
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(d6 == 0.0d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        Carrinha carrinha4 = carrinha0.clone();
        boolean b5 = carrinha0.getOcupado();
        int i6 = carrinha0.getVelocidadeMedia();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(carrinha4);
        org.junit.Assert.assertTrue(b5 == false);
        org.junit.Assert.assertTrue(i6 == 10);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setVelocidadeMedia((int) ' ');
        java.lang.String str3 = carrinha0.toString();
        Carrinha carrinha8 = new Carrinha();
        carrinha8.setMatricula("");
        Carrinha carrinha11 = carrinha8.clone();
        Coordenada coordenada12 = carrinha11.getCoordenadas();
        Carrinha carrinha14 = new Carrinha((int) (byte) 0, (double) 'a', 3, "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada12, false);
        boolean b15 = carrinha0.equals((java.lang.Object) 'a');
        carrinha0.setOcupado(false);
        double d18 = carrinha0.getPrecoBase();
        Carrinha carrinha19 = new Carrinha();
        carrinha19.setMatricula("");
        boolean b23 = carrinha19.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada24 = carrinha19.getCoordenadas();
        carrinha19.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Carrinha carrinha27 = new Carrinha(carrinha19);
        int i28 = carrinha0.compareTo((Veiculo) carrinha19);
        int i29 = carrinha19.getVelocidadeMedia();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha11);
        org.junit.Assert.assertNotNull(coordenada12);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertTrue(d18 == 0.0d);
        org.junit.Assert.assertTrue(b23 == false);
        org.junit.Assert.assertNotNull(coordenada24);
        org.junit.Assert.assertTrue(i28 == (-33));
        org.junit.Assert.assertTrue(i29 == 0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        Carrinha carrinha4 = new Carrinha(carrinha3);
        int i5 = carrinha1.compareTo((Veiculo) carrinha3);
        Carrinha carrinha6 = new Carrinha(carrinha3);
        carrinha3.setPrecoBase((double) (short) 1);
        org.junit.Assert.assertTrue(i5 == 0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        Carrinha carrinha4 = new Carrinha(carrinha0);
        int i5 = carrinha0.getVelocidadeMedia();
        Carrinha carrinha6 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i5 == 10);
        org.junit.Assert.assertNotNull(carrinha6);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        Carrinha carrinha12 = new Carrinha();
        carrinha12.setMatricula("");
        Carrinha carrinha15 = carrinha12.clone();
        carrinha12.setPrecoBase((double) 0L);
        Carrinha carrinha18 = new Carrinha();
        int i19 = carrinha18.getLugares();
        int i20 = carrinha12.compareTo((Veiculo) carrinha18);
        java.lang.String str21 = carrinha18.toString();
        Coordenada coordenada22 = carrinha18.getCoordenadas();
        Carrinha carrinha24 = new Carrinha((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada22, false);
        Carrinha carrinha26 = new Carrinha((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada22, true);
        Carrinha carrinha28 = new Carrinha((int) '#', 10.0d, (-1), "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada22, true);
        Coordenada coordenada29 = carrinha28.getCoordenadas();
        java.lang.String str30 = carrinha28.getMatricula();
        boolean b31 = carrinha28.getOcupado();
        org.junit.Assert.assertNotNull(carrinha15);
        org.junit.Assert.assertTrue(i19 == 0);
        org.junit.Assert.assertTrue(i20 == 3);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str21.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada22);
        org.junit.Assert.assertNotNull(coordenada29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str30.equals("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(b31 == true);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        int i4 = carrinha3.getVelocidadeMedia();
        Coordenada coordenada5 = carrinha3.getCoordenadas();
        Carrinha carrinha6 = new Carrinha();
        carrinha6.setMatricula("");
        Carrinha carrinha9 = carrinha6.clone();
        carrinha6.setPrecoBase((double) 0L);
        Carrinha carrinha12 = new Carrinha();
        int i13 = carrinha12.getLugares();
        int i14 = carrinha6.compareTo((Veiculo) carrinha12);
        java.lang.String str15 = carrinha12.toString();
        java.lang.String str16 = carrinha12.toString();
        boolean b17 = carrinha3.equals((java.lang.Object) str16);
        java.lang.String str18 = carrinha3.toString();
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertNotNull(carrinha9);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(i14 == 3);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str15.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str16.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(b17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str18.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        Carrinha carrinha4 = new Carrinha(carrinha3);
        int i5 = carrinha1.compareTo((Veiculo) carrinha3);
        Carrinha carrinha6 = new Carrinha();
        carrinha6.setMatricula("");
        boolean b10 = carrinha6.equals((java.lang.Object) (-1.0d));
        boolean b11 = carrinha1.equals((java.lang.Object) (-1.0d));
        boolean b12 = carrinha1.getOcupado();
        double d13 = carrinha1.getPrecoBase();
        Carrinha carrinha14 = new Carrinha();
        carrinha14.setMatricula("");
        Carrinha carrinha17 = carrinha14.clone();
        carrinha14.setPrecoBase((double) 0L);
        Carrinha carrinha20 = new Carrinha();
        int i21 = carrinha20.getLugares();
        int i22 = carrinha14.compareTo((Veiculo) carrinha20);
        Carrinha carrinha23 = new Carrinha(carrinha20);
        int i24 = carrinha23.getLugares();
        carrinha23.setPrecoBase((double) (-1));
        int i27 = carrinha1.compareTo((Veiculo) carrinha23);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertTrue(d13 == 0.0d);
        org.junit.Assert.assertNotNull(carrinha17);
        org.junit.Assert.assertTrue(i21 == 0);
        org.junit.Assert.assertTrue(i22 == 3);
        org.junit.Assert.assertTrue(i24 == 0);
        org.junit.Assert.assertTrue(i27 == 0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        int i4 = carrinha3.getVelocidadeMedia();
        java.lang.String str5 = carrinha3.toString();
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str5.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        Carrinha carrinha4 = new Carrinha(carrinha0);
        Carrinha carrinha5 = new Carrinha(carrinha4);
        int i6 = carrinha5.getLugares();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i6 == 0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carrinha0.getCoordenadas();
        carrinha0.setFiabilidade((int) ' ');
        int i8 = carrinha0.getLugares();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(i8 == 0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        Carrinha carrinha4 = new Carrinha(carrinha3);
        int i5 = carrinha1.compareTo((Veiculo) carrinha3);
        int i6 = carrinha3.getVelocidadeMedia();
        Carrinha carrinha7 = carrinha3.clone();
        int i8 = carrinha7.getFiabilidade();
        int i9 = carrinha7.getFiabilidade();
        carrinha7.setVelocidadeMedia(1);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertNotNull(carrinha7);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue(i9 == 0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        int i3 = carrinha0.getVelocidadeMedia();
        java.lang.String str4 = carrinha0.toString();
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str4.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        java.lang.String str9 = carrinha6.toString();
        int i10 = carrinha6.getFiabilidade();
        carrinha6.setPrecoBase(10.0d);
        int i13 = carrinha6.getVelocidadeMedia();
        Carrinha carrinha14 = new Carrinha(carrinha6);
        carrinha6.setVelocidadeMedia(1);
        int i17 = carrinha6.getLugares();
        double d18 = carrinha6.getPrecoBase();
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(i17 == 0);
        org.junit.Assert.assertTrue(d18 == 10.0d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = new Carrinha();
        int i4 = carrinha3.getLugares();
        java.lang.String str5 = carrinha3.getMatricula();
        Carrinha carrinha6 = new Carrinha(carrinha3);
        carrinha6.setVelocidadeMedia((int) '4');
        int i9 = carrinha0.compareTo((Veiculo) carrinha6);
        Carrinha carrinha10 = new Carrinha(carrinha6);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "n/a" + "'", str5.equals("n/a"));
        org.junit.Assert.assertTrue(i9 == 3);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        boolean b9 = carrinha6.getOcupado();
        carrinha6.setFiabilidade((-1));
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue(b9 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        Veiculo veiculo9 = null;
        try {
            int i10 = carrinha0.compareTo(veiculo9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        java.lang.String str2 = carrinha0.getMatricula();
        carrinha0.setMatricula("");
        Carrinha carrinha5 = new Carrinha();
        carrinha5.setVelocidadeMedia((int) ' ');
        java.lang.String str8 = carrinha5.toString();
        Carrinha carrinha13 = new Carrinha();
        carrinha13.setMatricula("");
        Carrinha carrinha16 = carrinha13.clone();
        Coordenada coordenada17 = carrinha16.getCoordenadas();
        Carrinha carrinha19 = new Carrinha((int) (byte) 0, (double) 'a', 3, "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada17, false);
        boolean b20 = carrinha5.equals((java.lang.Object) 'a');
        boolean b21 = carrinha0.equals((java.lang.Object) 'a');
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "n/a" + "'", str2.equals("n/a"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str8.equals("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha16);
        org.junit.Assert.assertNotNull(coordenada17);
        org.junit.Assert.assertTrue(b20 == false);
        org.junit.Assert.assertTrue(b21 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        int i4 = carrinha3.getFiabilidade();
        java.lang.String str5 = carrinha3.toString();
        carrinha3.setOcupado(false);
        double d8 = carrinha3.getPrecoBase();
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str5.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(d8 == 0.0d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        carrinha0.setMatricula("n/a");
        Carrinha carrinha6 = new Carrinha();
        carrinha6.setMatricula("");
        Carrinha carrinha9 = carrinha6.clone();
        carrinha6.setPrecoBase((double) 0L);
        Carrinha carrinha12 = new Carrinha();
        int i13 = carrinha12.getLugares();
        int i14 = carrinha6.compareTo((Veiculo) carrinha12);
        java.lang.String str15 = carrinha12.toString();
        Coordenada coordenada16 = carrinha12.getCoordenadas();
        Carrinha carrinha17 = new Carrinha();
        int i18 = carrinha17.getLugares();
        Coordenada coordenada19 = carrinha17.getCoordenadas();
        carrinha12.setCoordenadas(coordenada19);
        carrinha0.setCoordenadas(coordenada19);
        Carrinha carrinha22 = carrinha0.clone();
        Coordenada coordenada23 = null;
        try {
            carrinha22.setCoordenadas(coordenada23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(carrinha9);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(i14 == 3);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str15.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada16);
        org.junit.Assert.assertTrue(i18 == 0);
        org.junit.Assert.assertNotNull(coordenada19);
        org.junit.Assert.assertNotNull(carrinha22);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        Carrinha carrinha4 = new Carrinha(carrinha3);
        int i5 = carrinha1.compareTo((Veiculo) carrinha3);
        Carrinha carrinha6 = new Carrinha();
        carrinha6.setMatricula("");
        boolean b10 = carrinha6.equals((java.lang.Object) (-1.0d));
        boolean b11 = carrinha1.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha12 = new Carrinha();
        carrinha12.setMatricula("");
        Carrinha carrinha15 = carrinha12.clone();
        carrinha12.setPrecoBase((double) 0L);
        Carrinha carrinha18 = new Carrinha();
        int i19 = carrinha18.getLugares();
        int i20 = carrinha12.compareTo((Veiculo) carrinha18);
        java.lang.String str21 = carrinha18.toString();
        Coordenada coordenada22 = carrinha18.getCoordenadas();
        carrinha1.setCoordenadas(coordenada22);
        carrinha1.setPrecoBase((double) (short) 10);
        java.lang.String str26 = carrinha1.toString();
        Carrinha carrinha27 = new Carrinha();
        carrinha27.setMatricula("");
        Carrinha carrinha30 = carrinha27.clone();
        carrinha27.setPrecoBase((double) 0L);
        Carrinha carrinha33 = new Carrinha();
        int i34 = carrinha33.getLugares();
        int i35 = carrinha27.compareTo((Veiculo) carrinha33);
        java.lang.String str36 = carrinha33.toString();
        Coordenada coordenada37 = carrinha33.getCoordenadas();
        carrinha33.setFiabilidade((int) (byte) 1);
        int i40 = carrinha1.compareTo((Veiculo) carrinha33);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertNotNull(carrinha15);
        org.junit.Assert.assertTrue(i19 == 0);
        org.junit.Assert.assertTrue(i20 == 3);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str21.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada22);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 10.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str26.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 10.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha30);
        org.junit.Assert.assertTrue(i34 == 0);
        org.junit.Assert.assertTrue(i35 == 3);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str36.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada37);
        org.junit.Assert.assertTrue(i40 == 0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carrinha0.getCoordenadas();
        boolean b6 = carrinha0.getOcupado();
        java.lang.String str7 = carrinha0.getMatricula();
        Carrinha carrinha12 = new Carrinha();
        carrinha12.setMatricula("");
        Carrinha carrinha15 = carrinha12.clone();
        carrinha12.setPrecoBase((double) 0L);
        Carrinha carrinha18 = new Carrinha();
        int i19 = carrinha18.getLugares();
        int i20 = carrinha12.compareTo((Veiculo) carrinha18);
        java.lang.String str21 = carrinha18.toString();
        Coordenada coordenada22 = carrinha18.getCoordenadas();
        Carrinha carrinha24 = new Carrinha((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada22, false);
        carrinha0.setCoordenadas(coordenada22);
        carrinha0.setOcupado(true);
        double d28 = carrinha0.getPrecoBase();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(b6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(carrinha15);
        org.junit.Assert.assertTrue(i19 == 0);
        org.junit.Assert.assertTrue(i20 == 3);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str21.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada22);
        org.junit.Assert.assertTrue(d28 == 0.0d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        Carrinha carrinha4 = new Carrinha(carrinha3);
        int i5 = carrinha1.compareTo((Veiculo) carrinha3);
        Carrinha carrinha6 = new Carrinha();
        carrinha6.setMatricula("");
        boolean b10 = carrinha6.equals((java.lang.Object) (-1.0d));
        boolean b11 = carrinha1.equals((java.lang.Object) (-1.0d));
        carrinha1.setVelocidadeMedia(52);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue(b11 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        Carrinha carrinha12 = new Carrinha();
        carrinha12.setMatricula("");
        Carrinha carrinha15 = carrinha12.clone();
        carrinha12.setPrecoBase((double) 0L);
        Carrinha carrinha18 = new Carrinha();
        int i19 = carrinha18.getLugares();
        int i20 = carrinha12.compareTo((Veiculo) carrinha18);
        java.lang.String str21 = carrinha18.toString();
        Coordenada coordenada22 = carrinha18.getCoordenadas();
        Carrinha carrinha24 = new Carrinha((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada22, false);
        Carrinha carrinha26 = new Carrinha((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada22, true);
        Carrinha carrinha28 = new Carrinha((int) '#', 10.0d, (-1), "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada22, true);
        Coordenada coordenada29 = carrinha28.getCoordenadas();
        java.lang.String str30 = carrinha28.getMatricula();
        carrinha28.setOcupado(true);
        org.junit.Assert.assertNotNull(carrinha15);
        org.junit.Assert.assertTrue(i19 == 0);
        org.junit.Assert.assertTrue(i20 == 3);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str21.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada22);
        org.junit.Assert.assertNotNull(coordenada29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str30.equals("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha(carrinha0);
        carrinha6.setPrecoBase((double) (-1.0f));
        carrinha6.setVelocidadeMedia((int) (short) 0);
        carrinha6.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Carrinha carrinha13 = new Carrinha(carrinha6);
        carrinha6.setPrecoBase(1.0d);
        carrinha6.setMatricula("");
        org.junit.Assert.assertNotNull(carrinha3);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        Carrinha carrinha4 = new Carrinha();
        carrinha4.setMatricula("");
        boolean b8 = carrinha4.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada9 = carrinha4.getCoordenadas();
        boolean b10 = carrinha4.getOcupado();
        java.lang.String str11 = carrinha4.getMatricula();
        Carrinha carrinha16 = new Carrinha();
        carrinha16.setMatricula("");
        Carrinha carrinha19 = carrinha16.clone();
        carrinha16.setPrecoBase((double) 0L);
        Carrinha carrinha22 = new Carrinha();
        int i23 = carrinha22.getLugares();
        int i24 = carrinha16.compareTo((Veiculo) carrinha22);
        java.lang.String str25 = carrinha22.toString();
        Coordenada coordenada26 = carrinha22.getCoordenadas();
        Carrinha carrinha28 = new Carrinha((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada26, false);
        carrinha4.setCoordenadas(coordenada26);
        Carrinha carrinha30 = new Carrinha();
        carrinha30.setMatricula("");
        Carrinha carrinha33 = carrinha30.clone();
        carrinha30.setPrecoBase((double) 0L);
        Carrinha carrinha36 = new Carrinha();
        int i37 = carrinha36.getLugares();
        int i38 = carrinha30.compareTo((Veiculo) carrinha36);
        int i39 = carrinha36.getFiabilidade();
        Carrinha carrinha40 = carrinha36.clone();
        Coordenada coordenada41 = carrinha40.getCoordenadas();
        carrinha4.setCoordenadas(coordenada41);
        Carrinha carrinha44 = new Carrinha(0, (double) (short) 0, (-145), "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada41, false);
        org.junit.Assert.assertTrue(b8 == false);
        org.junit.Assert.assertNotNull(coordenada9);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(carrinha19);
        org.junit.Assert.assertTrue(i23 == 0);
        org.junit.Assert.assertTrue(i24 == 3);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str25.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada26);
        org.junit.Assert.assertNotNull(carrinha33);
        org.junit.Assert.assertTrue(i37 == 0);
        org.junit.Assert.assertTrue(i38 == 3);
        org.junit.Assert.assertTrue(i39 == 0);
        org.junit.Assert.assertNotNull(carrinha40);
        org.junit.Assert.assertNotNull(coordenada41);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha(carrinha0);
        carrinha6.setFiabilidade((int) '#');
        carrinha6.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n");
        org.junit.Assert.assertNotNull(carrinha3);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        java.lang.String str9 = carrinha6.toString();
        int i10 = carrinha6.getFiabilidade();
        carrinha6.setPrecoBase(10.0d);
        int i13 = carrinha6.getVelocidadeMedia();
        Carrinha carrinha14 = new Carrinha(carrinha6);
        int i15 = carrinha14.getVelocidadeMedia();
        boolean b16 = carrinha14.getOcupado();
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(i15 == 0);
        org.junit.Assert.assertTrue(b16 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha3.setOcupado(true);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        carrinha6.setVelocidadeMedia(10);
        int i10 = carrinha3.compareTo((Veiculo) carrinha6);
        Coordenada coordenada11 = carrinha3.getCoordenadas();
        int i12 = carrinha3.getLugares();
        carrinha3.setFiabilidade(9);
        carrinha3.setOcupado(true);
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i10 == 3);
        org.junit.Assert.assertNotNull(coordenada11);
        org.junit.Assert.assertTrue(i12 == 0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        int i9 = carrinha6.getFiabilidade();
        Carrinha carrinha10 = carrinha6.clone();
        int i11 = carrinha6.getLugares();
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertNotNull(carrinha10);
        org.junit.Assert.assertTrue(i11 == 0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        Carrinha carrinha4 = new Carrinha();
        Carrinha carrinha5 = new Carrinha(carrinha4);
        Carrinha carrinha6 = new Carrinha(carrinha5);
        Carrinha carrinha7 = new Carrinha();
        Carrinha carrinha8 = new Carrinha(carrinha7);
        int i9 = carrinha5.compareTo((Veiculo) carrinha7);
        int i10 = carrinha7.getVelocidadeMedia();
        Carrinha carrinha11 = carrinha7.clone();
        int i12 = carrinha11.getFiabilidade();
        int i13 = carrinha11.getFiabilidade();
        Carrinha carrinha14 = new Carrinha(carrinha11);
        Coordenada coordenada15 = carrinha11.getCoordenadas();
        Carrinha carrinha17 = new Carrinha((int) ' ', (double) (-1.0f), 3, "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada15, true);
        int i18 = carrinha17.getFiabilidade();
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertNotNull(carrinha11);
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertNotNull(coordenada15);
        org.junit.Assert.assertTrue(i18 == 3);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        java.lang.String str3 = carrinha0.toString();
        Carrinha carrinha4 = carrinha0.clone();
        carrinha4.setOcupado(true);
        Carrinha carrinha7 = new Carrinha();
        Carrinha carrinha8 = new Carrinha(carrinha7);
        java.lang.String str9 = carrinha7.toString();
        carrinha7.setFiabilidade(0);
        int i12 = carrinha7.getFiabilidade();
        Carrinha carrinha13 = new Carrinha(carrinha7);
        boolean b14 = carrinha4.equals((java.lang.Object) carrinha13);
        java.lang.String str15 = carrinha4.getMatricula();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setVelocidadeMedia((int) ' ');
        java.lang.String str3 = carrinha0.toString();
        Carrinha carrinha8 = new Carrinha();
        carrinha8.setMatricula("");
        Carrinha carrinha11 = carrinha8.clone();
        Coordenada coordenada12 = carrinha11.getCoordenadas();
        Carrinha carrinha14 = new Carrinha((int) (byte) 0, (double) 'a', 3, "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada12, false);
        boolean b15 = carrinha0.equals((java.lang.Object) 'a');
        carrinha0.setOcupado(false);
        double d18 = carrinha0.getPrecoBase();
        Carrinha carrinha19 = new Carrinha();
        carrinha19.setMatricula("");
        boolean b23 = carrinha19.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada24 = carrinha19.getCoordenadas();
        int i25 = carrinha19.getVelocidadeMedia();
        Carrinha carrinha26 = new Carrinha();
        carrinha26.setMatricula("");
        Carrinha carrinha29 = carrinha26.clone();
        carrinha29.setOcupado(true);
        boolean b32 = carrinha19.equals((java.lang.Object) carrinha29);
        carrinha29.setMatricula("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Carrinha carrinha35 = new Carrinha();
        Carrinha carrinha36 = new Carrinha(carrinha35);
        java.lang.String str37 = carrinha35.toString();
        carrinha35.setFiabilidade(0);
        Carrinha carrinha40 = carrinha35.clone();
        int i41 = carrinha35.getLugares();
        Carrinha carrinha46 = new Carrinha();
        Carrinha carrinha47 = new Carrinha(carrinha46);
        Carrinha carrinha48 = new Carrinha(carrinha47);
        Carrinha carrinha49 = new Carrinha();
        Carrinha carrinha50 = new Carrinha(carrinha49);
        int i51 = carrinha47.compareTo((Veiculo) carrinha49);
        Carrinha carrinha52 = new Carrinha();
        carrinha52.setMatricula("");
        boolean b56 = carrinha52.equals((java.lang.Object) (-1.0d));
        boolean b57 = carrinha47.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha58 = new Carrinha();
        carrinha58.setMatricula("");
        Carrinha carrinha61 = carrinha58.clone();
        carrinha58.setPrecoBase((double) 0L);
        Carrinha carrinha64 = new Carrinha();
        int i65 = carrinha64.getLugares();
        int i66 = carrinha58.compareTo((Veiculo) carrinha64);
        java.lang.String str67 = carrinha64.toString();
        Coordenada coordenada68 = carrinha64.getCoordenadas();
        carrinha47.setCoordenadas(coordenada68);
        Carrinha carrinha71 = new Carrinha((-1), 10.0d, (int) (byte) 1, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada68, true);
        carrinha35.setCoordenadas(coordenada68);
        carrinha29.setCoordenadas(coordenada68);
        int i74 = carrinha0.compareTo((Veiculo) carrinha29);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha11);
        org.junit.Assert.assertNotNull(coordenada12);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertTrue(d18 == 0.0d);
        org.junit.Assert.assertTrue(b23 == false);
        org.junit.Assert.assertNotNull(coordenada24);
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertNotNull(carrinha29);
        org.junit.Assert.assertTrue(b32 == false);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str37.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha40);
        org.junit.Assert.assertTrue(i41 == 0);
        org.junit.Assert.assertTrue(i51 == 0);
        org.junit.Assert.assertTrue(b56 == false);
        org.junit.Assert.assertTrue(b57 == false);
        org.junit.Assert.assertNotNull(carrinha61);
        org.junit.Assert.assertTrue(i65 == 0);
        org.junit.Assert.assertTrue(i66 == 3);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str67.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada68);
        org.junit.Assert.assertTrue(i74 == (-33));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        carrinha6.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carrinha6.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 10.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        java.lang.String str9 = carrinha6.toString();
        int i10 = carrinha6.getFiabilidade();
        Carrinha carrinha11 = new Carrinha();
        Carrinha carrinha12 = new Carrinha(carrinha11);
        Carrinha carrinha13 = new Carrinha(carrinha12);
        Carrinha carrinha14 = new Carrinha();
        Carrinha carrinha15 = new Carrinha(carrinha14);
        int i16 = carrinha12.compareTo((Veiculo) carrinha14);
        Carrinha carrinha17 = new Carrinha();
        carrinha17.setMatricula("");
        boolean b21 = carrinha17.equals((java.lang.Object) (-1.0d));
        boolean b22 = carrinha12.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha23 = new Carrinha();
        carrinha23.setMatricula("");
        Carrinha carrinha26 = carrinha23.clone();
        carrinha23.setPrecoBase((double) 0L);
        Carrinha carrinha29 = new Carrinha();
        int i30 = carrinha29.getLugares();
        int i31 = carrinha23.compareTo((Veiculo) carrinha29);
        java.lang.String str32 = carrinha29.toString();
        Coordenada coordenada33 = carrinha29.getCoordenadas();
        carrinha12.setCoordenadas(coordenada33);
        boolean b35 = carrinha6.equals((java.lang.Object) carrinha12);
        java.lang.String str36 = carrinha6.toString();
        Carrinha carrinha37 = new Carrinha();
        Carrinha carrinha38 = new Carrinha(carrinha37);
        java.lang.String str39 = carrinha37.toString();
        carrinha37.setFiabilidade(0);
        Carrinha carrinha42 = carrinha37.clone();
        int i43 = carrinha37.getLugares();
        java.lang.Object obj44 = new java.lang.Object();
        boolean b45 = carrinha37.equals(obj44);
        int i46 = carrinha6.compareTo((Veiculo) carrinha37);
        int i47 = carrinha37.getFiabilidade();
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue(b21 == false);
        org.junit.Assert.assertTrue(b22 == false);
        org.junit.Assert.assertNotNull(carrinha26);
        org.junit.Assert.assertTrue(i30 == 0);
        org.junit.Assert.assertTrue(i31 == 3);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str32.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada33);
        org.junit.Assert.assertTrue(b35 == true);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str36.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str39.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha42);
        org.junit.Assert.assertTrue(i43 == 0);
        org.junit.Assert.assertTrue(b45 == false);
        org.junit.Assert.assertTrue(i46 == 0);
        org.junit.Assert.assertTrue(i47 == 0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        int i9 = carrinha6.getFiabilidade();
        Carrinha carrinha10 = carrinha6.clone();
        java.lang.String str11 = carrinha6.getMatricula();
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertNotNull(carrinha10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "n/a" + "'", str11.equals("n/a"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        Carrinha carrinha4 = new Carrinha(carrinha3);
        int i5 = carrinha1.compareTo((Veiculo) carrinha3);
        carrinha3.setMatricula("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        int i8 = carrinha3.getFiabilidade();
        Carrinha carrinha9 = carrinha3.clone();
        Carrinha carrinha10 = new Carrinha(carrinha9);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertNotNull(carrinha9);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        java.lang.String str2 = carrinha0.toString();
        carrinha0.setFiabilidade(0);
        int i5 = carrinha0.getFiabilidade();
        Carrinha carrinha6 = new Carrinha(carrinha0);
        Carrinha carrinha7 = carrinha0.clone();
        carrinha0.setFiabilidade(3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertNotNull(carrinha7);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        java.lang.String str3 = carrinha0.toString();
        Carrinha carrinha4 = carrinha0.clone();
        int i5 = carrinha0.getVelocidadeMedia();
        boolean b6 = carrinha0.getOcupado();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha4);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(b6 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carrinha0.getCoordenadas();
        carrinha0.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carrinha0.setFiabilidade(0);
        java.lang.String str10 = carrinha0.getMatricula();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str10.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        Carrinha carrinha4 = new Carrinha(carrinha0);
        int i5 = carrinha0.getVelocidadeMedia();
        double d6 = carrinha0.getPrecoBase();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i5 == 10);
        org.junit.Assert.assertTrue(d6 == 0.0d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha3.setOcupado(true);
        int i6 = carrinha3.getFiabilidade();
        int i7 = carrinha3.getFiabilidade();
        java.lang.Object obj8 = null;
        boolean b9 = carrinha3.equals(obj8);
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(b9 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        Carrinha carrinha4 = new Carrinha(carrinha3);
        int i5 = carrinha1.compareTo((Veiculo) carrinha3);
        int i6 = carrinha3.getVelocidadeMedia();
        Carrinha carrinha7 = carrinha3.clone();
        int i8 = carrinha7.getFiabilidade();
        carrinha7.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertNotNull(carrinha7);
        org.junit.Assert.assertTrue(i8 == 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        java.lang.String str9 = carrinha6.toString();
        Coordenada coordenada10 = carrinha6.getCoordenadas();
        carrinha6.setFiabilidade((int) (byte) 1);
        Carrinha carrinha13 = new Carrinha();
        int i14 = carrinha13.getLugares();
        carrinha13.setVelocidadeMedia(10);
        Carrinha carrinha17 = carrinha13.clone();
        boolean b18 = carrinha6.equals((java.lang.Object) carrinha13);
        java.lang.String str19 = carrinha6.getMatricula();
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertNotNull(carrinha17);
        org.junit.Assert.assertTrue(b18 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "n/a" + "'", str19.equals("n/a"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        Carrinha carrinha4 = new Carrinha(carrinha0);
        Carrinha carrinha5 = new Carrinha(carrinha4);
        int i6 = carrinha5.getFiabilidade();
        Carrinha carrinha7 = carrinha5.clone();
        carrinha5.setPrecoBase((double) 0);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertNotNull(carrinha7);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        java.lang.String str9 = carrinha6.toString();
        int i10 = carrinha6.getFiabilidade();
        carrinha6.setPrecoBase(10.0d);
        int i13 = carrinha6.getFiabilidade();
        carrinha6.setFiabilidade(100);
        int i16 = carrinha6.getLugares();
        carrinha6.setOcupado(false);
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(i16 == 0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        int i4 = carrinha3.getVelocidadeMedia();
        java.lang.Object obj5 = null;
        boolean b6 = carrinha3.equals(obj5);
        Carrinha carrinha7 = new Carrinha();
        carrinha7.setMatricula("");
        Carrinha carrinha10 = carrinha7.clone();
        carrinha10.setOcupado(true);
        Carrinha carrinha13 = new Carrinha();
        int i14 = carrinha13.getLugares();
        carrinha13.setVelocidadeMedia(10);
        int i17 = carrinha10.compareTo((Veiculo) carrinha13);
        Coordenada coordenada18 = carrinha10.getCoordenadas();
        int i19 = carrinha10.getLugares();
        boolean b20 = carrinha3.equals((java.lang.Object) carrinha10);
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue(b6 == false);
        org.junit.Assert.assertNotNull(carrinha10);
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(i17 == 3);
        org.junit.Assert.assertNotNull(coordenada18);
        org.junit.Assert.assertTrue(i19 == 0);
        org.junit.Assert.assertTrue(b20 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        Coordenada coordenada4 = carrinha3.getCoordenadas();
        Carrinha carrinha5 = carrinha3.clone();
        java.lang.String str6 = carrinha3.getMatricula();
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertNotNull(coordenada4);
        org.junit.Assert.assertNotNull(carrinha5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        java.lang.String str2 = carrinha0.getMatricula();
        Carrinha carrinha3 = new Carrinha(carrinha0);
        carrinha0.setOcupado(true);
        java.lang.String str6 = carrinha0.toString();
        Carrinha carrinha7 = new Carrinha();
        int i8 = carrinha7.getLugares();
        java.lang.String str9 = carrinha7.getMatricula();
        Carrinha carrinha10 = new Carrinha(carrinha7);
        int i11 = carrinha10.getFiabilidade();
        boolean b12 = carrinha0.equals((java.lang.Object) i11);
        carrinha0.setVelocidadeMedia(33);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "n/a" + "'", str2.equals("n/a"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n" + "'", str6.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n"));
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "n/a" + "'", str9.equals("n/a"));
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(b12 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        java.lang.String str2 = carrinha0.toString();
        carrinha0.setFiabilidade(0);
        Carrinha carrinha5 = carrinha0.clone();
        int i6 = carrinha0.getLugares();
        java.lang.Object obj7 = new java.lang.Object();
        boolean b8 = carrinha0.equals(obj7);
        java.lang.String str9 = carrinha0.toString();
        java.lang.String str10 = carrinha0.getMatricula();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha5);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertTrue(b8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "n/a" + "'", str10.equals("n/a"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        int i4 = carrinha3.getLugares();
        boolean b5 = carrinha2.equals((java.lang.Object) carrinha3);
        carrinha3.setFiabilidade(100);
        int i8 = carrinha3.getFiabilidade();
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue(b5 == true);
        org.junit.Assert.assertTrue(i8 == 100);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        Carrinha carrinha4 = new Carrinha();
        carrinha4.setMatricula("");
        Carrinha carrinha7 = carrinha4.clone();
        carrinha4.setPrecoBase((double) 0L);
        Carrinha carrinha10 = new Carrinha(carrinha4);
        Carrinha carrinha11 = new Carrinha();
        int i12 = carrinha11.getLugares();
        carrinha11.setVelocidadeMedia(10);
        Carrinha carrinha15 = new Carrinha(carrinha11);
        Carrinha carrinha16 = new Carrinha(carrinha15);
        int i17 = carrinha16.getFiabilidade();
        Carrinha carrinha18 = carrinha16.clone();
        Carrinha carrinha19 = new Carrinha();
        carrinha19.setMatricula("");
        Carrinha carrinha22 = carrinha19.clone();
        int i23 = carrinha22.getVelocidadeMedia();
        Coordenada coordenada24 = carrinha22.getCoordenadas();
        carrinha18.setCoordenadas(coordenada24);
        carrinha4.setCoordenadas(coordenada24);
        Carrinha carrinha28 = new Carrinha(1, (double) 1, 32, "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 10.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada24, true);
        org.junit.Assert.assertNotNull(carrinha7);
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertTrue(i17 == 0);
        org.junit.Assert.assertNotNull(carrinha18);
        org.junit.Assert.assertNotNull(carrinha22);
        org.junit.Assert.assertTrue(i23 == 0);
        org.junit.Assert.assertNotNull(coordenada24);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carrinha0.getCoordenadas();
        carrinha0.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carrinha0.setFiabilidade(0);
        Carrinha carrinha10 = new Carrinha();
        carrinha10.setMatricula("");
        Carrinha carrinha13 = carrinha10.clone();
        carrinha10.setPrecoBase((double) 0L);
        Carrinha carrinha16 = new Carrinha(carrinha10);
        int i17 = carrinha0.compareTo((Veiculo) carrinha10);
        Carrinha carrinha18 = new Carrinha(carrinha10);
        carrinha18.setOcupado(false);
        carrinha18.setPrecoBase((double) 0.0f);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertNotNull(carrinha13);
        org.junit.Assert.assertTrue(i17 == (-142));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        carrinha0.setFiabilidade((int) (byte) 0);
        double d6 = carrinha0.getPrecoBase();
        carrinha0.setFiabilidade((-142));
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(d6 == 0.0d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        Carrinha carrinha4 = new Carrinha();
        Carrinha carrinha5 = new Carrinha(carrinha4);
        Carrinha carrinha6 = new Carrinha(carrinha5);
        Carrinha carrinha7 = new Carrinha();
        Carrinha carrinha8 = new Carrinha(carrinha7);
        int i9 = carrinha5.compareTo((Veiculo) carrinha7);
        Carrinha carrinha10 = new Carrinha();
        carrinha10.setMatricula("");
        boolean b14 = carrinha10.equals((java.lang.Object) (-1.0d));
        boolean b15 = carrinha5.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada16 = carrinha5.getCoordenadas();
        Carrinha carrinha18 = new Carrinha((int) (short) 10, (double) 0.0f, (int) (short) 0, "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada16, true);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertNotNull(coordenada16);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        java.lang.String str9 = carrinha6.toString();
        int i10 = carrinha6.getFiabilidade();
        carrinha6.setPrecoBase(10.0d);
        int i13 = carrinha6.getVelocidadeMedia();
        int i14 = carrinha6.getFiabilidade();
        Carrinha carrinha15 = carrinha6.clone();
        carrinha6.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n");
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertNotNull(carrinha15);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carrinha0.getCoordenadas();
        carrinha0.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carrinha0.setFiabilidade(0);
        Carrinha carrinha10 = new Carrinha();
        carrinha10.setMatricula("");
        Carrinha carrinha13 = carrinha10.clone();
        carrinha10.setPrecoBase((double) 0L);
        Carrinha carrinha16 = new Carrinha(carrinha10);
        int i17 = carrinha0.compareTo((Veiculo) carrinha10);
        Carrinha carrinha18 = new Carrinha(carrinha10);
        int i19 = carrinha10.getFiabilidade();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertNotNull(carrinha13);
        org.junit.Assert.assertTrue(i17 == (-142));
        org.junit.Assert.assertTrue(i19 == 0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        java.lang.String str2 = carrinha0.toString();
        carrinha0.setFiabilidade(0);
        int i5 = carrinha0.getFiabilidade();
        Carrinha carrinha6 = new Carrinha(carrinha0);
        int i7 = carrinha0.getLugares();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(i7 == 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carrinha0.getCoordenadas();
        int i6 = carrinha0.getVelocidadeMedia();
        Carrinha carrinha7 = new Carrinha();
        carrinha7.setMatricula("");
        Carrinha carrinha10 = carrinha7.clone();
        carrinha10.setOcupado(true);
        boolean b13 = carrinha0.equals((java.lang.Object) carrinha10);
        carrinha10.setMatricula("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Carrinha carrinha16 = carrinha10.clone();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertNotNull(carrinha10);
        org.junit.Assert.assertTrue(b13 == false);
        org.junit.Assert.assertNotNull(carrinha16);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        java.lang.String str2 = carrinha0.toString();
        carrinha0.setMatricula("hi!");
        carrinha0.setPrecoBase((double) 10.0f);
        java.lang.String str7 = carrinha0.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Matrícula: hi!\nVelocidade Média/km: 0km/h\nPreço Base: 10.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str7.equals("Matrícula: hi!\nVelocidade Média/km: 0km/h\nPreço Base: 10.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha3.setOcupado(true);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        carrinha6.setVelocidadeMedia(10);
        int i10 = carrinha3.compareTo((Veiculo) carrinha6);
        carrinha3.setFiabilidade((int) ' ');
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i10 == 3);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setVelocidadeMedia((int) ' ');
        java.lang.String str3 = carrinha0.toString();
        Carrinha carrinha8 = new Carrinha();
        carrinha8.setMatricula("");
        Carrinha carrinha11 = carrinha8.clone();
        Coordenada coordenada12 = carrinha11.getCoordenadas();
        Carrinha carrinha14 = new Carrinha((int) (byte) 0, (double) 'a', 3, "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada12, false);
        boolean b15 = carrinha0.equals((java.lang.Object) 'a');
        carrinha0.setOcupado(false);
        double d18 = carrinha0.getPrecoBase();
        carrinha0.setVelocidadeMedia((int) (byte) 100);
        double d21 = carrinha0.getPrecoBase();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha11);
        org.junit.Assert.assertNotNull(coordenada12);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertTrue(d18 == 0.0d);
        org.junit.Assert.assertTrue(d21 == 0.0d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        int i4 = carrinha3.getLugares();
        boolean b5 = carrinha2.equals((java.lang.Object) carrinha3);
        carrinha3.setPrecoBase(0.0d);
        java.lang.String str8 = carrinha3.getMatricula();
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue(b5 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "n/a" + "'", str8.equals("n/a"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        Carrinha carrinha2 = carrinha0.clone();
        Carrinha carrinha3 = new Carrinha(carrinha2);
        Coordenada coordenada4 = carrinha3.getCoordenadas();
        carrinha3.setFiabilidade((int) (short) 1);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(carrinha2);
        org.junit.Assert.assertNotNull(coordenada4);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        boolean b6 = carrinha0.getOcupado();
        int i7 = carrinha0.getFiabilidade();
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(b6 == false);
        org.junit.Assert.assertTrue(i7 == 0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        carrinha0.setOcupado(false);
        boolean b5 = carrinha0.getOcupado();
        org.junit.Assert.assertTrue(b5 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        Carrinha carrinha4 = new Carrinha();
        carrinha4.setMatricula("");
        Carrinha carrinha7 = carrinha4.clone();
        Coordenada coordenada8 = carrinha7.getCoordenadas();
        Carrinha carrinha10 = new Carrinha((int) (byte) 0, (double) 'a', 3, "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada8, false);
        int i11 = carrinha10.getVelocidadeMedia();
        java.lang.String str12 = carrinha10.toString();
        org.junit.Assert.assertNotNull(carrinha7);
        org.junit.Assert.assertNotNull(coordenada8);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Matrícula: Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 97.0€\nFiabilidade: 3\nLugares: 9\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str12.equals("Matrícula: Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 97.0€\nFiabilidade: 3\nLugares: 9\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        Carrinha carrinha4 = new Carrinha(carrinha3);
        int i5 = carrinha1.compareTo((Veiculo) carrinha3);
        Carrinha carrinha6 = new Carrinha();
        carrinha6.setMatricula("");
        boolean b10 = carrinha6.equals((java.lang.Object) (-1.0d));
        boolean b11 = carrinha1.equals((java.lang.Object) (-1.0d));
        boolean b12 = carrinha1.getOcupado();
        boolean b13 = carrinha1.getOcupado();
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertTrue(b13 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        double d2 = carrinha1.getPrecoBase();
        org.junit.Assert.assertTrue(d2 == 0.0d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        Coordenada coordenada2 = carrinha0.getCoordenadas();
        carrinha0.setFiabilidade(3);
        Carrinha carrinha5 = carrinha0.clone();
        Coordenada coordenada6 = carrinha0.getCoordenadas();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(coordenada2);
        org.junit.Assert.assertNotNull(carrinha5);
        org.junit.Assert.assertNotNull(coordenada6);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        java.lang.String str9 = carrinha6.toString();
        Coordenada coordenada10 = carrinha6.getCoordenadas();
        carrinha6.setFiabilidade((int) (byte) 1);
        double d13 = carrinha6.getPrecoBase();
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertTrue(d13 == 0.0d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        carrinha0.setMatricula("n/a");
        java.lang.String str11 = carrinha0.toString();
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str11.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        Carrinha carrinha4 = new Carrinha();
        carrinha4.setMatricula("");
        Carrinha carrinha7 = carrinha4.clone();
        Coordenada coordenada8 = carrinha7.getCoordenadas();
        Carrinha carrinha10 = new Carrinha((int) (byte) -1, (double) 0, (int) (short) 1, "", coordenada8, false);
        double d11 = carrinha10.getPrecoBase();
        carrinha10.setOcupado(false);
        carrinha10.setOcupado(true);
        org.junit.Assert.assertNotNull(carrinha7);
        org.junit.Assert.assertNotNull(coordenada8);
        org.junit.Assert.assertTrue(d11 == 0.0d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carrinha0.getCoordenadas();
        boolean b6 = carrinha0.getOcupado();
        int i7 = carrinha0.getVelocidadeMedia();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(b6 == false);
        org.junit.Assert.assertTrue(i7 == 0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carrinha0.getCoordenadas();
        carrinha0.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carrinha0.setFiabilidade(0);
        int i10 = carrinha0.getVelocidadeMedia();
        Carrinha carrinha11 = new Carrinha();
        Carrinha carrinha12 = new Carrinha();
        Carrinha carrinha13 = new Carrinha(carrinha12);
        int i14 = carrinha13.getFiabilidade();
        Coordenada coordenada15 = carrinha13.getCoordenadas();
        carrinha11.setCoordenadas(coordenada15);
        boolean b17 = carrinha0.equals((java.lang.Object) carrinha11);
        int i18 = carrinha11.getFiabilidade();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertNotNull(coordenada15);
        org.junit.Assert.assertTrue(b17 == false);
        org.junit.Assert.assertTrue(i18 == 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        java.lang.String str3 = carrinha0.toString();
        Carrinha carrinha4 = new Carrinha();
        carrinha4.setMatricula("");
        boolean b8 = carrinha4.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha9 = new Carrinha(carrinha4);
        double d10 = carrinha4.getPrecoBase();
        java.lang.String str11 = carrinha4.toString();
        int i12 = carrinha4.getVelocidadeMedia();
        int i13 = carrinha4.getVelocidadeMedia();
        boolean b14 = carrinha0.equals((java.lang.Object) carrinha4);
        carrinha0.setMatricula("n/a");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(b8 == false);
        org.junit.Assert.assertTrue(d10 == 0.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str11.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(b14 == true);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha5 = new Carrinha(carrinha0);
        double d6 = carrinha0.getPrecoBase();
        boolean b7 = carrinha0.getOcupado();
        int i8 = carrinha0.getVelocidadeMedia();
        Carrinha carrinha9 = carrinha0.clone();
        java.lang.String str10 = carrinha9.getMatricula();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(b7 == false);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertNotNull(carrinha9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        Carrinha carrinha9 = new Carrinha(carrinha6);
        carrinha6.setVelocidadeMedia(32);
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        boolean b9 = carrinha6.getOcupado();
        int i10 = carrinha6.getVelocidadeMedia();
        java.lang.String str11 = carrinha6.toString();
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue(b9 == false);
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str11.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        java.lang.String str3 = carrinha0.getMatricula();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carrinha0.getCoordenadas();
        java.lang.String str6 = carrinha0.getMatricula();
        Carrinha carrinha7 = carrinha0.clone();
        carrinha7.setFiabilidade((int) 'a');
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(carrinha7);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        Carrinha carrinha4 = new Carrinha(carrinha3);
        int i5 = carrinha1.compareTo((Veiculo) carrinha3);
        Coordenada coordenada6 = carrinha1.getCoordenadas();
        int i7 = carrinha1.getLugares();
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertNotNull(coordenada6);
        org.junit.Assert.assertTrue(i7 == 0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        java.lang.String str9 = carrinha6.toString();
        int i10 = carrinha6.getFiabilidade();
        carrinha6.setPrecoBase(10.0d);
        int i13 = carrinha6.getVelocidadeMedia();
        Carrinha carrinha14 = new Carrinha(carrinha6);
        carrinha14.setFiabilidade((int) (short) 10);
        int i17 = carrinha14.getVelocidadeMedia();
        Carrinha carrinha18 = new Carrinha();
        carrinha18.setMatricula("");
        Carrinha carrinha21 = carrinha18.clone();
        carrinha18.setPrecoBase((double) 0L);
        Carrinha carrinha24 = new Carrinha();
        int i25 = carrinha24.getLugares();
        int i26 = carrinha18.compareTo((Veiculo) carrinha24);
        java.lang.String str27 = carrinha24.toString();
        Coordenada coordenada28 = carrinha24.getCoordenadas();
        carrinha24.setMatricula("hi!");
        boolean b31 = carrinha14.equals((java.lang.Object) "hi!");
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(i17 == 0);
        org.junit.Assert.assertNotNull(carrinha21);
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue(i26 == 3);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str27.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada28);
        org.junit.Assert.assertTrue(b31 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        java.lang.String str2 = carrinha0.toString();
        carrinha0.setFiabilidade(0);
        Carrinha carrinha5 = carrinha0.clone();
        carrinha5.setMatricula("Matrícula: hi!\nVelocidade Média/km: 0km/h\nPreço Base: 10.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha5);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        java.lang.String str2 = carrinha0.toString();
        carrinha0.setFiabilidade(0);
        Carrinha carrinha5 = carrinha0.clone();
        int i6 = carrinha0.getLugares();
        Carrinha carrinha11 = new Carrinha();
        Carrinha carrinha12 = new Carrinha(carrinha11);
        Carrinha carrinha13 = new Carrinha(carrinha12);
        Carrinha carrinha14 = new Carrinha();
        Carrinha carrinha15 = new Carrinha(carrinha14);
        int i16 = carrinha12.compareTo((Veiculo) carrinha14);
        Carrinha carrinha17 = new Carrinha();
        carrinha17.setMatricula("");
        boolean b21 = carrinha17.equals((java.lang.Object) (-1.0d));
        boolean b22 = carrinha12.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha23 = new Carrinha();
        carrinha23.setMatricula("");
        Carrinha carrinha26 = carrinha23.clone();
        carrinha23.setPrecoBase((double) 0L);
        Carrinha carrinha29 = new Carrinha();
        int i30 = carrinha29.getLugares();
        int i31 = carrinha23.compareTo((Veiculo) carrinha29);
        java.lang.String str32 = carrinha29.toString();
        Coordenada coordenada33 = carrinha29.getCoordenadas();
        carrinha12.setCoordenadas(coordenada33);
        Carrinha carrinha36 = new Carrinha((-1), 10.0d, (int) (byte) 1, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada33, true);
        carrinha0.setCoordenadas(coordenada33);
        int i38 = carrinha0.getFiabilidade();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha5);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue(b21 == false);
        org.junit.Assert.assertTrue(b22 == false);
        org.junit.Assert.assertNotNull(carrinha26);
        org.junit.Assert.assertTrue(i30 == 0);
        org.junit.Assert.assertTrue(i31 == 3);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str32.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada33);
        org.junit.Assert.assertTrue(i38 == 0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        java.lang.String str9 = carrinha6.toString();
        int i10 = carrinha6.getFiabilidade();
        carrinha6.setPrecoBase(10.0d);
        int i13 = carrinha6.getVelocidadeMedia();
        Carrinha carrinha14 = new Carrinha(carrinha6);
        carrinha6.setVelocidadeMedia(1);
        Coordenada coordenada17 = carrinha6.getCoordenadas();
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertNotNull(coordenada17);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        java.lang.String str3 = carrinha0.toString();
        Carrinha carrinha4 = carrinha0.clone();
        carrinha4.setOcupado(true);
        Carrinha carrinha7 = new Carrinha();
        Carrinha carrinha8 = new Carrinha(carrinha7);
        java.lang.String str9 = carrinha7.toString();
        carrinha7.setFiabilidade(0);
        int i12 = carrinha7.getFiabilidade();
        Carrinha carrinha13 = new Carrinha(carrinha7);
        boolean b14 = carrinha4.equals((java.lang.Object) carrinha13);
        Coordenada coordenada15 = carrinha4.getCoordenadas();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertNotNull(coordenada15);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        Carrinha carrinha4 = new Carrinha(carrinha0);
        Carrinha carrinha5 = new Carrinha(carrinha4);
        int i6 = carrinha5.getFiabilidade();
        Carrinha carrinha7 = carrinha5.clone();
        carrinha7.setOcupado(false);
        double d10 = carrinha7.getPrecoBase();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertNotNull(carrinha7);
        org.junit.Assert.assertTrue(d10 == 0.0d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        java.lang.String str2 = carrinha0.getMatricula();
        Carrinha carrinha3 = new Carrinha(carrinha0);
        carrinha0.setOcupado(true);
        java.lang.String str6 = carrinha0.toString();
        Carrinha carrinha7 = new Carrinha();
        int i8 = carrinha7.getLugares();
        java.lang.String str9 = carrinha7.getMatricula();
        Carrinha carrinha10 = new Carrinha(carrinha7);
        int i11 = carrinha10.getFiabilidade();
        boolean b12 = carrinha0.equals((java.lang.Object) i11);
        Carrinha carrinha13 = new Carrinha();
        carrinha13.setMatricula("");
        boolean b17 = carrinha13.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada18 = carrinha13.getCoordenadas();
        java.lang.String str19 = carrinha13.getMatricula();
        Carrinha carrinha20 = carrinha13.clone();
        boolean b21 = carrinha0.equals((java.lang.Object) carrinha13);
        boolean b22 = carrinha0.getOcupado();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "n/a" + "'", str2.equals("n/a"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n" + "'", str6.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n"));
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "n/a" + "'", str9.equals("n/a"));
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertTrue(b17 == false);
        org.junit.Assert.assertNotNull(coordenada18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNotNull(carrinha20);
        org.junit.Assert.assertTrue(b21 == false);
        org.junit.Assert.assertTrue(b22 == true);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        Carrinha carrinha4 = new Carrinha(carrinha3);
        int i5 = carrinha1.compareTo((Veiculo) carrinha3);
        Carrinha carrinha6 = new Carrinha();
        carrinha6.setMatricula("");
        Carrinha carrinha9 = carrinha6.clone();
        boolean b10 = carrinha1.equals((java.lang.Object) carrinha6);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertNotNull(carrinha9);
        org.junit.Assert.assertTrue(b10 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        java.lang.String str3 = carrinha0.toString();
        Carrinha carrinha4 = new Carrinha();
        carrinha4.setMatricula("");
        boolean b8 = carrinha4.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha9 = new Carrinha(carrinha4);
        double d10 = carrinha4.getPrecoBase();
        java.lang.String str11 = carrinha4.toString();
        int i12 = carrinha4.getVelocidadeMedia();
        int i13 = carrinha4.getVelocidadeMedia();
        boolean b14 = carrinha0.equals((java.lang.Object) carrinha4);
        int i15 = carrinha0.getVelocidadeMedia();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(b8 == false);
        org.junit.Assert.assertTrue(d10 == 0.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str11.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(b14 == true);
        org.junit.Assert.assertTrue(i15 == 0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        java.lang.String str3 = carrinha0.toString();
        java.lang.Object obj4 = null;
        boolean b5 = carrinha0.equals(obj4);
        Carrinha carrinha6 = new Carrinha();
        carrinha6.setMatricula("");
        Carrinha carrinha9 = carrinha6.clone();
        int i10 = carrinha9.getFiabilidade();
        java.lang.String str11 = carrinha9.toString();
        boolean b12 = carrinha0.equals((java.lang.Object) carrinha9);
        carrinha9.setVelocidadeMedia((-142));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(b5 == false);
        org.junit.Assert.assertNotNull(carrinha9);
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str11.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(b12 == true);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        Carrinha carrinha4 = new Carrinha();
        carrinha4.setMatricula("");
        Carrinha carrinha7 = carrinha4.clone();
        carrinha4.setPrecoBase((double) 0L);
        Carrinha carrinha10 = new Carrinha();
        int i11 = carrinha10.getLugares();
        int i12 = carrinha4.compareTo((Veiculo) carrinha10);
        java.lang.String str13 = carrinha10.toString();
        Coordenada coordenada14 = carrinha10.getCoordenadas();
        Carrinha carrinha16 = new Carrinha((int) (byte) -1, 0.0d, (int) 'a', "", coordenada14, true);
        int i17 = carrinha16.getLugares();
        org.junit.Assert.assertNotNull(carrinha7);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(i12 == 3);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str13.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada14);
        org.junit.Assert.assertTrue(i17 == 9);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        int i9 = carrinha6.getFiabilidade();
        Carrinha carrinha10 = carrinha6.clone();
        Coordenada coordenada11 = carrinha10.getCoordenadas();
        int i12 = carrinha10.getLugares();
        carrinha10.setOcupado(false);
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertNotNull(carrinha10);
        org.junit.Assert.assertNotNull(coordenada11);
        org.junit.Assert.assertTrue(i12 == 0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        Carrinha carrinha4 = new Carrinha(carrinha0);
        int i5 = carrinha0.getVelocidadeMedia();
        Carrinha carrinha6 = carrinha0.clone();
        carrinha6.setMatricula("Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Coordenada coordenada9 = carrinha6.getCoordenadas();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i5 == 10);
        org.junit.Assert.assertNotNull(carrinha6);
        org.junit.Assert.assertNotNull(coordenada9);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        Carrinha carrinha4 = new Carrinha(carrinha3);
        int i5 = carrinha1.compareTo((Veiculo) carrinha3);
        Carrinha carrinha6 = new Carrinha();
        carrinha6.setMatricula("");
        boolean b10 = carrinha6.equals((java.lang.Object) (-1.0d));
        boolean b11 = carrinha1.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha12 = new Carrinha(carrinha1);
        Carrinha carrinha17 = new Carrinha();
        Carrinha carrinha18 = new Carrinha(carrinha17);
        Carrinha carrinha19 = new Carrinha(carrinha18);
        Carrinha carrinha20 = new Carrinha();
        Carrinha carrinha21 = new Carrinha(carrinha20);
        int i22 = carrinha18.compareTo((Veiculo) carrinha20);
        Carrinha carrinha23 = new Carrinha();
        carrinha23.setMatricula("");
        boolean b27 = carrinha23.equals((java.lang.Object) (-1.0d));
        boolean b28 = carrinha18.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha29 = new Carrinha();
        carrinha29.setMatricula("");
        Carrinha carrinha32 = carrinha29.clone();
        carrinha29.setPrecoBase((double) 0L);
        Carrinha carrinha35 = new Carrinha();
        int i36 = carrinha35.getLugares();
        int i37 = carrinha29.compareTo((Veiculo) carrinha35);
        java.lang.String str38 = carrinha35.toString();
        Coordenada coordenada39 = carrinha35.getCoordenadas();
        carrinha18.setCoordenadas(coordenada39);
        Carrinha carrinha42 = new Carrinha((-1), 10.0d, (int) (byte) 1, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada39, true);
        int i43 = carrinha1.compareTo((Veiculo) carrinha42);
        carrinha42.setOcupado(false);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertTrue(i22 == 0);
        org.junit.Assert.assertTrue(b27 == false);
        org.junit.Assert.assertTrue(b28 == false);
        org.junit.Assert.assertNotNull(carrinha32);
        org.junit.Assert.assertTrue(i36 == 0);
        org.junit.Assert.assertTrue(i37 == 3);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str38.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada39);
        org.junit.Assert.assertTrue(i43 == (-33));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha5 = new Carrinha(carrinha0);
        double d6 = carrinha0.getPrecoBase();
        boolean b7 = carrinha0.getOcupado();
        carrinha0.setOcupado(true);
        carrinha0.setPrecoBase((-1.0d));
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(b7 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        Carrinha carrinha8 = new Carrinha();
        carrinha8.setMatricula("");
        Carrinha carrinha11 = carrinha8.clone();
        carrinha8.setPrecoBase((double) 0L);
        Carrinha carrinha14 = new Carrinha();
        int i15 = carrinha14.getLugares();
        int i16 = carrinha8.compareTo((Veiculo) carrinha14);
        java.lang.String str17 = carrinha14.toString();
        Coordenada coordenada18 = carrinha14.getCoordenadas();
        Carrinha carrinha20 = new Carrinha((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, false);
        Carrinha carrinha22 = new Carrinha((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, true);
        carrinha22.setFiabilidade(0);
        carrinha22.setVelocidadeMedia((int) 'a');
        org.junit.Assert.assertNotNull(carrinha11);
        org.junit.Assert.assertTrue(i15 == 0);
        org.junit.Assert.assertTrue(i16 == 3);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str17.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada18);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        Carrinha carrinha4 = new Carrinha();
        carrinha4.setMatricula("");
        boolean b8 = carrinha4.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha9 = new Carrinha(carrinha4);
        int i10 = carrinha9.getVelocidadeMedia();
        Carrinha carrinha11 = new Carrinha();
        Carrinha carrinha12 = new Carrinha(carrinha11);
        Carrinha carrinha13 = new Carrinha(carrinha12);
        Carrinha carrinha14 = new Carrinha();
        Carrinha carrinha15 = new Carrinha(carrinha14);
        int i16 = carrinha12.compareTo((Veiculo) carrinha14);
        Carrinha carrinha17 = new Carrinha();
        carrinha17.setMatricula("");
        boolean b21 = carrinha17.equals((java.lang.Object) (-1.0d));
        boolean b22 = carrinha12.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada23 = carrinha12.getCoordenadas();
        carrinha9.setCoordenadas(coordenada23);
        int i25 = carrinha9.getLugares();
        Coordenada coordenada26 = carrinha9.getCoordenadas();
        Carrinha carrinha28 = new Carrinha((-1), 10.0d, (-145), "Matrícula: hi!\nVelocidade Média/km: 0km/h\nPreço Base: 10.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada26, false);
        org.junit.Assert.assertTrue(b8 == false);
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue(b21 == false);
        org.junit.Assert.assertTrue(b22 == false);
        org.junit.Assert.assertNotNull(coordenada23);
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertNotNull(coordenada26);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        Carrinha carrinha4 = new Carrinha(carrinha0);
        Carrinha carrinha5 = new Carrinha(carrinha4);
        int i6 = carrinha5.getFiabilidade();
        carrinha5.setPrecoBase((double) 0);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i6 == 0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha(carrinha0);
        carrinha6.setPrecoBase((double) (-1.0f));
        carrinha6.setVelocidadeMedia((int) (short) 0);
        carrinha6.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Carrinha carrinha13 = new Carrinha();
        int i14 = carrinha13.getLugares();
        carrinha13.setVelocidadeMedia(10);
        Carrinha carrinha17 = new Carrinha(carrinha13);
        Carrinha carrinha18 = carrinha17.clone();
        int i19 = carrinha6.compareTo((Veiculo) carrinha18);
        int i20 = carrinha18.getFiabilidade();
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertNotNull(carrinha18);
        org.junit.Assert.assertTrue(i19 == 33);
        org.junit.Assert.assertTrue(i20 == 0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        Carrinha carrinha9 = new Carrinha();
        carrinha9.setMatricula("");
        Carrinha carrinha12 = carrinha9.clone();
        carrinha9.setPrecoBase((double) 0L);
        Carrinha carrinha15 = new Carrinha();
        int i16 = carrinha15.getLugares();
        int i17 = carrinha9.compareTo((Veiculo) carrinha15);
        java.lang.String str18 = carrinha15.toString();
        Coordenada coordenada19 = carrinha15.getCoordenadas();
        Carrinha carrinha20 = new Carrinha();
        int i21 = carrinha20.getLugares();
        Coordenada coordenada22 = carrinha20.getCoordenadas();
        carrinha15.setCoordenadas(coordenada22);
        Carrinha carrinha24 = new Carrinha(carrinha15);
        int i25 = carrinha0.compareTo((Veiculo) carrinha15);
        boolean b26 = carrinha15.getOcupado();
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertNotNull(carrinha12);
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue(i17 == 3);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str18.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada19);
        org.junit.Assert.assertTrue(i21 == 0);
        org.junit.Assert.assertNotNull(coordenada22);
        org.junit.Assert.assertTrue(i25 == 3);
        org.junit.Assert.assertTrue(b26 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        int i9 = carrinha6.getFiabilidade();
        Carrinha carrinha10 = carrinha6.clone();
        carrinha6.setFiabilidade((int) (short) 1);
        carrinha6.setPrecoBase(10.0d);
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertNotNull(carrinha10);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha3.setOcupado(true);
        int i6 = carrinha3.getFiabilidade();
        int i7 = carrinha3.getFiabilidade();
        carrinha3.setVelocidadeMedia(10);
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertTrue(i7 == 0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        int i4 = carrinha3.getFiabilidade();
        Carrinha carrinha5 = carrinha3.clone();
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertNotNull(carrinha5);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        carrinha0.setMatricula("n/a");
        carrinha0.setMatricula("Matrícula: hi!\nVelocidade Média/km: 0km/h\nPreço Base: 10.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        java.lang.String str6 = carrinha0.getMatricula();
        Coordenada coordenada7 = carrinha0.getCoordenadas();
        carrinha0.setOcupado(true);
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(coordenada7);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        Carrinha carrinha4 = carrinha0.clone();
        Carrinha carrinha5 = new Carrinha(carrinha0);
        Carrinha carrinha6 = new Carrinha(carrinha5);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(carrinha4);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        java.lang.String str2 = carrinha0.toString();
        carrinha0.setMatricula("hi!");
        carrinha0.setMatricula("Matrícula: \nVelocidade Média/km: -1km/h\nPreço Base: 0.0€\nFiabilidade: 1\nLugares: 9\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        Carrinha carrinha4 = new Carrinha();
        carrinha4.setMatricula("");
        Carrinha carrinha7 = carrinha4.clone();
        carrinha4.setPrecoBase((double) 0L);
        Carrinha carrinha10 = new Carrinha();
        int i11 = carrinha10.getLugares();
        int i12 = carrinha4.compareTo((Veiculo) carrinha10);
        java.lang.String str13 = carrinha10.toString();
        Coordenada coordenada14 = carrinha10.getCoordenadas();
        Carrinha carrinha16 = new Carrinha((int) ' ', (double) 100.0f, (int) (byte) -1, "", coordenada14, false);
        double d17 = carrinha16.getPrecoBase();
        java.lang.String str18 = carrinha16.getMatricula();
        org.junit.Assert.assertNotNull(carrinha7);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(i12 == 3);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str13.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada14);
        org.junit.Assert.assertTrue(d17 == 100.0d);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha5 = new Carrinha(carrinha0);
        double d6 = carrinha0.getPrecoBase();
        boolean b7 = carrinha0.getOcupado();
        int i8 = carrinha0.getVelocidadeMedia();
        java.lang.String str9 = carrinha0.getMatricula();
        Carrinha carrinha10 = new Carrinha();
        carrinha10.setMatricula("");
        boolean b14 = carrinha10.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha15 = new Carrinha(carrinha10);
        int i16 = carrinha0.compareTo((Veiculo) carrinha10);
        Carrinha carrinha17 = carrinha10.clone();
        carrinha10.setVelocidadeMedia((-33));
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(b7 == false);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertNotNull(carrinha17);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        Carrinha carrinha9 = new Carrinha(carrinha6);
        int i10 = carrinha9.getLugares();
        carrinha9.setPrecoBase((double) (-1));
        carrinha9.setPrecoBase((double) 1);
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue(i10 == 0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        java.lang.String str9 = carrinha6.toString();
        Coordenada coordenada10 = carrinha6.getCoordenadas();
        carrinha6.setFiabilidade((int) (byte) 1);
        int i13 = carrinha6.getVelocidadeMedia();
        Carrinha carrinha14 = new Carrinha();
        int i15 = carrinha14.getLugares();
        carrinha14.setVelocidadeMedia(10);
        Carrinha carrinha18 = new Carrinha(carrinha14);
        Carrinha carrinha19 = new Carrinha(carrinha18);
        int i20 = carrinha19.getFiabilidade();
        Carrinha carrinha21 = carrinha19.clone();
        carrinha21.setOcupado(false);
        Coordenada coordenada24 = carrinha21.getCoordenadas();
        carrinha6.setCoordenadas(coordenada24);
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(i15 == 0);
        org.junit.Assert.assertTrue(i20 == 0);
        org.junit.Assert.assertNotNull(carrinha21);
        org.junit.Assert.assertNotNull(coordenada24);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha(carrinha0);
        carrinha6.setPrecoBase((double) (-1.0f));
        carrinha6.setVelocidadeMedia((int) (short) 0);
        carrinha6.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Carrinha carrinha13 = new Carrinha(carrinha6);
        carrinha13.setVelocidadeMedia((int) (short) 10);
        org.junit.Assert.assertNotNull(carrinha3);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        java.lang.String str2 = carrinha0.toString();
        carrinha0.setFiabilidade(0);
        int i5 = carrinha0.getFiabilidade();
        Carrinha carrinha6 = new Carrinha(carrinha0);
        carrinha6.setPrecoBase((double) (-1));
        Carrinha carrinha9 = new Carrinha();
        carrinha9.setMatricula("");
        Carrinha carrinha12 = carrinha9.clone();
        carrinha9.setPrecoBase((double) 0L);
        Carrinha carrinha15 = new Carrinha();
        int i16 = carrinha15.getLugares();
        int i17 = carrinha9.compareTo((Veiculo) carrinha15);
        java.lang.String str18 = carrinha15.toString();
        Coordenada coordenada19 = carrinha15.getCoordenadas();
        Carrinha carrinha20 = new Carrinha();
        int i21 = carrinha20.getLugares();
        Coordenada coordenada22 = carrinha20.getCoordenadas();
        carrinha15.setCoordenadas(coordenada22);
        Carrinha carrinha24 = new Carrinha(carrinha15);
        int i25 = carrinha6.compareTo((Veiculo) carrinha15);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertNotNull(carrinha12);
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue(i17 == 3);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str18.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada19);
        org.junit.Assert.assertTrue(i21 == 0);
        org.junit.Assert.assertNotNull(coordenada22);
        org.junit.Assert.assertTrue(i25 == 0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        java.lang.String str9 = carrinha6.toString();
        int i10 = carrinha6.getFiabilidade();
        carrinha6.setPrecoBase(10.0d);
        int i13 = carrinha6.getVelocidadeMedia();
        Carrinha carrinha14 = new Carrinha(carrinha6);
        carrinha14.setFiabilidade((int) (short) 10);
        carrinha14.setVelocidadeMedia(0);
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i13 == 0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha5 = new Carrinha(carrinha0);
        double d6 = carrinha0.getPrecoBase();
        boolean b7 = carrinha0.getOcupado();
        int i8 = carrinha0.getVelocidadeMedia();
        Carrinha carrinha9 = carrinha0.clone();
        carrinha9.setFiabilidade((int) (byte) 10);
        carrinha9.setFiabilidade((int) (short) -1);
        carrinha9.setMatricula("hi!");
        Carrinha carrinha16 = new Carrinha(carrinha9);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(b7 == false);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertNotNull(carrinha9);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        Carrinha carrinha8 = new Carrinha();
        int i9 = carrinha8.getLugares();
        Coordenada coordenada10 = carrinha8.getCoordenadas();
        Carrinha carrinha12 = new Carrinha((int) (short) -1, (double) (byte) -1, (int) '4', "", coordenada10, true);
        Carrinha carrinha14 = new Carrinha(52, (double) (short) 10, (-3), "n/a", coordenada10, true);
        carrinha14.setVelocidadeMedia(9);
        java.lang.String str17 = carrinha14.getMatricula();
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "n/a" + "'", str17.equals("n/a"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        Coordenada coordenada2 = carrinha0.getCoordenadas();
        Carrinha carrinha3 = new Carrinha();
        Carrinha carrinha4 = new Carrinha(carrinha3);
        java.lang.String str5 = carrinha3.toString();
        carrinha3.setFiabilidade(0);
        Carrinha carrinha8 = carrinha3.clone();
        int i9 = carrinha3.getLugares();
        Carrinha carrinha14 = new Carrinha();
        Carrinha carrinha15 = new Carrinha(carrinha14);
        Carrinha carrinha16 = new Carrinha(carrinha15);
        Carrinha carrinha17 = new Carrinha();
        Carrinha carrinha18 = new Carrinha(carrinha17);
        int i19 = carrinha15.compareTo((Veiculo) carrinha17);
        Carrinha carrinha20 = new Carrinha();
        carrinha20.setMatricula("");
        boolean b24 = carrinha20.equals((java.lang.Object) (-1.0d));
        boolean b25 = carrinha15.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha26 = new Carrinha();
        carrinha26.setMatricula("");
        Carrinha carrinha29 = carrinha26.clone();
        carrinha26.setPrecoBase((double) 0L);
        Carrinha carrinha32 = new Carrinha();
        int i33 = carrinha32.getLugares();
        int i34 = carrinha26.compareTo((Veiculo) carrinha32);
        java.lang.String str35 = carrinha32.toString();
        Coordenada coordenada36 = carrinha32.getCoordenadas();
        carrinha15.setCoordenadas(coordenada36);
        Carrinha carrinha39 = new Carrinha((-1), 10.0d, (int) (byte) 1, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada36, true);
        carrinha3.setCoordenadas(coordenada36);
        int i41 = carrinha0.compareTo((Veiculo) carrinha3);
        Coordenada coordenada42 = carrinha3.getCoordenadas();
        int i43 = carrinha3.getFiabilidade();
        Carrinha carrinha44 = carrinha3.clone();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(coordenada2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str5.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha8);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertTrue(i19 == 0);
        org.junit.Assert.assertTrue(b24 == false);
        org.junit.Assert.assertTrue(b25 == false);
        org.junit.Assert.assertNotNull(carrinha29);
        org.junit.Assert.assertTrue(i33 == 0);
        org.junit.Assert.assertTrue(i34 == 3);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str35.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada36);
        org.junit.Assert.assertTrue(i41 == 0);
        org.junit.Assert.assertNotNull(coordenada42);
        org.junit.Assert.assertTrue(i43 == 0);
        org.junit.Assert.assertNotNull(carrinha44);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        Carrinha carrinha4 = new Carrinha(carrinha0);
        int i5 = carrinha0.getVelocidadeMedia();
        java.lang.String str6 = carrinha0.getMatricula();
        carrinha0.setVelocidadeMedia((int) (byte) 1);
        carrinha0.setOcupado(false);
        carrinha0.setOcupado(false);
        boolean b13 = carrinha0.getOcupado();
        java.lang.String str14 = carrinha0.getMatricula();
        carrinha0.setVelocidadeMedia((-33));
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i5 == 10);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "n/a" + "'", str6.equals("n/a"));
        org.junit.Assert.assertTrue(b13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "n/a" + "'", str14.equals("n/a"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        java.lang.String str2 = carrinha0.getMatricula();
        Carrinha carrinha3 = new Carrinha(carrinha0);
        int i4 = carrinha3.getFiabilidade();
        carrinha3.setFiabilidade((int) (byte) 1);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "n/a" + "'", str2.equals("n/a"));
        org.junit.Assert.assertTrue(i4 == 0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        Carrinha carrinha4 = new Carrinha();
        carrinha4.setMatricula("");
        Carrinha carrinha7 = carrinha4.clone();
        carrinha4.setPrecoBase((double) 0L);
        Carrinha carrinha10 = new Carrinha(carrinha4);
        Coordenada coordenada11 = carrinha4.getCoordenadas();
        Carrinha carrinha13 = new Carrinha((int) (byte) 100, (double) (byte) 1, 0, "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada11, false);
        java.lang.String str14 = carrinha13.toString();
        org.junit.Assert.assertNotNull(carrinha7);
        org.junit.Assert.assertNotNull(coordenada11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Matrícula: Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 100km/h\nPreço Base: 1.0€\nFiabilidade: 0\nLugares: 9\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str14.equals("Matrícula: Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 100km/h\nPreço Base: 1.0€\nFiabilidade: 0\nLugares: 9\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        Carrinha carrinha4 = new Carrinha();
        carrinha4.setMatricula("");
        boolean b8 = carrinha4.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada9 = carrinha4.getCoordenadas();
        boolean b10 = carrinha4.getOcupado();
        java.lang.String str11 = carrinha4.getMatricula();
        Carrinha carrinha16 = new Carrinha();
        carrinha16.setMatricula("");
        Carrinha carrinha19 = carrinha16.clone();
        carrinha16.setPrecoBase((double) 0L);
        Carrinha carrinha22 = new Carrinha();
        int i23 = carrinha22.getLugares();
        int i24 = carrinha16.compareTo((Veiculo) carrinha22);
        java.lang.String str25 = carrinha22.toString();
        Coordenada coordenada26 = carrinha22.getCoordenadas();
        Carrinha carrinha28 = new Carrinha((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada26, false);
        carrinha4.setCoordenadas(coordenada26);
        Carrinha carrinha30 = new Carrinha();
        carrinha30.setMatricula("");
        Carrinha carrinha33 = carrinha30.clone();
        carrinha30.setPrecoBase((double) 0L);
        Carrinha carrinha36 = new Carrinha();
        int i37 = carrinha36.getLugares();
        int i38 = carrinha30.compareTo((Veiculo) carrinha36);
        int i39 = carrinha36.getFiabilidade();
        Carrinha carrinha40 = carrinha36.clone();
        Coordenada coordenada41 = carrinha40.getCoordenadas();
        carrinha4.setCoordenadas(coordenada41);
        Carrinha carrinha44 = new Carrinha((-1), (double) (-142), 0, "Matrícula: \nVelocidade Média/km: -1km/h\nPreço Base: 0.0€\nFiabilidade: 1\nLugares: 9\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada41, true);
        org.junit.Assert.assertTrue(b8 == false);
        org.junit.Assert.assertNotNull(coordenada9);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(carrinha19);
        org.junit.Assert.assertTrue(i23 == 0);
        org.junit.Assert.assertTrue(i24 == 3);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str25.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada26);
        org.junit.Assert.assertNotNull(carrinha33);
        org.junit.Assert.assertTrue(i37 == 0);
        org.junit.Assert.assertTrue(i38 == 3);
        org.junit.Assert.assertTrue(i39 == 0);
        org.junit.Assert.assertNotNull(carrinha40);
        org.junit.Assert.assertNotNull(coordenada41);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        Carrinha carrinha4 = new Carrinha(carrinha0);
        int i5 = carrinha0.getVelocidadeMedia();
        java.lang.String str6 = carrinha0.getMatricula();
        Carrinha carrinha7 = new Carrinha(carrinha0);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i5 == 10);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "n/a" + "'", str6.equals("n/a"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        carrinha0.setMatricula("n/a");
        Carrinha carrinha6 = new Carrinha();
        carrinha6.setMatricula("");
        Carrinha carrinha9 = carrinha6.clone();
        carrinha6.setPrecoBase((double) 0L);
        Carrinha carrinha12 = new Carrinha();
        int i13 = carrinha12.getLugares();
        int i14 = carrinha6.compareTo((Veiculo) carrinha12);
        java.lang.String str15 = carrinha12.toString();
        Coordenada coordenada16 = carrinha12.getCoordenadas();
        Carrinha carrinha17 = new Carrinha();
        int i18 = carrinha17.getLugares();
        Coordenada coordenada19 = carrinha17.getCoordenadas();
        carrinha12.setCoordenadas(coordenada19);
        carrinha0.setCoordenadas(coordenada19);
        carrinha0.setPrecoBase((double) (-1L));
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(carrinha9);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(i14 == 3);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str15.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada16);
        org.junit.Assert.assertTrue(i18 == 0);
        org.junit.Assert.assertNotNull(coordenada19);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        Carrinha carrinha12 = new Carrinha();
        carrinha12.setMatricula("");
        Carrinha carrinha15 = carrinha12.clone();
        carrinha12.setPrecoBase((double) 0L);
        Carrinha carrinha18 = new Carrinha();
        int i19 = carrinha18.getLugares();
        int i20 = carrinha12.compareTo((Veiculo) carrinha18);
        java.lang.String str21 = carrinha18.toString();
        Coordenada coordenada22 = carrinha18.getCoordenadas();
        Carrinha carrinha24 = new Carrinha((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada22, false);
        Carrinha carrinha26 = new Carrinha((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada22, true);
        Carrinha carrinha28 = new Carrinha((int) '#', 10.0d, (-1), "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada22, true);
        carrinha28.setMatricula("hi!");
        carrinha28.setFiabilidade((int) (byte) 0);
        org.junit.Assert.assertNotNull(carrinha15);
        org.junit.Assert.assertTrue(i19 == 0);
        org.junit.Assert.assertTrue(i20 == 3);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str21.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada22);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setVelocidadeMedia((int) ' ');
        java.lang.String str3 = carrinha0.toString();
        Carrinha carrinha8 = new Carrinha();
        carrinha8.setMatricula("");
        Carrinha carrinha11 = carrinha8.clone();
        Coordenada coordenada12 = carrinha11.getCoordenadas();
        Carrinha carrinha14 = new Carrinha((int) (byte) 0, (double) 'a', 3, "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada12, false);
        boolean b15 = carrinha0.equals((java.lang.Object) 'a');
        boolean b16 = carrinha0.getOcupado();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha11);
        org.junit.Assert.assertNotNull(coordenada12);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertTrue(b16 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setVelocidadeMedia((int) ' ');
        java.lang.String str3 = carrinha0.toString();
        Carrinha carrinha8 = new Carrinha();
        carrinha8.setMatricula("");
        Carrinha carrinha11 = carrinha8.clone();
        Coordenada coordenada12 = carrinha11.getCoordenadas();
        Carrinha carrinha14 = new Carrinha((int) (byte) 0, (double) 'a', 3, "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada12, false);
        boolean b15 = carrinha0.equals((java.lang.Object) 'a');
        carrinha0.setOcupado(false);
        double d18 = carrinha0.getPrecoBase();
        Carrinha carrinha19 = new Carrinha();
        carrinha19.setMatricula("");
        boolean b23 = carrinha19.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada24 = carrinha19.getCoordenadas();
        carrinha19.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Carrinha carrinha27 = new Carrinha(carrinha19);
        int i28 = carrinha0.compareTo((Veiculo) carrinha19);
        carrinha0.setPrecoBase((double) (short) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha11);
        org.junit.Assert.assertNotNull(coordenada12);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertTrue(d18 == 0.0d);
        org.junit.Assert.assertTrue(b23 == false);
        org.junit.Assert.assertNotNull(coordenada24);
        org.junit.Assert.assertTrue(i28 == (-33));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        carrinha0.setMatricula("n/a");
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        Coordenada coordenada8 = carrinha6.getCoordenadas();
        boolean b9 = carrinha0.equals((java.lang.Object) coordenada8);
        carrinha0.setFiabilidade((int) (byte) -1);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertNotNull(coordenada8);
        org.junit.Assert.assertTrue(b9 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        Carrinha carrinha8 = new Carrinha();
        carrinha8.setMatricula("");
        java.lang.String str11 = carrinha8.toString();
        Carrinha carrinha12 = new Carrinha();
        Carrinha carrinha13 = new Carrinha(carrinha12);
        java.lang.String str14 = carrinha12.toString();
        carrinha12.setFiabilidade(0);
        Carrinha carrinha17 = carrinha12.clone();
        Carrinha carrinha18 = new Carrinha();
        Carrinha carrinha19 = new Carrinha(carrinha18);
        Carrinha carrinha20 = new Carrinha(carrinha19);
        Carrinha carrinha21 = new Carrinha();
        Carrinha carrinha22 = new Carrinha(carrinha21);
        int i23 = carrinha19.compareTo((Veiculo) carrinha21);
        Carrinha carrinha24 = new Carrinha();
        carrinha24.setMatricula("");
        boolean b28 = carrinha24.equals((java.lang.Object) (-1.0d));
        boolean b29 = carrinha19.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha30 = new Carrinha();
        carrinha30.setMatricula("");
        Carrinha carrinha33 = carrinha30.clone();
        carrinha30.setPrecoBase((double) 0L);
        Carrinha carrinha36 = new Carrinha();
        int i37 = carrinha36.getLugares();
        int i38 = carrinha30.compareTo((Veiculo) carrinha36);
        java.lang.String str39 = carrinha36.toString();
        Coordenada coordenada40 = carrinha36.getCoordenadas();
        carrinha19.setCoordenadas(coordenada40);
        carrinha12.setCoordenadas(coordenada40);
        carrinha8.setCoordenadas(coordenada40);
        Carrinha carrinha45 = new Carrinha((int) '4', (double) 1.0f, 9, "hi!", coordenada40, false);
        Carrinha carrinha47 = new Carrinha((int) (byte) 10, (double) 'a', (int) (short) 0, "hi!", coordenada40, true);
        java.lang.String str48 = carrinha47.getMatricula();
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str11.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str14.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha17);
        org.junit.Assert.assertTrue(i23 == 0);
        org.junit.Assert.assertTrue(b28 == false);
        org.junit.Assert.assertTrue(b29 == false);
        org.junit.Assert.assertNotNull(carrinha33);
        org.junit.Assert.assertTrue(i37 == 0);
        org.junit.Assert.assertTrue(i38 == 3);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str39.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada40);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "hi!" + "'", str48.equals("hi!"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        Carrinha carrinha4 = new Carrinha();
        carrinha4.setMatricula("");
        boolean b8 = carrinha4.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada9 = carrinha4.getCoordenadas();
        boolean b10 = carrinha4.getOcupado();
        java.lang.String str11 = carrinha4.getMatricula();
        Carrinha carrinha16 = new Carrinha();
        carrinha16.setMatricula("");
        Carrinha carrinha19 = carrinha16.clone();
        carrinha16.setPrecoBase((double) 0L);
        Carrinha carrinha22 = new Carrinha();
        int i23 = carrinha22.getLugares();
        int i24 = carrinha16.compareTo((Veiculo) carrinha22);
        java.lang.String str25 = carrinha22.toString();
        Coordenada coordenada26 = carrinha22.getCoordenadas();
        Carrinha carrinha28 = new Carrinha((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada26, false);
        carrinha4.setCoordenadas(coordenada26);
        Carrinha carrinha31 = new Carrinha(32, (double) (short) 1, (int) (byte) 1, "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada26, true);
        Carrinha carrinha32 = new Carrinha();
        int i33 = carrinha32.getLugares();
        Coordenada coordenada34 = carrinha32.getCoordenadas();
        int i35 = carrinha31.compareTo((Veiculo) carrinha32);
        org.junit.Assert.assertTrue(b8 == false);
        org.junit.Assert.assertNotNull(coordenada9);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(carrinha19);
        org.junit.Assert.assertTrue(i23 == 0);
        org.junit.Assert.assertTrue(i24 == 3);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str25.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada26);
        org.junit.Assert.assertTrue(i33 == 0);
        org.junit.Assert.assertNotNull(coordenada34);
        org.junit.Assert.assertTrue(i35 == 33);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        Carrinha carrinha4 = new Carrinha();
        Carrinha carrinha5 = new Carrinha(carrinha4);
        Carrinha carrinha6 = new Carrinha(carrinha5);
        Carrinha carrinha7 = new Carrinha();
        int i8 = carrinha7.getLugares();
        boolean b9 = carrinha6.equals((java.lang.Object) carrinha7);
        Carrinha carrinha10 = carrinha7.clone();
        Coordenada coordenada11 = carrinha7.getCoordenadas();
        Carrinha carrinha13 = new Carrinha((int) (short) 0, 100.0d, (int) (short) -1, "Matrícula: Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: -1.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada11, true);
        carrinha13.setPrecoBase((double) 'a');
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue(b9 == true);
        org.junit.Assert.assertNotNull(carrinha10);
        org.junit.Assert.assertNotNull(coordenada11);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setVelocidadeMedia((int) ' ');
        java.lang.String str3 = carrinha0.toString();
        Carrinha carrinha8 = new Carrinha();
        carrinha8.setMatricula("");
        Carrinha carrinha11 = carrinha8.clone();
        Coordenada coordenada12 = carrinha11.getCoordenadas();
        Carrinha carrinha14 = new Carrinha((int) (byte) 0, (double) 'a', 3, "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada12, false);
        boolean b15 = carrinha0.equals((java.lang.Object) 'a');
        int i16 = carrinha0.getFiabilidade();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha11);
        org.junit.Assert.assertNotNull(coordenada12);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertTrue(i16 == 0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        java.lang.String str3 = carrinha0.toString();
        Carrinha carrinha4 = carrinha0.clone();
        carrinha4.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha4);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        java.lang.String str3 = carrinha0.toString();
        Carrinha carrinha4 = carrinha0.clone();
        int i5 = carrinha0.getLugares();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha4);
        org.junit.Assert.assertTrue(i5 == 0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        java.lang.String str2 = carrinha0.toString();
        carrinha0.setFiabilidade(0);
        int i5 = carrinha0.getFiabilidade();
        Carrinha carrinha6 = new Carrinha(carrinha0);
        Carrinha carrinha7 = carrinha0.clone();
        carrinha0.setOcupado(false);
        Carrinha carrinha10 = new Carrinha();
        carrinha10.setMatricula("");
        Carrinha carrinha13 = carrinha10.clone();
        carrinha10.setPrecoBase((double) 0L);
        java.lang.String str16 = carrinha10.getMatricula();
        Coordenada coordenada17 = carrinha10.getCoordenadas();
        carrinha0.setCoordenadas(coordenada17);
        carrinha0.setMatricula("Matrícula: Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 97.0€\nFiabilidade: 1\nLugares: 9\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertNotNull(carrinha7);
        org.junit.Assert.assertNotNull(carrinha13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(coordenada17);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha(carrinha0);
        carrinha6.setPrecoBase((double) (-1.0f));
        carrinha6.setVelocidadeMedia((int) (short) 0);
        carrinha6.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        java.lang.String str13 = carrinha6.toString();
        carrinha6.setPrecoBase((double) 0);
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Matrícula: Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: -1.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str13.equals("Matrícula: Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: -1.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        Carrinha carrinha4 = new Carrinha(carrinha0);
        java.lang.String str5 = carrinha0.toString();
        carrinha0.setOcupado(false);
        Coordenada coordenada8 = null;
        try {
            carrinha0.setCoordenadas(coordenada8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str5.equals("Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        Carrinha carrinha4 = new Carrinha();
        carrinha4.setMatricula("");
        boolean b8 = carrinha4.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha9 = new Carrinha(carrinha4);
        Coordenada coordenada10 = carrinha9.getCoordenadas();
        Carrinha carrinha12 = new Carrinha((int) (short) 0, (double) 1L, (int) (byte) 1, "hi!", coordenada10, false);
        org.junit.Assert.assertTrue(b8 == false);
        org.junit.Assert.assertNotNull(coordenada10);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        java.lang.String str9 = carrinha6.toString();
        int i10 = carrinha6.getFiabilidade();
        Carrinha carrinha11 = new Carrinha();
        Carrinha carrinha12 = new Carrinha(carrinha11);
        Carrinha carrinha13 = new Carrinha(carrinha12);
        Carrinha carrinha14 = new Carrinha();
        Carrinha carrinha15 = new Carrinha(carrinha14);
        int i16 = carrinha12.compareTo((Veiculo) carrinha14);
        Carrinha carrinha17 = new Carrinha();
        carrinha17.setMatricula("");
        boolean b21 = carrinha17.equals((java.lang.Object) (-1.0d));
        boolean b22 = carrinha12.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha23 = new Carrinha();
        carrinha23.setMatricula("");
        Carrinha carrinha26 = carrinha23.clone();
        carrinha23.setPrecoBase((double) 0L);
        Carrinha carrinha29 = new Carrinha();
        int i30 = carrinha29.getLugares();
        int i31 = carrinha23.compareTo((Veiculo) carrinha29);
        java.lang.String str32 = carrinha29.toString();
        Coordenada coordenada33 = carrinha29.getCoordenadas();
        carrinha12.setCoordenadas(coordenada33);
        boolean b35 = carrinha6.equals((java.lang.Object) carrinha12);
        boolean b36 = carrinha6.getOcupado();
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue(b21 == false);
        org.junit.Assert.assertTrue(b22 == false);
        org.junit.Assert.assertNotNull(carrinha26);
        org.junit.Assert.assertTrue(i30 == 0);
        org.junit.Assert.assertTrue(i31 == 3);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str32.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada33);
        org.junit.Assert.assertTrue(b35 == true);
        org.junit.Assert.assertTrue(b36 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha();
        Carrinha carrinha2 = new Carrinha(carrinha1);
        int i3 = carrinha2.getFiabilidade();
        Coordenada coordenada4 = carrinha2.getCoordenadas();
        carrinha0.setCoordenadas(coordenada4);
        Carrinha carrinha6 = new Carrinha();
        Carrinha carrinha7 = new Carrinha(carrinha6);
        java.lang.String str8 = carrinha6.toString();
        carrinha6.setFiabilidade(0);
        int i11 = carrinha6.getFiabilidade();
        Carrinha carrinha12 = new Carrinha();
        Carrinha carrinha13 = new Carrinha(carrinha12);
        java.lang.String str14 = carrinha12.toString();
        carrinha12.setFiabilidade(0);
        Carrinha carrinha17 = carrinha12.clone();
        Carrinha carrinha18 = new Carrinha(carrinha12);
        Coordenada coordenada19 = carrinha12.getCoordenadas();
        carrinha6.setCoordenadas(coordenada19);
        carrinha0.setCoordenadas(coordenada19);
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertNotNull(coordenada4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str8.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str14.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha17);
        org.junit.Assert.assertNotNull(coordenada19);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha5 = new Carrinha(carrinha0);
        double d6 = carrinha0.getPrecoBase();
        int i7 = carrinha0.getLugares();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(i7 == 0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carrinha0.getCoordenadas();
        carrinha0.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carrinha0.setFiabilidade(0);
        Carrinha carrinha10 = new Carrinha();
        carrinha10.setMatricula("");
        Carrinha carrinha13 = carrinha10.clone();
        carrinha10.setPrecoBase((double) 0L);
        Carrinha carrinha16 = new Carrinha(carrinha10);
        int i17 = carrinha0.compareTo((Veiculo) carrinha10);
        Carrinha carrinha18 = new Carrinha(carrinha10);
        carrinha18.setOcupado(false);
        java.lang.String str21 = carrinha18.getMatricula();
        carrinha18.setFiabilidade((int) (short) 10);
        carrinha18.setPrecoBase((double) 10.0f);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertNotNull(carrinha13);
        org.junit.Assert.assertTrue(i17 == (-142));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        int i9 = carrinha6.getFiabilidade();
        Carrinha carrinha10 = carrinha6.clone();
        Coordenada coordenada11 = carrinha10.getCoordenadas();
        carrinha10.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n");
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertNotNull(carrinha10);
        org.junit.Assert.assertNotNull(coordenada11);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        carrinha0.setMatricula("n/a");
        carrinha0.setPrecoBase((double) 1L);
        Coordenada coordenada8 = carrinha0.getCoordenadas();
        Carrinha carrinha9 = new Carrinha();
        carrinha9.setMatricula("");
        boolean b13 = carrinha9.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada14 = carrinha9.getCoordenadas();
        carrinha9.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carrinha9.setFiabilidade(0);
        Carrinha carrinha19 = new Carrinha();
        carrinha19.setMatricula("");
        Carrinha carrinha22 = carrinha19.clone();
        carrinha19.setPrecoBase((double) 0L);
        Carrinha carrinha25 = new Carrinha(carrinha19);
        int i26 = carrinha9.compareTo((Veiculo) carrinha19);
        Carrinha carrinha27 = new Carrinha(carrinha19);
        boolean b28 = carrinha0.equals((java.lang.Object) carrinha27);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(coordenada8);
        org.junit.Assert.assertTrue(b13 == false);
        org.junit.Assert.assertNotNull(coordenada14);
        org.junit.Assert.assertNotNull(carrinha22);
        org.junit.Assert.assertTrue(i26 == (-142));
        org.junit.Assert.assertTrue(b28 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setVelocidadeMedia((int) ' ');
        java.lang.String str3 = carrinha0.toString();
        Carrinha carrinha8 = new Carrinha();
        carrinha8.setMatricula("");
        Carrinha carrinha11 = carrinha8.clone();
        Coordenada coordenada12 = carrinha11.getCoordenadas();
        Carrinha carrinha14 = new Carrinha((int) (byte) 0, (double) 'a', 3, "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada12, false);
        boolean b15 = carrinha0.equals((java.lang.Object) 'a');
        carrinha0.setOcupado(false);
        double d18 = carrinha0.getPrecoBase();
        carrinha0.setVelocidadeMedia((int) (byte) 100);
        int i21 = carrinha0.getFiabilidade();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha11);
        org.junit.Assert.assertNotNull(coordenada12);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertTrue(d18 == 0.0d);
        org.junit.Assert.assertTrue(i21 == 0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carrinha0.getCoordenadas();
        carrinha0.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carrinha0.setFiabilidade(0);
        carrinha0.setVelocidadeMedia((int) (short) -1);
        carrinha0.setFiabilidade((int) (short) 1);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        java.lang.String str2 = carrinha0.toString();
        carrinha0.setMatricula("hi!");
        carrinha0.setPrecoBase((double) 10.0f);
        carrinha0.setOcupado(true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        int i2 = carrinha0.getLugares();
        Carrinha carrinha3 = carrinha0.clone();
        Carrinha carrinha4 = carrinha0.clone();
        java.lang.String str5 = carrinha4.getMatricula();
        org.junit.Assert.assertTrue(i2 == 0);
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertNotNull(carrinha4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "n/a" + "'", str5.equals("n/a"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        int i4 = carrinha3.getVelocidadeMedia();
        java.lang.Object obj5 = null;
        boolean b6 = carrinha3.equals(obj5);
        carrinha3.setMatricula("Matrícula: Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: -1.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue(b6 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        Coordenada coordenada4 = carrinha3.getCoordenadas();
        Carrinha carrinha5 = new Carrinha();
        carrinha5.setMatricula("");
        Carrinha carrinha8 = carrinha5.clone();
        carrinha5.setPrecoBase((double) 0L);
        Carrinha carrinha11 = new Carrinha();
        int i12 = carrinha11.getLugares();
        int i13 = carrinha5.compareTo((Veiculo) carrinha11);
        java.lang.String str14 = carrinha11.toString();
        Coordenada coordenada15 = carrinha11.getCoordenadas();
        int i16 = carrinha3.compareTo((Veiculo) carrinha11);
        java.lang.String str17 = carrinha3.getMatricula();
        carrinha3.setPrecoBase((double) 10);
        java.lang.String str20 = carrinha3.getMatricula();
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertNotNull(coordenada4);
        org.junit.Assert.assertNotNull(carrinha8);
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertTrue(i13 == 3);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str14.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada15);
        org.junit.Assert.assertTrue(i16 == 3);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        Carrinha carrinha4 = new Carrinha(carrinha0);
        int i5 = carrinha0.getVelocidadeMedia();
        carrinha0.setMatricula("");
        int i8 = carrinha0.getFiabilidade();
        int i9 = carrinha0.getVelocidadeMedia();
        int i10 = carrinha0.getVelocidadeMedia();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i5 == 10);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue(i9 == 10);
        org.junit.Assert.assertTrue(i10 == 10);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha(carrinha0);
        carrinha6.setPrecoBase((double) (-1.0f));
        java.lang.String str9 = carrinha6.getMatricula();
        double d10 = carrinha6.getPrecoBase();
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue(d10 == (-1.0d));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carrinha0.getCoordenadas();
        java.lang.String str6 = carrinha0.toString();
        Carrinha carrinha7 = new Carrinha();
        carrinha7.setMatricula("");
        Carrinha carrinha10 = carrinha7.clone();
        carrinha7.setPrecoBase((double) 0L);
        Carrinha carrinha13 = new Carrinha();
        int i14 = carrinha13.getLugares();
        int i15 = carrinha7.compareTo((Veiculo) carrinha13);
        Carrinha carrinha16 = new Carrinha();
        carrinha16.setMatricula("");
        Carrinha carrinha19 = carrinha16.clone();
        carrinha16.setPrecoBase((double) 0L);
        Carrinha carrinha22 = new Carrinha();
        int i23 = carrinha22.getLugares();
        int i24 = carrinha16.compareTo((Veiculo) carrinha22);
        java.lang.String str25 = carrinha22.toString();
        Coordenada coordenada26 = carrinha22.getCoordenadas();
        Carrinha carrinha27 = new Carrinha();
        int i28 = carrinha27.getLugares();
        Coordenada coordenada29 = carrinha27.getCoordenadas();
        carrinha22.setCoordenadas(coordenada29);
        Carrinha carrinha31 = new Carrinha(carrinha22);
        int i32 = carrinha7.compareTo((Veiculo) carrinha22);
        int i33 = carrinha22.getFiabilidade();
        int i34 = carrinha0.compareTo((Veiculo) carrinha22);
        Coordenada coordenada35 = carrinha22.getCoordenadas();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str6.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha10);
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(i15 == 3);
        org.junit.Assert.assertNotNull(carrinha19);
        org.junit.Assert.assertTrue(i23 == 0);
        org.junit.Assert.assertTrue(i24 == 3);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str25.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada26);
        org.junit.Assert.assertTrue(i28 == 0);
        org.junit.Assert.assertNotNull(coordenada29);
        org.junit.Assert.assertTrue(i32 == 3);
        org.junit.Assert.assertTrue(i33 == 0);
        org.junit.Assert.assertTrue(i34 == 3);
        org.junit.Assert.assertNotNull(coordenada35);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        Carrinha carrinha4 = new Carrinha(carrinha0);
        carrinha4.setFiabilidade((int) (short) 100);
        double d7 = carrinha4.getPrecoBase();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(d7 == 0.0d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        Carrinha carrinha4 = new Carrinha();
        carrinha4.setMatricula("");
        Carrinha carrinha7 = carrinha4.clone();
        int i8 = carrinha7.getVelocidadeMedia();
        Coordenada coordenada9 = carrinha7.getCoordenadas();
        Carrinha carrinha11 = new Carrinha((-142), (double) 0, 1, "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada9, false);
        carrinha11.setVelocidadeMedia(3);
        org.junit.Assert.assertNotNull(carrinha7);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertNotNull(coordenada9);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        Carrinha carrinha4 = new Carrinha(carrinha3);
        int i5 = carrinha1.compareTo((Veiculo) carrinha3);
        Carrinha carrinha6 = new Carrinha();
        carrinha6.setMatricula("");
        boolean b10 = carrinha6.equals((java.lang.Object) (-1.0d));
        boolean b11 = carrinha1.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha12 = new Carrinha(carrinha1);
        Carrinha carrinha17 = new Carrinha();
        Carrinha carrinha18 = new Carrinha(carrinha17);
        Carrinha carrinha19 = new Carrinha(carrinha18);
        Carrinha carrinha20 = new Carrinha();
        Carrinha carrinha21 = new Carrinha(carrinha20);
        int i22 = carrinha18.compareTo((Veiculo) carrinha20);
        Carrinha carrinha23 = new Carrinha();
        carrinha23.setMatricula("");
        boolean b27 = carrinha23.equals((java.lang.Object) (-1.0d));
        boolean b28 = carrinha18.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha29 = new Carrinha();
        carrinha29.setMatricula("");
        Carrinha carrinha32 = carrinha29.clone();
        carrinha29.setPrecoBase((double) 0L);
        Carrinha carrinha35 = new Carrinha();
        int i36 = carrinha35.getLugares();
        int i37 = carrinha29.compareTo((Veiculo) carrinha35);
        java.lang.String str38 = carrinha35.toString();
        Coordenada coordenada39 = carrinha35.getCoordenadas();
        carrinha18.setCoordenadas(coordenada39);
        Carrinha carrinha42 = new Carrinha((-1), 10.0d, (int) (byte) 1, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada39, true);
        int i43 = carrinha1.compareTo((Veiculo) carrinha42);
        carrinha42.setVelocidadeMedia(100);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertTrue(i22 == 0);
        org.junit.Assert.assertTrue(b27 == false);
        org.junit.Assert.assertTrue(b28 == false);
        org.junit.Assert.assertNotNull(carrinha32);
        org.junit.Assert.assertTrue(i36 == 0);
        org.junit.Assert.assertTrue(i37 == 3);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str38.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada39);
        org.junit.Assert.assertTrue(i43 == (-33));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carrinha0.getCoordenadas();
        carrinha0.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carrinha0.setFiabilidade(0);
        int i10 = carrinha0.getVelocidadeMedia();
        Carrinha carrinha11 = new Carrinha();
        Carrinha carrinha12 = new Carrinha();
        Carrinha carrinha13 = new Carrinha(carrinha12);
        int i14 = carrinha13.getFiabilidade();
        Coordenada coordenada15 = carrinha13.getCoordenadas();
        carrinha11.setCoordenadas(coordenada15);
        boolean b17 = carrinha0.equals((java.lang.Object) carrinha11);
        java.lang.String str18 = carrinha11.toString();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertNotNull(coordenada15);
        org.junit.Assert.assertTrue(b17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str18.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        java.lang.String str2 = carrinha0.getMatricula();
        Carrinha carrinha3 = new Carrinha(carrinha0);
        int i4 = carrinha3.getFiabilidade();
        carrinha3.setPrecoBase(1.0d);
        Carrinha carrinha7 = new Carrinha();
        Carrinha carrinha8 = new Carrinha(carrinha7);
        Carrinha carrinha9 = new Carrinha(carrinha8);
        Carrinha carrinha10 = new Carrinha();
        Carrinha carrinha11 = new Carrinha(carrinha10);
        int i12 = carrinha8.compareTo((Veiculo) carrinha10);
        Carrinha carrinha13 = new Carrinha();
        carrinha13.setMatricula("");
        boolean b17 = carrinha13.equals((java.lang.Object) (-1.0d));
        boolean b18 = carrinha8.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha19 = new Carrinha(carrinha8);
        Carrinha carrinha20 = new Carrinha(carrinha8);
        boolean b21 = carrinha3.equals((java.lang.Object) carrinha8);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "n/a" + "'", str2.equals("n/a"));
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertTrue(b17 == false);
        org.junit.Assert.assertTrue(b18 == false);
        org.junit.Assert.assertTrue(b21 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carrinha0.getCoordenadas();
        boolean b6 = carrinha0.getOcupado();
        java.lang.String str7 = carrinha0.getMatricula();
        Carrinha carrinha12 = new Carrinha();
        carrinha12.setMatricula("");
        Carrinha carrinha15 = carrinha12.clone();
        carrinha12.setPrecoBase((double) 0L);
        Carrinha carrinha18 = new Carrinha();
        int i19 = carrinha18.getLugares();
        int i20 = carrinha12.compareTo((Veiculo) carrinha18);
        java.lang.String str21 = carrinha18.toString();
        Coordenada coordenada22 = carrinha18.getCoordenadas();
        Carrinha carrinha24 = new Carrinha((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada22, false);
        carrinha0.setCoordenadas(coordenada22);
        carrinha0.setOcupado(true);
        carrinha0.setOcupado(true);
        java.lang.String str30 = carrinha0.toString();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(b6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(carrinha15);
        org.junit.Assert.assertTrue(i19 == 0);
        org.junit.Assert.assertTrue(i20 == 3);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str21.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada22);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n" + "'", str30.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        java.lang.String str9 = carrinha6.toString();
        int i10 = carrinha6.getFiabilidade();
        carrinha6.setPrecoBase(10.0d);
        int i13 = carrinha6.getVelocidadeMedia();
        Carrinha carrinha18 = new Carrinha();
        Carrinha carrinha19 = new Carrinha(carrinha18);
        Carrinha carrinha20 = new Carrinha(carrinha19);
        Carrinha carrinha21 = new Carrinha();
        Carrinha carrinha22 = new Carrinha(carrinha21);
        int i23 = carrinha19.compareTo((Veiculo) carrinha21);
        Carrinha carrinha24 = new Carrinha();
        carrinha24.setMatricula("");
        boolean b28 = carrinha24.equals((java.lang.Object) (-1.0d));
        boolean b29 = carrinha19.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha30 = new Carrinha();
        carrinha30.setMatricula("");
        Carrinha carrinha33 = carrinha30.clone();
        carrinha30.setPrecoBase((double) 0L);
        Carrinha carrinha36 = new Carrinha();
        int i37 = carrinha36.getLugares();
        int i38 = carrinha30.compareTo((Veiculo) carrinha36);
        java.lang.String str39 = carrinha36.toString();
        Coordenada coordenada40 = carrinha36.getCoordenadas();
        carrinha19.setCoordenadas(coordenada40);
        Carrinha carrinha43 = new Carrinha((-1), 10.0d, (int) (byte) 1, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada40, true);
        carrinha6.setCoordenadas(coordenada40);
        carrinha6.setFiabilidade(0);
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(i23 == 0);
        org.junit.Assert.assertTrue(b28 == false);
        org.junit.Assert.assertTrue(b29 == false);
        org.junit.Assert.assertNotNull(carrinha33);
        org.junit.Assert.assertTrue(i37 == 0);
        org.junit.Assert.assertTrue(i38 == 3);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str39.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada40);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        java.lang.String str9 = carrinha6.toString();
        int i10 = carrinha6.getFiabilidade();
        carrinha6.setPrecoBase(10.0d);
        int i13 = carrinha6.getVelocidadeMedia();
        Carrinha carrinha14 = new Carrinha(carrinha6);
        carrinha14.setFiabilidade((int) (short) 10);
        java.lang.Object obj17 = null;
        boolean b18 = carrinha14.equals(obj17);
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(b18 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        int i9 = carrinha6.getFiabilidade();
        Carrinha carrinha10 = carrinha6.clone();
        Coordenada coordenada11 = carrinha10.getCoordenadas();
        carrinha10.setVelocidadeMedia(33);
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertNotNull(carrinha10);
        org.junit.Assert.assertNotNull(coordenada11);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha(carrinha0);
        carrinha6.setPrecoBase((double) (-1.0f));
        carrinha6.setVelocidadeMedia((int) (short) 0);
        carrinha6.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Carrinha carrinha13 = new Carrinha();
        int i14 = carrinha13.getLugares();
        carrinha13.setVelocidadeMedia(10);
        Carrinha carrinha17 = new Carrinha(carrinha13);
        Carrinha carrinha18 = carrinha17.clone();
        int i19 = carrinha6.compareTo((Veiculo) carrinha18);
        java.lang.String str20 = carrinha18.getMatricula();
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertNotNull(carrinha18);
        org.junit.Assert.assertTrue(i19 == 33);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "n/a" + "'", str20.equals("n/a"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carrinha0.getCoordenadas();
        int i6 = carrinha0.getVelocidadeMedia();
        Carrinha carrinha7 = new Carrinha();
        carrinha7.setMatricula("");
        Carrinha carrinha10 = carrinha7.clone();
        carrinha10.setOcupado(true);
        boolean b13 = carrinha0.equals((java.lang.Object) carrinha10);
        carrinha10.setMatricula("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Carrinha carrinha16 = new Carrinha();
        Carrinha carrinha17 = new Carrinha(carrinha16);
        java.lang.String str18 = carrinha16.toString();
        carrinha16.setFiabilidade(0);
        Carrinha carrinha21 = carrinha16.clone();
        int i22 = carrinha16.getLugares();
        Carrinha carrinha27 = new Carrinha();
        Carrinha carrinha28 = new Carrinha(carrinha27);
        Carrinha carrinha29 = new Carrinha(carrinha28);
        Carrinha carrinha30 = new Carrinha();
        Carrinha carrinha31 = new Carrinha(carrinha30);
        int i32 = carrinha28.compareTo((Veiculo) carrinha30);
        Carrinha carrinha33 = new Carrinha();
        carrinha33.setMatricula("");
        boolean b37 = carrinha33.equals((java.lang.Object) (-1.0d));
        boolean b38 = carrinha28.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha39 = new Carrinha();
        carrinha39.setMatricula("");
        Carrinha carrinha42 = carrinha39.clone();
        carrinha39.setPrecoBase((double) 0L);
        Carrinha carrinha45 = new Carrinha();
        int i46 = carrinha45.getLugares();
        int i47 = carrinha39.compareTo((Veiculo) carrinha45);
        java.lang.String str48 = carrinha45.toString();
        Coordenada coordenada49 = carrinha45.getCoordenadas();
        carrinha28.setCoordenadas(coordenada49);
        Carrinha carrinha52 = new Carrinha((-1), 10.0d, (int) (byte) 1, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada49, true);
        carrinha16.setCoordenadas(coordenada49);
        carrinha10.setCoordenadas(coordenada49);
        Carrinha carrinha55 = new Carrinha(carrinha10);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertNotNull(carrinha10);
        org.junit.Assert.assertTrue(b13 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str18.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha21);
        org.junit.Assert.assertTrue(i22 == 0);
        org.junit.Assert.assertTrue(i32 == 0);
        org.junit.Assert.assertTrue(b37 == false);
        org.junit.Assert.assertTrue(b38 == false);
        org.junit.Assert.assertNotNull(carrinha42);
        org.junit.Assert.assertTrue(i46 == 0);
        org.junit.Assert.assertTrue(i47 == 3);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str48.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada49);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        carrinha1.setMatricula("Matrícula: hi!\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: -1\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        Carrinha carrinha4 = new Carrinha();
        carrinha4.setMatricula("");
        Carrinha carrinha7 = carrinha4.clone();
        carrinha4.setPrecoBase((double) 0L);
        Carrinha carrinha10 = new Carrinha();
        int i11 = carrinha10.getLugares();
        int i12 = carrinha4.compareTo((Veiculo) carrinha10);
        java.lang.String str13 = carrinha10.toString();
        int i14 = carrinha10.getFiabilidade();
        Carrinha carrinha15 = new Carrinha();
        Carrinha carrinha16 = new Carrinha(carrinha15);
        java.lang.String str17 = carrinha15.toString();
        carrinha15.setFiabilidade(0);
        Carrinha carrinha20 = carrinha15.clone();
        int i21 = carrinha20.getFiabilidade();
        Coordenada coordenada22 = carrinha20.getCoordenadas();
        carrinha10.setCoordenadas(coordenada22);
        Carrinha carrinha25 = new Carrinha((int) 'a', (double) (short) -1, (int) (short) 0, "n/a", coordenada22, true);
        org.junit.Assert.assertNotNull(carrinha7);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(i12 == 3);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str13.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str17.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha20);
        org.junit.Assert.assertTrue(i21 == 0);
        org.junit.Assert.assertNotNull(coordenada22);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        int i4 = carrinha3.getLugares();
        boolean b5 = carrinha2.equals((java.lang.Object) carrinha3);
        int i6 = carrinha3.getFiabilidade();
        boolean b7 = carrinha3.getOcupado();
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue(b5 == true);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertTrue(b7 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        Carrinha carrinha4 = carrinha0.clone();
        int i5 = carrinha4.getLugares();
        Coordenada coordenada6 = carrinha4.getCoordenadas();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(carrinha4);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertNotNull(coordenada6);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        Carrinha carrinha4 = new Carrinha();
        carrinha4.setMatricula("");
        Carrinha carrinha7 = carrinha4.clone();
        carrinha4.setPrecoBase((double) 0L);
        Carrinha carrinha10 = new Carrinha();
        int i11 = carrinha10.getLugares();
        int i12 = carrinha4.compareTo((Veiculo) carrinha10);
        java.lang.String str13 = carrinha10.toString();
        Coordenada coordenada14 = carrinha10.getCoordenadas();
        Carrinha carrinha16 = new Carrinha((int) ' ', (double) 100.0f, (int) (byte) -1, "", coordenada14, false);
        int i17 = carrinha16.getLugares();
        org.junit.Assert.assertNotNull(carrinha7);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(i12 == 3);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str13.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada14);
        org.junit.Assert.assertTrue(i17 == 9);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        Carrinha carrinha4 = new Carrinha();
        carrinha4.setMatricula("");
        boolean b8 = carrinha4.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada9 = carrinha4.getCoordenadas();
        int i10 = carrinha4.getVelocidadeMedia();
        Carrinha carrinha11 = new Carrinha();
        carrinha11.setMatricula("");
        Carrinha carrinha14 = carrinha11.clone();
        carrinha14.setOcupado(true);
        boolean b17 = carrinha4.equals((java.lang.Object) carrinha14);
        carrinha14.setMatricula("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Carrinha carrinha20 = new Carrinha();
        Carrinha carrinha21 = new Carrinha(carrinha20);
        java.lang.String str22 = carrinha20.toString();
        carrinha20.setFiabilidade(0);
        Carrinha carrinha25 = carrinha20.clone();
        int i26 = carrinha20.getLugares();
        Carrinha carrinha31 = new Carrinha();
        Carrinha carrinha32 = new Carrinha(carrinha31);
        Carrinha carrinha33 = new Carrinha(carrinha32);
        Carrinha carrinha34 = new Carrinha();
        Carrinha carrinha35 = new Carrinha(carrinha34);
        int i36 = carrinha32.compareTo((Veiculo) carrinha34);
        Carrinha carrinha37 = new Carrinha();
        carrinha37.setMatricula("");
        boolean b41 = carrinha37.equals((java.lang.Object) (-1.0d));
        boolean b42 = carrinha32.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha43 = new Carrinha();
        carrinha43.setMatricula("");
        Carrinha carrinha46 = carrinha43.clone();
        carrinha43.setPrecoBase((double) 0L);
        Carrinha carrinha49 = new Carrinha();
        int i50 = carrinha49.getLugares();
        int i51 = carrinha43.compareTo((Veiculo) carrinha49);
        java.lang.String str52 = carrinha49.toString();
        Coordenada coordenada53 = carrinha49.getCoordenadas();
        carrinha32.setCoordenadas(coordenada53);
        Carrinha carrinha56 = new Carrinha((-1), 10.0d, (int) (byte) 1, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada53, true);
        carrinha20.setCoordenadas(coordenada53);
        carrinha14.setCoordenadas(coordenada53);
        Carrinha carrinha60 = new Carrinha((-145), (double) 1.0f, (int) (byte) -1, "Matrícula: Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 97.0€\nFiabilidade: 1\nLugares: 9\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada53, true);
        Carrinha carrinha61 = new Carrinha(carrinha60);
        org.junit.Assert.assertTrue(b8 == false);
        org.junit.Assert.assertNotNull(coordenada9);
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertNotNull(carrinha14);
        org.junit.Assert.assertTrue(b17 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str22.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha25);
        org.junit.Assert.assertTrue(i26 == 0);
        org.junit.Assert.assertTrue(i36 == 0);
        org.junit.Assert.assertTrue(b41 == false);
        org.junit.Assert.assertTrue(b42 == false);
        org.junit.Assert.assertNotNull(carrinha46);
        org.junit.Assert.assertTrue(i50 == 0);
        org.junit.Assert.assertTrue(i51 == 3);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str52.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada53);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha5 = new Carrinha(carrinha0);
        double d6 = carrinha0.getPrecoBase();
        java.lang.String str7 = carrinha0.toString();
        int i8 = carrinha0.getVelocidadeMedia();
        int i9 = carrinha0.getVelocidadeMedia();
        double d10 = carrinha0.getPrecoBase();
        Coordenada coordenada11 = carrinha0.getCoordenadas();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str7.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertTrue(d10 == 0.0d);
        org.junit.Assert.assertNotNull(coordenada11);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        Coordenada coordenada4 = carrinha3.getCoordenadas();
        Carrinha carrinha5 = new Carrinha();
        carrinha5.setMatricula("");
        Carrinha carrinha8 = carrinha5.clone();
        carrinha5.setPrecoBase((double) 0L);
        Carrinha carrinha11 = new Carrinha();
        int i12 = carrinha11.getLugares();
        int i13 = carrinha5.compareTo((Veiculo) carrinha11);
        java.lang.String str14 = carrinha11.toString();
        Coordenada coordenada15 = carrinha11.getCoordenadas();
        int i16 = carrinha3.compareTo((Veiculo) carrinha11);
        Carrinha carrinha17 = new Carrinha();
        carrinha17.setMatricula("");
        Carrinha carrinha20 = carrinha17.clone();
        carrinha17.setPrecoBase((double) 0L);
        java.lang.String str23 = carrinha17.getMatricula();
        Coordenada coordenada24 = carrinha17.getCoordenadas();
        carrinha3.setCoordenadas(coordenada24);
        carrinha3.setFiabilidade((int) (short) 1);
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertNotNull(coordenada4);
        org.junit.Assert.assertNotNull(carrinha8);
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertTrue(i13 == 3);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str14.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada15);
        org.junit.Assert.assertTrue(i16 == 3);
        org.junit.Assert.assertNotNull(carrinha20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertNotNull(coordenada24);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        java.lang.String str9 = carrinha6.toString();
        int i10 = carrinha6.getFiabilidade();
        carrinha6.setPrecoBase(10.0d);
        int i13 = carrinha6.getVelocidadeMedia();
        java.lang.String str14 = carrinha6.getMatricula();
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "n/a" + "'", str14.equals("n/a"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        Carrinha carrinha9 = new Carrinha();
        carrinha9.setMatricula("");
        Carrinha carrinha12 = carrinha9.clone();
        carrinha9.setPrecoBase((double) 0L);
        Carrinha carrinha15 = new Carrinha();
        int i16 = carrinha15.getLugares();
        int i17 = carrinha9.compareTo((Veiculo) carrinha15);
        java.lang.String str18 = carrinha15.toString();
        Coordenada coordenada19 = carrinha15.getCoordenadas();
        Carrinha carrinha20 = new Carrinha();
        int i21 = carrinha20.getLugares();
        Coordenada coordenada22 = carrinha20.getCoordenadas();
        carrinha15.setCoordenadas(coordenada22);
        Carrinha carrinha24 = new Carrinha(carrinha15);
        int i25 = carrinha0.compareTo((Veiculo) carrinha15);
        int i26 = carrinha15.getFiabilidade();
        double d27 = carrinha15.getPrecoBase();
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertNotNull(carrinha12);
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue(i17 == 3);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str18.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada19);
        org.junit.Assert.assertTrue(i21 == 0);
        org.junit.Assert.assertNotNull(coordenada22);
        org.junit.Assert.assertTrue(i25 == 3);
        org.junit.Assert.assertTrue(i26 == 0);
        org.junit.Assert.assertTrue(d27 == 0.0d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        int i4 = carrinha3.getLugares();
        boolean b5 = carrinha2.equals((java.lang.Object) carrinha3);
        Carrinha carrinha6 = carrinha3.clone();
        carrinha6.setVelocidadeMedia((int) (short) 0);
        carrinha6.setFiabilidade((-33));
        java.lang.String str11 = carrinha6.toString();
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue(b5 == true);
        org.junit.Assert.assertNotNull(carrinha6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: -33\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str11.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: -33\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        java.lang.String str2 = carrinha0.getMatricula();
        Carrinha carrinha3 = new Carrinha(carrinha0);
        carrinha0.setOcupado(true);
        double d6 = carrinha0.getPrecoBase();
        java.lang.String str7 = carrinha0.getMatricula();
        carrinha0.setPrecoBase((double) 33);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "n/a" + "'", str2.equals("n/a"));
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "n/a" + "'", str7.equals("n/a"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha3.setOcupado(true);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        carrinha6.setVelocidadeMedia(10);
        int i10 = carrinha3.compareTo((Veiculo) carrinha6);
        Carrinha carrinha11 = new Carrinha(carrinha3);
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i10 == 3);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        Carrinha carrinha9 = new Carrinha(carrinha6);
        int i10 = carrinha9.getVelocidadeMedia();
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue(i10 == 0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        Carrinha carrinha4 = carrinha0.clone();
        Carrinha carrinha5 = new Carrinha(carrinha0);
        carrinha0.setMatricula("Matrícula: Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 100km/h\nPreço Base: 1.0€\nFiabilidade: 0\nLugares: 9\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(carrinha4);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        java.lang.String str4 = carrinha0.toString();
        java.lang.String str5 = carrinha0.getMatricula();
        Carrinha carrinha6 = new Carrinha(carrinha0);
        carrinha6.setPrecoBase((double) (byte) 1);
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str4.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        Carrinha carrinha4 = new Carrinha();
        Carrinha carrinha5 = new Carrinha(carrinha4);
        Carrinha carrinha6 = new Carrinha(carrinha5);
        Carrinha carrinha7 = new Carrinha();
        Carrinha carrinha8 = new Carrinha(carrinha7);
        int i9 = carrinha5.compareTo((Veiculo) carrinha7);
        Carrinha carrinha10 = new Carrinha();
        carrinha10.setMatricula("");
        boolean b14 = carrinha10.equals((java.lang.Object) (-1.0d));
        boolean b15 = carrinha5.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha16 = new Carrinha();
        carrinha16.setMatricula("");
        Carrinha carrinha19 = carrinha16.clone();
        carrinha16.setPrecoBase((double) 0L);
        Carrinha carrinha22 = new Carrinha();
        int i23 = carrinha22.getLugares();
        int i24 = carrinha16.compareTo((Veiculo) carrinha22);
        java.lang.String str25 = carrinha22.toString();
        Coordenada coordenada26 = carrinha22.getCoordenadas();
        carrinha5.setCoordenadas(coordenada26);
        Carrinha carrinha29 = new Carrinha((-1), 10.0d, (int) (byte) 1, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada26, true);
        int i30 = carrinha29.getVelocidadeMedia();
        java.lang.String str31 = carrinha29.getMatricula();
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertNotNull(carrinha19);
        org.junit.Assert.assertTrue(i23 == 0);
        org.junit.Assert.assertTrue(i24 == 3);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str25.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada26);
        org.junit.Assert.assertTrue(i30 == (-1));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str31.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        Carrinha carrinha12 = new Carrinha();
        carrinha12.setMatricula("");
        Carrinha carrinha15 = carrinha12.clone();
        carrinha12.setPrecoBase((double) 0L);
        Carrinha carrinha18 = new Carrinha();
        int i19 = carrinha18.getLugares();
        int i20 = carrinha12.compareTo((Veiculo) carrinha18);
        java.lang.String str21 = carrinha18.toString();
        Coordenada coordenada22 = carrinha18.getCoordenadas();
        Carrinha carrinha24 = new Carrinha((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada22, false);
        Carrinha carrinha26 = new Carrinha((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada22, true);
        Carrinha carrinha28 = new Carrinha((int) '#', 10.0d, (-1), "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada22, true);
        carrinha28.setMatricula("hi!");
        java.lang.String str31 = carrinha28.toString();
        org.junit.Assert.assertNotNull(carrinha15);
        org.junit.Assert.assertTrue(i19 == 0);
        org.junit.Assert.assertTrue(i20 == 3);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str21.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada22);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Matrícula: hi!\nVelocidade Média/km: 35km/h\nPreço Base: 10.0€\nFiabilidade: -1\nLugares: 9\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n" + "'", str31.equals("Matrícula: hi!\nVelocidade Média/km: 35km/h\nPreço Base: 10.0€\nFiabilidade: -1\nLugares: 9\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        java.lang.String str3 = carrinha0.toString();
        Carrinha carrinha4 = new Carrinha();
        Carrinha carrinha5 = new Carrinha(carrinha4);
        java.lang.String str6 = carrinha4.toString();
        carrinha4.setFiabilidade(0);
        Carrinha carrinha9 = carrinha4.clone();
        Carrinha carrinha10 = new Carrinha();
        Carrinha carrinha11 = new Carrinha(carrinha10);
        Carrinha carrinha12 = new Carrinha(carrinha11);
        Carrinha carrinha13 = new Carrinha();
        Carrinha carrinha14 = new Carrinha(carrinha13);
        int i15 = carrinha11.compareTo((Veiculo) carrinha13);
        Carrinha carrinha16 = new Carrinha();
        carrinha16.setMatricula("");
        boolean b20 = carrinha16.equals((java.lang.Object) (-1.0d));
        boolean b21 = carrinha11.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha22 = new Carrinha();
        carrinha22.setMatricula("");
        Carrinha carrinha25 = carrinha22.clone();
        carrinha22.setPrecoBase((double) 0L);
        Carrinha carrinha28 = new Carrinha();
        int i29 = carrinha28.getLugares();
        int i30 = carrinha22.compareTo((Veiculo) carrinha28);
        java.lang.String str31 = carrinha28.toString();
        Coordenada coordenada32 = carrinha28.getCoordenadas();
        carrinha11.setCoordenadas(coordenada32);
        carrinha4.setCoordenadas(coordenada32);
        carrinha0.setCoordenadas(coordenada32);
        carrinha0.setFiabilidade((int) '4');
        carrinha0.setPrecoBase((double) (-33));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str6.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha9);
        org.junit.Assert.assertTrue(i15 == 0);
        org.junit.Assert.assertTrue(b20 == false);
        org.junit.Assert.assertTrue(b21 == false);
        org.junit.Assert.assertNotNull(carrinha25);
        org.junit.Assert.assertTrue(i29 == 0);
        org.junit.Assert.assertTrue(i30 == 3);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str31.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada32);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        Carrinha carrinha4 = new Carrinha(carrinha3);
        int i5 = carrinha1.compareTo((Veiculo) carrinha3);
        carrinha1.setVelocidadeMedia((int) (short) 100);
        Coordenada coordenada8 = carrinha1.getCoordenadas();
        boolean b9 = carrinha1.getOcupado();
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertNotNull(coordenada8);
        org.junit.Assert.assertTrue(b9 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carrinha0.getCoordenadas();
        carrinha0.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carrinha0.setFiabilidade(0);
        Carrinha carrinha10 = new Carrinha();
        carrinha10.setMatricula("");
        boolean b14 = carrinha10.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada15 = carrinha10.getCoordenadas();
        int i16 = carrinha10.getVelocidadeMedia();
        boolean b17 = carrinha0.equals((java.lang.Object) carrinha10);
        Carrinha carrinha18 = new Carrinha();
        carrinha18.setMatricula("");
        Carrinha carrinha21 = carrinha18.clone();
        carrinha18.setPrecoBase((double) 0L);
        Carrinha carrinha24 = new Carrinha();
        int i25 = carrinha24.getLugares();
        int i26 = carrinha18.compareTo((Veiculo) carrinha24);
        int i27 = carrinha24.getFiabilidade();
        int i28 = carrinha10.compareTo((Veiculo) carrinha24);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertNotNull(coordenada15);
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue(b17 == false);
        org.junit.Assert.assertNotNull(carrinha21);
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue(i26 == 3);
        org.junit.Assert.assertTrue(i27 == 0);
        org.junit.Assert.assertTrue(i28 == 3);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        java.lang.String str2 = carrinha0.toString();
        carrinha0.setFiabilidade(0);
        carrinha0.setOcupado(true);
        boolean b7 = carrinha0.getOcupado();
        carrinha0.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carrinha0.setMatricula("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        int i12 = carrinha0.getVelocidadeMedia();
        Coordenada coordenada13 = carrinha0.getCoordenadas();
        Coordenada coordenada14 = carrinha0.getCoordenadas();
        carrinha0.setOcupado(true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(b7 == true);
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertNotNull(coordenada13);
        org.junit.Assert.assertNotNull(coordenada14);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha();
        Carrinha carrinha2 = new Carrinha(carrinha1);
        int i3 = carrinha2.getFiabilidade();
        Coordenada coordenada4 = carrinha2.getCoordenadas();
        carrinha0.setCoordenadas(coordenada4);
        int i6 = carrinha0.getVelocidadeMedia();
        int i7 = carrinha0.getLugares();
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertNotNull(coordenada4);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertTrue(i7 == 0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        Carrinha carrinha2 = carrinha0.clone();
        Carrinha carrinha3 = new Carrinha(carrinha2);
        Coordenada coordenada4 = carrinha3.getCoordenadas();
        Carrinha carrinha5 = carrinha3.clone();
        Carrinha carrinha6 = new Carrinha();
        carrinha6.setMatricula("");
        boolean b10 = carrinha6.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada11 = carrinha6.getCoordenadas();
        boolean b12 = carrinha6.getOcupado();
        java.lang.String str13 = carrinha6.getMatricula();
        Carrinha carrinha18 = new Carrinha();
        carrinha18.setMatricula("");
        Carrinha carrinha21 = carrinha18.clone();
        carrinha18.setPrecoBase((double) 0L);
        Carrinha carrinha24 = new Carrinha();
        int i25 = carrinha24.getLugares();
        int i26 = carrinha18.compareTo((Veiculo) carrinha24);
        java.lang.String str27 = carrinha24.toString();
        Coordenada coordenada28 = carrinha24.getCoordenadas();
        Carrinha carrinha30 = new Carrinha((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada28, false);
        carrinha6.setCoordenadas(coordenada28);
        boolean b32 = carrinha3.equals((java.lang.Object) carrinha6);
        Carrinha carrinha33 = new Carrinha(carrinha3);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(carrinha2);
        org.junit.Assert.assertNotNull(coordenada4);
        org.junit.Assert.assertNotNull(carrinha5);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertNotNull(coordenada11);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(carrinha21);
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue(i26 == 3);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str27.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada28);
        org.junit.Assert.assertTrue(b32 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        Carrinha carrinha4 = new Carrinha(carrinha3);
        int i5 = carrinha1.compareTo((Veiculo) carrinha3);
        Carrinha carrinha6 = new Carrinha();
        carrinha6.setMatricula("");
        boolean b10 = carrinha6.equals((java.lang.Object) (-1.0d));
        boolean b11 = carrinha1.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha12 = new Carrinha();
        carrinha12.setMatricula("");
        Carrinha carrinha15 = carrinha12.clone();
        carrinha12.setPrecoBase((double) 0L);
        Carrinha carrinha18 = new Carrinha();
        int i19 = carrinha18.getLugares();
        int i20 = carrinha12.compareTo((Veiculo) carrinha18);
        java.lang.String str21 = carrinha18.toString();
        Coordenada coordenada22 = carrinha18.getCoordenadas();
        carrinha1.setCoordenadas(coordenada22);
        carrinha1.setVelocidadeMedia((int) ' ');
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertNotNull(carrinha15);
        org.junit.Assert.assertTrue(i19 == 0);
        org.junit.Assert.assertTrue(i20 == 3);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str21.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada22);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        Carrinha carrinha4 = new Carrinha(carrinha3);
        int i5 = carrinha1.compareTo((Veiculo) carrinha3);
        Carrinha carrinha6 = new Carrinha();
        carrinha6.setMatricula("");
        boolean b10 = carrinha6.equals((java.lang.Object) (-1.0d));
        boolean b11 = carrinha1.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha12 = new Carrinha();
        carrinha12.setMatricula("");
        Carrinha carrinha15 = carrinha12.clone();
        carrinha12.setPrecoBase((double) 0L);
        Carrinha carrinha18 = new Carrinha();
        int i19 = carrinha18.getLugares();
        int i20 = carrinha12.compareTo((Veiculo) carrinha18);
        java.lang.String str21 = carrinha18.toString();
        Coordenada coordenada22 = carrinha18.getCoordenadas();
        carrinha1.setCoordenadas(coordenada22);
        carrinha1.setPrecoBase((double) (short) 10);
        int i26 = carrinha1.getFiabilidade();
        Carrinha carrinha27 = new Carrinha();
        carrinha27.setMatricula("");
        Carrinha carrinha30 = carrinha27.clone();
        carrinha27.setPrecoBase((double) 0L);
        Carrinha carrinha33 = new Carrinha();
        int i34 = carrinha33.getLugares();
        int i35 = carrinha27.compareTo((Veiculo) carrinha33);
        java.lang.String str36 = carrinha33.toString();
        Coordenada coordenada37 = carrinha33.getCoordenadas();
        carrinha33.setMatricula("hi!");
        double d40 = carrinha33.getPrecoBase();
        boolean b41 = carrinha1.equals((java.lang.Object) carrinha33);
        carrinha1.setOcupado(false);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertNotNull(carrinha15);
        org.junit.Assert.assertTrue(i19 == 0);
        org.junit.Assert.assertTrue(i20 == 3);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str21.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada22);
        org.junit.Assert.assertTrue(i26 == 0);
        org.junit.Assert.assertNotNull(carrinha30);
        org.junit.Assert.assertTrue(i34 == 0);
        org.junit.Assert.assertTrue(i35 == 3);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str36.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada37);
        org.junit.Assert.assertTrue(d40 == 0.0d);
        org.junit.Assert.assertTrue(b41 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        Carrinha carrinha4 = new Carrinha(carrinha3);
        int i5 = carrinha1.compareTo((Veiculo) carrinha3);
        int i6 = carrinha3.getVelocidadeMedia();
        Carrinha carrinha7 = carrinha3.clone();
        double d8 = carrinha7.getPrecoBase();
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertNotNull(carrinha7);
        org.junit.Assert.assertTrue(d8 == 0.0d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        Carrinha carrinha4 = new Carrinha(carrinha3);
        int i5 = carrinha1.compareTo((Veiculo) carrinha3);
        int i6 = carrinha3.getVelocidadeMedia();
        Carrinha carrinha7 = carrinha3.clone();
        int i8 = carrinha7.getFiabilidade();
        int i9 = carrinha7.getFiabilidade();
        Carrinha carrinha10 = new Carrinha(carrinha7);
        carrinha7.setFiabilidade((-145));
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertNotNull(carrinha7);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue(i9 == 0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carrinha0.getCoordenadas();
        boolean b6 = carrinha0.getOcupado();
        java.lang.String str7 = carrinha0.getMatricula();
        Carrinha carrinha8 = carrinha0.clone();
        Carrinha carrinha9 = new Carrinha(carrinha0);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(b6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(carrinha8);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        Carrinha carrinha4 = new Carrinha(carrinha0);
        int i5 = carrinha0.getVelocidadeMedia();
        java.lang.String str6 = carrinha0.getMatricula();
        boolean b7 = carrinha0.getOcupado();
        carrinha0.setFiabilidade((int) (short) 1);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i5 == 10);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "n/a" + "'", str6.equals("n/a"));
        org.junit.Assert.assertTrue(b7 == false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        Coordenada coordenada2 = carrinha0.getCoordenadas();
        carrinha0.setFiabilidade(3);
        Carrinha carrinha5 = carrinha0.clone();
        double d6 = carrinha5.getPrecoBase();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(coordenada2);
        org.junit.Assert.assertNotNull(carrinha5);
        org.junit.Assert.assertTrue(d6 == 0.0d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        carrinha0.setMatricula("n/a");
        carrinha0.setPrecoBase((double) 1L);
        int i8 = carrinha0.getFiabilidade();
        java.lang.String str9 = carrinha0.getMatricula();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "n/a" + "'", str9.equals("n/a"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        Carrinha carrinha16 = new Carrinha();
        carrinha16.setMatricula("");
        Carrinha carrinha19 = carrinha16.clone();
        carrinha16.setPrecoBase((double) 0L);
        Carrinha carrinha22 = new Carrinha();
        int i23 = carrinha22.getLugares();
        int i24 = carrinha16.compareTo((Veiculo) carrinha22);
        java.lang.String str25 = carrinha22.toString();
        Coordenada coordenada26 = carrinha22.getCoordenadas();
        Carrinha carrinha28 = new Carrinha((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada26, false);
        Carrinha carrinha30 = new Carrinha((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada26, true);
        Carrinha carrinha32 = new Carrinha((int) '#', 10.0d, (-1), "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada26, true);
        Coordenada coordenada33 = carrinha32.getCoordenadas();
        Carrinha carrinha35 = new Carrinha((int) '4', (double) (byte) 1, 0, "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada33, true);
        java.lang.String str36 = carrinha35.toString();
        org.junit.Assert.assertNotNull(carrinha19);
        org.junit.Assert.assertTrue(i23 == 0);
        org.junit.Assert.assertTrue(i24 == 3);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str25.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada26);
        org.junit.Assert.assertNotNull(coordenada33);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Matrícula: Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 52km/h\nPreço Base: 1.0€\nFiabilidade: 0\nLugares: 9\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n" + "'", str36.equals("Matrícula: Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 52km/h\nPreço Base: 1.0€\nFiabilidade: 0\nLugares: 9\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        Carrinha carrinha4 = new Carrinha();
        carrinha4.setMatricula("");
        Carrinha carrinha7 = carrinha4.clone();
        Coordenada coordenada8 = carrinha7.getCoordenadas();
        Carrinha carrinha10 = new Carrinha((int) (byte) -1, (double) 0, (int) (short) 1, "", coordenada8, false);
        double d11 = carrinha10.getPrecoBase();
        java.lang.String str12 = carrinha10.toString();
        Carrinha carrinha13 = new Carrinha();
        int i14 = carrinha13.getLugares();
        carrinha13.setVelocidadeMedia(10);
        carrinha13.setMatricula("n/a");
        Carrinha carrinha19 = new Carrinha();
        carrinha19.setMatricula("");
        Carrinha carrinha22 = carrinha19.clone();
        carrinha19.setPrecoBase((double) 0L);
        Carrinha carrinha25 = new Carrinha();
        int i26 = carrinha25.getLugares();
        int i27 = carrinha19.compareTo((Veiculo) carrinha25);
        java.lang.String str28 = carrinha25.toString();
        Coordenada coordenada29 = carrinha25.getCoordenadas();
        Carrinha carrinha30 = new Carrinha();
        int i31 = carrinha30.getLugares();
        Coordenada coordenada32 = carrinha30.getCoordenadas();
        carrinha25.setCoordenadas(coordenada32);
        carrinha13.setCoordenadas(coordenada32);
        Carrinha carrinha35 = new Carrinha();
        carrinha35.setMatricula("");
        boolean b39 = carrinha35.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada40 = carrinha35.getCoordenadas();
        carrinha13.setCoordenadas(coordenada40);
        Coordenada coordenada42 = carrinha13.getCoordenadas();
        Coordenada coordenada43 = carrinha13.getCoordenadas();
        boolean b44 = carrinha10.equals((java.lang.Object) carrinha13);
        org.junit.Assert.assertNotNull(carrinha7);
        org.junit.Assert.assertNotNull(coordenada8);
        org.junit.Assert.assertTrue(d11 == 0.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Matrícula: \nVelocidade Média/km: -1km/h\nPreço Base: 0.0€\nFiabilidade: 1\nLugares: 9\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str12.equals("Matrícula: \nVelocidade Média/km: -1km/h\nPreço Base: 0.0€\nFiabilidade: 1\nLugares: 9\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertNotNull(carrinha22);
        org.junit.Assert.assertTrue(i26 == 0);
        org.junit.Assert.assertTrue(i27 == 3);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str28.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada29);
        org.junit.Assert.assertTrue(i31 == 0);
        org.junit.Assert.assertNotNull(coordenada32);
        org.junit.Assert.assertTrue(b39 == false);
        org.junit.Assert.assertNotNull(coordenada40);
        org.junit.Assert.assertNotNull(coordenada42);
        org.junit.Assert.assertNotNull(coordenada43);
        org.junit.Assert.assertTrue(b44 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha5 = new Carrinha(carrinha0);
        double d6 = carrinha0.getPrecoBase();
        carrinha0.setFiabilidade((int) (short) 0);
        carrinha0.setOcupado(false);
        int i11 = carrinha0.getFiabilidade();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(i11 == 0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        carrinha0.setMatricula("n/a");
        Carrinha carrinha6 = new Carrinha();
        carrinha6.setMatricula("");
        Carrinha carrinha9 = carrinha6.clone();
        carrinha6.setPrecoBase((double) 0L);
        Carrinha carrinha12 = new Carrinha();
        int i13 = carrinha12.getLugares();
        int i14 = carrinha6.compareTo((Veiculo) carrinha12);
        java.lang.String str15 = carrinha12.toString();
        Coordenada coordenada16 = carrinha12.getCoordenadas();
        Carrinha carrinha17 = new Carrinha();
        int i18 = carrinha17.getLugares();
        Coordenada coordenada19 = carrinha17.getCoordenadas();
        carrinha12.setCoordenadas(coordenada19);
        carrinha0.setCoordenadas(coordenada19);
        Carrinha carrinha22 = new Carrinha();
        carrinha22.setMatricula("");
        boolean b26 = carrinha22.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada27 = carrinha22.getCoordenadas();
        carrinha0.setCoordenadas(coordenada27);
        java.lang.String str29 = carrinha0.getMatricula();
        java.lang.String str30 = carrinha0.getMatricula();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(carrinha9);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(i14 == 3);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str15.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada16);
        org.junit.Assert.assertTrue(i18 == 0);
        org.junit.Assert.assertNotNull(coordenada19);
        org.junit.Assert.assertTrue(b26 == false);
        org.junit.Assert.assertNotNull(coordenada27);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "n/a" + "'", str29.equals("n/a"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "n/a" + "'", str30.equals("n/a"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        java.lang.String str9 = carrinha6.toString();
        Coordenada coordenada10 = carrinha6.getCoordenadas();
        carrinha6.setFiabilidade((int) (byte) 1);
        Carrinha carrinha13 = new Carrinha();
        int i14 = carrinha13.getLugares();
        carrinha13.setVelocidadeMedia(10);
        Carrinha carrinha17 = carrinha13.clone();
        boolean b18 = carrinha6.equals((java.lang.Object) carrinha13);
        Carrinha carrinha19 = new Carrinha(carrinha6);
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertNotNull(carrinha17);
        org.junit.Assert.assertTrue(b18 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        carrinha0.setMatricula("n/a");
        carrinha0.setPrecoBase((double) 1L);
        Coordenada coordenada8 = carrinha0.getCoordenadas();
        Carrinha carrinha9 = new Carrinha();
        Carrinha carrinha10 = new Carrinha(carrinha9);
        java.lang.String str11 = carrinha9.toString();
        carrinha9.setFiabilidade(0);
        Carrinha carrinha14 = carrinha9.clone();
        Carrinha carrinha15 = new Carrinha(carrinha9);
        Coordenada coordenada16 = carrinha9.getCoordenadas();
        carrinha0.setCoordenadas(coordenada16);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(coordenada8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str11.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha14);
        org.junit.Assert.assertNotNull(coordenada16);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha(carrinha0);
        carrinha6.setPrecoBase((double) (-1.0f));
        carrinha6.setVelocidadeMedia((int) (short) 0);
        carrinha6.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Carrinha carrinha13 = new Carrinha(carrinha6);
        int i14 = carrinha13.getLugares();
        Coordenada coordenada15 = carrinha13.getCoordenadas();
        carrinha13.setVelocidadeMedia((int) (byte) 10);
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertNotNull(coordenada15);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        Carrinha carrinha4 = new Carrinha();
        int i5 = carrinha4.getLugares();
        Coordenada coordenada6 = carrinha4.getCoordenadas();
        Carrinha carrinha8 = new Carrinha((int) (short) -1, (double) (byte) -1, (int) '4', "", coordenada6, true);
        int i9 = carrinha8.getFiabilidade();
        carrinha8.setFiabilidade((-145));
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertNotNull(coordenada6);
        org.junit.Assert.assertTrue(i9 == 52);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        Carrinha carrinha4 = new Carrinha();
        carrinha4.setMatricula("");
        Carrinha carrinha7 = carrinha4.clone();
        carrinha4.setPrecoBase((double) 0L);
        Carrinha carrinha10 = new Carrinha();
        int i11 = carrinha10.getLugares();
        int i12 = carrinha4.compareTo((Veiculo) carrinha10);
        java.lang.String str13 = carrinha10.toString();
        Coordenada coordenada14 = carrinha10.getCoordenadas();
        Carrinha carrinha16 = new Carrinha((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada14, false);
        carrinha16.setPrecoBase((double) 10.0f);
        carrinha16.setMatricula("hi!");
        java.lang.String str21 = carrinha16.toString();
        carrinha16.setPrecoBase((double) (short) 1);
        java.lang.Object obj24 = null;
        boolean b25 = carrinha16.equals(obj24);
        org.junit.Assert.assertNotNull(carrinha7);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(i12 == 3);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str13.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada14);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Matrícula: hi!\nVelocidade Média/km: 100km/h\nPreço Base: 10.0€\nFiabilidade: 10\nLugares: 9\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str21.equals("Matrícula: hi!\nVelocidade Média/km: 100km/h\nPreço Base: 10.0€\nFiabilidade: 10\nLugares: 9\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(b25 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        int i9 = carrinha6.getFiabilidade();
        Carrinha carrinha10 = carrinha6.clone();
        carrinha6.setFiabilidade((int) (short) 1);
        Carrinha carrinha13 = new Carrinha(carrinha6);
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertNotNull(carrinha10);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        java.lang.String str2 = carrinha0.toString();
        carrinha0.setFiabilidade(0);
        Carrinha carrinha5 = carrinha0.clone();
        Carrinha carrinha6 = new Carrinha();
        Carrinha carrinha7 = new Carrinha(carrinha6);
        Carrinha carrinha8 = new Carrinha(carrinha7);
        Carrinha carrinha9 = new Carrinha();
        Carrinha carrinha10 = new Carrinha(carrinha9);
        int i11 = carrinha7.compareTo((Veiculo) carrinha9);
        Carrinha carrinha12 = new Carrinha();
        carrinha12.setMatricula("");
        boolean b16 = carrinha12.equals((java.lang.Object) (-1.0d));
        boolean b17 = carrinha7.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha18 = new Carrinha();
        carrinha18.setMatricula("");
        Carrinha carrinha21 = carrinha18.clone();
        carrinha18.setPrecoBase((double) 0L);
        Carrinha carrinha24 = new Carrinha();
        int i25 = carrinha24.getLugares();
        int i26 = carrinha18.compareTo((Veiculo) carrinha24);
        java.lang.String str27 = carrinha24.toString();
        Coordenada coordenada28 = carrinha24.getCoordenadas();
        carrinha7.setCoordenadas(coordenada28);
        carrinha0.setCoordenadas(coordenada28);
        carrinha0.setPrecoBase(100.0d);
        carrinha0.setMatricula("Matrícula: Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: -1.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        int i35 = carrinha0.getVelocidadeMedia();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha5);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(b16 == false);
        org.junit.Assert.assertTrue(b17 == false);
        org.junit.Assert.assertNotNull(carrinha21);
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue(i26 == 3);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str27.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada28);
        org.junit.Assert.assertTrue(i35 == 0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        Carrinha carrinha9 = new Carrinha(carrinha6);
        int i10 = carrinha9.getLugares();
        carrinha9.setPrecoBase(100.0d);
        Carrinha carrinha17 = new Carrinha();
        carrinha17.setMatricula("");
        java.lang.String str20 = carrinha17.toString();
        Carrinha carrinha21 = new Carrinha();
        Carrinha carrinha22 = new Carrinha(carrinha21);
        java.lang.String str23 = carrinha21.toString();
        carrinha21.setFiabilidade(0);
        Carrinha carrinha26 = carrinha21.clone();
        Carrinha carrinha27 = new Carrinha();
        Carrinha carrinha28 = new Carrinha(carrinha27);
        Carrinha carrinha29 = new Carrinha(carrinha28);
        Carrinha carrinha30 = new Carrinha();
        Carrinha carrinha31 = new Carrinha(carrinha30);
        int i32 = carrinha28.compareTo((Veiculo) carrinha30);
        Carrinha carrinha33 = new Carrinha();
        carrinha33.setMatricula("");
        boolean b37 = carrinha33.equals((java.lang.Object) (-1.0d));
        boolean b38 = carrinha28.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha39 = new Carrinha();
        carrinha39.setMatricula("");
        Carrinha carrinha42 = carrinha39.clone();
        carrinha39.setPrecoBase((double) 0L);
        Carrinha carrinha45 = new Carrinha();
        int i46 = carrinha45.getLugares();
        int i47 = carrinha39.compareTo((Veiculo) carrinha45);
        java.lang.String str48 = carrinha45.toString();
        Coordenada coordenada49 = carrinha45.getCoordenadas();
        carrinha28.setCoordenadas(coordenada49);
        carrinha21.setCoordenadas(coordenada49);
        carrinha17.setCoordenadas(coordenada49);
        Carrinha carrinha54 = new Carrinha((int) 'a', (double) (short) 100, (int) '#', "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n", coordenada49, false);
        carrinha9.setCoordenadas(coordenada49);
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str20.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str23.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha26);
        org.junit.Assert.assertTrue(i32 == 0);
        org.junit.Assert.assertTrue(b37 == false);
        org.junit.Assert.assertTrue(b38 == false);
        org.junit.Assert.assertNotNull(carrinha42);
        org.junit.Assert.assertTrue(i46 == 0);
        org.junit.Assert.assertTrue(i47 == 3);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str48.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada49);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        Carrinha carrinha4 = new Carrinha(carrinha0);
        Carrinha carrinha5 = new Carrinha(carrinha4);
        carrinha4.setFiabilidade((int) '4');
        carrinha4.setVelocidadeMedia((int) (byte) 1);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        Carrinha carrinha9 = new Carrinha(carrinha6);
        Carrinha carrinha10 = new Carrinha();
        Carrinha carrinha11 = new Carrinha(carrinha10);
        Carrinha carrinha12 = new Carrinha(carrinha11);
        Carrinha carrinha13 = new Carrinha();
        Carrinha carrinha14 = new Carrinha(carrinha13);
        int i15 = carrinha11.compareTo((Veiculo) carrinha13);
        int i16 = carrinha13.getVelocidadeMedia();
        int i17 = carrinha9.compareTo((Veiculo) carrinha13);
        int i18 = carrinha13.getVelocidadeMedia();
        int i19 = carrinha13.getVelocidadeMedia();
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue(i15 == 0);
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue(i17 == 0);
        org.junit.Assert.assertTrue(i18 == 0);
        org.junit.Assert.assertTrue(i19 == 0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        Carrinha carrinha4 = carrinha0.clone();
        boolean b5 = carrinha0.getOcupado();
        Carrinha carrinha6 = new Carrinha();
        carrinha6.setMatricula("");
        boolean b10 = carrinha6.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada11 = carrinha6.getCoordenadas();
        boolean b12 = carrinha0.equals((java.lang.Object) carrinha6);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(carrinha4);
        org.junit.Assert.assertTrue(b5 == false);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertNotNull(coordenada11);
        org.junit.Assert.assertTrue(b12 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        Carrinha carrinha4 = new Carrinha(carrinha0);
        java.lang.String str5 = carrinha0.toString();
        int i6 = carrinha0.getLugares();
        java.lang.String str7 = carrinha0.getMatricula();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str5.equals("Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "n/a" + "'", str7.equals("n/a"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        java.lang.String str2 = carrinha0.toString();
        carrinha0.setFiabilidade(0);
        Carrinha carrinha5 = carrinha0.clone();
        Carrinha carrinha6 = new Carrinha(carrinha0);
        Coordenada coordenada7 = carrinha0.getCoordenadas();
        double d8 = carrinha0.getPrecoBase();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha5);
        org.junit.Assert.assertNotNull(coordenada7);
        org.junit.Assert.assertTrue(d8 == 0.0d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = carrinha0.clone();
        double d3 = carrinha2.getPrecoBase();
        org.junit.Assert.assertNotNull(carrinha2);
        org.junit.Assert.assertTrue(d3 == 0.0d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        Carrinha carrinha12 = new Carrinha();
        carrinha12.setMatricula("");
        boolean b16 = carrinha12.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada17 = carrinha12.getCoordenadas();
        boolean b18 = carrinha12.getOcupado();
        java.lang.String str19 = carrinha12.getMatricula();
        Carrinha carrinha24 = new Carrinha();
        carrinha24.setMatricula("");
        Carrinha carrinha27 = carrinha24.clone();
        carrinha24.setPrecoBase((double) 0L);
        Carrinha carrinha30 = new Carrinha();
        int i31 = carrinha30.getLugares();
        int i32 = carrinha24.compareTo((Veiculo) carrinha30);
        java.lang.String str33 = carrinha30.toString();
        Coordenada coordenada34 = carrinha30.getCoordenadas();
        Carrinha carrinha36 = new Carrinha((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada34, false);
        carrinha12.setCoordenadas(coordenada34);
        Carrinha carrinha39 = new Carrinha(32, (double) (short) 1, (int) (byte) 1, "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada34, true);
        Carrinha carrinha41 = new Carrinha(9, (-1.0d), (int) ' ', "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 10.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada34, true);
        Carrinha carrinha43 = new Carrinha((int) (byte) 100, (double) (-3), (int) 'a', "Matrícula: Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 97.0€\nFiabilidade: 1\nLugares: 9\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada34, false);
        org.junit.Assert.assertTrue(b16 == false);
        org.junit.Assert.assertNotNull(coordenada17);
        org.junit.Assert.assertTrue(b18 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNotNull(carrinha27);
        org.junit.Assert.assertTrue(i31 == 0);
        org.junit.Assert.assertTrue(i32 == 3);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str33.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada34);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha3.setOcupado(true);
        int i6 = carrinha3.getFiabilidade();
        int i7 = carrinha3.getFiabilidade();
        Carrinha carrinha16 = new Carrinha();
        carrinha16.setMatricula("");
        Carrinha carrinha19 = carrinha16.clone();
        carrinha16.setPrecoBase((double) 0L);
        Carrinha carrinha22 = new Carrinha();
        int i23 = carrinha22.getLugares();
        int i24 = carrinha16.compareTo((Veiculo) carrinha22);
        java.lang.String str25 = carrinha22.toString();
        Coordenada coordenada26 = carrinha22.getCoordenadas();
        Carrinha carrinha28 = new Carrinha((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada26, false);
        Carrinha carrinha30 = new Carrinha((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada26, true);
        carrinha3.setCoordenadas(coordenada26);
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertNotNull(carrinha19);
        org.junit.Assert.assertTrue(i23 == 0);
        org.junit.Assert.assertTrue(i24 == 3);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str25.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada26);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        int i4 = carrinha3.getVelocidadeMedia();
        java.lang.Object obj5 = null;
        boolean b6 = carrinha3.equals(obj5);
        Carrinha carrinha11 = new Carrinha();
        carrinha11.setMatricula("");
        java.lang.String str14 = carrinha11.toString();
        Carrinha carrinha15 = new Carrinha();
        Carrinha carrinha16 = new Carrinha(carrinha15);
        java.lang.String str17 = carrinha15.toString();
        carrinha15.setFiabilidade(0);
        Carrinha carrinha20 = carrinha15.clone();
        Carrinha carrinha21 = new Carrinha();
        Carrinha carrinha22 = new Carrinha(carrinha21);
        Carrinha carrinha23 = new Carrinha(carrinha22);
        Carrinha carrinha24 = new Carrinha();
        Carrinha carrinha25 = new Carrinha(carrinha24);
        int i26 = carrinha22.compareTo((Veiculo) carrinha24);
        Carrinha carrinha27 = new Carrinha();
        carrinha27.setMatricula("");
        boolean b31 = carrinha27.equals((java.lang.Object) (-1.0d));
        boolean b32 = carrinha22.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha33 = new Carrinha();
        carrinha33.setMatricula("");
        Carrinha carrinha36 = carrinha33.clone();
        carrinha33.setPrecoBase((double) 0L);
        Carrinha carrinha39 = new Carrinha();
        int i40 = carrinha39.getLugares();
        int i41 = carrinha33.compareTo((Veiculo) carrinha39);
        java.lang.String str42 = carrinha39.toString();
        Coordenada coordenada43 = carrinha39.getCoordenadas();
        carrinha22.setCoordenadas(coordenada43);
        carrinha15.setCoordenadas(coordenada43);
        carrinha11.setCoordenadas(coordenada43);
        Carrinha carrinha48 = new Carrinha((int) '4', (double) 1.0f, 9, "hi!", coordenada43, false);
        carrinha3.setCoordenadas(coordenada43);
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue(b6 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str14.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str17.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha20);
        org.junit.Assert.assertTrue(i26 == 0);
        org.junit.Assert.assertTrue(b31 == false);
        org.junit.Assert.assertTrue(b32 == false);
        org.junit.Assert.assertNotNull(carrinha36);
        org.junit.Assert.assertTrue(i40 == 0);
        org.junit.Assert.assertTrue(i41 == 3);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str42.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada43);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        java.lang.String str3 = carrinha0.toString();
        java.lang.Object obj4 = null;
        boolean b5 = carrinha0.equals(obj4);
        Carrinha carrinha6 = new Carrinha();
        carrinha6.setMatricula("");
        Carrinha carrinha9 = carrinha6.clone();
        int i10 = carrinha9.getFiabilidade();
        java.lang.String str11 = carrinha9.toString();
        boolean b12 = carrinha0.equals((java.lang.Object) carrinha9);
        carrinha9.setMatricula("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carrinha9.setPrecoBase((double) 1.0f);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(b5 == false);
        org.junit.Assert.assertNotNull(carrinha9);
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str11.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(b12 == true);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        Carrinha carrinha4 = new Carrinha(carrinha0);
        Carrinha carrinha5 = new Carrinha(carrinha4);
        Coordenada coordenada6 = carrinha4.getCoordenadas();
        Carrinha carrinha7 = new Carrinha(carrinha4);
        double d8 = carrinha7.getPrecoBase();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(coordenada6);
        org.junit.Assert.assertTrue(d8 == 0.0d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        java.lang.String str2 = carrinha0.toString();
        carrinha0.setFiabilidade(0);
        Carrinha carrinha5 = carrinha0.clone();
        Carrinha carrinha6 = new Carrinha();
        Carrinha carrinha7 = new Carrinha(carrinha6);
        Carrinha carrinha8 = new Carrinha(carrinha7);
        Carrinha carrinha9 = new Carrinha();
        Carrinha carrinha10 = new Carrinha(carrinha9);
        int i11 = carrinha7.compareTo((Veiculo) carrinha9);
        Carrinha carrinha12 = new Carrinha();
        carrinha12.setMatricula("");
        boolean b16 = carrinha12.equals((java.lang.Object) (-1.0d));
        boolean b17 = carrinha7.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha18 = new Carrinha();
        carrinha18.setMatricula("");
        Carrinha carrinha21 = carrinha18.clone();
        carrinha18.setPrecoBase((double) 0L);
        Carrinha carrinha24 = new Carrinha();
        int i25 = carrinha24.getLugares();
        int i26 = carrinha18.compareTo((Veiculo) carrinha24);
        java.lang.String str27 = carrinha24.toString();
        Coordenada coordenada28 = carrinha24.getCoordenadas();
        carrinha7.setCoordenadas(coordenada28);
        carrinha0.setCoordenadas(coordenada28);
        carrinha0.setPrecoBase(100.0d);
        java.lang.String str33 = carrinha0.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha5);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(b16 == false);
        org.junit.Assert.assertTrue(b17 == false);
        org.junit.Assert.assertNotNull(carrinha21);
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue(i26 == 3);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str27.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada28);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 100.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str33.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 100.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        java.lang.String str4 = carrinha0.toString();
        int i5 = carrinha0.getVelocidadeMedia();
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str4.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i5 == 0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha(carrinha0);
        carrinha6.setPrecoBase((double) (-1.0f));
        double d9 = carrinha6.getPrecoBase();
        Carrinha carrinha10 = new Carrinha();
        Carrinha carrinha11 = new Carrinha(carrinha10);
        Carrinha carrinha12 = new Carrinha(carrinha11);
        Carrinha carrinha13 = new Carrinha();
        Carrinha carrinha14 = new Carrinha(carrinha13);
        int i15 = carrinha11.compareTo((Veiculo) carrinha13);
        int i16 = carrinha13.getVelocidadeMedia();
        Carrinha carrinha17 = carrinha13.clone();
        int i18 = carrinha17.getFiabilidade();
        int i19 = carrinha17.getFiabilidade();
        Carrinha carrinha20 = new Carrinha(carrinha17);
        Coordenada coordenada21 = carrinha17.getCoordenadas();
        carrinha6.setCoordenadas(coordenada21);
        int i23 = carrinha6.getFiabilidade();
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(d9 == (-1.0d));
        org.junit.Assert.assertTrue(i15 == 0);
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertNotNull(carrinha17);
        org.junit.Assert.assertTrue(i18 == 0);
        org.junit.Assert.assertTrue(i19 == 0);
        org.junit.Assert.assertNotNull(coordenada21);
        org.junit.Assert.assertTrue(i23 == 0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        java.lang.String str6 = carrinha0.getMatricula();
        Coordenada coordenada7 = carrinha0.getCoordenadas();
        Carrinha carrinha12 = new Carrinha();
        carrinha12.setMatricula("");
        boolean b16 = carrinha12.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada17 = carrinha12.getCoordenadas();
        carrinha12.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carrinha12.setFiabilidade(0);
        Carrinha carrinha22 = new Carrinha();
        carrinha22.setMatricula("");
        Carrinha carrinha25 = carrinha22.clone();
        carrinha22.setPrecoBase((double) 0L);
        Carrinha carrinha28 = new Carrinha(carrinha22);
        int i29 = carrinha12.compareTo((Veiculo) carrinha22);
        Carrinha carrinha30 = new Carrinha(carrinha22);
        Coordenada coordenada31 = carrinha30.getCoordenadas();
        Carrinha carrinha33 = new Carrinha((int) (byte) 0, (double) 0L, (int) (byte) 0, "n/a", coordenada31, true);
        Coordenada coordenada34 = carrinha33.getCoordenadas();
        carrinha0.setCoordenadas(coordenada34);
        int i36 = carrinha0.getLugares();
        int i37 = carrinha0.getLugares();
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(coordenada7);
        org.junit.Assert.assertTrue(b16 == false);
        org.junit.Assert.assertNotNull(coordenada17);
        org.junit.Assert.assertNotNull(carrinha25);
        org.junit.Assert.assertTrue(i29 == (-142));
        org.junit.Assert.assertNotNull(coordenada31);
        org.junit.Assert.assertNotNull(coordenada34);
        org.junit.Assert.assertTrue(i36 == 0);
        org.junit.Assert.assertTrue(i37 == 0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        int i4 = carrinha3.getLugares();
        boolean b5 = carrinha2.equals((java.lang.Object) carrinha3);
        carrinha3.setPrecoBase(0.0d);
        Carrinha carrinha8 = carrinha3.clone();
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue(b5 == true);
        org.junit.Assert.assertNotNull(carrinha8);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        carrinha0.setVelocidadeMedia((int) (short) -1);
        java.lang.String str7 = carrinha0.getMatricula();
        carrinha0.setMatricula("Matrícula: Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: -1.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Carrinha carrinha10 = new Carrinha();
        int i11 = carrinha10.getLugares();
        carrinha10.setVelocidadeMedia(10);
        Carrinha carrinha14 = new Carrinha(carrinha10);
        int i15 = carrinha10.getVelocidadeMedia();
        carrinha10.setMatricula("");
        int i18 = carrinha10.getFiabilidade();
        int i19 = carrinha10.getVelocidadeMedia();
        carrinha10.setVelocidadeMedia((-142));
        boolean b22 = carrinha0.equals((java.lang.Object) carrinha10);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(i15 == 10);
        org.junit.Assert.assertTrue(i18 == 0);
        org.junit.Assert.assertTrue(i19 == 10);
        org.junit.Assert.assertTrue(b22 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha();
        Carrinha carrinha2 = new Carrinha(carrinha1);
        int i3 = carrinha2.getFiabilidade();
        Coordenada coordenada4 = carrinha2.getCoordenadas();
        carrinha0.setCoordenadas(coordenada4);
        carrinha0.setVelocidadeMedia((int) (short) -1);
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertNotNull(coordenada4);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        carrinha0.setMatricula("n/a");
        carrinha0.setPrecoBase((double) 1L);
        Carrinha carrinha8 = new Carrinha();
        Carrinha carrinha9 = new Carrinha(carrinha8);
        Carrinha carrinha10 = new Carrinha(carrinha9);
        Carrinha carrinha11 = new Carrinha();
        int i12 = carrinha11.getLugares();
        boolean b13 = carrinha10.equals((java.lang.Object) carrinha11);
        Carrinha carrinha14 = carrinha11.clone();
        Coordenada coordenada15 = carrinha11.getCoordenadas();
        carrinha0.setCoordenadas(coordenada15);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertTrue(b13 == true);
        org.junit.Assert.assertNotNull(carrinha14);
        org.junit.Assert.assertNotNull(coordenada15);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        java.lang.String str3 = carrinha0.toString();
        int i4 = carrinha0.getFiabilidade();
        carrinha0.setMatricula("Matrícula: Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 97.0€\nFiabilidade: 3\nLugares: 9\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i4 == 0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        Carrinha carrinha4 = new Carrinha(carrinha3);
        int i5 = carrinha1.compareTo((Veiculo) carrinha3);
        carrinha3.setPrecoBase((double) 3);
        java.lang.String str8 = carrinha3.getMatricula();
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "n/a" + "'", str8.equals("n/a"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        Carrinha carrinha8 = new Carrinha();
        carrinha8.setMatricula("");
        boolean b12 = carrinha8.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha13 = new Carrinha(carrinha8);
        int i14 = carrinha13.getVelocidadeMedia();
        Carrinha carrinha15 = new Carrinha();
        Carrinha carrinha16 = new Carrinha(carrinha15);
        Carrinha carrinha17 = new Carrinha(carrinha16);
        Carrinha carrinha18 = new Carrinha();
        Carrinha carrinha19 = new Carrinha(carrinha18);
        int i20 = carrinha16.compareTo((Veiculo) carrinha18);
        Carrinha carrinha21 = new Carrinha();
        carrinha21.setMatricula("");
        boolean b25 = carrinha21.equals((java.lang.Object) (-1.0d));
        boolean b26 = carrinha16.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada27 = carrinha16.getCoordenadas();
        carrinha13.setCoordenadas(coordenada27);
        Carrinha carrinha30 = new Carrinha(9, (double) 0.0f, 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada27, false);
        Carrinha carrinha32 = new Carrinha((int) (byte) 1, (double) (-142), 9, "Matrícula: hi!\nVelocidade Média/km: 100km/h\nPreço Base: 10.0€\nFiabilidade: 10\nLugares: 9\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada27, false);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(i20 == 0);
        org.junit.Assert.assertTrue(b25 == false);
        org.junit.Assert.assertTrue(b26 == false);
        org.junit.Assert.assertNotNull(coordenada27);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha5 = new Carrinha(carrinha0);
        double d6 = carrinha0.getPrecoBase();
        boolean b7 = carrinha0.getOcupado();
        int i8 = carrinha0.getVelocidadeMedia();
        Carrinha carrinha9 = carrinha0.clone();
        carrinha9.setFiabilidade((int) (byte) 10);
        carrinha9.setFiabilidade((int) (short) -1);
        carrinha9.setMatricula("hi!");
        int i16 = carrinha9.getFiabilidade();
        java.lang.String str17 = carrinha9.toString();
        Coordenada coordenada18 = carrinha9.getCoordenadas();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(b7 == false);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertNotNull(carrinha9);
        org.junit.Assert.assertTrue(i16 == (-1));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Matrícula: hi!\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: -1\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str17.equals("Matrícula: hi!\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: -1\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada18);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carrinha0.getCoordenadas();
        carrinha0.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carrinha0.setFiabilidade(0);
        Carrinha carrinha10 = new Carrinha();
        carrinha10.setMatricula("");
        boolean b14 = carrinha10.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada15 = carrinha10.getCoordenadas();
        int i16 = carrinha10.getVelocidadeMedia();
        boolean b17 = carrinha0.equals((java.lang.Object) carrinha10);
        Carrinha carrinha18 = new Carrinha();
        Carrinha carrinha19 = new Carrinha(carrinha18);
        Carrinha carrinha20 = new Carrinha(carrinha19);
        Carrinha carrinha21 = new Carrinha();
        Carrinha carrinha22 = new Carrinha(carrinha21);
        int i23 = carrinha19.compareTo((Veiculo) carrinha21);
        Carrinha carrinha24 = new Carrinha();
        carrinha24.setMatricula("");
        boolean b28 = carrinha24.equals((java.lang.Object) (-1.0d));
        boolean b29 = carrinha19.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha30 = new Carrinha();
        carrinha30.setMatricula("");
        Carrinha carrinha33 = carrinha30.clone();
        carrinha30.setPrecoBase((double) 0L);
        Carrinha carrinha36 = new Carrinha();
        int i37 = carrinha36.getLugares();
        int i38 = carrinha30.compareTo((Veiculo) carrinha36);
        java.lang.String str39 = carrinha36.toString();
        Coordenada coordenada40 = carrinha36.getCoordenadas();
        carrinha19.setCoordenadas(coordenada40);
        carrinha19.setVelocidadeMedia((-145));
        boolean b44 = carrinha0.equals((java.lang.Object) carrinha19);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertNotNull(coordenada15);
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue(b17 == false);
        org.junit.Assert.assertTrue(i23 == 0);
        org.junit.Assert.assertTrue(b28 == false);
        org.junit.Assert.assertTrue(b29 == false);
        org.junit.Assert.assertNotNull(carrinha33);
        org.junit.Assert.assertTrue(i37 == 0);
        org.junit.Assert.assertTrue(i38 == 3);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str39.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada40);
        org.junit.Assert.assertTrue(b44 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        Carrinha carrinha4 = new Carrinha(carrinha0);
        Carrinha carrinha5 = new Carrinha(carrinha4);
        int i6 = carrinha5.getFiabilidade();
        Carrinha carrinha7 = carrinha5.clone();
        carrinha7.setOcupado(false);
        Coordenada coordenada10 = carrinha7.getCoordenadas();
        Carrinha carrinha11 = carrinha7.clone();
        java.lang.String str12 = carrinha7.toString();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertNotNull(carrinha7);
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertNotNull(carrinha11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str12.equals("Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        int i9 = carrinha6.getFiabilidade();
        Carrinha carrinha10 = carrinha6.clone();
        Coordenada coordenada11 = carrinha10.getCoordenadas();
        int i12 = carrinha10.getLugares();
        int i13 = carrinha10.getVelocidadeMedia();
        boolean b14 = carrinha10.getOcupado();
        java.lang.String str15 = carrinha10.toString();
        Carrinha carrinha16 = new Carrinha();
        Carrinha carrinha17 = new Carrinha(carrinha16);
        Carrinha carrinha18 = new Carrinha(carrinha17);
        Carrinha carrinha19 = new Carrinha();
        Carrinha carrinha20 = new Carrinha(carrinha19);
        int i21 = carrinha17.compareTo((Veiculo) carrinha19);
        Carrinha carrinha22 = new Carrinha();
        carrinha22.setMatricula("");
        boolean b26 = carrinha22.equals((java.lang.Object) (-1.0d));
        boolean b27 = carrinha17.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha28 = new Carrinha(carrinha17);
        int i29 = carrinha10.compareTo((Veiculo) carrinha17);
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertNotNull(carrinha10);
        org.junit.Assert.assertNotNull(coordenada11);
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str15.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i21 == 0);
        org.junit.Assert.assertTrue(b26 == false);
        org.junit.Assert.assertTrue(b27 == false);
        org.junit.Assert.assertTrue(i29 == 0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        int i2 = carrinha0.getLugares();
        Carrinha carrinha3 = carrinha0.clone();
        Carrinha carrinha4 = carrinha0.clone();
        java.lang.String str5 = carrinha0.getMatricula();
        org.junit.Assert.assertTrue(i2 == 0);
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertNotNull(carrinha4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "n/a" + "'", str5.equals("n/a"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        carrinha0.setMatricula("n/a");
        Carrinha carrinha6 = new Carrinha();
        carrinha6.setMatricula("");
        Carrinha carrinha9 = carrinha6.clone();
        carrinha6.setPrecoBase((double) 0L);
        Carrinha carrinha12 = new Carrinha();
        int i13 = carrinha12.getLugares();
        int i14 = carrinha6.compareTo((Veiculo) carrinha12);
        java.lang.String str15 = carrinha12.toString();
        Coordenada coordenada16 = carrinha12.getCoordenadas();
        Carrinha carrinha17 = new Carrinha();
        int i18 = carrinha17.getLugares();
        Coordenada coordenada19 = carrinha17.getCoordenadas();
        carrinha12.setCoordenadas(coordenada19);
        carrinha0.setCoordenadas(coordenada19);
        Carrinha carrinha26 = new Carrinha();
        carrinha26.setMatricula("");
        boolean b30 = carrinha26.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada31 = carrinha26.getCoordenadas();
        boolean b32 = carrinha26.getOcupado();
        java.lang.String str33 = carrinha26.getMatricula();
        Carrinha carrinha38 = new Carrinha();
        carrinha38.setMatricula("");
        Carrinha carrinha41 = carrinha38.clone();
        carrinha38.setPrecoBase((double) 0L);
        Carrinha carrinha44 = new Carrinha();
        int i45 = carrinha44.getLugares();
        int i46 = carrinha38.compareTo((Veiculo) carrinha44);
        java.lang.String str47 = carrinha44.toString();
        Coordenada coordenada48 = carrinha44.getCoordenadas();
        Carrinha carrinha50 = new Carrinha((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada48, false);
        carrinha26.setCoordenadas(coordenada48);
        Carrinha carrinha53 = new Carrinha(32, (double) (short) 1, (int) (byte) 1, "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada48, true);
        boolean b54 = carrinha0.equals((java.lang.Object) carrinha53);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(carrinha9);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(i14 == 3);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str15.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada16);
        org.junit.Assert.assertTrue(i18 == 0);
        org.junit.Assert.assertNotNull(coordenada19);
        org.junit.Assert.assertTrue(b30 == false);
        org.junit.Assert.assertNotNull(coordenada31);
        org.junit.Assert.assertTrue(b32 == false);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
        org.junit.Assert.assertNotNull(carrinha41);
        org.junit.Assert.assertTrue(i45 == 0);
        org.junit.Assert.assertTrue(i46 == 3);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str47.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada48);
        org.junit.Assert.assertTrue(b54 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        int i2 = carrinha1.getFiabilidade();
        int i3 = carrinha1.getVelocidadeMedia();
        carrinha1.setVelocidadeMedia(3);
        org.junit.Assert.assertTrue(i2 == 0);
        org.junit.Assert.assertTrue(i3 == 0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        carrinha0.setMatricula("n/a");
        Carrinha carrinha6 = new Carrinha();
        carrinha6.setMatricula("");
        Carrinha carrinha9 = carrinha6.clone();
        carrinha6.setPrecoBase((double) 0L);
        Carrinha carrinha12 = new Carrinha();
        int i13 = carrinha12.getLugares();
        int i14 = carrinha6.compareTo((Veiculo) carrinha12);
        java.lang.String str15 = carrinha12.toString();
        Coordenada coordenada16 = carrinha12.getCoordenadas();
        Carrinha carrinha17 = new Carrinha();
        int i18 = carrinha17.getLugares();
        Coordenada coordenada19 = carrinha17.getCoordenadas();
        carrinha12.setCoordenadas(coordenada19);
        carrinha0.setCoordenadas(coordenada19);
        Carrinha carrinha22 = new Carrinha();
        carrinha22.setMatricula("");
        boolean b26 = carrinha22.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada27 = carrinha22.getCoordenadas();
        carrinha0.setCoordenadas(coordenada27);
        Carrinha carrinha29 = new Carrinha();
        carrinha29.setMatricula("");
        boolean b33 = carrinha29.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha34 = new Carrinha(carrinha29);
        double d35 = carrinha29.getPrecoBase();
        boolean b36 = carrinha0.equals((java.lang.Object) carrinha29);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(carrinha9);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(i14 == 3);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str15.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada16);
        org.junit.Assert.assertTrue(i18 == 0);
        org.junit.Assert.assertNotNull(coordenada19);
        org.junit.Assert.assertTrue(b26 == false);
        org.junit.Assert.assertNotNull(coordenada27);
        org.junit.Assert.assertTrue(b33 == false);
        org.junit.Assert.assertTrue(d35 == 0.0d);
        org.junit.Assert.assertTrue(b36 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        Carrinha carrinha2 = carrinha0.clone();
        Carrinha carrinha3 = new Carrinha(carrinha2);
        Carrinha carrinha4 = new Carrinha();
        int i5 = carrinha4.getLugares();
        java.lang.String str6 = carrinha4.getMatricula();
        Carrinha carrinha7 = new Carrinha(carrinha4);
        int i8 = carrinha7.getFiabilidade();
        Coordenada coordenada9 = carrinha7.getCoordenadas();
        carrinha2.setCoordenadas(coordenada9);
        int i11 = carrinha2.getLugares();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(carrinha2);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "n/a" + "'", str6.equals("n/a"));
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertNotNull(coordenada9);
        org.junit.Assert.assertTrue(i11 == 0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        Carrinha carrinha4 = new Carrinha(carrinha3);
        int i5 = carrinha1.compareTo((Veiculo) carrinha3);
        int i6 = carrinha3.getVelocidadeMedia();
        Carrinha carrinha7 = carrinha3.clone();
        int i8 = carrinha7.getFiabilidade();
        int i9 = carrinha7.getFiabilidade();
        Carrinha carrinha10 = new Carrinha(carrinha7);
        boolean b11 = carrinha7.getOcupado();
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertNotNull(carrinha7);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertTrue(b11 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha5 = new Carrinha(carrinha0);
        int i6 = carrinha5.getFiabilidade();
        int i7 = carrinha5.getLugares();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertTrue(i7 == 0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        Carrinha carrinha2 = carrinha0.clone();
        Carrinha carrinha3 = new Carrinha();
        Carrinha carrinha4 = new Carrinha(carrinha3);
        java.lang.String str5 = carrinha3.toString();
        carrinha3.setFiabilidade(0);
        int i8 = carrinha3.getFiabilidade();
        carrinha3.setFiabilidade((int) (byte) 0);
        boolean b11 = carrinha2.equals((java.lang.Object) carrinha3);
        carrinha3.setPrecoBase((double) (-1.0f));
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(carrinha2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str5.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue(b11 == true);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        Coordenada coordenada4 = null;
        try {
            Carrinha carrinha6 = new Carrinha((int) (byte) -1, (double) 9, 33, "Matrícula: Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 52km/h\nPreço Base: 1.0€\nFiabilidade: 0\nLugares: 9\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n", coordenada4, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        Carrinha carrinha4 = new Carrinha(carrinha3);
        int i5 = carrinha1.compareTo((Veiculo) carrinha3);
        carrinha3.setMatricula("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carrinha3.setOcupado(false);
        org.junit.Assert.assertTrue(i5 == 0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        Carrinha carrinha4 = new Carrinha(carrinha0);
        int i5 = carrinha0.getVelocidadeMedia();
        Carrinha carrinha6 = carrinha0.clone();
        int i7 = carrinha0.getFiabilidade();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i5 == 10);
        org.junit.Assert.assertNotNull(carrinha6);
        org.junit.Assert.assertTrue(i7 == 0);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        java.lang.String str9 = carrinha6.toString();
        Coordenada coordenada10 = carrinha6.getCoordenadas();
        Carrinha carrinha11 = new Carrinha();
        int i12 = carrinha11.getLugares();
        Coordenada coordenada13 = carrinha11.getCoordenadas();
        carrinha6.setCoordenadas(coordenada13);
        carrinha6.setVelocidadeMedia(9);
        int i17 = carrinha6.getLugares();
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertNotNull(coordenada13);
        org.junit.Assert.assertTrue(i17 == 0);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        java.lang.String str2 = carrinha0.toString();
        carrinha0.setFiabilidade(0);
        Carrinha carrinha5 = carrinha0.clone();
        int i6 = carrinha0.getLugares();
        java.lang.Object obj7 = new java.lang.Object();
        boolean b8 = carrinha0.equals(obj7);
        carrinha0.setOcupado(false);
        java.lang.String str11 = carrinha0.getMatricula();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha5);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertTrue(b8 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "n/a" + "'", str11.equals("n/a"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setVelocidadeMedia((int) ' ');
        java.lang.String str3 = carrinha0.toString();
        java.lang.String str4 = carrinha0.getMatricula();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "n/a" + "'", str4.equals("n/a"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        Carrinha carrinha4 = new Carrinha();
        carrinha4.setMatricula("");
        Carrinha carrinha7 = carrinha4.clone();
        carrinha4.setPrecoBase((double) 0L);
        Carrinha carrinha10 = new Carrinha();
        int i11 = carrinha10.getLugares();
        int i12 = carrinha4.compareTo((Veiculo) carrinha10);
        java.lang.String str13 = carrinha10.toString();
        Coordenada coordenada14 = carrinha10.getCoordenadas();
        Carrinha carrinha16 = new Carrinha(10, (double) (short) -1, (int) (byte) 1, "", coordenada14, false);
        Carrinha carrinha17 = new Carrinha();
        carrinha17.setMatricula("");
        java.lang.String str20 = carrinha17.toString();
        Carrinha carrinha21 = carrinha17.clone();
        int i22 = carrinha16.compareTo((Veiculo) carrinha21);
        org.junit.Assert.assertNotNull(carrinha7);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(i12 == 3);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str13.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str20.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha21);
        org.junit.Assert.assertTrue(i22 == 0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        Carrinha carrinha2 = carrinha0.clone();
        Carrinha carrinha3 = new Carrinha(carrinha0);
        double d4 = carrinha0.getPrecoBase();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(carrinha2);
        org.junit.Assert.assertTrue(d4 == 0.0d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        Carrinha carrinha4 = new Carrinha(carrinha0);
        Coordenada coordenada5 = carrinha0.getCoordenadas();
        java.lang.String str6 = carrinha0.getMatricula();
        carrinha0.setVelocidadeMedia((int) (byte) 10);
        carrinha0.setVelocidadeMedia(0);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "n/a" + "'", str6.equals("n/a"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        java.lang.String str2 = carrinha0.toString();
        carrinha0.setFiabilidade(0);
        Carrinha carrinha5 = carrinha0.clone();
        Carrinha carrinha6 = new Carrinha(carrinha0);
        Coordenada coordenada7 = null;
        try {
            carrinha6.setCoordenadas(coordenada7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha5);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        carrinha0.setMatricula("n/a");
        carrinha0.setPrecoBase((double) 1L);
        carrinha0.setVelocidadeMedia((int) (byte) 1);
        carrinha0.setMatricula("hi!");
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carrinha0.getCoordenadas();
        carrinha0.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carrinha0.setFiabilidade(0);
        Carrinha carrinha10 = new Carrinha();
        carrinha10.setMatricula("");
        Carrinha carrinha13 = carrinha10.clone();
        carrinha10.setPrecoBase((double) 0L);
        Carrinha carrinha16 = new Carrinha(carrinha10);
        int i17 = carrinha0.compareTo((Veiculo) carrinha10);
        Carrinha carrinha18 = new Carrinha(carrinha10);
        int i19 = carrinha18.getLugares();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertNotNull(carrinha13);
        org.junit.Assert.assertTrue(i17 == (-142));
        org.junit.Assert.assertTrue(i19 == 0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        Carrinha carrinha4 = new Carrinha();
        carrinha4.setMatricula("");
        boolean b8 = carrinha4.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha9 = new Carrinha(carrinha4);
        int i10 = carrinha9.getVelocidadeMedia();
        Carrinha carrinha11 = new Carrinha();
        Carrinha carrinha12 = new Carrinha(carrinha11);
        Carrinha carrinha13 = new Carrinha(carrinha12);
        Carrinha carrinha14 = new Carrinha();
        Carrinha carrinha15 = new Carrinha(carrinha14);
        int i16 = carrinha12.compareTo((Veiculo) carrinha14);
        Carrinha carrinha17 = new Carrinha();
        carrinha17.setMatricula("");
        boolean b21 = carrinha17.equals((java.lang.Object) (-1.0d));
        boolean b22 = carrinha12.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada23 = carrinha12.getCoordenadas();
        carrinha9.setCoordenadas(coordenada23);
        Carrinha carrinha26 = new Carrinha(9, (double) 0.0f, 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada23, false);
        Carrinha carrinha27 = new Carrinha(carrinha26);
        org.junit.Assert.assertTrue(b8 == false);
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue(b21 == false);
        org.junit.Assert.assertTrue(b22 == false);
        org.junit.Assert.assertNotNull(coordenada23);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        Carrinha carrinha4 = new Carrinha(carrinha3);
        int i5 = carrinha1.compareTo((Veiculo) carrinha3);
        carrinha1.setVelocidadeMedia((int) (short) 100);
        java.lang.String str8 = carrinha1.getMatricula();
        double d9 = carrinha1.getPrecoBase();
        carrinha1.setPrecoBase((double) 100);
        carrinha1.setVelocidadeMedia((int) (short) 1);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "n/a" + "'", str8.equals("n/a"));
        org.junit.Assert.assertTrue(d9 == 0.0d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setVelocidadeMedia((int) ' ');
        java.lang.String str3 = carrinha0.toString();
        int i4 = carrinha0.getVelocidadeMedia();
        Carrinha carrinha5 = carrinha0.clone();
        carrinha5.setOcupado(false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i4 == 32);
        org.junit.Assert.assertNotNull(carrinha5);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        Carrinha carrinha4 = new Carrinha(carrinha0);
        int i5 = carrinha0.getVelocidadeMedia();
        carrinha0.setMatricula("");
        int i8 = carrinha0.getFiabilidade();
        int i9 = carrinha0.getVelocidadeMedia();
        carrinha0.setVelocidadeMedia((-142));
        carrinha0.setVelocidadeMedia(32);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i5 == 10);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue(i9 == 10);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        java.lang.String str9 = carrinha6.toString();
        int i10 = carrinha6.getFiabilidade();
        carrinha6.setPrecoBase(10.0d);
        int i13 = carrinha6.getFiabilidade();
        carrinha6.setFiabilidade(100);
        int i16 = carrinha6.getLugares();
        Carrinha carrinha17 = new Carrinha();
        carrinha17.setMatricula("");
        boolean b21 = carrinha17.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada22 = carrinha17.getCoordenadas();
        boolean b23 = carrinha17.getOcupado();
        java.lang.String str24 = carrinha17.getMatricula();
        Carrinha carrinha29 = new Carrinha();
        carrinha29.setMatricula("");
        Carrinha carrinha32 = carrinha29.clone();
        carrinha29.setPrecoBase((double) 0L);
        Carrinha carrinha35 = new Carrinha();
        int i36 = carrinha35.getLugares();
        int i37 = carrinha29.compareTo((Veiculo) carrinha35);
        java.lang.String str38 = carrinha35.toString();
        Coordenada coordenada39 = carrinha35.getCoordenadas();
        Carrinha carrinha41 = new Carrinha((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada39, false);
        carrinha17.setCoordenadas(coordenada39);
        Carrinha carrinha43 = new Carrinha();
        carrinha43.setMatricula("");
        Carrinha carrinha46 = carrinha43.clone();
        carrinha43.setPrecoBase((double) 0L);
        Carrinha carrinha49 = new Carrinha();
        int i50 = carrinha49.getLugares();
        int i51 = carrinha43.compareTo((Veiculo) carrinha49);
        int i52 = carrinha49.getFiabilidade();
        Carrinha carrinha53 = carrinha49.clone();
        Coordenada coordenada54 = carrinha53.getCoordenadas();
        carrinha17.setCoordenadas(coordenada54);
        carrinha6.setCoordenadas(coordenada54);
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue(b21 == false);
        org.junit.Assert.assertNotNull(coordenada22);
        org.junit.Assert.assertTrue(b23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertNotNull(carrinha32);
        org.junit.Assert.assertTrue(i36 == 0);
        org.junit.Assert.assertTrue(i37 == 3);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str38.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada39);
        org.junit.Assert.assertNotNull(carrinha46);
        org.junit.Assert.assertTrue(i50 == 0);
        org.junit.Assert.assertTrue(i51 == 3);
        org.junit.Assert.assertTrue(i52 == 0);
        org.junit.Assert.assertNotNull(carrinha53);
        org.junit.Assert.assertNotNull(coordenada54);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carrinha0.getCoordenadas();
        carrinha0.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Carrinha carrinha8 = new Carrinha(carrinha0);
        java.lang.String str9 = carrinha8.toString();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        java.lang.String str4 = carrinha0.toString();
        java.lang.String str5 = carrinha0.getMatricula();
        java.lang.String str6 = carrinha0.getMatricula();
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str4.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        Carrinha carrinha4 = new Carrinha(carrinha3);
        int i5 = carrinha1.compareTo((Veiculo) carrinha3);
        carrinha3.setPrecoBase((double) 3);
        carrinha3.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        org.junit.Assert.assertTrue(i5 == 0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carrinha0.getCoordenadas();
        boolean b6 = carrinha0.getOcupado();
        java.lang.String str7 = carrinha0.getMatricula();
        Carrinha carrinha8 = carrinha0.clone();
        java.lang.String str9 = carrinha0.toString();
        Carrinha carrinha10 = new Carrinha(carrinha0);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(b6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(carrinha8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        java.lang.String str2 = carrinha0.toString();
        carrinha0.setFiabilidade(0);
        carrinha0.setPrecoBase(1.0d);
        int i7 = carrinha0.getFiabilidade();
        int i8 = carrinha0.getLugares();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        Carrinha carrinha4 = new Carrinha(carrinha3);
        int i5 = carrinha1.compareTo((Veiculo) carrinha3);
        Carrinha carrinha6 = new Carrinha();
        carrinha6.setMatricula("");
        boolean b10 = carrinha6.equals((java.lang.Object) (-1.0d));
        boolean b11 = carrinha1.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha12 = new Carrinha(carrinha1);
        int i13 = carrinha1.getVelocidadeMedia();
        Carrinha carrinha14 = new Carrinha();
        carrinha14.setMatricula("");
        Carrinha carrinha17 = carrinha14.clone();
        carrinha14.setPrecoBase((double) 0L);
        Carrinha carrinha20 = new Carrinha();
        int i21 = carrinha20.getLugares();
        int i22 = carrinha14.compareTo((Veiculo) carrinha20);
        java.lang.String str23 = carrinha20.toString();
        int i24 = carrinha20.getFiabilidade();
        boolean b25 = carrinha1.equals((java.lang.Object) i24);
        carrinha1.setMatricula("hi!");
        Carrinha carrinha28 = new Carrinha();
        carrinha28.setMatricula("");
        boolean b32 = carrinha28.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada33 = carrinha28.getCoordenadas();
        int i34 = carrinha28.getVelocidadeMedia();
        Carrinha carrinha35 = new Carrinha();
        carrinha35.setMatricula("");
        Carrinha carrinha38 = carrinha35.clone();
        carrinha38.setOcupado(true);
        boolean b41 = carrinha28.equals((java.lang.Object) carrinha38);
        carrinha38.setMatricula("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Carrinha carrinha44 = new Carrinha();
        Carrinha carrinha45 = new Carrinha(carrinha44);
        java.lang.String str46 = carrinha44.toString();
        carrinha44.setFiabilidade(0);
        Carrinha carrinha49 = carrinha44.clone();
        int i50 = carrinha44.getLugares();
        Carrinha carrinha55 = new Carrinha();
        Carrinha carrinha56 = new Carrinha(carrinha55);
        Carrinha carrinha57 = new Carrinha(carrinha56);
        Carrinha carrinha58 = new Carrinha();
        Carrinha carrinha59 = new Carrinha(carrinha58);
        int i60 = carrinha56.compareTo((Veiculo) carrinha58);
        Carrinha carrinha61 = new Carrinha();
        carrinha61.setMatricula("");
        boolean b65 = carrinha61.equals((java.lang.Object) (-1.0d));
        boolean b66 = carrinha56.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha67 = new Carrinha();
        carrinha67.setMatricula("");
        Carrinha carrinha70 = carrinha67.clone();
        carrinha67.setPrecoBase((double) 0L);
        Carrinha carrinha73 = new Carrinha();
        int i74 = carrinha73.getLugares();
        int i75 = carrinha67.compareTo((Veiculo) carrinha73);
        java.lang.String str76 = carrinha73.toString();
        Coordenada coordenada77 = carrinha73.getCoordenadas();
        carrinha56.setCoordenadas(coordenada77);
        Carrinha carrinha80 = new Carrinha((-1), 10.0d, (int) (byte) 1, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada77, true);
        carrinha44.setCoordenadas(coordenada77);
        carrinha38.setCoordenadas(coordenada77);
        carrinha1.setCoordenadas(coordenada77);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertNotNull(carrinha17);
        org.junit.Assert.assertTrue(i21 == 0);
        org.junit.Assert.assertTrue(i22 == 3);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str23.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i24 == 0);
        org.junit.Assert.assertTrue(b25 == false);
        org.junit.Assert.assertTrue(b32 == false);
        org.junit.Assert.assertNotNull(coordenada33);
        org.junit.Assert.assertTrue(i34 == 0);
        org.junit.Assert.assertNotNull(carrinha38);
        org.junit.Assert.assertTrue(b41 == false);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str46.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha49);
        org.junit.Assert.assertTrue(i50 == 0);
        org.junit.Assert.assertTrue(i60 == 0);
        org.junit.Assert.assertTrue(b65 == false);
        org.junit.Assert.assertTrue(b66 == false);
        org.junit.Assert.assertNotNull(carrinha70);
        org.junit.Assert.assertTrue(i74 == 0);
        org.junit.Assert.assertTrue(i75 == 3);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str76.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada77);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        Carrinha carrinha4 = new Carrinha();
        carrinha4.setMatricula("");
        boolean b8 = carrinha4.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada9 = carrinha4.getCoordenadas();
        Carrinha carrinha11 = new Carrinha((int) (short) 0, (double) 'a', 1, "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada9, false);
        java.lang.String str12 = carrinha11.toString();
        carrinha11.setVelocidadeMedia((int) 'a');
        Carrinha carrinha15 = new Carrinha();
        Carrinha carrinha16 = new Carrinha(carrinha15);
        Carrinha carrinha17 = new Carrinha(carrinha16);
        Carrinha carrinha18 = new Carrinha();
        int i19 = carrinha18.getLugares();
        boolean b20 = carrinha17.equals((java.lang.Object) carrinha18);
        carrinha18.setOcupado(true);
        int i23 = carrinha18.getVelocidadeMedia();
        Carrinha carrinha24 = new Carrinha();
        carrinha24.setMatricula("");
        boolean b28 = carrinha24.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha29 = new Carrinha(carrinha24);
        double d30 = carrinha24.getPrecoBase();
        boolean b31 = carrinha24.getOcupado();
        int i32 = carrinha24.getVelocidadeMedia();
        java.lang.String str33 = carrinha24.getMatricula();
        carrinha24.setMatricula("hi!");
        carrinha24.setVelocidadeMedia((int) (byte) 1);
        int i38 = carrinha18.compareTo((Veiculo) carrinha24);
        int i39 = carrinha11.compareTo((Veiculo) carrinha18);
        org.junit.Assert.assertTrue(b8 == false);
        org.junit.Assert.assertNotNull(coordenada9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Matrícula: Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 97.0€\nFiabilidade: 1\nLugares: 9\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str12.equals("Matrícula: Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 97.0€\nFiabilidade: 1\nLugares: 9\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i19 == 0);
        org.junit.Assert.assertTrue(b20 == true);
        org.junit.Assert.assertTrue(i23 == 0);
        org.junit.Assert.assertTrue(b28 == false);
        org.junit.Assert.assertTrue(d30 == 0.0d);
        org.junit.Assert.assertTrue(b31 == false);
        org.junit.Assert.assertTrue(i32 == 0);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
        org.junit.Assert.assertTrue(i38 == (-6));
        org.junit.Assert.assertTrue(i39 == 33);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        Carrinha carrinha4 = new Carrinha(carrinha3);
        int i5 = carrinha1.compareTo((Veiculo) carrinha3);
        int i6 = carrinha3.getVelocidadeMedia();
        Carrinha carrinha7 = carrinha3.clone();
        Carrinha carrinha8 = new Carrinha();
        Carrinha carrinha9 = new Carrinha(carrinha8);
        java.lang.String str10 = carrinha8.toString();
        carrinha8.setFiabilidade(0);
        Carrinha carrinha13 = carrinha8.clone();
        int i14 = carrinha8.getLugares();
        Carrinha carrinha19 = new Carrinha();
        Carrinha carrinha20 = new Carrinha(carrinha19);
        Carrinha carrinha21 = new Carrinha(carrinha20);
        Carrinha carrinha22 = new Carrinha();
        Carrinha carrinha23 = new Carrinha(carrinha22);
        int i24 = carrinha20.compareTo((Veiculo) carrinha22);
        Carrinha carrinha25 = new Carrinha();
        carrinha25.setMatricula("");
        boolean b29 = carrinha25.equals((java.lang.Object) (-1.0d));
        boolean b30 = carrinha20.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha31 = new Carrinha();
        carrinha31.setMatricula("");
        Carrinha carrinha34 = carrinha31.clone();
        carrinha31.setPrecoBase((double) 0L);
        Carrinha carrinha37 = new Carrinha();
        int i38 = carrinha37.getLugares();
        int i39 = carrinha31.compareTo((Veiculo) carrinha37);
        java.lang.String str40 = carrinha37.toString();
        Coordenada coordenada41 = carrinha37.getCoordenadas();
        carrinha20.setCoordenadas(coordenada41);
        Carrinha carrinha44 = new Carrinha((-1), 10.0d, (int) (byte) 1, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada41, true);
        carrinha8.setCoordenadas(coordenada41);
        carrinha3.setCoordenadas(coordenada41);
        int i47 = carrinha3.getLugares();
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertNotNull(carrinha7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str10.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha13);
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(i24 == 0);
        org.junit.Assert.assertTrue(b29 == false);
        org.junit.Assert.assertTrue(b30 == false);
        org.junit.Assert.assertNotNull(carrinha34);
        org.junit.Assert.assertTrue(i38 == 0);
        org.junit.Assert.assertTrue(i39 == 3);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str40.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada41);
        org.junit.Assert.assertTrue(i47 == 0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        Carrinha carrinha4 = new Carrinha(carrinha3);
        int i5 = carrinha1.compareTo((Veiculo) carrinha3);
        Carrinha carrinha10 = new Carrinha();
        carrinha10.setMatricula("");
        Carrinha carrinha13 = carrinha10.clone();
        carrinha10.setPrecoBase((double) 0L);
        Carrinha carrinha16 = new Carrinha();
        int i17 = carrinha16.getLugares();
        int i18 = carrinha10.compareTo((Veiculo) carrinha16);
        java.lang.String str19 = carrinha16.toString();
        Coordenada coordenada20 = carrinha16.getCoordenadas();
        Carrinha carrinha22 = new Carrinha((int) ' ', (double) 100.0f, (int) (byte) -1, "", coordenada20, false);
        int i23 = carrinha1.compareTo((Veiculo) carrinha22);
        boolean b24 = carrinha22.getOcupado();
        int i25 = carrinha22.getFiabilidade();
        carrinha22.setMatricula("Matrícula: Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 52km/h\nPreço Base: 1.0€\nFiabilidade: 0\nLugares: 9\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n");
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertNotNull(carrinha13);
        org.junit.Assert.assertTrue(i17 == 0);
        org.junit.Assert.assertTrue(i18 == 3);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str19.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada20);
        org.junit.Assert.assertTrue(i23 == (-3));
        org.junit.Assert.assertTrue(b24 == false);
        org.junit.Assert.assertTrue(i25 == (-1));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        java.lang.String str9 = carrinha6.toString();
        Coordenada coordenada10 = carrinha6.getCoordenadas();
        java.lang.String str11 = carrinha6.toString();
        Carrinha carrinha12 = new Carrinha();
        carrinha12.setMatricula("");
        Carrinha carrinha15 = carrinha12.clone();
        carrinha12.setPrecoBase((double) 0L);
        Carrinha carrinha18 = new Carrinha();
        int i19 = carrinha18.getLugares();
        int i20 = carrinha12.compareTo((Veiculo) carrinha18);
        java.lang.String str21 = carrinha18.toString();
        int i22 = carrinha18.getVelocidadeMedia();
        java.lang.String str23 = carrinha18.getMatricula();
        int i24 = carrinha6.compareTo((Veiculo) carrinha18);
        carrinha6.setPrecoBase((double) (-1));
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str11.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha15);
        org.junit.Assert.assertTrue(i19 == 0);
        org.junit.Assert.assertTrue(i20 == 3);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str21.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i22 == 0);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "n/a" + "'", str23.equals("n/a"));
        org.junit.Assert.assertTrue(i24 == 0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        Carrinha carrinha4 = new Carrinha();
        carrinha4.setMatricula("");
        Carrinha carrinha7 = carrinha4.clone();
        carrinha4.setPrecoBase((double) 0L);
        Carrinha carrinha10 = new Carrinha();
        int i11 = carrinha10.getLugares();
        int i12 = carrinha4.compareTo((Veiculo) carrinha10);
        java.lang.String str13 = carrinha10.toString();
        Coordenada coordenada14 = carrinha10.getCoordenadas();
        Carrinha carrinha16 = new Carrinha((int) (byte) 100, (double) '#', (int) (short) 0, "", coordenada14, false);
        carrinha16.setFiabilidade(0);
        org.junit.Assert.assertNotNull(carrinha7);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(i12 == 3);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str13.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada14);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        Carrinha carrinha16 = new Carrinha();
        carrinha16.setMatricula("");
        Carrinha carrinha19 = carrinha16.clone();
        carrinha16.setPrecoBase((double) 0L);
        Carrinha carrinha22 = new Carrinha();
        int i23 = carrinha22.getLugares();
        int i24 = carrinha16.compareTo((Veiculo) carrinha22);
        java.lang.String str25 = carrinha22.toString();
        Coordenada coordenada26 = carrinha22.getCoordenadas();
        Carrinha carrinha28 = new Carrinha((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada26, false);
        Carrinha carrinha30 = new Carrinha((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada26, true);
        Carrinha carrinha32 = new Carrinha((int) '#', 10.0d, (-1), "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada26, true);
        Coordenada coordenada33 = carrinha32.getCoordenadas();
        Carrinha carrinha35 = new Carrinha(33, (double) 52, (-142), "Matrícula: \nVelocidade Média/km: -1km/h\nPreço Base: 0.0€\nFiabilidade: 1\nLugares: 9\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada33, false);
        java.lang.String str36 = carrinha35.getMatricula();
        org.junit.Assert.assertNotNull(carrinha19);
        org.junit.Assert.assertTrue(i23 == 0);
        org.junit.Assert.assertTrue(i24 == 3);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str25.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada26);
        org.junit.Assert.assertNotNull(coordenada33);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Matrícula: \nVelocidade Média/km: -1km/h\nPreço Base: 0.0€\nFiabilidade: 1\nLugares: 9\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str36.equals("Matrícula: \nVelocidade Média/km: -1km/h\nPreço Base: 0.0€\nFiabilidade: 1\nLugares: 9\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        Carrinha carrinha8 = new Carrinha();
        carrinha8.setMatricula("");
        Carrinha carrinha11 = carrinha8.clone();
        carrinha8.setPrecoBase((double) 0L);
        Carrinha carrinha14 = new Carrinha();
        int i15 = carrinha14.getLugares();
        int i16 = carrinha8.compareTo((Veiculo) carrinha14);
        java.lang.String str17 = carrinha14.toString();
        Coordenada coordenada18 = carrinha14.getCoordenadas();
        Carrinha carrinha20 = new Carrinha((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, false);
        Carrinha carrinha22 = new Carrinha((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, true);
        carrinha22.setFiabilidade(0);
        carrinha22.setFiabilidade(32);
        org.junit.Assert.assertNotNull(carrinha11);
        org.junit.Assert.assertTrue(i15 == 0);
        org.junit.Assert.assertTrue(i16 == 3);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str17.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada18);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        java.lang.String str9 = carrinha6.toString();
        int i10 = carrinha6.getFiabilidade();
        Carrinha carrinha11 = new Carrinha();
        Carrinha carrinha12 = new Carrinha(carrinha11);
        java.lang.String str13 = carrinha11.toString();
        carrinha11.setFiabilidade(0);
        Carrinha carrinha16 = carrinha11.clone();
        int i17 = carrinha16.getFiabilidade();
        Coordenada coordenada18 = carrinha16.getCoordenadas();
        carrinha6.setCoordenadas(coordenada18);
        Carrinha carrinha20 = new Carrinha();
        carrinha20.setMatricula("");
        Carrinha carrinha23 = carrinha20.clone();
        carrinha20.setPrecoBase((double) 0L);
        Carrinha carrinha26 = new Carrinha();
        int i27 = carrinha26.getLugares();
        int i28 = carrinha20.compareTo((Veiculo) carrinha26);
        int i29 = carrinha26.getFiabilidade();
        Carrinha carrinha30 = carrinha26.clone();
        Coordenada coordenada31 = carrinha30.getCoordenadas();
        boolean b32 = carrinha6.equals((java.lang.Object) carrinha30);
        Carrinha carrinha33 = carrinha30.clone();
        double d34 = carrinha33.getPrecoBase();
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str13.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha16);
        org.junit.Assert.assertTrue(i17 == 0);
        org.junit.Assert.assertNotNull(coordenada18);
        org.junit.Assert.assertNotNull(carrinha23);
        org.junit.Assert.assertTrue(i27 == 0);
        org.junit.Assert.assertTrue(i28 == 3);
        org.junit.Assert.assertTrue(i29 == 0);
        org.junit.Assert.assertNotNull(carrinha30);
        org.junit.Assert.assertNotNull(coordenada31);
        org.junit.Assert.assertTrue(b32 == true);
        org.junit.Assert.assertNotNull(carrinha33);
        org.junit.Assert.assertTrue(d34 == 0.0d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha5 = new Carrinha(carrinha0);
        double d6 = carrinha0.getPrecoBase();
        java.lang.String str7 = carrinha0.toString();
        int i8 = carrinha0.getVelocidadeMedia();
        int i9 = carrinha0.getVelocidadeMedia();
        double d10 = carrinha0.getPrecoBase();
        carrinha0.setFiabilidade((-33));
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str7.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertTrue(d10 == 0.0d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        Carrinha carrinha16 = new Carrinha();
        carrinha16.setMatricula("");
        Carrinha carrinha19 = carrinha16.clone();
        carrinha16.setPrecoBase((double) 0L);
        Carrinha carrinha22 = new Carrinha();
        int i23 = carrinha22.getLugares();
        int i24 = carrinha16.compareTo((Veiculo) carrinha22);
        java.lang.String str25 = carrinha22.toString();
        Coordenada coordenada26 = carrinha22.getCoordenadas();
        Carrinha carrinha28 = new Carrinha((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada26, false);
        Carrinha carrinha30 = new Carrinha((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada26, true);
        Carrinha carrinha32 = new Carrinha((int) '#', 10.0d, (-1), "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada26, true);
        Carrinha carrinha33 = new Carrinha();
        carrinha33.setMatricula("");
        boolean b37 = carrinha33.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada38 = carrinha33.getCoordenadas();
        boolean b39 = carrinha33.getOcupado();
        java.lang.String str40 = carrinha33.getMatricula();
        Carrinha carrinha45 = new Carrinha();
        carrinha45.setMatricula("");
        Carrinha carrinha48 = carrinha45.clone();
        carrinha45.setPrecoBase((double) 0L);
        Carrinha carrinha51 = new Carrinha();
        int i52 = carrinha51.getLugares();
        int i53 = carrinha45.compareTo((Veiculo) carrinha51);
        java.lang.String str54 = carrinha51.toString();
        Coordenada coordenada55 = carrinha51.getCoordenadas();
        Carrinha carrinha57 = new Carrinha((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada55, false);
        carrinha33.setCoordenadas(coordenada55);
        carrinha32.setCoordenadas(coordenada55);
        Carrinha carrinha61 = new Carrinha((int) (short) 1, (double) (-1.0f), 100, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada55, true);
        int i62 = carrinha61.getFiabilidade();
        boolean b63 = carrinha61.getOcupado();
        org.junit.Assert.assertNotNull(carrinha19);
        org.junit.Assert.assertTrue(i23 == 0);
        org.junit.Assert.assertTrue(i24 == 3);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str25.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada26);
        org.junit.Assert.assertTrue(b37 == false);
        org.junit.Assert.assertNotNull(coordenada38);
        org.junit.Assert.assertTrue(b39 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "" + "'", str40.equals(""));
        org.junit.Assert.assertNotNull(carrinha48);
        org.junit.Assert.assertTrue(i52 == 0);
        org.junit.Assert.assertTrue(i53 == 3);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str54.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada55);
        org.junit.Assert.assertTrue(i62 == 100);
        org.junit.Assert.assertTrue(b63 == true);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        Carrinha carrinha4 = new Carrinha();
        carrinha4.setMatricula("");
        Carrinha carrinha7 = carrinha4.clone();
        carrinha4.setPrecoBase((double) 0L);
        Carrinha carrinha10 = new Carrinha();
        int i11 = carrinha10.getLugares();
        int i12 = carrinha4.compareTo((Veiculo) carrinha10);
        java.lang.String str13 = carrinha10.toString();
        Coordenada coordenada14 = carrinha10.getCoordenadas();
        Carrinha carrinha16 = new Carrinha((int) ' ', (double) 100.0f, (int) (byte) -1, "", coordenada14, false);
        double d17 = carrinha16.getPrecoBase();
        Carrinha carrinha18 = new Carrinha();
        carrinha18.setMatricula("");
        Carrinha carrinha21 = carrinha18.clone();
        carrinha18.setPrecoBase((double) 0L);
        Carrinha carrinha24 = new Carrinha();
        int i25 = carrinha24.getLugares();
        int i26 = carrinha18.compareTo((Veiculo) carrinha24);
        java.lang.String str27 = carrinha24.toString();
        Coordenada coordenada28 = carrinha24.getCoordenadas();
        carrinha16.setCoordenadas(coordenada28);
        org.junit.Assert.assertNotNull(carrinha7);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(i12 == 3);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str13.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada14);
        org.junit.Assert.assertTrue(d17 == 100.0d);
        org.junit.Assert.assertNotNull(carrinha21);
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue(i26 == 3);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str27.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada28);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        java.lang.String str9 = carrinha6.toString();
        int i10 = carrinha6.getFiabilidade();
        carrinha6.setPrecoBase(10.0d);
        int i13 = carrinha6.getFiabilidade();
        carrinha6.setFiabilidade(100);
        Carrinha carrinha16 = new Carrinha();
        carrinha16.setMatricula("");
        Carrinha carrinha19 = carrinha16.clone();
        carrinha16.setPrecoBase((double) 0L);
        Carrinha carrinha22 = new Carrinha(carrinha16);
        carrinha22.setPrecoBase((double) (-1.0f));
        carrinha22.setVelocidadeMedia((int) (short) 0);
        carrinha22.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Carrinha carrinha29 = new Carrinha(carrinha22);
        int i30 = carrinha6.compareTo((Veiculo) carrinha22);
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertNotNull(carrinha19);
        org.junit.Assert.assertTrue(i30 == (-33));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        Carrinha carrinha4 = new Carrinha(carrinha3);
        int i5 = carrinha1.compareTo((Veiculo) carrinha3);
        int i6 = carrinha3.getVelocidadeMedia();
        int i7 = carrinha3.getVelocidadeMedia();
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertTrue(i7 == 0);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        Carrinha carrinha4 = new Carrinha();
        carrinha4.setMatricula("");
        boolean b8 = carrinha4.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada9 = carrinha4.getCoordenadas();
        Carrinha carrinha11 = new Carrinha((int) (short) 0, (double) 'a', 1, "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada9, false);
        java.lang.String str12 = carrinha11.toString();
        carrinha11.setVelocidadeMedia((int) 'a');
        java.lang.String str15 = carrinha11.toString();
        org.junit.Assert.assertTrue(b8 == false);
        org.junit.Assert.assertNotNull(coordenada9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Matrícula: Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 97.0€\nFiabilidade: 1\nLugares: 9\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str12.equals("Matrícula: Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 97.0€\nFiabilidade: 1\nLugares: 9\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Matrícula: Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 97km/h\nPreço Base: 97.0€\nFiabilidade: 1\nLugares: 9\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str15.equals("Matrícula: Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 97km/h\nPreço Base: 97.0€\nFiabilidade: 1\nLugares: 9\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        carrinha0.setOcupado(false);
        carrinha0.setVelocidadeMedia((int) (byte) 1);
        carrinha0.setFiabilidade((int) (byte) 10);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        java.lang.String str9 = carrinha6.toString();
        Coordenada coordenada10 = carrinha6.getCoordenadas();
        Carrinha carrinha11 = new Carrinha();
        int i12 = carrinha11.getLugares();
        Coordenada coordenada13 = carrinha11.getCoordenadas();
        carrinha6.setCoordenadas(coordenada13);
        Carrinha carrinha19 = new Carrinha();
        carrinha19.setMatricula("");
        Carrinha carrinha22 = carrinha19.clone();
        carrinha19.setPrecoBase((double) 0L);
        Carrinha carrinha25 = new Carrinha();
        int i26 = carrinha25.getLugares();
        int i27 = carrinha19.compareTo((Veiculo) carrinha25);
        java.lang.String str28 = carrinha25.toString();
        Coordenada coordenada29 = carrinha25.getCoordenadas();
        Carrinha carrinha30 = new Carrinha();
        int i31 = carrinha30.getLugares();
        Coordenada coordenada32 = carrinha30.getCoordenadas();
        carrinha25.setCoordenadas(coordenada32);
        Carrinha carrinha35 = new Carrinha((int) (byte) -1, (double) 10, 32, "Matrícula: hi!\nVelocidade Média/km: 0km/h\nPreço Base: 10.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada32, false);
        carrinha6.setCoordenadas(coordenada32);
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertNotNull(coordenada13);
        org.junit.Assert.assertNotNull(carrinha22);
        org.junit.Assert.assertTrue(i26 == 0);
        org.junit.Assert.assertTrue(i27 == 3);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str28.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada29);
        org.junit.Assert.assertTrue(i31 == 0);
        org.junit.Assert.assertNotNull(coordenada32);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        carrinha0.setMatricula("n/a");
        Carrinha carrinha6 = new Carrinha();
        carrinha6.setMatricula("");
        Carrinha carrinha9 = carrinha6.clone();
        carrinha6.setPrecoBase((double) 0L);
        Carrinha carrinha12 = new Carrinha();
        int i13 = carrinha12.getLugares();
        int i14 = carrinha6.compareTo((Veiculo) carrinha12);
        java.lang.String str15 = carrinha12.toString();
        Coordenada coordenada16 = carrinha12.getCoordenadas();
        Carrinha carrinha17 = new Carrinha();
        int i18 = carrinha17.getLugares();
        Coordenada coordenada19 = carrinha17.getCoordenadas();
        carrinha12.setCoordenadas(coordenada19);
        carrinha0.setCoordenadas(coordenada19);
        Carrinha carrinha22 = new Carrinha();
        carrinha22.setMatricula("");
        boolean b26 = carrinha22.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada27 = carrinha22.getCoordenadas();
        carrinha0.setCoordenadas(coordenada27);
        Carrinha carrinha29 = new Carrinha();
        carrinha29.setMatricula("");
        Carrinha carrinha32 = carrinha29.clone();
        carrinha29.setPrecoBase((double) 0L);
        Carrinha carrinha35 = new Carrinha();
        int i36 = carrinha35.getLugares();
        int i37 = carrinha29.compareTo((Veiculo) carrinha35);
        java.lang.String str38 = carrinha35.toString();
        int i39 = carrinha35.getFiabilidade();
        Carrinha carrinha40 = new Carrinha();
        Carrinha carrinha41 = new Carrinha(carrinha40);
        Carrinha carrinha42 = new Carrinha(carrinha41);
        Carrinha carrinha43 = new Carrinha();
        Carrinha carrinha44 = new Carrinha(carrinha43);
        int i45 = carrinha41.compareTo((Veiculo) carrinha43);
        Carrinha carrinha46 = new Carrinha();
        carrinha46.setMatricula("");
        boolean b50 = carrinha46.equals((java.lang.Object) (-1.0d));
        boolean b51 = carrinha41.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha52 = new Carrinha();
        carrinha52.setMatricula("");
        Carrinha carrinha55 = carrinha52.clone();
        carrinha52.setPrecoBase((double) 0L);
        Carrinha carrinha58 = new Carrinha();
        int i59 = carrinha58.getLugares();
        int i60 = carrinha52.compareTo((Veiculo) carrinha58);
        java.lang.String str61 = carrinha58.toString();
        Coordenada coordenada62 = carrinha58.getCoordenadas();
        carrinha41.setCoordenadas(coordenada62);
        boolean b64 = carrinha35.equals((java.lang.Object) carrinha41);
        java.lang.String str65 = carrinha35.toString();
        Carrinha carrinha66 = new Carrinha();
        Carrinha carrinha67 = new Carrinha(carrinha66);
        java.lang.String str68 = carrinha66.toString();
        carrinha66.setFiabilidade(0);
        Carrinha carrinha71 = carrinha66.clone();
        carrinha66.setPrecoBase((double) 0.0f);
        boolean b74 = carrinha35.equals((java.lang.Object) carrinha66);
        int i75 = carrinha0.compareTo((Veiculo) carrinha35);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(carrinha9);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(i14 == 3);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str15.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada16);
        org.junit.Assert.assertTrue(i18 == 0);
        org.junit.Assert.assertNotNull(coordenada19);
        org.junit.Assert.assertTrue(b26 == false);
        org.junit.Assert.assertNotNull(coordenada27);
        org.junit.Assert.assertNotNull(carrinha32);
        org.junit.Assert.assertTrue(i36 == 0);
        org.junit.Assert.assertTrue(i37 == 3);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str38.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i39 == 0);
        org.junit.Assert.assertTrue(i45 == 0);
        org.junit.Assert.assertTrue(b50 == false);
        org.junit.Assert.assertTrue(b51 == false);
        org.junit.Assert.assertNotNull(carrinha55);
        org.junit.Assert.assertTrue(i59 == 0);
        org.junit.Assert.assertTrue(i60 == 3);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str61.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada62);
        org.junit.Assert.assertTrue(b64 == true);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str65.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str68.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha71);
        org.junit.Assert.assertTrue(b74 == true);
        org.junit.Assert.assertTrue(i75 == 0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha3.setOcupado(true);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        carrinha6.setVelocidadeMedia(10);
        int i10 = carrinha3.compareTo((Veiculo) carrinha6);
        Coordenada coordenada11 = carrinha3.getCoordenadas();
        int i12 = carrinha3.getVelocidadeMedia();
        Carrinha carrinha13 = new Carrinha();
        carrinha13.setMatricula("");
        Carrinha carrinha16 = carrinha13.clone();
        carrinha13.setPrecoBase((double) 0L);
        Carrinha carrinha19 = new Carrinha(carrinha13);
        Coordenada coordenada20 = carrinha13.getCoordenadas();
        carrinha3.setCoordenadas(coordenada20);
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i10 == 3);
        org.junit.Assert.assertNotNull(coordenada11);
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertNotNull(carrinha16);
        org.junit.Assert.assertNotNull(coordenada20);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        int i2 = carrinha1.getFiabilidade();
        Coordenada coordenada3 = carrinha1.getCoordenadas();
        Carrinha carrinha4 = new Carrinha();
        carrinha4.setMatricula("");
        boolean b8 = carrinha4.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada9 = carrinha4.getCoordenadas();
        boolean b10 = carrinha4.getOcupado();
        java.lang.String str11 = carrinha4.getMatricula();
        Carrinha carrinha16 = new Carrinha();
        carrinha16.setMatricula("");
        Carrinha carrinha19 = carrinha16.clone();
        carrinha16.setPrecoBase((double) 0L);
        Carrinha carrinha22 = new Carrinha();
        int i23 = carrinha22.getLugares();
        int i24 = carrinha16.compareTo((Veiculo) carrinha22);
        java.lang.String str25 = carrinha22.toString();
        Coordenada coordenada26 = carrinha22.getCoordenadas();
        Carrinha carrinha28 = new Carrinha((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada26, false);
        carrinha4.setCoordenadas(coordenada26);
        Carrinha carrinha30 = new Carrinha();
        carrinha30.setMatricula("");
        Carrinha carrinha33 = carrinha30.clone();
        carrinha30.setPrecoBase((double) 0L);
        Carrinha carrinha36 = new Carrinha();
        int i37 = carrinha36.getLugares();
        int i38 = carrinha30.compareTo((Veiculo) carrinha36);
        int i39 = carrinha36.getFiabilidade();
        Carrinha carrinha40 = carrinha36.clone();
        Coordenada coordenada41 = carrinha40.getCoordenadas();
        carrinha4.setCoordenadas(coordenada41);
        boolean b43 = carrinha1.equals((java.lang.Object) carrinha4);
        int i44 = carrinha4.getVelocidadeMedia();
        int i45 = carrinha4.getVelocidadeMedia();
        org.junit.Assert.assertTrue(i2 == 0);
        org.junit.Assert.assertNotNull(coordenada3);
        org.junit.Assert.assertTrue(b8 == false);
        org.junit.Assert.assertNotNull(coordenada9);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(carrinha19);
        org.junit.Assert.assertTrue(i23 == 0);
        org.junit.Assert.assertTrue(i24 == 3);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str25.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada26);
        org.junit.Assert.assertNotNull(carrinha33);
        org.junit.Assert.assertTrue(i37 == 0);
        org.junit.Assert.assertTrue(i38 == 3);
        org.junit.Assert.assertTrue(i39 == 0);
        org.junit.Assert.assertNotNull(carrinha40);
        org.junit.Assert.assertNotNull(coordenada41);
        org.junit.Assert.assertTrue(b43 == false);
        org.junit.Assert.assertTrue(i44 == 0);
        org.junit.Assert.assertTrue(i45 == 0);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha3.setOcupado(true);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        carrinha6.setVelocidadeMedia(10);
        int i10 = carrinha3.compareTo((Veiculo) carrinha6);
        Coordenada coordenada11 = carrinha3.getCoordenadas();
        int i12 = carrinha3.getLugares();
        carrinha3.setPrecoBase((double) 10.0f);
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i10 == 3);
        org.junit.Assert.assertNotNull(coordenada11);
        org.junit.Assert.assertTrue(i12 == 0);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        Carrinha carrinha2 = carrinha0.clone();
        Carrinha carrinha3 = new Carrinha(carrinha2);
        Coordenada coordenada4 = carrinha3.getCoordenadas();
        Carrinha carrinha5 = carrinha3.clone();
        Carrinha carrinha6 = new Carrinha();
        carrinha6.setMatricula("");
        boolean b10 = carrinha6.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada11 = carrinha6.getCoordenadas();
        boolean b12 = carrinha6.getOcupado();
        java.lang.String str13 = carrinha6.getMatricula();
        Carrinha carrinha18 = new Carrinha();
        carrinha18.setMatricula("");
        Carrinha carrinha21 = carrinha18.clone();
        carrinha18.setPrecoBase((double) 0L);
        Carrinha carrinha24 = new Carrinha();
        int i25 = carrinha24.getLugares();
        int i26 = carrinha18.compareTo((Veiculo) carrinha24);
        java.lang.String str27 = carrinha24.toString();
        Coordenada coordenada28 = carrinha24.getCoordenadas();
        Carrinha carrinha30 = new Carrinha((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada28, false);
        carrinha6.setCoordenadas(coordenada28);
        boolean b32 = carrinha3.equals((java.lang.Object) carrinha6);
        int i33 = carrinha3.getVelocidadeMedia();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(carrinha2);
        org.junit.Assert.assertNotNull(coordenada4);
        org.junit.Assert.assertNotNull(carrinha5);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertNotNull(coordenada11);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(carrinha21);
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue(i26 == 3);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str27.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada28);
        org.junit.Assert.assertTrue(b32 == false);
        org.junit.Assert.assertTrue(i33 == 0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        Carrinha carrinha4 = new Carrinha(carrinha0);
        carrinha4.setOcupado(true);
        java.lang.String str7 = carrinha4.getMatricula();
        Carrinha carrinha8 = new Carrinha(carrinha4);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "n/a" + "'", str7.equals("n/a"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        Carrinha carrinha4 = new Carrinha();
        carrinha4.setMatricula("");
        java.lang.String str7 = carrinha4.toString();
        Carrinha carrinha8 = new Carrinha();
        Carrinha carrinha9 = new Carrinha(carrinha8);
        java.lang.String str10 = carrinha8.toString();
        carrinha8.setFiabilidade(0);
        Carrinha carrinha13 = carrinha8.clone();
        Carrinha carrinha14 = new Carrinha();
        Carrinha carrinha15 = new Carrinha(carrinha14);
        Carrinha carrinha16 = new Carrinha(carrinha15);
        Carrinha carrinha17 = new Carrinha();
        Carrinha carrinha18 = new Carrinha(carrinha17);
        int i19 = carrinha15.compareTo((Veiculo) carrinha17);
        Carrinha carrinha20 = new Carrinha();
        carrinha20.setMatricula("");
        boolean b24 = carrinha20.equals((java.lang.Object) (-1.0d));
        boolean b25 = carrinha15.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha26 = new Carrinha();
        carrinha26.setMatricula("");
        Carrinha carrinha29 = carrinha26.clone();
        carrinha26.setPrecoBase((double) 0L);
        Carrinha carrinha32 = new Carrinha();
        int i33 = carrinha32.getLugares();
        int i34 = carrinha26.compareTo((Veiculo) carrinha32);
        java.lang.String str35 = carrinha32.toString();
        Coordenada coordenada36 = carrinha32.getCoordenadas();
        carrinha15.setCoordenadas(coordenada36);
        carrinha8.setCoordenadas(coordenada36);
        carrinha4.setCoordenadas(coordenada36);
        Carrinha carrinha41 = new Carrinha((int) '4', (double) 1.0f, 9, "hi!", coordenada36, false);
        carrinha41.setFiabilidade(100);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str7.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str10.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha13);
        org.junit.Assert.assertTrue(i19 == 0);
        org.junit.Assert.assertTrue(b24 == false);
        org.junit.Assert.assertTrue(b25 == false);
        org.junit.Assert.assertNotNull(carrinha29);
        org.junit.Assert.assertTrue(i33 == 0);
        org.junit.Assert.assertTrue(i34 == 3);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str35.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada36);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        java.lang.String str3 = carrinha0.toString();
        Carrinha carrinha4 = carrinha0.clone();
        Carrinha carrinha5 = new Carrinha();
        carrinha5.setMatricula("");
        boolean b9 = carrinha5.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha10 = new Carrinha(carrinha5);
        int i11 = carrinha10.getVelocidadeMedia();
        Carrinha carrinha12 = new Carrinha();
        Carrinha carrinha13 = new Carrinha(carrinha12);
        Carrinha carrinha14 = new Carrinha(carrinha13);
        Carrinha carrinha15 = new Carrinha();
        Carrinha carrinha16 = new Carrinha(carrinha15);
        int i17 = carrinha13.compareTo((Veiculo) carrinha15);
        Carrinha carrinha18 = new Carrinha();
        carrinha18.setMatricula("");
        boolean b22 = carrinha18.equals((java.lang.Object) (-1.0d));
        boolean b23 = carrinha13.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada24 = carrinha13.getCoordenadas();
        carrinha10.setCoordenadas(coordenada24);
        carrinha10.setMatricula("n/a");
        Coordenada coordenada28 = carrinha10.getCoordenadas();
        boolean b29 = carrinha10.getOcupado();
        Coordenada coordenada30 = carrinha10.getCoordenadas();
        carrinha4.setCoordenadas(coordenada30);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha4);
        org.junit.Assert.assertTrue(b9 == false);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(i17 == 0);
        org.junit.Assert.assertTrue(b22 == false);
        org.junit.Assert.assertTrue(b23 == false);
        org.junit.Assert.assertNotNull(coordenada24);
        org.junit.Assert.assertNotNull(coordenada28);
        org.junit.Assert.assertTrue(b29 == false);
        org.junit.Assert.assertNotNull(coordenada30);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carrinha0.getCoordenadas();
        carrinha0.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carrinha0.setFiabilidade(0);
        Carrinha carrinha10 = new Carrinha();
        carrinha10.setMatricula("");
        Carrinha carrinha13 = carrinha10.clone();
        carrinha10.setPrecoBase((double) 0L);
        Carrinha carrinha16 = new Carrinha(carrinha10);
        int i17 = carrinha0.compareTo((Veiculo) carrinha10);
        Carrinha carrinha18 = new Carrinha(carrinha10);
        java.lang.String str19 = carrinha10.toString();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertNotNull(carrinha13);
        org.junit.Assert.assertTrue(i17 == (-142));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str19.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        int i4 = carrinha3.getFiabilidade();
        java.lang.String str5 = carrinha3.toString();
        carrinha3.setOcupado(false);
        java.lang.String str8 = carrinha3.getMatricula();
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str5.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        Carrinha carrinha4 = new Carrinha(carrinha0);
        java.lang.String str5 = carrinha0.toString();
        int i6 = carrinha0.getVelocidadeMedia();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str5.equals("Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i6 == 10);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        Carrinha carrinha4 = new Carrinha(carrinha3);
        int i5 = carrinha1.compareTo((Veiculo) carrinha3);
        Carrinha carrinha10 = new Carrinha();
        carrinha10.setMatricula("");
        Carrinha carrinha13 = carrinha10.clone();
        carrinha10.setPrecoBase((double) 0L);
        Carrinha carrinha16 = new Carrinha();
        int i17 = carrinha16.getLugares();
        int i18 = carrinha10.compareTo((Veiculo) carrinha16);
        java.lang.String str19 = carrinha16.toString();
        Coordenada coordenada20 = carrinha16.getCoordenadas();
        Carrinha carrinha22 = new Carrinha((int) ' ', (double) 100.0f, (int) (byte) -1, "", coordenada20, false);
        int i23 = carrinha1.compareTo((Veiculo) carrinha22);
        java.lang.String str24 = carrinha22.toString();
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertNotNull(carrinha13);
        org.junit.Assert.assertTrue(i17 == 0);
        org.junit.Assert.assertTrue(i18 == 3);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str19.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada20);
        org.junit.Assert.assertTrue(i23 == (-3));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Matrícula: \nVelocidade Média/km: 32km/h\nPreço Base: 100.0€\nFiabilidade: -1\nLugares: 9\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str24.equals("Matrícula: \nVelocidade Média/km: 32km/h\nPreço Base: 100.0€\nFiabilidade: -1\nLugares: 9\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        java.lang.String str3 = carrinha0.toString();
        carrinha0.setPrecoBase((double) (short) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        Carrinha carrinha4 = new Carrinha(carrinha3);
        int i5 = carrinha1.compareTo((Veiculo) carrinha3);
        carrinha3.setMatricula("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        int i8 = carrinha3.getFiabilidade();
        Carrinha carrinha9 = carrinha3.clone();
        Carrinha carrinha10 = carrinha3.clone();
        double d11 = carrinha3.getPrecoBase();
        double d12 = carrinha3.getPrecoBase();
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertNotNull(carrinha9);
        org.junit.Assert.assertNotNull(carrinha10);
        org.junit.Assert.assertTrue(d11 == 0.0d);
        org.junit.Assert.assertTrue(d12 == 0.0d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha5 = new Carrinha(carrinha0);
        double d6 = carrinha0.getPrecoBase();
        boolean b7 = carrinha0.getOcupado();
        carrinha0.setOcupado(true);
        java.lang.String str10 = carrinha0.toString();
        Coordenada coordenada11 = carrinha0.getCoordenadas();
        java.lang.String str12 = carrinha0.getMatricula();
        Carrinha carrinha13 = new Carrinha();
        carrinha13.setMatricula("");
        Carrinha carrinha16 = carrinha13.clone();
        carrinha13.setPrecoBase((double) 0L);
        Carrinha carrinha19 = new Carrinha();
        int i20 = carrinha19.getLugares();
        int i21 = carrinha13.compareTo((Veiculo) carrinha19);
        Carrinha carrinha22 = new Carrinha();
        carrinha22.setMatricula("");
        Carrinha carrinha25 = carrinha22.clone();
        carrinha22.setPrecoBase((double) 0L);
        Carrinha carrinha28 = new Carrinha();
        int i29 = carrinha28.getLugares();
        int i30 = carrinha22.compareTo((Veiculo) carrinha28);
        java.lang.String str31 = carrinha28.toString();
        Coordenada coordenada32 = carrinha28.getCoordenadas();
        Carrinha carrinha33 = new Carrinha();
        int i34 = carrinha33.getLugares();
        Coordenada coordenada35 = carrinha33.getCoordenadas();
        carrinha28.setCoordenadas(coordenada35);
        Carrinha carrinha37 = new Carrinha(carrinha28);
        int i38 = carrinha13.compareTo((Veiculo) carrinha28);
        int i39 = carrinha28.getFiabilidade();
        boolean b40 = carrinha0.equals((java.lang.Object) i39);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(b7 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n" + "'", str10.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n"));
        org.junit.Assert.assertNotNull(coordenada11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNotNull(carrinha16);
        org.junit.Assert.assertTrue(i20 == 0);
        org.junit.Assert.assertTrue(i21 == 3);
        org.junit.Assert.assertNotNull(carrinha25);
        org.junit.Assert.assertTrue(i29 == 0);
        org.junit.Assert.assertTrue(i30 == 3);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str31.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada32);
        org.junit.Assert.assertTrue(i34 == 0);
        org.junit.Assert.assertNotNull(coordenada35);
        org.junit.Assert.assertTrue(i38 == 3);
        org.junit.Assert.assertTrue(i39 == 0);
        org.junit.Assert.assertTrue(b40 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha(carrinha0);
        carrinha6.setPrecoBase((double) (-1.0f));
        carrinha6.setVelocidadeMedia((int) (short) 0);
        carrinha6.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Carrinha carrinha13 = new Carrinha(carrinha6);
        carrinha6.setPrecoBase(1.0d);
        boolean b16 = carrinha6.getOcupado();
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(b16 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        Carrinha carrinha4 = new Carrinha(carrinha0);
        Carrinha carrinha5 = new Carrinha(carrinha4);
        int i6 = carrinha4.getLugares();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i6 == 0);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        java.lang.String str2 = carrinha0.getMatricula();
        Carrinha carrinha3 = new Carrinha(carrinha0);
        carrinha3.setVelocidadeMedia((int) '4');
        Coordenada coordenada6 = carrinha3.getCoordenadas();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "n/a" + "'", str2.equals("n/a"));
        org.junit.Assert.assertNotNull(coordenada6);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        java.lang.String str9 = carrinha6.toString();
        int i10 = carrinha6.getFiabilidade();
        Carrinha carrinha11 = new Carrinha();
        Carrinha carrinha12 = new Carrinha(carrinha11);
        java.lang.String str13 = carrinha11.toString();
        carrinha11.setFiabilidade(0);
        Carrinha carrinha16 = carrinha11.clone();
        int i17 = carrinha16.getFiabilidade();
        Coordenada coordenada18 = carrinha16.getCoordenadas();
        carrinha6.setCoordenadas(coordenada18);
        Carrinha carrinha20 = new Carrinha();
        carrinha20.setMatricula("");
        Carrinha carrinha23 = carrinha20.clone();
        carrinha20.setPrecoBase((double) 0L);
        Carrinha carrinha26 = new Carrinha();
        int i27 = carrinha26.getLugares();
        int i28 = carrinha20.compareTo((Veiculo) carrinha26);
        int i29 = carrinha26.getFiabilidade();
        Carrinha carrinha30 = carrinha26.clone();
        Coordenada coordenada31 = carrinha30.getCoordenadas();
        boolean b32 = carrinha6.equals((java.lang.Object) carrinha30);
        int i33 = carrinha30.getLugares();
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str13.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha16);
        org.junit.Assert.assertTrue(i17 == 0);
        org.junit.Assert.assertNotNull(coordenada18);
        org.junit.Assert.assertNotNull(carrinha23);
        org.junit.Assert.assertTrue(i27 == 0);
        org.junit.Assert.assertTrue(i28 == 3);
        org.junit.Assert.assertTrue(i29 == 0);
        org.junit.Assert.assertNotNull(carrinha30);
        org.junit.Assert.assertNotNull(coordenada31);
        org.junit.Assert.assertTrue(b32 == true);
        org.junit.Assert.assertTrue(i33 == 0);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        Carrinha carrinha4 = new Carrinha(carrinha3);
        int i5 = carrinha1.compareTo((Veiculo) carrinha3);
        Carrinha carrinha6 = new Carrinha();
        carrinha6.setMatricula("");
        boolean b10 = carrinha6.equals((java.lang.Object) (-1.0d));
        boolean b11 = carrinha1.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha12 = new Carrinha(carrinha1);
        int i13 = carrinha1.getVelocidadeMedia();
        double d14 = carrinha1.getPrecoBase();
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(d14 == 0.0d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha5 = new Carrinha(carrinha0);
        int i6 = carrinha5.getVelocidadeMedia();
        Carrinha carrinha7 = new Carrinha();
        Carrinha carrinha8 = new Carrinha(carrinha7);
        Carrinha carrinha9 = new Carrinha(carrinha8);
        Carrinha carrinha10 = new Carrinha();
        Carrinha carrinha11 = new Carrinha(carrinha10);
        int i12 = carrinha8.compareTo((Veiculo) carrinha10);
        Carrinha carrinha13 = new Carrinha();
        carrinha13.setMatricula("");
        boolean b17 = carrinha13.equals((java.lang.Object) (-1.0d));
        boolean b18 = carrinha8.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada19 = carrinha8.getCoordenadas();
        carrinha5.setCoordenadas(coordenada19);
        carrinha5.setMatricula("n/a");
        Carrinha carrinha23 = carrinha5.clone();
        carrinha23.setOcupado(true);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertTrue(b17 == false);
        org.junit.Assert.assertTrue(b18 == false);
        org.junit.Assert.assertNotNull(coordenada19);
        org.junit.Assert.assertNotNull(carrinha23);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha3.setOcupado(true);
        java.lang.String str6 = carrinha3.toString();
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n" + "'", str6.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha5 = new Carrinha(carrinha0);
        int i6 = carrinha5.getVelocidadeMedia();
        Carrinha carrinha7 = new Carrinha();
        Carrinha carrinha8 = new Carrinha(carrinha7);
        Carrinha carrinha9 = new Carrinha(carrinha8);
        Carrinha carrinha10 = new Carrinha();
        Carrinha carrinha11 = new Carrinha(carrinha10);
        int i12 = carrinha8.compareTo((Veiculo) carrinha10);
        Carrinha carrinha13 = new Carrinha();
        carrinha13.setMatricula("");
        boolean b17 = carrinha13.equals((java.lang.Object) (-1.0d));
        boolean b18 = carrinha8.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada19 = carrinha8.getCoordenadas();
        carrinha5.setCoordenadas(coordenada19);
        int i21 = carrinha5.getLugares();
        Coordenada coordenada22 = carrinha5.getCoordenadas();
        carrinha5.setPrecoBase((double) 10.0f);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertTrue(b17 == false);
        org.junit.Assert.assertTrue(b18 == false);
        org.junit.Assert.assertNotNull(coordenada19);
        org.junit.Assert.assertTrue(i21 == 0);
        org.junit.Assert.assertNotNull(coordenada22);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        java.lang.String str2 = carrinha0.toString();
        carrinha0.setFiabilidade(0);
        Carrinha carrinha5 = carrinha0.clone();
        int i6 = carrinha0.getLugares();
        java.lang.Object obj7 = new java.lang.Object();
        boolean b8 = carrinha0.equals(obj7);
        java.lang.String str9 = carrinha0.toString();
        Coordenada coordenada10 = carrinha0.getCoordenadas();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha5);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertTrue(b8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada10);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        Carrinha carrinha9 = new Carrinha(carrinha6);
        int i10 = carrinha9.getLugares();
        carrinha9.setPrecoBase(100.0d);
        int i13 = carrinha9.getLugares();
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i13 == 0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        java.lang.String str2 = carrinha0.toString();
        carrinha0.setFiabilidade(0);
        carrinha0.setOcupado(true);
        boolean b7 = carrinha0.getOcupado();
        carrinha0.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        double d10 = carrinha0.getPrecoBase();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(b7 == true);
        org.junit.Assert.assertTrue(d10 == 0.0d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        Carrinha carrinha4 = new Carrinha(carrinha0);
        int i5 = carrinha0.getVelocidadeMedia();
        carrinha0.setMatricula("");
        int i8 = carrinha0.getFiabilidade();
        double d9 = carrinha0.getPrecoBase();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i5 == 10);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue(d9 == 0.0d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        java.lang.String str3 = carrinha0.toString();
        Carrinha carrinha4 = carrinha0.clone();
        carrinha4.setOcupado(true);
        Carrinha carrinha7 = new Carrinha();
        Carrinha carrinha8 = new Carrinha(carrinha7);
        java.lang.String str9 = carrinha7.toString();
        carrinha7.setFiabilidade(0);
        int i12 = carrinha7.getFiabilidade();
        Carrinha carrinha13 = new Carrinha(carrinha7);
        boolean b14 = carrinha4.equals((java.lang.Object) carrinha13);
        int i15 = carrinha4.getVelocidadeMedia();
        int i16 = carrinha4.getFiabilidade();
        Coordenada coordenada17 = carrinha4.getCoordenadas();
        Carrinha carrinha18 = carrinha4.clone();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertTrue(i15 == 0);
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertNotNull(coordenada17);
        org.junit.Assert.assertNotNull(carrinha18);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        java.lang.String str3 = carrinha0.toString();
        Carrinha carrinha4 = carrinha0.clone();
        carrinha4.setOcupado(true);
        Carrinha carrinha7 = new Carrinha();
        Carrinha carrinha8 = new Carrinha(carrinha7);
        java.lang.String str9 = carrinha7.toString();
        carrinha7.setFiabilidade(0);
        int i12 = carrinha7.getFiabilidade();
        Carrinha carrinha13 = new Carrinha(carrinha7);
        boolean b14 = carrinha4.equals((java.lang.Object) carrinha13);
        boolean b16 = carrinha4.equals((java.lang.Object) 10L);
        Carrinha carrinha21 = new Carrinha();
        carrinha21.setMatricula("");
        Carrinha carrinha24 = carrinha21.clone();
        Coordenada coordenada25 = carrinha24.getCoordenadas();
        Carrinha carrinha27 = new Carrinha((int) (byte) -1, (double) 0, (int) (short) 1, "", coordenada25, false);
        carrinha27.setOcupado(false);
        int i30 = carrinha4.compareTo((Veiculo) carrinha27);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertTrue(b16 == false);
        org.junit.Assert.assertNotNull(carrinha24);
        org.junit.Assert.assertNotNull(coordenada25);
        org.junit.Assert.assertTrue(i30 == 0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        Carrinha carrinha12 = new Carrinha();
        carrinha12.setMatricula("");
        Carrinha carrinha15 = carrinha12.clone();
        carrinha12.setPrecoBase((double) 0L);
        Carrinha carrinha18 = new Carrinha();
        int i19 = carrinha18.getLugares();
        int i20 = carrinha12.compareTo((Veiculo) carrinha18);
        java.lang.String str21 = carrinha18.toString();
        Coordenada coordenada22 = carrinha18.getCoordenadas();
        Carrinha carrinha24 = new Carrinha((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada22, false);
        Carrinha carrinha26 = new Carrinha((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada22, true);
        Carrinha carrinha28 = new Carrinha((int) '#', 10.0d, (-1), "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada22, true);
        Coordenada coordenada29 = carrinha28.getCoordenadas();
        java.lang.String str30 = carrinha28.getMatricula();
        java.lang.String str31 = carrinha28.toString();
        org.junit.Assert.assertNotNull(carrinha15);
        org.junit.Assert.assertTrue(i19 == 0);
        org.junit.Assert.assertTrue(i20 == 3);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str21.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada22);
        org.junit.Assert.assertNotNull(coordenada29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str30.equals("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Matrícula: Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 35km/h\nPreço Base: 10.0€\nFiabilidade: -1\nLugares: 9\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n" + "'", str31.equals("Matrícula: Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 35km/h\nPreço Base: 10.0€\nFiabilidade: -1\nLugares: 9\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        int i4 = carrinha3.getLugares();
        boolean b5 = carrinha2.equals((java.lang.Object) carrinha3);
        Carrinha carrinha6 = carrinha3.clone();
        carrinha6.setVelocidadeMedia((int) (short) 0);
        int i9 = carrinha6.getLugares();
        boolean b10 = carrinha6.getOcupado();
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue(b5 == true);
        org.junit.Assert.assertNotNull(carrinha6);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertTrue(b10 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        Carrinha carrinha4 = new Carrinha(carrinha3);
        int i5 = carrinha1.compareTo((Veiculo) carrinha3);
        Carrinha carrinha6 = new Carrinha();
        carrinha6.setMatricula("");
        boolean b10 = carrinha6.equals((java.lang.Object) (-1.0d));
        boolean b11 = carrinha1.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha12 = new Carrinha(carrinha1);
        int i13 = carrinha1.getVelocidadeMedia();
        Carrinha carrinha14 = new Carrinha();
        carrinha14.setMatricula("");
        Carrinha carrinha17 = carrinha14.clone();
        carrinha14.setPrecoBase((double) 0L);
        Carrinha carrinha20 = new Carrinha();
        int i21 = carrinha20.getLugares();
        int i22 = carrinha14.compareTo((Veiculo) carrinha20);
        java.lang.String str23 = carrinha20.toString();
        int i24 = carrinha20.getFiabilidade();
        boolean b25 = carrinha1.equals((java.lang.Object) i24);
        carrinha1.setMatricula("hi!");
        carrinha1.setFiabilidade((-1));
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertNotNull(carrinha17);
        org.junit.Assert.assertTrue(i21 == 0);
        org.junit.Assert.assertTrue(i22 == 3);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str23.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i24 == 0);
        org.junit.Assert.assertTrue(b25 == false);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        java.lang.String str2 = carrinha0.toString();
        double d3 = carrinha0.getPrecoBase();
        carrinha0.setOcupado(false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(d3 == 0.0d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        Carrinha carrinha4 = new Carrinha(carrinha3);
        int i5 = carrinha1.compareTo((Veiculo) carrinha3);
        Carrinha carrinha6 = new Carrinha();
        carrinha6.setMatricula("");
        boolean b10 = carrinha6.equals((java.lang.Object) (-1.0d));
        boolean b11 = carrinha1.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha12 = new Carrinha(carrinha1);
        int i13 = carrinha1.getVelocidadeMedia();
        Carrinha carrinha14 = new Carrinha();
        carrinha14.setMatricula("");
        Carrinha carrinha17 = carrinha14.clone();
        carrinha14.setPrecoBase((double) 0L);
        Carrinha carrinha20 = new Carrinha();
        int i21 = carrinha20.getLugares();
        int i22 = carrinha14.compareTo((Veiculo) carrinha20);
        java.lang.String str23 = carrinha20.toString();
        int i24 = carrinha20.getFiabilidade();
        boolean b25 = carrinha1.equals((java.lang.Object) i24);
        int i26 = carrinha1.getVelocidadeMedia();
        Carrinha carrinha27 = carrinha1.clone();
        Coordenada coordenada28 = carrinha27.getCoordenadas();
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertNotNull(carrinha17);
        org.junit.Assert.assertTrue(i21 == 0);
        org.junit.Assert.assertTrue(i22 == 3);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str23.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i24 == 0);
        org.junit.Assert.assertTrue(b25 == false);
        org.junit.Assert.assertTrue(i26 == 0);
        org.junit.Assert.assertNotNull(carrinha27);
        org.junit.Assert.assertNotNull(coordenada28);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        java.lang.String str2 = carrinha0.getMatricula();
        Carrinha carrinha3 = new Carrinha(carrinha0);
        carrinha0.setOcupado(true);
        java.lang.String str6 = carrinha0.toString();
        Carrinha carrinha7 = new Carrinha();
        int i8 = carrinha7.getLugares();
        java.lang.String str9 = carrinha7.getMatricula();
        Carrinha carrinha10 = new Carrinha(carrinha7);
        int i11 = carrinha7.getVelocidadeMedia();
        int i12 = carrinha0.compareTo((Veiculo) carrinha7);
        carrinha0.setPrecoBase((double) 9);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "n/a" + "'", str2.equals("n/a"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n" + "'", str6.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n"));
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "n/a" + "'", str9.equals("n/a"));
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(i12 == 0);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carrinha0.getCoordenadas();
        java.lang.String str6 = carrinha0.toString();
        Carrinha carrinha7 = new Carrinha();
        carrinha7.setMatricula("");
        Carrinha carrinha10 = carrinha7.clone();
        carrinha7.setPrecoBase((double) 0L);
        Carrinha carrinha13 = new Carrinha();
        int i14 = carrinha13.getLugares();
        int i15 = carrinha7.compareTo((Veiculo) carrinha13);
        Carrinha carrinha16 = new Carrinha();
        carrinha16.setMatricula("");
        Carrinha carrinha19 = carrinha16.clone();
        carrinha16.setPrecoBase((double) 0L);
        Carrinha carrinha22 = new Carrinha();
        int i23 = carrinha22.getLugares();
        int i24 = carrinha16.compareTo((Veiculo) carrinha22);
        java.lang.String str25 = carrinha22.toString();
        Coordenada coordenada26 = carrinha22.getCoordenadas();
        Carrinha carrinha27 = new Carrinha();
        int i28 = carrinha27.getLugares();
        Coordenada coordenada29 = carrinha27.getCoordenadas();
        carrinha22.setCoordenadas(coordenada29);
        Carrinha carrinha31 = new Carrinha(carrinha22);
        int i32 = carrinha7.compareTo((Veiculo) carrinha22);
        int i33 = carrinha22.getFiabilidade();
        int i34 = carrinha0.compareTo((Veiculo) carrinha22);
        boolean b35 = carrinha22.getOcupado();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str6.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha10);
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(i15 == 3);
        org.junit.Assert.assertNotNull(carrinha19);
        org.junit.Assert.assertTrue(i23 == 0);
        org.junit.Assert.assertTrue(i24 == 3);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str25.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada26);
        org.junit.Assert.assertTrue(i28 == 0);
        org.junit.Assert.assertNotNull(coordenada29);
        org.junit.Assert.assertTrue(i32 == 3);
        org.junit.Assert.assertTrue(i33 == 0);
        org.junit.Assert.assertTrue(i34 == 3);
        org.junit.Assert.assertTrue(b35 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setVelocidadeMedia((int) '4');
        Coordenada coordenada6 = carrinha0.getCoordenadas();
        org.junit.Assert.assertNotNull(carrinha3);
        org.junit.Assert.assertNotNull(coordenada6);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        java.lang.String str5 = carrinha0.getMatricula();
        java.lang.Object obj6 = null;
        boolean b7 = carrinha0.equals(obj6);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue(b7 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carrinha0.getCoordenadas();
        java.lang.String str6 = carrinha0.toString();
        double d7 = carrinha0.getPrecoBase();
        Carrinha carrinha12 = new Carrinha();
        carrinha12.setMatricula("");
        boolean b16 = carrinha12.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada17 = carrinha12.getCoordenadas();
        carrinha12.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carrinha12.setFiabilidade(0);
        Carrinha carrinha22 = new Carrinha();
        carrinha22.setMatricula("");
        Carrinha carrinha25 = carrinha22.clone();
        carrinha22.setPrecoBase((double) 0L);
        Carrinha carrinha28 = new Carrinha(carrinha22);
        int i29 = carrinha12.compareTo((Veiculo) carrinha22);
        Carrinha carrinha30 = new Carrinha(carrinha22);
        Coordenada coordenada31 = carrinha30.getCoordenadas();
        Carrinha carrinha33 = new Carrinha((int) (byte) 0, (double) 0L, (int) (byte) 0, "n/a", coordenada31, true);
        boolean b34 = carrinha0.equals((java.lang.Object) (byte) 0);
        int i35 = carrinha0.getFiabilidade();
        java.lang.String str36 = carrinha0.toString();
        java.lang.String str37 = carrinha0.toString();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str6.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(d7 == 0.0d);
        org.junit.Assert.assertTrue(b16 == false);
        org.junit.Assert.assertNotNull(coordenada17);
        org.junit.Assert.assertNotNull(carrinha25);
        org.junit.Assert.assertTrue(i29 == (-142));
        org.junit.Assert.assertNotNull(coordenada31);
        org.junit.Assert.assertTrue(b34 == false);
        org.junit.Assert.assertTrue(i35 == 0);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str36.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str37.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        Carrinha carrinha4 = new Carrinha(carrinha3);
        int i5 = carrinha1.compareTo((Veiculo) carrinha3);
        carrinha3.setMatricula("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        int i8 = carrinha3.getFiabilidade();
        carrinha3.setFiabilidade(0);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(i8 == 0);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        java.lang.String str2 = carrinha0.toString();
        carrinha0.setFiabilidade(0);
        int i5 = carrinha0.getFiabilidade();
        Carrinha carrinha6 = new Carrinha();
        carrinha6.setMatricula("");
        java.lang.String str9 = carrinha6.toString();
        Carrinha carrinha10 = carrinha6.clone();
        carrinha10.setOcupado(true);
        Carrinha carrinha13 = new Carrinha();
        Carrinha carrinha14 = new Carrinha(carrinha13);
        java.lang.String str15 = carrinha13.toString();
        carrinha13.setFiabilidade(0);
        int i18 = carrinha13.getFiabilidade();
        Carrinha carrinha19 = new Carrinha(carrinha13);
        boolean b20 = carrinha10.equals((java.lang.Object) carrinha19);
        carrinha10.setPrecoBase((double) 1);
        int i23 = carrinha0.compareTo((Veiculo) carrinha10);
        carrinha10.setFiabilidade((int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha10);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str15.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i18 == 0);
        org.junit.Assert.assertTrue(b20 == false);
        org.junit.Assert.assertTrue(i23 == (-3));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        Carrinha carrinha4 = new Carrinha(carrinha3);
        int i5 = carrinha1.compareTo((Veiculo) carrinha3);
        Carrinha carrinha6 = new Carrinha(carrinha3);
        Carrinha carrinha7 = carrinha6.clone();
        Coordenada coordenada8 = carrinha6.getCoordenadas();
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertNotNull(carrinha7);
        org.junit.Assert.assertNotNull(coordenada8);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        Carrinha carrinha4 = new Carrinha(carrinha3);
        int i5 = carrinha1.compareTo((Veiculo) carrinha3);
        int i6 = carrinha3.getVelocidadeMedia();
        carrinha3.setVelocidadeMedia((int) (short) 10);
        carrinha3.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(i6 == 0);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha5 = new Carrinha(carrinha0);
        double d6 = carrinha0.getPrecoBase();
        java.lang.String str7 = carrinha0.toString();
        int i8 = carrinha0.getVelocidadeMedia();
        double d9 = carrinha0.getPrecoBase();
        int i10 = carrinha0.getVelocidadeMedia();
        carrinha0.setFiabilidade((int) (byte) -1);
        java.lang.String str13 = carrinha0.getMatricula();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str7.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha();
        Carrinha carrinha2 = new Carrinha(carrinha1);
        int i3 = carrinha2.getFiabilidade();
        Coordenada coordenada4 = carrinha2.getCoordenadas();
        carrinha0.setCoordenadas(coordenada4);
        java.lang.String str6 = carrinha0.toString();
        int i7 = carrinha0.getFiabilidade();
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertNotNull(coordenada4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str6.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i7 == 0);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        int i4 = carrinha3.getLugares();
        boolean b5 = carrinha2.equals((java.lang.Object) carrinha3);
        Carrinha carrinha6 = carrinha3.clone();
        carrinha6.setVelocidadeMedia((int) (short) 0);
        int i9 = carrinha6.getLugares();
        carrinha6.setMatricula("Matrícula: \nVelocidade Média/km: -1km/h\nPreço Base: 0.0€\nFiabilidade: 1\nLugares: 9\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Coordenada coordenada12 = carrinha6.getCoordenadas();
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue(b5 == true);
        org.junit.Assert.assertNotNull(carrinha6);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertNotNull(coordenada12);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        Carrinha carrinha4 = new Carrinha(carrinha3);
        int i5 = carrinha1.compareTo((Veiculo) carrinha3);
        Carrinha carrinha6 = new Carrinha();
        carrinha6.setMatricula("");
        boolean b10 = carrinha6.equals((java.lang.Object) (-1.0d));
        boolean b11 = carrinha1.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha12 = new Carrinha(carrinha1);
        int i13 = carrinha1.getVelocidadeMedia();
        Carrinha carrinha14 = new Carrinha();
        carrinha14.setMatricula("");
        Carrinha carrinha17 = carrinha14.clone();
        carrinha14.setPrecoBase((double) 0L);
        Carrinha carrinha20 = new Carrinha();
        int i21 = carrinha20.getLugares();
        int i22 = carrinha14.compareTo((Veiculo) carrinha20);
        java.lang.String str23 = carrinha20.toString();
        int i24 = carrinha20.getFiabilidade();
        boolean b25 = carrinha1.equals((java.lang.Object) i24);
        int i26 = carrinha1.getVelocidadeMedia();
        Carrinha carrinha27 = carrinha1.clone();
        carrinha1.setOcupado(true);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertNotNull(carrinha17);
        org.junit.Assert.assertTrue(i21 == 0);
        org.junit.Assert.assertTrue(i22 == 3);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str23.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i24 == 0);
        org.junit.Assert.assertTrue(b25 == false);
        org.junit.Assert.assertTrue(i26 == 0);
        org.junit.Assert.assertNotNull(carrinha27);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        java.lang.String str2 = carrinha0.toString();
        carrinha0.setMatricula("hi!");
        Carrinha carrinha5 = carrinha0.clone();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carrinha5);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carrinha0.getCoordenadas();
        carrinha0.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Carrinha carrinha8 = new Carrinha(carrinha0);
        Carrinha carrinha9 = carrinha8.clone();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertNotNull(carrinha9);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        carrinha0.setMatricula("n/a");
        Carrinha carrinha6 = new Carrinha(carrinha0);
        carrinha6.setFiabilidade((-3));
        int i9 = carrinha6.getFiabilidade();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i9 == (-3));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carrinha0.getCoordenadas();
        carrinha0.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carrinha0.setFiabilidade(0);
        Carrinha carrinha10 = new Carrinha();
        carrinha10.setMatricula("");
        Carrinha carrinha13 = carrinha10.clone();
        carrinha10.setPrecoBase((double) 0L);
        Carrinha carrinha16 = new Carrinha(carrinha10);
        int i17 = carrinha0.compareTo((Veiculo) carrinha10);
        Carrinha carrinha18 = new Carrinha(carrinha10);
        carrinha18.setOcupado(false);
        java.lang.String str21 = carrinha18.getMatricula();
        int i22 = carrinha18.getLugares();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertNotNull(carrinha13);
        org.junit.Assert.assertTrue(i17 == (-142));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertTrue(i22 == 0);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        Carrinha carrinha4 = new Carrinha(carrinha0);
        Carrinha carrinha5 = new Carrinha(carrinha4);
        int i6 = carrinha5.getFiabilidade();
        Carrinha carrinha7 = carrinha5.clone();
        carrinha7.setOcupado(false);
        Coordenada coordenada10 = carrinha7.getCoordenadas();
        Carrinha carrinha11 = carrinha7.clone();
        boolean b12 = carrinha11.getOcupado();
        Carrinha carrinha13 = new Carrinha(carrinha11);
        java.lang.String str14 = carrinha13.toString();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertNotNull(carrinha7);
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertNotNull(carrinha11);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str14.equals("Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }
}

