import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ErrorTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test001");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha7 = new Carrinha();
        carrinha7.setMatricula("");
        Carrinha carrinha10 = carrinha7.clone();
        carrinha7.setPrecoBase((double) 0L);
        Carrinha carrinha13 = new Carrinha();
        int i14 = carrinha13.getLugares();
        int i15 = carrinha7.compareTo((Veiculo) carrinha13);
        java.lang.String str16 = carrinha13.toString();
        Coordenada coordenada17 = carrinha13.getCoordenadas();
        Carrinha carrinha19 = new Carrinha((int) ' ', (double) 100.0f, (int) (byte) -1, "", coordenada17, false);
        carrinha0.setCoordenadas(coordenada17);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha10 and carrinha19", (carrinha10.compareTo(carrinha19) == 0) == carrinha10.equals(carrinha19));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test002");
        Carrinha carrinha8 = new Carrinha();
        carrinha8.setMatricula("");
        Carrinha carrinha11 = carrinha8.clone();
        carrinha8.setPrecoBase((double) 0L);
        Carrinha carrinha14 = new Carrinha();
        int i15 = carrinha14.getLugares();
        int i16 = carrinha8.compareTo((Veiculo) carrinha14);
        java.lang.String str17 = carrinha14.toString();
        Coordenada coordenada18 = carrinha14.getCoordenadas();
        Carrinha carrinha20 = new Carrinha((int) ' ', (double) 100.0f, (int) (byte) -1, "", coordenada18, false);
        Carrinha carrinha22 = new Carrinha(100, (double) 10, (int) (short) 100, "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, true);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha11 and carrinha20", (carrinha11.compareTo(carrinha20) == 0) == carrinha11.equals(carrinha20));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test003");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha3.setOcupado(true);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        carrinha6.setVelocidadeMedia(10);
        int i10 = carrinha3.compareTo((Veiculo) carrinha6);
        Carrinha carrinha15 = new Carrinha();
        carrinha15.setMatricula("");
        Carrinha carrinha18 = carrinha15.clone();
        carrinha15.setPrecoBase((double) 0L);
        Carrinha carrinha21 = new Carrinha();
        int i22 = carrinha21.getLugares();
        int i23 = carrinha15.compareTo((Veiculo) carrinha21);
        java.lang.String str24 = carrinha21.toString();
        Coordenada coordenada25 = carrinha21.getCoordenadas();
        Carrinha carrinha27 = new Carrinha((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada25, false);
        carrinha3.setCoordenadas(coordenada25);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha21 and carrinha6", (carrinha21.compareTo(carrinha6) == 0) == carrinha21.equals(carrinha6));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test004");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha3.setOcupado(true);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        carrinha6.setVelocidadeMedia(10);
        int i10 = carrinha3.compareTo((Veiculo) carrinha6);
        Carrinha carrinha11 = new Carrinha();
        carrinha11.setMatricula("");
        Carrinha carrinha14 = carrinha11.clone();
        carrinha11.setPrecoBase((double) 0L);
        Carrinha carrinha17 = new Carrinha();
        int i18 = carrinha17.getLugares();
        int i19 = carrinha11.compareTo((Veiculo) carrinha17);
        java.lang.String str20 = carrinha17.toString();
        Coordenada coordenada21 = carrinha17.getCoordenadas();
        carrinha3.setCoordenadas(coordenada21);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha6 and carrinha17", (carrinha6.compareTo(carrinha17) == 0) == carrinha6.equals(carrinha17));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test005");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha5 = new Carrinha(carrinha0);
        double d6 = carrinha0.getPrecoBase();
        boolean b7 = carrinha0.getOcupado();
        int i8 = carrinha0.getVelocidadeMedia();
        Carrinha carrinha9 = new Carrinha();
        carrinha9.setMatricula("");
        Carrinha carrinha12 = carrinha9.clone();
        carrinha12.setOcupado(true);
        Carrinha carrinha15 = new Carrinha();
        int i16 = carrinha15.getLugares();
        carrinha15.setVelocidadeMedia(10);
        int i19 = carrinha12.compareTo((Veiculo) carrinha15);
        Coordenada coordenada20 = carrinha12.getCoordenadas();
        boolean b21 = carrinha0.equals((java.lang.Object) coordenada20);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha5 and carrinha12", (carrinha5.compareTo(carrinha12) == 0) == carrinha5.equals(carrinha12));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test006");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        Carrinha carrinha4 = new Carrinha();
        carrinha4.setMatricula("");
        Carrinha carrinha7 = carrinha4.clone();
        carrinha7.setOcupado(true);
        Carrinha carrinha10 = new Carrinha();
        int i11 = carrinha10.getLugares();
        carrinha10.setVelocidadeMedia(10);
        int i14 = carrinha7.compareTo((Veiculo) carrinha10);
        Carrinha carrinha15 = carrinha7.clone();
        int i16 = carrinha3.compareTo((Veiculo) carrinha15);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha7 and carrinha4", (carrinha7.compareTo(carrinha4) == 0) == carrinha7.equals(carrinha4));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test007");
        Carrinha carrinha4 = new Carrinha();
        int i5 = carrinha4.getLugares();
        carrinha4.setVelocidadeMedia(10);
        carrinha4.setMatricula("n/a");
        Carrinha carrinha10 = new Carrinha();
        carrinha10.setMatricula("");
        Carrinha carrinha13 = carrinha10.clone();
        carrinha10.setPrecoBase((double) 0L);
        Carrinha carrinha16 = new Carrinha();
        int i17 = carrinha16.getLugares();
        int i18 = carrinha10.compareTo((Veiculo) carrinha16);
        java.lang.String str19 = carrinha16.toString();
        Coordenada coordenada20 = carrinha16.getCoordenadas();
        Carrinha carrinha21 = new Carrinha();
        int i22 = carrinha21.getLugares();
        Coordenada coordenada23 = carrinha21.getCoordenadas();
        carrinha16.setCoordenadas(coordenada23);
        carrinha4.setCoordenadas(coordenada23);
        Carrinha carrinha27 = new Carrinha((int) (byte) -1, (double) 1.0f, (int) '#', "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada23, false);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha21 and carrinha4", (carrinha21.compareTo(carrinha4) == 0) == carrinha21.equals(carrinha4));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test008");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        java.lang.String str9 = carrinha6.toString();
        Coordenada coordenada10 = carrinha6.getCoordenadas();
        Carrinha carrinha15 = new Carrinha();
        carrinha15.setMatricula("");
        Carrinha carrinha18 = carrinha15.clone();
        carrinha15.setPrecoBase((double) 0L);
        Carrinha carrinha21 = new Carrinha();
        int i22 = carrinha21.getLugares();
        int i23 = carrinha15.compareTo((Veiculo) carrinha21);
        java.lang.String str24 = carrinha21.toString();
        Coordenada coordenada25 = carrinha21.getCoordenadas();
        Carrinha carrinha27 = new Carrinha((int) (byte) 100, (double) '#', (int) (short) 0, "", coordenada25, false);
        carrinha6.setCoordenadas(coordenada25);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha27 and carrinha0", (carrinha27.compareTo(carrinha0) == 0) == carrinha27.equals(carrinha0));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test009");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        int i9 = carrinha6.getFiabilidade();
        Carrinha carrinha10 = carrinha6.clone();
        Carrinha carrinha11 = new Carrinha();
        int i12 = carrinha11.getLugares();
        carrinha11.setVelocidadeMedia(10);
        Carrinha carrinha15 = new Carrinha(carrinha11);
        Coordenada coordenada16 = carrinha11.getCoordenadas();
        carrinha10.setCoordenadas(coordenada16);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha11 and carrinha6", (carrinha11.compareTo(carrinha6) == 0) == carrinha11.equals(carrinha6));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test010");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        Carrinha carrinha4 = new Carrinha(carrinha3);
        int i5 = carrinha1.compareTo((Veiculo) carrinha3);
        carrinha1.setVelocidadeMedia((int) (short) 100);
        Carrinha carrinha8 = new Carrinha();
        int i9 = carrinha8.getLugares();
        carrinha8.setVelocidadeMedia(10);
        carrinha8.setMatricula("n/a");
        Carrinha carrinha14 = new Carrinha();
        carrinha14.setMatricula("");
        Carrinha carrinha17 = carrinha14.clone();
        carrinha14.setPrecoBase((double) 0L);
        Carrinha carrinha20 = new Carrinha();
        int i21 = carrinha20.getLugares();
        int i22 = carrinha14.compareTo((Veiculo) carrinha20);
        java.lang.String str23 = carrinha20.toString();
        Coordenada coordenada24 = carrinha20.getCoordenadas();
        Carrinha carrinha25 = new Carrinha();
        int i26 = carrinha25.getLugares();
        Coordenada coordenada27 = carrinha25.getCoordenadas();
        carrinha20.setCoordenadas(coordenada27);
        carrinha8.setCoordenadas(coordenada27);
        Carrinha carrinha30 = carrinha8.clone();
        int i31 = carrinha1.compareTo((Veiculo) carrinha8);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha4 and carrinha30", (carrinha4.compareTo(carrinha30) == 0) == carrinha4.equals(carrinha30));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test011");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha3.setOcupado(true);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        carrinha6.setVelocidadeMedia(10);
        int i10 = carrinha3.compareTo((Veiculo) carrinha6);
        Carrinha carrinha11 = carrinha3.clone();
        double d12 = carrinha3.getPrecoBase();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha0 and carrinha11", (carrinha0.compareTo(carrinha11) == 0) == carrinha0.equals(carrinha11));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test012");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha3.setOcupado(true);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        carrinha6.setVelocidadeMedia(10);
        int i10 = carrinha3.compareTo((Veiculo) carrinha6);
        Carrinha carrinha11 = carrinha3.clone();
        carrinha3.setOcupado(false);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha11 and carrinha0", (carrinha11.compareTo(carrinha0) == 0) == carrinha11.equals(carrinha0));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test013");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        int i4 = carrinha3.getLugares();
        boolean b5 = carrinha2.equals((java.lang.Object) carrinha3);
        Carrinha carrinha6 = carrinha3.clone();
        Carrinha carrinha7 = new Carrinha();
        carrinha7.setMatricula("");
        Carrinha carrinha10 = carrinha7.clone();
        carrinha7.setPrecoBase((double) 0L);
        Carrinha carrinha13 = new Carrinha();
        int i14 = carrinha13.getLugares();
        int i15 = carrinha7.compareTo((Veiculo) carrinha13);
        java.lang.String str16 = carrinha13.toString();
        int i17 = carrinha13.getFiabilidade();
        carrinha13.setPrecoBase(10.0d);
        Coordenada coordenada20 = carrinha13.getCoordenadas();
        carrinha3.setCoordenadas(coordenada20);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha0 and carrinha13", (carrinha0.compareTo(carrinha13) == 0) == carrinha0.equals(carrinha13));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test014");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carrinha0.getCoordenadas();
        carrinha0.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carrinha0.setFiabilidade(0);
        Carrinha carrinha10 = new Carrinha();
        carrinha10.setMatricula("");
        Carrinha carrinha13 = carrinha10.clone();
        carrinha10.setPrecoBase((double) 0L);
        Carrinha carrinha16 = new Carrinha(carrinha10);
        carrinha16.setPrecoBase((double) (-1.0f));
        carrinha16.setVelocidadeMedia((int) (short) 0);
        boolean b21 = carrinha0.equals((java.lang.Object) (short) 0);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha10 and carrinha16", (carrinha10.compareTo(carrinha16) == 0) == carrinha10.equals(carrinha16));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test015");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        java.lang.String str2 = carrinha0.toString();
        carrinha0.setFiabilidade(0);
        Carrinha carrinha9 = new Carrinha();
        carrinha9.setMatricula("");
        Carrinha carrinha12 = carrinha9.clone();
        Coordenada coordenada13 = carrinha12.getCoordenadas();
        Carrinha carrinha15 = new Carrinha((int) (byte) -1, (double) 0, (int) (short) 1, "", coordenada13, false);
        carrinha0.setCoordenadas(coordenada13);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha12 and carrinha15", (carrinha12.compareTo(carrinha15) == 0) == carrinha12.equals(carrinha15));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test016");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        java.lang.String str9 = carrinha6.toString();
        int i10 = carrinha6.getFiabilidade();
        carrinha6.setPrecoBase(10.0d);
        int i13 = carrinha6.getVelocidadeMedia();
        Carrinha carrinha14 = new Carrinha(carrinha6);
        Carrinha carrinha15 = new Carrinha();
        Carrinha carrinha16 = new Carrinha(carrinha15);
        Carrinha carrinha17 = new Carrinha(carrinha16);
        Carrinha carrinha18 = new Carrinha();
        int i19 = carrinha18.getLugares();
        boolean b20 = carrinha17.equals((java.lang.Object) carrinha18);
        Carrinha carrinha21 = carrinha18.clone();
        carrinha21.setVelocidadeMedia((int) (short) 0);
        int i24 = carrinha14.compareTo((Veiculo) carrinha21);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha6 and carrinha15", (carrinha6.compareTo(carrinha15) == 0) == carrinha6.equals(carrinha15));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test017");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha3.setOcupado(true);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        carrinha6.setVelocidadeMedia(10);
        int i10 = carrinha3.compareTo((Veiculo) carrinha6);
        carrinha6.setPrecoBase((double) 0L);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha3 and carrinha0", (carrinha3.compareTo(carrinha0) == 0) == carrinha3.equals(carrinha0));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test018");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        Carrinha carrinha8 = new Carrinha();
        carrinha8.setMatricula("");
        Carrinha carrinha11 = carrinha8.clone();
        carrinha8.setPrecoBase((double) 0L);
        Carrinha carrinha14 = new Carrinha();
        int i15 = carrinha14.getLugares();
        int i16 = carrinha8.compareTo((Veiculo) carrinha14);
        java.lang.String str17 = carrinha14.toString();
        Coordenada coordenada18 = carrinha14.getCoordenadas();
        Carrinha carrinha20 = new Carrinha((int) ' ', (double) 100.0f, (int) (byte) -1, "", coordenada18, false);
        boolean b21 = carrinha3.equals((java.lang.Object) false);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha11 and carrinha20", (carrinha11.compareTo(carrinha20) == 0) == carrinha11.equals(carrinha20));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test019");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carrinha0.getCoordenadas();
        java.lang.String str6 = carrinha0.getMatricula();
        Carrinha carrinha11 = new Carrinha();
        carrinha11.setMatricula("");
        Carrinha carrinha14 = carrinha11.clone();
        carrinha11.setPrecoBase((double) 0L);
        Carrinha carrinha17 = new Carrinha();
        int i18 = carrinha17.getLugares();
        int i19 = carrinha11.compareTo((Veiculo) carrinha17);
        java.lang.String str20 = carrinha17.toString();
        Coordenada coordenada21 = carrinha17.getCoordenadas();
        Carrinha carrinha23 = new Carrinha((int) (byte) -1, 0.0d, (int) 'a', "", coordenada21, true);
        int i24 = carrinha0.compareTo((Veiculo) carrinha23);
        double d25 = carrinha0.getPrecoBase();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha14 and carrinha23", (carrinha14.compareTo(carrinha23) == 0) == carrinha14.equals(carrinha23));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test020");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        Carrinha carrinha9 = new Carrinha(carrinha6);
        Carrinha carrinha10 = new Carrinha();
        Carrinha carrinha11 = new Carrinha(carrinha10);
        Carrinha carrinha12 = new Carrinha(carrinha11);
        Carrinha carrinha13 = new Carrinha();
        Carrinha carrinha14 = new Carrinha(carrinha13);
        int i15 = carrinha11.compareTo((Veiculo) carrinha13);
        int i16 = carrinha13.getVelocidadeMedia();
        int i17 = carrinha9.compareTo((Veiculo) carrinha13);
        Carrinha carrinha18 = new Carrinha();
        carrinha18.setMatricula("");
        Carrinha carrinha21 = carrinha18.clone();
        carrinha21.setOcupado(true);
        Carrinha carrinha24 = new Carrinha();
        int i25 = carrinha24.getLugares();
        carrinha24.setVelocidadeMedia(10);
        int i28 = carrinha21.compareTo((Veiculo) carrinha24);
        Coordenada coordenada29 = carrinha21.getCoordenadas();
        carrinha9.setCoordenadas(coordenada29);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha6 and carrinha24", (carrinha6.compareTo(carrinha24) == 0) == carrinha6.equals(carrinha24));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test021");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha3.setOcupado(true);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        carrinha6.setVelocidadeMedia(10);
        int i10 = carrinha3.compareTo((Veiculo) carrinha6);
        Carrinha carrinha11 = carrinha6.clone();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha0 and carrinha3", (carrinha0.compareTo(carrinha3) == 0) == carrinha0.equals(carrinha3));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test022");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        java.lang.String str9 = carrinha6.toString();
        Coordenada coordenada10 = carrinha6.getCoordenadas();
        Carrinha carrinha11 = new Carrinha();
        int i12 = carrinha11.getLugares();
        Coordenada coordenada13 = carrinha11.getCoordenadas();
        carrinha6.setCoordenadas(coordenada13);
        Carrinha carrinha15 = new Carrinha(carrinha6);
        Carrinha carrinha16 = new Carrinha();
        int i17 = carrinha16.getLugares();
        carrinha16.setVelocidadeMedia(10);
        Carrinha carrinha20 = new Carrinha(carrinha16);
        int i21 = carrinha16.getVelocidadeMedia();
        java.lang.String str22 = carrinha16.getMatricula();
        carrinha16.setVelocidadeMedia((int) (byte) 1);
        Carrinha carrinha25 = new Carrinha(carrinha16);
        int i26 = carrinha6.compareTo((Veiculo) carrinha16);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha11 and carrinha20", (carrinha11.compareTo(carrinha20) == 0) == carrinha11.equals(carrinha20));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test023");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        carrinha0.setMatricula("n/a");
        Carrinha carrinha6 = new Carrinha();
        carrinha6.setMatricula("");
        Carrinha carrinha9 = carrinha6.clone();
        carrinha6.setPrecoBase((double) 0L);
        Carrinha carrinha12 = new Carrinha();
        int i13 = carrinha12.getLugares();
        int i14 = carrinha6.compareTo((Veiculo) carrinha12);
        java.lang.String str15 = carrinha12.toString();
        Coordenada coordenada16 = carrinha12.getCoordenadas();
        Carrinha carrinha17 = new Carrinha();
        int i18 = carrinha17.getLugares();
        Coordenada coordenada19 = carrinha17.getCoordenadas();
        carrinha12.setCoordenadas(coordenada19);
        carrinha0.setCoordenadas(coordenada19);
        Carrinha carrinha22 = carrinha0.clone();
        Coordenada coordenada23 = carrinha22.getCoordenadas();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha17 and carrinha0", (carrinha17.compareTo(carrinha0) == 0) == carrinha17.equals(carrinha0));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test024");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        Carrinha carrinha8 = new Carrinha();
        carrinha8.setMatricula("");
        Carrinha carrinha11 = carrinha8.clone();
        carrinha8.setPrecoBase((double) 0L);
        Carrinha carrinha14 = new Carrinha();
        int i15 = carrinha14.getLugares();
        int i16 = carrinha8.compareTo((Veiculo) carrinha14);
        java.lang.String str17 = carrinha14.toString();
        Coordenada coordenada18 = carrinha14.getCoordenadas();
        Carrinha carrinha20 = new Carrinha((int) (byte) 100, (double) '#', (int) (short) 0, "", coordenada18, false);
        carrinha0.setCoordenadas(coordenada18);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha3 and carrinha20", (carrinha3.compareTo(carrinha20) == 0) == carrinha3.equals(carrinha20));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test025");
        Carrinha carrinha8 = new Carrinha();
        carrinha8.setMatricula("");
        Carrinha carrinha11 = carrinha8.clone();
        carrinha8.setPrecoBase((double) 0L);
        Carrinha carrinha14 = new Carrinha();
        int i15 = carrinha14.getLugares();
        int i16 = carrinha8.compareTo((Veiculo) carrinha14);
        java.lang.String str17 = carrinha14.toString();
        Coordenada coordenada18 = carrinha14.getCoordenadas();
        Carrinha carrinha20 = new Carrinha((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, false);
        Carrinha carrinha22 = new Carrinha((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, true);
        Carrinha carrinha23 = new Carrinha();
        carrinha23.setVelocidadeMedia((int) ' ');
        java.lang.String str26 = carrinha23.toString();
        boolean b27 = carrinha22.equals((java.lang.Object) carrinha23);
        carrinha22.setFiabilidade(1);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha14 and carrinha23", (carrinha14.compareTo(carrinha23) == 0) == carrinha14.equals(carrinha23));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test026");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        Carrinha carrinha4 = carrinha0.clone();
        int i5 = carrinha4.getLugares();
        Carrinha carrinha6 = new Carrinha();
        Carrinha carrinha7 = new Carrinha(carrinha6);
        Carrinha carrinha8 = new Carrinha(carrinha7);
        Carrinha carrinha9 = new Carrinha();
        Carrinha carrinha10 = new Carrinha(carrinha9);
        int i11 = carrinha7.compareTo((Veiculo) carrinha9);
        Carrinha carrinha12 = new Carrinha();
        carrinha12.setMatricula("");
        boolean b16 = carrinha12.equals((java.lang.Object) (-1.0d));
        boolean b17 = carrinha7.equals((java.lang.Object) (-1.0d));
        int i18 = carrinha4.compareTo((Veiculo) carrinha7);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha10 and carrinha0", (carrinha10.compareTo(carrinha0) == 0) == carrinha10.equals(carrinha0));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test027");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        int i2 = carrinha1.getFiabilidade();
        Carrinha carrinha3 = new Carrinha();
        carrinha3.setMatricula("");
        boolean b7 = carrinha3.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada8 = carrinha3.getCoordenadas();
        int i9 = carrinha3.getVelocidadeMedia();
        Carrinha carrinha10 = new Carrinha();
        carrinha10.setMatricula("");
        Carrinha carrinha13 = carrinha10.clone();
        carrinha13.setOcupado(true);
        boolean b16 = carrinha3.equals((java.lang.Object) carrinha13);
        int i17 = carrinha1.compareTo((Veiculo) carrinha3);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha13 and carrinha10", (carrinha13.compareTo(carrinha10) == 0) == carrinha13.equals(carrinha10));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test028");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        java.lang.String str2 = carrinha0.getMatricula();
        Carrinha carrinha3 = new Carrinha(carrinha0);
        carrinha0.setOcupado(true);
        Carrinha carrinha6 = new Carrinha();
        carrinha6.setMatricula("");
        Carrinha carrinha9 = carrinha6.clone();
        carrinha6.setPrecoBase((double) 0L);
        Carrinha carrinha12 = new Carrinha();
        int i13 = carrinha12.getLugares();
        int i14 = carrinha6.compareTo((Veiculo) carrinha12);
        java.lang.String str15 = carrinha12.toString();
        int i16 = carrinha12.getFiabilidade();
        carrinha12.setPrecoBase(10.0d);
        Carrinha carrinha19 = carrinha12.clone();
        boolean b20 = carrinha0.equals((java.lang.Object) carrinha19);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha3 and carrinha12", (carrinha3.compareTo(carrinha12) == 0) == carrinha3.equals(carrinha12));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test029");
        Carrinha carrinha4 = new Carrinha();
        Carrinha carrinha5 = new Carrinha(carrinha4);
        Carrinha carrinha6 = new Carrinha(carrinha5);
        Carrinha carrinha7 = new Carrinha();
        int i8 = carrinha7.getLugares();
        boolean b9 = carrinha6.equals((java.lang.Object) carrinha7);
        carrinha7.setOcupado(true);
        Coordenada coordenada12 = carrinha7.getCoordenadas();
        Carrinha carrinha14 = new Carrinha((int) (short) 100, (double) (-1L), (int) (short) 10, "n/a", coordenada12, false);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha4 and carrinha7", (carrinha4.compareTo(carrinha7) == 0) == carrinha4.equals(carrinha7));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test030");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        Carrinha carrinha4 = new Carrinha(carrinha0);
        int i5 = carrinha0.getVelocidadeMedia();
        carrinha0.setMatricula("");
        Carrinha carrinha12 = new Carrinha();
        carrinha12.setMatricula("");
        boolean b16 = carrinha12.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada17 = carrinha12.getCoordenadas();
        carrinha12.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carrinha12.setFiabilidade(0);
        Carrinha carrinha22 = new Carrinha();
        carrinha22.setMatricula("");
        Carrinha carrinha25 = carrinha22.clone();
        carrinha22.setPrecoBase((double) 0L);
        Carrinha carrinha28 = new Carrinha(carrinha22);
        int i29 = carrinha12.compareTo((Veiculo) carrinha22);
        Carrinha carrinha30 = new Carrinha(carrinha22);
        Coordenada coordenada31 = carrinha30.getCoordenadas();
        Carrinha carrinha33 = new Carrinha((int) (byte) 0, (double) 0L, (int) (byte) 0, "n/a", coordenada31, true);
        carrinha0.setCoordenadas(coordenada31);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha4 and carrinha33", (carrinha4.compareTo(carrinha33) == 0) == carrinha4.equals(carrinha33));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test031");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        carrinha0.setMatricula("n/a");
        Carrinha carrinha6 = new Carrinha();
        carrinha6.setMatricula("");
        Carrinha carrinha9 = carrinha6.clone();
        carrinha6.setPrecoBase((double) 0L);
        Carrinha carrinha12 = new Carrinha();
        int i13 = carrinha12.getLugares();
        int i14 = carrinha6.compareTo((Veiculo) carrinha12);
        java.lang.String str15 = carrinha12.toString();
        Coordenada coordenada16 = carrinha12.getCoordenadas();
        Carrinha carrinha17 = new Carrinha();
        int i18 = carrinha17.getLugares();
        Coordenada coordenada19 = carrinha17.getCoordenadas();
        carrinha12.setCoordenadas(coordenada19);
        carrinha0.setCoordenadas(coordenada19);
        Carrinha carrinha22 = carrinha0.clone();
        carrinha0.setVelocidadeMedia(9);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha12 and carrinha22", (carrinha12.compareTo(carrinha22) == 0) == carrinha12.equals(carrinha22));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test032");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        java.lang.String str9 = carrinha6.toString();
        int i10 = carrinha6.getFiabilidade();
        carrinha6.setPrecoBase(10.0d);
        int i13 = carrinha6.getVelocidadeMedia();
        Carrinha carrinha14 = new Carrinha(carrinha6);
        carrinha6.setVelocidadeMedia(1);
        Carrinha carrinha17 = new Carrinha();
        int i18 = carrinha17.getLugares();
        carrinha17.setVelocidadeMedia(10);
        carrinha17.setMatricula("n/a");
        carrinha17.setPrecoBase((double) (-1.0f));
        boolean b25 = carrinha6.equals((java.lang.Object) carrinha17);
        double d26 = carrinha6.getPrecoBase();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha14 and carrinha17", (carrinha14.compareTo(carrinha17) == 0) == carrinha14.equals(carrinha17));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test033");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carrinha0.getCoordenadas();
        java.lang.String str6 = carrinha0.getMatricula();
        Carrinha carrinha11 = new Carrinha();
        carrinha11.setMatricula("");
        Carrinha carrinha14 = carrinha11.clone();
        carrinha11.setPrecoBase((double) 0L);
        Carrinha carrinha17 = new Carrinha();
        int i18 = carrinha17.getLugares();
        int i19 = carrinha11.compareTo((Veiculo) carrinha17);
        java.lang.String str20 = carrinha17.toString();
        Coordenada coordenada21 = carrinha17.getCoordenadas();
        Carrinha carrinha23 = new Carrinha((int) (byte) -1, 0.0d, (int) 'a', "", coordenada21, true);
        int i24 = carrinha0.compareTo((Veiculo) carrinha23);
        java.lang.String str25 = carrinha0.getMatricula();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha14 and carrinha23", (carrinha14.compareTo(carrinha23) == 0) == carrinha14.equals(carrinha23));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test034");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carrinha0.getCoordenadas();
        int i6 = carrinha0.getVelocidadeMedia();
        Carrinha carrinha7 = new Carrinha();
        carrinha7.setMatricula("");
        Carrinha carrinha10 = carrinha7.clone();
        carrinha10.setOcupado(true);
        boolean b13 = carrinha0.equals((java.lang.Object) carrinha10);
        int i14 = carrinha0.getVelocidadeMedia();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha7 and carrinha10", (carrinha7.compareTo(carrinha10) == 0) == carrinha7.equals(carrinha10));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test035");
        Carrinha carrinha8 = new Carrinha();
        carrinha8.setMatricula("");
        Carrinha carrinha11 = carrinha8.clone();
        carrinha8.setPrecoBase((double) 0L);
        Carrinha carrinha14 = new Carrinha();
        int i15 = carrinha14.getLugares();
        int i16 = carrinha8.compareTo((Veiculo) carrinha14);
        java.lang.String str17 = carrinha14.toString();
        Coordenada coordenada18 = carrinha14.getCoordenadas();
        Carrinha carrinha20 = new Carrinha((int) (byte) 100, (double) '#', (int) (short) 0, "", coordenada18, false);
        Carrinha carrinha22 = new Carrinha(0, (-1.0d), 9, "hi!", coordenada18, false);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha8 and carrinha20", (carrinha8.compareTo(carrinha20) == 0) == carrinha8.equals(carrinha20));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test036");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        Carrinha carrinha4 = new Carrinha(carrinha3);
        int i5 = carrinha1.compareTo((Veiculo) carrinha3);
        Carrinha carrinha10 = new Carrinha();
        carrinha10.setMatricula("");
        Carrinha carrinha13 = carrinha10.clone();
        carrinha10.setPrecoBase((double) 0L);
        Carrinha carrinha16 = new Carrinha();
        int i17 = carrinha16.getLugares();
        int i18 = carrinha10.compareTo((Veiculo) carrinha16);
        java.lang.String str19 = carrinha16.toString();
        Coordenada coordenada20 = carrinha16.getCoordenadas();
        Carrinha carrinha22 = new Carrinha((int) ' ', (double) 100.0f, (int) (byte) -1, "", coordenada20, false);
        int i23 = carrinha1.compareTo((Veiculo) carrinha22);
        java.lang.String str24 = carrinha1.getMatricula();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha13 and carrinha22", (carrinha13.compareTo(carrinha22) == 0) == carrinha13.equals(carrinha22));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test037");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carrinha0.getCoordenadas();
        java.lang.String str6 = carrinha0.getMatricula();
        Carrinha carrinha11 = new Carrinha();
        carrinha11.setMatricula("");
        Carrinha carrinha14 = carrinha11.clone();
        carrinha11.setPrecoBase((double) 0L);
        Carrinha carrinha17 = new Carrinha();
        int i18 = carrinha17.getLugares();
        int i19 = carrinha11.compareTo((Veiculo) carrinha17);
        java.lang.String str20 = carrinha17.toString();
        Coordenada coordenada21 = carrinha17.getCoordenadas();
        Carrinha carrinha23 = new Carrinha((int) (byte) -1, 0.0d, (int) 'a', "", coordenada21, true);
        int i24 = carrinha0.compareTo((Veiculo) carrinha23);
        carrinha0.setPrecoBase(0.0d);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha14 and carrinha23", (carrinha14.compareTo(carrinha23) == 0) == carrinha14.equals(carrinha23));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test038");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha3.setOcupado(true);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        carrinha6.setVelocidadeMedia(10);
        int i10 = carrinha3.compareTo((Veiculo) carrinha6);
        Carrinha carrinha11 = carrinha3.clone();
        boolean b12 = carrinha3.getOcupado();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha0 and carrinha11", (carrinha0.compareTo(carrinha11) == 0) == carrinha0.equals(carrinha11));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test039");
        Carrinha carrinha4 = new Carrinha();
        int i5 = carrinha4.getLugares();
        carrinha4.setVelocidadeMedia(10);
        carrinha4.setMatricula("n/a");
        Carrinha carrinha10 = new Carrinha();
        carrinha10.setMatricula("");
        Carrinha carrinha13 = carrinha10.clone();
        carrinha10.setPrecoBase((double) 0L);
        Carrinha carrinha16 = new Carrinha();
        int i17 = carrinha16.getLugares();
        int i18 = carrinha10.compareTo((Veiculo) carrinha16);
        java.lang.String str19 = carrinha16.toString();
        Coordenada coordenada20 = carrinha16.getCoordenadas();
        Carrinha carrinha21 = new Carrinha();
        int i22 = carrinha21.getLugares();
        Coordenada coordenada23 = carrinha21.getCoordenadas();
        carrinha16.setCoordenadas(coordenada23);
        carrinha4.setCoordenadas(coordenada23);
        Carrinha carrinha26 = new Carrinha();
        carrinha26.setMatricula("");
        boolean b30 = carrinha26.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada31 = carrinha26.getCoordenadas();
        carrinha4.setCoordenadas(coordenada31);
        Carrinha carrinha34 = new Carrinha(9, 100.0d, (int) (short) 100, "", coordenada31, false);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha4 and carrinha21", (carrinha4.compareTo(carrinha21) == 0) == carrinha4.equals(carrinha21));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test040");
        Carrinha carrinha4 = new Carrinha();
        carrinha4.setMatricula("");
        Carrinha carrinha7 = carrinha4.clone();
        carrinha4.setPrecoBase((double) 0L);
        Carrinha carrinha10 = new Carrinha();
        int i11 = carrinha10.getLugares();
        int i12 = carrinha4.compareTo((Veiculo) carrinha10);
        java.lang.String str13 = carrinha10.toString();
        Coordenada coordenada14 = carrinha10.getCoordenadas();
        Carrinha carrinha16 = new Carrinha((int) 'a', (double) 3, 0, "", coordenada14, true);
        Carrinha carrinha17 = new Carrinha();
        carrinha17.setMatricula("");
        boolean b21 = carrinha17.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha22 = new Carrinha(carrinha17);
        double d23 = carrinha17.getPrecoBase();
        boolean b24 = carrinha17.getOcupado();
        int i25 = carrinha17.getVelocidadeMedia();
        java.lang.String str26 = carrinha17.getMatricula();
        carrinha17.setMatricula("hi!");
        int i29 = carrinha16.compareTo((Veiculo) carrinha17);
        carrinha17.setMatricula("n/a");
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha7 and carrinha16", (carrinha7.compareTo(carrinha16) == 0) == carrinha7.equals(carrinha16));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test041");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carrinha0.getCoordenadas();
        java.lang.String str6 = carrinha0.getMatricula();
        Carrinha carrinha11 = new Carrinha();
        carrinha11.setMatricula("");
        Carrinha carrinha14 = carrinha11.clone();
        carrinha11.setPrecoBase((double) 0L);
        Carrinha carrinha17 = new Carrinha();
        int i18 = carrinha17.getLugares();
        int i19 = carrinha11.compareTo((Veiculo) carrinha17);
        java.lang.String str20 = carrinha17.toString();
        Coordenada coordenada21 = carrinha17.getCoordenadas();
        Carrinha carrinha23 = new Carrinha((int) (byte) -1, 0.0d, (int) 'a', "", coordenada21, true);
        int i24 = carrinha0.compareTo((Veiculo) carrinha23);
        java.lang.String str25 = carrinha0.toString();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha11 and carrinha23", (carrinha11.compareTo(carrinha23) == 0) == carrinha11.equals(carrinha23));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test042");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha3.setOcupado(true);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        carrinha6.setVelocidadeMedia(10);
        int i10 = carrinha3.compareTo((Veiculo) carrinha6);
        Carrinha carrinha11 = carrinha3.clone();
        Carrinha carrinha12 = new Carrinha();
        carrinha12.setMatricula("");
        Carrinha carrinha15 = carrinha12.clone();
        carrinha12.setPrecoBase((double) 0L);
        Carrinha carrinha18 = new Carrinha();
        int i19 = carrinha18.getLugares();
        int i20 = carrinha12.compareTo((Veiculo) carrinha18);
        Carrinha carrinha21 = new Carrinha(carrinha18);
        carrinha18.setOcupado(false);
        boolean b24 = carrinha3.equals((java.lang.Object) carrinha18);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha6 and carrinha21", (carrinha6.compareTo(carrinha21) == 0) == carrinha6.equals(carrinha21));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test043");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        java.lang.String str9 = carrinha6.toString();
        Coordenada coordenada10 = carrinha6.getCoordenadas();
        carrinha6.setFiabilidade((int) (byte) 1);
        Carrinha carrinha13 = new Carrinha();
        int i14 = carrinha13.getLugares();
        carrinha13.setVelocidadeMedia(10);
        Carrinha carrinha17 = carrinha13.clone();
        boolean b18 = carrinha6.equals((java.lang.Object) carrinha13);
        Carrinha carrinha19 = new Carrinha();
        Carrinha carrinha20 = new Carrinha(carrinha19);
        Carrinha carrinha21 = new Carrinha(carrinha20);
        Carrinha carrinha22 = new Carrinha();
        Carrinha carrinha23 = new Carrinha(carrinha22);
        int i24 = carrinha20.compareTo((Veiculo) carrinha22);
        Carrinha carrinha25 = new Carrinha();
        carrinha25.setMatricula("");
        boolean b29 = carrinha25.equals((java.lang.Object) (-1.0d));
        boolean b30 = carrinha20.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha31 = new Carrinha(carrinha20);
        Carrinha carrinha32 = new Carrinha(carrinha20);
        boolean b33 = carrinha6.equals((java.lang.Object) carrinha20);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha17 and carrinha21", (carrinha17.compareTo(carrinha21) == 0) == carrinha17.equals(carrinha21));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test044");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        Carrinha carrinha4 = new Carrinha(carrinha0);
        int i5 = carrinha0.getVelocidadeMedia();
        carrinha0.setMatricula("");
        carrinha0.setPrecoBase((double) (byte) 1);
        Carrinha carrinha10 = new Carrinha();
        int i11 = carrinha10.getLugares();
        Coordenada coordenada12 = carrinha10.getCoordenadas();
        boolean b13 = carrinha0.equals((java.lang.Object) carrinha10);
        carrinha0.setOcupado(false);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha4 and carrinha10", (carrinha4.compareTo(carrinha10) == 0) == carrinha4.equals(carrinha10));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test045");
        Carrinha carrinha8 = new Carrinha();
        carrinha8.setMatricula("");
        Carrinha carrinha11 = carrinha8.clone();
        carrinha8.setPrecoBase((double) 0L);
        Carrinha carrinha14 = new Carrinha();
        int i15 = carrinha14.getLugares();
        int i16 = carrinha8.compareTo((Veiculo) carrinha14);
        java.lang.String str17 = carrinha14.toString();
        Coordenada coordenada18 = carrinha14.getCoordenadas();
        Carrinha carrinha20 = new Carrinha((int) 'a', (double) 3, 0, "", coordenada18, true);
        Carrinha carrinha22 = new Carrinha((int) (byte) -1, (double) 32, 32, "", coordenada18, true);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha11 and carrinha20", (carrinha11.compareTo(carrinha20) == 0) == carrinha11.equals(carrinha20));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test046");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        java.lang.String str2 = carrinha0.toString();
        carrinha0.setFiabilidade(0);
        Carrinha carrinha5 = carrinha0.clone();
        Carrinha carrinha6 = new Carrinha();
        Carrinha carrinha7 = new Carrinha(carrinha6);
        Carrinha carrinha8 = new Carrinha(carrinha7);
        Carrinha carrinha9 = new Carrinha();
        Carrinha carrinha10 = new Carrinha(carrinha9);
        int i11 = carrinha7.compareTo((Veiculo) carrinha9);
        Carrinha carrinha12 = new Carrinha();
        carrinha12.setMatricula("");
        boolean b16 = carrinha12.equals((java.lang.Object) (-1.0d));
        boolean b17 = carrinha7.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha18 = new Carrinha();
        carrinha18.setMatricula("");
        Carrinha carrinha21 = carrinha18.clone();
        carrinha18.setPrecoBase((double) 0L);
        Carrinha carrinha24 = new Carrinha();
        int i25 = carrinha24.getLugares();
        int i26 = carrinha18.compareTo((Veiculo) carrinha24);
        java.lang.String str27 = carrinha24.toString();
        Coordenada coordenada28 = carrinha24.getCoordenadas();
        carrinha7.setCoordenadas(coordenada28);
        carrinha0.setCoordenadas(coordenada28);
        carrinha0.setPrecoBase(100.0d);
        Carrinha carrinha33 = new Carrinha(carrinha0);
        java.lang.String str34 = carrinha0.toString();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha7 and carrinha33", (carrinha7.compareTo(carrinha33) == 0) == carrinha7.equals(carrinha33));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test047");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        Carrinha carrinha4 = new Carrinha(carrinha0);
        int i5 = carrinha0.getVelocidadeMedia();
        java.lang.String str6 = carrinha0.getMatricula();
        Carrinha carrinha7 = new Carrinha();
        carrinha7.setMatricula("");
        Carrinha carrinha10 = carrinha7.clone();
        carrinha7.setPrecoBase((double) 0L);
        Carrinha carrinha13 = new Carrinha();
        int i14 = carrinha13.getLugares();
        int i15 = carrinha7.compareTo((Veiculo) carrinha13);
        int i16 = carrinha13.getFiabilidade();
        Carrinha carrinha17 = carrinha13.clone();
        Coordenada coordenada18 = carrinha17.getCoordenadas();
        carrinha0.setCoordenadas(coordenada18);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha17 and carrinha4", (carrinha17.compareTo(carrinha4) == 0) == carrinha17.equals(carrinha4));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test048");
        Carrinha carrinha8 = new Carrinha();
        carrinha8.setMatricula("");
        Carrinha carrinha11 = carrinha8.clone();
        carrinha8.setPrecoBase((double) 0L);
        Carrinha carrinha14 = new Carrinha();
        int i15 = carrinha14.getLugares();
        int i16 = carrinha8.compareTo((Veiculo) carrinha14);
        java.lang.String str17 = carrinha14.toString();
        Coordenada coordenada18 = carrinha14.getCoordenadas();
        Carrinha carrinha20 = new Carrinha((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, false);
        Carrinha carrinha22 = new Carrinha((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, true);
        Carrinha carrinha23 = new Carrinha();
        carrinha23.setVelocidadeMedia((int) ' ');
        java.lang.String str26 = carrinha23.toString();
        boolean b27 = carrinha22.equals((java.lang.Object) carrinha23);
        Carrinha carrinha28 = new Carrinha();
        int i29 = carrinha28.getLugares();
        carrinha28.setVelocidadeMedia(10);
        Carrinha carrinha32 = carrinha28.clone();
        Carrinha carrinha33 = new Carrinha(carrinha28);
        int i34 = carrinha22.compareTo((Veiculo) carrinha28);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha23 and carrinha14", (carrinha23.compareTo(carrinha14) == 0) == carrinha23.equals(carrinha14));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test049");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha(carrinha0);
        carrinha6.setPrecoBase((double) (-1.0f));
        carrinha6.setVelocidadeMedia((int) (short) 0);
        carrinha6.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Carrinha carrinha13 = new Carrinha(carrinha6);
        carrinha6.setPrecoBase(1.0d);
        Carrinha carrinha16 = new Carrinha();
        carrinha16.setMatricula("");
        boolean b20 = carrinha16.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha21 = new Carrinha(carrinha16);
        double d22 = carrinha16.getPrecoBase();
        boolean b23 = carrinha16.getOcupado();
        int i24 = carrinha16.getVelocidadeMedia();
        Carrinha carrinha25 = carrinha16.clone();
        carrinha25.setFiabilidade((int) (byte) 10);
        carrinha25.setFiabilidade((int) (short) -1);
        int i30 = carrinha6.compareTo((Veiculo) carrinha25);
        carrinha6.setFiabilidade((int) (byte) -1);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha21 and carrinha25", (carrinha21.compareTo(carrinha25) == 0) == carrinha21.equals(carrinha25));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test050");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        java.lang.String str2 = carrinha0.toString();
        carrinha0.setFiabilidade(0);
        Carrinha carrinha5 = carrinha0.clone();
        Carrinha carrinha6 = new Carrinha();
        Carrinha carrinha7 = new Carrinha(carrinha6);
        Carrinha carrinha8 = new Carrinha(carrinha7);
        Carrinha carrinha9 = new Carrinha();
        Carrinha carrinha10 = new Carrinha(carrinha9);
        int i11 = carrinha7.compareTo((Veiculo) carrinha9);
        Carrinha carrinha12 = new Carrinha();
        carrinha12.setMatricula("");
        boolean b16 = carrinha12.equals((java.lang.Object) (-1.0d));
        boolean b17 = carrinha7.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha18 = new Carrinha();
        carrinha18.setMatricula("");
        Carrinha carrinha21 = carrinha18.clone();
        carrinha18.setPrecoBase((double) 0L);
        Carrinha carrinha24 = new Carrinha();
        int i25 = carrinha24.getLugares();
        int i26 = carrinha18.compareTo((Veiculo) carrinha24);
        java.lang.String str27 = carrinha24.toString();
        Coordenada coordenada28 = carrinha24.getCoordenadas();
        carrinha7.setCoordenadas(coordenada28);
        carrinha0.setCoordenadas(coordenada28);
        carrinha0.setPrecoBase(100.0d);
        Carrinha carrinha33 = new Carrinha(carrinha0);
        int i34 = carrinha33.getVelocidadeMedia();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha5 and carrinha0", (carrinha5.compareTo(carrinha0) == 0) == carrinha5.equals(carrinha0));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test051");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        Carrinha carrinha4 = new Carrinha(carrinha0);
        int i5 = carrinha0.getVelocidadeMedia();
        java.lang.String str6 = carrinha0.getMatricula();
        carrinha0.setFiabilidade((int) ' ');
        Carrinha carrinha9 = new Carrinha();
        Carrinha carrinha10 = new Carrinha(carrinha9);
        java.lang.String str11 = carrinha9.toString();
        carrinha9.setFiabilidade(0);
        int i14 = carrinha9.getFiabilidade();
        Carrinha carrinha15 = new Carrinha();
        Carrinha carrinha16 = new Carrinha(carrinha15);
        java.lang.String str17 = carrinha15.toString();
        carrinha15.setFiabilidade(0);
        Carrinha carrinha20 = carrinha15.clone();
        Carrinha carrinha21 = new Carrinha(carrinha15);
        Coordenada coordenada22 = carrinha15.getCoordenadas();
        carrinha9.setCoordenadas(coordenada22);
        carrinha0.setCoordenadas(coordenada22);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha15 and carrinha4", (carrinha15.compareTo(carrinha4) == 0) == carrinha15.equals(carrinha4));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test052");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carrinha0.getCoordenadas();
        boolean b6 = carrinha0.getOcupado();
        java.lang.String str7 = carrinha0.getMatricula();
        Carrinha carrinha12 = new Carrinha();
        carrinha12.setMatricula("");
        Carrinha carrinha15 = carrinha12.clone();
        carrinha12.setPrecoBase((double) 0L);
        Carrinha carrinha18 = new Carrinha();
        int i19 = carrinha18.getLugares();
        int i20 = carrinha12.compareTo((Veiculo) carrinha18);
        java.lang.String str21 = carrinha18.toString();
        Coordenada coordenada22 = carrinha18.getCoordenadas();
        Carrinha carrinha24 = new Carrinha((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada22, false);
        carrinha0.setCoordenadas(coordenada22);
        carrinha0.setOcupado(true);
        Carrinha carrinha28 = new Carrinha(carrinha0);
        int i29 = carrinha28.getFiabilidade();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha15 and carrinha0", (carrinha15.compareTo(carrinha0) == 0) == carrinha15.equals(carrinha0));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test053");
        Carrinha carrinha4 = new Carrinha();
        carrinha4.setMatricula("");
        Carrinha carrinha7 = carrinha4.clone();
        carrinha4.setPrecoBase((double) 0L);
        Carrinha carrinha10 = new Carrinha();
        int i11 = carrinha10.getLugares();
        int i12 = carrinha4.compareTo((Veiculo) carrinha10);
        java.lang.String str13 = carrinha10.toString();
        Coordenada coordenada14 = carrinha10.getCoordenadas();
        Carrinha carrinha16 = new Carrinha((int) 'a', (double) 3, 0, "", coordenada14, true);
        Carrinha carrinha17 = new Carrinha();
        carrinha17.setMatricula("");
        boolean b21 = carrinha17.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha22 = new Carrinha(carrinha17);
        double d23 = carrinha17.getPrecoBase();
        boolean b24 = carrinha17.getOcupado();
        int i25 = carrinha17.getVelocidadeMedia();
        java.lang.String str26 = carrinha17.getMatricula();
        carrinha17.setMatricula("hi!");
        int i29 = carrinha16.compareTo((Veiculo) carrinha17);
        Carrinha carrinha30 = new Carrinha();
        Carrinha carrinha31 = new Carrinha(carrinha30);
        int i32 = carrinha31.getFiabilidade();
        Coordenada coordenada33 = carrinha31.getCoordenadas();
        carrinha17.setCoordenadas(coordenada33);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha7 and carrinha16", (carrinha7.compareTo(carrinha16) == 0) == carrinha7.equals(carrinha16));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test054");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        int i4 = carrinha3.getLugares();
        boolean b5 = carrinha2.equals((java.lang.Object) carrinha3);
        carrinha3.setOcupado(true);
        Carrinha carrinha12 = new Carrinha();
        carrinha12.setMatricula("");
        Carrinha carrinha15 = carrinha12.clone();
        carrinha12.setPrecoBase((double) 0L);
        Carrinha carrinha18 = new Carrinha();
        int i19 = carrinha18.getLugares();
        int i20 = carrinha12.compareTo((Veiculo) carrinha18);
        java.lang.String str21 = carrinha18.toString();
        Coordenada coordenada22 = carrinha18.getCoordenadas();
        Carrinha carrinha24 = new Carrinha((int) (byte) -1, 0.0d, (int) 'a', "", coordenada22, true);
        carrinha3.setCoordenadas(coordenada22);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha12 and carrinha24", (carrinha12.compareTo(carrinha24) == 0) == carrinha12.equals(carrinha24));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test055");
        Carrinha carrinha4 = new Carrinha();
        int i5 = carrinha4.getLugares();
        carrinha4.setVelocidadeMedia(10);
        carrinha4.setMatricula("n/a");
        Carrinha carrinha10 = new Carrinha();
        carrinha10.setMatricula("");
        Carrinha carrinha13 = carrinha10.clone();
        carrinha10.setPrecoBase((double) 0L);
        Carrinha carrinha16 = new Carrinha();
        int i17 = carrinha16.getLugares();
        int i18 = carrinha10.compareTo((Veiculo) carrinha16);
        java.lang.String str19 = carrinha16.toString();
        Coordenada coordenada20 = carrinha16.getCoordenadas();
        Carrinha carrinha21 = new Carrinha();
        int i22 = carrinha21.getLugares();
        Coordenada coordenada23 = carrinha21.getCoordenadas();
        carrinha16.setCoordenadas(coordenada23);
        carrinha4.setCoordenadas(coordenada23);
        Carrinha carrinha27 = new Carrinha((int) '#', (double) 100L, (int) (short) 1, "hi!", coordenada23, true);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha16 and carrinha4", (carrinha16.compareTo(carrinha4) == 0) == carrinha16.equals(carrinha4));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test056");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        java.lang.String str2 = carrinha0.getMatricula();
        carrinha0.setMatricula("");
        int i5 = carrinha0.getFiabilidade();
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        java.lang.String str8 = carrinha6.getMatricula();
        Carrinha carrinha9 = new Carrinha(carrinha6);
        carrinha6.setOcupado(true);
        double d12 = carrinha6.getPrecoBase();
        boolean b13 = carrinha0.equals((java.lang.Object) d12);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha6 and carrinha9", (carrinha6.compareTo(carrinha9) == 0) == carrinha6.equals(carrinha9));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test057");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        java.lang.String str2 = carrinha0.toString();
        carrinha0.setFiabilidade(0);
        int i5 = carrinha0.getFiabilidade();
        Carrinha carrinha6 = new Carrinha();
        carrinha6.setMatricula("");
        java.lang.String str9 = carrinha6.toString();
        Carrinha carrinha10 = carrinha6.clone();
        carrinha10.setOcupado(true);
        Carrinha carrinha13 = new Carrinha();
        Carrinha carrinha14 = new Carrinha(carrinha13);
        java.lang.String str15 = carrinha13.toString();
        carrinha13.setFiabilidade(0);
        int i18 = carrinha13.getFiabilidade();
        Carrinha carrinha19 = new Carrinha(carrinha13);
        boolean b20 = carrinha10.equals((java.lang.Object) carrinha19);
        carrinha10.setPrecoBase((double) 1);
        int i23 = carrinha0.compareTo((Veiculo) carrinha10);
        Carrinha carrinha24 = new Carrinha();
        Carrinha carrinha25 = new Carrinha(carrinha24);
        java.lang.String str26 = carrinha24.toString();
        carrinha24.setFiabilidade(0);
        int i29 = carrinha24.getFiabilidade();
        Carrinha carrinha30 = new Carrinha();
        carrinha30.setMatricula("");
        java.lang.String str33 = carrinha30.toString();
        Carrinha carrinha34 = carrinha30.clone();
        carrinha34.setOcupado(true);
        Carrinha carrinha37 = new Carrinha();
        Carrinha carrinha38 = new Carrinha(carrinha37);
        java.lang.String str39 = carrinha37.toString();
        carrinha37.setFiabilidade(0);
        int i42 = carrinha37.getFiabilidade();
        Carrinha carrinha43 = new Carrinha(carrinha37);
        boolean b44 = carrinha34.equals((java.lang.Object) carrinha43);
        carrinha34.setPrecoBase((double) 1);
        int i47 = carrinha24.compareTo((Veiculo) carrinha34);
        boolean b48 = carrinha10.equals((java.lang.Object) carrinha24);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha34 and carrinha6", (carrinha34.compareTo(carrinha6) == 0) == carrinha34.equals(carrinha6));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test058");
        Carrinha carrinha4 = new Carrinha();
        carrinha4.setMatricula("");
        Carrinha carrinha7 = carrinha4.clone();
        carrinha4.setPrecoBase((double) 0L);
        Carrinha carrinha10 = new Carrinha();
        int i11 = carrinha10.getLugares();
        int i12 = carrinha4.compareTo((Veiculo) carrinha10);
        java.lang.String str13 = carrinha10.toString();
        Coordenada coordenada14 = carrinha10.getCoordenadas();
        Carrinha carrinha16 = new Carrinha((int) 'a', (double) 3, 0, "", coordenada14, true);
        Carrinha carrinha17 = new Carrinha();
        carrinha17.setMatricula("");
        boolean b21 = carrinha17.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha22 = new Carrinha(carrinha17);
        double d23 = carrinha17.getPrecoBase();
        boolean b24 = carrinha17.getOcupado();
        int i25 = carrinha17.getVelocidadeMedia();
        java.lang.String str26 = carrinha17.getMatricula();
        carrinha17.setMatricula("hi!");
        int i29 = carrinha16.compareTo((Veiculo) carrinha17);
        carrinha17.setFiabilidade(10);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha16 and carrinha7", (carrinha16.compareTo(carrinha7) == 0) == carrinha16.equals(carrinha7));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test059");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        java.lang.String str9 = carrinha6.toString();
        int i10 = carrinha6.getFiabilidade();
        carrinha6.setPrecoBase(10.0d);
        int i13 = carrinha6.getFiabilidade();
        carrinha6.setFiabilidade(100);
        Carrinha carrinha16 = new Carrinha();
        carrinha16.setMatricula("");
        Carrinha carrinha19 = carrinha16.clone();
        carrinha19.setOcupado(true);
        int i22 = carrinha19.getFiabilidade();
        int i23 = carrinha19.getFiabilidade();
        boolean b24 = carrinha6.equals((java.lang.Object) i23);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha0 and carrinha19", (carrinha0.compareTo(carrinha19) == 0) == carrinha0.equals(carrinha19));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test060");
        Carrinha carrinha4 = new Carrinha();
        carrinha4.setMatricula("");
        Carrinha carrinha7 = carrinha4.clone();
        carrinha4.setPrecoBase((double) 0L);
        Carrinha carrinha10 = new Carrinha();
        int i11 = carrinha10.getLugares();
        int i12 = carrinha4.compareTo((Veiculo) carrinha10);
        java.lang.String str13 = carrinha10.toString();
        Coordenada coordenada14 = carrinha10.getCoordenadas();
        Carrinha carrinha16 = new Carrinha((int) ' ', (double) 100.0f, (int) (byte) -1, "", coordenada14, false);
        Carrinha carrinha17 = new Carrinha(carrinha16);
        Carrinha carrinha18 = new Carrinha(carrinha16);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha17 and carrinha4", (carrinha17.compareTo(carrinha4) == 0) == carrinha17.equals(carrinha4));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test061");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setVelocidadeMedia((int) ' ');
        java.lang.String str3 = carrinha0.toString();
        Carrinha carrinha4 = new Carrinha();
        Carrinha carrinha5 = new Carrinha(carrinha4);
        Carrinha carrinha6 = new Carrinha(carrinha5);
        Carrinha carrinha7 = new Carrinha();
        int i8 = carrinha7.getLugares();
        boolean b9 = carrinha6.equals((java.lang.Object) carrinha7);
        carrinha7.setFiabilidade(100);
        boolean b12 = carrinha0.equals((java.lang.Object) 100);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha5 and carrinha7", (carrinha5.compareTo(carrinha7) == 0) == carrinha5.equals(carrinha7));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test062");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        java.lang.String str2 = carrinha0.toString();
        Carrinha carrinha3 = new Carrinha();
        carrinha3.setMatricula("");
        Carrinha carrinha6 = carrinha3.clone();
        carrinha3.setPrecoBase((double) 0L);
        Carrinha carrinha9 = new Carrinha();
        int i10 = carrinha9.getLugares();
        int i11 = carrinha3.compareTo((Veiculo) carrinha9);
        java.lang.String str12 = carrinha9.toString();
        Coordenada coordenada13 = carrinha9.getCoordenadas();
        carrinha9.setFiabilidade((int) (byte) 1);
        Carrinha carrinha16 = new Carrinha();
        int i17 = carrinha16.getLugares();
        carrinha16.setVelocidadeMedia(10);
        Carrinha carrinha20 = carrinha16.clone();
        boolean b21 = carrinha9.equals((java.lang.Object) carrinha16);
        int i22 = carrinha0.compareTo((Veiculo) carrinha16);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha1 and carrinha20", (carrinha1.compareTo(carrinha20) == 0) == carrinha1.equals(carrinha20));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test063");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        java.lang.String str2 = carrinha0.toString();
        carrinha0.setFiabilidade(0);
        Carrinha carrinha5 = carrinha0.clone();
        int i6 = carrinha5.getFiabilidade();
        Coordenada coordenada7 = carrinha5.getCoordenadas();
        Carrinha carrinha8 = new Carrinha();
        carrinha8.setMatricula("");
        Carrinha carrinha11 = carrinha8.clone();
        carrinha8.setPrecoBase((double) 0L);
        Carrinha carrinha14 = new Carrinha();
        int i15 = carrinha14.getLugares();
        int i16 = carrinha8.compareTo((Veiculo) carrinha14);
        java.lang.String str17 = carrinha14.toString();
        int i18 = carrinha14.getFiabilidade();
        carrinha14.setPrecoBase(10.0d);
        int i21 = carrinha14.getVelocidadeMedia();
        boolean b22 = carrinha5.equals((java.lang.Object) i21);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha0 and carrinha14", (carrinha0.compareTo(carrinha14) == 0) == carrinha0.equals(carrinha14));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test064");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        java.lang.String str9 = carrinha6.toString();
        int i10 = carrinha6.getFiabilidade();
        carrinha6.setPrecoBase(10.0d);
        int i13 = carrinha6.getVelocidadeMedia();
        Carrinha carrinha14 = new Carrinha(carrinha6);
        carrinha6.setVelocidadeMedia(1);
        Carrinha carrinha17 = new Carrinha();
        int i18 = carrinha17.getLugares();
        carrinha17.setVelocidadeMedia(10);
        carrinha17.setMatricula("n/a");
        carrinha17.setPrecoBase((double) (-1.0f));
        boolean b25 = carrinha6.equals((java.lang.Object) carrinha17);
        int i26 = carrinha17.getFiabilidade();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha14 and carrinha6", (carrinha14.compareTo(carrinha6) == 0) == carrinha14.equals(carrinha6));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test065");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carrinha0.getCoordenadas();
        int i6 = carrinha0.getVelocidadeMedia();
        Carrinha carrinha7 = new Carrinha();
        carrinha7.setMatricula("");
        Carrinha carrinha10 = carrinha7.clone();
        carrinha10.setOcupado(true);
        boolean b13 = carrinha0.equals((java.lang.Object) carrinha10);
        int i14 = carrinha0.getFiabilidade();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha7 and carrinha10", (carrinha7.compareTo(carrinha10) == 0) == carrinha7.equals(carrinha10));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test066");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        int i4 = carrinha3.getLugares();
        boolean b5 = carrinha2.equals((java.lang.Object) carrinha3);
        Carrinha carrinha6 = carrinha3.clone();
        carrinha6.setOcupado(true);
        Carrinha carrinha13 = new Carrinha();
        carrinha13.setMatricula("");
        Carrinha carrinha16 = carrinha13.clone();
        carrinha13.setPrecoBase((double) 0L);
        Carrinha carrinha19 = new Carrinha();
        int i20 = carrinha19.getLugares();
        int i21 = carrinha13.compareTo((Veiculo) carrinha19);
        java.lang.String str22 = carrinha19.toString();
        Coordenada coordenada23 = carrinha19.getCoordenadas();
        Carrinha carrinha25 = new Carrinha((int) 'a', (double) 3, 0, "", coordenada23, true);
        carrinha6.setCoordenadas(coordenada23);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha25 and carrinha13", (carrinha25.compareTo(carrinha13) == 0) == carrinha25.equals(carrinha13));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test067");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        java.lang.String str9 = carrinha6.toString();
        int i10 = carrinha6.getFiabilidade();
        carrinha6.setPrecoBase(10.0d);
        int i13 = carrinha6.getVelocidadeMedia();
        Carrinha carrinha14 = new Carrinha(carrinha6);
        boolean b15 = carrinha14.getOcupado();
        Carrinha carrinha16 = new Carrinha();
        carrinha16.setMatricula("");
        carrinha16.setOcupado(true);
        boolean b21 = carrinha14.equals((java.lang.Object) carrinha16);
        Coordenada coordenada22 = carrinha14.getCoordenadas();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha0 and carrinha16", (carrinha0.compareTo(carrinha16) == 0) == carrinha0.equals(carrinha16));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test068");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        java.lang.String str9 = carrinha6.toString();
        int i10 = carrinha6.getFiabilidade();
        carrinha6.setPrecoBase(10.0d);
        int i13 = carrinha6.getVelocidadeMedia();
        Carrinha carrinha14 = new Carrinha(carrinha6);
        boolean b15 = carrinha14.getOcupado();
        Carrinha carrinha16 = new Carrinha();
        carrinha16.setMatricula("");
        carrinha16.setOcupado(true);
        boolean b21 = carrinha14.equals((java.lang.Object) carrinha16);
        int i22 = carrinha14.getVelocidadeMedia();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha3 and carrinha16", (carrinha3.compareTo(carrinha16) == 0) == carrinha3.equals(carrinha16));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test069");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha3.setOcupado(true);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        carrinha6.setVelocidadeMedia(10);
        int i10 = carrinha3.compareTo((Veiculo) carrinha6);
        Carrinha carrinha11 = carrinha3.clone();
        java.lang.String str12 = carrinha3.toString();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha0 and carrinha11", (carrinha0.compareTo(carrinha11) == 0) == carrinha0.equals(carrinha11));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test070");
        Carrinha carrinha8 = new Carrinha();
        carrinha8.setMatricula("");
        Carrinha carrinha11 = carrinha8.clone();
        carrinha8.setPrecoBase((double) 0L);
        Carrinha carrinha14 = new Carrinha();
        int i15 = carrinha14.getLugares();
        int i16 = carrinha8.compareTo((Veiculo) carrinha14);
        java.lang.String str17 = carrinha14.toString();
        Coordenada coordenada18 = carrinha14.getCoordenadas();
        Carrinha carrinha20 = new Carrinha((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, false);
        Carrinha carrinha22 = new Carrinha((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, true);
        Carrinha carrinha23 = new Carrinha();
        carrinha23.setVelocidadeMedia((int) ' ');
        java.lang.String str26 = carrinha23.toString();
        boolean b27 = carrinha22.equals((java.lang.Object) carrinha23);
        carrinha22.setVelocidadeMedia((int) 'a');
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha14 and carrinha23", (carrinha14.compareTo(carrinha23) == 0) == carrinha14.equals(carrinha23));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test071");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carrinha0.getCoordenadas();
        int i6 = carrinha0.getVelocidadeMedia();
        Carrinha carrinha7 = new Carrinha();
        carrinha7.setMatricula("");
        Carrinha carrinha10 = carrinha7.clone();
        carrinha10.setOcupado(true);
        boolean b13 = carrinha0.equals((java.lang.Object) carrinha10);
        Carrinha carrinha14 = new Carrinha(carrinha0);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha10 and carrinha7", (carrinha10.compareTo(carrinha7) == 0) == carrinha10.equals(carrinha7));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test072");
        Carrinha carrinha8 = new Carrinha();
        carrinha8.setMatricula("");
        Carrinha carrinha11 = carrinha8.clone();
        carrinha8.setPrecoBase((double) 0L);
        Carrinha carrinha14 = new Carrinha();
        int i15 = carrinha14.getLugares();
        int i16 = carrinha8.compareTo((Veiculo) carrinha14);
        java.lang.String str17 = carrinha14.toString();
        Coordenada coordenada18 = carrinha14.getCoordenadas();
        Carrinha carrinha20 = new Carrinha((int) (byte) 100, (double) '#', (int) (short) 0, "", coordenada18, false);
        Carrinha carrinha22 = new Carrinha((int) (short) 10, (double) (short) 1, (int) '4', "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, false);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha8 and carrinha20", (carrinha8.compareTo(carrinha20) == 0) == carrinha8.equals(carrinha20));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test073");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        Coordenada coordenada4 = carrinha3.getCoordenadas();
        Carrinha carrinha5 = new Carrinha();
        carrinha5.setMatricula("");
        Carrinha carrinha8 = carrinha5.clone();
        carrinha5.setPrecoBase((double) 0L);
        Carrinha carrinha11 = new Carrinha();
        int i12 = carrinha11.getLugares();
        int i13 = carrinha5.compareTo((Veiculo) carrinha11);
        java.lang.String str14 = carrinha11.toString();
        Coordenada coordenada15 = carrinha11.getCoordenadas();
        int i16 = carrinha3.compareTo((Veiculo) carrinha11);
        java.lang.String str17 = carrinha3.getMatricula();
        Carrinha carrinha18 = new Carrinha();
        int i19 = carrinha18.getLugares();
        carrinha18.setVelocidadeMedia(10);
        Carrinha carrinha22 = new Carrinha(carrinha18);
        boolean b23 = carrinha3.equals((java.lang.Object) carrinha18);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha11 and carrinha22", (carrinha11.compareTo(carrinha22) == 0) == carrinha11.equals(carrinha22));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test074");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        int i4 = carrinha3.getLugares();
        boolean b5 = carrinha2.equals((java.lang.Object) carrinha3);
        carrinha3.setOcupado(true);
        Carrinha carrinha16 = new Carrinha();
        carrinha16.setMatricula("");
        boolean b20 = carrinha16.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada21 = carrinha16.getCoordenadas();
        carrinha16.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carrinha16.setFiabilidade(0);
        Carrinha carrinha26 = new Carrinha();
        carrinha26.setMatricula("");
        Carrinha carrinha29 = carrinha26.clone();
        carrinha26.setPrecoBase((double) 0L);
        Carrinha carrinha32 = new Carrinha(carrinha26);
        int i33 = carrinha16.compareTo((Veiculo) carrinha26);
        Carrinha carrinha34 = new Carrinha(carrinha26);
        Coordenada coordenada35 = carrinha34.getCoordenadas();
        Carrinha carrinha37 = new Carrinha((int) (byte) 0, (double) 0L, (int) (byte) 0, "n/a", coordenada35, true);
        Coordenada coordenada38 = carrinha37.getCoordenadas();
        Carrinha carrinha40 = new Carrinha(52, (double) 3, (int) (byte) 0, "hi!", coordenada38, true);
        carrinha3.setCoordenadas(coordenada38);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha1 and carrinha37", (carrinha1.compareTo(carrinha37) == 0) == carrinha1.equals(carrinha37));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test075");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha();
        carrinha2.setMatricula("");
        Carrinha carrinha5 = carrinha2.clone();
        carrinha2.setPrecoBase((double) 0L);
        java.lang.String str8 = carrinha2.getMatricula();
        Coordenada coordenada9 = carrinha2.getCoordenadas();
        Carrinha carrinha14 = new Carrinha();
        carrinha14.setMatricula("");
        boolean b18 = carrinha14.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada19 = carrinha14.getCoordenadas();
        carrinha14.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carrinha14.setFiabilidade(0);
        Carrinha carrinha24 = new Carrinha();
        carrinha24.setMatricula("");
        Carrinha carrinha27 = carrinha24.clone();
        carrinha24.setPrecoBase((double) 0L);
        Carrinha carrinha30 = new Carrinha(carrinha24);
        int i31 = carrinha14.compareTo((Veiculo) carrinha24);
        Carrinha carrinha32 = new Carrinha(carrinha24);
        Coordenada coordenada33 = carrinha32.getCoordenadas();
        Carrinha carrinha35 = new Carrinha((int) (byte) 0, (double) 0L, (int) (byte) 0, "n/a", coordenada33, true);
        Coordenada coordenada36 = carrinha35.getCoordenadas();
        carrinha2.setCoordenadas(coordenada36);
        carrinha0.setCoordenadas(coordenada36);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha35 and carrinha1", (carrinha35.compareTo(carrinha1) == 0) == carrinha35.equals(carrinha1));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test076");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha(carrinha0);
        carrinha6.setPrecoBase((double) (-1.0f));
        carrinha6.setVelocidadeMedia((int) (short) 0);
        carrinha6.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Carrinha carrinha13 = new Carrinha(carrinha6);
        int i14 = carrinha13.getLugares();
        Carrinha carrinha15 = new Carrinha();
        int i16 = carrinha15.getLugares();
        java.lang.String str17 = carrinha15.getMatricula();
        Carrinha carrinha18 = new Carrinha(carrinha15);
        int i19 = carrinha18.getFiabilidade();
        carrinha18.setPrecoBase(1.0d);
        boolean b22 = carrinha13.equals((java.lang.Object) 1.0d);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha18 and carrinha15", (carrinha18.compareTo(carrinha15) == 0) == carrinha18.equals(carrinha15));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test077");
        Carrinha carrinha4 = new Carrinha();
        carrinha4.setMatricula("");
        Carrinha carrinha7 = carrinha4.clone();
        carrinha4.setPrecoBase((double) 0L);
        Carrinha carrinha10 = new Carrinha();
        int i11 = carrinha10.getLugares();
        int i12 = carrinha4.compareTo((Veiculo) carrinha10);
        java.lang.String str13 = carrinha10.toString();
        Coordenada coordenada14 = carrinha10.getCoordenadas();
        Carrinha carrinha16 = new Carrinha((int) ' ', (double) 100.0f, (int) (byte) -1, "", coordenada14, false);
        Carrinha carrinha17 = new Carrinha(carrinha16);
        carrinha16.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n");
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha17 and carrinha7", (carrinha17.compareTo(carrinha7) == 0) == carrinha17.equals(carrinha7));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test078");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        int i4 = carrinha3.getLugares();
        boolean b5 = carrinha2.equals((java.lang.Object) carrinha3);
        Carrinha carrinha6 = carrinha3.clone();
        carrinha6.setVelocidadeMedia((int) (short) 0);
        int i9 = carrinha6.getLugares();
        carrinha6.setMatricula("Matrícula: \nVelocidade Média/km: -1km/h\nPreço Base: 0.0€\nFiabilidade: 1\nLugares: 9\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Carrinha carrinha12 = new Carrinha();
        carrinha12.setMatricula("");
        boolean b16 = carrinha12.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada17 = carrinha12.getCoordenadas();
        java.lang.String str18 = carrinha12.getMatricula();
        Carrinha carrinha23 = new Carrinha();
        carrinha23.setMatricula("");
        Carrinha carrinha26 = carrinha23.clone();
        carrinha23.setPrecoBase((double) 0L);
        Carrinha carrinha29 = new Carrinha();
        int i30 = carrinha29.getLugares();
        int i31 = carrinha23.compareTo((Veiculo) carrinha29);
        java.lang.String str32 = carrinha29.toString();
        Coordenada coordenada33 = carrinha29.getCoordenadas();
        Carrinha carrinha35 = new Carrinha((int) (byte) -1, 0.0d, (int) 'a', "", coordenada33, true);
        int i36 = carrinha12.compareTo((Veiculo) carrinha35);
        boolean b37 = carrinha6.equals((java.lang.Object) carrinha12);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha35 and carrinha23", (carrinha35.compareTo(carrinha23) == 0) == carrinha35.equals(carrinha23));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test079");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha3.setOcupado(true);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        carrinha6.setVelocidadeMedia(10);
        int i10 = carrinha3.compareTo((Veiculo) carrinha6);
        Carrinha carrinha11 = carrinha3.clone();
        carrinha11.setVelocidadeMedia((int) 'a');
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha3 and carrinha0", (carrinha3.compareTo(carrinha0) == 0) == carrinha3.equals(carrinha0));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test080");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        Carrinha carrinha4 = new Carrinha(carrinha0);
        int i5 = carrinha0.getVelocidadeMedia();
        java.lang.String str6 = carrinha0.getMatricula();
        carrinha0.setVelocidadeMedia((int) (byte) 1);
        Carrinha carrinha9 = new Carrinha(carrinha0);
        int i10 = carrinha9.getVelocidadeMedia();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha0 and carrinha4", (carrinha0.compareTo(carrinha4) == 0) == carrinha0.equals(carrinha4));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test081");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        Carrinha carrinha4 = new Carrinha(carrinha0);
        int i5 = carrinha0.getVelocidadeMedia();
        carrinha0.setMatricula("");
        carrinha0.setPrecoBase((double) (byte) 1);
        Carrinha carrinha10 = new Carrinha();
        int i11 = carrinha10.getLugares();
        Coordenada coordenada12 = carrinha10.getCoordenadas();
        boolean b13 = carrinha0.equals((java.lang.Object) carrinha10);
        carrinha0.setPrecoBase((double) (-33));
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha10 and carrinha4", (carrinha10.compareTo(carrinha4) == 0) == carrinha10.equals(carrinha4));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test082");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        java.lang.String str3 = carrinha0.toString();
        Carrinha carrinha4 = new Carrinha();
        Carrinha carrinha5 = new Carrinha(carrinha4);
        java.lang.String str6 = carrinha4.toString();
        carrinha4.setFiabilidade(0);
        Carrinha carrinha9 = carrinha4.clone();
        Carrinha carrinha10 = new Carrinha();
        Carrinha carrinha11 = new Carrinha(carrinha10);
        Carrinha carrinha12 = new Carrinha(carrinha11);
        Carrinha carrinha13 = new Carrinha();
        Carrinha carrinha14 = new Carrinha(carrinha13);
        int i15 = carrinha11.compareTo((Veiculo) carrinha13);
        Carrinha carrinha16 = new Carrinha();
        carrinha16.setMatricula("");
        boolean b20 = carrinha16.equals((java.lang.Object) (-1.0d));
        boolean b21 = carrinha11.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha22 = new Carrinha();
        carrinha22.setMatricula("");
        Carrinha carrinha25 = carrinha22.clone();
        carrinha22.setPrecoBase((double) 0L);
        Carrinha carrinha28 = new Carrinha();
        int i29 = carrinha28.getLugares();
        int i30 = carrinha22.compareTo((Veiculo) carrinha28);
        java.lang.String str31 = carrinha28.toString();
        Coordenada coordenada32 = carrinha28.getCoordenadas();
        carrinha11.setCoordenadas(coordenada32);
        carrinha4.setCoordenadas(coordenada32);
        carrinha0.setCoordenadas(coordenada32);
        Carrinha carrinha36 = new Carrinha();
        int i37 = carrinha36.getLugares();
        carrinha36.setVelocidadeMedia(10);
        Carrinha carrinha40 = new Carrinha(carrinha36);
        int i41 = carrinha0.compareTo((Veiculo) carrinha40);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha5 and carrinha36", (carrinha5.compareTo(carrinha36) == 0) == carrinha5.equals(carrinha36));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test083");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carrinha0.getCoordenadas();
        boolean b6 = carrinha0.getOcupado();
        java.lang.String str7 = carrinha0.getMatricula();
        Carrinha carrinha12 = new Carrinha();
        carrinha12.setMatricula("");
        Carrinha carrinha15 = carrinha12.clone();
        carrinha12.setPrecoBase((double) 0L);
        Carrinha carrinha18 = new Carrinha();
        int i19 = carrinha18.getLugares();
        int i20 = carrinha12.compareTo((Veiculo) carrinha18);
        java.lang.String str21 = carrinha18.toString();
        Coordenada coordenada22 = carrinha18.getCoordenadas();
        Carrinha carrinha24 = new Carrinha((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada22, false);
        carrinha0.setCoordenadas(coordenada22);
        carrinha0.setOcupado(true);
        Carrinha carrinha28 = new Carrinha(carrinha0);
        carrinha0.setVelocidadeMedia((int) ' ');
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha12 and carrinha28", (carrinha12.compareTo(carrinha28) == 0) == carrinha12.equals(carrinha28));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test084");
        Carrinha carrinha8 = new Carrinha();
        carrinha8.setMatricula("");
        Carrinha carrinha11 = carrinha8.clone();
        carrinha8.setPrecoBase((double) 0L);
        Carrinha carrinha14 = new Carrinha();
        int i15 = carrinha14.getLugares();
        int i16 = carrinha8.compareTo((Veiculo) carrinha14);
        java.lang.String str17 = carrinha14.toString();
        Coordenada coordenada18 = carrinha14.getCoordenadas();
        Carrinha carrinha20 = new Carrinha((int) ' ', (double) 100.0f, (int) (byte) -1, "", coordenada18, false);
        Carrinha carrinha22 = new Carrinha((int) (short) 10, 100.0d, 32, "", coordenada18, false);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha8 and carrinha20", (carrinha8.compareTo(carrinha20) == 0) == carrinha8.equals(carrinha20));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test085");
        Carrinha carrinha4 = new Carrinha();
        carrinha4.setMatricula("");
        Carrinha carrinha7 = carrinha4.clone();
        carrinha4.setPrecoBase((double) 0L);
        Carrinha carrinha10 = new Carrinha();
        int i11 = carrinha10.getLugares();
        int i12 = carrinha4.compareTo((Veiculo) carrinha10);
        java.lang.String str13 = carrinha10.toString();
        Coordenada coordenada14 = carrinha10.getCoordenadas();
        Carrinha carrinha16 = new Carrinha((int) 'a', (double) 3, 0, "", coordenada14, true);
        Carrinha carrinha17 = new Carrinha();
        carrinha17.setMatricula("");
        boolean b21 = carrinha17.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha22 = new Carrinha(carrinha17);
        double d23 = carrinha17.getPrecoBase();
        boolean b24 = carrinha17.getOcupado();
        int i25 = carrinha17.getVelocidadeMedia();
        java.lang.String str26 = carrinha17.getMatricula();
        carrinha17.setMatricula("hi!");
        int i29 = carrinha16.compareTo((Veiculo) carrinha17);
        Carrinha carrinha30 = carrinha16.clone();
        boolean b31 = carrinha30.getOcupado();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha16 and carrinha4", (carrinha16.compareTo(carrinha4) == 0) == carrinha16.equals(carrinha4));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test086");
        Carrinha carrinha8 = new Carrinha();
        int i9 = carrinha8.getLugares();
        Coordenada coordenada10 = carrinha8.getCoordenadas();
        Carrinha carrinha12 = new Carrinha((int) (short) -1, (double) (byte) -1, (int) '4', "", coordenada10, true);
        Carrinha carrinha14 = new Carrinha(52, (double) (short) 10, (-3), "n/a", coordenada10, true);
        carrinha14.setVelocidadeMedia(9);
        Carrinha carrinha21 = new Carrinha();
        carrinha21.setMatricula("");
        boolean b25 = carrinha21.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada26 = carrinha21.getCoordenadas();
        carrinha21.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carrinha21.setFiabilidade(0);
        Carrinha carrinha31 = new Carrinha();
        carrinha31.setMatricula("");
        Carrinha carrinha34 = carrinha31.clone();
        carrinha31.setPrecoBase((double) 0L);
        Carrinha carrinha37 = new Carrinha(carrinha31);
        int i38 = carrinha21.compareTo((Veiculo) carrinha31);
        Carrinha carrinha39 = new Carrinha(carrinha31);
        Coordenada coordenada40 = carrinha39.getCoordenadas();
        Carrinha carrinha42 = new Carrinha((int) (byte) 0, (double) 0L, (int) (byte) 0, "n/a", coordenada40, true);
        carrinha14.setCoordenadas(coordenada40);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha12 and carrinha34", (carrinha12.compareTo(carrinha34) == 0) == carrinha12.equals(carrinha34));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test087");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        Carrinha carrinha4 = new Carrinha(carrinha3);
        int i5 = carrinha1.compareTo((Veiculo) carrinha3);
        int i6 = carrinha3.getVelocidadeMedia();
        Carrinha carrinha7 = carrinha3.clone();
        int i8 = carrinha7.getFiabilidade();
        int i9 = carrinha7.getFiabilidade();
        Carrinha carrinha10 = new Carrinha(carrinha7);
        java.lang.String str11 = carrinha7.getMatricula();
        Carrinha carrinha12 = new Carrinha();
        int i13 = carrinha12.getLugares();
        carrinha12.setVelocidadeMedia(10);
        carrinha12.setFiabilidade((int) (byte) 0);
        double d18 = carrinha12.getPrecoBase();
        boolean b19 = carrinha7.equals((java.lang.Object) d18);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha10 and carrinha12", (carrinha10.compareTo(carrinha12) == 0) == carrinha10.equals(carrinha12));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test088");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        Carrinha carrinha4 = new Carrinha(carrinha3);
        int i5 = carrinha1.compareTo((Veiculo) carrinha3);
        int i6 = carrinha3.getVelocidadeMedia();
        Carrinha carrinha7 = carrinha3.clone();
        int i8 = carrinha7.getFiabilidade();
        int i9 = carrinha7.getFiabilidade();
        Carrinha carrinha10 = new Carrinha(carrinha7);
        Carrinha carrinha11 = new Carrinha();
        carrinha11.setMatricula("");
        Carrinha carrinha14 = carrinha11.clone();
        Coordenada coordenada15 = carrinha14.getCoordenadas();
        Carrinha carrinha16 = new Carrinha();
        carrinha16.setMatricula("");
        Carrinha carrinha19 = carrinha16.clone();
        carrinha16.setPrecoBase((double) 0L);
        Carrinha carrinha22 = new Carrinha();
        int i23 = carrinha22.getLugares();
        int i24 = carrinha16.compareTo((Veiculo) carrinha22);
        java.lang.String str25 = carrinha22.toString();
        Coordenada coordenada26 = carrinha22.getCoordenadas();
        int i27 = carrinha14.compareTo((Veiculo) carrinha22);
        Carrinha carrinha28 = new Carrinha();
        carrinha28.setMatricula("");
        Carrinha carrinha31 = carrinha28.clone();
        carrinha28.setPrecoBase((double) 0L);
        java.lang.String str34 = carrinha28.getMatricula();
        Coordenada coordenada35 = carrinha28.getCoordenadas();
        carrinha14.setCoordenadas(coordenada35);
        carrinha14.setFiabilidade((int) (short) -1);
        int i39 = carrinha7.compareTo((Veiculo) carrinha14);
        boolean b40 = carrinha7.getOcupado();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha19 and carrinha14", (carrinha19.compareTo(carrinha14) == 0) == carrinha19.equals(carrinha14));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test089");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        Carrinha carrinha4 = new Carrinha(carrinha0);
        carrinha4.setOcupado(true);
        java.lang.String str7 = carrinha4.getMatricula();
        Carrinha carrinha16 = new Carrinha();
        carrinha16.setMatricula("");
        boolean b20 = carrinha16.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada21 = carrinha16.getCoordenadas();
        boolean b22 = carrinha16.getOcupado();
        java.lang.String str23 = carrinha16.getMatricula();
        Carrinha carrinha28 = new Carrinha();
        carrinha28.setMatricula("");
        Carrinha carrinha31 = carrinha28.clone();
        carrinha28.setPrecoBase((double) 0L);
        Carrinha carrinha34 = new Carrinha();
        int i35 = carrinha34.getLugares();
        int i36 = carrinha28.compareTo((Veiculo) carrinha34);
        java.lang.String str37 = carrinha34.toString();
        Coordenada coordenada38 = carrinha34.getCoordenadas();
        Carrinha carrinha40 = new Carrinha((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada38, false);
        carrinha16.setCoordenadas(coordenada38);
        Carrinha carrinha43 = new Carrinha(32, (double) (short) 1, (int) (byte) 1, "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada38, true);
        Carrinha carrinha45 = new Carrinha(9, (-1.0d), (int) ' ', "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 10.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada38, true);
        carrinha4.setCoordenadas(coordenada38);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha0 and carrinha34", (carrinha0.compareTo(carrinha34) == 0) == carrinha0.equals(carrinha34));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test090");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        java.lang.String str2 = carrinha0.getMatricula();
        Carrinha carrinha3 = new Carrinha(carrinha0);
        carrinha0.setOcupado(true);
        java.lang.String str6 = carrinha0.toString();
        Carrinha carrinha7 = new Carrinha();
        int i8 = carrinha7.getLugares();
        java.lang.String str9 = carrinha7.getMatricula();
        Carrinha carrinha10 = new Carrinha(carrinha7);
        int i11 = carrinha7.getVelocidadeMedia();
        int i12 = carrinha0.compareTo((Veiculo) carrinha7);
        int i13 = carrinha7.getVelocidadeMedia();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha0 and carrinha3", (carrinha0.compareTo(carrinha3) == 0) == carrinha0.equals(carrinha3));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test091");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        Carrinha carrinha4 = new Carrinha(carrinha0);
        int i5 = carrinha0.getVelocidadeMedia();
        java.lang.String str6 = carrinha0.getMatricula();
        carrinha0.setVelocidadeMedia((int) (byte) 1);
        Carrinha carrinha9 = new Carrinha(carrinha0);
        int i10 = carrinha9.getLugares();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha4 and carrinha0", (carrinha4.compareTo(carrinha0) == 0) == carrinha4.equals(carrinha0));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test092");
        Carrinha carrinha8 = new Carrinha();
        carrinha8.setMatricula("");
        Carrinha carrinha11 = carrinha8.clone();
        carrinha8.setPrecoBase((double) 0L);
        Carrinha carrinha14 = new Carrinha();
        int i15 = carrinha14.getLugares();
        int i16 = carrinha8.compareTo((Veiculo) carrinha14);
        java.lang.String str17 = carrinha14.toString();
        Coordenada coordenada18 = carrinha14.getCoordenadas();
        Carrinha carrinha20 = new Carrinha((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, false);
        Carrinha carrinha22 = new Carrinha((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, true);
        Carrinha carrinha23 = new Carrinha();
        carrinha23.setVelocidadeMedia((int) ' ');
        java.lang.String str26 = carrinha23.toString();
        boolean b27 = carrinha22.equals((java.lang.Object) carrinha23);
        carrinha22.setFiabilidade((-3));
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha23 and carrinha14", (carrinha23.compareTo(carrinha14) == 0) == carrinha23.equals(carrinha14));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test093");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        Carrinha carrinha4 = new Carrinha(carrinha3);
        int i5 = carrinha1.compareTo((Veiculo) carrinha3);
        Carrinha carrinha6 = new Carrinha();
        carrinha6.setMatricula("");
        boolean b10 = carrinha6.equals((java.lang.Object) (-1.0d));
        boolean b11 = carrinha1.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha12 = new Carrinha();
        carrinha12.setMatricula("");
        Carrinha carrinha15 = carrinha12.clone();
        carrinha12.setPrecoBase((double) 0L);
        Carrinha carrinha18 = new Carrinha();
        int i19 = carrinha18.getLugares();
        int i20 = carrinha12.compareTo((Veiculo) carrinha18);
        java.lang.String str21 = carrinha18.toString();
        Coordenada coordenada22 = carrinha18.getCoordenadas();
        carrinha1.setCoordenadas(coordenada22);
        double d24 = carrinha1.getPrecoBase();
        Carrinha carrinha29 = new Carrinha();
        carrinha29.setMatricula("");
        Carrinha carrinha32 = carrinha29.clone();
        carrinha29.setPrecoBase((double) 0L);
        Carrinha carrinha35 = new Carrinha();
        int i36 = carrinha35.getLugares();
        int i37 = carrinha29.compareTo((Veiculo) carrinha35);
        java.lang.String str38 = carrinha35.toString();
        Coordenada coordenada39 = carrinha35.getCoordenadas();
        Carrinha carrinha41 = new Carrinha((int) ' ', (double) 100.0f, (int) (byte) -1, "", coordenada39, false);
        double d42 = carrinha41.getPrecoBase();
        Carrinha carrinha43 = carrinha41.clone();
        boolean b44 = carrinha1.equals((java.lang.Object) carrinha43);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha29 and carrinha41", (carrinha29.compareTo(carrinha41) == 0) == carrinha29.equals(carrinha41));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test094");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        java.lang.String str2 = carrinha0.getMatricula();
        Carrinha carrinha3 = new Carrinha(carrinha0);
        carrinha0.setOcupado(true);
        double d6 = carrinha0.getPrecoBase();
        java.lang.String str7 = carrinha0.getMatricula();
        Carrinha carrinha8 = new Carrinha();
        int i9 = carrinha8.getLugares();
        carrinha8.setVelocidadeMedia(10);
        Carrinha carrinha12 = carrinha8.clone();
        boolean b13 = carrinha8.getOcupado();
        double d14 = carrinha8.getPrecoBase();
        int i15 = carrinha8.getFiabilidade();
        boolean b16 = carrinha0.equals((java.lang.Object) carrinha8);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha12 and carrinha3", (carrinha12.compareTo(carrinha3) == 0) == carrinha12.equals(carrinha3));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test095");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha3.setOcupado(true);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        carrinha6.setVelocidadeMedia(10);
        int i10 = carrinha3.compareTo((Veiculo) carrinha6);
        carrinha6.setMatricula("Matrícula: Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 100km/h\nPreço Base: 1.0€\nFiabilidade: 0\nLugares: 9\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha3 and carrinha0", (carrinha3.compareTo(carrinha0) == 0) == carrinha3.equals(carrinha0));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test096");
        Carrinha carrinha8 = new Carrinha();
        carrinha8.setMatricula("");
        Carrinha carrinha11 = carrinha8.clone();
        carrinha8.setPrecoBase((double) 0L);
        Carrinha carrinha14 = new Carrinha();
        int i15 = carrinha14.getLugares();
        int i16 = carrinha8.compareTo((Veiculo) carrinha14);
        java.lang.String str17 = carrinha14.toString();
        Coordenada coordenada18 = carrinha14.getCoordenadas();
        Carrinha carrinha20 = new Carrinha((int) ' ', (double) 100.0f, (int) (byte) -1, "", coordenada18, false);
        Carrinha carrinha22 = new Carrinha((int) ' ', (double) ' ', 0, "", coordenada18, false);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha11 and carrinha20", (carrinha11.compareTo(carrinha20) == 0) == carrinha11.equals(carrinha20));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test097");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carrinha0.getCoordenadas();
        carrinha0.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carrinha0.setFiabilidade(0);
        int i10 = carrinha0.getVelocidadeMedia();
        Carrinha carrinha11 = new Carrinha();
        Carrinha carrinha12 = new Carrinha();
        Carrinha carrinha13 = new Carrinha(carrinha12);
        int i14 = carrinha13.getFiabilidade();
        Coordenada coordenada15 = carrinha13.getCoordenadas();
        carrinha11.setCoordenadas(coordenada15);
        boolean b17 = carrinha0.equals((java.lang.Object) carrinha11);
        Carrinha carrinha18 = new Carrinha();
        carrinha18.setMatricula("");
        Carrinha carrinha21 = carrinha18.clone();
        carrinha21.setOcupado(true);
        int i24 = carrinha21.getLugares();
        Carrinha carrinha25 = new Carrinha(carrinha21);
        int i26 = carrinha0.compareTo((Veiculo) carrinha21);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha18 and carrinha25", (carrinha18.compareTo(carrinha25) == 0) == carrinha18.equals(carrinha25));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test098");
        Carrinha carrinha8 = new Carrinha();
        carrinha8.setMatricula("");
        Carrinha carrinha11 = carrinha8.clone();
        carrinha8.setPrecoBase((double) 0L);
        Carrinha carrinha14 = new Carrinha();
        int i15 = carrinha14.getLugares();
        int i16 = carrinha8.compareTo((Veiculo) carrinha14);
        java.lang.String str17 = carrinha14.toString();
        Coordenada coordenada18 = carrinha14.getCoordenadas();
        Carrinha carrinha20 = new Carrinha((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, false);
        Carrinha carrinha22 = new Carrinha((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, true);
        carrinha22.setFiabilidade(0);
        carrinha22.setPrecoBase((double) 1.0f);
        Carrinha carrinha27 = new Carrinha();
        carrinha27.setMatricula("");
        Carrinha carrinha30 = carrinha27.clone();
        carrinha27.setPrecoBase((double) 0L);
        Carrinha carrinha33 = new Carrinha();
        int i34 = carrinha33.getLugares();
        int i35 = carrinha27.compareTo((Veiculo) carrinha33);
        java.lang.String str36 = carrinha33.toString();
        int i37 = carrinha33.getFiabilidade();
        carrinha33.setPrecoBase(10.0d);
        Carrinha carrinha40 = carrinha33.clone();
        int i41 = carrinha22.compareTo((Veiculo) carrinha40);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha14 and carrinha33", (carrinha14.compareTo(carrinha33) == 0) == carrinha14.equals(carrinha33));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test099");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha5 = new Carrinha(carrinha0);
        double d6 = carrinha0.getPrecoBase();
        boolean b7 = carrinha0.getOcupado();
        int i8 = carrinha0.getVelocidadeMedia();
        Carrinha carrinha9 = carrinha0.clone();
        carrinha9.setFiabilidade((int) (byte) 10);
        Carrinha carrinha12 = new Carrinha();
        carrinha12.setMatricula("");
        Carrinha carrinha15 = carrinha12.clone();
        carrinha12.setPrecoBase((double) 0L);
        Carrinha carrinha18 = new Carrinha(carrinha12);
        carrinha18.setPrecoBase((double) (-1.0f));
        double d21 = carrinha18.getPrecoBase();
        boolean b22 = carrinha9.equals((java.lang.Object) d21);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha12 and carrinha18", (carrinha12.compareTo(carrinha18) == 0) == carrinha12.equals(carrinha18));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test100");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        java.lang.String str2 = carrinha0.toString();
        carrinha0.setFiabilidade(0);
        Carrinha carrinha5 = carrinha0.clone();
        Carrinha carrinha6 = new Carrinha();
        Carrinha carrinha7 = new Carrinha(carrinha6);
        Carrinha carrinha8 = new Carrinha(carrinha7);
        Carrinha carrinha9 = new Carrinha();
        Carrinha carrinha10 = new Carrinha(carrinha9);
        int i11 = carrinha7.compareTo((Veiculo) carrinha9);
        Carrinha carrinha12 = new Carrinha();
        carrinha12.setMatricula("");
        boolean b16 = carrinha12.equals((java.lang.Object) (-1.0d));
        boolean b17 = carrinha7.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha18 = new Carrinha();
        carrinha18.setMatricula("");
        Carrinha carrinha21 = carrinha18.clone();
        carrinha18.setPrecoBase((double) 0L);
        Carrinha carrinha24 = new Carrinha();
        int i25 = carrinha24.getLugares();
        int i26 = carrinha18.compareTo((Veiculo) carrinha24);
        java.lang.String str27 = carrinha24.toString();
        Coordenada coordenada28 = carrinha24.getCoordenadas();
        carrinha7.setCoordenadas(coordenada28);
        carrinha0.setCoordenadas(coordenada28);
        carrinha0.setPrecoBase(100.0d);
        Carrinha carrinha33 = new Carrinha(carrinha0);
        Coordenada coordenada34 = carrinha0.getCoordenadas();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha10 and carrinha33", (carrinha10.compareTo(carrinha33) == 0) == carrinha10.equals(carrinha33));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test101");
        Carrinha carrinha16 = new Carrinha();
        carrinha16.setMatricula("");
        Carrinha carrinha19 = carrinha16.clone();
        carrinha16.setPrecoBase((double) 0L);
        Carrinha carrinha22 = new Carrinha();
        int i23 = carrinha22.getLugares();
        int i24 = carrinha16.compareTo((Veiculo) carrinha22);
        java.lang.String str25 = carrinha22.toString();
        Coordenada coordenada26 = carrinha22.getCoordenadas();
        Carrinha carrinha28 = new Carrinha((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada26, false);
        Carrinha carrinha30 = new Carrinha((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada26, true);
        Carrinha carrinha32 = new Carrinha((int) '#', 10.0d, (-1), "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada26, true);
        Coordenada coordenada33 = carrinha32.getCoordenadas();
        Carrinha carrinha35 = new Carrinha((int) '4', (double) (byte) 1, 0, "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada33, true);
        Carrinha carrinha36 = new Carrinha();
        carrinha36.setMatricula("");
        boolean b40 = carrinha36.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada41 = carrinha36.getCoordenadas();
        carrinha36.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carrinha36.setFiabilidade(0);
        Carrinha carrinha46 = new Carrinha();
        carrinha46.setMatricula("");
        Carrinha carrinha49 = carrinha46.clone();
        carrinha46.setPrecoBase((double) 0L);
        Carrinha carrinha52 = new Carrinha(carrinha46);
        int i53 = carrinha36.compareTo((Veiculo) carrinha46);
        Carrinha carrinha54 = new Carrinha(carrinha46);
        Coordenada coordenada55 = carrinha54.getCoordenadas();
        carrinha35.setCoordenadas(coordenada55);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha36 and carrinha28", (carrinha36.compareTo(carrinha28) == 0) == carrinha36.equals(carrinha28));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test102");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        java.lang.String str9 = carrinha6.toString();
        Coordenada coordenada10 = carrinha6.getCoordenadas();
        carrinha6.setFiabilidade((int) (byte) 1);
        Carrinha carrinha13 = new Carrinha();
        int i14 = carrinha13.getLugares();
        carrinha13.setVelocidadeMedia(10);
        Carrinha carrinha17 = carrinha13.clone();
        boolean b18 = carrinha6.equals((java.lang.Object) carrinha13);
        Carrinha carrinha19 = new Carrinha();
        carrinha19.setMatricula("");
        Carrinha carrinha22 = carrinha19.clone();
        carrinha19.setPrecoBase((double) 0L);
        Carrinha carrinha25 = new Carrinha();
        int i26 = carrinha25.getLugares();
        int i27 = carrinha19.compareTo((Veiculo) carrinha25);
        java.lang.String str28 = carrinha25.toString();
        int i29 = carrinha25.getFiabilidade();
        carrinha25.setPrecoBase(10.0d);
        int i32 = carrinha25.getVelocidadeMedia();
        Carrinha carrinha37 = new Carrinha();
        Carrinha carrinha38 = new Carrinha(carrinha37);
        Carrinha carrinha39 = new Carrinha(carrinha38);
        Carrinha carrinha40 = new Carrinha();
        Carrinha carrinha41 = new Carrinha(carrinha40);
        int i42 = carrinha38.compareTo((Veiculo) carrinha40);
        Carrinha carrinha43 = new Carrinha();
        carrinha43.setMatricula("");
        boolean b47 = carrinha43.equals((java.lang.Object) (-1.0d));
        boolean b48 = carrinha38.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha49 = new Carrinha();
        carrinha49.setMatricula("");
        Carrinha carrinha52 = carrinha49.clone();
        carrinha49.setPrecoBase((double) 0L);
        Carrinha carrinha55 = new Carrinha();
        int i56 = carrinha55.getLugares();
        int i57 = carrinha49.compareTo((Veiculo) carrinha55);
        java.lang.String str58 = carrinha55.toString();
        Coordenada coordenada59 = carrinha55.getCoordenadas();
        carrinha38.setCoordenadas(coordenada59);
        Carrinha carrinha62 = new Carrinha((-1), 10.0d, (int) (byte) 1, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada59, true);
        carrinha25.setCoordenadas(coordenada59);
        carrinha6.setCoordenadas(coordenada59);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha40 and carrinha13", (carrinha40.compareTo(carrinha13) == 0) == carrinha40.equals(carrinha13));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test103");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setVelocidadeMedia((int) '4');
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        carrinha6.setVelocidadeMedia(10);
        carrinha6.setMatricula("n/a");
        Carrinha carrinha12 = new Carrinha();
        carrinha12.setMatricula("");
        Carrinha carrinha15 = carrinha12.clone();
        carrinha12.setPrecoBase((double) 0L);
        Carrinha carrinha18 = new Carrinha();
        int i19 = carrinha18.getLugares();
        int i20 = carrinha12.compareTo((Veiculo) carrinha18);
        java.lang.String str21 = carrinha18.toString();
        Coordenada coordenada22 = carrinha18.getCoordenadas();
        Carrinha carrinha23 = new Carrinha();
        int i24 = carrinha23.getLugares();
        Coordenada coordenada25 = carrinha23.getCoordenadas();
        carrinha18.setCoordenadas(coordenada25);
        carrinha6.setCoordenadas(coordenada25);
        Carrinha carrinha28 = new Carrinha();
        carrinha28.setMatricula("");
        boolean b32 = carrinha28.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada33 = carrinha28.getCoordenadas();
        carrinha6.setCoordenadas(coordenada33);
        carrinha0.setCoordenadas(coordenada33);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha18 and carrinha6", (carrinha18.compareTo(carrinha6) == 0) == carrinha18.equals(carrinha6));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test104");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        java.lang.String str2 = carrinha0.toString();
        carrinha0.setFiabilidade(0);
        Carrinha carrinha5 = carrinha0.clone();
        Carrinha carrinha6 = new Carrinha();
        Carrinha carrinha7 = new Carrinha(carrinha6);
        Carrinha carrinha8 = new Carrinha(carrinha7);
        Carrinha carrinha9 = new Carrinha();
        Carrinha carrinha10 = new Carrinha(carrinha9);
        int i11 = carrinha7.compareTo((Veiculo) carrinha9);
        Carrinha carrinha12 = new Carrinha();
        carrinha12.setMatricula("");
        boolean b16 = carrinha12.equals((java.lang.Object) (-1.0d));
        boolean b17 = carrinha7.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha18 = new Carrinha();
        carrinha18.setMatricula("");
        Carrinha carrinha21 = carrinha18.clone();
        carrinha18.setPrecoBase((double) 0L);
        Carrinha carrinha24 = new Carrinha();
        int i25 = carrinha24.getLugares();
        int i26 = carrinha18.compareTo((Veiculo) carrinha24);
        java.lang.String str27 = carrinha24.toString();
        Coordenada coordenada28 = carrinha24.getCoordenadas();
        carrinha7.setCoordenadas(coordenada28);
        carrinha0.setCoordenadas(coordenada28);
        carrinha0.setPrecoBase(100.0d);
        Coordenada coordenada33 = carrinha0.getCoordenadas();
        Carrinha carrinha34 = new Carrinha();
        Carrinha carrinha35 = new Carrinha(carrinha34);
        Carrinha carrinha36 = new Carrinha(carrinha35);
        Carrinha carrinha37 = new Carrinha();
        Carrinha carrinha38 = new Carrinha(carrinha37);
        int i39 = carrinha35.compareTo((Veiculo) carrinha37);
        Carrinha carrinha40 = new Carrinha();
        carrinha40.setMatricula("");
        boolean b44 = carrinha40.equals((java.lang.Object) (-1.0d));
        boolean b45 = carrinha35.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha46 = new Carrinha();
        carrinha46.setMatricula("");
        Carrinha carrinha49 = carrinha46.clone();
        carrinha46.setPrecoBase((double) 0L);
        Carrinha carrinha52 = new Carrinha();
        int i53 = carrinha52.getLugares();
        int i54 = carrinha46.compareTo((Veiculo) carrinha52);
        java.lang.String str55 = carrinha52.toString();
        Coordenada coordenada56 = carrinha52.getCoordenadas();
        carrinha35.setCoordenadas(coordenada56);
        carrinha35.setVelocidadeMedia((-145));
        boolean b60 = carrinha0.equals((java.lang.Object) (-145));
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha9 and carrinha35", (carrinha9.compareTo(carrinha35) == 0) == carrinha9.equals(carrinha35));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test105");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carrinha0.getCoordenadas();
        carrinha0.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carrinha0.setFiabilidade(0);
        carrinha0.setVelocidadeMedia((int) (short) -1);
        double d12 = carrinha0.getPrecoBase();
        Carrinha carrinha13 = new Carrinha();
        Carrinha carrinha14 = new Carrinha(carrinha13);
        Carrinha carrinha15 = new Carrinha(carrinha14);
        Carrinha carrinha16 = new Carrinha();
        Carrinha carrinha17 = new Carrinha(carrinha16);
        int i18 = carrinha14.compareTo((Veiculo) carrinha16);
        Carrinha carrinha19 = new Carrinha();
        carrinha19.setMatricula("");
        boolean b23 = carrinha19.equals((java.lang.Object) (-1.0d));
        boolean b24 = carrinha14.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha25 = new Carrinha();
        carrinha25.setMatricula("");
        Carrinha carrinha28 = carrinha25.clone();
        carrinha25.setPrecoBase((double) 0L);
        Carrinha carrinha31 = new Carrinha();
        int i32 = carrinha31.getLugares();
        int i33 = carrinha25.compareTo((Veiculo) carrinha31);
        java.lang.String str34 = carrinha31.toString();
        Coordenada coordenada35 = carrinha31.getCoordenadas();
        carrinha14.setCoordenadas(coordenada35);
        carrinha14.setVelocidadeMedia((-145));
        Coordenada coordenada39 = carrinha14.getCoordenadas();
        carrinha0.setCoordenadas(coordenada39);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha17 and carrinha14", (carrinha17.compareTo(carrinha14) == 0) == carrinha17.equals(carrinha14));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test106");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        carrinha0.setMatricula("n/a");
        Carrinha carrinha6 = new Carrinha();
        carrinha6.setMatricula("");
        Carrinha carrinha9 = carrinha6.clone();
        carrinha6.setPrecoBase((double) 0L);
        Carrinha carrinha12 = new Carrinha();
        int i13 = carrinha12.getLugares();
        int i14 = carrinha6.compareTo((Veiculo) carrinha12);
        java.lang.String str15 = carrinha12.toString();
        Coordenada coordenada16 = carrinha12.getCoordenadas();
        Carrinha carrinha17 = new Carrinha();
        int i18 = carrinha17.getLugares();
        Coordenada coordenada19 = carrinha17.getCoordenadas();
        carrinha12.setCoordenadas(coordenada19);
        carrinha0.setCoordenadas(coordenada19);
        Carrinha carrinha22 = new Carrinha();
        carrinha22.setMatricula("");
        boolean b26 = carrinha22.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada27 = carrinha22.getCoordenadas();
        carrinha0.setCoordenadas(coordenada27);
        Carrinha carrinha29 = new Carrinha();
        carrinha29.setMatricula("");
        boolean b33 = carrinha29.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada34 = carrinha29.getCoordenadas();
        java.lang.String str35 = carrinha29.toString();
        double d36 = carrinha29.getPrecoBase();
        boolean b37 = carrinha0.equals((java.lang.Object) d36);
        carrinha0.setMatricula("Matrícula: hi!\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: -1\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Carrinha carrinha40 = new Carrinha();
        int i41 = carrinha40.getLugares();
        carrinha40.setVelocidadeMedia(10);
        carrinha40.setMatricula("n/a");
        Carrinha carrinha46 = new Carrinha();
        carrinha46.setMatricula("");
        Carrinha carrinha49 = carrinha46.clone();
        carrinha46.setPrecoBase((double) 0L);
        Carrinha carrinha52 = new Carrinha();
        int i53 = carrinha52.getLugares();
        int i54 = carrinha46.compareTo((Veiculo) carrinha52);
        java.lang.String str55 = carrinha52.toString();
        Coordenada coordenada56 = carrinha52.getCoordenadas();
        Carrinha carrinha57 = new Carrinha();
        int i58 = carrinha57.getLugares();
        Coordenada coordenada59 = carrinha57.getCoordenadas();
        carrinha52.setCoordenadas(coordenada59);
        carrinha40.setCoordenadas(coordenada59);
        Carrinha carrinha62 = new Carrinha();
        carrinha62.setMatricula("");
        boolean b66 = carrinha62.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada67 = carrinha62.getCoordenadas();
        carrinha40.setCoordenadas(coordenada67);
        java.lang.String str69 = carrinha40.getMatricula();
        boolean b70 = carrinha0.equals((java.lang.Object) str69);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha52 and carrinha40", (carrinha52.compareTo(carrinha40) == 0) == carrinha52.equals(carrinha40));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test107");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha(carrinha0);
        carrinha6.setPrecoBase((double) (-1.0f));
        carrinha6.setVelocidadeMedia((int) (short) 0);
        carrinha6.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Carrinha carrinha13 = new Carrinha(carrinha6);
        carrinha6.setPrecoBase(1.0d);
        Carrinha carrinha16 = new Carrinha();
        carrinha16.setMatricula("");
        boolean b20 = carrinha16.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha21 = new Carrinha(carrinha16);
        double d22 = carrinha16.getPrecoBase();
        boolean b23 = carrinha16.getOcupado();
        int i24 = carrinha16.getVelocidadeMedia();
        Carrinha carrinha25 = carrinha16.clone();
        carrinha25.setFiabilidade((int) (byte) 10);
        carrinha25.setFiabilidade((int) (short) -1);
        int i30 = carrinha6.compareTo((Veiculo) carrinha25);
        Carrinha carrinha31 = new Carrinha(carrinha25);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha6 and carrinha13", (carrinha6.compareTo(carrinha13) == 0) == carrinha6.equals(carrinha13));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test108");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        boolean b4 = carrinha0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carrinha0.getCoordenadas();
        carrinha0.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Carrinha carrinha8 = new Carrinha(carrinha0);
        carrinha0.setOcupado(false);
        Coordenada coordenada11 = carrinha0.getCoordenadas();
        java.lang.String str12 = carrinha0.toString();
        Carrinha carrinha13 = new Carrinha();
        int i14 = carrinha13.getLugares();
        carrinha13.setVelocidadeMedia(10);
        carrinha13.setMatricula("n/a");
        Carrinha carrinha19 = new Carrinha();
        carrinha19.setMatricula("");
        Carrinha carrinha22 = carrinha19.clone();
        carrinha19.setPrecoBase((double) 0L);
        Carrinha carrinha25 = new Carrinha();
        int i26 = carrinha25.getLugares();
        int i27 = carrinha19.compareTo((Veiculo) carrinha25);
        java.lang.String str28 = carrinha25.toString();
        Coordenada coordenada29 = carrinha25.getCoordenadas();
        Carrinha carrinha30 = new Carrinha();
        int i31 = carrinha30.getLugares();
        Coordenada coordenada32 = carrinha30.getCoordenadas();
        carrinha25.setCoordenadas(coordenada32);
        carrinha13.setCoordenadas(coordenada32);
        Carrinha carrinha35 = new Carrinha();
        carrinha35.setMatricula("");
        boolean b39 = carrinha35.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada40 = carrinha35.getCoordenadas();
        carrinha13.setCoordenadas(coordenada40);
        Coordenada coordenada42 = carrinha13.getCoordenadas();
        carrinha0.setCoordenadas(coordenada42);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha30 and carrinha13", (carrinha30.compareTo(carrinha13) == 0) == carrinha30.equals(carrinha13));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test109");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        Carrinha carrinha2 = new Carrinha(carrinha1);
        Carrinha carrinha3 = new Carrinha();
        Carrinha carrinha4 = new Carrinha(carrinha3);
        int i5 = carrinha1.compareTo((Veiculo) carrinha3);
        int i6 = carrinha3.getVelocidadeMedia();
        Carrinha carrinha7 = carrinha3.clone();
        int i8 = carrinha7.getFiabilidade();
        int i9 = carrinha7.getFiabilidade();
        Carrinha carrinha10 = new Carrinha(carrinha7);
        Carrinha carrinha11 = new Carrinha();
        carrinha11.setMatricula("");
        Carrinha carrinha14 = carrinha11.clone();
        Coordenada coordenada15 = carrinha14.getCoordenadas();
        Carrinha carrinha16 = new Carrinha();
        carrinha16.setMatricula("");
        Carrinha carrinha19 = carrinha16.clone();
        carrinha16.setPrecoBase((double) 0L);
        Carrinha carrinha22 = new Carrinha();
        int i23 = carrinha22.getLugares();
        int i24 = carrinha16.compareTo((Veiculo) carrinha22);
        java.lang.String str25 = carrinha22.toString();
        Coordenada coordenada26 = carrinha22.getCoordenadas();
        int i27 = carrinha14.compareTo((Veiculo) carrinha22);
        Carrinha carrinha28 = new Carrinha();
        carrinha28.setMatricula("");
        Carrinha carrinha31 = carrinha28.clone();
        carrinha28.setPrecoBase((double) 0L);
        java.lang.String str34 = carrinha28.getMatricula();
        Coordenada coordenada35 = carrinha28.getCoordenadas();
        carrinha14.setCoordenadas(coordenada35);
        carrinha14.setFiabilidade((int) (short) -1);
        int i39 = carrinha7.compareTo((Veiculo) carrinha14);
        Carrinha carrinha40 = carrinha7.clone();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha14 and carrinha11", (carrinha14.compareTo(carrinha11) == 0) == carrinha14.equals(carrinha11));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test110");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha3.setOcupado(true);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        carrinha6.setVelocidadeMedia(10);
        int i10 = carrinha3.compareTo((Veiculo) carrinha6);
        Carrinha carrinha11 = carrinha3.clone();
        int i12 = carrinha3.getLugares();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha0 and carrinha11", (carrinha0.compareTo(carrinha11) == 0) == carrinha0.equals(carrinha11));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test111");
        Carrinha carrinha0 = new Carrinha();
        Carrinha carrinha1 = new Carrinha(carrinha0);
        java.lang.String str2 = carrinha0.toString();
        carrinha0.setFiabilidade(0);
        Carrinha carrinha13 = new Carrinha();
        carrinha13.setMatricula("");
        boolean b17 = carrinha13.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada18 = carrinha13.getCoordenadas();
        carrinha13.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carrinha13.setFiabilidade(0);
        Carrinha carrinha23 = new Carrinha();
        carrinha23.setMatricula("");
        Carrinha carrinha26 = carrinha23.clone();
        carrinha23.setPrecoBase((double) 0L);
        Carrinha carrinha29 = new Carrinha(carrinha23);
        int i30 = carrinha13.compareTo((Veiculo) carrinha23);
        Carrinha carrinha31 = new Carrinha(carrinha23);
        Coordenada coordenada32 = carrinha31.getCoordenadas();
        Carrinha carrinha34 = new Carrinha((int) (byte) 0, (double) 0L, (int) (byte) 0, "n/a", coordenada32, true);
        Coordenada coordenada35 = carrinha34.getCoordenadas();
        Carrinha carrinha37 = new Carrinha(52, (double) 3, (int) (byte) 0, "hi!", coordenada35, true);
        carrinha0.setCoordenadas(coordenada35);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha1 and carrinha34", (carrinha1.compareTo(carrinha34) == 0) == carrinha1.equals(carrinha34));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test112");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        carrinha0.setMatricula("n/a");
        Carrinha carrinha6 = new Carrinha();
        carrinha6.setMatricula("");
        Carrinha carrinha9 = carrinha6.clone();
        carrinha6.setPrecoBase((double) 0L);
        Carrinha carrinha12 = new Carrinha();
        int i13 = carrinha12.getLugares();
        int i14 = carrinha6.compareTo((Veiculo) carrinha12);
        java.lang.String str15 = carrinha12.toString();
        Coordenada coordenada16 = carrinha12.getCoordenadas();
        Carrinha carrinha17 = new Carrinha();
        int i18 = carrinha17.getLugares();
        Coordenada coordenada19 = carrinha17.getCoordenadas();
        carrinha12.setCoordenadas(coordenada19);
        carrinha0.setCoordenadas(coordenada19);
        Carrinha carrinha22 = new Carrinha();
        carrinha22.setMatricula("");
        boolean b26 = carrinha22.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada27 = carrinha22.getCoordenadas();
        carrinha0.setCoordenadas(coordenada27);
        Carrinha carrinha29 = new Carrinha();
        carrinha29.setMatricula("");
        boolean b33 = carrinha29.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada34 = carrinha29.getCoordenadas();
        java.lang.String str35 = carrinha29.toString();
        double d36 = carrinha29.getPrecoBase();
        boolean b37 = carrinha0.equals((java.lang.Object) d36);
        carrinha0.setVelocidadeMedia((int) (byte) 1);
        Carrinha carrinha40 = new Carrinha();
        carrinha40.setMatricula("");
        boolean b44 = carrinha40.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada45 = carrinha40.getCoordenadas();
        carrinha40.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carrinha40.setFiabilidade(0);
        int i50 = carrinha40.getFiabilidade();
        int i51 = carrinha0.compareTo((Veiculo) carrinha40);
        java.lang.String str52 = carrinha40.getMatricula();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha17 and carrinha0", (carrinha17.compareTo(carrinha0) == 0) == carrinha17.equals(carrinha0));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test113");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        java.lang.String str2 = carrinha0.getMatricula();
        Carrinha carrinha3 = new Carrinha(carrinha0);
        carrinha0.setOcupado(true);
        java.lang.String str6 = carrinha0.toString();
        Carrinha carrinha7 = new Carrinha();
        int i8 = carrinha7.getLugares();
        java.lang.String str9 = carrinha7.getMatricula();
        Carrinha carrinha10 = new Carrinha(carrinha7);
        int i11 = carrinha7.getVelocidadeMedia();
        int i12 = carrinha0.compareTo((Veiculo) carrinha7);
        int i13 = carrinha7.getLugares();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha10 and carrinha0", (carrinha10.compareTo(carrinha0) == 0) == carrinha10.equals(carrinha0));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test114");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha3.setOcupado(true);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        carrinha6.setVelocidadeMedia(10);
        int i10 = carrinha3.compareTo((Veiculo) carrinha6);
        Coordenada coordenada11 = carrinha3.getCoordenadas();
        int i12 = carrinha3.getVelocidadeMedia();
        Carrinha carrinha17 = new Carrinha();
        carrinha17.setMatricula("");
        Carrinha carrinha20 = carrinha17.clone();
        carrinha17.setPrecoBase((double) 0L);
        Carrinha carrinha23 = new Carrinha();
        int i24 = carrinha23.getLugares();
        int i25 = carrinha17.compareTo((Veiculo) carrinha23);
        java.lang.String str26 = carrinha23.toString();
        Coordenada coordenada27 = carrinha23.getCoordenadas();
        Carrinha carrinha29 = new Carrinha((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada27, false);
        carrinha29.setPrecoBase((double) 10.0f);
        boolean b32 = carrinha3.equals((java.lang.Object) 10.0f);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha23 and carrinha6", (carrinha23.compareTo(carrinha6) == 0) == carrinha23.equals(carrinha6));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test115");
        Carrinha carrinha8 = new Carrinha();
        carrinha8.setMatricula("");
        boolean b12 = carrinha8.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada13 = carrinha8.getCoordenadas();
        boolean b14 = carrinha8.getOcupado();
        java.lang.String str15 = carrinha8.getMatricula();
        Carrinha carrinha20 = new Carrinha();
        carrinha20.setMatricula("");
        Carrinha carrinha23 = carrinha20.clone();
        carrinha20.setPrecoBase((double) 0L);
        Carrinha carrinha26 = new Carrinha();
        int i27 = carrinha26.getLugares();
        int i28 = carrinha20.compareTo((Veiculo) carrinha26);
        java.lang.String str29 = carrinha26.toString();
        Coordenada coordenada30 = carrinha26.getCoordenadas();
        Carrinha carrinha32 = new Carrinha((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada30, false);
        carrinha8.setCoordenadas(coordenada30);
        Carrinha carrinha35 = new Carrinha(32, (double) (short) 1, (int) (byte) 1, "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada30, true);
        Carrinha carrinha37 = new Carrinha(9, (-1.0d), (int) ' ', "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 10.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada30, true);
        Carrinha carrinha38 = new Carrinha();
        Carrinha carrinha39 = new Carrinha(carrinha38);
        carrinha38.setPrecoBase((double) (byte) 10);
        carrinha38.setFiabilidade((-3));
        boolean b44 = carrinha37.equals((java.lang.Object) (-3));
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha39 and carrinha38", (carrinha39.compareTo(carrinha38) == 0) == carrinha39.equals(carrinha38));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test116");
        Carrinha carrinha8 = new Carrinha();
        carrinha8.setMatricula("");
        Carrinha carrinha11 = carrinha8.clone();
        carrinha8.setPrecoBase((double) 0L);
        Carrinha carrinha14 = new Carrinha();
        int i15 = carrinha14.getLugares();
        int i16 = carrinha8.compareTo((Veiculo) carrinha14);
        java.lang.String str17 = carrinha14.toString();
        Coordenada coordenada18 = carrinha14.getCoordenadas();
        Carrinha carrinha20 = new Carrinha((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, false);
        Carrinha carrinha22 = new Carrinha((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, true);
        Carrinha carrinha23 = new Carrinha();
        carrinha23.setVelocidadeMedia((int) ' ');
        java.lang.String str26 = carrinha23.toString();
        boolean b27 = carrinha22.equals((java.lang.Object) carrinha23);
        carrinha23.setVelocidadeMedia(32);
        Coordenada coordenada30 = carrinha23.getCoordenadas();
        Carrinha carrinha31 = new Carrinha();
        carrinha31.setMatricula("");
        boolean b35 = carrinha31.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada36 = carrinha31.getCoordenadas();
        carrinha31.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Carrinha carrinha39 = new Carrinha(carrinha31);
        boolean b40 = carrinha23.equals((java.lang.Object) carrinha39);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha20 and carrinha31", (carrinha20.compareTo(carrinha31) == 0) == carrinha20.equals(carrinha31));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test117");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        java.lang.String str3 = carrinha0.toString();
        Carrinha carrinha4 = new Carrinha();
        Carrinha carrinha5 = new Carrinha(carrinha4);
        java.lang.String str6 = carrinha4.toString();
        carrinha4.setFiabilidade(0);
        Carrinha carrinha9 = carrinha4.clone();
        Carrinha carrinha10 = new Carrinha();
        Carrinha carrinha11 = new Carrinha(carrinha10);
        Carrinha carrinha12 = new Carrinha(carrinha11);
        Carrinha carrinha13 = new Carrinha();
        Carrinha carrinha14 = new Carrinha(carrinha13);
        int i15 = carrinha11.compareTo((Veiculo) carrinha13);
        Carrinha carrinha16 = new Carrinha();
        carrinha16.setMatricula("");
        boolean b20 = carrinha16.equals((java.lang.Object) (-1.0d));
        boolean b21 = carrinha11.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha22 = new Carrinha();
        carrinha22.setMatricula("");
        Carrinha carrinha25 = carrinha22.clone();
        carrinha22.setPrecoBase((double) 0L);
        Carrinha carrinha28 = new Carrinha();
        int i29 = carrinha28.getLugares();
        int i30 = carrinha22.compareTo((Veiculo) carrinha28);
        java.lang.String str31 = carrinha28.toString();
        Coordenada coordenada32 = carrinha28.getCoordenadas();
        carrinha11.setCoordenadas(coordenada32);
        carrinha4.setCoordenadas(coordenada32);
        carrinha0.setCoordenadas(coordenada32);
        Carrinha carrinha36 = new Carrinha();
        Carrinha carrinha37 = new Carrinha(carrinha36);
        java.lang.String str38 = carrinha36.toString();
        carrinha36.setFiabilidade(0);
        int i41 = carrinha36.getFiabilidade();
        Carrinha carrinha42 = new Carrinha(carrinha36);
        Carrinha carrinha43 = carrinha36.clone();
        carrinha36.setOcupado(false);
        Carrinha carrinha46 = new Carrinha();
        carrinha46.setMatricula("");
        Carrinha carrinha49 = carrinha46.clone();
        carrinha46.setPrecoBase((double) 0L);
        java.lang.String str52 = carrinha46.getMatricula();
        Coordenada coordenada53 = carrinha46.getCoordenadas();
        carrinha36.setCoordenadas(coordenada53);
        carrinha0.setCoordenadas(coordenada53);
        Carrinha carrinha56 = new Carrinha();
        int i57 = carrinha56.getLugares();
        carrinha56.setVelocidadeMedia(10);
        Carrinha carrinha60 = new Carrinha(carrinha56);
        int i61 = carrinha56.getVelocidadeMedia();
        carrinha56.setMatricula("");
        int i64 = carrinha56.getFiabilidade();
        int i65 = carrinha56.getVelocidadeMedia();
        carrinha56.setVelocidadeMedia((-142));
        boolean b68 = carrinha0.equals((java.lang.Object) (-142));
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha14 and carrinha60", (carrinha14.compareTo(carrinha60) == 0) == carrinha14.equals(carrinha60));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test118");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = new Carrinha();
        int i4 = carrinha3.getLugares();
        java.lang.String str5 = carrinha3.getMatricula();
        Carrinha carrinha6 = new Carrinha(carrinha3);
        carrinha6.setVelocidadeMedia((int) '4');
        int i9 = carrinha0.compareTo((Veiculo) carrinha6);
        Carrinha carrinha10 = new Carrinha();
        int i11 = carrinha10.getLugares();
        Coordenada coordenada12 = carrinha10.getCoordenadas();
        Carrinha carrinha13 = new Carrinha();
        Carrinha carrinha14 = new Carrinha(carrinha13);
        java.lang.String str15 = carrinha13.toString();
        carrinha13.setFiabilidade(0);
        Carrinha carrinha18 = carrinha13.clone();
        int i19 = carrinha13.getLugares();
        Carrinha carrinha24 = new Carrinha();
        Carrinha carrinha25 = new Carrinha(carrinha24);
        Carrinha carrinha26 = new Carrinha(carrinha25);
        Carrinha carrinha27 = new Carrinha();
        Carrinha carrinha28 = new Carrinha(carrinha27);
        int i29 = carrinha25.compareTo((Veiculo) carrinha27);
        Carrinha carrinha30 = new Carrinha();
        carrinha30.setMatricula("");
        boolean b34 = carrinha30.equals((java.lang.Object) (-1.0d));
        boolean b35 = carrinha25.equals((java.lang.Object) (-1.0d));
        Carrinha carrinha36 = new Carrinha();
        carrinha36.setMatricula("");
        Carrinha carrinha39 = carrinha36.clone();
        carrinha36.setPrecoBase((double) 0L);
        Carrinha carrinha42 = new Carrinha();
        int i43 = carrinha42.getLugares();
        int i44 = carrinha36.compareTo((Veiculo) carrinha42);
        java.lang.String str45 = carrinha42.toString();
        Coordenada coordenada46 = carrinha42.getCoordenadas();
        carrinha25.setCoordenadas(coordenada46);
        Carrinha carrinha49 = new Carrinha((-1), 10.0d, (int) (byte) 1, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada46, true);
        carrinha13.setCoordenadas(coordenada46);
        int i51 = carrinha10.compareTo((Veiculo) carrinha13);
        int i52 = carrinha10.getFiabilidade();
        Coordenada coordenada53 = carrinha10.getCoordenadas();
        carrinha0.setCoordenadas(coordenada53);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha14 and carrinha6", (carrinha14.compareTo(carrinha6) == 0) == carrinha14.equals(carrinha6));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test119");
        Carrinha carrinha0 = new Carrinha();
        carrinha0.setMatricula("");
        Carrinha carrinha3 = carrinha0.clone();
        carrinha0.setPrecoBase((double) 0L);
        Carrinha carrinha6 = new Carrinha();
        int i7 = carrinha6.getLugares();
        int i8 = carrinha0.compareTo((Veiculo) carrinha6);
        java.lang.String str9 = carrinha6.toString();
        int i10 = carrinha6.getFiabilidade();
        Carrinha carrinha11 = new Carrinha();
        Carrinha carrinha12 = new Carrinha(carrinha11);
        java.lang.String str13 = carrinha11.toString();
        carrinha11.setFiabilidade(0);
        Carrinha carrinha16 = carrinha11.clone();
        int i17 = carrinha16.getFiabilidade();
        Coordenada coordenada18 = carrinha16.getCoordenadas();
        carrinha6.setCoordenadas(coordenada18);
        Carrinha carrinha20 = new Carrinha();
        carrinha20.setMatricula("");
        Carrinha carrinha23 = carrinha20.clone();
        carrinha20.setPrecoBase((double) 0L);
        Carrinha carrinha26 = new Carrinha();
        int i27 = carrinha26.getLugares();
        int i28 = carrinha20.compareTo((Veiculo) carrinha26);
        int i29 = carrinha26.getFiabilidade();
        Carrinha carrinha30 = carrinha26.clone();
        Coordenada coordenada31 = carrinha30.getCoordenadas();
        boolean b32 = carrinha6.equals((java.lang.Object) carrinha30);
        Carrinha carrinha33 = carrinha30.clone();
        Carrinha carrinha38 = new Carrinha();
        carrinha38.setMatricula("");
        Carrinha carrinha41 = carrinha38.clone();
        carrinha38.setPrecoBase((double) 0L);
        Carrinha carrinha44 = new Carrinha();
        int i45 = carrinha44.getLugares();
        int i46 = carrinha38.compareTo((Veiculo) carrinha44);
        java.lang.String str47 = carrinha44.toString();
        Coordenada coordenada48 = carrinha44.getCoordenadas();
        Carrinha carrinha50 = new Carrinha(10, (double) (short) -1, (int) (byte) 1, "", coordenada48, false);
        carrinha30.setCoordenadas(coordenada48);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha23 and carrinha50", (carrinha23.compareTo(carrinha50) == 0) == carrinha23.equals(carrinha50));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test120");
        Carrinha carrinha0 = new Carrinha();
        int i1 = carrinha0.getLugares();
        carrinha0.setVelocidadeMedia(10);
        Carrinha carrinha4 = new Carrinha(carrinha0);
        int i5 = carrinha0.getVelocidadeMedia();
        java.lang.String str6 = carrinha0.getMatricula();
        carrinha0.setVelocidadeMedia((int) (byte) 1);
        carrinha0.setOcupado(false);
        carrinha0.setOcupado(false);
        Carrinha carrinha13 = new Carrinha();
        carrinha13.setMatricula("");
        Carrinha carrinha16 = carrinha13.clone();
        carrinha13.setPrecoBase((double) 0L);
        Carrinha carrinha19 = new Carrinha();
        int i20 = carrinha19.getLugares();
        int i21 = carrinha13.compareTo((Veiculo) carrinha19);
        java.lang.String str22 = carrinha19.toString();
        int i23 = carrinha19.getVelocidadeMedia();
        java.lang.String str24 = carrinha19.getMatricula();
        java.lang.String str25 = carrinha19.toString();
        boolean b26 = carrinha0.equals((java.lang.Object) carrinha19);
        carrinha19.setPrecoBase((double) ' ');
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carrinha0 and carrinha4", (carrinha0.compareTo(carrinha4) == 0) == carrinha0.equals(carrinha4));
    }
}

