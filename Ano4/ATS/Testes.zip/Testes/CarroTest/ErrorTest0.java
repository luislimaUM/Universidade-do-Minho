import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ErrorTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test001");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro7 = new Carro();
        carro7.setMatricula("");
        Carro carro10 = carro7.clone();
        carro7.setPrecoBase((double) 0L);
        Carro carro13 = new Carro();
        int i14 = carro13.getLugares();
        int i15 = carro7.compareTo((Veiculo) carro13);
        java.lang.String str16 = carro13.toString();
        Coordenada coordenada17 = carro13.getCoordenadas();
        Carro carro19 = new Carro((int) ' ', (double) 100.0f, (int) (byte) -1, "", coordenada17, false);
        carro0.setCoordenadas(coordenada17);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro10 and carro19", (carro10.compareTo(carro19) == 0) == carro10.equals(carro19));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test002");
        Carro carro8 = new Carro();
        carro8.setMatricula("");
        Carro carro11 = carro8.clone();
        carro8.setPrecoBase((double) 0L);
        Carro carro14 = new Carro();
        int i15 = carro14.getLugares();
        int i16 = carro8.compareTo((Veiculo) carro14);
        java.lang.String str17 = carro14.toString();
        Coordenada coordenada18 = carro14.getCoordenadas();
        Carro carro20 = new Carro((int) ' ', (double) 100.0f, (int) (byte) -1, "", coordenada18, false);
        Carro carro22 = new Carro(100, (double) 10, (int) (short) 100, "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, true);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro11 and carro20", (carro11.compareTo(carro20) == 0) == carro11.equals(carro20));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test003");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro3.setOcupado(true);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        carro6.setVelocidadeMedia(10);
        int i10 = carro3.compareTo((Veiculo) carro6);
        Carro carro15 = new Carro();
        carro15.setMatricula("");
        Carro carro18 = carro15.clone();
        carro15.setPrecoBase((double) 0L);
        Carro carro21 = new Carro();
        int i22 = carro21.getLugares();
        int i23 = carro15.compareTo((Veiculo) carro21);
        java.lang.String str24 = carro21.toString();
        Coordenada coordenada25 = carro21.getCoordenadas();
        Carro carro27 = new Carro((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada25, false);
        carro3.setCoordenadas(coordenada25);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro21 and carro6", (carro21.compareTo(carro6) == 0) == carro21.equals(carro6));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test004");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro3.setOcupado(true);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        carro6.setVelocidadeMedia(10);
        int i10 = carro3.compareTo((Veiculo) carro6);
        Carro carro11 = new Carro();
        carro11.setMatricula("");
        Carro carro14 = carro11.clone();
        carro11.setPrecoBase((double) 0L);
        Carro carro17 = new Carro();
        int i18 = carro17.getLugares();
        int i19 = carro11.compareTo((Veiculo) carro17);
        java.lang.String str20 = carro17.toString();
        Coordenada coordenada21 = carro17.getCoordenadas();
        carro3.setCoordenadas(coordenada21);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro6 and carro17", (carro6.compareTo(carro17) == 0) == carro6.equals(carro17));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test005");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Carro carro5 = new Carro(carro0);
        double d6 = carro0.getPrecoBase();
        boolean b7 = carro0.getOcupado();
        int i8 = carro0.getVelocidadeMedia();
        Carro carro9 = new Carro();
        carro9.setMatricula("");
        Carro carro12 = carro9.clone();
        carro12.setOcupado(true);
        Carro carro15 = new Carro();
        int i16 = carro15.getLugares();
        carro15.setVelocidadeMedia(10);
        int i19 = carro12.compareTo((Veiculo) carro15);
        Coordenada coordenada20 = carro12.getCoordenadas();
        boolean b21 = carro0.equals((java.lang.Object) coordenada20);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro5 and carro12", (carro5.compareTo(carro12) == 0) == carro5.equals(carro12));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test006");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        Carro carro4 = new Carro();
        carro4.setMatricula("");
        Carro carro7 = carro4.clone();
        carro7.setOcupado(true);
        Carro carro10 = new Carro();
        int i11 = carro10.getLugares();
        carro10.setVelocidadeMedia(10);
        int i14 = carro7.compareTo((Veiculo) carro10);
        Carro carro15 = carro7.clone();
        int i16 = carro3.compareTo((Veiculo) carro15);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro7 and carro4", (carro7.compareTo(carro4) == 0) == carro7.equals(carro4));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test007");
        Carro carro4 = new Carro();
        int i5 = carro4.getLugares();
        carro4.setVelocidadeMedia(10);
        carro4.setMatricula("n/a");
        Carro carro10 = new Carro();
        carro10.setMatricula("");
        Carro carro13 = carro10.clone();
        carro10.setPrecoBase((double) 0L);
        Carro carro16 = new Carro();
        int i17 = carro16.getLugares();
        int i18 = carro10.compareTo((Veiculo) carro16);
        java.lang.String str19 = carro16.toString();
        Coordenada coordenada20 = carro16.getCoordenadas();
        Carro carro21 = new Carro();
        int i22 = carro21.getLugares();
        Coordenada coordenada23 = carro21.getCoordenadas();
        carro16.setCoordenadas(coordenada23);
        carro4.setCoordenadas(coordenada23);
        Carro carro27 = new Carro((int) (byte) -1, (double) 1.0f, (int) '#', "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada23, false);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro21 and carro4", (carro21.compareTo(carro4) == 0) == carro21.equals(carro4));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test008");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        java.lang.String str9 = carro6.toString();
        Coordenada coordenada10 = carro6.getCoordenadas();
        Carro carro15 = new Carro();
        carro15.setMatricula("");
        Carro carro18 = carro15.clone();
        carro15.setPrecoBase((double) 0L);
        Carro carro21 = new Carro();
        int i22 = carro21.getLugares();
        int i23 = carro15.compareTo((Veiculo) carro21);
        java.lang.String str24 = carro21.toString();
        Coordenada coordenada25 = carro21.getCoordenadas();
        Carro carro27 = new Carro((int) (byte) 100, (double) '#', (int) (short) 0, "", coordenada25, false);
        carro6.setCoordenadas(coordenada25);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro27 and carro0", (carro27.compareTo(carro0) == 0) == carro27.equals(carro0));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test009");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        int i9 = carro6.getFiabilidade();
        Carro carro10 = carro6.clone();
        Carro carro11 = new Carro();
        int i12 = carro11.getLugares();
        carro11.setVelocidadeMedia(10);
        Carro carro15 = new Carro(carro11);
        Coordenada coordenada16 = carro11.getCoordenadas();
        carro10.setCoordenadas(coordenada16);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro11 and carro6", (carro11.compareTo(carro6) == 0) == carro11.equals(carro6));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test010");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        Carro carro4 = new Carro(carro3);
        int i5 = carro1.compareTo((Veiculo) carro3);
        carro1.setVelocidadeMedia((int) (short) 100);
        Carro carro8 = new Carro();
        int i9 = carro8.getLugares();
        carro8.setVelocidadeMedia(10);
        carro8.setMatricula("n/a");
        Carro carro14 = new Carro();
        carro14.setMatricula("");
        Carro carro17 = carro14.clone();
        carro14.setPrecoBase((double) 0L);
        Carro carro20 = new Carro();
        int i21 = carro20.getLugares();
        int i22 = carro14.compareTo((Veiculo) carro20);
        java.lang.String str23 = carro20.toString();
        Coordenada coordenada24 = carro20.getCoordenadas();
        Carro carro25 = new Carro();
        int i26 = carro25.getLugares();
        Coordenada coordenada27 = carro25.getCoordenadas();
        carro20.setCoordenadas(coordenada27);
        carro8.setCoordenadas(coordenada27);
        Carro carro30 = carro8.clone();
        int i31 = carro1.compareTo((Veiculo) carro8);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro4 and carro30", (carro4.compareTo(carro30) == 0) == carro4.equals(carro30));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test011");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro3.setOcupado(true);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        carro6.setVelocidadeMedia(10);
        int i10 = carro3.compareTo((Veiculo) carro6);
        Carro carro11 = carro3.clone();
        double d12 = carro3.getPrecoBase();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro0 and carro11", (carro0.compareTo(carro11) == 0) == carro0.equals(carro11));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test012");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro3.setOcupado(true);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        carro6.setVelocidadeMedia(10);
        int i10 = carro3.compareTo((Veiculo) carro6);
        Carro carro11 = carro3.clone();
        carro3.setOcupado(false);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro11 and carro0", (carro11.compareTo(carro0) == 0) == carro11.equals(carro0));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test013");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        int i4 = carro3.getLugares();
        boolean b5 = carro2.equals((java.lang.Object) carro3);
        Carro carro6 = carro3.clone();
        Carro carro7 = new Carro();
        carro7.setMatricula("");
        Carro carro10 = carro7.clone();
        carro7.setPrecoBase((double) 0L);
        Carro carro13 = new Carro();
        int i14 = carro13.getLugares();
        int i15 = carro7.compareTo((Veiculo) carro13);
        java.lang.String str16 = carro13.toString();
        int i17 = carro13.getFiabilidade();
        carro13.setPrecoBase(10.0d);
        Coordenada coordenada20 = carro13.getCoordenadas();
        carro3.setCoordenadas(coordenada20);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro0 and carro13", (carro0.compareTo(carro13) == 0) == carro0.equals(carro13));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test014");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carro0.getCoordenadas();
        carro0.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carro0.setFiabilidade(0);
        Carro carro10 = new Carro();
        carro10.setMatricula("");
        Carro carro13 = carro10.clone();
        carro10.setPrecoBase((double) 0L);
        Carro carro16 = new Carro(carro10);
        carro16.setPrecoBase((double) (-1.0f));
        carro16.setVelocidadeMedia((int) (short) 0);
        boolean b21 = carro0.equals((java.lang.Object) (short) 0);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro10 and carro16", (carro10.compareTo(carro16) == 0) == carro10.equals(carro16));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test015");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        java.lang.String str2 = carro0.toString();
        carro0.setFiabilidade(0);
        Carro carro9 = new Carro();
        carro9.setMatricula("");
        Carro carro12 = carro9.clone();
        Coordenada coordenada13 = carro12.getCoordenadas();
        Carro carro15 = new Carro((int) (byte) -1, (double) 0, (int) (short) 1, "", coordenada13, false);
        carro0.setCoordenadas(coordenada13);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro12 and carro15", (carro12.compareTo(carro15) == 0) == carro12.equals(carro15));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test016");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        java.lang.String str9 = carro6.toString();
        int i10 = carro6.getFiabilidade();
        carro6.setPrecoBase(10.0d);
        int i13 = carro6.getVelocidadeMedia();
        Carro carro14 = new Carro(carro6);
        Carro carro15 = new Carro();
        Carro carro16 = new Carro(carro15);
        Carro carro17 = new Carro(carro16);
        Carro carro18 = new Carro();
        int i19 = carro18.getLugares();
        boolean b20 = carro17.equals((java.lang.Object) carro18);
        Carro carro21 = carro18.clone();
        carro21.setVelocidadeMedia((int) (short) 0);
        int i24 = carro14.compareTo((Veiculo) carro21);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro6 and carro15", (carro6.compareTo(carro15) == 0) == carro6.equals(carro15));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test017");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro3.setOcupado(true);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        carro6.setVelocidadeMedia(10);
        int i10 = carro3.compareTo((Veiculo) carro6);
        carro6.setPrecoBase((double) 0L);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro3 and carro0", (carro3.compareTo(carro0) == 0) == carro3.equals(carro0));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test018");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        Carro carro8 = new Carro();
        carro8.setMatricula("");
        Carro carro11 = carro8.clone();
        carro8.setPrecoBase((double) 0L);
        Carro carro14 = new Carro();
        int i15 = carro14.getLugares();
        int i16 = carro8.compareTo((Veiculo) carro14);
        java.lang.String str17 = carro14.toString();
        Coordenada coordenada18 = carro14.getCoordenadas();
        Carro carro20 = new Carro((int) ' ', (double) 100.0f, (int) (byte) -1, "", coordenada18, false);
        boolean b21 = carro3.equals((java.lang.Object) false);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro11 and carro20", (carro11.compareTo(carro20) == 0) == carro11.equals(carro20));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test019");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carro0.getCoordenadas();
        java.lang.String str6 = carro0.getMatricula();
        Carro carro11 = new Carro();
        carro11.setMatricula("");
        Carro carro14 = carro11.clone();
        carro11.setPrecoBase((double) 0L);
        Carro carro17 = new Carro();
        int i18 = carro17.getLugares();
        int i19 = carro11.compareTo((Veiculo) carro17);
        java.lang.String str20 = carro17.toString();
        Coordenada coordenada21 = carro17.getCoordenadas();
        Carro carro23 = new Carro((int) (byte) -1, 0.0d, (int) 'a', "", coordenada21, true);
        int i24 = carro0.compareTo((Veiculo) carro23);
        double d25 = carro0.getPrecoBase();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro14 and carro23", (carro14.compareTo(carro23) == 0) == carro14.equals(carro23));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test020");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        Carro carro9 = new Carro(carro6);
        Carro carro10 = new Carro();
        Carro carro11 = new Carro(carro10);
        Carro carro12 = new Carro(carro11);
        Carro carro13 = new Carro();
        Carro carro14 = new Carro(carro13);
        int i15 = carro11.compareTo((Veiculo) carro13);
        int i16 = carro13.getVelocidadeMedia();
        int i17 = carro9.compareTo((Veiculo) carro13);
        Carro carro18 = new Carro();
        carro18.setMatricula("");
        Carro carro21 = carro18.clone();
        carro21.setOcupado(true);
        Carro carro24 = new Carro();
        int i25 = carro24.getLugares();
        carro24.setVelocidadeMedia(10);
        int i28 = carro21.compareTo((Veiculo) carro24);
        Coordenada coordenada29 = carro21.getCoordenadas();
        carro9.setCoordenadas(coordenada29);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro6 and carro24", (carro6.compareTo(carro24) == 0) == carro6.equals(carro24));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test021");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro3.setOcupado(true);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        carro6.setVelocidadeMedia(10);
        int i10 = carro3.compareTo((Veiculo) carro6);
        Carro carro11 = carro6.clone();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro0 and carro3", (carro0.compareTo(carro3) == 0) == carro0.equals(carro3));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test022");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        java.lang.String str9 = carro6.toString();
        Coordenada coordenada10 = carro6.getCoordenadas();
        Carro carro11 = new Carro();
        int i12 = carro11.getLugares();
        Coordenada coordenada13 = carro11.getCoordenadas();
        carro6.setCoordenadas(coordenada13);
        Carro carro15 = new Carro(carro6);
        Carro carro16 = new Carro();
        int i17 = carro16.getLugares();
        carro16.setVelocidadeMedia(10);
        Carro carro20 = new Carro(carro16);
        int i21 = carro16.getVelocidadeMedia();
        java.lang.String str22 = carro16.getMatricula();
        carro16.setVelocidadeMedia((int) (byte) 1);
        Carro carro25 = new Carro(carro16);
        int i26 = carro6.compareTo((Veiculo) carro16);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro11 and carro20", (carro11.compareTo(carro20) == 0) == carro11.equals(carro20));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test023");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        carro0.setMatricula("n/a");
        Carro carro6 = new Carro();
        carro6.setMatricula("");
        Carro carro9 = carro6.clone();
        carro6.setPrecoBase((double) 0L);
        Carro carro12 = new Carro();
        int i13 = carro12.getLugares();
        int i14 = carro6.compareTo((Veiculo) carro12);
        java.lang.String str15 = carro12.toString();
        Coordenada coordenada16 = carro12.getCoordenadas();
        Carro carro17 = new Carro();
        int i18 = carro17.getLugares();
        Coordenada coordenada19 = carro17.getCoordenadas();
        carro12.setCoordenadas(coordenada19);
        carro0.setCoordenadas(coordenada19);
        Carro carro22 = carro0.clone();
        Coordenada coordenada23 = carro22.getCoordenadas();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro17 and carro0", (carro17.compareTo(carro0) == 0) == carro17.equals(carro0));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test024");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        Carro carro8 = new Carro();
        carro8.setMatricula("");
        Carro carro11 = carro8.clone();
        carro8.setPrecoBase((double) 0L);
        Carro carro14 = new Carro();
        int i15 = carro14.getLugares();
        int i16 = carro8.compareTo((Veiculo) carro14);
        java.lang.String str17 = carro14.toString();
        Coordenada coordenada18 = carro14.getCoordenadas();
        Carro carro20 = new Carro((int) (byte) 100, (double) '#', (int) (short) 0, "", coordenada18, false);
        carro0.setCoordenadas(coordenada18);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro3 and carro20", (carro3.compareTo(carro20) == 0) == carro3.equals(carro20));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test025");
        Carro carro8 = new Carro();
        carro8.setMatricula("");
        Carro carro11 = carro8.clone();
        carro8.setPrecoBase((double) 0L);
        Carro carro14 = new Carro();
        int i15 = carro14.getLugares();
        int i16 = carro8.compareTo((Veiculo) carro14);
        java.lang.String str17 = carro14.toString();
        Coordenada coordenada18 = carro14.getCoordenadas();
        Carro carro20 = new Carro((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, false);
        Carro carro22 = new Carro((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, true);
        Carro carro23 = new Carro();
        carro23.setVelocidadeMedia((int) ' ');
        java.lang.String str26 = carro23.toString();
        boolean b27 = carro22.equals((java.lang.Object) carro23);
        carro22.setFiabilidade(1);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro14 and carro23", (carro14.compareTo(carro23) == 0) == carro14.equals(carro23));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test026");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        Carro carro4 = carro0.clone();
        int i5 = carro4.getLugares();
        Carro carro6 = new Carro();
        Carro carro7 = new Carro(carro6);
        Carro carro8 = new Carro(carro7);
        Carro carro9 = new Carro();
        Carro carro10 = new Carro(carro9);
        int i11 = carro7.compareTo((Veiculo) carro9);
        Carro carro12 = new Carro();
        carro12.setMatricula("");
        boolean b16 = carro12.equals((java.lang.Object) (-1.0d));
        boolean b17 = carro7.equals((java.lang.Object) (-1.0d));
        int i18 = carro4.compareTo((Veiculo) carro7);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro10 and carro0", (carro10.compareTo(carro0) == 0) == carro10.equals(carro0));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test027");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        int i2 = carro1.getFiabilidade();
        Carro carro3 = new Carro();
        carro3.setMatricula("");
        boolean b7 = carro3.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada8 = carro3.getCoordenadas();
        int i9 = carro3.getVelocidadeMedia();
        Carro carro10 = new Carro();
        carro10.setMatricula("");
        Carro carro13 = carro10.clone();
        carro13.setOcupado(true);
        boolean b16 = carro3.equals((java.lang.Object) carro13);
        int i17 = carro1.compareTo((Veiculo) carro3);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro13 and carro10", (carro13.compareTo(carro10) == 0) == carro13.equals(carro10));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test028");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        java.lang.String str2 = carro0.getMatricula();
        Carro carro3 = new Carro(carro0);
        carro0.setOcupado(true);
        Carro carro6 = new Carro();
        carro6.setMatricula("");
        Carro carro9 = carro6.clone();
        carro6.setPrecoBase((double) 0L);
        Carro carro12 = new Carro();
        int i13 = carro12.getLugares();
        int i14 = carro6.compareTo((Veiculo) carro12);
        java.lang.String str15 = carro12.toString();
        int i16 = carro12.getFiabilidade();
        carro12.setPrecoBase(10.0d);
        Carro carro19 = carro12.clone();
        boolean b20 = carro0.equals((java.lang.Object) carro19);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro3 and carro12", (carro3.compareTo(carro12) == 0) == carro3.equals(carro12));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test029");
        Carro carro4 = new Carro();
        Carro carro5 = new Carro(carro4);
        Carro carro6 = new Carro(carro5);
        Carro carro7 = new Carro();
        int i8 = carro7.getLugares();
        boolean b9 = carro6.equals((java.lang.Object) carro7);
        carro7.setOcupado(true);
        Coordenada coordenada12 = carro7.getCoordenadas();
        Carro carro14 = new Carro((int) (short) 100, (double) (-1L), (int) (short) 10, "n/a", coordenada12, false);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro4 and carro7", (carro4.compareTo(carro7) == 0) == carro4.equals(carro7));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test030");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        Carro carro4 = new Carro(carro0);
        int i5 = carro0.getVelocidadeMedia();
        carro0.setMatricula("");
        Carro carro12 = new Carro();
        carro12.setMatricula("");
        boolean b16 = carro12.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada17 = carro12.getCoordenadas();
        carro12.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carro12.setFiabilidade(0);
        Carro carro22 = new Carro();
        carro22.setMatricula("");
        Carro carro25 = carro22.clone();
        carro22.setPrecoBase((double) 0L);
        Carro carro28 = new Carro(carro22);
        int i29 = carro12.compareTo((Veiculo) carro22);
        Carro carro30 = new Carro(carro22);
        Coordenada coordenada31 = carro30.getCoordenadas();
        Carro carro33 = new Carro((int) (byte) 0, (double) 0L, (int) (byte) 0, "n/a", coordenada31, true);
        carro0.setCoordenadas(coordenada31);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro4 and carro33", (carro4.compareTo(carro33) == 0) == carro4.equals(carro33));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test031");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        carro0.setMatricula("n/a");
        Carro carro6 = new Carro();
        carro6.setMatricula("");
        Carro carro9 = carro6.clone();
        carro6.setPrecoBase((double) 0L);
        Carro carro12 = new Carro();
        int i13 = carro12.getLugares();
        int i14 = carro6.compareTo((Veiculo) carro12);
        java.lang.String str15 = carro12.toString();
        Coordenada coordenada16 = carro12.getCoordenadas();
        Carro carro17 = new Carro();
        int i18 = carro17.getLugares();
        Coordenada coordenada19 = carro17.getCoordenadas();
        carro12.setCoordenadas(coordenada19);
        carro0.setCoordenadas(coordenada19);
        Carro carro22 = carro0.clone();
        carro0.setVelocidadeMedia(4);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro12 and carro22", (carro12.compareTo(carro22) == 0) == carro12.equals(carro22));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test032");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        java.lang.String str9 = carro6.toString();
        int i10 = carro6.getFiabilidade();
        carro6.setPrecoBase(10.0d);
        int i13 = carro6.getVelocidadeMedia();
        Carro carro14 = new Carro(carro6);
        carro6.setVelocidadeMedia(1);
        Carro carro17 = new Carro();
        int i18 = carro17.getLugares();
        carro17.setVelocidadeMedia(10);
        carro17.setMatricula("n/a");
        carro17.setPrecoBase((double) (-1.0f));
        boolean b25 = carro6.equals((java.lang.Object) carro17);
        double d26 = carro6.getPrecoBase();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro14 and carro17", (carro14.compareTo(carro17) == 0) == carro14.equals(carro17));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test033");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carro0.getCoordenadas();
        java.lang.String str6 = carro0.getMatricula();
        Carro carro11 = new Carro();
        carro11.setMatricula("");
        Carro carro14 = carro11.clone();
        carro11.setPrecoBase((double) 0L);
        Carro carro17 = new Carro();
        int i18 = carro17.getLugares();
        int i19 = carro11.compareTo((Veiculo) carro17);
        java.lang.String str20 = carro17.toString();
        Coordenada coordenada21 = carro17.getCoordenadas();
        Carro carro23 = new Carro((int) (byte) -1, 0.0d, (int) 'a', "", coordenada21, true);
        int i24 = carro0.compareTo((Veiculo) carro23);
        java.lang.String str25 = carro0.getMatricula();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro14 and carro23", (carro14.compareTo(carro23) == 0) == carro14.equals(carro23));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test034");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carro0.getCoordenadas();
        int i6 = carro0.getVelocidadeMedia();
        Carro carro7 = new Carro();
        carro7.setMatricula("");
        Carro carro10 = carro7.clone();
        carro10.setOcupado(true);
        boolean b13 = carro0.equals((java.lang.Object) carro10);
        int i14 = carro0.getVelocidadeMedia();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro7 and carro10", (carro7.compareTo(carro10) == 0) == carro7.equals(carro10));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test035");
        Carro carro8 = new Carro();
        carro8.setMatricula("");
        Carro carro11 = carro8.clone();
        carro8.setPrecoBase((double) 0L);
        Carro carro14 = new Carro();
        int i15 = carro14.getLugares();
        int i16 = carro8.compareTo((Veiculo) carro14);
        java.lang.String str17 = carro14.toString();
        Coordenada coordenada18 = carro14.getCoordenadas();
        Carro carro20 = new Carro((int) (byte) 100, (double) '#', (int) (short) 0, "", coordenada18, false);
        Carro carro22 = new Carro(0, (-1.0d), 4, "hi!", coordenada18, false);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro8 and carro20", (carro8.compareTo(carro20) == 0) == carro8.equals(carro20));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test036");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        Carro carro4 = new Carro(carro3);
        int i5 = carro1.compareTo((Veiculo) carro3);
        Carro carro10 = new Carro();
        carro10.setMatricula("");
        Carro carro13 = carro10.clone();
        carro10.setPrecoBase((double) 0L);
        Carro carro16 = new Carro();
        int i17 = carro16.getLugares();
        int i18 = carro10.compareTo((Veiculo) carro16);
        java.lang.String str19 = carro16.toString();
        Coordenada coordenada20 = carro16.getCoordenadas();
        Carro carro22 = new Carro((int) ' ', (double) 100.0f, (int) (byte) -1, "", coordenada20, false);
        int i23 = carro1.compareTo((Veiculo) carro22);
        java.lang.String str24 = carro1.getMatricula();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro13 and carro22", (carro13.compareTo(carro22) == 0) == carro13.equals(carro22));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test037");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carro0.getCoordenadas();
        java.lang.String str6 = carro0.getMatricula();
        Carro carro11 = new Carro();
        carro11.setMatricula("");
        Carro carro14 = carro11.clone();
        carro11.setPrecoBase((double) 0L);
        Carro carro17 = new Carro();
        int i18 = carro17.getLugares();
        int i19 = carro11.compareTo((Veiculo) carro17);
        java.lang.String str20 = carro17.toString();
        Coordenada coordenada21 = carro17.getCoordenadas();
        Carro carro23 = new Carro((int) (byte) -1, 0.0d, (int) 'a', "", coordenada21, true);
        int i24 = carro0.compareTo((Veiculo) carro23);
        carro0.setPrecoBase(0.0d);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro14 and carro23", (carro14.compareTo(carro23) == 0) == carro14.equals(carro23));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test038");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro3.setOcupado(true);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        carro6.setVelocidadeMedia(10);
        int i10 = carro3.compareTo((Veiculo) carro6);
        Carro carro11 = carro3.clone();
        boolean b12 = carro3.getOcupado();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro0 and carro11", (carro0.compareTo(carro11) == 0) == carro0.equals(carro11));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test039");
        Carro carro4 = new Carro();
        int i5 = carro4.getLugares();
        carro4.setVelocidadeMedia(10);
        carro4.setMatricula("n/a");
        Carro carro10 = new Carro();
        carro10.setMatricula("");
        Carro carro13 = carro10.clone();
        carro10.setPrecoBase((double) 0L);
        Carro carro16 = new Carro();
        int i17 = carro16.getLugares();
        int i18 = carro10.compareTo((Veiculo) carro16);
        java.lang.String str19 = carro16.toString();
        Coordenada coordenada20 = carro16.getCoordenadas();
        Carro carro21 = new Carro();
        int i22 = carro21.getLugares();
        Coordenada coordenada23 = carro21.getCoordenadas();
        carro16.setCoordenadas(coordenada23);
        carro4.setCoordenadas(coordenada23);
        Carro carro26 = new Carro();
        carro26.setMatricula("");
        boolean b30 = carro26.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada31 = carro26.getCoordenadas();
        carro4.setCoordenadas(coordenada31);
        Carro carro34 = new Carro(4, 100.0d, (int) (short) 100, "", coordenada31, false);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro4 and carro21", (carro4.compareTo(carro21) == 0) == carro4.equals(carro21));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test040");
        Carro carro4 = new Carro();
        carro4.setMatricula("");
        Carro carro7 = carro4.clone();
        carro4.setPrecoBase((double) 0L);
        Carro carro10 = new Carro();
        int i11 = carro10.getLugares();
        int i12 = carro4.compareTo((Veiculo) carro10);
        java.lang.String str13 = carro10.toString();
        Coordenada coordenada14 = carro10.getCoordenadas();
        Carro carro16 = new Carro((int) 'a', (double) 3, 0, "", coordenada14, true);
        Carro carro17 = new Carro();
        carro17.setMatricula("");
        boolean b21 = carro17.equals((java.lang.Object) (-1.0d));
        Carro carro22 = new Carro(carro17);
        double d23 = carro17.getPrecoBase();
        boolean b24 = carro17.getOcupado();
        int i25 = carro17.getVelocidadeMedia();
        java.lang.String str26 = carro17.getMatricula();
        carro17.setMatricula("hi!");
        int i29 = carro16.compareTo((Veiculo) carro17);
        carro17.setMatricula("n/a");
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro7 and carro16", (carro7.compareTo(carro16) == 0) == carro7.equals(carro16));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test041");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carro0.getCoordenadas();
        java.lang.String str6 = carro0.getMatricula();
        Carro carro11 = new Carro();
        carro11.setMatricula("");
        Carro carro14 = carro11.clone();
        carro11.setPrecoBase((double) 0L);
        Carro carro17 = new Carro();
        int i18 = carro17.getLugares();
        int i19 = carro11.compareTo((Veiculo) carro17);
        java.lang.String str20 = carro17.toString();
        Coordenada coordenada21 = carro17.getCoordenadas();
        Carro carro23 = new Carro((int) (byte) -1, 0.0d, (int) 'a', "", coordenada21, true);
        int i24 = carro0.compareTo((Veiculo) carro23);
        java.lang.String str25 = carro0.toString();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro11 and carro23", (carro11.compareTo(carro23) == 0) == carro11.equals(carro23));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test042");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro3.setOcupado(true);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        carro6.setVelocidadeMedia(10);
        int i10 = carro3.compareTo((Veiculo) carro6);
        Carro carro11 = carro3.clone();
        Carro carro12 = new Carro();
        carro12.setMatricula("");
        Carro carro15 = carro12.clone();
        carro12.setPrecoBase((double) 0L);
        Carro carro18 = new Carro();
        int i19 = carro18.getLugares();
        int i20 = carro12.compareTo((Veiculo) carro18);
        Carro carro21 = new Carro(carro18);
        carro18.setOcupado(false);
        boolean b24 = carro3.equals((java.lang.Object) carro18);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro6 and carro21", (carro6.compareTo(carro21) == 0) == carro6.equals(carro21));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test043");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        java.lang.String str9 = carro6.toString();
        Coordenada coordenada10 = carro6.getCoordenadas();
        carro6.setFiabilidade((int) (byte) 1);
        Carro carro13 = new Carro();
        int i14 = carro13.getLugares();
        carro13.setVelocidadeMedia(10);
        Carro carro17 = carro13.clone();
        boolean b18 = carro6.equals((java.lang.Object) carro13);
        Carro carro19 = new Carro();
        Carro carro20 = new Carro(carro19);
        Carro carro21 = new Carro(carro20);
        Carro carro22 = new Carro();
        Carro carro23 = new Carro(carro22);
        int i24 = carro20.compareTo((Veiculo) carro22);
        Carro carro25 = new Carro();
        carro25.setMatricula("");
        boolean b29 = carro25.equals((java.lang.Object) (-1.0d));
        boolean b30 = carro20.equals((java.lang.Object) (-1.0d));
        Carro carro31 = new Carro(carro20);
        Carro carro32 = new Carro(carro20);
        boolean b33 = carro6.equals((java.lang.Object) carro20);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro17 and carro21", (carro17.compareTo(carro21) == 0) == carro17.equals(carro21));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test044");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        Carro carro4 = new Carro(carro0);
        int i5 = carro0.getVelocidadeMedia();
        carro0.setMatricula("");
        carro0.setPrecoBase((double) (byte) 1);
        Carro carro10 = new Carro();
        int i11 = carro10.getLugares();
        Coordenada coordenada12 = carro10.getCoordenadas();
        boolean b13 = carro0.equals((java.lang.Object) carro10);
        carro0.setOcupado(false);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro4 and carro10", (carro4.compareTo(carro10) == 0) == carro4.equals(carro10));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test045");
        Carro carro8 = new Carro();
        carro8.setMatricula("");
        Carro carro11 = carro8.clone();
        carro8.setPrecoBase((double) 0L);
        Carro carro14 = new Carro();
        int i15 = carro14.getLugares();
        int i16 = carro8.compareTo((Veiculo) carro14);
        java.lang.String str17 = carro14.toString();
        Coordenada coordenada18 = carro14.getCoordenadas();
        Carro carro20 = new Carro((int) 'a', (double) 3, 0, "", coordenada18, true);
        Carro carro22 = new Carro((int) (byte) -1, (double) 32, 32, "", coordenada18, true);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro11 and carro20", (carro11.compareTo(carro20) == 0) == carro11.equals(carro20));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test046");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        java.lang.String str2 = carro0.toString();
        carro0.setFiabilidade(0);
        Carro carro5 = carro0.clone();
        Carro carro6 = new Carro();
        Carro carro7 = new Carro(carro6);
        Carro carro8 = new Carro(carro7);
        Carro carro9 = new Carro();
        Carro carro10 = new Carro(carro9);
        int i11 = carro7.compareTo((Veiculo) carro9);
        Carro carro12 = new Carro();
        carro12.setMatricula("");
        boolean b16 = carro12.equals((java.lang.Object) (-1.0d));
        boolean b17 = carro7.equals((java.lang.Object) (-1.0d));
        Carro carro18 = new Carro();
        carro18.setMatricula("");
        Carro carro21 = carro18.clone();
        carro18.setPrecoBase((double) 0L);
        Carro carro24 = new Carro();
        int i25 = carro24.getLugares();
        int i26 = carro18.compareTo((Veiculo) carro24);
        java.lang.String str27 = carro24.toString();
        Coordenada coordenada28 = carro24.getCoordenadas();
        carro7.setCoordenadas(coordenada28);
        carro0.setCoordenadas(coordenada28);
        carro0.setPrecoBase(100.0d);
        Carro carro33 = new Carro(carro0);
        java.lang.String str34 = carro0.toString();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro7 and carro33", (carro7.compareTo(carro33) == 0) == carro7.equals(carro33));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test047");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        Carro carro4 = new Carro(carro0);
        int i5 = carro0.getVelocidadeMedia();
        java.lang.String str6 = carro0.getMatricula();
        Carro carro7 = new Carro();
        carro7.setMatricula("");
        Carro carro10 = carro7.clone();
        carro7.setPrecoBase((double) 0L);
        Carro carro13 = new Carro();
        int i14 = carro13.getLugares();
        int i15 = carro7.compareTo((Veiculo) carro13);
        int i16 = carro13.getFiabilidade();
        Carro carro17 = carro13.clone();
        Coordenada coordenada18 = carro17.getCoordenadas();
        carro0.setCoordenadas(coordenada18);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro17 and carro4", (carro17.compareTo(carro4) == 0) == carro17.equals(carro4));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test048");
        Carro carro8 = new Carro();
        carro8.setMatricula("");
        Carro carro11 = carro8.clone();
        carro8.setPrecoBase((double) 0L);
        Carro carro14 = new Carro();
        int i15 = carro14.getLugares();
        int i16 = carro8.compareTo((Veiculo) carro14);
        java.lang.String str17 = carro14.toString();
        Coordenada coordenada18 = carro14.getCoordenadas();
        Carro carro20 = new Carro((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, false);
        Carro carro22 = new Carro((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, true);
        Carro carro23 = new Carro();
        carro23.setVelocidadeMedia((int) ' ');
        java.lang.String str26 = carro23.toString();
        boolean b27 = carro22.equals((java.lang.Object) carro23);
        Carro carro28 = new Carro();
        int i29 = carro28.getLugares();
        carro28.setVelocidadeMedia(10);
        Carro carro32 = carro28.clone();
        Carro carro33 = new Carro(carro28);
        int i34 = carro22.compareTo((Veiculo) carro28);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro23 and carro14", (carro23.compareTo(carro14) == 0) == carro23.equals(carro14));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test049");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro(carro0);
        carro6.setPrecoBase((double) (-1.0f));
        carro6.setVelocidadeMedia((int) (short) 0);
        carro6.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Carro carro13 = new Carro(carro6);
        carro6.setPrecoBase(1.0d);
        Carro carro16 = new Carro();
        carro16.setMatricula("");
        boolean b20 = carro16.equals((java.lang.Object) (-1.0d));
        Carro carro21 = new Carro(carro16);
        double d22 = carro16.getPrecoBase();
        boolean b23 = carro16.getOcupado();
        int i24 = carro16.getVelocidadeMedia();
        Carro carro25 = carro16.clone();
        carro25.setFiabilidade((int) (byte) 10);
        carro25.setFiabilidade((int) (short) -1);
        int i30 = carro6.compareTo((Veiculo) carro25);
        carro6.setFiabilidade((int) (byte) -1);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro21 and carro25", (carro21.compareTo(carro25) == 0) == carro21.equals(carro25));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test050");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        java.lang.String str2 = carro0.toString();
        carro0.setFiabilidade(0);
        Carro carro5 = carro0.clone();
        Carro carro6 = new Carro();
        Carro carro7 = new Carro(carro6);
        Carro carro8 = new Carro(carro7);
        Carro carro9 = new Carro();
        Carro carro10 = new Carro(carro9);
        int i11 = carro7.compareTo((Veiculo) carro9);
        Carro carro12 = new Carro();
        carro12.setMatricula("");
        boolean b16 = carro12.equals((java.lang.Object) (-1.0d));
        boolean b17 = carro7.equals((java.lang.Object) (-1.0d));
        Carro carro18 = new Carro();
        carro18.setMatricula("");
        Carro carro21 = carro18.clone();
        carro18.setPrecoBase((double) 0L);
        Carro carro24 = new Carro();
        int i25 = carro24.getLugares();
        int i26 = carro18.compareTo((Veiculo) carro24);
        java.lang.String str27 = carro24.toString();
        Coordenada coordenada28 = carro24.getCoordenadas();
        carro7.setCoordenadas(coordenada28);
        carro0.setCoordenadas(coordenada28);
        carro0.setPrecoBase(100.0d);
        Carro carro33 = new Carro(carro0);
        int i34 = carro33.getVelocidadeMedia();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro5 and carro0", (carro5.compareTo(carro0) == 0) == carro5.equals(carro0));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test051");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        Carro carro4 = new Carro(carro0);
        int i5 = carro0.getVelocidadeMedia();
        java.lang.String str6 = carro0.getMatricula();
        carro0.setFiabilidade((int) ' ');
        Carro carro9 = new Carro();
        Carro carro10 = new Carro(carro9);
        java.lang.String str11 = carro9.toString();
        carro9.setFiabilidade(0);
        int i14 = carro9.getFiabilidade();
        Carro carro15 = new Carro();
        Carro carro16 = new Carro(carro15);
        java.lang.String str17 = carro15.toString();
        carro15.setFiabilidade(0);
        Carro carro20 = carro15.clone();
        Carro carro21 = new Carro(carro15);
        Coordenada coordenada22 = carro15.getCoordenadas();
        carro9.setCoordenadas(coordenada22);
        carro0.setCoordenadas(coordenada22);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro15 and carro4", (carro15.compareTo(carro4) == 0) == carro15.equals(carro4));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test052");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carro0.getCoordenadas();
        boolean b6 = carro0.getOcupado();
        java.lang.String str7 = carro0.getMatricula();
        Carro carro12 = new Carro();
        carro12.setMatricula("");
        Carro carro15 = carro12.clone();
        carro12.setPrecoBase((double) 0L);
        Carro carro18 = new Carro();
        int i19 = carro18.getLugares();
        int i20 = carro12.compareTo((Veiculo) carro18);
        java.lang.String str21 = carro18.toString();
        Coordenada coordenada22 = carro18.getCoordenadas();
        Carro carro24 = new Carro((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada22, false);
        carro0.setCoordenadas(coordenada22);
        carro0.setOcupado(true);
        Carro carro28 = new Carro(carro0);
        int i29 = carro28.getFiabilidade();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro15 and carro0", (carro15.compareTo(carro0) == 0) == carro15.equals(carro0));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test053");
        Carro carro4 = new Carro();
        carro4.setMatricula("");
        Carro carro7 = carro4.clone();
        carro4.setPrecoBase((double) 0L);
        Carro carro10 = new Carro();
        int i11 = carro10.getLugares();
        int i12 = carro4.compareTo((Veiculo) carro10);
        java.lang.String str13 = carro10.toString();
        Coordenada coordenada14 = carro10.getCoordenadas();
        Carro carro16 = new Carro((int) 'a', (double) 3, 0, "", coordenada14, true);
        Carro carro17 = new Carro();
        carro17.setMatricula("");
        boolean b21 = carro17.equals((java.lang.Object) (-1.0d));
        Carro carro22 = new Carro(carro17);
        double d23 = carro17.getPrecoBase();
        boolean b24 = carro17.getOcupado();
        int i25 = carro17.getVelocidadeMedia();
        java.lang.String str26 = carro17.getMatricula();
        carro17.setMatricula("hi!");
        int i29 = carro16.compareTo((Veiculo) carro17);
        Carro carro30 = new Carro();
        Carro carro31 = new Carro(carro30);
        int i32 = carro31.getFiabilidade();
        Coordenada coordenada33 = carro31.getCoordenadas();
        carro17.setCoordenadas(coordenada33);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro7 and carro16", (carro7.compareTo(carro16) == 0) == carro7.equals(carro16));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test054");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        int i4 = carro3.getLugares();
        boolean b5 = carro2.equals((java.lang.Object) carro3);
        carro3.setOcupado(true);
        Carro carro12 = new Carro();
        carro12.setMatricula("");
        Carro carro15 = carro12.clone();
        carro12.setPrecoBase((double) 0L);
        Carro carro18 = new Carro();
        int i19 = carro18.getLugares();
        int i20 = carro12.compareTo((Veiculo) carro18);
        java.lang.String str21 = carro18.toString();
        Coordenada coordenada22 = carro18.getCoordenadas();
        Carro carro24 = new Carro((int) (byte) -1, 0.0d, (int) 'a', "", coordenada22, true);
        carro3.setCoordenadas(coordenada22);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro12 and carro24", (carro12.compareTo(carro24) == 0) == carro12.equals(carro24));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test055");
        Carro carro4 = new Carro();
        int i5 = carro4.getLugares();
        carro4.setVelocidadeMedia(10);
        carro4.setMatricula("n/a");
        Carro carro10 = new Carro();
        carro10.setMatricula("");
        Carro carro13 = carro10.clone();
        carro10.setPrecoBase((double) 0L);
        Carro carro16 = new Carro();
        int i17 = carro16.getLugares();
        int i18 = carro10.compareTo((Veiculo) carro16);
        java.lang.String str19 = carro16.toString();
        Coordenada coordenada20 = carro16.getCoordenadas();
        Carro carro21 = new Carro();
        int i22 = carro21.getLugares();
        Coordenada coordenada23 = carro21.getCoordenadas();
        carro16.setCoordenadas(coordenada23);
        carro4.setCoordenadas(coordenada23);
        Carro carro27 = new Carro((int) '#', (double) 100L, (int) (short) 1, "hi!", coordenada23, true);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro16 and carro4", (carro16.compareTo(carro4) == 0) == carro16.equals(carro4));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test056");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        java.lang.String str2 = carro0.getMatricula();
        carro0.setMatricula("");
        int i5 = carro0.getFiabilidade();
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        java.lang.String str8 = carro6.getMatricula();
        Carro carro9 = new Carro(carro6);
        carro6.setOcupado(true);
        double d12 = carro6.getPrecoBase();
        boolean b13 = carro0.equals((java.lang.Object) d12);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro6 and carro9", (carro6.compareTo(carro9) == 0) == carro6.equals(carro9));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test057");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        java.lang.String str2 = carro0.toString();
        carro0.setFiabilidade(0);
        int i5 = carro0.getFiabilidade();
        Carro carro6 = new Carro();
        carro6.setMatricula("");
        java.lang.String str9 = carro6.toString();
        Carro carro10 = carro6.clone();
        carro10.setOcupado(true);
        Carro carro13 = new Carro();
        Carro carro14 = new Carro(carro13);
        java.lang.String str15 = carro13.toString();
        carro13.setFiabilidade(0);
        int i18 = carro13.getFiabilidade();
        Carro carro19 = new Carro(carro13);
        boolean b20 = carro10.equals((java.lang.Object) carro19);
        carro10.setPrecoBase((double) 1);
        int i23 = carro0.compareTo((Veiculo) carro10);
        Carro carro24 = new Carro();
        Carro carro25 = new Carro(carro24);
        java.lang.String str26 = carro24.toString();
        carro24.setFiabilidade(0);
        int i29 = carro24.getFiabilidade();
        Carro carro30 = new Carro();
        carro30.setMatricula("");
        java.lang.String str33 = carro30.toString();
        Carro carro34 = carro30.clone();
        carro34.setOcupado(true);
        Carro carro37 = new Carro();
        Carro carro38 = new Carro(carro37);
        java.lang.String str39 = carro37.toString();
        carro37.setFiabilidade(0);
        int i42 = carro37.getFiabilidade();
        Carro carro43 = new Carro(carro37);
        boolean b44 = carro34.equals((java.lang.Object) carro43);
        carro34.setPrecoBase((double) 1);
        int i47 = carro24.compareTo((Veiculo) carro34);
        boolean b48 = carro10.equals((java.lang.Object) carro24);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro34 and carro6", (carro34.compareTo(carro6) == 0) == carro34.equals(carro6));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test058");
        Carro carro4 = new Carro();
        carro4.setMatricula("");
        Carro carro7 = carro4.clone();
        carro4.setPrecoBase((double) 0L);
        Carro carro10 = new Carro();
        int i11 = carro10.getLugares();
        int i12 = carro4.compareTo((Veiculo) carro10);
        java.lang.String str13 = carro10.toString();
        Coordenada coordenada14 = carro10.getCoordenadas();
        Carro carro16 = new Carro((int) 'a', (double) 3, 0, "", coordenada14, true);
        Carro carro17 = new Carro();
        carro17.setMatricula("");
        boolean b21 = carro17.equals((java.lang.Object) (-1.0d));
        Carro carro22 = new Carro(carro17);
        double d23 = carro17.getPrecoBase();
        boolean b24 = carro17.getOcupado();
        int i25 = carro17.getVelocidadeMedia();
        java.lang.String str26 = carro17.getMatricula();
        carro17.setMatricula("hi!");
        int i29 = carro16.compareTo((Veiculo) carro17);
        carro17.setFiabilidade(10);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro16 and carro7", (carro16.compareTo(carro7) == 0) == carro16.equals(carro7));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test059");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        java.lang.String str9 = carro6.toString();
        int i10 = carro6.getFiabilidade();
        carro6.setPrecoBase(10.0d);
        int i13 = carro6.getFiabilidade();
        carro6.setFiabilidade(100);
        Carro carro16 = new Carro();
        carro16.setMatricula("");
        Carro carro19 = carro16.clone();
        carro19.setOcupado(true);
        int i22 = carro19.getFiabilidade();
        int i23 = carro19.getFiabilidade();
        boolean b24 = carro6.equals((java.lang.Object) i23);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro0 and carro19", (carro0.compareTo(carro19) == 0) == carro0.equals(carro19));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test060");
        Carro carro4 = new Carro();
        carro4.setMatricula("");
        Carro carro7 = carro4.clone();
        carro4.setPrecoBase((double) 0L);
        Carro carro10 = new Carro();
        int i11 = carro10.getLugares();
        int i12 = carro4.compareTo((Veiculo) carro10);
        java.lang.String str13 = carro10.toString();
        Coordenada coordenada14 = carro10.getCoordenadas();
        Carro carro16 = new Carro((int) ' ', (double) 100.0f, (int) (byte) -1, "", coordenada14, false);
        Carro carro17 = new Carro(carro16);
        Carro carro18 = new Carro(carro16);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro17 and carro4", (carro17.compareTo(carro4) == 0) == carro17.equals(carro4));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test061");
        Carro carro0 = new Carro();
        carro0.setVelocidadeMedia((int) ' ');
        java.lang.String str3 = carro0.toString();
        Carro carro4 = new Carro();
        Carro carro5 = new Carro(carro4);
        Carro carro6 = new Carro(carro5);
        Carro carro7 = new Carro();
        int i8 = carro7.getLugares();
        boolean b9 = carro6.equals((java.lang.Object) carro7);
        carro7.setFiabilidade(100);
        boolean b12 = carro0.equals((java.lang.Object) 100);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro5 and carro7", (carro5.compareTo(carro7) == 0) == carro5.equals(carro7));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test062");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        java.lang.String str2 = carro0.toString();
        Carro carro3 = new Carro();
        carro3.setMatricula("");
        Carro carro6 = carro3.clone();
        carro3.setPrecoBase((double) 0L);
        Carro carro9 = new Carro();
        int i10 = carro9.getLugares();
        int i11 = carro3.compareTo((Veiculo) carro9);
        java.lang.String str12 = carro9.toString();
        Coordenada coordenada13 = carro9.getCoordenadas();
        carro9.setFiabilidade((int) (byte) 1);
        Carro carro16 = new Carro();
        int i17 = carro16.getLugares();
        carro16.setVelocidadeMedia(10);
        Carro carro20 = carro16.clone();
        boolean b21 = carro9.equals((java.lang.Object) carro16);
        int i22 = carro0.compareTo((Veiculo) carro16);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro1 and carro20", (carro1.compareTo(carro20) == 0) == carro1.equals(carro20));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test063");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        java.lang.String str2 = carro0.toString();
        carro0.setFiabilidade(0);
        Carro carro5 = carro0.clone();
        int i6 = carro5.getFiabilidade();
        Coordenada coordenada7 = carro5.getCoordenadas();
        Carro carro8 = new Carro();
        carro8.setMatricula("");
        Carro carro11 = carro8.clone();
        carro8.setPrecoBase((double) 0L);
        Carro carro14 = new Carro();
        int i15 = carro14.getLugares();
        int i16 = carro8.compareTo((Veiculo) carro14);
        java.lang.String str17 = carro14.toString();
        int i18 = carro14.getFiabilidade();
        carro14.setPrecoBase(10.0d);
        int i21 = carro14.getVelocidadeMedia();
        boolean b22 = carro5.equals((java.lang.Object) i21);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro0 and carro14", (carro0.compareTo(carro14) == 0) == carro0.equals(carro14));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test064");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        java.lang.String str9 = carro6.toString();
        int i10 = carro6.getFiabilidade();
        carro6.setPrecoBase(10.0d);
        int i13 = carro6.getVelocidadeMedia();
        Carro carro14 = new Carro(carro6);
        carro6.setVelocidadeMedia(1);
        Carro carro17 = new Carro();
        int i18 = carro17.getLugares();
        carro17.setVelocidadeMedia(10);
        carro17.setMatricula("n/a");
        carro17.setPrecoBase((double) (-1.0f));
        boolean b25 = carro6.equals((java.lang.Object) carro17);
        int i26 = carro17.getFiabilidade();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro14 and carro6", (carro14.compareTo(carro6) == 0) == carro14.equals(carro6));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test065");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carro0.getCoordenadas();
        int i6 = carro0.getVelocidadeMedia();
        Carro carro7 = new Carro();
        carro7.setMatricula("");
        Carro carro10 = carro7.clone();
        carro10.setOcupado(true);
        boolean b13 = carro0.equals((java.lang.Object) carro10);
        int i14 = carro0.getFiabilidade();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro7 and carro10", (carro7.compareTo(carro10) == 0) == carro7.equals(carro10));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test066");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        int i4 = carro3.getLugares();
        boolean b5 = carro2.equals((java.lang.Object) carro3);
        Carro carro6 = carro3.clone();
        carro6.setOcupado(true);
        Carro carro13 = new Carro();
        carro13.setMatricula("");
        Carro carro16 = carro13.clone();
        carro13.setPrecoBase((double) 0L);
        Carro carro19 = new Carro();
        int i20 = carro19.getLugares();
        int i21 = carro13.compareTo((Veiculo) carro19);
        java.lang.String str22 = carro19.toString();
        Coordenada coordenada23 = carro19.getCoordenadas();
        Carro carro25 = new Carro((int) 'a', (double) 3, 0, "", coordenada23, true);
        carro6.setCoordenadas(coordenada23);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro25 and carro13", (carro25.compareTo(carro13) == 0) == carro25.equals(carro13));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test067");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        java.lang.String str9 = carro6.toString();
        int i10 = carro6.getFiabilidade();
        carro6.setPrecoBase(10.0d);
        int i13 = carro6.getVelocidadeMedia();
        Carro carro14 = new Carro(carro6);
        boolean b15 = carro14.getOcupado();
        Carro carro16 = new Carro();
        carro16.setMatricula("");
        carro16.setOcupado(true);
        boolean b21 = carro14.equals((java.lang.Object) carro16);
        Coordenada coordenada22 = carro14.getCoordenadas();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro0 and carro16", (carro0.compareTo(carro16) == 0) == carro0.equals(carro16));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test068");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        java.lang.String str9 = carro6.toString();
        int i10 = carro6.getFiabilidade();
        carro6.setPrecoBase(10.0d);
        int i13 = carro6.getVelocidadeMedia();
        Carro carro14 = new Carro(carro6);
        boolean b15 = carro14.getOcupado();
        Carro carro16 = new Carro();
        carro16.setMatricula("");
        carro16.setOcupado(true);
        boolean b21 = carro14.equals((java.lang.Object) carro16);
        int i22 = carro14.getVelocidadeMedia();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro3 and carro16", (carro3.compareTo(carro16) == 0) == carro3.equals(carro16));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test069");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro3.setOcupado(true);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        carro6.setVelocidadeMedia(10);
        int i10 = carro3.compareTo((Veiculo) carro6);
        Carro carro11 = carro3.clone();
        java.lang.String str12 = carro3.toString();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro0 and carro11", (carro0.compareTo(carro11) == 0) == carro0.equals(carro11));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test070");
        Carro carro8 = new Carro();
        carro8.setMatricula("");
        Carro carro11 = carro8.clone();
        carro8.setPrecoBase((double) 0L);
        Carro carro14 = new Carro();
        int i15 = carro14.getLugares();
        int i16 = carro8.compareTo((Veiculo) carro14);
        java.lang.String str17 = carro14.toString();
        Coordenada coordenada18 = carro14.getCoordenadas();
        Carro carro20 = new Carro((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, false);
        Carro carro22 = new Carro((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, true);
        Carro carro23 = new Carro();
        carro23.setVelocidadeMedia((int) ' ');
        java.lang.String str26 = carro23.toString();
        boolean b27 = carro22.equals((java.lang.Object) carro23);
        carro22.setVelocidadeMedia((int) 'a');
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro14 and carro23", (carro14.compareTo(carro23) == 0) == carro14.equals(carro23));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test071");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carro0.getCoordenadas();
        int i6 = carro0.getVelocidadeMedia();
        Carro carro7 = new Carro();
        carro7.setMatricula("");
        Carro carro10 = carro7.clone();
        carro10.setOcupado(true);
        boolean b13 = carro0.equals((java.lang.Object) carro10);
        Carro carro14 = new Carro(carro0);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro10 and carro7", (carro10.compareTo(carro7) == 0) == carro10.equals(carro7));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test072");
        Carro carro8 = new Carro();
        carro8.setMatricula("");
        Carro carro11 = carro8.clone();
        carro8.setPrecoBase((double) 0L);
        Carro carro14 = new Carro();
        int i15 = carro14.getLugares();
        int i16 = carro8.compareTo((Veiculo) carro14);
        java.lang.String str17 = carro14.toString();
        Coordenada coordenada18 = carro14.getCoordenadas();
        Carro carro20 = new Carro((int) (byte) 100, (double) '#', (int) (short) 0, "", coordenada18, false);
        Carro carro22 = new Carro((int) (short) 10, (double) (short) 1, (int) '4', "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, false);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro8 and carro20", (carro8.compareTo(carro20) == 0) == carro8.equals(carro20));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test073");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        Coordenada coordenada4 = carro3.getCoordenadas();
        Carro carro5 = new Carro();
        carro5.setMatricula("");
        Carro carro8 = carro5.clone();
        carro5.setPrecoBase((double) 0L);
        Carro carro11 = new Carro();
        int i12 = carro11.getLugares();
        int i13 = carro5.compareTo((Veiculo) carro11);
        java.lang.String str14 = carro11.toString();
        Coordenada coordenada15 = carro11.getCoordenadas();
        int i16 = carro3.compareTo((Veiculo) carro11);
        java.lang.String str17 = carro3.getMatricula();
        Carro carro18 = new Carro();
        int i19 = carro18.getLugares();
        carro18.setVelocidadeMedia(10);
        Carro carro22 = new Carro(carro18);
        boolean b23 = carro3.equals((java.lang.Object) carro18);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro11 and carro22", (carro11.compareTo(carro22) == 0) == carro11.equals(carro22));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test074");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        int i4 = carro3.getLugares();
        boolean b5 = carro2.equals((java.lang.Object) carro3);
        carro3.setOcupado(true);
        Carro carro16 = new Carro();
        carro16.setMatricula("");
        boolean b20 = carro16.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada21 = carro16.getCoordenadas();
        carro16.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carro16.setFiabilidade(0);
        Carro carro26 = new Carro();
        carro26.setMatricula("");
        Carro carro29 = carro26.clone();
        carro26.setPrecoBase((double) 0L);
        Carro carro32 = new Carro(carro26);
        int i33 = carro16.compareTo((Veiculo) carro26);
        Carro carro34 = new Carro(carro26);
        Coordenada coordenada35 = carro34.getCoordenadas();
        Carro carro37 = new Carro((int) (byte) 0, (double) 0L, (int) (byte) 0, "n/a", coordenada35, true);
        Coordenada coordenada38 = carro37.getCoordenadas();
        Carro carro40 = new Carro(52, (double) 3, (int) (byte) 0, "hi!", coordenada38, true);
        carro3.setCoordenadas(coordenada38);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro1 and carro37", (carro1.compareTo(carro37) == 0) == carro1.equals(carro37));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test075");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro();
        carro2.setMatricula("");
        Carro carro5 = carro2.clone();
        carro2.setPrecoBase((double) 0L);
        java.lang.String str8 = carro2.getMatricula();
        Coordenada coordenada9 = carro2.getCoordenadas();
        Carro carro14 = new Carro();
        carro14.setMatricula("");
        boolean b18 = carro14.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada19 = carro14.getCoordenadas();
        carro14.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carro14.setFiabilidade(0);
        Carro carro24 = new Carro();
        carro24.setMatricula("");
        Carro carro27 = carro24.clone();
        carro24.setPrecoBase((double) 0L);
        Carro carro30 = new Carro(carro24);
        int i31 = carro14.compareTo((Veiculo) carro24);
        Carro carro32 = new Carro(carro24);
        Coordenada coordenada33 = carro32.getCoordenadas();
        Carro carro35 = new Carro((int) (byte) 0, (double) 0L, (int) (byte) 0, "n/a", coordenada33, true);
        Coordenada coordenada36 = carro35.getCoordenadas();
        carro2.setCoordenadas(coordenada36);
        carro0.setCoordenadas(coordenada36);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro35 and carro1", (carro35.compareTo(carro1) == 0) == carro35.equals(carro1));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test076");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro(carro0);
        carro6.setPrecoBase((double) (-1.0f));
        carro6.setVelocidadeMedia((int) (short) 0);
        carro6.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Carro carro13 = new Carro(carro6);
        int i14 = carro13.getLugares();
        Carro carro15 = new Carro();
        int i16 = carro15.getLugares();
        java.lang.String str17 = carro15.getMatricula();
        Carro carro18 = new Carro(carro15);
        int i19 = carro18.getFiabilidade();
        carro18.setPrecoBase(1.0d);
        boolean b22 = carro13.equals((java.lang.Object) 1.0d);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro18 and carro15", (carro18.compareTo(carro15) == 0) == carro18.equals(carro15));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test077");
        Carro carro4 = new Carro();
        carro4.setMatricula("");
        Carro carro7 = carro4.clone();
        carro4.setPrecoBase((double) 0L);
        Carro carro10 = new Carro();
        int i11 = carro10.getLugares();
        int i12 = carro4.compareTo((Veiculo) carro10);
        java.lang.String str13 = carro10.toString();
        Coordenada coordenada14 = carro10.getCoordenadas();
        Carro carro16 = new Carro((int) ' ', (double) 100.0f, (int) (byte) -1, "", coordenada14, false);
        Carro carro17 = new Carro(carro16);
        carro16.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n");
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro17 and carro7", (carro17.compareTo(carro7) == 0) == carro17.equals(carro7));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test078");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        int i4 = carro3.getLugares();
        boolean b5 = carro2.equals((java.lang.Object) carro3);
        Carro carro6 = carro3.clone();
        carro6.setVelocidadeMedia((int) (short) 0);
        int i9 = carro6.getLugares();
        carro6.setMatricula("Matrícula: \nVelocidade Média/km: -1km/h\nPreço Base: 0.0€\nFiabilidade: 1\nLugares: 4\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Carro carro12 = new Carro();
        carro12.setMatricula("");
        boolean b16 = carro12.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada17 = carro12.getCoordenadas();
        java.lang.String str18 = carro12.getMatricula();
        Carro carro23 = new Carro();
        carro23.setMatricula("");
        Carro carro26 = carro23.clone();
        carro23.setPrecoBase((double) 0L);
        Carro carro29 = new Carro();
        int i30 = carro29.getLugares();
        int i31 = carro23.compareTo((Veiculo) carro29);
        java.lang.String str32 = carro29.toString();
        Coordenada coordenada33 = carro29.getCoordenadas();
        Carro carro35 = new Carro((int) (byte) -1, 0.0d, (int) 'a', "", coordenada33, true);
        int i36 = carro12.compareTo((Veiculo) carro35);
        boolean b37 = carro6.equals((java.lang.Object) carro12);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro35 and carro23", (carro35.compareTo(carro23) == 0) == carro35.equals(carro23));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test079");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro3.setOcupado(true);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        carro6.setVelocidadeMedia(10);
        int i10 = carro3.compareTo((Veiculo) carro6);
        Carro carro11 = carro3.clone();
        carro11.setVelocidadeMedia((int) 'a');
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro3 and carro0", (carro3.compareTo(carro0) == 0) == carro3.equals(carro0));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test080");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        Carro carro4 = new Carro(carro0);
        int i5 = carro0.getVelocidadeMedia();
        java.lang.String str6 = carro0.getMatricula();
        carro0.setVelocidadeMedia((int) (byte) 1);
        Carro carro9 = new Carro(carro0);
        int i10 = carro9.getVelocidadeMedia();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro0 and carro4", (carro0.compareTo(carro4) == 0) == carro0.equals(carro4));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test081");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        Carro carro4 = new Carro(carro0);
        int i5 = carro0.getVelocidadeMedia();
        carro0.setMatricula("");
        carro0.setPrecoBase((double) (byte) 1);
        Carro carro10 = new Carro();
        int i11 = carro10.getLugares();
        Coordenada coordenada12 = carro10.getCoordenadas();
        boolean b13 = carro0.equals((java.lang.Object) carro10);
        carro0.setPrecoBase((double) (-33));
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro10 and carro4", (carro10.compareTo(carro4) == 0) == carro10.equals(carro4));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test082");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        java.lang.String str3 = carro0.toString();
        Carro carro4 = new Carro();
        Carro carro5 = new Carro(carro4);
        java.lang.String str6 = carro4.toString();
        carro4.setFiabilidade(0);
        Carro carro9 = carro4.clone();
        Carro carro10 = new Carro();
        Carro carro11 = new Carro(carro10);
        Carro carro12 = new Carro(carro11);
        Carro carro13 = new Carro();
        Carro carro14 = new Carro(carro13);
        int i15 = carro11.compareTo((Veiculo) carro13);
        Carro carro16 = new Carro();
        carro16.setMatricula("");
        boolean b20 = carro16.equals((java.lang.Object) (-1.0d));
        boolean b21 = carro11.equals((java.lang.Object) (-1.0d));
        Carro carro22 = new Carro();
        carro22.setMatricula("");
        Carro carro25 = carro22.clone();
        carro22.setPrecoBase((double) 0L);
        Carro carro28 = new Carro();
        int i29 = carro28.getLugares();
        int i30 = carro22.compareTo((Veiculo) carro28);
        java.lang.String str31 = carro28.toString();
        Coordenada coordenada32 = carro28.getCoordenadas();
        carro11.setCoordenadas(coordenada32);
        carro4.setCoordenadas(coordenada32);
        carro0.setCoordenadas(coordenada32);
        Carro carro36 = new Carro();
        int i37 = carro36.getLugares();
        carro36.setVelocidadeMedia(10);
        Carro carro40 = new Carro(carro36);
        int i41 = carro0.compareTo((Veiculo) carro40);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro5 and carro36", (carro5.compareTo(carro36) == 0) == carro5.equals(carro36));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test083");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carro0.getCoordenadas();
        boolean b6 = carro0.getOcupado();
        java.lang.String str7 = carro0.getMatricula();
        Carro carro12 = new Carro();
        carro12.setMatricula("");
        Carro carro15 = carro12.clone();
        carro12.setPrecoBase((double) 0L);
        Carro carro18 = new Carro();
        int i19 = carro18.getLugares();
        int i20 = carro12.compareTo((Veiculo) carro18);
        java.lang.String str21 = carro18.toString();
        Coordenada coordenada22 = carro18.getCoordenadas();
        Carro carro24 = new Carro((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada22, false);
        carro0.setCoordenadas(coordenada22);
        carro0.setOcupado(true);
        Carro carro28 = new Carro(carro0);
        carro0.setVelocidadeMedia((int) ' ');
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro12 and carro28", (carro12.compareTo(carro28) == 0) == carro12.equals(carro28));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test084");
        Carro carro8 = new Carro();
        carro8.setMatricula("");
        Carro carro11 = carro8.clone();
        carro8.setPrecoBase((double) 0L);
        Carro carro14 = new Carro();
        int i15 = carro14.getLugares();
        int i16 = carro8.compareTo((Veiculo) carro14);
        java.lang.String str17 = carro14.toString();
        Coordenada coordenada18 = carro14.getCoordenadas();
        Carro carro20 = new Carro((int) ' ', (double) 100.0f, (int) (byte) -1, "", coordenada18, false);
        Carro carro22 = new Carro((int) (short) 10, 100.0d, 32, "", coordenada18, false);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro8 and carro20", (carro8.compareTo(carro20) == 0) == carro8.equals(carro20));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test085");
        Carro carro4 = new Carro();
        carro4.setMatricula("");
        Carro carro7 = carro4.clone();
        carro4.setPrecoBase((double) 0L);
        Carro carro10 = new Carro();
        int i11 = carro10.getLugares();
        int i12 = carro4.compareTo((Veiculo) carro10);
        java.lang.String str13 = carro10.toString();
        Coordenada coordenada14 = carro10.getCoordenadas();
        Carro carro16 = new Carro((int) 'a', (double) 3, 0, "", coordenada14, true);
        Carro carro17 = new Carro();
        carro17.setMatricula("");
        boolean b21 = carro17.equals((java.lang.Object) (-1.0d));
        Carro carro22 = new Carro(carro17);
        double d23 = carro17.getPrecoBase();
        boolean b24 = carro17.getOcupado();
        int i25 = carro17.getVelocidadeMedia();
        java.lang.String str26 = carro17.getMatricula();
        carro17.setMatricula("hi!");
        int i29 = carro16.compareTo((Veiculo) carro17);
        Carro carro30 = carro16.clone();
        boolean b31 = carro30.getOcupado();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro16 and carro4", (carro16.compareTo(carro4) == 0) == carro16.equals(carro4));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test086");
        Carro carro8 = new Carro();
        int i9 = carro8.getLugares();
        Coordenada coordenada10 = carro8.getCoordenadas();
        Carro carro12 = new Carro((int) (short) -1, (double) (byte) -1, (int) '4', "", coordenada10, true);
        Carro carro14 = new Carro(52, (double) (short) 10, (-3), "n/a", coordenada10, true);
        carro14.setVelocidadeMedia(4);
        Carro carro21 = new Carro();
        carro21.setMatricula("");
        boolean b25 = carro21.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada26 = carro21.getCoordenadas();
        carro21.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carro21.setFiabilidade(0);
        Carro carro31 = new Carro();
        carro31.setMatricula("");
        Carro carro34 = carro31.clone();
        carro31.setPrecoBase((double) 0L);
        Carro carro37 = new Carro(carro31);
        int i38 = carro21.compareTo((Veiculo) carro31);
        Carro carro39 = new Carro(carro31);
        Coordenada coordenada40 = carro39.getCoordenadas();
        Carro carro42 = new Carro((int) (byte) 0, (double) 0L, (int) (byte) 0, "n/a", coordenada40, true);
        carro14.setCoordenadas(coordenada40);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro12 and carro34", (carro12.compareTo(carro34) == 0) == carro12.equals(carro34));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test087");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        Carro carro4 = new Carro(carro3);
        int i5 = carro1.compareTo((Veiculo) carro3);
        int i6 = carro3.getVelocidadeMedia();
        Carro carro7 = carro3.clone();
        int i8 = carro7.getFiabilidade();
        int i9 = carro7.getFiabilidade();
        Carro carro10 = new Carro(carro7);
        java.lang.String str11 = carro7.getMatricula();
        Carro carro12 = new Carro();
        int i13 = carro12.getLugares();
        carro12.setVelocidadeMedia(10);
        carro12.setFiabilidade((int) (byte) 0);
        double d18 = carro12.getPrecoBase();
        boolean b19 = carro7.equals((java.lang.Object) d18);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro10 and carro12", (carro10.compareTo(carro12) == 0) == carro10.equals(carro12));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test088");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        Carro carro4 = new Carro(carro3);
        int i5 = carro1.compareTo((Veiculo) carro3);
        int i6 = carro3.getVelocidadeMedia();
        Carro carro7 = carro3.clone();
        int i8 = carro7.getFiabilidade();
        int i9 = carro7.getFiabilidade();
        Carro carro10 = new Carro(carro7);
        Carro carro11 = new Carro();
        carro11.setMatricula("");
        Carro carro14 = carro11.clone();
        Coordenada coordenada15 = carro14.getCoordenadas();
        Carro carro16 = new Carro();
        carro16.setMatricula("");
        Carro carro19 = carro16.clone();
        carro16.setPrecoBase((double) 0L);
        Carro carro22 = new Carro();
        int i23 = carro22.getLugares();
        int i24 = carro16.compareTo((Veiculo) carro22);
        java.lang.String str25 = carro22.toString();
        Coordenada coordenada26 = carro22.getCoordenadas();
        int i27 = carro14.compareTo((Veiculo) carro22);
        Carro carro28 = new Carro();
        carro28.setMatricula("");
        Carro carro31 = carro28.clone();
        carro28.setPrecoBase((double) 0L);
        java.lang.String str34 = carro28.getMatricula();
        Coordenada coordenada35 = carro28.getCoordenadas();
        carro14.setCoordenadas(coordenada35);
        carro14.setFiabilidade((int) (short) -1);
        int i39 = carro7.compareTo((Veiculo) carro14);
        boolean b40 = carro7.getOcupado();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro19 and carro14", (carro19.compareTo(carro14) == 0) == carro19.equals(carro14));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test089");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        Carro carro4 = new Carro(carro0);
        carro4.setOcupado(true);
        java.lang.String str7 = carro4.getMatricula();
        Carro carro16 = new Carro();
        carro16.setMatricula("");
        boolean b20 = carro16.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada21 = carro16.getCoordenadas();
        boolean b22 = carro16.getOcupado();
        java.lang.String str23 = carro16.getMatricula();
        Carro carro28 = new Carro();
        carro28.setMatricula("");
        Carro carro31 = carro28.clone();
        carro28.setPrecoBase((double) 0L);
        Carro carro34 = new Carro();
        int i35 = carro34.getLugares();
        int i36 = carro28.compareTo((Veiculo) carro34);
        java.lang.String str37 = carro34.toString();
        Coordenada coordenada38 = carro34.getCoordenadas();
        Carro carro40 = new Carro((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada38, false);
        carro16.setCoordenadas(coordenada38);
        Carro carro43 = new Carro(32, (double) (short) 1, (int) (byte) 1, "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada38, true);
        Carro carro45 = new Carro(4, (-1.0d), (int) ' ', "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 10.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada38, true);
        carro4.setCoordenadas(coordenada38);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro0 and carro34", (carro0.compareTo(carro34) == 0) == carro0.equals(carro34));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test090");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        java.lang.String str2 = carro0.getMatricula();
        Carro carro3 = new Carro(carro0);
        carro0.setOcupado(true);
        java.lang.String str6 = carro0.toString();
        Carro carro7 = new Carro();
        int i8 = carro7.getLugares();
        java.lang.String str9 = carro7.getMatricula();
        Carro carro10 = new Carro(carro7);
        int i11 = carro7.getVelocidadeMedia();
        int i12 = carro0.compareTo((Veiculo) carro7);
        int i13 = carro7.getVelocidadeMedia();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro0 and carro3", (carro0.compareTo(carro3) == 0) == carro0.equals(carro3));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test091");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        Carro carro4 = new Carro(carro0);
        int i5 = carro0.getVelocidadeMedia();
        java.lang.String str6 = carro0.getMatricula();
        carro0.setVelocidadeMedia((int) (byte) 1);
        Carro carro9 = new Carro(carro0);
        int i10 = carro9.getLugares();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro4 and carro0", (carro4.compareTo(carro0) == 0) == carro4.equals(carro0));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test092");
        Carro carro8 = new Carro();
        carro8.setMatricula("");
        Carro carro11 = carro8.clone();
        carro8.setPrecoBase((double) 0L);
        Carro carro14 = new Carro();
        int i15 = carro14.getLugares();
        int i16 = carro8.compareTo((Veiculo) carro14);
        java.lang.String str17 = carro14.toString();
        Coordenada coordenada18 = carro14.getCoordenadas();
        Carro carro20 = new Carro((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, false);
        Carro carro22 = new Carro((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, true);
        Carro carro23 = new Carro();
        carro23.setVelocidadeMedia((int) ' ');
        java.lang.String str26 = carro23.toString();
        boolean b27 = carro22.equals((java.lang.Object) carro23);
        carro22.setFiabilidade((-3));
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro23 and carro14", (carro23.compareTo(carro14) == 0) == carro23.equals(carro14));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test093");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        Carro carro4 = new Carro(carro3);
        int i5 = carro1.compareTo((Veiculo) carro3);
        Carro carro6 = new Carro();
        carro6.setMatricula("");
        boolean b10 = carro6.equals((java.lang.Object) (-1.0d));
        boolean b11 = carro1.equals((java.lang.Object) (-1.0d));
        Carro carro12 = new Carro();
        carro12.setMatricula("");
        Carro carro15 = carro12.clone();
        carro12.setPrecoBase((double) 0L);
        Carro carro18 = new Carro();
        int i19 = carro18.getLugares();
        int i20 = carro12.compareTo((Veiculo) carro18);
        java.lang.String str21 = carro18.toString();
        Coordenada coordenada22 = carro18.getCoordenadas();
        carro1.setCoordenadas(coordenada22);
        double d24 = carro1.getPrecoBase();
        Carro carro29 = new Carro();
        carro29.setMatricula("");
        Carro carro32 = carro29.clone();
        carro29.setPrecoBase((double) 0L);
        Carro carro35 = new Carro();
        int i36 = carro35.getLugares();
        int i37 = carro29.compareTo((Veiculo) carro35);
        java.lang.String str38 = carro35.toString();
        Coordenada coordenada39 = carro35.getCoordenadas();
        Carro carro41 = new Carro((int) ' ', (double) 100.0f, (int) (byte) -1, "", coordenada39, false);
        double d42 = carro41.getPrecoBase();
        Carro carro43 = carro41.clone();
        boolean b44 = carro1.equals((java.lang.Object) carro43);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro29 and carro41", (carro29.compareTo(carro41) == 0) == carro29.equals(carro41));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test094");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        java.lang.String str2 = carro0.getMatricula();
        Carro carro3 = new Carro(carro0);
        carro0.setOcupado(true);
        double d6 = carro0.getPrecoBase();
        java.lang.String str7 = carro0.getMatricula();
        Carro carro8 = new Carro();
        int i9 = carro8.getLugares();
        carro8.setVelocidadeMedia(10);
        Carro carro12 = carro8.clone();
        boolean b13 = carro8.getOcupado();
        double d14 = carro8.getPrecoBase();
        int i15 = carro8.getFiabilidade();
        boolean b16 = carro0.equals((java.lang.Object) carro8);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro12 and carro3", (carro12.compareTo(carro3) == 0) == carro12.equals(carro3));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test095");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro3.setOcupado(true);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        carro6.setVelocidadeMedia(10);
        int i10 = carro3.compareTo((Veiculo) carro6);
        carro6.setMatricula("Matrícula: Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 100km/h\nPreço Base: 1.0€\nFiabilidade: 0\nLugares: 4\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro3 and carro0", (carro3.compareTo(carro0) == 0) == carro3.equals(carro0));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test096");
        Carro carro8 = new Carro();
        carro8.setMatricula("");
        Carro carro11 = carro8.clone();
        carro8.setPrecoBase((double) 0L);
        Carro carro14 = new Carro();
        int i15 = carro14.getLugares();
        int i16 = carro8.compareTo((Veiculo) carro14);
        java.lang.String str17 = carro14.toString();
        Coordenada coordenada18 = carro14.getCoordenadas();
        Carro carro20 = new Carro((int) ' ', (double) 100.0f, (int) (byte) -1, "", coordenada18, false);
        Carro carro22 = new Carro((int) ' ', (double) ' ', 0, "", coordenada18, false);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro11 and carro20", (carro11.compareTo(carro20) == 0) == carro11.equals(carro20));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test097");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carro0.getCoordenadas();
        carro0.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carro0.setFiabilidade(0);
        int i10 = carro0.getVelocidadeMedia();
        Carro carro11 = new Carro();
        Carro carro12 = new Carro();
        Carro carro13 = new Carro(carro12);
        int i14 = carro13.getFiabilidade();
        Coordenada coordenada15 = carro13.getCoordenadas();
        carro11.setCoordenadas(coordenada15);
        boolean b17 = carro0.equals((java.lang.Object) carro11);
        Carro carro18 = new Carro();
        carro18.setMatricula("");
        Carro carro21 = carro18.clone();
        carro21.setOcupado(true);
        int i24 = carro21.getLugares();
        Carro carro25 = new Carro(carro21);
        int i26 = carro0.compareTo((Veiculo) carro21);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro18 and carro25", (carro18.compareTo(carro25) == 0) == carro18.equals(carro25));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test098");
        Carro carro8 = new Carro();
        carro8.setMatricula("");
        Carro carro11 = carro8.clone();
        carro8.setPrecoBase((double) 0L);
        Carro carro14 = new Carro();
        int i15 = carro14.getLugares();
        int i16 = carro8.compareTo((Veiculo) carro14);
        java.lang.String str17 = carro14.toString();
        Coordenada coordenada18 = carro14.getCoordenadas();
        Carro carro20 = new Carro((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, false);
        Carro carro22 = new Carro((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, true);
        carro22.setFiabilidade(0);
        carro22.setPrecoBase((double) 1.0f);
        Carro carro27 = new Carro();
        carro27.setMatricula("");
        Carro carro30 = carro27.clone();
        carro27.setPrecoBase((double) 0L);
        Carro carro33 = new Carro();
        int i34 = carro33.getLugares();
        int i35 = carro27.compareTo((Veiculo) carro33);
        java.lang.String str36 = carro33.toString();
        int i37 = carro33.getFiabilidade();
        carro33.setPrecoBase(10.0d);
        Carro carro40 = carro33.clone();
        int i41 = carro22.compareTo((Veiculo) carro40);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro14 and carro33", (carro14.compareTo(carro33) == 0) == carro14.equals(carro33));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test099");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Carro carro5 = new Carro(carro0);
        double d6 = carro0.getPrecoBase();
        boolean b7 = carro0.getOcupado();
        int i8 = carro0.getVelocidadeMedia();
        Carro carro9 = carro0.clone();
        carro9.setFiabilidade((int) (byte) 10);
        Carro carro12 = new Carro();
        carro12.setMatricula("");
        Carro carro15 = carro12.clone();
        carro12.setPrecoBase((double) 0L);
        Carro carro18 = new Carro(carro12);
        carro18.setPrecoBase((double) (-1.0f));
        double d21 = carro18.getPrecoBase();
        boolean b22 = carro9.equals((java.lang.Object) d21);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro12 and carro18", (carro12.compareTo(carro18) == 0) == carro12.equals(carro18));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test100");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        java.lang.String str2 = carro0.toString();
        carro0.setFiabilidade(0);
        Carro carro5 = carro0.clone();
        Carro carro6 = new Carro();
        Carro carro7 = new Carro(carro6);
        Carro carro8 = new Carro(carro7);
        Carro carro9 = new Carro();
        Carro carro10 = new Carro(carro9);
        int i11 = carro7.compareTo((Veiculo) carro9);
        Carro carro12 = new Carro();
        carro12.setMatricula("");
        boolean b16 = carro12.equals((java.lang.Object) (-1.0d));
        boolean b17 = carro7.equals((java.lang.Object) (-1.0d));
        Carro carro18 = new Carro();
        carro18.setMatricula("");
        Carro carro21 = carro18.clone();
        carro18.setPrecoBase((double) 0L);
        Carro carro24 = new Carro();
        int i25 = carro24.getLugares();
        int i26 = carro18.compareTo((Veiculo) carro24);
        java.lang.String str27 = carro24.toString();
        Coordenada coordenada28 = carro24.getCoordenadas();
        carro7.setCoordenadas(coordenada28);
        carro0.setCoordenadas(coordenada28);
        carro0.setPrecoBase(100.0d);
        Carro carro33 = new Carro(carro0);
        Coordenada coordenada34 = carro0.getCoordenadas();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro10 and carro33", (carro10.compareTo(carro33) == 0) == carro10.equals(carro33));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test101");
        Carro carro16 = new Carro();
        carro16.setMatricula("");
        Carro carro19 = carro16.clone();
        carro16.setPrecoBase((double) 0L);
        Carro carro22 = new Carro();
        int i23 = carro22.getLugares();
        int i24 = carro16.compareTo((Veiculo) carro22);
        java.lang.String str25 = carro22.toString();
        Coordenada coordenada26 = carro22.getCoordenadas();
        Carro carro28 = new Carro((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada26, false);
        Carro carro30 = new Carro((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada26, true);
        Carro carro32 = new Carro((int) '#', 10.0d, (-1), "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada26, true);
        Coordenada coordenada33 = carro32.getCoordenadas();
        Carro carro35 = new Carro((int) '4', (double) (byte) 1, 0, "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada33, true);
        Carro carro36 = new Carro();
        carro36.setMatricula("");
        boolean b40 = carro36.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada41 = carro36.getCoordenadas();
        carro36.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carro36.setFiabilidade(0);
        Carro carro46 = new Carro();
        carro46.setMatricula("");
        Carro carro49 = carro46.clone();
        carro46.setPrecoBase((double) 0L);
        Carro carro52 = new Carro(carro46);
        int i53 = carro36.compareTo((Veiculo) carro46);
        Carro carro54 = new Carro(carro46);
        Coordenada coordenada55 = carro54.getCoordenadas();
        carro35.setCoordenadas(coordenada55);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro36 and carro28", (carro36.compareTo(carro28) == 0) == carro36.equals(carro28));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test102");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        java.lang.String str9 = carro6.toString();
        Coordenada coordenada10 = carro6.getCoordenadas();
        carro6.setFiabilidade((int) (byte) 1);
        Carro carro13 = new Carro();
        int i14 = carro13.getLugares();
        carro13.setVelocidadeMedia(10);
        Carro carro17 = carro13.clone();
        boolean b18 = carro6.equals((java.lang.Object) carro13);
        Carro carro19 = new Carro();
        carro19.setMatricula("");
        Carro carro22 = carro19.clone();
        carro19.setPrecoBase((double) 0L);
        Carro carro25 = new Carro();
        int i26 = carro25.getLugares();
        int i27 = carro19.compareTo((Veiculo) carro25);
        java.lang.String str28 = carro25.toString();
        int i29 = carro25.getFiabilidade();
        carro25.setPrecoBase(10.0d);
        int i32 = carro25.getVelocidadeMedia();
        Carro carro37 = new Carro();
        Carro carro38 = new Carro(carro37);
        Carro carro39 = new Carro(carro38);
        Carro carro40 = new Carro();
        Carro carro41 = new Carro(carro40);
        int i42 = carro38.compareTo((Veiculo) carro40);
        Carro carro43 = new Carro();
        carro43.setMatricula("");
        boolean b47 = carro43.equals((java.lang.Object) (-1.0d));
        boolean b48 = carro38.equals((java.lang.Object) (-1.0d));
        Carro carro49 = new Carro();
        carro49.setMatricula("");
        Carro carro52 = carro49.clone();
        carro49.setPrecoBase((double) 0L);
        Carro carro55 = new Carro();
        int i56 = carro55.getLugares();
        int i57 = carro49.compareTo((Veiculo) carro55);
        java.lang.String str58 = carro55.toString();
        Coordenada coordenada59 = carro55.getCoordenadas();
        carro38.setCoordenadas(coordenada59);
        Carro carro62 = new Carro((-1), 10.0d, (int) (byte) 1, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada59, true);
        carro25.setCoordenadas(coordenada59);
        carro6.setCoordenadas(coordenada59);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro40 and carro13", (carro40.compareTo(carro13) == 0) == carro40.equals(carro13));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test103");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setVelocidadeMedia((int) '4');
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        carro6.setVelocidadeMedia(10);
        carro6.setMatricula("n/a");
        Carro carro12 = new Carro();
        carro12.setMatricula("");
        Carro carro15 = carro12.clone();
        carro12.setPrecoBase((double) 0L);
        Carro carro18 = new Carro();
        int i19 = carro18.getLugares();
        int i20 = carro12.compareTo((Veiculo) carro18);
        java.lang.String str21 = carro18.toString();
        Coordenada coordenada22 = carro18.getCoordenadas();
        Carro carro23 = new Carro();
        int i24 = carro23.getLugares();
        Coordenada coordenada25 = carro23.getCoordenadas();
        carro18.setCoordenadas(coordenada25);
        carro6.setCoordenadas(coordenada25);
        Carro carro28 = new Carro();
        carro28.setMatricula("");
        boolean b32 = carro28.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada33 = carro28.getCoordenadas();
        carro6.setCoordenadas(coordenada33);
        carro0.setCoordenadas(coordenada33);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro18 and carro6", (carro18.compareTo(carro6) == 0) == carro18.equals(carro6));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test104");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        java.lang.String str2 = carro0.toString();
        carro0.setFiabilidade(0);
        Carro carro5 = carro0.clone();
        Carro carro6 = new Carro();
        Carro carro7 = new Carro(carro6);
        Carro carro8 = new Carro(carro7);
        Carro carro9 = new Carro();
        Carro carro10 = new Carro(carro9);
        int i11 = carro7.compareTo((Veiculo) carro9);
        Carro carro12 = new Carro();
        carro12.setMatricula("");
        boolean b16 = carro12.equals((java.lang.Object) (-1.0d));
        boolean b17 = carro7.equals((java.lang.Object) (-1.0d));
        Carro carro18 = new Carro();
        carro18.setMatricula("");
        Carro carro21 = carro18.clone();
        carro18.setPrecoBase((double) 0L);
        Carro carro24 = new Carro();
        int i25 = carro24.getLugares();
        int i26 = carro18.compareTo((Veiculo) carro24);
        java.lang.String str27 = carro24.toString();
        Coordenada coordenada28 = carro24.getCoordenadas();
        carro7.setCoordenadas(coordenada28);
        carro0.setCoordenadas(coordenada28);
        carro0.setPrecoBase(100.0d);
        Coordenada coordenada33 = carro0.getCoordenadas();
        Carro carro34 = new Carro();
        Carro carro35 = new Carro(carro34);
        Carro carro36 = new Carro(carro35);
        Carro carro37 = new Carro();
        Carro carro38 = new Carro(carro37);
        int i39 = carro35.compareTo((Veiculo) carro37);
        Carro carro40 = new Carro();
        carro40.setMatricula("");
        boolean b44 = carro40.equals((java.lang.Object) (-1.0d));
        boolean b45 = carro35.equals((java.lang.Object) (-1.0d));
        Carro carro46 = new Carro();
        carro46.setMatricula("");
        Carro carro49 = carro46.clone();
        carro46.setPrecoBase((double) 0L);
        Carro carro52 = new Carro();
        int i53 = carro52.getLugares();
        int i54 = carro46.compareTo((Veiculo) carro52);
        java.lang.String str55 = carro52.toString();
        Coordenada coordenada56 = carro52.getCoordenadas();
        carro35.setCoordenadas(coordenada56);
        carro35.setVelocidadeMedia((-145));
        boolean b60 = carro0.equals((java.lang.Object) (-145));
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro9 and carro35", (carro9.compareTo(carro35) == 0) == carro9.equals(carro35));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test105");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carro0.getCoordenadas();
        carro0.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carro0.setFiabilidade(0);
        carro0.setVelocidadeMedia((int) (short) -1);
        double d12 = carro0.getPrecoBase();
        Carro carro13 = new Carro();
        Carro carro14 = new Carro(carro13);
        Carro carro15 = new Carro(carro14);
        Carro carro16 = new Carro();
        Carro carro17 = new Carro(carro16);
        int i18 = carro14.compareTo((Veiculo) carro16);
        Carro carro19 = new Carro();
        carro19.setMatricula("");
        boolean b23 = carro19.equals((java.lang.Object) (-1.0d));
        boolean b24 = carro14.equals((java.lang.Object) (-1.0d));
        Carro carro25 = new Carro();
        carro25.setMatricula("");
        Carro carro28 = carro25.clone();
        carro25.setPrecoBase((double) 0L);
        Carro carro31 = new Carro();
        int i32 = carro31.getLugares();
        int i33 = carro25.compareTo((Veiculo) carro31);
        java.lang.String str34 = carro31.toString();
        Coordenada coordenada35 = carro31.getCoordenadas();
        carro14.setCoordenadas(coordenada35);
        carro14.setVelocidadeMedia((-145));
        Coordenada coordenada39 = carro14.getCoordenadas();
        carro0.setCoordenadas(coordenada39);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro17 and carro14", (carro17.compareTo(carro14) == 0) == carro17.equals(carro14));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test106");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        carro0.setMatricula("n/a");
        Carro carro6 = new Carro();
        carro6.setMatricula("");
        Carro carro9 = carro6.clone();
        carro6.setPrecoBase((double) 0L);
        Carro carro12 = new Carro();
        int i13 = carro12.getLugares();
        int i14 = carro6.compareTo((Veiculo) carro12);
        java.lang.String str15 = carro12.toString();
        Coordenada coordenada16 = carro12.getCoordenadas();
        Carro carro17 = new Carro();
        int i18 = carro17.getLugares();
        Coordenada coordenada19 = carro17.getCoordenadas();
        carro12.setCoordenadas(coordenada19);
        carro0.setCoordenadas(coordenada19);
        Carro carro22 = new Carro();
        carro22.setMatricula("");
        boolean b26 = carro22.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada27 = carro22.getCoordenadas();
        carro0.setCoordenadas(coordenada27);
        Carro carro29 = new Carro();
        carro29.setMatricula("");
        boolean b33 = carro29.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada34 = carro29.getCoordenadas();
        java.lang.String str35 = carro29.toString();
        double d36 = carro29.getPrecoBase();
        boolean b37 = carro0.equals((java.lang.Object) d36);
        carro0.setMatricula("Matrícula: hi!\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: -1\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Carro carro40 = new Carro();
        int i41 = carro40.getLugares();
        carro40.setVelocidadeMedia(10);
        carro40.setMatricula("n/a");
        Carro carro46 = new Carro();
        carro46.setMatricula("");
        Carro carro49 = carro46.clone();
        carro46.setPrecoBase((double) 0L);
        Carro carro52 = new Carro();
        int i53 = carro52.getLugares();
        int i54 = carro46.compareTo((Veiculo) carro52);
        java.lang.String str55 = carro52.toString();
        Coordenada coordenada56 = carro52.getCoordenadas();
        Carro carro57 = new Carro();
        int i58 = carro57.getLugares();
        Coordenada coordenada59 = carro57.getCoordenadas();
        carro52.setCoordenadas(coordenada59);
        carro40.setCoordenadas(coordenada59);
        Carro carro62 = new Carro();
        carro62.setMatricula("");
        boolean b66 = carro62.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada67 = carro62.getCoordenadas();
        carro40.setCoordenadas(coordenada67);
        java.lang.String str69 = carro40.getMatricula();
        boolean b70 = carro0.equals((java.lang.Object) str69);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro52 and carro40", (carro52.compareTo(carro40) == 0) == carro52.equals(carro40));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test107");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro(carro0);
        carro6.setPrecoBase((double) (-1.0f));
        carro6.setVelocidadeMedia((int) (short) 0);
        carro6.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Carro carro13 = new Carro(carro6);
        carro6.setPrecoBase(1.0d);
        Carro carro16 = new Carro();
        carro16.setMatricula("");
        boolean b20 = carro16.equals((java.lang.Object) (-1.0d));
        Carro carro21 = new Carro(carro16);
        double d22 = carro16.getPrecoBase();
        boolean b23 = carro16.getOcupado();
        int i24 = carro16.getVelocidadeMedia();
        Carro carro25 = carro16.clone();
        carro25.setFiabilidade((int) (byte) 10);
        carro25.setFiabilidade((int) (short) -1);
        int i30 = carro6.compareTo((Veiculo) carro25);
        Carro carro31 = new Carro(carro25);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro6 and carro13", (carro6.compareTo(carro13) == 0) == carro6.equals(carro13));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test108");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carro0.getCoordenadas();
        carro0.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Carro carro8 = new Carro(carro0);
        carro0.setOcupado(false);
        Coordenada coordenada11 = carro0.getCoordenadas();
        java.lang.String str12 = carro0.toString();
        Carro carro13 = new Carro();
        int i14 = carro13.getLugares();
        carro13.setVelocidadeMedia(10);
        carro13.setMatricula("n/a");
        Carro carro19 = new Carro();
        carro19.setMatricula("");
        Carro carro22 = carro19.clone();
        carro19.setPrecoBase((double) 0L);
        Carro carro25 = new Carro();
        int i26 = carro25.getLugares();
        int i27 = carro19.compareTo((Veiculo) carro25);
        java.lang.String str28 = carro25.toString();
        Coordenada coordenada29 = carro25.getCoordenadas();
        Carro carro30 = new Carro();
        int i31 = carro30.getLugares();
        Coordenada coordenada32 = carro30.getCoordenadas();
        carro25.setCoordenadas(coordenada32);
        carro13.setCoordenadas(coordenada32);
        Carro carro35 = new Carro();
        carro35.setMatricula("");
        boolean b39 = carro35.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada40 = carro35.getCoordenadas();
        carro13.setCoordenadas(coordenada40);
        Coordenada coordenada42 = carro13.getCoordenadas();
        carro0.setCoordenadas(coordenada42);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro30 and carro13", (carro30.compareTo(carro13) == 0) == carro30.equals(carro13));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test109");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        Carro carro4 = new Carro(carro3);
        int i5 = carro1.compareTo((Veiculo) carro3);
        int i6 = carro3.getVelocidadeMedia();
        Carro carro7 = carro3.clone();
        int i8 = carro7.getFiabilidade();
        int i9 = carro7.getFiabilidade();
        Carro carro10 = new Carro(carro7);
        Carro carro11 = new Carro();
        carro11.setMatricula("");
        Carro carro14 = carro11.clone();
        Coordenada coordenada15 = carro14.getCoordenadas();
        Carro carro16 = new Carro();
        carro16.setMatricula("");
        Carro carro19 = carro16.clone();
        carro16.setPrecoBase((double) 0L);
        Carro carro22 = new Carro();
        int i23 = carro22.getLugares();
        int i24 = carro16.compareTo((Veiculo) carro22);
        java.lang.String str25 = carro22.toString();
        Coordenada coordenada26 = carro22.getCoordenadas();
        int i27 = carro14.compareTo((Veiculo) carro22);
        Carro carro28 = new Carro();
        carro28.setMatricula("");
        Carro carro31 = carro28.clone();
        carro28.setPrecoBase((double) 0L);
        java.lang.String str34 = carro28.getMatricula();
        Coordenada coordenada35 = carro28.getCoordenadas();
        carro14.setCoordenadas(coordenada35);
        carro14.setFiabilidade((int) (short) -1);
        int i39 = carro7.compareTo((Veiculo) carro14);
        Carro carro40 = carro7.clone();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro14 and carro11", (carro14.compareTo(carro11) == 0) == carro14.equals(carro11));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test110");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro3.setOcupado(true);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        carro6.setVelocidadeMedia(10);
        int i10 = carro3.compareTo((Veiculo) carro6);
        Carro carro11 = carro3.clone();
        int i12 = carro3.getLugares();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro0 and carro11", (carro0.compareTo(carro11) == 0) == carro0.equals(carro11));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test111");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        java.lang.String str2 = carro0.toString();
        carro0.setFiabilidade(0);
        Carro carro13 = new Carro();
        carro13.setMatricula("");
        boolean b17 = carro13.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada18 = carro13.getCoordenadas();
        carro13.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carro13.setFiabilidade(0);
        Carro carro23 = new Carro();
        carro23.setMatricula("");
        Carro carro26 = carro23.clone();
        carro23.setPrecoBase((double) 0L);
        Carro carro29 = new Carro(carro23);
        int i30 = carro13.compareTo((Veiculo) carro23);
        Carro carro31 = new Carro(carro23);
        Coordenada coordenada32 = carro31.getCoordenadas();
        Carro carro34 = new Carro((int) (byte) 0, (double) 0L, (int) (byte) 0, "n/a", coordenada32, true);
        Coordenada coordenada35 = carro34.getCoordenadas();
        Carro carro37 = new Carro(52, (double) 3, (int) (byte) 0, "hi!", coordenada35, true);
        carro0.setCoordenadas(coordenada35);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro1 and carro34", (carro1.compareTo(carro34) == 0) == carro1.equals(carro34));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test112");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        carro0.setMatricula("n/a");
        Carro carro6 = new Carro();
        carro6.setMatricula("");
        Carro carro9 = carro6.clone();
        carro6.setPrecoBase((double) 0L);
        Carro carro12 = new Carro();
        int i13 = carro12.getLugares();
        int i14 = carro6.compareTo((Veiculo) carro12);
        java.lang.String str15 = carro12.toString();
        Coordenada coordenada16 = carro12.getCoordenadas();
        Carro carro17 = new Carro();
        int i18 = carro17.getLugares();
        Coordenada coordenada19 = carro17.getCoordenadas();
        carro12.setCoordenadas(coordenada19);
        carro0.setCoordenadas(coordenada19);
        Carro carro22 = new Carro();
        carro22.setMatricula("");
        boolean b26 = carro22.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada27 = carro22.getCoordenadas();
        carro0.setCoordenadas(coordenada27);
        Carro carro29 = new Carro();
        carro29.setMatricula("");
        boolean b33 = carro29.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada34 = carro29.getCoordenadas();
        java.lang.String str35 = carro29.toString();
        double d36 = carro29.getPrecoBase();
        boolean b37 = carro0.equals((java.lang.Object) d36);
        carro0.setVelocidadeMedia((int) (byte) 1);
        Carro carro40 = new Carro();
        carro40.setMatricula("");
        boolean b44 = carro40.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada45 = carro40.getCoordenadas();
        carro40.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carro40.setFiabilidade(0);
        int i50 = carro40.getFiabilidade();
        int i51 = carro0.compareTo((Veiculo) carro40);
        java.lang.String str52 = carro40.getMatricula();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro17 and carro0", (carro17.compareTo(carro0) == 0) == carro17.equals(carro0));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test113");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        java.lang.String str2 = carro0.getMatricula();
        Carro carro3 = new Carro(carro0);
        carro0.setOcupado(true);
        java.lang.String str6 = carro0.toString();
        Carro carro7 = new Carro();
        int i8 = carro7.getLugares();
        java.lang.String str9 = carro7.getMatricula();
        Carro carro10 = new Carro(carro7);
        int i11 = carro7.getVelocidadeMedia();
        int i12 = carro0.compareTo((Veiculo) carro7);
        int i13 = carro7.getLugares();
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro10 and carro0", (carro10.compareTo(carro0) == 0) == carro10.equals(carro0));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test114");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro3.setOcupado(true);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        carro6.setVelocidadeMedia(10);
        int i10 = carro3.compareTo((Veiculo) carro6);
        Coordenada coordenada11 = carro3.getCoordenadas();
        int i12 = carro3.getVelocidadeMedia();
        Carro carro17 = new Carro();
        carro17.setMatricula("");
        Carro carro20 = carro17.clone();
        carro17.setPrecoBase((double) 0L);
        Carro carro23 = new Carro();
        int i24 = carro23.getLugares();
        int i25 = carro17.compareTo((Veiculo) carro23);
        java.lang.String str26 = carro23.toString();
        Coordenada coordenada27 = carro23.getCoordenadas();
        Carro carro29 = new Carro((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada27, false);
        carro29.setPrecoBase((double) 10.0f);
        boolean b32 = carro3.equals((java.lang.Object) 10.0f);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro23 and carro6", (carro23.compareTo(carro6) == 0) == carro23.equals(carro6));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test115");
        Carro carro8 = new Carro();
        carro8.setMatricula("");
        boolean b12 = carro8.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada13 = carro8.getCoordenadas();
        boolean b14 = carro8.getOcupado();
        java.lang.String str15 = carro8.getMatricula();
        Carro carro20 = new Carro();
        carro20.setMatricula("");
        Carro carro23 = carro20.clone();
        carro20.setPrecoBase((double) 0L);
        Carro carro26 = new Carro();
        int i27 = carro26.getLugares();
        int i28 = carro20.compareTo((Veiculo) carro26);
        java.lang.String str29 = carro26.toString();
        Coordenada coordenada30 = carro26.getCoordenadas();
        Carro carro32 = new Carro((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada30, false);
        carro8.setCoordenadas(coordenada30);
        Carro carro35 = new Carro(32, (double) (short) 1, (int) (byte) 1, "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada30, true);
        Carro carro37 = new Carro(4, (-1.0d), (int) ' ', "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 10.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada30, true);
        Carro carro38 = new Carro();
        Carro carro39 = new Carro(carro38);
        carro38.setPrecoBase((double) (byte) 10);
        carro38.setFiabilidade((-3));
        boolean b44 = carro37.equals((java.lang.Object) (-3));
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro39 and carro38", (carro39.compareTo(carro38) == 0) == carro39.equals(carro38));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test116");
        Carro carro8 = new Carro();
        carro8.setMatricula("");
        Carro carro11 = carro8.clone();
        carro8.setPrecoBase((double) 0L);
        Carro carro14 = new Carro();
        int i15 = carro14.getLugares();
        int i16 = carro8.compareTo((Veiculo) carro14);
        java.lang.String str17 = carro14.toString();
        Coordenada coordenada18 = carro14.getCoordenadas();
        Carro carro20 = new Carro((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, false);
        Carro carro22 = new Carro((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, true);
        Carro carro23 = new Carro();
        carro23.setVelocidadeMedia((int) ' ');
        java.lang.String str26 = carro23.toString();
        boolean b27 = carro22.equals((java.lang.Object) carro23);
        carro23.setVelocidadeMedia(32);
        Coordenada coordenada30 = carro23.getCoordenadas();
        Carro carro31 = new Carro();
        carro31.setMatricula("");
        boolean b35 = carro31.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada36 = carro31.getCoordenadas();
        carro31.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Carro carro39 = new Carro(carro31);
        boolean b40 = carro23.equals((java.lang.Object) carro39);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro20 and carro31", (carro20.compareTo(carro31) == 0) == carro20.equals(carro31));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test117");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        java.lang.String str3 = carro0.toString();
        Carro carro4 = new Carro();
        Carro carro5 = new Carro(carro4);
        java.lang.String str6 = carro4.toString();
        carro4.setFiabilidade(0);
        Carro carro9 = carro4.clone();
        Carro carro10 = new Carro();
        Carro carro11 = new Carro(carro10);
        Carro carro12 = new Carro(carro11);
        Carro carro13 = new Carro();
        Carro carro14 = new Carro(carro13);
        int i15 = carro11.compareTo((Veiculo) carro13);
        Carro carro16 = new Carro();
        carro16.setMatricula("");
        boolean b20 = carro16.equals((java.lang.Object) (-1.0d));
        boolean b21 = carro11.equals((java.lang.Object) (-1.0d));
        Carro carro22 = new Carro();
        carro22.setMatricula("");
        Carro carro25 = carro22.clone();
        carro22.setPrecoBase((double) 0L);
        Carro carro28 = new Carro();
        int i29 = carro28.getLugares();
        int i30 = carro22.compareTo((Veiculo) carro28);
        java.lang.String str31 = carro28.toString();
        Coordenada coordenada32 = carro28.getCoordenadas();
        carro11.setCoordenadas(coordenada32);
        carro4.setCoordenadas(coordenada32);
        carro0.setCoordenadas(coordenada32);
        Carro carro36 = new Carro();
        Carro carro37 = new Carro(carro36);
        java.lang.String str38 = carro36.toString();
        carro36.setFiabilidade(0);
        int i41 = carro36.getFiabilidade();
        Carro carro42 = new Carro(carro36);
        Carro carro43 = carro36.clone();
        carro36.setOcupado(false);
        Carro carro46 = new Carro();
        carro46.setMatricula("");
        Carro carro49 = carro46.clone();
        carro46.setPrecoBase((double) 0L);
        java.lang.String str52 = carro46.getMatricula();
        Coordenada coordenada53 = carro46.getCoordenadas();
        carro36.setCoordenadas(coordenada53);
        carro0.setCoordenadas(coordenada53);
        Carro carro56 = new Carro();
        int i57 = carro56.getLugares();
        carro56.setVelocidadeMedia(10);
        Carro carro60 = new Carro(carro56);
        int i61 = carro56.getVelocidadeMedia();
        carro56.setMatricula("");
        int i64 = carro56.getFiabilidade();
        int i65 = carro56.getVelocidadeMedia();
        carro56.setVelocidadeMedia((-142));
        boolean b68 = carro0.equals((java.lang.Object) (-142));
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro14 and carro60", (carro14.compareTo(carro60) == 0) == carro14.equals(carro60));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test118");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = new Carro();
        int i4 = carro3.getLugares();
        java.lang.String str5 = carro3.getMatricula();
        Carro carro6 = new Carro(carro3);
        carro6.setVelocidadeMedia((int) '4');
        int i9 = carro0.compareTo((Veiculo) carro6);
        Carro carro10 = new Carro();
        int i11 = carro10.getLugares();
        Coordenada coordenada12 = carro10.getCoordenadas();
        Carro carro13 = new Carro();
        Carro carro14 = new Carro(carro13);
        java.lang.String str15 = carro13.toString();
        carro13.setFiabilidade(0);
        Carro carro18 = carro13.clone();
        int i19 = carro13.getLugares();
        Carro carro24 = new Carro();
        Carro carro25 = new Carro(carro24);
        Carro carro26 = new Carro(carro25);
        Carro carro27 = new Carro();
        Carro carro28 = new Carro(carro27);
        int i29 = carro25.compareTo((Veiculo) carro27);
        Carro carro30 = new Carro();
        carro30.setMatricula("");
        boolean b34 = carro30.equals((java.lang.Object) (-1.0d));
        boolean b35 = carro25.equals((java.lang.Object) (-1.0d));
        Carro carro36 = new Carro();
        carro36.setMatricula("");
        Carro carro39 = carro36.clone();
        carro36.setPrecoBase((double) 0L);
        Carro carro42 = new Carro();
        int i43 = carro42.getLugares();
        int i44 = carro36.compareTo((Veiculo) carro42);
        java.lang.String str45 = carro42.toString();
        Coordenada coordenada46 = carro42.getCoordenadas();
        carro25.setCoordenadas(coordenada46);
        Carro carro49 = new Carro((-1), 10.0d, (int) (byte) 1, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada46, true);
        carro13.setCoordenadas(coordenada46);
        int i51 = carro10.compareTo((Veiculo) carro13);
        int i52 = carro10.getFiabilidade();
        Coordenada coordenada53 = carro10.getCoordenadas();
        carro0.setCoordenadas(coordenada53);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro14 and carro6", (carro14.compareTo(carro6) == 0) == carro14.equals(carro6));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test119");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        java.lang.String str9 = carro6.toString();
        int i10 = carro6.getFiabilidade();
        Carro carro11 = new Carro();
        Carro carro12 = new Carro(carro11);
        java.lang.String str13 = carro11.toString();
        carro11.setFiabilidade(0);
        Carro carro16 = carro11.clone();
        int i17 = carro16.getFiabilidade();
        Coordenada coordenada18 = carro16.getCoordenadas();
        carro6.setCoordenadas(coordenada18);
        Carro carro20 = new Carro();
        carro20.setMatricula("");
        Carro carro23 = carro20.clone();
        carro20.setPrecoBase((double) 0L);
        Carro carro26 = new Carro();
        int i27 = carro26.getLugares();
        int i28 = carro20.compareTo((Veiculo) carro26);
        int i29 = carro26.getFiabilidade();
        Carro carro30 = carro26.clone();
        Coordenada coordenada31 = carro30.getCoordenadas();
        boolean b32 = carro6.equals((java.lang.Object) carro30);
        Carro carro33 = carro30.clone();
        Carro carro38 = new Carro();
        carro38.setMatricula("");
        Carro carro41 = carro38.clone();
        carro38.setPrecoBase((double) 0L);
        Carro carro44 = new Carro();
        int i45 = carro44.getLugares();
        int i46 = carro38.compareTo((Veiculo) carro44);
        java.lang.String str47 = carro44.toString();
        Coordenada coordenada48 = carro44.getCoordenadas();
        Carro carro50 = new Carro(10, (double) (short) -1, (int) (byte) 1, "", coordenada48, false);
        carro30.setCoordenadas(coordenada48);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro23 and carro50", (carro23.compareTo(carro50) == 0) == carro23.equals(carro50));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test120");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        Carro carro4 = new Carro(carro0);
        int i5 = carro0.getVelocidadeMedia();
        java.lang.String str6 = carro0.getMatricula();
        carro0.setVelocidadeMedia((int) (byte) 1);
        carro0.setOcupado(false);
        carro0.setOcupado(false);
        Carro carro13 = new Carro();
        carro13.setMatricula("");
        Carro carro16 = carro13.clone();
        carro13.setPrecoBase((double) 0L);
        Carro carro19 = new Carro();
        int i20 = carro19.getLugares();
        int i21 = carro13.compareTo((Veiculo) carro19);
        java.lang.String str22 = carro19.toString();
        int i23 = carro19.getVelocidadeMedia();
        java.lang.String str24 = carro19.getMatricula();
        java.lang.String str25 = carro19.toString();
        boolean b26 = carro0.equals((java.lang.Object) carro19);
        carro19.setPrecoBase((double) ' ');
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro0 and carro4", (carro0.compareTo(carro4) == 0) == carro0.equals(carro4));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test121");
        Carro carro4 = new Carro();
        carro4.setMatricula("");
        boolean b8 = carro4.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada9 = carro4.getCoordenadas();
        int i10 = carro4.getVelocidadeMedia();
        Carro carro11 = new Carro();
        carro11.setMatricula("");
        Carro carro14 = carro11.clone();
        carro14.setOcupado(true);
        boolean b17 = carro4.equals((java.lang.Object) carro14);
        carro14.setMatricula("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Carro carro20 = new Carro();
        Carro carro21 = new Carro(carro20);
        java.lang.String str22 = carro20.toString();
        carro20.setFiabilidade(0);
        Carro carro25 = carro20.clone();
        int i26 = carro20.getLugares();
        Carro carro31 = new Carro();
        Carro carro32 = new Carro(carro31);
        Carro carro33 = new Carro(carro32);
        Carro carro34 = new Carro();
        Carro carro35 = new Carro(carro34);
        int i36 = carro32.compareTo((Veiculo) carro34);
        Carro carro37 = new Carro();
        carro37.setMatricula("");
        boolean b41 = carro37.equals((java.lang.Object) (-1.0d));
        boolean b42 = carro32.equals((java.lang.Object) (-1.0d));
        Carro carro43 = new Carro();
        carro43.setMatricula("");
        Carro carro46 = carro43.clone();
        carro43.setPrecoBase((double) 0L);
        Carro carro49 = new Carro();
        int i50 = carro49.getLugares();
        int i51 = carro43.compareTo((Veiculo) carro49);
        java.lang.String str52 = carro49.toString();
        Coordenada coordenada53 = carro49.getCoordenadas();
        carro32.setCoordenadas(coordenada53);
        Carro carro56 = new Carro((-1), 10.0d, (int) (byte) 1, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada53, true);
        carro20.setCoordenadas(coordenada53);
        carro14.setCoordenadas(coordenada53);
        Carro carro60 = new Carro((-145), (double) 1.0f, (int) (byte) -1, "Matrícula: Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 97.0€\nFiabilidade: 1\nLugares: 4\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada53, true);
        Carro carro61 = new Carro(carro60);
        Carro carro66 = new Carro();
        carro66.setMatricula("");
        Carro carro69 = carro66.clone();
        carro66.setPrecoBase((double) 0L);
        Carro carro72 = new Carro();
        int i73 = carro72.getLugares();
        int i74 = carro66.compareTo((Veiculo) carro72);
        java.lang.String str75 = carro72.toString();
        Coordenada coordenada76 = carro72.getCoordenadas();
        Carro carro78 = new Carro((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada76, false);
        carro78.setPrecoBase((double) 10.0f);
        boolean b81 = carro60.equals((java.lang.Object) 10.0f);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro78 and carro56", (carro78.compareTo(carro56) == 0) == carro78.equals(carro56));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest0.test122");
        Carro carro4 = new Carro();
        int i5 = carro4.getLugares();
        carro4.setVelocidadeMedia(10);
        carro4.setMatricula("n/a");
        Carro carro10 = new Carro();
        carro10.setMatricula("");
        Carro carro13 = carro10.clone();
        carro10.setPrecoBase((double) 0L);
        Carro carro16 = new Carro();
        int i17 = carro16.getLugares();
        int i18 = carro10.compareTo((Veiculo) carro16);
        java.lang.String str19 = carro16.toString();
        Coordenada coordenada20 = carro16.getCoordenadas();
        Carro carro21 = new Carro();
        int i22 = carro21.getLugares();
        Coordenada coordenada23 = carro21.getCoordenadas();
        carro16.setCoordenadas(coordenada23);
        carro4.setCoordenadas(coordenada23);
        Carro carro26 = new Carro();
        carro26.setMatricula("");
        boolean b30 = carro26.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada31 = carro26.getCoordenadas();
        carro4.setCoordenadas(coordenada31);
        Coordenada coordenada33 = carro4.getCoordenadas();
        Coordenada coordenada34 = carro4.getCoordenadas();
        Carro carro36 = new Carro((int) (byte) 10, (double) 100L, (int) (short) 0, "Matrícula: Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 52km/h\nPreço Base: 1.0€\nFiabilidade: 0\nLugares: 4\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n", coordenada34, true);
        org.junit.Assert.assertTrue("Contract failed: compareTo-equals on carro21 and carro4", (carro21.compareTo(carro4) == 0) == carro21.equals(carro4));
    }
}

