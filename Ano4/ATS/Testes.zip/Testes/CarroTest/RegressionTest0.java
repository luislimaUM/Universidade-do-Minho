import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        Coordenada coordenada4 = null;
        try {
            Carro carro6 = new Carro((int) (short) -1, (double) (short) 100, (int) '4', "hi!", coordenada4, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        Coordenada coordenada4 = null;
        try {
            Carro carro6 = new Carro(1, 100.0d, (int) (byte) 0, "hi!", coordenada4, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        Coordenada coordenada4 = null;
        try {
            Carro carro6 = new Carro((int) 'a', (double) 10, 100, "hi!", coordenada4, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        Coordenada coordenada4 = null;
        try {
            Carro carro6 = new Carro(0, (double) 100, 100, "", coordenada4, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        Coordenada coordenada4 = null;
        try {
            Carro carro6 = new Carro((int) (byte) -1, (double) 1.0f, 10, "", coordenada4, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Coordenada coordenada3 = null;
        try {
            carro2.setCoordenadas(coordenada3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        Carro carro4 = new Carro();
        carro4.setMatricula("");
        Carro carro7 = carro4.clone();
        Coordenada coordenada8 = carro7.getCoordenadas();
        Carro carro10 = new Carro((int) (byte) 0, (double) 'a', 3, "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada8, false);
        java.lang.Object obj11 = null;
        boolean b12 = carro10.equals(obj11);
        org.junit.Assert.assertNotNull(carro7);
        org.junit.Assert.assertNotNull(coordenada8);
        org.junit.Assert.assertTrue(b12 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        carro0.setFiabilidade((int) (byte) 0);
        Veiculo veiculo6 = null;
        try {
            int i7 = carro0.compareTo(veiculo6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        int i4 = carro3.getLugares();
        boolean b5 = carro2.equals((java.lang.Object) carro3);
        carro3.setOcupado(true);
        boolean b8 = carro3.getOcupado();
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue(b5 == true);
        org.junit.Assert.assertTrue(b8 == true);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        carro0.setPrecoBase((double) (byte) 10);
        java.lang.String str4 = carro0.getMatricula();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "n/a" + "'", str4.equals("n/a"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro(carro0);
        carro6.setPrecoBase((double) (-1.0f));
        carro6.setVelocidadeMedia((int) (short) 0);
        carro6.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        java.lang.String str13 = carro6.getMatricula();
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str13.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        carro0.setOcupado(false);
        carro0.setMatricula("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        Carro carro0 = new Carro();
        java.lang.String str1 = carro0.toString();
        int i2 = carro0.getFiabilidade();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str1.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i2 == 0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Carro carro5 = new Carro(carro0);
        double d6 = carro0.getPrecoBase();
        boolean b7 = carro0.getOcupado();
        int i8 = carro0.getVelocidadeMedia();
        Carro carro9 = carro0.clone();
        int i10 = carro0.getLugares();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(b7 == false);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertNotNull(carro9);
        org.junit.Assert.assertTrue(i10 == 0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        Coordenada coordenada4 = null;
        try {
            Carro carro6 = new Carro(3, (-1.0d), (int) (short) -1, "", coordenada4, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        java.lang.String str2 = carro0.toString();
        carro0.setFiabilidade(0);
        Carro carro5 = carro0.clone();
        Carro carro6 = new Carro();
        Carro carro7 = new Carro(carro6);
        Carro carro8 = new Carro(carro7);
        Carro carro9 = new Carro();
        Carro carro10 = new Carro(carro9);
        int i11 = carro7.compareTo((Veiculo) carro9);
        Carro carro12 = new Carro();
        carro12.setMatricula("");
        boolean b16 = carro12.equals((java.lang.Object) (-1.0d));
        boolean b17 = carro7.equals((java.lang.Object) (-1.0d));
        Carro carro18 = new Carro();
        carro18.setMatricula("");
        Carro carro21 = carro18.clone();
        carro18.setPrecoBase((double) 0L);
        Carro carro24 = new Carro();
        int i25 = carro24.getLugares();
        int i26 = carro18.compareTo((Veiculo) carro24);
        java.lang.String str27 = carro24.toString();
        Coordenada coordenada28 = carro24.getCoordenadas();
        carro7.setCoordenadas(coordenada28);
        carro0.setCoordenadas(coordenada28);
        carro0.setMatricula("hi!");
        carro0.setOcupado(true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro5);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(b16 == false);
        org.junit.Assert.assertTrue(b17 == false);
        org.junit.Assert.assertNotNull(carro21);
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue(i26 == 3);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str27.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada28);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        Coordenada coordenada4 = carro3.getCoordenadas();
        Carro carro5 = new Carro();
        carro5.setMatricula("");
        Carro carro8 = carro5.clone();
        carro5.setPrecoBase((double) 0L);
        Carro carro11 = new Carro();
        int i12 = carro11.getLugares();
        int i13 = carro5.compareTo((Veiculo) carro11);
        java.lang.String str14 = carro11.toString();
        Coordenada coordenada15 = carro11.getCoordenadas();
        int i16 = carro3.compareTo((Veiculo) carro11);
        java.lang.String str17 = carro3.getMatricula();
        carro3.setMatricula("");
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertNotNull(coordenada4);
        org.junit.Assert.assertNotNull(carro8);
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertTrue(i13 == 3);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str14.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada15);
        org.junit.Assert.assertTrue(i16 == 3);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        Carro carro0 = new Carro();
        java.lang.String str1 = carro0.toString();
        double d2 = carro0.getPrecoBase();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str1.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(d2 == 0.0d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        java.lang.String str2 = carro0.getMatricula();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "n/a" + "'", str2.equals("n/a"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        java.lang.String str2 = carro0.toString();
        carro0.setFiabilidade(0);
        Carro carro5 = carro0.clone();
        Carro carro6 = new Carro();
        Carro carro7 = new Carro(carro6);
        Carro carro8 = new Carro(carro7);
        Carro carro9 = new Carro();
        Carro carro10 = new Carro(carro9);
        int i11 = carro7.compareTo((Veiculo) carro9);
        Carro carro12 = new Carro();
        carro12.setMatricula("");
        boolean b16 = carro12.equals((java.lang.Object) (-1.0d));
        boolean b17 = carro7.equals((java.lang.Object) (-1.0d));
        Carro carro18 = new Carro();
        carro18.setMatricula("");
        Carro carro21 = carro18.clone();
        carro18.setPrecoBase((double) 0L);
        Carro carro24 = new Carro();
        int i25 = carro24.getLugares();
        int i26 = carro18.compareTo((Veiculo) carro24);
        java.lang.String str27 = carro24.toString();
        Coordenada coordenada28 = carro24.getCoordenadas();
        carro7.setCoordenadas(coordenada28);
        carro0.setCoordenadas(coordenada28);
        carro0.setPrecoBase(100.0d);
        double d33 = carro0.getPrecoBase();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro5);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(b16 == false);
        org.junit.Assert.assertTrue(b17 == false);
        org.junit.Assert.assertNotNull(carro21);
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue(i26 == 3);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str27.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada28);
        org.junit.Assert.assertTrue(d33 == 100.0d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        Carro carro4 = new Carro(carro0);
        java.lang.String str5 = carro4.toString();
        carro4.setFiabilidade(3);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str5.equals("Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        Coordenada coordenada4 = carro3.getCoordenadas();
        Carro carro5 = new Carro();
        carro5.setMatricula("");
        Carro carro8 = carro5.clone();
        carro5.setPrecoBase((double) 0L);
        Carro carro11 = new Carro();
        int i12 = carro11.getLugares();
        int i13 = carro5.compareTo((Veiculo) carro11);
        java.lang.String str14 = carro11.toString();
        Coordenada coordenada15 = carro11.getCoordenadas();
        int i16 = carro3.compareTo((Veiculo) carro11);
        Carro carro17 = new Carro();
        Carro carro18 = new Carro(carro17);
        java.lang.String str19 = carro17.toString();
        carro17.setFiabilidade(0);
        Carro carro22 = carro17.clone();
        int i23 = carro17.getLugares();
        Carro carro28 = new Carro();
        Carro carro29 = new Carro(carro28);
        Carro carro30 = new Carro(carro29);
        Carro carro31 = new Carro();
        Carro carro32 = new Carro(carro31);
        int i33 = carro29.compareTo((Veiculo) carro31);
        Carro carro34 = new Carro();
        carro34.setMatricula("");
        boolean b38 = carro34.equals((java.lang.Object) (-1.0d));
        boolean b39 = carro29.equals((java.lang.Object) (-1.0d));
        Carro carro40 = new Carro();
        carro40.setMatricula("");
        Carro carro43 = carro40.clone();
        carro40.setPrecoBase((double) 0L);
        Carro carro46 = new Carro();
        int i47 = carro46.getLugares();
        int i48 = carro40.compareTo((Veiculo) carro46);
        java.lang.String str49 = carro46.toString();
        Coordenada coordenada50 = carro46.getCoordenadas();
        carro29.setCoordenadas(coordenada50);
        Carro carro53 = new Carro((-1), 10.0d, (int) (byte) 1, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada50, true);
        carro17.setCoordenadas(coordenada50);
        carro11.setCoordenadas(coordenada50);
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertNotNull(coordenada4);
        org.junit.Assert.assertNotNull(carro8);
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertTrue(i13 == 3);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str14.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada15);
        org.junit.Assert.assertTrue(i16 == 3);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str19.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro22);
        org.junit.Assert.assertTrue(i23 == 0);
        org.junit.Assert.assertTrue(i33 == 0);
        org.junit.Assert.assertTrue(b38 == false);
        org.junit.Assert.assertTrue(b39 == false);
        org.junit.Assert.assertNotNull(carro43);
        org.junit.Assert.assertTrue(i47 == 0);
        org.junit.Assert.assertTrue(i48 == 3);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str49.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada50);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        java.lang.String str9 = carro6.toString();
        Coordenada coordenada10 = carro6.getCoordenadas();
        Carro carro11 = new Carro();
        int i12 = carro11.getLugares();
        Coordenada coordenada13 = carro11.getCoordenadas();
        carro6.setCoordenadas(coordenada13);
        Carro carro15 = new Carro(carro6);
        java.lang.String str16 = carro15.toString();
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertNotNull(coordenada13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str16.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        java.lang.String str2 = carro0.toString();
        carro0.setFiabilidade(0);
        Carro carro5 = carro0.clone();
        carro0.setFiabilidade((int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro5);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        Carro carro0 = null;
        try {
            Carro carro1 = new Carro(carro0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        int i3 = carro2.getLugares();
        org.junit.Assert.assertTrue(i3 == 0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        Carro carro4 = new Carro();
        Carro carro5 = new Carro(carro4);
        Carro carro6 = new Carro(carro5);
        Carro carro7 = new Carro();
        Carro carro8 = new Carro(carro7);
        int i9 = carro5.compareTo((Veiculo) carro7);
        Carro carro10 = new Carro();
        carro10.setMatricula("");
        boolean b14 = carro10.equals((java.lang.Object) (-1.0d));
        boolean b15 = carro5.equals((java.lang.Object) (-1.0d));
        Carro carro16 = new Carro();
        carro16.setMatricula("");
        Carro carro19 = carro16.clone();
        carro16.setPrecoBase((double) 0L);
        Carro carro22 = new Carro();
        int i23 = carro22.getLugares();
        int i24 = carro16.compareTo((Veiculo) carro22);
        java.lang.String str25 = carro22.toString();
        Coordenada coordenada26 = carro22.getCoordenadas();
        carro5.setCoordenadas(coordenada26);
        Carro carro29 = new Carro((-1), 10.0d, (int) (byte) 1, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada26, true);
        Veiculo veiculo30 = null;
        try {
            int i31 = carro29.compareTo(veiculo30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertNotNull(carro19);
        org.junit.Assert.assertTrue(i23 == 0);
        org.junit.Assert.assertTrue(i24 == 3);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str25.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada26);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        java.lang.String str2 = carro0.toString();
        carro0.setFiabilidade(0);
        Carro carro5 = carro0.clone();
        Carro carro6 = new Carro(carro0);
        Carro carro7 = new Carro();
        carro7.setMatricula("");
        Carro carro10 = carro7.clone();
        Coordenada coordenada11 = carro10.getCoordenadas();
        carro6.setCoordenadas(coordenada11);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro5);
        org.junit.Assert.assertNotNull(carro10);
        org.junit.Assert.assertNotNull(coordenada11);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        Carro carro4 = new Carro(carro3);
        int i5 = carro1.compareTo((Veiculo) carro3);
        Carro carro6 = new Carro(carro3);
        carro6.setOcupado(true);
        org.junit.Assert.assertTrue(i5 == 0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carro0.getCoordenadas();
        boolean b6 = carro0.getOcupado();
        java.lang.String str7 = carro0.getMatricula();
        int i8 = carro0.getFiabilidade();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(b6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i8 == 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        Carro carro4 = new Carro();
        carro4.setMatricula("");
        Carro carro7 = carro4.clone();
        carro4.setPrecoBase((double) 0L);
        Carro carro10 = new Carro();
        int i11 = carro10.getLugares();
        int i12 = carro4.compareTo((Veiculo) carro10);
        java.lang.String str13 = carro10.toString();
        Coordenada coordenada14 = carro10.getCoordenadas();
        Carro carro16 = new Carro(10, (double) (short) -1, (int) (byte) 1, "", coordenada14, false);
        int i17 = carro16.getLugares();
        org.junit.Assert.assertNotNull(carro7);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(i12 == 3);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str13.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada14);
        org.junit.Assert.assertTrue(i17 == 4);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        java.lang.String str2 = carro0.toString();
        carro0.setFiabilidade(0);
        Carro carro5 = carro0.clone();
        Carro carro6 = new Carro();
        Carro carro7 = new Carro(carro6);
        Carro carro8 = new Carro(carro7);
        Carro carro9 = new Carro();
        Carro carro10 = new Carro(carro9);
        int i11 = carro7.compareTo((Veiculo) carro9);
        Carro carro12 = new Carro();
        carro12.setMatricula("");
        boolean b16 = carro12.equals((java.lang.Object) (-1.0d));
        boolean b17 = carro7.equals((java.lang.Object) (-1.0d));
        Carro carro18 = new Carro();
        carro18.setMatricula("");
        Carro carro21 = carro18.clone();
        carro18.setPrecoBase((double) 0L);
        Carro carro24 = new Carro();
        int i25 = carro24.getLugares();
        int i26 = carro18.compareTo((Veiculo) carro24);
        java.lang.String str27 = carro24.toString();
        Coordenada coordenada28 = carro24.getCoordenadas();
        carro7.setCoordenadas(coordenada28);
        carro0.setCoordenadas(coordenada28);
        carro0.setMatricula("hi!");
        boolean b33 = carro0.getOcupado();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro5);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(b16 == false);
        org.junit.Assert.assertTrue(b17 == false);
        org.junit.Assert.assertNotNull(carro21);
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue(i26 == 3);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str27.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada28);
        org.junit.Assert.assertTrue(b33 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        Carro carro4 = new Carro(carro0);
        Carro carro5 = carro4.clone();
        boolean b6 = carro4.getOcupado();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(carro5);
        org.junit.Assert.assertTrue(b6 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carro0.getCoordenadas();
        int i6 = carro0.getVelocidadeMedia();
        Carro carro7 = new Carro();
        carro7.setMatricula("");
        Carro carro10 = carro7.clone();
        carro10.setOcupado(true);
        boolean b13 = carro0.equals((java.lang.Object) carro10);
        carro10.setMatricula("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        boolean b16 = carro10.getOcupado();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertNotNull(carro10);
        org.junit.Assert.assertTrue(b13 == false);
        org.junit.Assert.assertTrue(b16 == true);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        Carro carro4 = new Carro(carro3);
        int i5 = carro1.compareTo((Veiculo) carro3);
        Carro carro6 = new Carro(carro3);
        int i7 = carro3.getFiabilidade();
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(i7 == 0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        Carro carro9 = new Carro(carro6);
        Carro carro10 = new Carro();
        Carro carro11 = new Carro(carro10);
        Carro carro12 = new Carro(carro11);
        Carro carro13 = new Carro();
        Carro carro14 = new Carro(carro13);
        int i15 = carro11.compareTo((Veiculo) carro13);
        int i16 = carro13.getVelocidadeMedia();
        int i17 = carro9.compareTo((Veiculo) carro13);
        int i18 = carro13.getLugares();
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue(i15 == 0);
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue(i17 == 0);
        org.junit.Assert.assertTrue(i18 == 0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carro0.getCoordenadas();
        java.lang.String str6 = carro0.getMatricula();
        Carro carro11 = new Carro();
        carro11.setMatricula("");
        Carro carro14 = carro11.clone();
        carro11.setPrecoBase((double) 0L);
        Carro carro17 = new Carro();
        int i18 = carro17.getLugares();
        int i19 = carro11.compareTo((Veiculo) carro17);
        java.lang.String str20 = carro17.toString();
        Coordenada coordenada21 = carro17.getCoordenadas();
        Carro carro23 = new Carro((int) (byte) -1, 0.0d, (int) 'a', "", coordenada21, true);
        int i24 = carro0.compareTo((Veiculo) carro23);
        int i25 = carro23.getLugares();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(carro14);
        org.junit.Assert.assertTrue(i18 == 0);
        org.junit.Assert.assertTrue(i19 == 3);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str20.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada21);
        org.junit.Assert.assertTrue(i24 == 0);
        org.junit.Assert.assertTrue(i25 == 4);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        carro0.setVelocidadeMedia((int) ' ');
        org.junit.Assert.assertNotNull(carro3);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        Carro carro4 = new Carro(carro3);
        int i5 = carro1.compareTo((Veiculo) carro3);
        int i6 = carro3.getVelocidadeMedia();
        Carro carro7 = carro3.clone();
        int i8 = carro7.getFiabilidade();
        int i9 = carro7.getFiabilidade();
        Carro carro10 = new Carro(carro7);
        carro10.setOcupado(false);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertNotNull(carro7);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue(i9 == 0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        int i4 = carro3.getLugares();
        boolean b5 = carro2.equals((java.lang.Object) carro3);
        boolean b6 = carro3.getOcupado();
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue(b5 == true);
        org.junit.Assert.assertTrue(b6 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Carro carro5 = new Carro(carro0);
        double d6 = carro0.getPrecoBase();
        carro0.setVelocidadeMedia((int) (byte) 100);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        Carro carro4 = new Carro(carro0);
        Carro carro5 = carro4.clone();
        int i6 = carro4.getLugares();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(carro5);
        org.junit.Assert.assertTrue(i6 == 0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        java.lang.String str9 = carro6.toString();
        int i10 = carro6.getFiabilidade();
        Carro carro11 = new Carro();
        Carro carro12 = new Carro(carro11);
        Carro carro13 = new Carro(carro12);
        Carro carro14 = new Carro();
        Carro carro15 = new Carro(carro14);
        int i16 = carro12.compareTo((Veiculo) carro14);
        Carro carro17 = new Carro();
        carro17.setMatricula("");
        boolean b21 = carro17.equals((java.lang.Object) (-1.0d));
        boolean b22 = carro12.equals((java.lang.Object) (-1.0d));
        Carro carro23 = new Carro();
        carro23.setMatricula("");
        Carro carro26 = carro23.clone();
        carro23.setPrecoBase((double) 0L);
        Carro carro29 = new Carro();
        int i30 = carro29.getLugares();
        int i31 = carro23.compareTo((Veiculo) carro29);
        java.lang.String str32 = carro29.toString();
        Coordenada coordenada33 = carro29.getCoordenadas();
        carro12.setCoordenadas(coordenada33);
        boolean b35 = carro6.equals((java.lang.Object) carro12);
        int i36 = carro6.getLugares();
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue(b21 == false);
        org.junit.Assert.assertTrue(b22 == false);
        org.junit.Assert.assertNotNull(carro26);
        org.junit.Assert.assertTrue(i30 == 0);
        org.junit.Assert.assertTrue(i31 == 3);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str32.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada33);
        org.junit.Assert.assertTrue(b35 == true);
        org.junit.Assert.assertTrue(i36 == 0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carro0.getCoordenadas();
        carro0.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carro0.setFiabilidade(0);
        Carro carro10 = new Carro();
        carro10.setMatricula("");
        Carro carro13 = carro10.clone();
        carro10.setPrecoBase((double) 0L);
        Carro carro16 = new Carro(carro10);
        int i17 = carro0.compareTo((Veiculo) carro10);
        Carro carro18 = new Carro(carro10);
        Coordenada coordenada19 = carro10.getCoordenadas();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertNotNull(carro13);
        org.junit.Assert.assertTrue(i17 == (-142));
        org.junit.Assert.assertNotNull(coordenada19);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        java.lang.String str9 = carro6.toString();
        Coordenada coordenada10 = carro6.getCoordenadas();
        carro6.setFiabilidade((int) (byte) 1);
        Carro carro13 = new Carro();
        int i14 = carro13.getLugares();
        carro13.setVelocidadeMedia(10);
        Carro carro17 = carro13.clone();
        boolean b18 = carro6.equals((java.lang.Object) carro13);
        carro6.setOcupado(true);
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertNotNull(carro17);
        org.junit.Assert.assertTrue(b18 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        java.lang.String str2 = carro0.getMatricula();
        Carro carro3 = new Carro(carro0);
        Veiculo veiculo4 = null;
        try {
            int i5 = carro0.compareTo(veiculo4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "n/a" + "'", str2.equals("n/a"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        Carro carro8 = new Carro();
        carro8.setMatricula("");
        Carro carro11 = carro8.clone();
        carro8.setPrecoBase((double) 0L);
        Carro carro14 = new Carro();
        int i15 = carro14.getLugares();
        int i16 = carro8.compareTo((Veiculo) carro14);
        java.lang.String str17 = carro14.toString();
        Coordenada coordenada18 = carro14.getCoordenadas();
        Carro carro20 = new Carro((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, false);
        Carro carro22 = new Carro((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, true);
        int i23 = carro22.getVelocidadeMedia();
        org.junit.Assert.assertNotNull(carro11);
        org.junit.Assert.assertTrue(i15 == 0);
        org.junit.Assert.assertTrue(i16 == 3);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str17.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada18);
        org.junit.Assert.assertTrue(i23 == (-142));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        java.lang.String str9 = carro6.toString();
        Coordenada coordenada10 = carro6.getCoordenadas();
        carro6.setMatricula("hi!");
        carro6.setPrecoBase((double) (-1.0f));
        double d15 = carro6.getPrecoBase();
        carro6.setPrecoBase((double) 0);
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertTrue(d15 == (-1.0d));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        Coordenada coordenada2 = carro0.getCoordenadas();
        int i3 = carro0.getLugares();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(coordenada2);
        org.junit.Assert.assertTrue(i3 == 0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        int i4 = carro3.getLugares();
        boolean b5 = carro2.equals((java.lang.Object) carro3);
        carro3.setPrecoBase(0.0d);
        int i8 = carro3.getLugares();
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue(b5 == true);
        org.junit.Assert.assertTrue(i8 == 0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        java.lang.String str9 = carro6.toString();
        Coordenada coordenada10 = carro6.getCoordenadas();
        carro6.setFiabilidade((int) (byte) 1);
        int i13 = carro6.getFiabilidade();
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertTrue(i13 == 1);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        int i4 = carro3.getLugares();
        boolean b5 = carro2.equals((java.lang.Object) carro3);
        Carro carro6 = carro3.clone();
        carro6.setVelocidadeMedia((int) (short) 0);
        Carro carro9 = new Carro();
        Carro carro10 = new Carro(carro9);
        Carro carro11 = new Carro(carro10);
        Carro carro12 = new Carro();
        int i13 = carro12.getLugares();
        boolean b14 = carro11.equals((java.lang.Object) carro12);
        Carro carro15 = carro12.clone();
        carro15.setOcupado(true);
        boolean b18 = carro6.equals((java.lang.Object) carro15);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue(b5 == true);
        org.junit.Assert.assertNotNull(carro6);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(b14 == true);
        org.junit.Assert.assertNotNull(carro15);
        org.junit.Assert.assertTrue(b18 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Carro carro5 = new Carro(carro0);
        double d6 = carro0.getPrecoBase();
        java.lang.String str7 = carro0.toString();
        int i8 = carro0.getVelocidadeMedia();
        int i9 = carro0.getVelocidadeMedia();
        carro0.setMatricula("n/a");
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str7.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue(i9 == 0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Carro carro5 = new Carro(carro0);
        int i6 = carro5.getVelocidadeMedia();
        double d7 = carro5.getPrecoBase();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertTrue(d7 == 0.0d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        java.lang.String str2 = carro0.toString();
        carro0.setFiabilidade(0);
        Carro carro5 = carro0.clone();
        Carro carro6 = new Carro();
        Carro carro7 = new Carro(carro6);
        Carro carro8 = new Carro(carro7);
        Carro carro9 = new Carro();
        Carro carro10 = new Carro(carro9);
        int i11 = carro7.compareTo((Veiculo) carro9);
        Carro carro12 = new Carro();
        carro12.setMatricula("");
        boolean b16 = carro12.equals((java.lang.Object) (-1.0d));
        boolean b17 = carro7.equals((java.lang.Object) (-1.0d));
        Carro carro18 = new Carro();
        carro18.setMatricula("");
        Carro carro21 = carro18.clone();
        carro18.setPrecoBase((double) 0L);
        Carro carro24 = new Carro();
        int i25 = carro24.getLugares();
        int i26 = carro18.compareTo((Veiculo) carro24);
        java.lang.String str27 = carro24.toString();
        Coordenada coordenada28 = carro24.getCoordenadas();
        carro7.setCoordenadas(coordenada28);
        carro0.setCoordenadas(coordenada28);
        carro0.setPrecoBase(100.0d);
        carro0.setMatricula("Matrícula: Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: -1.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        java.lang.String str35 = carro0.getMatricula();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro5);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(b16 == false);
        org.junit.Assert.assertTrue(b17 == false);
        org.junit.Assert.assertNotNull(carro21);
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue(i26 == 3);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str27.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada28);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Matrícula: Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: -1.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str35.equals("Matrícula: Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: -1.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Carro carro5 = new Carro(carro0);
        double d6 = carro0.getPrecoBase();
        boolean b7 = carro0.getOcupado();
        carro0.setVelocidadeMedia(10);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(b7 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        Carro carro4 = new Carro(carro3);
        int i5 = carro1.compareTo((Veiculo) carro3);
        Carro carro6 = new Carro();
        carro6.setMatricula("");
        boolean b10 = carro6.equals((java.lang.Object) (-1.0d));
        boolean b11 = carro1.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada12 = carro1.getCoordenadas();
        carro1.setPrecoBase((double) 1L);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertNotNull(coordenada12);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        java.lang.String str4 = carro0.getMatricula();
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        java.lang.String str9 = carro6.toString();
        Coordenada coordenada10 = carro6.getCoordenadas();
        carro6.setFiabilidade((int) (byte) 1);
        Carro carro13 = new Carro();
        int i14 = carro13.getLugares();
        carro13.setVelocidadeMedia(10);
        Carro carro17 = carro13.clone();
        boolean b18 = carro6.equals((java.lang.Object) carro13);
        carro6.setVelocidadeMedia((-1));
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertNotNull(carro17);
        org.junit.Assert.assertTrue(b18 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        Carro carro4 = new Carro(carro3);
        int i5 = carro1.compareTo((Veiculo) carro3);
        Carro carro6 = new Carro();
        carro6.setMatricula("");
        boolean b10 = carro6.equals((java.lang.Object) (-1.0d));
        boolean b11 = carro1.equals((java.lang.Object) (-1.0d));
        Carro carro12 = new Carro();
        carro12.setMatricula("");
        Carro carro15 = carro12.clone();
        carro12.setPrecoBase((double) 0L);
        Carro carro18 = new Carro();
        int i19 = carro18.getLugares();
        int i20 = carro12.compareTo((Veiculo) carro18);
        java.lang.String str21 = carro18.toString();
        Coordenada coordenada22 = carro18.getCoordenadas();
        carro1.setCoordenadas(coordenada22);
        java.lang.String str24 = carro1.getMatricula();
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertNotNull(carro15);
        org.junit.Assert.assertTrue(i19 == 0);
        org.junit.Assert.assertTrue(i20 == 3);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str21.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "n/a" + "'", str24.equals("n/a"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        int i4 = carro3.getVelocidadeMedia();
        int i5 = carro3.getVelocidadeMedia();
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue(i5 == 0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro(carro0);
        int i7 = carro0.getFiabilidade();
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        java.lang.String str9 = carro6.toString();
        int i10 = carro6.getFiabilidade();
        Carro carro11 = new Carro();
        Carro carro12 = new Carro(carro11);
        Carro carro13 = new Carro(carro12);
        Carro carro14 = new Carro();
        Carro carro15 = new Carro(carro14);
        int i16 = carro12.compareTo((Veiculo) carro14);
        Carro carro17 = new Carro();
        carro17.setMatricula("");
        boolean b21 = carro17.equals((java.lang.Object) (-1.0d));
        boolean b22 = carro12.equals((java.lang.Object) (-1.0d));
        Carro carro23 = new Carro();
        carro23.setMatricula("");
        Carro carro26 = carro23.clone();
        carro23.setPrecoBase((double) 0L);
        Carro carro29 = new Carro();
        int i30 = carro29.getLugares();
        int i31 = carro23.compareTo((Veiculo) carro29);
        java.lang.String str32 = carro29.toString();
        Coordenada coordenada33 = carro29.getCoordenadas();
        carro12.setCoordenadas(coordenada33);
        boolean b35 = carro6.equals((java.lang.Object) carro12);
        boolean b37 = carro6.equals((java.lang.Object) "n/a");
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue(b21 == false);
        org.junit.Assert.assertTrue(b22 == false);
        org.junit.Assert.assertNotNull(carro26);
        org.junit.Assert.assertTrue(i30 == 0);
        org.junit.Assert.assertTrue(i31 == 3);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str32.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada33);
        org.junit.Assert.assertTrue(b35 == true);
        org.junit.Assert.assertTrue(b37 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        java.lang.String str3 = carro0.toString();
        java.lang.Object obj4 = null;
        boolean b5 = carro0.equals(obj4);
        double d6 = carro0.getPrecoBase();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(b5 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        Carro carro4 = new Carro(carro3);
        int i5 = carro1.compareTo((Veiculo) carro3);
        int i6 = carro3.getVelocidadeMedia();
        Carro carro7 = carro3.clone();
        carro7.setVelocidadeMedia(32);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertNotNull(carro7);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        double d6 = carro0.getPrecoBase();
        carro0.setFiabilidade((int) ' ');
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(d6 == 0.0d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        Carro carro4 = carro0.clone();
        boolean b5 = carro0.getOcupado();
        int i6 = carro0.getVelocidadeMedia();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(carro4);
        org.junit.Assert.assertTrue(b5 == false);
        org.junit.Assert.assertTrue(i6 == 10);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        Carro carro0 = new Carro();
        carro0.setVelocidadeMedia((int) ' ');
        java.lang.String str3 = carro0.toString();
        Carro carro8 = new Carro();
        carro8.setMatricula("");
        Carro carro11 = carro8.clone();
        Coordenada coordenada12 = carro11.getCoordenadas();
        Carro carro14 = new Carro((int) (byte) 0, (double) 'a', 3, "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada12, false);
        boolean b15 = carro0.equals((java.lang.Object) 'a');
        carro0.setOcupado(false);
        double d18 = carro0.getPrecoBase();
        Carro carro19 = new Carro();
        carro19.setMatricula("");
        boolean b23 = carro19.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada24 = carro19.getCoordenadas();
        carro19.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Carro carro27 = new Carro(carro19);
        int i28 = carro0.compareTo((Veiculo) carro19);
        int i29 = carro19.getVelocidadeMedia();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro11);
        org.junit.Assert.assertNotNull(coordenada12);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertTrue(d18 == 0.0d);
        org.junit.Assert.assertTrue(b23 == false);
        org.junit.Assert.assertNotNull(coordenada24);
        org.junit.Assert.assertTrue(i28 == (-33));
        org.junit.Assert.assertTrue(i29 == 0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        Carro carro4 = new Carro(carro3);
        int i5 = carro1.compareTo((Veiculo) carro3);
        Carro carro6 = new Carro(carro3);
        carro3.setPrecoBase((double) (short) 1);
        org.junit.Assert.assertTrue(i5 == 0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        Carro carro4 = new Carro(carro0);
        int i5 = carro0.getVelocidadeMedia();
        Carro carro6 = carro0.clone();
        carro0.setPrecoBase((double) 0);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i5 == 10);
        org.junit.Assert.assertNotNull(carro6);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        Carro carro12 = new Carro();
        carro12.setMatricula("");
        Carro carro15 = carro12.clone();
        carro12.setPrecoBase((double) 0L);
        Carro carro18 = new Carro();
        int i19 = carro18.getLugares();
        int i20 = carro12.compareTo((Veiculo) carro18);
        java.lang.String str21 = carro18.toString();
        Coordenada coordenada22 = carro18.getCoordenadas();
        Carro carro24 = new Carro((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada22, false);
        Carro carro26 = new Carro((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada22, true);
        Carro carro28 = new Carro((int) '#', 10.0d, (-1), "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada22, true);
        Coordenada coordenada29 = carro28.getCoordenadas();
        java.lang.String str30 = carro28.getMatricula();
        boolean b31 = carro28.getOcupado();
        org.junit.Assert.assertNotNull(carro15);
        org.junit.Assert.assertTrue(i19 == 0);
        org.junit.Assert.assertTrue(i20 == 3);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str21.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada22);
        org.junit.Assert.assertNotNull(coordenada29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str30.equals("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(b31 == true);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        int i4 = carro3.getVelocidadeMedia();
        Coordenada coordenada5 = carro3.getCoordenadas();
        Carro carro6 = new Carro();
        carro6.setMatricula("");
        Carro carro9 = carro6.clone();
        carro6.setPrecoBase((double) 0L);
        Carro carro12 = new Carro();
        int i13 = carro12.getLugares();
        int i14 = carro6.compareTo((Veiculo) carro12);
        java.lang.String str15 = carro12.toString();
        java.lang.String str16 = carro12.toString();
        boolean b17 = carro3.equals((java.lang.Object) str16);
        java.lang.String str18 = carro3.toString();
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertNotNull(carro9);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(i14 == 3);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str15.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str16.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(b17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str18.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        Carro carro4 = new Carro(carro3);
        int i5 = carro1.compareTo((Veiculo) carro3);
        Carro carro6 = new Carro();
        carro6.setMatricula("");
        boolean b10 = carro6.equals((java.lang.Object) (-1.0d));
        boolean b11 = carro1.equals((java.lang.Object) (-1.0d));
        boolean b12 = carro1.getOcupado();
        double d13 = carro1.getPrecoBase();
        Carro carro14 = new Carro();
        carro14.setMatricula("");
        Carro carro17 = carro14.clone();
        carro14.setPrecoBase((double) 0L);
        Carro carro20 = new Carro();
        int i21 = carro20.getLugares();
        int i22 = carro14.compareTo((Veiculo) carro20);
        Carro carro23 = new Carro(carro20);
        int i24 = carro23.getLugares();
        carro23.setPrecoBase((double) (-1));
        int i27 = carro1.compareTo((Veiculo) carro23);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertTrue(d13 == 0.0d);
        org.junit.Assert.assertNotNull(carro17);
        org.junit.Assert.assertTrue(i21 == 0);
        org.junit.Assert.assertTrue(i22 == 3);
        org.junit.Assert.assertTrue(i24 == 0);
        org.junit.Assert.assertTrue(i27 == 0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        int i4 = carro3.getVelocidadeMedia();
        java.lang.String str5 = carro3.toString();
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str5.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        Carro carro4 = new Carro(carro0);
        Carro carro5 = new Carro(carro4);
        int i6 = carro5.getLugares();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i6 == 0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carro0.getCoordenadas();
        carro0.setFiabilidade((int) ' ');
        int i8 = carro0.getLugares();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(i8 == 0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        Carro carro4 = new Carro(carro3);
        int i5 = carro1.compareTo((Veiculo) carro3);
        int i6 = carro3.getVelocidadeMedia();
        Carro carro7 = carro3.clone();
        int i8 = carro7.getFiabilidade();
        int i9 = carro7.getFiabilidade();
        carro7.setVelocidadeMedia(1);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertNotNull(carro7);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue(i9 == 0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        int i3 = carro0.getVelocidadeMedia();
        java.lang.String str4 = carro0.toString();
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str4.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        java.lang.String str9 = carro6.toString();
        int i10 = carro6.getFiabilidade();
        carro6.setPrecoBase(10.0d);
        int i13 = carro6.getVelocidadeMedia();
        Carro carro14 = new Carro(carro6);
        carro6.setVelocidadeMedia(1);
        int i17 = carro6.getLugares();
        double d18 = carro6.getPrecoBase();
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(i17 == 0);
        org.junit.Assert.assertTrue(d18 == 10.0d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = new Carro();
        int i4 = carro3.getLugares();
        java.lang.String str5 = carro3.getMatricula();
        Carro carro6 = new Carro(carro3);
        carro6.setVelocidadeMedia((int) '4');
        int i9 = carro0.compareTo((Veiculo) carro6);
        Carro carro10 = new Carro(carro6);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "n/a" + "'", str5.equals("n/a"));
        org.junit.Assert.assertTrue(i9 == 3);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        boolean b9 = carro6.getOcupado();
        carro6.setFiabilidade((-1));
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue(b9 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        Veiculo veiculo9 = null;
        try {
            int i10 = carro0.compareTo(veiculo9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        java.lang.String str2 = carro0.getMatricula();
        carro0.setMatricula("");
        Carro carro5 = new Carro();
        carro5.setVelocidadeMedia((int) ' ');
        java.lang.String str8 = carro5.toString();
        Carro carro13 = new Carro();
        carro13.setMatricula("");
        Carro carro16 = carro13.clone();
        Coordenada coordenada17 = carro16.getCoordenadas();
        Carro carro19 = new Carro((int) (byte) 0, (double) 'a', 3, "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada17, false);
        boolean b20 = carro5.equals((java.lang.Object) 'a');
        boolean b21 = carro0.equals((java.lang.Object) 'a');
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "n/a" + "'", str2.equals("n/a"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str8.equals("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro16);
        org.junit.Assert.assertNotNull(coordenada17);
        org.junit.Assert.assertTrue(b20 == false);
        org.junit.Assert.assertTrue(b21 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        int i4 = carro3.getFiabilidade();
        java.lang.String str5 = carro3.toString();
        carro3.setOcupado(false);
        double d8 = carro3.getPrecoBase();
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str5.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(d8 == 0.0d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        carro0.setMatricula("n/a");
        Carro carro6 = new Carro();
        carro6.setMatricula("");
        Carro carro9 = carro6.clone();
        carro6.setPrecoBase((double) 0L);
        Carro carro12 = new Carro();
        int i13 = carro12.getLugares();
        int i14 = carro6.compareTo((Veiculo) carro12);
        java.lang.String str15 = carro12.toString();
        Coordenada coordenada16 = carro12.getCoordenadas();
        Carro carro17 = new Carro();
        int i18 = carro17.getLugares();
        Coordenada coordenada19 = carro17.getCoordenadas();
        carro12.setCoordenadas(coordenada19);
        carro0.setCoordenadas(coordenada19);
        Carro carro22 = carro0.clone();
        Coordenada coordenada23 = null;
        try {
            carro22.setCoordenadas(coordenada23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(carro9);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(i14 == 3);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str15.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada16);
        org.junit.Assert.assertTrue(i18 == 0);
        org.junit.Assert.assertNotNull(coordenada19);
        org.junit.Assert.assertNotNull(carro22);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        Carro carro4 = new Carro(carro3);
        int i5 = carro1.compareTo((Veiculo) carro3);
        Carro carro6 = new Carro();
        carro6.setMatricula("");
        boolean b10 = carro6.equals((java.lang.Object) (-1.0d));
        boolean b11 = carro1.equals((java.lang.Object) (-1.0d));
        Carro carro12 = new Carro();
        carro12.setMatricula("");
        Carro carro15 = carro12.clone();
        carro12.setPrecoBase((double) 0L);
        Carro carro18 = new Carro();
        int i19 = carro18.getLugares();
        int i20 = carro12.compareTo((Veiculo) carro18);
        java.lang.String str21 = carro18.toString();
        Coordenada coordenada22 = carro18.getCoordenadas();
        carro1.setCoordenadas(coordenada22);
        carro1.setPrecoBase((double) (short) 10);
        java.lang.String str26 = carro1.toString();
        Carro carro27 = new Carro();
        carro27.setMatricula("");
        Carro carro30 = carro27.clone();
        carro27.setPrecoBase((double) 0L);
        Carro carro33 = new Carro();
        int i34 = carro33.getLugares();
        int i35 = carro27.compareTo((Veiculo) carro33);
        java.lang.String str36 = carro33.toString();
        Coordenada coordenada37 = carro33.getCoordenadas();
        carro33.setFiabilidade((int) (byte) 1);
        int i40 = carro1.compareTo((Veiculo) carro33);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertNotNull(carro15);
        org.junit.Assert.assertTrue(i19 == 0);
        org.junit.Assert.assertTrue(i20 == 3);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str21.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada22);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 10.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str26.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 10.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro30);
        org.junit.Assert.assertTrue(i34 == 0);
        org.junit.Assert.assertTrue(i35 == 3);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str36.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada37);
        org.junit.Assert.assertTrue(i40 == 0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carro0.getCoordenadas();
        boolean b6 = carro0.getOcupado();
        java.lang.String str7 = carro0.getMatricula();
        Carro carro12 = new Carro();
        carro12.setMatricula("");
        Carro carro15 = carro12.clone();
        carro12.setPrecoBase((double) 0L);
        Carro carro18 = new Carro();
        int i19 = carro18.getLugares();
        int i20 = carro12.compareTo((Veiculo) carro18);
        java.lang.String str21 = carro18.toString();
        Coordenada coordenada22 = carro18.getCoordenadas();
        Carro carro24 = new Carro((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada22, false);
        carro0.setCoordenadas(coordenada22);
        carro0.setOcupado(true);
        double d28 = carro0.getPrecoBase();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(b6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(carro15);
        org.junit.Assert.assertTrue(i19 == 0);
        org.junit.Assert.assertTrue(i20 == 3);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str21.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada22);
        org.junit.Assert.assertTrue(d28 == 0.0d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        Carro carro4 = new Carro(carro3);
        int i5 = carro1.compareTo((Veiculo) carro3);
        Carro carro6 = new Carro();
        carro6.setMatricula("");
        boolean b10 = carro6.equals((java.lang.Object) (-1.0d));
        boolean b11 = carro1.equals((java.lang.Object) (-1.0d));
        carro1.setVelocidadeMedia(52);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue(b11 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        Carro carro12 = new Carro();
        carro12.setMatricula("");
        Carro carro15 = carro12.clone();
        carro12.setPrecoBase((double) 0L);
        Carro carro18 = new Carro();
        int i19 = carro18.getLugares();
        int i20 = carro12.compareTo((Veiculo) carro18);
        java.lang.String str21 = carro18.toString();
        Coordenada coordenada22 = carro18.getCoordenadas();
        Carro carro24 = new Carro((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada22, false);
        Carro carro26 = new Carro((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada22, true);
        Carro carro28 = new Carro((int) '#', 10.0d, (-1), "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada22, true);
        Coordenada coordenada29 = carro28.getCoordenadas();
        java.lang.String str30 = carro28.getMatricula();
        carro28.setOcupado(true);
        org.junit.Assert.assertNotNull(carro15);
        org.junit.Assert.assertTrue(i19 == 0);
        org.junit.Assert.assertTrue(i20 == 3);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str21.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada22);
        org.junit.Assert.assertNotNull(coordenada29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str30.equals("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro(carro0);
        carro6.setPrecoBase((double) (-1.0f));
        carro6.setVelocidadeMedia((int) (short) 0);
        carro6.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Carro carro13 = new Carro(carro6);
        carro6.setPrecoBase(1.0d);
        carro6.setMatricula("");
        org.junit.Assert.assertNotNull(carro3);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        Carro carro4 = new Carro();
        carro4.setMatricula("");
        boolean b8 = carro4.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada9 = carro4.getCoordenadas();
        boolean b10 = carro4.getOcupado();
        java.lang.String str11 = carro4.getMatricula();
        Carro carro16 = new Carro();
        carro16.setMatricula("");
        Carro carro19 = carro16.clone();
        carro16.setPrecoBase((double) 0L);
        Carro carro22 = new Carro();
        int i23 = carro22.getLugares();
        int i24 = carro16.compareTo((Veiculo) carro22);
        java.lang.String str25 = carro22.toString();
        Coordenada coordenada26 = carro22.getCoordenadas();
        Carro carro28 = new Carro((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada26, false);
        carro4.setCoordenadas(coordenada26);
        Carro carro30 = new Carro();
        carro30.setMatricula("");
        Carro carro33 = carro30.clone();
        carro30.setPrecoBase((double) 0L);
        Carro carro36 = new Carro();
        int i37 = carro36.getLugares();
        int i38 = carro30.compareTo((Veiculo) carro36);
        int i39 = carro36.getFiabilidade();
        Carro carro40 = carro36.clone();
        Coordenada coordenada41 = carro40.getCoordenadas();
        carro4.setCoordenadas(coordenada41);
        Carro carro44 = new Carro(0, (double) (short) 0, (-145), "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada41, false);
        org.junit.Assert.assertTrue(b8 == false);
        org.junit.Assert.assertNotNull(coordenada9);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(carro19);
        org.junit.Assert.assertTrue(i23 == 0);
        org.junit.Assert.assertTrue(i24 == 3);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str25.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada26);
        org.junit.Assert.assertNotNull(carro33);
        org.junit.Assert.assertTrue(i37 == 0);
        org.junit.Assert.assertTrue(i38 == 3);
        org.junit.Assert.assertTrue(i39 == 0);
        org.junit.Assert.assertNotNull(carro40);
        org.junit.Assert.assertNotNull(coordenada41);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro(carro0);
        carro6.setFiabilidade((int) '#');
        carro6.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n");
        org.junit.Assert.assertNotNull(carro3);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        java.lang.String str9 = carro6.toString();
        int i10 = carro6.getFiabilidade();
        carro6.setPrecoBase(10.0d);
        int i13 = carro6.getVelocidadeMedia();
        Carro carro14 = new Carro(carro6);
        int i15 = carro14.getVelocidadeMedia();
        boolean b16 = carro14.getOcupado();
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(i15 == 0);
        org.junit.Assert.assertTrue(b16 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro3.setOcupado(true);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        carro6.setVelocidadeMedia(10);
        int i10 = carro3.compareTo((Veiculo) carro6);
        Coordenada coordenada11 = carro3.getCoordenadas();
        int i12 = carro3.getLugares();
        carro3.setFiabilidade(4);
        carro3.setOcupado(true);
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i10 == 3);
        org.junit.Assert.assertNotNull(coordenada11);
        org.junit.Assert.assertTrue(i12 == 0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        int i9 = carro6.getFiabilidade();
        Carro carro10 = carro6.clone();
        int i11 = carro6.getLugares();
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertNotNull(carro10);
        org.junit.Assert.assertTrue(i11 == 0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        Carro carro4 = new Carro();
        Carro carro5 = new Carro(carro4);
        Carro carro6 = new Carro(carro5);
        Carro carro7 = new Carro();
        Carro carro8 = new Carro(carro7);
        int i9 = carro5.compareTo((Veiculo) carro7);
        int i10 = carro7.getVelocidadeMedia();
        Carro carro11 = carro7.clone();
        int i12 = carro11.getFiabilidade();
        int i13 = carro11.getFiabilidade();
        Carro carro14 = new Carro(carro11);
        Coordenada coordenada15 = carro11.getCoordenadas();
        Carro carro17 = new Carro((int) ' ', (double) (-1.0f), 3, "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada15, true);
        int i18 = carro17.getFiabilidade();
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertNotNull(carro11);
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertNotNull(coordenada15);
        org.junit.Assert.assertTrue(i18 == 3);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        java.lang.String str3 = carro0.toString();
        Carro carro4 = carro0.clone();
        carro4.setOcupado(true);
        Carro carro7 = new Carro();
        Carro carro8 = new Carro(carro7);
        java.lang.String str9 = carro7.toString();
        carro7.setFiabilidade(0);
        int i12 = carro7.getFiabilidade();
        Carro carro13 = new Carro(carro7);
        boolean b14 = carro4.equals((java.lang.Object) carro13);
        java.lang.String str15 = carro4.getMatricula();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        Carro carro0 = new Carro();
        carro0.setVelocidadeMedia((int) ' ');
        java.lang.String str3 = carro0.toString();
        Carro carro8 = new Carro();
        carro8.setMatricula("");
        Carro carro11 = carro8.clone();
        Coordenada coordenada12 = carro11.getCoordenadas();
        Carro carro14 = new Carro((int) (byte) 0, (double) 'a', 3, "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada12, false);
        boolean b15 = carro0.equals((java.lang.Object) 'a');
        carro0.setOcupado(false);
        double d18 = carro0.getPrecoBase();
        Carro carro19 = new Carro();
        carro19.setMatricula("");
        boolean b23 = carro19.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada24 = carro19.getCoordenadas();
        int i25 = carro19.getVelocidadeMedia();
        Carro carro26 = new Carro();
        carro26.setMatricula("");
        Carro carro29 = carro26.clone();
        carro29.setOcupado(true);
        boolean b32 = carro19.equals((java.lang.Object) carro29);
        carro29.setMatricula("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Carro carro35 = new Carro();
        Carro carro36 = new Carro(carro35);
        java.lang.String str37 = carro35.toString();
        carro35.setFiabilidade(0);
        Carro carro40 = carro35.clone();
        int i41 = carro35.getLugares();
        Carro carro46 = new Carro();
        Carro carro47 = new Carro(carro46);
        Carro carro48 = new Carro(carro47);
        Carro carro49 = new Carro();
        Carro carro50 = new Carro(carro49);
        int i51 = carro47.compareTo((Veiculo) carro49);
        Carro carro52 = new Carro();
        carro52.setMatricula("");
        boolean b56 = carro52.equals((java.lang.Object) (-1.0d));
        boolean b57 = carro47.equals((java.lang.Object) (-1.0d));
        Carro carro58 = new Carro();
        carro58.setMatricula("");
        Carro carro61 = carro58.clone();
        carro58.setPrecoBase((double) 0L);
        Carro carro64 = new Carro();
        int i65 = carro64.getLugares();
        int i66 = carro58.compareTo((Veiculo) carro64);
        java.lang.String str67 = carro64.toString();
        Coordenada coordenada68 = carro64.getCoordenadas();
        carro47.setCoordenadas(coordenada68);
        Carro carro71 = new Carro((-1), 10.0d, (int) (byte) 1, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada68, true);
        carro35.setCoordenadas(coordenada68);
        carro29.setCoordenadas(coordenada68);
        int i74 = carro0.compareTo((Veiculo) carro29);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro11);
        org.junit.Assert.assertNotNull(coordenada12);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertTrue(d18 == 0.0d);
        org.junit.Assert.assertTrue(b23 == false);
        org.junit.Assert.assertNotNull(coordenada24);
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertNotNull(carro29);
        org.junit.Assert.assertTrue(b32 == false);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str37.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro40);
        org.junit.Assert.assertTrue(i41 == 0);
        org.junit.Assert.assertTrue(i51 == 0);
        org.junit.Assert.assertTrue(b56 == false);
        org.junit.Assert.assertTrue(b57 == false);
        org.junit.Assert.assertNotNull(carro61);
        org.junit.Assert.assertTrue(i65 == 0);
        org.junit.Assert.assertTrue(i66 == 3);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str67.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada68);
        org.junit.Assert.assertTrue(i74 == (-33));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        carro6.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carro6.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 10.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        java.lang.String str9 = carro6.toString();
        int i10 = carro6.getFiabilidade();
        Carro carro11 = new Carro();
        Carro carro12 = new Carro(carro11);
        Carro carro13 = new Carro(carro12);
        Carro carro14 = new Carro();
        Carro carro15 = new Carro(carro14);
        int i16 = carro12.compareTo((Veiculo) carro14);
        Carro carro17 = new Carro();
        carro17.setMatricula("");
        boolean b21 = carro17.equals((java.lang.Object) (-1.0d));
        boolean b22 = carro12.equals((java.lang.Object) (-1.0d));
        Carro carro23 = new Carro();
        carro23.setMatricula("");
        Carro carro26 = carro23.clone();
        carro23.setPrecoBase((double) 0L);
        Carro carro29 = new Carro();
        int i30 = carro29.getLugares();
        int i31 = carro23.compareTo((Veiculo) carro29);
        java.lang.String str32 = carro29.toString();
        Coordenada coordenada33 = carro29.getCoordenadas();
        carro12.setCoordenadas(coordenada33);
        boolean b35 = carro6.equals((java.lang.Object) carro12);
        java.lang.String str36 = carro6.toString();
        Carro carro37 = new Carro();
        Carro carro38 = new Carro(carro37);
        java.lang.String str39 = carro37.toString();
        carro37.setFiabilidade(0);
        Carro carro42 = carro37.clone();
        int i43 = carro37.getLugares();
        java.lang.Object obj44 = new java.lang.Object();
        boolean b45 = carro37.equals(obj44);
        int i46 = carro6.compareTo((Veiculo) carro37);
        int i47 = carro37.getFiabilidade();
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue(b21 == false);
        org.junit.Assert.assertTrue(b22 == false);
        org.junit.Assert.assertNotNull(carro26);
        org.junit.Assert.assertTrue(i30 == 0);
        org.junit.Assert.assertTrue(i31 == 3);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str32.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada33);
        org.junit.Assert.assertTrue(b35 == true);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str36.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str39.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro42);
        org.junit.Assert.assertTrue(i43 == 0);
        org.junit.Assert.assertTrue(b45 == false);
        org.junit.Assert.assertTrue(i46 == 0);
        org.junit.Assert.assertTrue(i47 == 0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        int i9 = carro6.getFiabilidade();
        Carro carro10 = carro6.clone();
        java.lang.String str11 = carro6.getMatricula();
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertNotNull(carro10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "n/a" + "'", str11.equals("n/a"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        Carro carro4 = new Carro(carro3);
        int i5 = carro1.compareTo((Veiculo) carro3);
        carro3.setMatricula("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        int i8 = carro3.getFiabilidade();
        Carro carro9 = carro3.clone();
        Carro carro10 = new Carro(carro9);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertNotNull(carro9);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        java.lang.String str2 = carro0.toString();
        carro0.setFiabilidade(0);
        int i5 = carro0.getFiabilidade();
        Carro carro6 = new Carro(carro0);
        Carro carro7 = carro0.clone();
        carro0.setFiabilidade(3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertNotNull(carro7);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        java.lang.String str3 = carro0.toString();
        Carro carro4 = carro0.clone();
        int i5 = carro0.getVelocidadeMedia();
        boolean b6 = carro0.getOcupado();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro4);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(b6 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carro0.getCoordenadas();
        carro0.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carro0.setFiabilidade(0);
        java.lang.String str10 = carro0.getMatricula();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str10.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        Carro carro4 = new Carro(carro0);
        int i5 = carro0.getVelocidadeMedia();
        double d6 = carro0.getPrecoBase();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i5 == 10);
        org.junit.Assert.assertTrue(d6 == 0.0d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro3.setOcupado(true);
        int i6 = carro3.getFiabilidade();
        int i7 = carro3.getFiabilidade();
        java.lang.Object obj8 = null;
        boolean b9 = carro3.equals(obj8);
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(b9 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        Carro carro4 = new Carro(carro3);
        int i5 = carro1.compareTo((Veiculo) carro3);
        int i6 = carro3.getVelocidadeMedia();
        Carro carro7 = carro3.clone();
        int i8 = carro7.getFiabilidade();
        carro7.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertNotNull(carro7);
        org.junit.Assert.assertTrue(i8 == 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        java.lang.String str9 = carro6.toString();
        Coordenada coordenada10 = carro6.getCoordenadas();
        carro6.setFiabilidade((int) (byte) 1);
        Carro carro13 = new Carro();
        int i14 = carro13.getLugares();
        carro13.setVelocidadeMedia(10);
        Carro carro17 = carro13.clone();
        boolean b18 = carro6.equals((java.lang.Object) carro13);
        java.lang.String str19 = carro6.getMatricula();
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertNotNull(carro17);
        org.junit.Assert.assertTrue(b18 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "n/a" + "'", str19.equals("n/a"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        Carro carro4 = new Carro(carro0);
        Carro carro5 = new Carro(carro4);
        int i6 = carro5.getFiabilidade();
        Carro carro7 = carro5.clone();
        carro5.setPrecoBase((double) 0);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertNotNull(carro7);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        java.lang.String str9 = carro6.toString();
        int i10 = carro6.getFiabilidade();
        carro6.setPrecoBase(10.0d);
        int i13 = carro6.getFiabilidade();
        carro6.setFiabilidade(100);
        int i16 = carro6.getLugares();
        carro6.setOcupado(false);
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(i16 == 0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        int i4 = carro3.getVelocidadeMedia();
        java.lang.Object obj5 = null;
        boolean b6 = carro3.equals(obj5);
        Carro carro7 = new Carro();
        carro7.setMatricula("");
        Carro carro10 = carro7.clone();
        carro10.setOcupado(true);
        Carro carro13 = new Carro();
        int i14 = carro13.getLugares();
        carro13.setVelocidadeMedia(10);
        int i17 = carro10.compareTo((Veiculo) carro13);
        Coordenada coordenada18 = carro10.getCoordenadas();
        int i19 = carro10.getLugares();
        boolean b20 = carro3.equals((java.lang.Object) carro10);
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue(b6 == false);
        org.junit.Assert.assertNotNull(carro10);
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(i17 == 3);
        org.junit.Assert.assertNotNull(coordenada18);
        org.junit.Assert.assertTrue(i19 == 0);
        org.junit.Assert.assertTrue(b20 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        Coordenada coordenada4 = carro3.getCoordenadas();
        Carro carro5 = carro3.clone();
        java.lang.String str6 = carro3.getMatricula();
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertNotNull(coordenada4);
        org.junit.Assert.assertNotNull(carro5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        java.lang.String str2 = carro0.getMatricula();
        Carro carro3 = new Carro(carro0);
        carro0.setOcupado(true);
        java.lang.String str6 = carro0.toString();
        Carro carro7 = new Carro();
        int i8 = carro7.getLugares();
        java.lang.String str9 = carro7.getMatricula();
        Carro carro10 = new Carro(carro7);
        int i11 = carro10.getFiabilidade();
        boolean b12 = carro0.equals((java.lang.Object) i11);
        carro0.setVelocidadeMedia(33);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "n/a" + "'", str2.equals("n/a"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n" + "'", str6.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n"));
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "n/a" + "'", str9.equals("n/a"));
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(b12 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        java.lang.String str2 = carro0.toString();
        carro0.setFiabilidade(0);
        Carro carro5 = carro0.clone();
        int i6 = carro0.getLugares();
        java.lang.Object obj7 = new java.lang.Object();
        boolean b8 = carro0.equals(obj7);
        java.lang.String str9 = carro0.toString();
        java.lang.String str10 = carro0.getMatricula();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro5);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertTrue(b8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "n/a" + "'", str10.equals("n/a"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        int i4 = carro3.getLugares();
        boolean b5 = carro2.equals((java.lang.Object) carro3);
        carro3.setFiabilidade(100);
        int i8 = carro3.getFiabilidade();
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue(b5 == true);
        org.junit.Assert.assertTrue(i8 == 100);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        Carro carro4 = new Carro();
        carro4.setMatricula("");
        Carro carro7 = carro4.clone();
        carro4.setPrecoBase((double) 0L);
        Carro carro10 = new Carro(carro4);
        Carro carro11 = new Carro();
        int i12 = carro11.getLugares();
        carro11.setVelocidadeMedia(10);
        Carro carro15 = new Carro(carro11);
        Carro carro16 = new Carro(carro15);
        int i17 = carro16.getFiabilidade();
        Carro carro18 = carro16.clone();
        Carro carro19 = new Carro();
        carro19.setMatricula("");
        Carro carro22 = carro19.clone();
        int i23 = carro22.getVelocidadeMedia();
        Coordenada coordenada24 = carro22.getCoordenadas();
        carro18.setCoordenadas(coordenada24);
        carro4.setCoordenadas(coordenada24);
        Carro carro28 = new Carro(1, (double) 1, 32, "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 10.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada24, true);
        org.junit.Assert.assertNotNull(carro7);
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertTrue(i17 == 0);
        org.junit.Assert.assertNotNull(carro18);
        org.junit.Assert.assertNotNull(carro22);
        org.junit.Assert.assertTrue(i23 == 0);
        org.junit.Assert.assertNotNull(coordenada24);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carro0.getCoordenadas();
        carro0.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carro0.setFiabilidade(0);
        Carro carro10 = new Carro();
        carro10.setMatricula("");
        Carro carro13 = carro10.clone();
        carro10.setPrecoBase((double) 0L);
        Carro carro16 = new Carro(carro10);
        int i17 = carro0.compareTo((Veiculo) carro10);
        Carro carro18 = new Carro(carro10);
        carro18.setOcupado(false);
        carro18.setPrecoBase((double) 0.0f);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertNotNull(carro13);
        org.junit.Assert.assertTrue(i17 == (-142));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        carro0.setFiabilidade((int) (byte) 0);
        double d6 = carro0.getPrecoBase();
        carro0.setFiabilidade((-142));
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(d6 == 0.0d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        Carro carro4 = new Carro();
        Carro carro5 = new Carro(carro4);
        Carro carro6 = new Carro(carro5);
        Carro carro7 = new Carro();
        Carro carro8 = new Carro(carro7);
        int i9 = carro5.compareTo((Veiculo) carro7);
        Carro carro10 = new Carro();
        carro10.setMatricula("");
        boolean b14 = carro10.equals((java.lang.Object) (-1.0d));
        boolean b15 = carro5.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada16 = carro5.getCoordenadas();
        Carro carro18 = new Carro((int) (short) 10, (double) 0.0f, (int) (short) 0, "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada16, true);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertNotNull(coordenada16);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        java.lang.String str9 = carro6.toString();
        int i10 = carro6.getFiabilidade();
        carro6.setPrecoBase(10.0d);
        int i13 = carro6.getVelocidadeMedia();
        int i14 = carro6.getFiabilidade();
        Carro carro15 = carro6.clone();
        carro6.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n");
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertNotNull(carro15);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carro0.getCoordenadas();
        carro0.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carro0.setFiabilidade(0);
        Carro carro10 = new Carro();
        carro10.setMatricula("");
        Carro carro13 = carro10.clone();
        carro10.setPrecoBase((double) 0L);
        Carro carro16 = new Carro(carro10);
        int i17 = carro0.compareTo((Veiculo) carro10);
        Carro carro18 = new Carro(carro10);
        int i19 = carro10.getFiabilidade();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertNotNull(carro13);
        org.junit.Assert.assertTrue(i17 == (-142));
        org.junit.Assert.assertTrue(i19 == 0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        java.lang.String str2 = carro0.toString();
        carro0.setFiabilidade(0);
        int i5 = carro0.getFiabilidade();
        Carro carro6 = new Carro(carro0);
        int i7 = carro0.getLugares();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(i7 == 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carro0.getCoordenadas();
        int i6 = carro0.getVelocidadeMedia();
        Carro carro7 = new Carro();
        carro7.setMatricula("");
        Carro carro10 = carro7.clone();
        carro10.setOcupado(true);
        boolean b13 = carro0.equals((java.lang.Object) carro10);
        carro10.setMatricula("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Carro carro16 = carro10.clone();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertNotNull(carro10);
        org.junit.Assert.assertTrue(b13 == false);
        org.junit.Assert.assertNotNull(carro16);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        java.lang.String str2 = carro0.toString();
        carro0.setMatricula("hi!");
        carro0.setPrecoBase((double) 10.0f);
        java.lang.String str7 = carro0.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Matrícula: hi!\nVelocidade Média/km: 0km/h\nPreço Base: 10.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str7.equals("Matrícula: hi!\nVelocidade Média/km: 0km/h\nPreço Base: 10.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro3.setOcupado(true);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        carro6.setVelocidadeMedia(10);
        int i10 = carro3.compareTo((Veiculo) carro6);
        carro3.setFiabilidade((int) ' ');
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i10 == 3);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        Carro carro0 = new Carro();
        carro0.setVelocidadeMedia((int) ' ');
        java.lang.String str3 = carro0.toString();
        Carro carro8 = new Carro();
        carro8.setMatricula("");
        Carro carro11 = carro8.clone();
        Coordenada coordenada12 = carro11.getCoordenadas();
        Carro carro14 = new Carro((int) (byte) 0, (double) 'a', 3, "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada12, false);
        boolean b15 = carro0.equals((java.lang.Object) 'a');
        carro0.setOcupado(false);
        double d18 = carro0.getPrecoBase();
        carro0.setVelocidadeMedia((int) (byte) 100);
        double d21 = carro0.getPrecoBase();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro11);
        org.junit.Assert.assertNotNull(coordenada12);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertTrue(d18 == 0.0d);
        org.junit.Assert.assertTrue(d21 == 0.0d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        int i4 = carro3.getLugares();
        boolean b5 = carro2.equals((java.lang.Object) carro3);
        carro3.setPrecoBase(0.0d);
        java.lang.String str8 = carro3.getMatricula();
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue(b5 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "n/a" + "'", str8.equals("n/a"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        Carro carro2 = carro0.clone();
        Carro carro3 = new Carro(carro2);
        Coordenada coordenada4 = carro3.getCoordenadas();
        carro3.setFiabilidade((int) (short) 1);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(carro2);
        org.junit.Assert.assertNotNull(coordenada4);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        boolean b6 = carro0.getOcupado();
        int i7 = carro0.getFiabilidade();
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(b6 == false);
        org.junit.Assert.assertTrue(i7 == 0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        carro0.setOcupado(false);
        boolean b5 = carro0.getOcupado();
        org.junit.Assert.assertTrue(b5 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        Carro carro4 = new Carro();
        carro4.setMatricula("");
        Carro carro7 = carro4.clone();
        Coordenada coordenada8 = carro7.getCoordenadas();
        Carro carro10 = new Carro((int) (byte) 0, (double) 'a', 3, "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada8, false);
        int i11 = carro10.getVelocidadeMedia();
        java.lang.String str12 = carro10.toString();
        org.junit.Assert.assertNotNull(carro7);
        org.junit.Assert.assertNotNull(coordenada8);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Matrícula: Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 97.0€\nFiabilidade: 3\nLugares: 4\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str12.equals("Matrícula: Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 97.0€\nFiabilidade: 3\nLugares: 4\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        Carro carro4 = new Carro(carro3);
        int i5 = carro1.compareTo((Veiculo) carro3);
        Carro carro6 = new Carro();
        carro6.setMatricula("");
        boolean b10 = carro6.equals((java.lang.Object) (-1.0d));
        boolean b11 = carro1.equals((java.lang.Object) (-1.0d));
        boolean b12 = carro1.getOcupado();
        boolean b13 = carro1.getOcupado();
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertTrue(b13 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        Coordenada coordenada2 = carro0.getCoordenadas();
        carro0.setFiabilidade(3);
        Carro carro5 = carro0.clone();
        Coordenada coordenada6 = carro0.getCoordenadas();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(coordenada2);
        org.junit.Assert.assertNotNull(carro5);
        org.junit.Assert.assertNotNull(coordenada6);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        java.lang.String str9 = carro6.toString();
        Coordenada coordenada10 = carro6.getCoordenadas();
        carro6.setFiabilidade((int) (byte) 1);
        double d13 = carro6.getPrecoBase();
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertTrue(d13 == 0.0d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        carro0.setMatricula("n/a");
        java.lang.String str11 = carro0.toString();
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str11.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        Carro carro4 = new Carro();
        carro4.setMatricula("");
        Carro carro7 = carro4.clone();
        Coordenada coordenada8 = carro7.getCoordenadas();
        Carro carro10 = new Carro((int) (byte) -1, (double) 0, (int) (short) 1, "", coordenada8, false);
        double d11 = carro10.getPrecoBase();
        carro10.setOcupado(false);
        carro10.setOcupado(true);
        org.junit.Assert.assertNotNull(carro7);
        org.junit.Assert.assertNotNull(coordenada8);
        org.junit.Assert.assertTrue(d11 == 0.0d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carro0.getCoordenadas();
        boolean b6 = carro0.getOcupado();
        int i7 = carro0.getVelocidadeMedia();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(b6 == false);
        org.junit.Assert.assertTrue(i7 == 0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carro0.getCoordenadas();
        carro0.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carro0.setFiabilidade(0);
        int i10 = carro0.getVelocidadeMedia();
        Carro carro11 = new Carro();
        Carro carro12 = new Carro();
        Carro carro13 = new Carro(carro12);
        int i14 = carro13.getFiabilidade();
        Coordenada coordenada15 = carro13.getCoordenadas();
        carro11.setCoordenadas(coordenada15);
        boolean b17 = carro0.equals((java.lang.Object) carro11);
        int i18 = carro11.getFiabilidade();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertNotNull(coordenada15);
        org.junit.Assert.assertTrue(b17 == false);
        org.junit.Assert.assertTrue(i18 == 0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        java.lang.String str3 = carro0.toString();
        Carro carro4 = new Carro();
        carro4.setMatricula("");
        boolean b8 = carro4.equals((java.lang.Object) (-1.0d));
        Carro carro9 = new Carro(carro4);
        double d10 = carro4.getPrecoBase();
        java.lang.String str11 = carro4.toString();
        int i12 = carro4.getVelocidadeMedia();
        int i13 = carro4.getVelocidadeMedia();
        boolean b14 = carro0.equals((java.lang.Object) carro4);
        carro0.setMatricula("n/a");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(b8 == false);
        org.junit.Assert.assertTrue(d10 == 0.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str11.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(b14 == true);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Carro carro5 = new Carro(carro0);
        double d6 = carro0.getPrecoBase();
        boolean b7 = carro0.getOcupado();
        int i8 = carro0.getVelocidadeMedia();
        Carro carro9 = carro0.clone();
        java.lang.String str10 = carro9.getMatricula();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(b7 == false);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertNotNull(carro9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        Carro carro9 = new Carro(carro6);
        carro6.setVelocidadeMedia(32);
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        boolean b9 = carro6.getOcupado();
        int i10 = carro6.getVelocidadeMedia();
        java.lang.String str11 = carro6.toString();
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue(b9 == false);
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str11.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        java.lang.String str3 = carro0.getMatricula();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carro0.getCoordenadas();
        java.lang.String str6 = carro0.getMatricula();
        Carro carro7 = carro0.clone();
        carro7.setFiabilidade((int) 'a');
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(carro7);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        Carro carro4 = new Carro(carro3);
        int i5 = carro1.compareTo((Veiculo) carro3);
        Coordenada coordenada6 = carro1.getCoordenadas();
        int i7 = carro1.getLugares();
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertNotNull(coordenada6);
        org.junit.Assert.assertTrue(i7 == 0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        java.lang.String str9 = carro6.toString();
        int i10 = carro6.getFiabilidade();
        carro6.setPrecoBase(10.0d);
        int i13 = carro6.getVelocidadeMedia();
        Carro carro14 = new Carro(carro6);
        carro14.setFiabilidade((int) (short) 10);
        int i17 = carro14.getVelocidadeMedia();
        Carro carro18 = new Carro();
        carro18.setMatricula("");
        Carro carro21 = carro18.clone();
        carro18.setPrecoBase((double) 0L);
        Carro carro24 = new Carro();
        int i25 = carro24.getLugares();
        int i26 = carro18.compareTo((Veiculo) carro24);
        java.lang.String str27 = carro24.toString();
        Coordenada coordenada28 = carro24.getCoordenadas();
        carro24.setMatricula("hi!");
        boolean b31 = carro14.equals((java.lang.Object) "hi!");
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(i17 == 0);
        org.junit.Assert.assertNotNull(carro21);
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue(i26 == 3);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str27.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada28);
        org.junit.Assert.assertTrue(b31 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        java.lang.String str2 = carro0.toString();
        carro0.setFiabilidade(0);
        Carro carro5 = carro0.clone();
        carro5.setMatricula("Matrícula: hi!\nVelocidade Média/km: 0km/h\nPreço Base: 10.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro5);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        java.lang.String str2 = carro0.toString();
        carro0.setFiabilidade(0);
        Carro carro5 = carro0.clone();
        int i6 = carro0.getLugares();
        Carro carro11 = new Carro();
        Carro carro12 = new Carro(carro11);
        Carro carro13 = new Carro(carro12);
        Carro carro14 = new Carro();
        Carro carro15 = new Carro(carro14);
        int i16 = carro12.compareTo((Veiculo) carro14);
        Carro carro17 = new Carro();
        carro17.setMatricula("");
        boolean b21 = carro17.equals((java.lang.Object) (-1.0d));
        boolean b22 = carro12.equals((java.lang.Object) (-1.0d));
        Carro carro23 = new Carro();
        carro23.setMatricula("");
        Carro carro26 = carro23.clone();
        carro23.setPrecoBase((double) 0L);
        Carro carro29 = new Carro();
        int i30 = carro29.getLugares();
        int i31 = carro23.compareTo((Veiculo) carro29);
        java.lang.String str32 = carro29.toString();
        Coordenada coordenada33 = carro29.getCoordenadas();
        carro12.setCoordenadas(coordenada33);
        Carro carro36 = new Carro((-1), 10.0d, (int) (byte) 1, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada33, true);
        carro0.setCoordenadas(coordenada33);
        int i38 = carro0.getFiabilidade();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro5);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue(b21 == false);
        org.junit.Assert.assertTrue(b22 == false);
        org.junit.Assert.assertNotNull(carro26);
        org.junit.Assert.assertTrue(i30 == 0);
        org.junit.Assert.assertTrue(i31 == 3);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str32.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada33);
        org.junit.Assert.assertTrue(i38 == 0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        java.lang.String str9 = carro6.toString();
        int i10 = carro6.getFiabilidade();
        carro6.setPrecoBase(10.0d);
        int i13 = carro6.getVelocidadeMedia();
        Carro carro14 = new Carro(carro6);
        carro6.setVelocidadeMedia(1);
        Coordenada coordenada17 = carro6.getCoordenadas();
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertNotNull(coordenada17);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        java.lang.String str3 = carro0.toString();
        Carro carro4 = carro0.clone();
        carro4.setOcupado(true);
        Carro carro7 = new Carro();
        Carro carro8 = new Carro(carro7);
        java.lang.String str9 = carro7.toString();
        carro7.setFiabilidade(0);
        int i12 = carro7.getFiabilidade();
        Carro carro13 = new Carro(carro7);
        boolean b14 = carro4.equals((java.lang.Object) carro13);
        Coordenada coordenada15 = carro4.getCoordenadas();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertNotNull(coordenada15);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        Carro carro4 = new Carro(carro0);
        Carro carro5 = new Carro(carro4);
        int i6 = carro5.getFiabilidade();
        Carro carro7 = carro5.clone();
        carro7.setOcupado(false);
        double d10 = carro7.getPrecoBase();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertNotNull(carro7);
        org.junit.Assert.assertTrue(d10 == 0.0d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        java.lang.String str2 = carro0.getMatricula();
        Carro carro3 = new Carro(carro0);
        carro0.setOcupado(true);
        java.lang.String str6 = carro0.toString();
        Carro carro7 = new Carro();
        int i8 = carro7.getLugares();
        java.lang.String str9 = carro7.getMatricula();
        Carro carro10 = new Carro(carro7);
        int i11 = carro10.getFiabilidade();
        boolean b12 = carro0.equals((java.lang.Object) i11);
        Carro carro13 = new Carro();
        carro13.setMatricula("");
        boolean b17 = carro13.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada18 = carro13.getCoordenadas();
        java.lang.String str19 = carro13.getMatricula();
        Carro carro20 = carro13.clone();
        boolean b21 = carro0.equals((java.lang.Object) carro13);
        boolean b22 = carro0.getOcupado();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "n/a" + "'", str2.equals("n/a"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n" + "'", str6.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n"));
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "n/a" + "'", str9.equals("n/a"));
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertTrue(b17 == false);
        org.junit.Assert.assertNotNull(coordenada18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNotNull(carro20);
        org.junit.Assert.assertTrue(b21 == false);
        org.junit.Assert.assertTrue(b22 == true);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        Carro carro4 = new Carro(carro3);
        int i5 = carro1.compareTo((Veiculo) carro3);
        Carro carro6 = new Carro();
        carro6.setMatricula("");
        Carro carro9 = carro6.clone();
        boolean b10 = carro1.equals((java.lang.Object) carro6);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertNotNull(carro9);
        org.junit.Assert.assertTrue(b10 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        java.lang.String str3 = carro0.toString();
        Carro carro4 = new Carro();
        carro4.setMatricula("");
        boolean b8 = carro4.equals((java.lang.Object) (-1.0d));
        Carro carro9 = new Carro(carro4);
        double d10 = carro4.getPrecoBase();
        java.lang.String str11 = carro4.toString();
        int i12 = carro4.getVelocidadeMedia();
        int i13 = carro4.getVelocidadeMedia();
        boolean b14 = carro0.equals((java.lang.Object) carro4);
        int i15 = carro0.getVelocidadeMedia();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(b8 == false);
        org.junit.Assert.assertTrue(d10 == 0.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str11.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(b14 == true);
        org.junit.Assert.assertTrue(i15 == 0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        java.lang.String str3 = carro0.toString();
        java.lang.Object obj4 = null;
        boolean b5 = carro0.equals(obj4);
        Carro carro6 = new Carro();
        carro6.setMatricula("");
        Carro carro9 = carro6.clone();
        int i10 = carro9.getFiabilidade();
        java.lang.String str11 = carro9.toString();
        boolean b12 = carro0.equals((java.lang.Object) carro9);
        carro9.setVelocidadeMedia((-142));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(b5 == false);
        org.junit.Assert.assertNotNull(carro9);
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str11.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(b12 == true);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        Carro carro4 = new Carro();
        carro4.setMatricula("");
        Carro carro7 = carro4.clone();
        carro4.setPrecoBase((double) 0L);
        Carro carro10 = new Carro();
        int i11 = carro10.getLugares();
        int i12 = carro4.compareTo((Veiculo) carro10);
        java.lang.String str13 = carro10.toString();
        Coordenada coordenada14 = carro10.getCoordenadas();
        Carro carro16 = new Carro((int) (byte) -1, 0.0d, (int) 'a', "", coordenada14, true);
        int i17 = carro16.getLugares();
        org.junit.Assert.assertNotNull(carro7);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(i12 == 3);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str13.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada14);
        org.junit.Assert.assertTrue(i17 == 4);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        int i9 = carro6.getFiabilidade();
        Carro carro10 = carro6.clone();
        Coordenada coordenada11 = carro10.getCoordenadas();
        int i12 = carro10.getLugares();
        carro10.setOcupado(false);
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertNotNull(carro10);
        org.junit.Assert.assertNotNull(coordenada11);
        org.junit.Assert.assertTrue(i12 == 0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        Carro carro4 = new Carro(carro0);
        int i5 = carro0.getVelocidadeMedia();
        Carro carro6 = carro0.clone();
        carro6.setMatricula("Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Coordenada coordenada9 = carro6.getCoordenadas();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i5 == 10);
        org.junit.Assert.assertNotNull(carro6);
        org.junit.Assert.assertNotNull(coordenada9);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        Carro carro4 = new Carro(carro3);
        int i5 = carro1.compareTo((Veiculo) carro3);
        Carro carro6 = new Carro();
        carro6.setMatricula("");
        boolean b10 = carro6.equals((java.lang.Object) (-1.0d));
        boolean b11 = carro1.equals((java.lang.Object) (-1.0d));
        Carro carro12 = new Carro(carro1);
        Carro carro17 = new Carro();
        Carro carro18 = new Carro(carro17);
        Carro carro19 = new Carro(carro18);
        Carro carro20 = new Carro();
        Carro carro21 = new Carro(carro20);
        int i22 = carro18.compareTo((Veiculo) carro20);
        Carro carro23 = new Carro();
        carro23.setMatricula("");
        boolean b27 = carro23.equals((java.lang.Object) (-1.0d));
        boolean b28 = carro18.equals((java.lang.Object) (-1.0d));
        Carro carro29 = new Carro();
        carro29.setMatricula("");
        Carro carro32 = carro29.clone();
        carro29.setPrecoBase((double) 0L);
        Carro carro35 = new Carro();
        int i36 = carro35.getLugares();
        int i37 = carro29.compareTo((Veiculo) carro35);
        java.lang.String str38 = carro35.toString();
        Coordenada coordenada39 = carro35.getCoordenadas();
        carro18.setCoordenadas(coordenada39);
        Carro carro42 = new Carro((-1), 10.0d, (int) (byte) 1, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada39, true);
        int i43 = carro1.compareTo((Veiculo) carro42);
        carro42.setOcupado(false);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertTrue(i22 == 0);
        org.junit.Assert.assertTrue(b27 == false);
        org.junit.Assert.assertTrue(b28 == false);
        org.junit.Assert.assertNotNull(carro32);
        org.junit.Assert.assertTrue(i36 == 0);
        org.junit.Assert.assertTrue(i37 == 3);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str38.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada39);
        org.junit.Assert.assertTrue(i43 == (-33));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Carro carro5 = new Carro(carro0);
        double d6 = carro0.getPrecoBase();
        boolean b7 = carro0.getOcupado();
        carro0.setOcupado(true);
        carro0.setPrecoBase((-1.0d));
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(b7 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        Carro carro8 = new Carro();
        carro8.setMatricula("");
        Carro carro11 = carro8.clone();
        carro8.setPrecoBase((double) 0L);
        Carro carro14 = new Carro();
        int i15 = carro14.getLugares();
        int i16 = carro8.compareTo((Veiculo) carro14);
        java.lang.String str17 = carro14.toString();
        Coordenada coordenada18 = carro14.getCoordenadas();
        Carro carro20 = new Carro((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, false);
        Carro carro22 = new Carro((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, true);
        carro22.setFiabilidade(0);
        carro22.setVelocidadeMedia((int) 'a');
        org.junit.Assert.assertNotNull(carro11);
        org.junit.Assert.assertTrue(i15 == 0);
        org.junit.Assert.assertTrue(i16 == 3);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str17.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada18);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        Carro carro4 = new Carro();
        carro4.setMatricula("");
        boolean b8 = carro4.equals((java.lang.Object) (-1.0d));
        Carro carro9 = new Carro(carro4);
        int i10 = carro9.getVelocidadeMedia();
        Carro carro11 = new Carro();
        Carro carro12 = new Carro(carro11);
        Carro carro13 = new Carro(carro12);
        Carro carro14 = new Carro();
        Carro carro15 = new Carro(carro14);
        int i16 = carro12.compareTo((Veiculo) carro14);
        Carro carro17 = new Carro();
        carro17.setMatricula("");
        boolean b21 = carro17.equals((java.lang.Object) (-1.0d));
        boolean b22 = carro12.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada23 = carro12.getCoordenadas();
        carro9.setCoordenadas(coordenada23);
        int i25 = carro9.getLugares();
        Coordenada coordenada26 = carro9.getCoordenadas();
        Carro carro28 = new Carro((-1), 10.0d, (-145), "Matrícula: hi!\nVelocidade Média/km: 0km/h\nPreço Base: 10.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada26, false);
        org.junit.Assert.assertTrue(b8 == false);
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue(b21 == false);
        org.junit.Assert.assertTrue(b22 == false);
        org.junit.Assert.assertNotNull(coordenada23);
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertNotNull(coordenada26);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        Carro carro4 = new Carro(carro0);
        Carro carro5 = new Carro(carro4);
        int i6 = carro5.getFiabilidade();
        carro5.setPrecoBase((double) 0);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i6 == 0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro(carro0);
        carro6.setPrecoBase((double) (-1.0f));
        carro6.setVelocidadeMedia((int) (short) 0);
        carro6.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Carro carro13 = new Carro();
        int i14 = carro13.getLugares();
        carro13.setVelocidadeMedia(10);
        Carro carro17 = new Carro(carro13);
        Carro carro18 = carro17.clone();
        int i19 = carro6.compareTo((Veiculo) carro18);
        int i20 = carro18.getFiabilidade();
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertNotNull(carro18);
        org.junit.Assert.assertTrue(i19 == 33);
        org.junit.Assert.assertTrue(i20 == 0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        Carro carro9 = new Carro();
        carro9.setMatricula("");
        Carro carro12 = carro9.clone();
        carro9.setPrecoBase((double) 0L);
        Carro carro15 = new Carro();
        int i16 = carro15.getLugares();
        int i17 = carro9.compareTo((Veiculo) carro15);
        java.lang.String str18 = carro15.toString();
        Coordenada coordenada19 = carro15.getCoordenadas();
        Carro carro20 = new Carro();
        int i21 = carro20.getLugares();
        Coordenada coordenada22 = carro20.getCoordenadas();
        carro15.setCoordenadas(coordenada22);
        Carro carro24 = new Carro(carro15);
        int i25 = carro0.compareTo((Veiculo) carro15);
        boolean b26 = carro15.getOcupado();
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertNotNull(carro12);
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue(i17 == 3);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str18.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada19);
        org.junit.Assert.assertTrue(i21 == 0);
        org.junit.Assert.assertNotNull(coordenada22);
        org.junit.Assert.assertTrue(i25 == 3);
        org.junit.Assert.assertTrue(b26 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        int i9 = carro6.getFiabilidade();
        Carro carro10 = carro6.clone();
        carro6.setFiabilidade((int) (short) 1);
        carro6.setPrecoBase(10.0d);
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertNotNull(carro10);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro3.setOcupado(true);
        int i6 = carro3.getFiabilidade();
        int i7 = carro3.getFiabilidade();
        carro3.setVelocidadeMedia(10);
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertTrue(i7 == 0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        int i4 = carro3.getFiabilidade();
        Carro carro5 = carro3.clone();
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertNotNull(carro5);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        carro0.setMatricula("n/a");
        carro0.setMatricula("Matrícula: hi!\nVelocidade Média/km: 0km/h\nPreço Base: 10.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        java.lang.String str6 = carro0.getMatricula();
        Coordenada coordenada7 = carro0.getCoordenadas();
        carro0.setOcupado(true);
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(coordenada7);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        Carro carro4 = carro0.clone();
        Carro carro5 = new Carro(carro0);
        Carro carro6 = new Carro(carro5);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(carro4);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        java.lang.String str2 = carro0.toString();
        carro0.setMatricula("hi!");
        carro0.setMatricula("Matrícula: \nVelocidade Média/km: -1km/h\nPreço Base: 0.0€\nFiabilidade: 1\nLugares: 4\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        Carro carro4 = new Carro();
        carro4.setMatricula("");
        Carro carro7 = carro4.clone();
        carro4.setPrecoBase((double) 0L);
        Carro carro10 = new Carro();
        int i11 = carro10.getLugares();
        int i12 = carro4.compareTo((Veiculo) carro10);
        java.lang.String str13 = carro10.toString();
        Coordenada coordenada14 = carro10.getCoordenadas();
        Carro carro16 = new Carro((int) ' ', (double) 100.0f, (int) (byte) -1, "", coordenada14, false);
        double d17 = carro16.getPrecoBase();
        java.lang.String str18 = carro16.getMatricula();
        org.junit.Assert.assertNotNull(carro7);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(i12 == 3);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str13.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada14);
        org.junit.Assert.assertTrue(d17 == 100.0d);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Carro carro5 = new Carro(carro0);
        double d6 = carro0.getPrecoBase();
        boolean b7 = carro0.getOcupado();
        int i8 = carro0.getVelocidadeMedia();
        java.lang.String str9 = carro0.getMatricula();
        Carro carro10 = new Carro();
        carro10.setMatricula("");
        boolean b14 = carro10.equals((java.lang.Object) (-1.0d));
        Carro carro15 = new Carro(carro10);
        int i16 = carro0.compareTo((Veiculo) carro10);
        Carro carro17 = carro10.clone();
        carro10.setVelocidadeMedia((-33));
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(b7 == false);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertNotNull(carro17);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        Carro carro9 = new Carro(carro6);
        int i10 = carro9.getLugares();
        carro9.setPrecoBase((double) (-1));
        carro9.setPrecoBase((double) 1);
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue(i10 == 0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        java.lang.String str9 = carro6.toString();
        Coordenada coordenada10 = carro6.getCoordenadas();
        carro6.setFiabilidade((int) (byte) 1);
        int i13 = carro6.getVelocidadeMedia();
        Carro carro14 = new Carro();
        int i15 = carro14.getLugares();
        carro14.setVelocidadeMedia(10);
        Carro carro18 = new Carro(carro14);
        Carro carro19 = new Carro(carro18);
        int i20 = carro19.getFiabilidade();
        Carro carro21 = carro19.clone();
        carro21.setOcupado(false);
        Coordenada coordenada24 = carro21.getCoordenadas();
        carro6.setCoordenadas(coordenada24);
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(i15 == 0);
        org.junit.Assert.assertTrue(i20 == 0);
        org.junit.Assert.assertNotNull(carro21);
        org.junit.Assert.assertNotNull(coordenada24);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro(carro0);
        carro6.setPrecoBase((double) (-1.0f));
        carro6.setVelocidadeMedia((int) (short) 0);
        carro6.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Carro carro13 = new Carro(carro6);
        carro13.setVelocidadeMedia((int) (short) 10);
        org.junit.Assert.assertNotNull(carro3);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        java.lang.String str2 = carro0.toString();
        carro0.setFiabilidade(0);
        int i5 = carro0.getFiabilidade();
        Carro carro6 = new Carro(carro0);
        carro6.setPrecoBase((double) (-1));
        Carro carro9 = new Carro();
        carro9.setMatricula("");
        Carro carro12 = carro9.clone();
        carro9.setPrecoBase((double) 0L);
        Carro carro15 = new Carro();
        int i16 = carro15.getLugares();
        int i17 = carro9.compareTo((Veiculo) carro15);
        java.lang.String str18 = carro15.toString();
        Coordenada coordenada19 = carro15.getCoordenadas();
        Carro carro20 = new Carro();
        int i21 = carro20.getLugares();
        Coordenada coordenada22 = carro20.getCoordenadas();
        carro15.setCoordenadas(coordenada22);
        Carro carro24 = new Carro(carro15);
        int i25 = carro6.compareTo((Veiculo) carro15);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertNotNull(carro12);
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue(i17 == 3);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str18.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada19);
        org.junit.Assert.assertTrue(i21 == 0);
        org.junit.Assert.assertNotNull(coordenada22);
        org.junit.Assert.assertTrue(i25 == 0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        java.lang.String str9 = carro6.toString();
        int i10 = carro6.getFiabilidade();
        carro6.setPrecoBase(10.0d);
        int i13 = carro6.getVelocidadeMedia();
        Carro carro14 = new Carro(carro6);
        carro14.setFiabilidade((int) (short) 10);
        carro14.setVelocidadeMedia(0);
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i13 == 0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Carro carro5 = new Carro(carro0);
        double d6 = carro0.getPrecoBase();
        boolean b7 = carro0.getOcupado();
        int i8 = carro0.getVelocidadeMedia();
        Carro carro9 = carro0.clone();
        carro9.setFiabilidade((int) (byte) 10);
        carro9.setFiabilidade((int) (short) -1);
        carro9.setMatricula("hi!");
        Carro carro16 = new Carro(carro9);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(b7 == false);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertNotNull(carro9);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        Carro carro8 = new Carro();
        int i9 = carro8.getLugares();
        Coordenada coordenada10 = carro8.getCoordenadas();
        Carro carro12 = new Carro((int) (short) -1, (double) (byte) -1, (int) '4', "", coordenada10, true);
        Carro carro14 = new Carro(52, (double) (short) 10, (-3), "n/a", coordenada10, true);
        carro14.setVelocidadeMedia(4);
        java.lang.String str17 = carro14.getMatricula();
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "n/a" + "'", str17.equals("n/a"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        Coordenada coordenada2 = carro0.getCoordenadas();
        Carro carro3 = new Carro();
        Carro carro4 = new Carro(carro3);
        java.lang.String str5 = carro3.toString();
        carro3.setFiabilidade(0);
        Carro carro8 = carro3.clone();
        int i9 = carro3.getLugares();
        Carro carro14 = new Carro();
        Carro carro15 = new Carro(carro14);
        Carro carro16 = new Carro(carro15);
        Carro carro17 = new Carro();
        Carro carro18 = new Carro(carro17);
        int i19 = carro15.compareTo((Veiculo) carro17);
        Carro carro20 = new Carro();
        carro20.setMatricula("");
        boolean b24 = carro20.equals((java.lang.Object) (-1.0d));
        boolean b25 = carro15.equals((java.lang.Object) (-1.0d));
        Carro carro26 = new Carro();
        carro26.setMatricula("");
        Carro carro29 = carro26.clone();
        carro26.setPrecoBase((double) 0L);
        Carro carro32 = new Carro();
        int i33 = carro32.getLugares();
        int i34 = carro26.compareTo((Veiculo) carro32);
        java.lang.String str35 = carro32.toString();
        Coordenada coordenada36 = carro32.getCoordenadas();
        carro15.setCoordenadas(coordenada36);
        Carro carro39 = new Carro((-1), 10.0d, (int) (byte) 1, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada36, true);
        carro3.setCoordenadas(coordenada36);
        int i41 = carro0.compareTo((Veiculo) carro3);
        Coordenada coordenada42 = carro3.getCoordenadas();
        int i43 = carro3.getFiabilidade();
        Carro carro44 = carro3.clone();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(coordenada2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str5.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro8);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertTrue(i19 == 0);
        org.junit.Assert.assertTrue(b24 == false);
        org.junit.Assert.assertTrue(b25 == false);
        org.junit.Assert.assertNotNull(carro29);
        org.junit.Assert.assertTrue(i33 == 0);
        org.junit.Assert.assertTrue(i34 == 3);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str35.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada36);
        org.junit.Assert.assertTrue(i41 == 0);
        org.junit.Assert.assertNotNull(coordenada42);
        org.junit.Assert.assertTrue(i43 == 0);
        org.junit.Assert.assertNotNull(carro44);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        Carro carro4 = new Carro(carro0);
        int i5 = carro0.getVelocidadeMedia();
        java.lang.String str6 = carro0.getMatricula();
        carro0.setVelocidadeMedia((int) (byte) 1);
        carro0.setOcupado(false);
        carro0.setOcupado(false);
        boolean b13 = carro0.getOcupado();
        java.lang.String str14 = carro0.getMatricula();
        carro0.setVelocidadeMedia((-33));
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i5 == 10);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "n/a" + "'", str6.equals("n/a"));
        org.junit.Assert.assertTrue(b13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "n/a" + "'", str14.equals("n/a"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        java.lang.String str2 = carro0.getMatricula();
        Carro carro3 = new Carro(carro0);
        int i4 = carro3.getFiabilidade();
        carro3.setFiabilidade((int) (byte) 1);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "n/a" + "'", str2.equals("n/a"));
        org.junit.Assert.assertTrue(i4 == 0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        Carro carro4 = new Carro();
        carro4.setMatricula("");
        Carro carro7 = carro4.clone();
        carro4.setPrecoBase((double) 0L);
        Carro carro10 = new Carro(carro4);
        Coordenada coordenada11 = carro4.getCoordenadas();
        Carro carro13 = new Carro((int) (byte) 100, (double) (byte) 1, 0, "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada11, false);
        java.lang.String str14 = carro13.toString();
        org.junit.Assert.assertNotNull(carro7);
        org.junit.Assert.assertNotNull(coordenada11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Matrícula: Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 100km/h\nPreço Base: 1.0€\nFiabilidade: 0\nLugares: 4\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str14.equals("Matrícula: Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 100km/h\nPreço Base: 1.0€\nFiabilidade: 0\nLugares: 4\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        Carro carro4 = new Carro();
        carro4.setMatricula("");
        boolean b8 = carro4.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada9 = carro4.getCoordenadas();
        boolean b10 = carro4.getOcupado();
        java.lang.String str11 = carro4.getMatricula();
        Carro carro16 = new Carro();
        carro16.setMatricula("");
        Carro carro19 = carro16.clone();
        carro16.setPrecoBase((double) 0L);
        Carro carro22 = new Carro();
        int i23 = carro22.getLugares();
        int i24 = carro16.compareTo((Veiculo) carro22);
        java.lang.String str25 = carro22.toString();
        Coordenada coordenada26 = carro22.getCoordenadas();
        Carro carro28 = new Carro((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada26, false);
        carro4.setCoordenadas(coordenada26);
        Carro carro30 = new Carro();
        carro30.setMatricula("");
        Carro carro33 = carro30.clone();
        carro30.setPrecoBase((double) 0L);
        Carro carro36 = new Carro();
        int i37 = carro36.getLugares();
        int i38 = carro30.compareTo((Veiculo) carro36);
        int i39 = carro36.getFiabilidade();
        Carro carro40 = carro36.clone();
        Coordenada coordenada41 = carro40.getCoordenadas();
        carro4.setCoordenadas(coordenada41);
        Carro carro44 = new Carro((-1), (double) (-142), 0, "Matrícula: \nVelocidade Média/km: -1km/h\nPreço Base: 0.0€\nFiabilidade: 1\nLugares: 4\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada41, true);
        org.junit.Assert.assertTrue(b8 == false);
        org.junit.Assert.assertNotNull(coordenada9);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(carro19);
        org.junit.Assert.assertTrue(i23 == 0);
        org.junit.Assert.assertTrue(i24 == 3);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str25.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada26);
        org.junit.Assert.assertNotNull(carro33);
        org.junit.Assert.assertTrue(i37 == 0);
        org.junit.Assert.assertTrue(i38 == 3);
        org.junit.Assert.assertTrue(i39 == 0);
        org.junit.Assert.assertNotNull(carro40);
        org.junit.Assert.assertNotNull(coordenada41);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        Carro carro4 = new Carro(carro0);
        int i5 = carro0.getVelocidadeMedia();
        java.lang.String str6 = carro0.getMatricula();
        Carro carro7 = new Carro(carro0);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i5 == 10);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "n/a" + "'", str6.equals("n/a"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        carro0.setMatricula("n/a");
        Carro carro6 = new Carro();
        carro6.setMatricula("");
        Carro carro9 = carro6.clone();
        carro6.setPrecoBase((double) 0L);
        Carro carro12 = new Carro();
        int i13 = carro12.getLugares();
        int i14 = carro6.compareTo((Veiculo) carro12);
        java.lang.String str15 = carro12.toString();
        Coordenada coordenada16 = carro12.getCoordenadas();
        Carro carro17 = new Carro();
        int i18 = carro17.getLugares();
        Coordenada coordenada19 = carro17.getCoordenadas();
        carro12.setCoordenadas(coordenada19);
        carro0.setCoordenadas(coordenada19);
        carro0.setPrecoBase((double) (-1L));
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(carro9);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(i14 == 3);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str15.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada16);
        org.junit.Assert.assertTrue(i18 == 0);
        org.junit.Assert.assertNotNull(coordenada19);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        Carro carro12 = new Carro();
        carro12.setMatricula("");
        Carro carro15 = carro12.clone();
        carro12.setPrecoBase((double) 0L);
        Carro carro18 = new Carro();
        int i19 = carro18.getLugares();
        int i20 = carro12.compareTo((Veiculo) carro18);
        java.lang.String str21 = carro18.toString();
        Coordenada coordenada22 = carro18.getCoordenadas();
        Carro carro24 = new Carro((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada22, false);
        Carro carro26 = new Carro((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada22, true);
        Carro carro28 = new Carro((int) '#', 10.0d, (-1), "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada22, true);
        carro28.setMatricula("hi!");
        carro28.setFiabilidade((int) (byte) 0);
        org.junit.Assert.assertNotNull(carro15);
        org.junit.Assert.assertTrue(i19 == 0);
        org.junit.Assert.assertTrue(i20 == 3);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str21.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada22);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        Carro carro0 = new Carro();
        carro0.setVelocidadeMedia((int) ' ');
        java.lang.String str3 = carro0.toString();
        Carro carro8 = new Carro();
        carro8.setMatricula("");
        Carro carro11 = carro8.clone();
        Coordenada coordenada12 = carro11.getCoordenadas();
        Carro carro14 = new Carro((int) (byte) 0, (double) 'a', 3, "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada12, false);
        boolean b15 = carro0.equals((java.lang.Object) 'a');
        boolean b16 = carro0.getOcupado();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro11);
        org.junit.Assert.assertNotNull(coordenada12);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertTrue(b16 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        Carro carro0 = new Carro();
        carro0.setVelocidadeMedia((int) ' ');
        java.lang.String str3 = carro0.toString();
        Carro carro8 = new Carro();
        carro8.setMatricula("");
        Carro carro11 = carro8.clone();
        Coordenada coordenada12 = carro11.getCoordenadas();
        Carro carro14 = new Carro((int) (byte) 0, (double) 'a', 3, "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada12, false);
        boolean b15 = carro0.equals((java.lang.Object) 'a');
        carro0.setOcupado(false);
        double d18 = carro0.getPrecoBase();
        Carro carro19 = new Carro();
        carro19.setMatricula("");
        boolean b23 = carro19.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada24 = carro19.getCoordenadas();
        carro19.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Carro carro27 = new Carro(carro19);
        int i28 = carro0.compareTo((Veiculo) carro19);
        carro0.setPrecoBase((double) (short) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro11);
        org.junit.Assert.assertNotNull(coordenada12);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertTrue(d18 == 0.0d);
        org.junit.Assert.assertTrue(b23 == false);
        org.junit.Assert.assertNotNull(coordenada24);
        org.junit.Assert.assertTrue(i28 == (-33));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        carro0.setMatricula("n/a");
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        Coordenada coordenada8 = carro6.getCoordenadas();
        boolean b9 = carro0.equals((java.lang.Object) coordenada8);
        carro0.setFiabilidade((int) (byte) -1);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertNotNull(coordenada8);
        org.junit.Assert.assertTrue(b9 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        Carro carro8 = new Carro();
        carro8.setMatricula("");
        java.lang.String str11 = carro8.toString();
        Carro carro12 = new Carro();
        Carro carro13 = new Carro(carro12);
        java.lang.String str14 = carro12.toString();
        carro12.setFiabilidade(0);
        Carro carro17 = carro12.clone();
        Carro carro18 = new Carro();
        Carro carro19 = new Carro(carro18);
        Carro carro20 = new Carro(carro19);
        Carro carro21 = new Carro();
        Carro carro22 = new Carro(carro21);
        int i23 = carro19.compareTo((Veiculo) carro21);
        Carro carro24 = new Carro();
        carro24.setMatricula("");
        boolean b28 = carro24.equals((java.lang.Object) (-1.0d));
        boolean b29 = carro19.equals((java.lang.Object) (-1.0d));
        Carro carro30 = new Carro();
        carro30.setMatricula("");
        Carro carro33 = carro30.clone();
        carro30.setPrecoBase((double) 0L);
        Carro carro36 = new Carro();
        int i37 = carro36.getLugares();
        int i38 = carro30.compareTo((Veiculo) carro36);
        java.lang.String str39 = carro36.toString();
        Coordenada coordenada40 = carro36.getCoordenadas();
        carro19.setCoordenadas(coordenada40);
        carro12.setCoordenadas(coordenada40);
        carro8.setCoordenadas(coordenada40);
        Carro carro45 = new Carro((int) '4', (double) 1.0f, 4, "hi!", coordenada40, false);
        Carro carro47 = new Carro((int) (byte) 10, (double) 'a', (int) (short) 0, "hi!", coordenada40, true);
        java.lang.String str48 = carro47.getMatricula();
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str11.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str14.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro17);
        org.junit.Assert.assertTrue(i23 == 0);
        org.junit.Assert.assertTrue(b28 == false);
        org.junit.Assert.assertTrue(b29 == false);
        org.junit.Assert.assertNotNull(carro33);
        org.junit.Assert.assertTrue(i37 == 0);
        org.junit.Assert.assertTrue(i38 == 3);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str39.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada40);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "hi!" + "'", str48.equals("hi!"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        Carro carro4 = new Carro();
        carro4.setMatricula("");
        boolean b8 = carro4.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada9 = carro4.getCoordenadas();
        boolean b10 = carro4.getOcupado();
        java.lang.String str11 = carro4.getMatricula();
        Carro carro16 = new Carro();
        carro16.setMatricula("");
        Carro carro19 = carro16.clone();
        carro16.setPrecoBase((double) 0L);
        Carro carro22 = new Carro();
        int i23 = carro22.getLugares();
        int i24 = carro16.compareTo((Veiculo) carro22);
        java.lang.String str25 = carro22.toString();
        Coordenada coordenada26 = carro22.getCoordenadas();
        Carro carro28 = new Carro((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada26, false);
        carro4.setCoordenadas(coordenada26);
        Carro carro31 = new Carro(32, (double) (short) 1, (int) (byte) 1, "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada26, true);
        Carro carro32 = new Carro();
        int i33 = carro32.getLugares();
        Coordenada coordenada34 = carro32.getCoordenadas();
        int i35 = carro31.compareTo((Veiculo) carro32);
        org.junit.Assert.assertTrue(b8 == false);
        org.junit.Assert.assertNotNull(coordenada9);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(carro19);
        org.junit.Assert.assertTrue(i23 == 0);
        org.junit.Assert.assertTrue(i24 == 3);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str25.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada26);
        org.junit.Assert.assertTrue(i33 == 0);
        org.junit.Assert.assertNotNull(coordenada34);
        org.junit.Assert.assertTrue(i35 == 33);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        Carro carro4 = new Carro();
        Carro carro5 = new Carro(carro4);
        Carro carro6 = new Carro(carro5);
        Carro carro7 = new Carro();
        int i8 = carro7.getLugares();
        boolean b9 = carro6.equals((java.lang.Object) carro7);
        Carro carro10 = carro7.clone();
        Coordenada coordenada11 = carro7.getCoordenadas();
        Carro carro13 = new Carro((int) (short) 0, 100.0d, (int) (short) -1, "Matrícula: Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: -1.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada11, true);
        carro13.setPrecoBase((double) 'a');
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue(b9 == true);
        org.junit.Assert.assertNotNull(carro10);
        org.junit.Assert.assertNotNull(coordenada11);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        Carro carro0 = new Carro();
        carro0.setVelocidadeMedia((int) ' ');
        java.lang.String str3 = carro0.toString();
        Carro carro8 = new Carro();
        carro8.setMatricula("");
        Carro carro11 = carro8.clone();
        Coordenada coordenada12 = carro11.getCoordenadas();
        Carro carro14 = new Carro((int) (byte) 0, (double) 'a', 3, "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada12, false);
        boolean b15 = carro0.equals((java.lang.Object) 'a');
        int i16 = carro0.getFiabilidade();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro11);
        org.junit.Assert.assertNotNull(coordenada12);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertTrue(i16 == 0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        java.lang.String str3 = carro0.toString();
        Carro carro4 = carro0.clone();
        carro4.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro4);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        java.lang.String str3 = carro0.toString();
        Carro carro4 = carro0.clone();
        int i5 = carro0.getLugares();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro4);
        org.junit.Assert.assertTrue(i5 == 0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        java.lang.String str2 = carro0.toString();
        carro0.setFiabilidade(0);
        int i5 = carro0.getFiabilidade();
        Carro carro6 = new Carro(carro0);
        Carro carro7 = carro0.clone();
        carro0.setOcupado(false);
        Carro carro10 = new Carro();
        carro10.setMatricula("");
        Carro carro13 = carro10.clone();
        carro10.setPrecoBase((double) 0L);
        java.lang.String str16 = carro10.getMatricula();
        Coordenada coordenada17 = carro10.getCoordenadas();
        carro0.setCoordenadas(coordenada17);
        carro0.setMatricula("Matrícula: Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 97.0€\nFiabilidade: 1\nLugares: 4\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertNotNull(carro7);
        org.junit.Assert.assertNotNull(carro13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(coordenada17);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro(carro0);
        carro6.setPrecoBase((double) (-1.0f));
        carro6.setVelocidadeMedia((int) (short) 0);
        carro6.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        java.lang.String str13 = carro6.toString();
        carro6.setPrecoBase((double) 0);
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Matrícula: Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: -1.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str13.equals("Matrícula: Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: -1.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        Carro carro4 = new Carro(carro0);
        java.lang.String str5 = carro0.toString();
        carro0.setOcupado(false);
        Coordenada coordenada8 = null;
        try {
            carro0.setCoordenadas(coordenada8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str5.equals("Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        Carro carro4 = new Carro();
        carro4.setMatricula("");
        boolean b8 = carro4.equals((java.lang.Object) (-1.0d));
        Carro carro9 = new Carro(carro4);
        Coordenada coordenada10 = carro9.getCoordenadas();
        Carro carro12 = new Carro((int) (short) 0, (double) 1L, (int) (byte) 1, "hi!", coordenada10, false);
        org.junit.Assert.assertTrue(b8 == false);
        org.junit.Assert.assertNotNull(coordenada10);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        java.lang.String str9 = carro6.toString();
        int i10 = carro6.getFiabilidade();
        Carro carro11 = new Carro();
        Carro carro12 = new Carro(carro11);
        Carro carro13 = new Carro(carro12);
        Carro carro14 = new Carro();
        Carro carro15 = new Carro(carro14);
        int i16 = carro12.compareTo((Veiculo) carro14);
        Carro carro17 = new Carro();
        carro17.setMatricula("");
        boolean b21 = carro17.equals((java.lang.Object) (-1.0d));
        boolean b22 = carro12.equals((java.lang.Object) (-1.0d));
        Carro carro23 = new Carro();
        carro23.setMatricula("");
        Carro carro26 = carro23.clone();
        carro23.setPrecoBase((double) 0L);
        Carro carro29 = new Carro();
        int i30 = carro29.getLugares();
        int i31 = carro23.compareTo((Veiculo) carro29);
        java.lang.String str32 = carro29.toString();
        Coordenada coordenada33 = carro29.getCoordenadas();
        carro12.setCoordenadas(coordenada33);
        boolean b35 = carro6.equals((java.lang.Object) carro12);
        boolean b36 = carro6.getOcupado();
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue(b21 == false);
        org.junit.Assert.assertTrue(b22 == false);
        org.junit.Assert.assertNotNull(carro26);
        org.junit.Assert.assertTrue(i30 == 0);
        org.junit.Assert.assertTrue(i31 == 3);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str32.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada33);
        org.junit.Assert.assertTrue(b35 == true);
        org.junit.Assert.assertTrue(b36 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro();
        Carro carro2 = new Carro(carro1);
        int i3 = carro2.getFiabilidade();
        Coordenada coordenada4 = carro2.getCoordenadas();
        carro0.setCoordenadas(coordenada4);
        Carro carro6 = new Carro();
        Carro carro7 = new Carro(carro6);
        java.lang.String str8 = carro6.toString();
        carro6.setFiabilidade(0);
        int i11 = carro6.getFiabilidade();
        Carro carro12 = new Carro();
        Carro carro13 = new Carro(carro12);
        java.lang.String str14 = carro12.toString();
        carro12.setFiabilidade(0);
        Carro carro17 = carro12.clone();
        Carro carro18 = new Carro(carro12);
        Coordenada coordenada19 = carro12.getCoordenadas();
        carro6.setCoordenadas(coordenada19);
        carro0.setCoordenadas(coordenada19);
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertNotNull(coordenada4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str8.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str14.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro17);
        org.junit.Assert.assertNotNull(coordenada19);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Carro carro5 = new Carro(carro0);
        double d6 = carro0.getPrecoBase();
        int i7 = carro0.getLugares();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(i7 == 0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carro0.getCoordenadas();
        carro0.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carro0.setFiabilidade(0);
        Carro carro10 = new Carro();
        carro10.setMatricula("");
        Carro carro13 = carro10.clone();
        carro10.setPrecoBase((double) 0L);
        Carro carro16 = new Carro(carro10);
        int i17 = carro0.compareTo((Veiculo) carro10);
        Carro carro18 = new Carro(carro10);
        carro18.setOcupado(false);
        java.lang.String str21 = carro18.getMatricula();
        carro18.setFiabilidade((int) (short) 10);
        carro18.setPrecoBase((double) 10.0f);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertNotNull(carro13);
        org.junit.Assert.assertTrue(i17 == (-142));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        int i9 = carro6.getFiabilidade();
        Carro carro10 = carro6.clone();
        Coordenada coordenada11 = carro10.getCoordenadas();
        carro10.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n");
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertNotNull(carro10);
        org.junit.Assert.assertNotNull(coordenada11);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        carro0.setMatricula("n/a");
        carro0.setPrecoBase((double) 1L);
        Coordenada coordenada8 = carro0.getCoordenadas();
        Carro carro9 = new Carro();
        carro9.setMatricula("");
        boolean b13 = carro9.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada14 = carro9.getCoordenadas();
        carro9.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carro9.setFiabilidade(0);
        Carro carro19 = new Carro();
        carro19.setMatricula("");
        Carro carro22 = carro19.clone();
        carro19.setPrecoBase((double) 0L);
        Carro carro25 = new Carro(carro19);
        int i26 = carro9.compareTo((Veiculo) carro19);
        Carro carro27 = new Carro(carro19);
        boolean b28 = carro0.equals((java.lang.Object) carro27);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(coordenada8);
        org.junit.Assert.assertTrue(b13 == false);
        org.junit.Assert.assertNotNull(coordenada14);
        org.junit.Assert.assertNotNull(carro22);
        org.junit.Assert.assertTrue(i26 == (-142));
        org.junit.Assert.assertTrue(b28 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        Carro carro0 = new Carro();
        carro0.setVelocidadeMedia((int) ' ');
        java.lang.String str3 = carro0.toString();
        Carro carro8 = new Carro();
        carro8.setMatricula("");
        Carro carro11 = carro8.clone();
        Coordenada coordenada12 = carro11.getCoordenadas();
        Carro carro14 = new Carro((int) (byte) 0, (double) 'a', 3, "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada12, false);
        boolean b15 = carro0.equals((java.lang.Object) 'a');
        carro0.setOcupado(false);
        double d18 = carro0.getPrecoBase();
        carro0.setVelocidadeMedia((int) (byte) 100);
        int i21 = carro0.getFiabilidade();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro11);
        org.junit.Assert.assertNotNull(coordenada12);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertTrue(d18 == 0.0d);
        org.junit.Assert.assertTrue(i21 == 0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carro0.getCoordenadas();
        carro0.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carro0.setFiabilidade(0);
        carro0.setVelocidadeMedia((int) (short) -1);
        carro0.setFiabilidade((int) (short) 1);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        java.lang.String str2 = carro0.toString();
        carro0.setMatricula("hi!");
        carro0.setPrecoBase((double) 10.0f);
        carro0.setOcupado(true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        int i2 = carro0.getLugares();
        Carro carro3 = carro0.clone();
        Carro carro4 = carro0.clone();
        java.lang.String str5 = carro4.getMatricula();
        org.junit.Assert.assertTrue(i2 == 0);
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertNotNull(carro4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "n/a" + "'", str5.equals("n/a"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        int i4 = carro3.getVelocidadeMedia();
        java.lang.Object obj5 = null;
        boolean b6 = carro3.equals(obj5);
        carro3.setMatricula("Matrícula: Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: -1.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue(b6 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        Coordenada coordenada4 = carro3.getCoordenadas();
        Carro carro5 = new Carro();
        carro5.setMatricula("");
        Carro carro8 = carro5.clone();
        carro5.setPrecoBase((double) 0L);
        Carro carro11 = new Carro();
        int i12 = carro11.getLugares();
        int i13 = carro5.compareTo((Veiculo) carro11);
        java.lang.String str14 = carro11.toString();
        Coordenada coordenada15 = carro11.getCoordenadas();
        int i16 = carro3.compareTo((Veiculo) carro11);
        java.lang.String str17 = carro3.getMatricula();
        carro3.setPrecoBase((double) 10);
        java.lang.String str20 = carro3.getMatricula();
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertNotNull(coordenada4);
        org.junit.Assert.assertNotNull(carro8);
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertTrue(i13 == 3);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str14.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada15);
        org.junit.Assert.assertTrue(i16 == 3);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        Carro carro4 = new Carro(carro0);
        int i5 = carro0.getVelocidadeMedia();
        carro0.setMatricula("");
        int i8 = carro0.getFiabilidade();
        int i9 = carro0.getVelocidadeMedia();
        int i10 = carro0.getVelocidadeMedia();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i5 == 10);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue(i9 == 10);
        org.junit.Assert.assertTrue(i10 == 10);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro(carro0);
        carro6.setPrecoBase((double) (-1.0f));
        java.lang.String str9 = carro6.getMatricula();
        double d10 = carro6.getPrecoBase();
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue(d10 == (-1.0d));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carro0.getCoordenadas();
        java.lang.String str6 = carro0.toString();
        Carro carro7 = new Carro();
        carro7.setMatricula("");
        Carro carro10 = carro7.clone();
        carro7.setPrecoBase((double) 0L);
        Carro carro13 = new Carro();
        int i14 = carro13.getLugares();
        int i15 = carro7.compareTo((Veiculo) carro13);
        Carro carro16 = new Carro();
        carro16.setMatricula("");
        Carro carro19 = carro16.clone();
        carro16.setPrecoBase((double) 0L);
        Carro carro22 = new Carro();
        int i23 = carro22.getLugares();
        int i24 = carro16.compareTo((Veiculo) carro22);
        java.lang.String str25 = carro22.toString();
        Coordenada coordenada26 = carro22.getCoordenadas();
        Carro carro27 = new Carro();
        int i28 = carro27.getLugares();
        Coordenada coordenada29 = carro27.getCoordenadas();
        carro22.setCoordenadas(coordenada29);
        Carro carro31 = new Carro(carro22);
        int i32 = carro7.compareTo((Veiculo) carro22);
        int i33 = carro22.getFiabilidade();
        int i34 = carro0.compareTo((Veiculo) carro22);
        Coordenada coordenada35 = carro22.getCoordenadas();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str6.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro10);
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(i15 == 3);
        org.junit.Assert.assertNotNull(carro19);
        org.junit.Assert.assertTrue(i23 == 0);
        org.junit.Assert.assertTrue(i24 == 3);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str25.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada26);
        org.junit.Assert.assertTrue(i28 == 0);
        org.junit.Assert.assertNotNull(coordenada29);
        org.junit.Assert.assertTrue(i32 == 3);
        org.junit.Assert.assertTrue(i33 == 0);
        org.junit.Assert.assertTrue(i34 == 3);
        org.junit.Assert.assertNotNull(coordenada35);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        Carro carro4 = new Carro(carro0);
        carro4.setFiabilidade((int) (short) 100);
        double d7 = carro4.getPrecoBase();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(d7 == 0.0d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        Carro carro4 = new Carro();
        carro4.setMatricula("");
        Carro carro7 = carro4.clone();
        int i8 = carro7.getVelocidadeMedia();
        Coordenada coordenada9 = carro7.getCoordenadas();
        Carro carro11 = new Carro((-142), (double) 0, 1, "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada9, false);
        carro11.setVelocidadeMedia(3);
        org.junit.Assert.assertNotNull(carro7);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertNotNull(coordenada9);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        Carro carro4 = new Carro(carro3);
        int i5 = carro1.compareTo((Veiculo) carro3);
        Carro carro6 = new Carro();
        carro6.setMatricula("");
        boolean b10 = carro6.equals((java.lang.Object) (-1.0d));
        boolean b11 = carro1.equals((java.lang.Object) (-1.0d));
        Carro carro12 = new Carro(carro1);
        Carro carro17 = new Carro();
        Carro carro18 = new Carro(carro17);
        Carro carro19 = new Carro(carro18);
        Carro carro20 = new Carro();
        Carro carro21 = new Carro(carro20);
        int i22 = carro18.compareTo((Veiculo) carro20);
        Carro carro23 = new Carro();
        carro23.setMatricula("");
        boolean b27 = carro23.equals((java.lang.Object) (-1.0d));
        boolean b28 = carro18.equals((java.lang.Object) (-1.0d));
        Carro carro29 = new Carro();
        carro29.setMatricula("");
        Carro carro32 = carro29.clone();
        carro29.setPrecoBase((double) 0L);
        Carro carro35 = new Carro();
        int i36 = carro35.getLugares();
        int i37 = carro29.compareTo((Veiculo) carro35);
        java.lang.String str38 = carro35.toString();
        Coordenada coordenada39 = carro35.getCoordenadas();
        carro18.setCoordenadas(coordenada39);
        Carro carro42 = new Carro((-1), 10.0d, (int) (byte) 1, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada39, true);
        int i43 = carro1.compareTo((Veiculo) carro42);
        carro42.setVelocidadeMedia(100);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertTrue(i22 == 0);
        org.junit.Assert.assertTrue(b27 == false);
        org.junit.Assert.assertTrue(b28 == false);
        org.junit.Assert.assertNotNull(carro32);
        org.junit.Assert.assertTrue(i36 == 0);
        org.junit.Assert.assertTrue(i37 == 3);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str38.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada39);
        org.junit.Assert.assertTrue(i43 == (-33));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carro0.getCoordenadas();
        carro0.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carro0.setFiabilidade(0);
        int i10 = carro0.getVelocidadeMedia();
        Carro carro11 = new Carro();
        Carro carro12 = new Carro();
        Carro carro13 = new Carro(carro12);
        int i14 = carro13.getFiabilidade();
        Coordenada coordenada15 = carro13.getCoordenadas();
        carro11.setCoordenadas(coordenada15);
        boolean b17 = carro0.equals((java.lang.Object) carro11);
        java.lang.String str18 = carro11.toString();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertNotNull(coordenada15);
        org.junit.Assert.assertTrue(b17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str18.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        java.lang.String str2 = carro0.getMatricula();
        Carro carro3 = new Carro(carro0);
        int i4 = carro3.getFiabilidade();
        carro3.setPrecoBase(1.0d);
        Carro carro7 = new Carro();
        Carro carro8 = new Carro(carro7);
        Carro carro9 = new Carro(carro8);
        Carro carro10 = new Carro();
        Carro carro11 = new Carro(carro10);
        int i12 = carro8.compareTo((Veiculo) carro10);
        Carro carro13 = new Carro();
        carro13.setMatricula("");
        boolean b17 = carro13.equals((java.lang.Object) (-1.0d));
        boolean b18 = carro8.equals((java.lang.Object) (-1.0d));
        Carro carro19 = new Carro(carro8);
        Carro carro20 = new Carro(carro8);
        boolean b21 = carro3.equals((java.lang.Object) carro8);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "n/a" + "'", str2.equals("n/a"));
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertTrue(b17 == false);
        org.junit.Assert.assertTrue(b18 == false);
        org.junit.Assert.assertTrue(b21 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carro0.getCoordenadas();
        boolean b6 = carro0.getOcupado();
        java.lang.String str7 = carro0.getMatricula();
        Carro carro12 = new Carro();
        carro12.setMatricula("");
        Carro carro15 = carro12.clone();
        carro12.setPrecoBase((double) 0L);
        Carro carro18 = new Carro();
        int i19 = carro18.getLugares();
        int i20 = carro12.compareTo((Veiculo) carro18);
        java.lang.String str21 = carro18.toString();
        Coordenada coordenada22 = carro18.getCoordenadas();
        Carro carro24 = new Carro((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada22, false);
        carro0.setCoordenadas(coordenada22);
        carro0.setOcupado(true);
        carro0.setOcupado(true);
        java.lang.String str30 = carro0.toString();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(b6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(carro15);
        org.junit.Assert.assertTrue(i19 == 0);
        org.junit.Assert.assertTrue(i20 == 3);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str21.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada22);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n" + "'", str30.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        java.lang.String str9 = carro6.toString();
        int i10 = carro6.getFiabilidade();
        carro6.setPrecoBase(10.0d);
        int i13 = carro6.getVelocidadeMedia();
        Carro carro18 = new Carro();
        Carro carro19 = new Carro(carro18);
        Carro carro20 = new Carro(carro19);
        Carro carro21 = new Carro();
        Carro carro22 = new Carro(carro21);
        int i23 = carro19.compareTo((Veiculo) carro21);
        Carro carro24 = new Carro();
        carro24.setMatricula("");
        boolean b28 = carro24.equals((java.lang.Object) (-1.0d));
        boolean b29 = carro19.equals((java.lang.Object) (-1.0d));
        Carro carro30 = new Carro();
        carro30.setMatricula("");
        Carro carro33 = carro30.clone();
        carro30.setPrecoBase((double) 0L);
        Carro carro36 = new Carro();
        int i37 = carro36.getLugares();
        int i38 = carro30.compareTo((Veiculo) carro36);
        java.lang.String str39 = carro36.toString();
        Coordenada coordenada40 = carro36.getCoordenadas();
        carro19.setCoordenadas(coordenada40);
        Carro carro43 = new Carro((-1), 10.0d, (int) (byte) 1, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada40, true);
        carro6.setCoordenadas(coordenada40);
        carro6.setFiabilidade(0);
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(i23 == 0);
        org.junit.Assert.assertTrue(b28 == false);
        org.junit.Assert.assertTrue(b29 == false);
        org.junit.Assert.assertNotNull(carro33);
        org.junit.Assert.assertTrue(i37 == 0);
        org.junit.Assert.assertTrue(i38 == 3);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str39.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada40);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        java.lang.String str9 = carro6.toString();
        int i10 = carro6.getFiabilidade();
        carro6.setPrecoBase(10.0d);
        int i13 = carro6.getVelocidadeMedia();
        Carro carro14 = new Carro(carro6);
        carro14.setFiabilidade((int) (short) 10);
        java.lang.Object obj17 = null;
        boolean b18 = carro14.equals(obj17);
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(b18 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        int i9 = carro6.getFiabilidade();
        Carro carro10 = carro6.clone();
        Coordenada coordenada11 = carro10.getCoordenadas();
        carro10.setVelocidadeMedia(33);
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertNotNull(carro10);
        org.junit.Assert.assertNotNull(coordenada11);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro(carro0);
        carro6.setPrecoBase((double) (-1.0f));
        carro6.setVelocidadeMedia((int) (short) 0);
        carro6.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Carro carro13 = new Carro();
        int i14 = carro13.getLugares();
        carro13.setVelocidadeMedia(10);
        Carro carro17 = new Carro(carro13);
        Carro carro18 = carro17.clone();
        int i19 = carro6.compareTo((Veiculo) carro18);
        java.lang.String str20 = carro18.getMatricula();
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertNotNull(carro18);
        org.junit.Assert.assertTrue(i19 == 33);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "n/a" + "'", str20.equals("n/a"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carro0.getCoordenadas();
        int i6 = carro0.getVelocidadeMedia();
        Carro carro7 = new Carro();
        carro7.setMatricula("");
        Carro carro10 = carro7.clone();
        carro10.setOcupado(true);
        boolean b13 = carro0.equals((java.lang.Object) carro10);
        carro10.setMatricula("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Carro carro16 = new Carro();
        Carro carro17 = new Carro(carro16);
        java.lang.String str18 = carro16.toString();
        carro16.setFiabilidade(0);
        Carro carro21 = carro16.clone();
        int i22 = carro16.getLugares();
        Carro carro27 = new Carro();
        Carro carro28 = new Carro(carro27);
        Carro carro29 = new Carro(carro28);
        Carro carro30 = new Carro();
        Carro carro31 = new Carro(carro30);
        int i32 = carro28.compareTo((Veiculo) carro30);
        Carro carro33 = new Carro();
        carro33.setMatricula("");
        boolean b37 = carro33.equals((java.lang.Object) (-1.0d));
        boolean b38 = carro28.equals((java.lang.Object) (-1.0d));
        Carro carro39 = new Carro();
        carro39.setMatricula("");
        Carro carro42 = carro39.clone();
        carro39.setPrecoBase((double) 0L);
        Carro carro45 = new Carro();
        int i46 = carro45.getLugares();
        int i47 = carro39.compareTo((Veiculo) carro45);
        java.lang.String str48 = carro45.toString();
        Coordenada coordenada49 = carro45.getCoordenadas();
        carro28.setCoordenadas(coordenada49);
        Carro carro52 = new Carro((-1), 10.0d, (int) (byte) 1, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada49, true);
        carro16.setCoordenadas(coordenada49);
        carro10.setCoordenadas(coordenada49);
        Carro carro55 = new Carro(carro10);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertNotNull(carro10);
        org.junit.Assert.assertTrue(b13 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str18.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro21);
        org.junit.Assert.assertTrue(i22 == 0);
        org.junit.Assert.assertTrue(i32 == 0);
        org.junit.Assert.assertTrue(b37 == false);
        org.junit.Assert.assertTrue(b38 == false);
        org.junit.Assert.assertNotNull(carro42);
        org.junit.Assert.assertTrue(i46 == 0);
        org.junit.Assert.assertTrue(i47 == 3);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str48.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada49);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        carro1.setMatricula("Matrícula: hi!\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: -1\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        Carro carro4 = new Carro();
        carro4.setMatricula("");
        Carro carro7 = carro4.clone();
        carro4.setPrecoBase((double) 0L);
        Carro carro10 = new Carro();
        int i11 = carro10.getLugares();
        int i12 = carro4.compareTo((Veiculo) carro10);
        java.lang.String str13 = carro10.toString();
        int i14 = carro10.getFiabilidade();
        Carro carro15 = new Carro();
        Carro carro16 = new Carro(carro15);
        java.lang.String str17 = carro15.toString();
        carro15.setFiabilidade(0);
        Carro carro20 = carro15.clone();
        int i21 = carro20.getFiabilidade();
        Coordenada coordenada22 = carro20.getCoordenadas();
        carro10.setCoordenadas(coordenada22);
        Carro carro25 = new Carro((int) 'a', (double) (short) -1, (int) (short) 0, "n/a", coordenada22, true);
        org.junit.Assert.assertNotNull(carro7);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(i12 == 3);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str13.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str17.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro20);
        org.junit.Assert.assertTrue(i21 == 0);
        org.junit.Assert.assertNotNull(coordenada22);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        int i4 = carro3.getLugares();
        boolean b5 = carro2.equals((java.lang.Object) carro3);
        int i6 = carro3.getFiabilidade();
        boolean b7 = carro3.getOcupado();
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue(b5 == true);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertTrue(b7 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        Carro carro4 = carro0.clone();
        int i5 = carro4.getLugares();
        Coordenada coordenada6 = carro4.getCoordenadas();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(carro4);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertNotNull(coordenada6);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        Carro carro4 = new Carro();
        carro4.setMatricula("");
        Carro carro7 = carro4.clone();
        carro4.setPrecoBase((double) 0L);
        Carro carro10 = new Carro();
        int i11 = carro10.getLugares();
        int i12 = carro4.compareTo((Veiculo) carro10);
        java.lang.String str13 = carro10.toString();
        Coordenada coordenada14 = carro10.getCoordenadas();
        Carro carro16 = new Carro((int) ' ', (double) 100.0f, (int) (byte) -1, "", coordenada14, false);
        int i17 = carro16.getLugares();
        org.junit.Assert.assertNotNull(carro7);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(i12 == 3);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str13.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada14);
        org.junit.Assert.assertTrue(i17 == 4);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Carro carro5 = new Carro(carro0);
        double d6 = carro0.getPrecoBase();
        java.lang.String str7 = carro0.toString();
        int i8 = carro0.getVelocidadeMedia();
        int i9 = carro0.getVelocidadeMedia();
        double d10 = carro0.getPrecoBase();
        Coordenada coordenada11 = carro0.getCoordenadas();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str7.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertTrue(d10 == 0.0d);
        org.junit.Assert.assertNotNull(coordenada11);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        Coordenada coordenada4 = carro3.getCoordenadas();
        Carro carro5 = new Carro();
        carro5.setMatricula("");
        Carro carro8 = carro5.clone();
        carro5.setPrecoBase((double) 0L);
        Carro carro11 = new Carro();
        int i12 = carro11.getLugares();
        int i13 = carro5.compareTo((Veiculo) carro11);
        java.lang.String str14 = carro11.toString();
        Coordenada coordenada15 = carro11.getCoordenadas();
        int i16 = carro3.compareTo((Veiculo) carro11);
        Carro carro17 = new Carro();
        carro17.setMatricula("");
        Carro carro20 = carro17.clone();
        carro17.setPrecoBase((double) 0L);
        java.lang.String str23 = carro17.getMatricula();
        Coordenada coordenada24 = carro17.getCoordenadas();
        carro3.setCoordenadas(coordenada24);
        carro3.setFiabilidade((int) (short) 1);
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertNotNull(coordenada4);
        org.junit.Assert.assertNotNull(carro8);
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertTrue(i13 == 3);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str14.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada15);
        org.junit.Assert.assertTrue(i16 == 3);
        org.junit.Assert.assertNotNull(carro20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertNotNull(coordenada24);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        java.lang.String str9 = carro6.toString();
        int i10 = carro6.getFiabilidade();
        carro6.setPrecoBase(10.0d);
        int i13 = carro6.getVelocidadeMedia();
        java.lang.String str14 = carro6.getMatricula();
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "n/a" + "'", str14.equals("n/a"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        Carro carro9 = new Carro();
        carro9.setMatricula("");
        Carro carro12 = carro9.clone();
        carro9.setPrecoBase((double) 0L);
        Carro carro15 = new Carro();
        int i16 = carro15.getLugares();
        int i17 = carro9.compareTo((Veiculo) carro15);
        java.lang.String str18 = carro15.toString();
        Coordenada coordenada19 = carro15.getCoordenadas();
        Carro carro20 = new Carro();
        int i21 = carro20.getLugares();
        Coordenada coordenada22 = carro20.getCoordenadas();
        carro15.setCoordenadas(coordenada22);
        Carro carro24 = new Carro(carro15);
        int i25 = carro0.compareTo((Veiculo) carro15);
        int i26 = carro15.getFiabilidade();
        double d27 = carro15.getPrecoBase();
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertNotNull(carro12);
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue(i17 == 3);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str18.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada19);
        org.junit.Assert.assertTrue(i21 == 0);
        org.junit.Assert.assertNotNull(coordenada22);
        org.junit.Assert.assertTrue(i25 == 3);
        org.junit.Assert.assertTrue(i26 == 0);
        org.junit.Assert.assertTrue(d27 == 0.0d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        int i4 = carro3.getLugares();
        boolean b5 = carro2.equals((java.lang.Object) carro3);
        Carro carro6 = carro3.clone();
        carro6.setVelocidadeMedia((int) (short) 0);
        carro6.setFiabilidade((-33));
        java.lang.String str11 = carro6.toString();
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue(b5 == true);
        org.junit.Assert.assertNotNull(carro6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: -33\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str11.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: -33\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        java.lang.String str2 = carro0.getMatricula();
        Carro carro3 = new Carro(carro0);
        carro0.setOcupado(true);
        double d6 = carro0.getPrecoBase();
        java.lang.String str7 = carro0.getMatricula();
        carro0.setPrecoBase((double) 33);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "n/a" + "'", str2.equals("n/a"));
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "n/a" + "'", str7.equals("n/a"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro3.setOcupado(true);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        carro6.setVelocidadeMedia(10);
        int i10 = carro3.compareTo((Veiculo) carro6);
        Carro carro11 = new Carro(carro3);
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i10 == 3);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        Carro carro9 = new Carro(carro6);
        int i10 = carro9.getVelocidadeMedia();
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue(i10 == 0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        Carro carro4 = carro0.clone();
        Carro carro5 = new Carro(carro0);
        carro0.setMatricula("Matrícula: Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 100km/h\nPreço Base: 1.0€\nFiabilidade: 0\nLugares: 4\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(carro4);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        java.lang.String str4 = carro0.toString();
        java.lang.String str5 = carro0.getMatricula();
        Carro carro6 = new Carro(carro0);
        carro6.setPrecoBase((double) (byte) 1);
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str4.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        Carro carro4 = new Carro();
        Carro carro5 = new Carro(carro4);
        Carro carro6 = new Carro(carro5);
        Carro carro7 = new Carro();
        Carro carro8 = new Carro(carro7);
        int i9 = carro5.compareTo((Veiculo) carro7);
        Carro carro10 = new Carro();
        carro10.setMatricula("");
        boolean b14 = carro10.equals((java.lang.Object) (-1.0d));
        boolean b15 = carro5.equals((java.lang.Object) (-1.0d));
        Carro carro16 = new Carro();
        carro16.setMatricula("");
        Carro carro19 = carro16.clone();
        carro16.setPrecoBase((double) 0L);
        Carro carro22 = new Carro();
        int i23 = carro22.getLugares();
        int i24 = carro16.compareTo((Veiculo) carro22);
        java.lang.String str25 = carro22.toString();
        Coordenada coordenada26 = carro22.getCoordenadas();
        carro5.setCoordenadas(coordenada26);
        Carro carro29 = new Carro((-1), 10.0d, (int) (byte) 1, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada26, true);
        int i30 = carro29.getVelocidadeMedia();
        java.lang.String str31 = carro29.getMatricula();
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertNotNull(carro19);
        org.junit.Assert.assertTrue(i23 == 0);
        org.junit.Assert.assertTrue(i24 == 3);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str25.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada26);
        org.junit.Assert.assertTrue(i30 == (-1));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str31.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        Carro carro12 = new Carro();
        carro12.setMatricula("");
        Carro carro15 = carro12.clone();
        carro12.setPrecoBase((double) 0L);
        Carro carro18 = new Carro();
        int i19 = carro18.getLugares();
        int i20 = carro12.compareTo((Veiculo) carro18);
        java.lang.String str21 = carro18.toString();
        Coordenada coordenada22 = carro18.getCoordenadas();
        Carro carro24 = new Carro((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada22, false);
        Carro carro26 = new Carro((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada22, true);
        Carro carro28 = new Carro((int) '#', 10.0d, (-1), "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada22, true);
        carro28.setMatricula("hi!");
        java.lang.String str31 = carro28.toString();
        org.junit.Assert.assertNotNull(carro15);
        org.junit.Assert.assertTrue(i19 == 0);
        org.junit.Assert.assertTrue(i20 == 3);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str21.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada22);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Matrícula: hi!\nVelocidade Média/km: 35km/h\nPreço Base: 10.0€\nFiabilidade: -1\nLugares: 4\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n" + "'", str31.equals("Matrícula: hi!\nVelocidade Média/km: 35km/h\nPreço Base: 10.0€\nFiabilidade: -1\nLugares: 4\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        java.lang.String str3 = carro0.toString();
        Carro carro4 = new Carro();
        Carro carro5 = new Carro(carro4);
        java.lang.String str6 = carro4.toString();
        carro4.setFiabilidade(0);
        Carro carro9 = carro4.clone();
        Carro carro10 = new Carro();
        Carro carro11 = new Carro(carro10);
        Carro carro12 = new Carro(carro11);
        Carro carro13 = new Carro();
        Carro carro14 = new Carro(carro13);
        int i15 = carro11.compareTo((Veiculo) carro13);
        Carro carro16 = new Carro();
        carro16.setMatricula("");
        boolean b20 = carro16.equals((java.lang.Object) (-1.0d));
        boolean b21 = carro11.equals((java.lang.Object) (-1.0d));
        Carro carro22 = new Carro();
        carro22.setMatricula("");
        Carro carro25 = carro22.clone();
        carro22.setPrecoBase((double) 0L);
        Carro carro28 = new Carro();
        int i29 = carro28.getLugares();
        int i30 = carro22.compareTo((Veiculo) carro28);
        java.lang.String str31 = carro28.toString();
        Coordenada coordenada32 = carro28.getCoordenadas();
        carro11.setCoordenadas(coordenada32);
        carro4.setCoordenadas(coordenada32);
        carro0.setCoordenadas(coordenada32);
        carro0.setFiabilidade((int) '4');
        carro0.setPrecoBase((double) (-33));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str6.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro9);
        org.junit.Assert.assertTrue(i15 == 0);
        org.junit.Assert.assertTrue(b20 == false);
        org.junit.Assert.assertTrue(b21 == false);
        org.junit.Assert.assertNotNull(carro25);
        org.junit.Assert.assertTrue(i29 == 0);
        org.junit.Assert.assertTrue(i30 == 3);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str31.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada32);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        Carro carro4 = new Carro(carro3);
        int i5 = carro1.compareTo((Veiculo) carro3);
        carro1.setVelocidadeMedia((int) (short) 100);
        Coordenada coordenada8 = carro1.getCoordenadas();
        boolean b9 = carro1.getOcupado();
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertNotNull(coordenada8);
        org.junit.Assert.assertTrue(b9 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carro0.getCoordenadas();
        carro0.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carro0.setFiabilidade(0);
        Carro carro10 = new Carro();
        carro10.setMatricula("");
        boolean b14 = carro10.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada15 = carro10.getCoordenadas();
        int i16 = carro10.getVelocidadeMedia();
        boolean b17 = carro0.equals((java.lang.Object) carro10);
        Carro carro18 = new Carro();
        carro18.setMatricula("");
        Carro carro21 = carro18.clone();
        carro18.setPrecoBase((double) 0L);
        Carro carro24 = new Carro();
        int i25 = carro24.getLugares();
        int i26 = carro18.compareTo((Veiculo) carro24);
        int i27 = carro24.getFiabilidade();
        int i28 = carro10.compareTo((Veiculo) carro24);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertNotNull(coordenada15);
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue(b17 == false);
        org.junit.Assert.assertNotNull(carro21);
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue(i26 == 3);
        org.junit.Assert.assertTrue(i27 == 0);
        org.junit.Assert.assertTrue(i28 == 3);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        java.lang.String str2 = carro0.toString();
        carro0.setFiabilidade(0);
        carro0.setOcupado(true);
        boolean b7 = carro0.getOcupado();
        carro0.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carro0.setMatricula("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        int i12 = carro0.getVelocidadeMedia();
        Coordenada coordenada13 = carro0.getCoordenadas();
        Coordenada coordenada14 = carro0.getCoordenadas();
        carro0.setOcupado(true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(b7 == true);
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertNotNull(coordenada13);
        org.junit.Assert.assertNotNull(coordenada14);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro();
        Carro carro2 = new Carro(carro1);
        int i3 = carro2.getFiabilidade();
        Coordenada coordenada4 = carro2.getCoordenadas();
        carro0.setCoordenadas(coordenada4);
        int i6 = carro0.getVelocidadeMedia();
        int i7 = carro0.getLugares();
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertNotNull(coordenada4);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertTrue(i7 == 0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        Carro carro2 = carro0.clone();
        Carro carro3 = new Carro(carro2);
        Coordenada coordenada4 = carro3.getCoordenadas();
        Carro carro5 = carro3.clone();
        Carro carro6 = new Carro();
        carro6.setMatricula("");
        boolean b10 = carro6.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada11 = carro6.getCoordenadas();
        boolean b12 = carro6.getOcupado();
        java.lang.String str13 = carro6.getMatricula();
        Carro carro18 = new Carro();
        carro18.setMatricula("");
        Carro carro21 = carro18.clone();
        carro18.setPrecoBase((double) 0L);
        Carro carro24 = new Carro();
        int i25 = carro24.getLugares();
        int i26 = carro18.compareTo((Veiculo) carro24);
        java.lang.String str27 = carro24.toString();
        Coordenada coordenada28 = carro24.getCoordenadas();
        Carro carro30 = new Carro((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada28, false);
        carro6.setCoordenadas(coordenada28);
        boolean b32 = carro3.equals((java.lang.Object) carro6);
        Carro carro33 = new Carro(carro3);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(carro2);
        org.junit.Assert.assertNotNull(coordenada4);
        org.junit.Assert.assertNotNull(carro5);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertNotNull(coordenada11);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(carro21);
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue(i26 == 3);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str27.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada28);
        org.junit.Assert.assertTrue(b32 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        Carro carro4 = new Carro(carro3);
        int i5 = carro1.compareTo((Veiculo) carro3);
        Carro carro6 = new Carro();
        carro6.setMatricula("");
        boolean b10 = carro6.equals((java.lang.Object) (-1.0d));
        boolean b11 = carro1.equals((java.lang.Object) (-1.0d));
        Carro carro12 = new Carro();
        carro12.setMatricula("");
        Carro carro15 = carro12.clone();
        carro12.setPrecoBase((double) 0L);
        Carro carro18 = new Carro();
        int i19 = carro18.getLugares();
        int i20 = carro12.compareTo((Veiculo) carro18);
        java.lang.String str21 = carro18.toString();
        Coordenada coordenada22 = carro18.getCoordenadas();
        carro1.setCoordenadas(coordenada22);
        carro1.setVelocidadeMedia((int) ' ');
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertNotNull(carro15);
        org.junit.Assert.assertTrue(i19 == 0);
        org.junit.Assert.assertTrue(i20 == 3);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str21.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada22);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        Carro carro4 = new Carro(carro3);
        int i5 = carro1.compareTo((Veiculo) carro3);
        Carro carro6 = new Carro();
        carro6.setMatricula("");
        boolean b10 = carro6.equals((java.lang.Object) (-1.0d));
        boolean b11 = carro1.equals((java.lang.Object) (-1.0d));
        Carro carro12 = new Carro();
        carro12.setMatricula("");
        Carro carro15 = carro12.clone();
        carro12.setPrecoBase((double) 0L);
        Carro carro18 = new Carro();
        int i19 = carro18.getLugares();
        int i20 = carro12.compareTo((Veiculo) carro18);
        java.lang.String str21 = carro18.toString();
        Coordenada coordenada22 = carro18.getCoordenadas();
        carro1.setCoordenadas(coordenada22);
        carro1.setPrecoBase((double) (short) 10);
        int i26 = carro1.getFiabilidade();
        Carro carro27 = new Carro();
        carro27.setMatricula("");
        Carro carro30 = carro27.clone();
        carro27.setPrecoBase((double) 0L);
        Carro carro33 = new Carro();
        int i34 = carro33.getLugares();
        int i35 = carro27.compareTo((Veiculo) carro33);
        java.lang.String str36 = carro33.toString();
        Coordenada coordenada37 = carro33.getCoordenadas();
        carro33.setMatricula("hi!");
        double d40 = carro33.getPrecoBase();
        boolean b41 = carro1.equals((java.lang.Object) carro33);
        carro1.setOcupado(false);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertNotNull(carro15);
        org.junit.Assert.assertTrue(i19 == 0);
        org.junit.Assert.assertTrue(i20 == 3);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str21.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada22);
        org.junit.Assert.assertTrue(i26 == 0);
        org.junit.Assert.assertNotNull(carro30);
        org.junit.Assert.assertTrue(i34 == 0);
        org.junit.Assert.assertTrue(i35 == 3);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str36.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada37);
        org.junit.Assert.assertTrue(d40 == 0.0d);
        org.junit.Assert.assertTrue(b41 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        Carro carro4 = new Carro(carro3);
        int i5 = carro1.compareTo((Veiculo) carro3);
        int i6 = carro3.getVelocidadeMedia();
        Carro carro7 = carro3.clone();
        double d8 = carro7.getPrecoBase();
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertNotNull(carro7);
        org.junit.Assert.assertTrue(d8 == 0.0d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        Carro carro4 = new Carro(carro3);
        int i5 = carro1.compareTo((Veiculo) carro3);
        int i6 = carro3.getVelocidadeMedia();
        Carro carro7 = carro3.clone();
        int i8 = carro7.getFiabilidade();
        int i9 = carro7.getFiabilidade();
        Carro carro10 = new Carro(carro7);
        carro7.setFiabilidade((-145));
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertNotNull(carro7);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue(i9 == 0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carro0.getCoordenadas();
        boolean b6 = carro0.getOcupado();
        java.lang.String str7 = carro0.getMatricula();
        Carro carro8 = carro0.clone();
        Carro carro9 = new Carro(carro0);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(b6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(carro8);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        Carro carro4 = new Carro(carro0);
        int i5 = carro0.getVelocidadeMedia();
        java.lang.String str6 = carro0.getMatricula();
        boolean b7 = carro0.getOcupado();
        carro0.setFiabilidade((int) (short) 1);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i5 == 10);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "n/a" + "'", str6.equals("n/a"));
        org.junit.Assert.assertTrue(b7 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        Coordenada coordenada2 = carro0.getCoordenadas();
        carro0.setFiabilidade(3);
        Carro carro5 = carro0.clone();
        double d6 = carro5.getPrecoBase();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(coordenada2);
        org.junit.Assert.assertNotNull(carro5);
        org.junit.Assert.assertTrue(d6 == 0.0d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        carro0.setMatricula("n/a");
        carro0.setPrecoBase((double) 1L);
        int i8 = carro0.getFiabilidade();
        java.lang.String str9 = carro0.getMatricula();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "n/a" + "'", str9.equals("n/a"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        Carro carro16 = new Carro();
        carro16.setMatricula("");
        Carro carro19 = carro16.clone();
        carro16.setPrecoBase((double) 0L);
        Carro carro22 = new Carro();
        int i23 = carro22.getLugares();
        int i24 = carro16.compareTo((Veiculo) carro22);
        java.lang.String str25 = carro22.toString();
        Coordenada coordenada26 = carro22.getCoordenadas();
        Carro carro28 = new Carro((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada26, false);
        Carro carro30 = new Carro((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada26, true);
        Carro carro32 = new Carro((int) '#', 10.0d, (-1), "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada26, true);
        Coordenada coordenada33 = carro32.getCoordenadas();
        Carro carro35 = new Carro((int) '4', (double) (byte) 1, 0, "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada33, true);
        java.lang.String str36 = carro35.toString();
        org.junit.Assert.assertNotNull(carro19);
        org.junit.Assert.assertTrue(i23 == 0);
        org.junit.Assert.assertTrue(i24 == 3);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str25.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada26);
        org.junit.Assert.assertNotNull(coordenada33);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Matrícula: Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 52km/h\nPreço Base: 1.0€\nFiabilidade: 0\nLugares: 4\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n" + "'", str36.equals("Matrícula: Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 52km/h\nPreço Base: 1.0€\nFiabilidade: 0\nLugares: 4\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        Carro carro4 = new Carro();
        carro4.setMatricula("");
        Carro carro7 = carro4.clone();
        Coordenada coordenada8 = carro7.getCoordenadas();
        Carro carro10 = new Carro((int) (byte) -1, (double) 0, (int) (short) 1, "", coordenada8, false);
        double d11 = carro10.getPrecoBase();
        java.lang.String str12 = carro10.toString();
        Carro carro13 = new Carro();
        int i14 = carro13.getLugares();
        carro13.setVelocidadeMedia(10);
        carro13.setMatricula("n/a");
        Carro carro19 = new Carro();
        carro19.setMatricula("");
        Carro carro22 = carro19.clone();
        carro19.setPrecoBase((double) 0L);
        Carro carro25 = new Carro();
        int i26 = carro25.getLugares();
        int i27 = carro19.compareTo((Veiculo) carro25);
        java.lang.String str28 = carro25.toString();
        Coordenada coordenada29 = carro25.getCoordenadas();
        Carro carro30 = new Carro();
        int i31 = carro30.getLugares();
        Coordenada coordenada32 = carro30.getCoordenadas();
        carro25.setCoordenadas(coordenada32);
        carro13.setCoordenadas(coordenada32);
        Carro carro35 = new Carro();
        carro35.setMatricula("");
        boolean b39 = carro35.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada40 = carro35.getCoordenadas();
        carro13.setCoordenadas(coordenada40);
        Coordenada coordenada42 = carro13.getCoordenadas();
        Coordenada coordenada43 = carro13.getCoordenadas();
        boolean b44 = carro10.equals((java.lang.Object) carro13);
        org.junit.Assert.assertNotNull(carro7);
        org.junit.Assert.assertNotNull(coordenada8);
        org.junit.Assert.assertTrue(d11 == 0.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Matrícula: \nVelocidade Média/km: -1km/h\nPreço Base: 0.0€\nFiabilidade: 1\nLugares: 4\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str12.equals("Matrícula: \nVelocidade Média/km: -1km/h\nPreço Base: 0.0€\nFiabilidade: 1\nLugares: 4\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertNotNull(carro22);
        org.junit.Assert.assertTrue(i26 == 0);
        org.junit.Assert.assertTrue(i27 == 3);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str28.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada29);
        org.junit.Assert.assertTrue(i31 == 0);
        org.junit.Assert.assertNotNull(coordenada32);
        org.junit.Assert.assertTrue(b39 == false);
        org.junit.Assert.assertNotNull(coordenada40);
        org.junit.Assert.assertNotNull(coordenada42);
        org.junit.Assert.assertNotNull(coordenada43);
        org.junit.Assert.assertTrue(b44 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Carro carro5 = new Carro(carro0);
        double d6 = carro0.getPrecoBase();
        carro0.setFiabilidade((int) (short) 0);
        carro0.setOcupado(false);
        int i11 = carro0.getFiabilidade();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(i11 == 0);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        carro0.setMatricula("n/a");
        Carro carro6 = new Carro();
        carro6.setMatricula("");
        Carro carro9 = carro6.clone();
        carro6.setPrecoBase((double) 0L);
        Carro carro12 = new Carro();
        int i13 = carro12.getLugares();
        int i14 = carro6.compareTo((Veiculo) carro12);
        java.lang.String str15 = carro12.toString();
        Coordenada coordenada16 = carro12.getCoordenadas();
        Carro carro17 = new Carro();
        int i18 = carro17.getLugares();
        Coordenada coordenada19 = carro17.getCoordenadas();
        carro12.setCoordenadas(coordenada19);
        carro0.setCoordenadas(coordenada19);
        Carro carro22 = new Carro();
        carro22.setMatricula("");
        boolean b26 = carro22.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada27 = carro22.getCoordenadas();
        carro0.setCoordenadas(coordenada27);
        java.lang.String str29 = carro0.getMatricula();
        java.lang.String str30 = carro0.getMatricula();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(carro9);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(i14 == 3);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str15.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada16);
        org.junit.Assert.assertTrue(i18 == 0);
        org.junit.Assert.assertNotNull(coordenada19);
        org.junit.Assert.assertTrue(b26 == false);
        org.junit.Assert.assertNotNull(coordenada27);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "n/a" + "'", str29.equals("n/a"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "n/a" + "'", str30.equals("n/a"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        java.lang.String str9 = carro6.toString();
        Coordenada coordenada10 = carro6.getCoordenadas();
        carro6.setFiabilidade((int) (byte) 1);
        Carro carro13 = new Carro();
        int i14 = carro13.getLugares();
        carro13.setVelocidadeMedia(10);
        Carro carro17 = carro13.clone();
        boolean b18 = carro6.equals((java.lang.Object) carro13);
        Carro carro19 = new Carro(carro6);
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertNotNull(carro17);
        org.junit.Assert.assertTrue(b18 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        carro0.setMatricula("n/a");
        carro0.setPrecoBase((double) 1L);
        Coordenada coordenada8 = carro0.getCoordenadas();
        Carro carro9 = new Carro();
        Carro carro10 = new Carro(carro9);
        java.lang.String str11 = carro9.toString();
        carro9.setFiabilidade(0);
        Carro carro14 = carro9.clone();
        Carro carro15 = new Carro(carro9);
        Coordenada coordenada16 = carro9.getCoordenadas();
        carro0.setCoordenadas(coordenada16);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(coordenada8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str11.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro14);
        org.junit.Assert.assertNotNull(coordenada16);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro(carro0);
        carro6.setPrecoBase((double) (-1.0f));
        carro6.setVelocidadeMedia((int) (short) 0);
        carro6.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Carro carro13 = new Carro(carro6);
        int i14 = carro13.getLugares();
        Coordenada coordenada15 = carro13.getCoordenadas();
        carro13.setVelocidadeMedia((int) (byte) 10);
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertNotNull(coordenada15);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        Carro carro4 = new Carro();
        int i5 = carro4.getLugares();
        Coordenada coordenada6 = carro4.getCoordenadas();
        Carro carro8 = new Carro((int) (short) -1, (double) (byte) -1, (int) '4', "", coordenada6, true);
        int i9 = carro8.getFiabilidade();
        carro8.setFiabilidade((-145));
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertNotNull(coordenada6);
        org.junit.Assert.assertTrue(i9 == 52);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        Carro carro4 = new Carro();
        carro4.setMatricula("");
        Carro carro7 = carro4.clone();
        carro4.setPrecoBase((double) 0L);
        Carro carro10 = new Carro();
        int i11 = carro10.getLugares();
        int i12 = carro4.compareTo((Veiculo) carro10);
        java.lang.String str13 = carro10.toString();
        Coordenada coordenada14 = carro10.getCoordenadas();
        Carro carro16 = new Carro((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada14, false);
        carro16.setPrecoBase((double) 10.0f);
        carro16.setMatricula("hi!");
        java.lang.String str21 = carro16.toString();
        carro16.setPrecoBase((double) (short) 1);
        java.lang.Object obj24 = null;
        boolean b25 = carro16.equals(obj24);
        org.junit.Assert.assertNotNull(carro7);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(i12 == 3);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str13.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada14);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Matrícula: hi!\nVelocidade Média/km: 100km/h\nPreço Base: 10.0€\nFiabilidade: 10\nLugares: 4\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str21.equals("Matrícula: hi!\nVelocidade Média/km: 100km/h\nPreço Base: 10.0€\nFiabilidade: 10\nLugares: 4\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(b25 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        int i9 = carro6.getFiabilidade();
        Carro carro10 = carro6.clone();
        carro6.setFiabilidade((int) (short) 1);
        Carro carro13 = new Carro(carro6);
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertNotNull(carro10);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        java.lang.String str2 = carro0.toString();
        carro0.setFiabilidade(0);
        Carro carro5 = carro0.clone();
        Carro carro6 = new Carro();
        Carro carro7 = new Carro(carro6);
        Carro carro8 = new Carro(carro7);
        Carro carro9 = new Carro();
        Carro carro10 = new Carro(carro9);
        int i11 = carro7.compareTo((Veiculo) carro9);
        Carro carro12 = new Carro();
        carro12.setMatricula("");
        boolean b16 = carro12.equals((java.lang.Object) (-1.0d));
        boolean b17 = carro7.equals((java.lang.Object) (-1.0d));
        Carro carro18 = new Carro();
        carro18.setMatricula("");
        Carro carro21 = carro18.clone();
        carro18.setPrecoBase((double) 0L);
        Carro carro24 = new Carro();
        int i25 = carro24.getLugares();
        int i26 = carro18.compareTo((Veiculo) carro24);
        java.lang.String str27 = carro24.toString();
        Coordenada coordenada28 = carro24.getCoordenadas();
        carro7.setCoordenadas(coordenada28);
        carro0.setCoordenadas(coordenada28);
        carro0.setPrecoBase(100.0d);
        carro0.setMatricula("Matrícula: Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: -1.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        int i35 = carro0.getVelocidadeMedia();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro5);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(b16 == false);
        org.junit.Assert.assertTrue(b17 == false);
        org.junit.Assert.assertNotNull(carro21);
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue(i26 == 3);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str27.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada28);
        org.junit.Assert.assertTrue(i35 == 0);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        Carro carro9 = new Carro(carro6);
        int i10 = carro9.getLugares();
        carro9.setPrecoBase(100.0d);
        Carro carro17 = new Carro();
        carro17.setMatricula("");
        java.lang.String str20 = carro17.toString();
        Carro carro21 = new Carro();
        Carro carro22 = new Carro(carro21);
        java.lang.String str23 = carro21.toString();
        carro21.setFiabilidade(0);
        Carro carro26 = carro21.clone();
        Carro carro27 = new Carro();
        Carro carro28 = new Carro(carro27);
        Carro carro29 = new Carro(carro28);
        Carro carro30 = new Carro();
        Carro carro31 = new Carro(carro30);
        int i32 = carro28.compareTo((Veiculo) carro30);
        Carro carro33 = new Carro();
        carro33.setMatricula("");
        boolean b37 = carro33.equals((java.lang.Object) (-1.0d));
        boolean b38 = carro28.equals((java.lang.Object) (-1.0d));
        Carro carro39 = new Carro();
        carro39.setMatricula("");
        Carro carro42 = carro39.clone();
        carro39.setPrecoBase((double) 0L);
        Carro carro45 = new Carro();
        int i46 = carro45.getLugares();
        int i47 = carro39.compareTo((Veiculo) carro45);
        java.lang.String str48 = carro45.toString();
        Coordenada coordenada49 = carro45.getCoordenadas();
        carro28.setCoordenadas(coordenada49);
        carro21.setCoordenadas(coordenada49);
        carro17.setCoordenadas(coordenada49);
        Carro carro54 = new Carro((int) 'a', (double) (short) 100, (int) '#', "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n", coordenada49, false);
        carro9.setCoordenadas(coordenada49);
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str20.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str23.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro26);
        org.junit.Assert.assertTrue(i32 == 0);
        org.junit.Assert.assertTrue(b37 == false);
        org.junit.Assert.assertTrue(b38 == false);
        org.junit.Assert.assertNotNull(carro42);
        org.junit.Assert.assertTrue(i46 == 0);
        org.junit.Assert.assertTrue(i47 == 3);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str48.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada49);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        Carro carro4 = new Carro(carro0);
        Carro carro5 = new Carro(carro4);
        carro4.setFiabilidade((int) '4');
        carro4.setVelocidadeMedia((int) (byte) 1);
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        Carro carro9 = new Carro(carro6);
        Carro carro10 = new Carro();
        Carro carro11 = new Carro(carro10);
        Carro carro12 = new Carro(carro11);
        Carro carro13 = new Carro();
        Carro carro14 = new Carro(carro13);
        int i15 = carro11.compareTo((Veiculo) carro13);
        int i16 = carro13.getVelocidadeMedia();
        int i17 = carro9.compareTo((Veiculo) carro13);
        int i18 = carro13.getVelocidadeMedia();
        int i19 = carro13.getVelocidadeMedia();
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue(i15 == 0);
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue(i17 == 0);
        org.junit.Assert.assertTrue(i18 == 0);
        org.junit.Assert.assertTrue(i19 == 0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        Carro carro4 = carro0.clone();
        boolean b5 = carro0.getOcupado();
        Carro carro6 = new Carro();
        carro6.setMatricula("");
        boolean b10 = carro6.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada11 = carro6.getCoordenadas();
        boolean b12 = carro0.equals((java.lang.Object) carro6);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(carro4);
        org.junit.Assert.assertTrue(b5 == false);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertNotNull(coordenada11);
        org.junit.Assert.assertTrue(b12 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        Carro carro4 = new Carro(carro0);
        java.lang.String str5 = carro0.toString();
        int i6 = carro0.getLugares();
        java.lang.String str7 = carro0.getMatricula();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str5.equals("Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "n/a" + "'", str7.equals("n/a"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        java.lang.String str2 = carro0.toString();
        carro0.setFiabilidade(0);
        Carro carro5 = carro0.clone();
        Carro carro6 = new Carro(carro0);
        Coordenada coordenada7 = carro0.getCoordenadas();
        double d8 = carro0.getPrecoBase();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro5);
        org.junit.Assert.assertNotNull(coordenada7);
        org.junit.Assert.assertTrue(d8 == 0.0d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = carro0.clone();
        double d3 = carro2.getPrecoBase();
        org.junit.Assert.assertNotNull(carro2);
        org.junit.Assert.assertTrue(d3 == 0.0d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        Carro carro12 = new Carro();
        carro12.setMatricula("");
        boolean b16 = carro12.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada17 = carro12.getCoordenadas();
        boolean b18 = carro12.getOcupado();
        java.lang.String str19 = carro12.getMatricula();
        Carro carro24 = new Carro();
        carro24.setMatricula("");
        Carro carro27 = carro24.clone();
        carro24.setPrecoBase((double) 0L);
        Carro carro30 = new Carro();
        int i31 = carro30.getLugares();
        int i32 = carro24.compareTo((Veiculo) carro30);
        java.lang.String str33 = carro30.toString();
        Coordenada coordenada34 = carro30.getCoordenadas();
        Carro carro36 = new Carro((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada34, false);
        carro12.setCoordenadas(coordenada34);
        Carro carro39 = new Carro(32, (double) (short) 1, (int) (byte) 1, "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada34, true);
        Carro carro41 = new Carro(4, (-1.0d), (int) ' ', "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 10.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada34, true);
        Carro carro43 = new Carro((int) (byte) 100, (double) (-3), (int) 'a', "Matrícula: Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 97.0€\nFiabilidade: 1\nLugares: 4\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada34, false);
        org.junit.Assert.assertTrue(b16 == false);
        org.junit.Assert.assertNotNull(coordenada17);
        org.junit.Assert.assertTrue(b18 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNotNull(carro27);
        org.junit.Assert.assertTrue(i31 == 0);
        org.junit.Assert.assertTrue(i32 == 3);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str33.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada34);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro3.setOcupado(true);
        int i6 = carro3.getFiabilidade();
        int i7 = carro3.getFiabilidade();
        Carro carro16 = new Carro();
        carro16.setMatricula("");
        Carro carro19 = carro16.clone();
        carro16.setPrecoBase((double) 0L);
        Carro carro22 = new Carro();
        int i23 = carro22.getLugares();
        int i24 = carro16.compareTo((Veiculo) carro22);
        java.lang.String str25 = carro22.toString();
        Coordenada coordenada26 = carro22.getCoordenadas();
        Carro carro28 = new Carro((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada26, false);
        Carro carro30 = new Carro((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada26, true);
        carro3.setCoordenadas(coordenada26);
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertNotNull(carro19);
        org.junit.Assert.assertTrue(i23 == 0);
        org.junit.Assert.assertTrue(i24 == 3);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str25.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada26);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        int i4 = carro3.getVelocidadeMedia();
        java.lang.Object obj5 = null;
        boolean b6 = carro3.equals(obj5);
        Carro carro11 = new Carro();
        carro11.setMatricula("");
        java.lang.String str14 = carro11.toString();
        Carro carro15 = new Carro();
        Carro carro16 = new Carro(carro15);
        java.lang.String str17 = carro15.toString();
        carro15.setFiabilidade(0);
        Carro carro20 = carro15.clone();
        Carro carro21 = new Carro();
        Carro carro22 = new Carro(carro21);
        Carro carro23 = new Carro(carro22);
        Carro carro24 = new Carro();
        Carro carro25 = new Carro(carro24);
        int i26 = carro22.compareTo((Veiculo) carro24);
        Carro carro27 = new Carro();
        carro27.setMatricula("");
        boolean b31 = carro27.equals((java.lang.Object) (-1.0d));
        boolean b32 = carro22.equals((java.lang.Object) (-1.0d));
        Carro carro33 = new Carro();
        carro33.setMatricula("");
        Carro carro36 = carro33.clone();
        carro33.setPrecoBase((double) 0L);
        Carro carro39 = new Carro();
        int i40 = carro39.getLugares();
        int i41 = carro33.compareTo((Veiculo) carro39);
        java.lang.String str42 = carro39.toString();
        Coordenada coordenada43 = carro39.getCoordenadas();
        carro22.setCoordenadas(coordenada43);
        carro15.setCoordenadas(coordenada43);
        carro11.setCoordenadas(coordenada43);
        Carro carro48 = new Carro((int) '4', (double) 1.0f, 4, "hi!", coordenada43, false);
        carro3.setCoordenadas(coordenada43);
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue(b6 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str14.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str17.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro20);
        org.junit.Assert.assertTrue(i26 == 0);
        org.junit.Assert.assertTrue(b31 == false);
        org.junit.Assert.assertTrue(b32 == false);
        org.junit.Assert.assertNotNull(carro36);
        org.junit.Assert.assertTrue(i40 == 0);
        org.junit.Assert.assertTrue(i41 == 3);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str42.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada43);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        java.lang.String str3 = carro0.toString();
        java.lang.Object obj4 = null;
        boolean b5 = carro0.equals(obj4);
        Carro carro6 = new Carro();
        carro6.setMatricula("");
        Carro carro9 = carro6.clone();
        int i10 = carro9.getFiabilidade();
        java.lang.String str11 = carro9.toString();
        boolean b12 = carro0.equals((java.lang.Object) carro9);
        carro9.setMatricula("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carro9.setPrecoBase((double) 1.0f);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(b5 == false);
        org.junit.Assert.assertNotNull(carro9);
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str11.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(b12 == true);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        Carro carro4 = new Carro(carro0);
        Carro carro5 = new Carro(carro4);
        Coordenada coordenada6 = carro4.getCoordenadas();
        Carro carro7 = new Carro(carro4);
        double d8 = carro7.getPrecoBase();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(coordenada6);
        org.junit.Assert.assertTrue(d8 == 0.0d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        java.lang.String str2 = carro0.toString();
        carro0.setFiabilidade(0);
        Carro carro5 = carro0.clone();
        Carro carro6 = new Carro();
        Carro carro7 = new Carro(carro6);
        Carro carro8 = new Carro(carro7);
        Carro carro9 = new Carro();
        Carro carro10 = new Carro(carro9);
        int i11 = carro7.compareTo((Veiculo) carro9);
        Carro carro12 = new Carro();
        carro12.setMatricula("");
        boolean b16 = carro12.equals((java.lang.Object) (-1.0d));
        boolean b17 = carro7.equals((java.lang.Object) (-1.0d));
        Carro carro18 = new Carro();
        carro18.setMatricula("");
        Carro carro21 = carro18.clone();
        carro18.setPrecoBase((double) 0L);
        Carro carro24 = new Carro();
        int i25 = carro24.getLugares();
        int i26 = carro18.compareTo((Veiculo) carro24);
        java.lang.String str27 = carro24.toString();
        Coordenada coordenada28 = carro24.getCoordenadas();
        carro7.setCoordenadas(coordenada28);
        carro0.setCoordenadas(coordenada28);
        carro0.setPrecoBase(100.0d);
        java.lang.String str33 = carro0.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro5);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(b16 == false);
        org.junit.Assert.assertTrue(b17 == false);
        org.junit.Assert.assertNotNull(carro21);
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue(i26 == 3);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str27.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada28);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 100.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str33.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 100.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        java.lang.String str4 = carro0.toString();
        int i5 = carro0.getVelocidadeMedia();
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str4.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i5 == 0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro(carro0);
        carro6.setPrecoBase((double) (-1.0f));
        double d9 = carro6.getPrecoBase();
        Carro carro10 = new Carro();
        Carro carro11 = new Carro(carro10);
        Carro carro12 = new Carro(carro11);
        Carro carro13 = new Carro();
        Carro carro14 = new Carro(carro13);
        int i15 = carro11.compareTo((Veiculo) carro13);
        int i16 = carro13.getVelocidadeMedia();
        Carro carro17 = carro13.clone();
        int i18 = carro17.getFiabilidade();
        int i19 = carro17.getFiabilidade();
        Carro carro20 = new Carro(carro17);
        Coordenada coordenada21 = carro17.getCoordenadas();
        carro6.setCoordenadas(coordenada21);
        int i23 = carro6.getFiabilidade();
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(d9 == (-1.0d));
        org.junit.Assert.assertTrue(i15 == 0);
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertNotNull(carro17);
        org.junit.Assert.assertTrue(i18 == 0);
        org.junit.Assert.assertTrue(i19 == 0);
        org.junit.Assert.assertNotNull(coordenada21);
        org.junit.Assert.assertTrue(i23 == 0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        java.lang.String str6 = carro0.getMatricula();
        Coordenada coordenada7 = carro0.getCoordenadas();
        Carro carro12 = new Carro();
        carro12.setMatricula("");
        boolean b16 = carro12.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada17 = carro12.getCoordenadas();
        carro12.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carro12.setFiabilidade(0);
        Carro carro22 = new Carro();
        carro22.setMatricula("");
        Carro carro25 = carro22.clone();
        carro22.setPrecoBase((double) 0L);
        Carro carro28 = new Carro(carro22);
        int i29 = carro12.compareTo((Veiculo) carro22);
        Carro carro30 = new Carro(carro22);
        Coordenada coordenada31 = carro30.getCoordenadas();
        Carro carro33 = new Carro((int) (byte) 0, (double) 0L, (int) (byte) 0, "n/a", coordenada31, true);
        Coordenada coordenada34 = carro33.getCoordenadas();
        carro0.setCoordenadas(coordenada34);
        int i36 = carro0.getLugares();
        int i37 = carro0.getLugares();
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(coordenada7);
        org.junit.Assert.assertTrue(b16 == false);
        org.junit.Assert.assertNotNull(coordenada17);
        org.junit.Assert.assertNotNull(carro25);
        org.junit.Assert.assertTrue(i29 == (-142));
        org.junit.Assert.assertNotNull(coordenada31);
        org.junit.Assert.assertNotNull(coordenada34);
        org.junit.Assert.assertTrue(i36 == 0);
        org.junit.Assert.assertTrue(i37 == 0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        int i4 = carro3.getLugares();
        boolean b5 = carro2.equals((java.lang.Object) carro3);
        carro3.setPrecoBase(0.0d);
        Carro carro8 = carro3.clone();
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue(b5 == true);
        org.junit.Assert.assertNotNull(carro8);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        carro0.setVelocidadeMedia((int) (short) -1);
        java.lang.String str7 = carro0.getMatricula();
        carro0.setMatricula("Matrícula: Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: -1.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Carro carro10 = new Carro();
        int i11 = carro10.getLugares();
        carro10.setVelocidadeMedia(10);
        Carro carro14 = new Carro(carro10);
        int i15 = carro10.getVelocidadeMedia();
        carro10.setMatricula("");
        int i18 = carro10.getFiabilidade();
        int i19 = carro10.getVelocidadeMedia();
        carro10.setVelocidadeMedia((-142));
        boolean b22 = carro0.equals((java.lang.Object) carro10);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(i15 == 10);
        org.junit.Assert.assertTrue(i18 == 0);
        org.junit.Assert.assertTrue(i19 == 10);
        org.junit.Assert.assertTrue(b22 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro();
        Carro carro2 = new Carro(carro1);
        int i3 = carro2.getFiabilidade();
        Coordenada coordenada4 = carro2.getCoordenadas();
        carro0.setCoordenadas(coordenada4);
        carro0.setVelocidadeMedia((int) (short) -1);
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertNotNull(coordenada4);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        carro0.setMatricula("n/a");
        carro0.setPrecoBase((double) 1L);
        Carro carro8 = new Carro();
        Carro carro9 = new Carro(carro8);
        Carro carro10 = new Carro(carro9);
        Carro carro11 = new Carro();
        int i12 = carro11.getLugares();
        boolean b13 = carro10.equals((java.lang.Object) carro11);
        Carro carro14 = carro11.clone();
        Coordenada coordenada15 = carro11.getCoordenadas();
        carro0.setCoordenadas(coordenada15);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertTrue(b13 == true);
        org.junit.Assert.assertNotNull(carro14);
        org.junit.Assert.assertNotNull(coordenada15);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        java.lang.String str3 = carro0.toString();
        int i4 = carro0.getFiabilidade();
        carro0.setMatricula("Matrícula: Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 97.0€\nFiabilidade: 3\nLugares: 4\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i4 == 0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        Carro carro4 = new Carro(carro3);
        int i5 = carro1.compareTo((Veiculo) carro3);
        carro3.setPrecoBase((double) 3);
        java.lang.String str8 = carro3.getMatricula();
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "n/a" + "'", str8.equals("n/a"));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        Carro carro8 = new Carro();
        carro8.setMatricula("");
        boolean b12 = carro8.equals((java.lang.Object) (-1.0d));
        Carro carro13 = new Carro(carro8);
        int i14 = carro13.getVelocidadeMedia();
        Carro carro15 = new Carro();
        Carro carro16 = new Carro(carro15);
        Carro carro17 = new Carro(carro16);
        Carro carro18 = new Carro();
        Carro carro19 = new Carro(carro18);
        int i20 = carro16.compareTo((Veiculo) carro18);
        Carro carro21 = new Carro();
        carro21.setMatricula("");
        boolean b25 = carro21.equals((java.lang.Object) (-1.0d));
        boolean b26 = carro16.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada27 = carro16.getCoordenadas();
        carro13.setCoordenadas(coordenada27);
        Carro carro30 = new Carro(4, (double) 0.0f, 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada27, false);
        Carro carro32 = new Carro((int) (byte) 1, (double) (-142), 4, "Matrícula: hi!\nVelocidade Média/km: 100km/h\nPreço Base: 10.0€\nFiabilidade: 10\nLugares: 4\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada27, false);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(i20 == 0);
        org.junit.Assert.assertTrue(b25 == false);
        org.junit.Assert.assertTrue(b26 == false);
        org.junit.Assert.assertNotNull(coordenada27);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Carro carro5 = new Carro(carro0);
        double d6 = carro0.getPrecoBase();
        boolean b7 = carro0.getOcupado();
        int i8 = carro0.getVelocidadeMedia();
        Carro carro9 = carro0.clone();
        carro9.setFiabilidade((int) (byte) 10);
        carro9.setFiabilidade((int) (short) -1);
        carro9.setMatricula("hi!");
        int i16 = carro9.getFiabilidade();
        java.lang.String str17 = carro9.toString();
        Coordenada coordenada18 = carro9.getCoordenadas();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(b7 == false);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertNotNull(carro9);
        org.junit.Assert.assertTrue(i16 == (-1));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Matrícula: hi!\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: -1\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str17.equals("Matrícula: hi!\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: -1\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada18);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carro0.getCoordenadas();
        carro0.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carro0.setFiabilidade(0);
        Carro carro10 = new Carro();
        carro10.setMatricula("");
        boolean b14 = carro10.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada15 = carro10.getCoordenadas();
        int i16 = carro10.getVelocidadeMedia();
        boolean b17 = carro0.equals((java.lang.Object) carro10);
        Carro carro18 = new Carro();
        Carro carro19 = new Carro(carro18);
        Carro carro20 = new Carro(carro19);
        Carro carro21 = new Carro();
        Carro carro22 = new Carro(carro21);
        int i23 = carro19.compareTo((Veiculo) carro21);
        Carro carro24 = new Carro();
        carro24.setMatricula("");
        boolean b28 = carro24.equals((java.lang.Object) (-1.0d));
        boolean b29 = carro19.equals((java.lang.Object) (-1.0d));
        Carro carro30 = new Carro();
        carro30.setMatricula("");
        Carro carro33 = carro30.clone();
        carro30.setPrecoBase((double) 0L);
        Carro carro36 = new Carro();
        int i37 = carro36.getLugares();
        int i38 = carro30.compareTo((Veiculo) carro36);
        java.lang.String str39 = carro36.toString();
        Coordenada coordenada40 = carro36.getCoordenadas();
        carro19.setCoordenadas(coordenada40);
        carro19.setVelocidadeMedia((-145));
        boolean b44 = carro0.equals((java.lang.Object) carro19);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertNotNull(coordenada15);
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue(b17 == false);
        org.junit.Assert.assertTrue(i23 == 0);
        org.junit.Assert.assertTrue(b28 == false);
        org.junit.Assert.assertTrue(b29 == false);
        org.junit.Assert.assertNotNull(carro33);
        org.junit.Assert.assertTrue(i37 == 0);
        org.junit.Assert.assertTrue(i38 == 3);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str39.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada40);
        org.junit.Assert.assertTrue(b44 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        Carro carro4 = new Carro(carro0);
        Carro carro5 = new Carro(carro4);
        int i6 = carro5.getFiabilidade();
        Carro carro7 = carro5.clone();
        carro7.setOcupado(false);
        Coordenada coordenada10 = carro7.getCoordenadas();
        Carro carro11 = carro7.clone();
        java.lang.String str12 = carro7.toString();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertNotNull(carro7);
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertNotNull(carro11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str12.equals("Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        int i9 = carro6.getFiabilidade();
        Carro carro10 = carro6.clone();
        Coordenada coordenada11 = carro10.getCoordenadas();
        int i12 = carro10.getLugares();
        int i13 = carro10.getVelocidadeMedia();
        boolean b14 = carro10.getOcupado();
        java.lang.String str15 = carro10.toString();
        Carro carro16 = new Carro();
        Carro carro17 = new Carro(carro16);
        Carro carro18 = new Carro(carro17);
        Carro carro19 = new Carro();
        Carro carro20 = new Carro(carro19);
        int i21 = carro17.compareTo((Veiculo) carro19);
        Carro carro22 = new Carro();
        carro22.setMatricula("");
        boolean b26 = carro22.equals((java.lang.Object) (-1.0d));
        boolean b27 = carro17.equals((java.lang.Object) (-1.0d));
        Carro carro28 = new Carro(carro17);
        int i29 = carro10.compareTo((Veiculo) carro17);
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertNotNull(carro10);
        org.junit.Assert.assertNotNull(coordenada11);
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str15.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i21 == 0);
        org.junit.Assert.assertTrue(b26 == false);
        org.junit.Assert.assertTrue(b27 == false);
        org.junit.Assert.assertTrue(i29 == 0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        int i2 = carro0.getLugares();
        Carro carro3 = carro0.clone();
        Carro carro4 = carro0.clone();
        java.lang.String str5 = carro0.getMatricula();
        org.junit.Assert.assertTrue(i2 == 0);
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertNotNull(carro4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "n/a" + "'", str5.equals("n/a"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        carro0.setMatricula("n/a");
        Carro carro6 = new Carro();
        carro6.setMatricula("");
        Carro carro9 = carro6.clone();
        carro6.setPrecoBase((double) 0L);
        Carro carro12 = new Carro();
        int i13 = carro12.getLugares();
        int i14 = carro6.compareTo((Veiculo) carro12);
        java.lang.String str15 = carro12.toString();
        Coordenada coordenada16 = carro12.getCoordenadas();
        Carro carro17 = new Carro();
        int i18 = carro17.getLugares();
        Coordenada coordenada19 = carro17.getCoordenadas();
        carro12.setCoordenadas(coordenada19);
        carro0.setCoordenadas(coordenada19);
        Carro carro26 = new Carro();
        carro26.setMatricula("");
        boolean b30 = carro26.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada31 = carro26.getCoordenadas();
        boolean b32 = carro26.getOcupado();
        java.lang.String str33 = carro26.getMatricula();
        Carro carro38 = new Carro();
        carro38.setMatricula("");
        Carro carro41 = carro38.clone();
        carro38.setPrecoBase((double) 0L);
        Carro carro44 = new Carro();
        int i45 = carro44.getLugares();
        int i46 = carro38.compareTo((Veiculo) carro44);
        java.lang.String str47 = carro44.toString();
        Coordenada coordenada48 = carro44.getCoordenadas();
        Carro carro50 = new Carro((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada48, false);
        carro26.setCoordenadas(coordenada48);
        Carro carro53 = new Carro(32, (double) (short) 1, (int) (byte) 1, "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada48, true);
        boolean b54 = carro0.equals((java.lang.Object) carro53);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(carro9);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(i14 == 3);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str15.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada16);
        org.junit.Assert.assertTrue(i18 == 0);
        org.junit.Assert.assertNotNull(coordenada19);
        org.junit.Assert.assertTrue(b30 == false);
        org.junit.Assert.assertNotNull(coordenada31);
        org.junit.Assert.assertTrue(b32 == false);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
        org.junit.Assert.assertNotNull(carro41);
        org.junit.Assert.assertTrue(i45 == 0);
        org.junit.Assert.assertTrue(i46 == 3);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str47.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada48);
        org.junit.Assert.assertTrue(b54 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        int i2 = carro1.getFiabilidade();
        int i3 = carro1.getVelocidadeMedia();
        carro1.setVelocidadeMedia(3);
        org.junit.Assert.assertTrue(i2 == 0);
        org.junit.Assert.assertTrue(i3 == 0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        carro0.setMatricula("n/a");
        Carro carro6 = new Carro();
        carro6.setMatricula("");
        Carro carro9 = carro6.clone();
        carro6.setPrecoBase((double) 0L);
        Carro carro12 = new Carro();
        int i13 = carro12.getLugares();
        int i14 = carro6.compareTo((Veiculo) carro12);
        java.lang.String str15 = carro12.toString();
        Coordenada coordenada16 = carro12.getCoordenadas();
        Carro carro17 = new Carro();
        int i18 = carro17.getLugares();
        Coordenada coordenada19 = carro17.getCoordenadas();
        carro12.setCoordenadas(coordenada19);
        carro0.setCoordenadas(coordenada19);
        Carro carro22 = new Carro();
        carro22.setMatricula("");
        boolean b26 = carro22.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada27 = carro22.getCoordenadas();
        carro0.setCoordenadas(coordenada27);
        Carro carro29 = new Carro();
        carro29.setMatricula("");
        boolean b33 = carro29.equals((java.lang.Object) (-1.0d));
        Carro carro34 = new Carro(carro29);
        double d35 = carro29.getPrecoBase();
        boolean b36 = carro0.equals((java.lang.Object) carro29);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(carro9);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(i14 == 3);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str15.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada16);
        org.junit.Assert.assertTrue(i18 == 0);
        org.junit.Assert.assertNotNull(coordenada19);
        org.junit.Assert.assertTrue(b26 == false);
        org.junit.Assert.assertNotNull(coordenada27);
        org.junit.Assert.assertTrue(b33 == false);
        org.junit.Assert.assertTrue(d35 == 0.0d);
        org.junit.Assert.assertTrue(b36 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        Carro carro2 = carro0.clone();
        Carro carro3 = new Carro(carro2);
        Carro carro4 = new Carro();
        int i5 = carro4.getLugares();
        java.lang.String str6 = carro4.getMatricula();
        Carro carro7 = new Carro(carro4);
        int i8 = carro7.getFiabilidade();
        Coordenada coordenada9 = carro7.getCoordenadas();
        carro2.setCoordenadas(coordenada9);
        int i11 = carro2.getLugares();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(carro2);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "n/a" + "'", str6.equals("n/a"));
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertNotNull(coordenada9);
        org.junit.Assert.assertTrue(i11 == 0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        Carro carro4 = new Carro(carro3);
        int i5 = carro1.compareTo((Veiculo) carro3);
        int i6 = carro3.getVelocidadeMedia();
        Carro carro7 = carro3.clone();
        int i8 = carro7.getFiabilidade();
        int i9 = carro7.getFiabilidade();
        Carro carro10 = new Carro(carro7);
        boolean b11 = carro7.getOcupado();
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertNotNull(carro7);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertTrue(b11 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Carro carro5 = new Carro(carro0);
        int i6 = carro5.getFiabilidade();
        int i7 = carro5.getLugares();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertTrue(i7 == 0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        Carro carro2 = carro0.clone();
        Carro carro3 = new Carro();
        Carro carro4 = new Carro(carro3);
        java.lang.String str5 = carro3.toString();
        carro3.setFiabilidade(0);
        int i8 = carro3.getFiabilidade();
        carro3.setFiabilidade((int) (byte) 0);
        boolean b11 = carro2.equals((java.lang.Object) carro3);
        carro3.setPrecoBase((double) (-1.0f));
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(carro2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str5.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue(b11 == true);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        Coordenada coordenada4 = null;
        try {
            Carro carro6 = new Carro((int) (byte) -1, (double) 4, 33, "Matrícula: Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 52km/h\nPreço Base: 1.0€\nFiabilidade: 0\nLugares: 4\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n", coordenada4, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        Carro carro4 = new Carro(carro3);
        int i5 = carro1.compareTo((Veiculo) carro3);
        carro3.setMatricula("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carro3.setOcupado(false);
        org.junit.Assert.assertTrue(i5 == 0);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        Carro carro4 = new Carro(carro0);
        int i5 = carro0.getVelocidadeMedia();
        Carro carro6 = carro0.clone();
        int i7 = carro0.getFiabilidade();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i5 == 10);
        org.junit.Assert.assertNotNull(carro6);
        org.junit.Assert.assertTrue(i7 == 0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        java.lang.String str9 = carro6.toString();
        Coordenada coordenada10 = carro6.getCoordenadas();
        Carro carro11 = new Carro();
        int i12 = carro11.getLugares();
        Coordenada coordenada13 = carro11.getCoordenadas();
        carro6.setCoordenadas(coordenada13);
        carro6.setVelocidadeMedia(4);
        int i17 = carro6.getLugares();
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertNotNull(coordenada13);
        org.junit.Assert.assertTrue(i17 == 0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        java.lang.String str2 = carro0.toString();
        carro0.setFiabilidade(0);
        Carro carro5 = carro0.clone();
        int i6 = carro0.getLugares();
        java.lang.Object obj7 = new java.lang.Object();
        boolean b8 = carro0.equals(obj7);
        carro0.setOcupado(false);
        java.lang.String str11 = carro0.getMatricula();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro5);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertTrue(b8 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "n/a" + "'", str11.equals("n/a"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        Carro carro0 = new Carro();
        carro0.setVelocidadeMedia((int) ' ');
        java.lang.String str3 = carro0.toString();
        java.lang.String str4 = carro0.getMatricula();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "n/a" + "'", str4.equals("n/a"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        Carro carro4 = new Carro();
        carro4.setMatricula("");
        Carro carro7 = carro4.clone();
        carro4.setPrecoBase((double) 0L);
        Carro carro10 = new Carro();
        int i11 = carro10.getLugares();
        int i12 = carro4.compareTo((Veiculo) carro10);
        java.lang.String str13 = carro10.toString();
        Coordenada coordenada14 = carro10.getCoordenadas();
        Carro carro16 = new Carro(10, (double) (short) -1, (int) (byte) 1, "", coordenada14, false);
        Carro carro17 = new Carro();
        carro17.setMatricula("");
        java.lang.String str20 = carro17.toString();
        Carro carro21 = carro17.clone();
        int i22 = carro16.compareTo((Veiculo) carro21);
        org.junit.Assert.assertNotNull(carro7);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(i12 == 3);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str13.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str20.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro21);
        org.junit.Assert.assertTrue(i22 == 0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        Carro carro2 = carro0.clone();
        Carro carro3 = new Carro(carro0);
        double d4 = carro0.getPrecoBase();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(carro2);
        org.junit.Assert.assertTrue(d4 == 0.0d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        Carro carro4 = new Carro(carro0);
        Coordenada coordenada5 = carro0.getCoordenadas();
        java.lang.String str6 = carro0.getMatricula();
        carro0.setVelocidadeMedia((int) (byte) 10);
        carro0.setVelocidadeMedia(0);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "n/a" + "'", str6.equals("n/a"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        java.lang.String str2 = carro0.toString();
        carro0.setFiabilidade(0);
        Carro carro5 = carro0.clone();
        Carro carro6 = new Carro(carro0);
        Coordenada coordenada7 = null;
        try {
            carro6.setCoordenadas(coordenada7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro5);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        carro0.setMatricula("n/a");
        carro0.setPrecoBase((double) 1L);
        carro0.setVelocidadeMedia((int) (byte) 1);
        carro0.setMatricula("hi!");
        org.junit.Assert.assertTrue(i1 == 0);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carro0.getCoordenadas();
        carro0.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carro0.setFiabilidade(0);
        Carro carro10 = new Carro();
        carro10.setMatricula("");
        Carro carro13 = carro10.clone();
        carro10.setPrecoBase((double) 0L);
        Carro carro16 = new Carro(carro10);
        int i17 = carro0.compareTo((Veiculo) carro10);
        Carro carro18 = new Carro(carro10);
        int i19 = carro18.getLugares();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertNotNull(carro13);
        org.junit.Assert.assertTrue(i17 == (-142));
        org.junit.Assert.assertTrue(i19 == 0);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        Carro carro4 = new Carro();
        carro4.setMatricula("");
        boolean b8 = carro4.equals((java.lang.Object) (-1.0d));
        Carro carro9 = new Carro(carro4);
        int i10 = carro9.getVelocidadeMedia();
        Carro carro11 = new Carro();
        Carro carro12 = new Carro(carro11);
        Carro carro13 = new Carro(carro12);
        Carro carro14 = new Carro();
        Carro carro15 = new Carro(carro14);
        int i16 = carro12.compareTo((Veiculo) carro14);
        Carro carro17 = new Carro();
        carro17.setMatricula("");
        boolean b21 = carro17.equals((java.lang.Object) (-1.0d));
        boolean b22 = carro12.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada23 = carro12.getCoordenadas();
        carro9.setCoordenadas(coordenada23);
        Carro carro26 = new Carro(4, (double) 0.0f, 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada23, false);
        Carro carro27 = new Carro(carro26);
        org.junit.Assert.assertTrue(b8 == false);
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue(b21 == false);
        org.junit.Assert.assertTrue(b22 == false);
        org.junit.Assert.assertNotNull(coordenada23);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        Carro carro4 = new Carro(carro3);
        int i5 = carro1.compareTo((Veiculo) carro3);
        carro1.setVelocidadeMedia((int) (short) 100);
        java.lang.String str8 = carro1.getMatricula();
        double d9 = carro1.getPrecoBase();
        carro1.setPrecoBase((double) 100);
        carro1.setVelocidadeMedia((int) (short) 1);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "n/a" + "'", str8.equals("n/a"));
        org.junit.Assert.assertTrue(d9 == 0.0d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        Carro carro0 = new Carro();
        carro0.setVelocidadeMedia((int) ' ');
        java.lang.String str3 = carro0.toString();
        int i4 = carro0.getVelocidadeMedia();
        Carro carro5 = carro0.clone();
        carro5.setOcupado(false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i4 == 32);
        org.junit.Assert.assertNotNull(carro5);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        Carro carro4 = new Carro(carro0);
        int i5 = carro0.getVelocidadeMedia();
        carro0.setMatricula("");
        int i8 = carro0.getFiabilidade();
        int i9 = carro0.getVelocidadeMedia();
        carro0.setVelocidadeMedia((-142));
        carro0.setVelocidadeMedia(32);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i5 == 10);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue(i9 == 10);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        java.lang.String str9 = carro6.toString();
        int i10 = carro6.getFiabilidade();
        carro6.setPrecoBase(10.0d);
        int i13 = carro6.getFiabilidade();
        carro6.setFiabilidade(100);
        int i16 = carro6.getLugares();
        Carro carro17 = new Carro();
        carro17.setMatricula("");
        boolean b21 = carro17.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada22 = carro17.getCoordenadas();
        boolean b23 = carro17.getOcupado();
        java.lang.String str24 = carro17.getMatricula();
        Carro carro29 = new Carro();
        carro29.setMatricula("");
        Carro carro32 = carro29.clone();
        carro29.setPrecoBase((double) 0L);
        Carro carro35 = new Carro();
        int i36 = carro35.getLugares();
        int i37 = carro29.compareTo((Veiculo) carro35);
        java.lang.String str38 = carro35.toString();
        Coordenada coordenada39 = carro35.getCoordenadas();
        Carro carro41 = new Carro((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada39, false);
        carro17.setCoordenadas(coordenada39);
        Carro carro43 = new Carro();
        carro43.setMatricula("");
        Carro carro46 = carro43.clone();
        carro43.setPrecoBase((double) 0L);
        Carro carro49 = new Carro();
        int i50 = carro49.getLugares();
        int i51 = carro43.compareTo((Veiculo) carro49);
        int i52 = carro49.getFiabilidade();
        Carro carro53 = carro49.clone();
        Coordenada coordenada54 = carro53.getCoordenadas();
        carro17.setCoordenadas(coordenada54);
        carro6.setCoordenadas(coordenada54);
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertTrue(b21 == false);
        org.junit.Assert.assertNotNull(coordenada22);
        org.junit.Assert.assertTrue(b23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertNotNull(carro32);
        org.junit.Assert.assertTrue(i36 == 0);
        org.junit.Assert.assertTrue(i37 == 3);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str38.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada39);
        org.junit.Assert.assertNotNull(carro46);
        org.junit.Assert.assertTrue(i50 == 0);
        org.junit.Assert.assertTrue(i51 == 3);
        org.junit.Assert.assertTrue(i52 == 0);
        org.junit.Assert.assertNotNull(carro53);
        org.junit.Assert.assertNotNull(coordenada54);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carro0.getCoordenadas();
        carro0.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Carro carro8 = new Carro(carro0);
        java.lang.String str9 = carro8.toString();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        java.lang.String str4 = carro0.toString();
        java.lang.String str5 = carro0.getMatricula();
        java.lang.String str6 = carro0.getMatricula();
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str4.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        Carro carro4 = new Carro(carro3);
        int i5 = carro1.compareTo((Veiculo) carro3);
        carro3.setPrecoBase((double) 3);
        carro3.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        org.junit.Assert.assertTrue(i5 == 0);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carro0.getCoordenadas();
        boolean b6 = carro0.getOcupado();
        java.lang.String str7 = carro0.getMatricula();
        Carro carro8 = carro0.clone();
        java.lang.String str9 = carro0.toString();
        Carro carro10 = new Carro(carro0);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue(b6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(carro8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        java.lang.String str2 = carro0.toString();
        carro0.setFiabilidade(0);
        carro0.setPrecoBase(1.0d);
        int i7 = carro0.getFiabilidade();
        int i8 = carro0.getLugares();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        Carro carro4 = new Carro(carro3);
        int i5 = carro1.compareTo((Veiculo) carro3);
        Carro carro6 = new Carro();
        carro6.setMatricula("");
        boolean b10 = carro6.equals((java.lang.Object) (-1.0d));
        boolean b11 = carro1.equals((java.lang.Object) (-1.0d));
        Carro carro12 = new Carro(carro1);
        int i13 = carro1.getVelocidadeMedia();
        Carro carro14 = new Carro();
        carro14.setMatricula("");
        Carro carro17 = carro14.clone();
        carro14.setPrecoBase((double) 0L);
        Carro carro20 = new Carro();
        int i21 = carro20.getLugares();
        int i22 = carro14.compareTo((Veiculo) carro20);
        java.lang.String str23 = carro20.toString();
        int i24 = carro20.getFiabilidade();
        boolean b25 = carro1.equals((java.lang.Object) i24);
        carro1.setMatricula("hi!");
        Carro carro28 = new Carro();
        carro28.setMatricula("");
        boolean b32 = carro28.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada33 = carro28.getCoordenadas();
        int i34 = carro28.getVelocidadeMedia();
        Carro carro35 = new Carro();
        carro35.setMatricula("");
        Carro carro38 = carro35.clone();
        carro38.setOcupado(true);
        boolean b41 = carro28.equals((java.lang.Object) carro38);
        carro38.setMatricula("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Carro carro44 = new Carro();
        Carro carro45 = new Carro(carro44);
        java.lang.String str46 = carro44.toString();
        carro44.setFiabilidade(0);
        Carro carro49 = carro44.clone();
        int i50 = carro44.getLugares();
        Carro carro55 = new Carro();
        Carro carro56 = new Carro(carro55);
        Carro carro57 = new Carro(carro56);
        Carro carro58 = new Carro();
        Carro carro59 = new Carro(carro58);
        int i60 = carro56.compareTo((Veiculo) carro58);
        Carro carro61 = new Carro();
        carro61.setMatricula("");
        boolean b65 = carro61.equals((java.lang.Object) (-1.0d));
        boolean b66 = carro56.equals((java.lang.Object) (-1.0d));
        Carro carro67 = new Carro();
        carro67.setMatricula("");
        Carro carro70 = carro67.clone();
        carro67.setPrecoBase((double) 0L);
        Carro carro73 = new Carro();
        int i74 = carro73.getLugares();
        int i75 = carro67.compareTo((Veiculo) carro73);
        java.lang.String str76 = carro73.toString();
        Coordenada coordenada77 = carro73.getCoordenadas();
        carro56.setCoordenadas(coordenada77);
        Carro carro80 = new Carro((-1), 10.0d, (int) (byte) 1, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada77, true);
        carro44.setCoordenadas(coordenada77);
        carro38.setCoordenadas(coordenada77);
        carro1.setCoordenadas(coordenada77);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertNotNull(carro17);
        org.junit.Assert.assertTrue(i21 == 0);
        org.junit.Assert.assertTrue(i22 == 3);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str23.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i24 == 0);
        org.junit.Assert.assertTrue(b25 == false);
        org.junit.Assert.assertTrue(b32 == false);
        org.junit.Assert.assertNotNull(coordenada33);
        org.junit.Assert.assertTrue(i34 == 0);
        org.junit.Assert.assertNotNull(carro38);
        org.junit.Assert.assertTrue(b41 == false);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str46.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro49);
        org.junit.Assert.assertTrue(i50 == 0);
        org.junit.Assert.assertTrue(i60 == 0);
        org.junit.Assert.assertTrue(b65 == false);
        org.junit.Assert.assertTrue(b66 == false);
        org.junit.Assert.assertNotNull(carro70);
        org.junit.Assert.assertTrue(i74 == 0);
        org.junit.Assert.assertTrue(i75 == 3);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str76.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada77);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        Carro carro4 = new Carro();
        carro4.setMatricula("");
        boolean b8 = carro4.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada9 = carro4.getCoordenadas();
        Carro carro11 = new Carro((int) (short) 0, (double) 'a', 1, "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada9, false);
        java.lang.String str12 = carro11.toString();
        carro11.setVelocidadeMedia((int) 'a');
        Carro carro15 = new Carro();
        Carro carro16 = new Carro(carro15);
        Carro carro17 = new Carro(carro16);
        Carro carro18 = new Carro();
        int i19 = carro18.getLugares();
        boolean b20 = carro17.equals((java.lang.Object) carro18);
        carro18.setOcupado(true);
        int i23 = carro18.getVelocidadeMedia();
        Carro carro24 = new Carro();
        carro24.setMatricula("");
        boolean b28 = carro24.equals((java.lang.Object) (-1.0d));
        Carro carro29 = new Carro(carro24);
        double d30 = carro24.getPrecoBase();
        boolean b31 = carro24.getOcupado();
        int i32 = carro24.getVelocidadeMedia();
        java.lang.String str33 = carro24.getMatricula();
        carro24.setMatricula("hi!");
        carro24.setVelocidadeMedia((int) (byte) 1);
        int i38 = carro18.compareTo((Veiculo) carro24);
        int i39 = carro11.compareTo((Veiculo) carro18);
        org.junit.Assert.assertTrue(b8 == false);
        org.junit.Assert.assertNotNull(coordenada9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Matrícula: Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 97.0€\nFiabilidade: 1\nLugares: 4\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str12.equals("Matrícula: Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 97.0€\nFiabilidade: 1\nLugares: 4\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i19 == 0);
        org.junit.Assert.assertTrue(b20 == true);
        org.junit.Assert.assertTrue(i23 == 0);
        org.junit.Assert.assertTrue(b28 == false);
        org.junit.Assert.assertTrue(d30 == 0.0d);
        org.junit.Assert.assertTrue(b31 == false);
        org.junit.Assert.assertTrue(i32 == 0);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
        org.junit.Assert.assertTrue(i38 == (-6));
        org.junit.Assert.assertTrue(i39 == 33);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        Carro carro4 = new Carro(carro3);
        int i5 = carro1.compareTo((Veiculo) carro3);
        int i6 = carro3.getVelocidadeMedia();
        Carro carro7 = carro3.clone();
        Carro carro8 = new Carro();
        Carro carro9 = new Carro(carro8);
        java.lang.String str10 = carro8.toString();
        carro8.setFiabilidade(0);
        Carro carro13 = carro8.clone();
        int i14 = carro8.getLugares();
        Carro carro19 = new Carro();
        Carro carro20 = new Carro(carro19);
        Carro carro21 = new Carro(carro20);
        Carro carro22 = new Carro();
        Carro carro23 = new Carro(carro22);
        int i24 = carro20.compareTo((Veiculo) carro22);
        Carro carro25 = new Carro();
        carro25.setMatricula("");
        boolean b29 = carro25.equals((java.lang.Object) (-1.0d));
        boolean b30 = carro20.equals((java.lang.Object) (-1.0d));
        Carro carro31 = new Carro();
        carro31.setMatricula("");
        Carro carro34 = carro31.clone();
        carro31.setPrecoBase((double) 0L);
        Carro carro37 = new Carro();
        int i38 = carro37.getLugares();
        int i39 = carro31.compareTo((Veiculo) carro37);
        java.lang.String str40 = carro37.toString();
        Coordenada coordenada41 = carro37.getCoordenadas();
        carro20.setCoordenadas(coordenada41);
        Carro carro44 = new Carro((-1), 10.0d, (int) (byte) 1, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada41, true);
        carro8.setCoordenadas(coordenada41);
        carro3.setCoordenadas(coordenada41);
        int i47 = carro3.getLugares();
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertNotNull(carro7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str10.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro13);
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(i24 == 0);
        org.junit.Assert.assertTrue(b29 == false);
        org.junit.Assert.assertTrue(b30 == false);
        org.junit.Assert.assertNotNull(carro34);
        org.junit.Assert.assertTrue(i38 == 0);
        org.junit.Assert.assertTrue(i39 == 3);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str40.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada41);
        org.junit.Assert.assertTrue(i47 == 0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        Carro carro4 = new Carro(carro3);
        int i5 = carro1.compareTo((Veiculo) carro3);
        Carro carro10 = new Carro();
        carro10.setMatricula("");
        Carro carro13 = carro10.clone();
        carro10.setPrecoBase((double) 0L);
        Carro carro16 = new Carro();
        int i17 = carro16.getLugares();
        int i18 = carro10.compareTo((Veiculo) carro16);
        java.lang.String str19 = carro16.toString();
        Coordenada coordenada20 = carro16.getCoordenadas();
        Carro carro22 = new Carro((int) ' ', (double) 100.0f, (int) (byte) -1, "", coordenada20, false);
        int i23 = carro1.compareTo((Veiculo) carro22);
        boolean b24 = carro22.getOcupado();
        int i25 = carro22.getFiabilidade();
        carro22.setMatricula("Matrícula: Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 52km/h\nPreço Base: 1.0€\nFiabilidade: 0\nLugares: 4\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n");
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertNotNull(carro13);
        org.junit.Assert.assertTrue(i17 == 0);
        org.junit.Assert.assertTrue(i18 == 3);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str19.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada20);
        org.junit.Assert.assertTrue(i23 == (-3));
        org.junit.Assert.assertTrue(b24 == false);
        org.junit.Assert.assertTrue(i25 == (-1));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        java.lang.String str9 = carro6.toString();
        Coordenada coordenada10 = carro6.getCoordenadas();
        java.lang.String str11 = carro6.toString();
        Carro carro12 = new Carro();
        carro12.setMatricula("");
        Carro carro15 = carro12.clone();
        carro12.setPrecoBase((double) 0L);
        Carro carro18 = new Carro();
        int i19 = carro18.getLugares();
        int i20 = carro12.compareTo((Veiculo) carro18);
        java.lang.String str21 = carro18.toString();
        int i22 = carro18.getVelocidadeMedia();
        java.lang.String str23 = carro18.getMatricula();
        int i24 = carro6.compareTo((Veiculo) carro18);
        carro6.setPrecoBase((double) (-1));
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str11.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro15);
        org.junit.Assert.assertTrue(i19 == 0);
        org.junit.Assert.assertTrue(i20 == 3);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str21.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i22 == 0);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "n/a" + "'", str23.equals("n/a"));
        org.junit.Assert.assertTrue(i24 == 0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        Carro carro4 = new Carro();
        carro4.setMatricula("");
        Carro carro7 = carro4.clone();
        carro4.setPrecoBase((double) 0L);
        Carro carro10 = new Carro();
        int i11 = carro10.getLugares();
        int i12 = carro4.compareTo((Veiculo) carro10);
        java.lang.String str13 = carro10.toString();
        Coordenada coordenada14 = carro10.getCoordenadas();
        Carro carro16 = new Carro((int) (byte) 100, (double) '#', (int) (short) 0, "", coordenada14, false);
        carro16.setFiabilidade(0);
        org.junit.Assert.assertNotNull(carro7);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(i12 == 3);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str13.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada14);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        Carro carro16 = new Carro();
        carro16.setMatricula("");
        Carro carro19 = carro16.clone();
        carro16.setPrecoBase((double) 0L);
        Carro carro22 = new Carro();
        int i23 = carro22.getLugares();
        int i24 = carro16.compareTo((Veiculo) carro22);
        java.lang.String str25 = carro22.toString();
        Coordenada coordenada26 = carro22.getCoordenadas();
        Carro carro28 = new Carro((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada26, false);
        Carro carro30 = new Carro((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada26, true);
        Carro carro32 = new Carro((int) '#', 10.0d, (-1), "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada26, true);
        Coordenada coordenada33 = carro32.getCoordenadas();
        Carro carro35 = new Carro(33, (double) 52, (-142), "Matrícula: \nVelocidade Média/km: -1km/h\nPreço Base: 0.0€\nFiabilidade: 1\nLugares: 4\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada33, false);
        java.lang.String str36 = carro35.getMatricula();
        org.junit.Assert.assertNotNull(carro19);
        org.junit.Assert.assertTrue(i23 == 0);
        org.junit.Assert.assertTrue(i24 == 3);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str25.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada26);
        org.junit.Assert.assertNotNull(coordenada33);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Matrícula: \nVelocidade Média/km: -1km/h\nPreço Base: 0.0€\nFiabilidade: 1\nLugares: 4\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str36.equals("Matrícula: \nVelocidade Média/km: -1km/h\nPreço Base: 0.0€\nFiabilidade: 1\nLugares: 4\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        Carro carro8 = new Carro();
        carro8.setMatricula("");
        Carro carro11 = carro8.clone();
        carro8.setPrecoBase((double) 0L);
        Carro carro14 = new Carro();
        int i15 = carro14.getLugares();
        int i16 = carro8.compareTo((Veiculo) carro14);
        java.lang.String str17 = carro14.toString();
        Coordenada coordenada18 = carro14.getCoordenadas();
        Carro carro20 = new Carro((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, false);
        Carro carro22 = new Carro((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada18, true);
        carro22.setFiabilidade(0);
        carro22.setFiabilidade(32);
        org.junit.Assert.assertNotNull(carro11);
        org.junit.Assert.assertTrue(i15 == 0);
        org.junit.Assert.assertTrue(i16 == 3);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str17.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada18);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        java.lang.String str9 = carro6.toString();
        int i10 = carro6.getFiabilidade();
        Carro carro11 = new Carro();
        Carro carro12 = new Carro(carro11);
        java.lang.String str13 = carro11.toString();
        carro11.setFiabilidade(0);
        Carro carro16 = carro11.clone();
        int i17 = carro16.getFiabilidade();
        Coordenada coordenada18 = carro16.getCoordenadas();
        carro6.setCoordenadas(coordenada18);
        Carro carro20 = new Carro();
        carro20.setMatricula("");
        Carro carro23 = carro20.clone();
        carro20.setPrecoBase((double) 0L);
        Carro carro26 = new Carro();
        int i27 = carro26.getLugares();
        int i28 = carro20.compareTo((Veiculo) carro26);
        int i29 = carro26.getFiabilidade();
        Carro carro30 = carro26.clone();
        Coordenada coordenada31 = carro30.getCoordenadas();
        boolean b32 = carro6.equals((java.lang.Object) carro30);
        Carro carro33 = carro30.clone();
        double d34 = carro33.getPrecoBase();
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str13.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro16);
        org.junit.Assert.assertTrue(i17 == 0);
        org.junit.Assert.assertNotNull(coordenada18);
        org.junit.Assert.assertNotNull(carro23);
        org.junit.Assert.assertTrue(i27 == 0);
        org.junit.Assert.assertTrue(i28 == 3);
        org.junit.Assert.assertTrue(i29 == 0);
        org.junit.Assert.assertNotNull(carro30);
        org.junit.Assert.assertNotNull(coordenada31);
        org.junit.Assert.assertTrue(b32 == true);
        org.junit.Assert.assertNotNull(carro33);
        org.junit.Assert.assertTrue(d34 == 0.0d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Carro carro5 = new Carro(carro0);
        double d6 = carro0.getPrecoBase();
        java.lang.String str7 = carro0.toString();
        int i8 = carro0.getVelocidadeMedia();
        int i9 = carro0.getVelocidadeMedia();
        double d10 = carro0.getPrecoBase();
        carro0.setFiabilidade((-33));
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str7.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertTrue(d10 == 0.0d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        Carro carro16 = new Carro();
        carro16.setMatricula("");
        Carro carro19 = carro16.clone();
        carro16.setPrecoBase((double) 0L);
        Carro carro22 = new Carro();
        int i23 = carro22.getLugares();
        int i24 = carro16.compareTo((Veiculo) carro22);
        java.lang.String str25 = carro22.toString();
        Coordenada coordenada26 = carro22.getCoordenadas();
        Carro carro28 = new Carro((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada26, false);
        Carro carro30 = new Carro((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada26, true);
        Carro carro32 = new Carro((int) '#', 10.0d, (-1), "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada26, true);
        Carro carro33 = new Carro();
        carro33.setMatricula("");
        boolean b37 = carro33.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada38 = carro33.getCoordenadas();
        boolean b39 = carro33.getOcupado();
        java.lang.String str40 = carro33.getMatricula();
        Carro carro45 = new Carro();
        carro45.setMatricula("");
        Carro carro48 = carro45.clone();
        carro45.setPrecoBase((double) 0L);
        Carro carro51 = new Carro();
        int i52 = carro51.getLugares();
        int i53 = carro45.compareTo((Veiculo) carro51);
        java.lang.String str54 = carro51.toString();
        Coordenada coordenada55 = carro51.getCoordenadas();
        Carro carro57 = new Carro((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada55, false);
        carro33.setCoordenadas(coordenada55);
        carro32.setCoordenadas(coordenada55);
        Carro carro61 = new Carro((int) (short) 1, (double) (-1.0f), 100, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada55, true);
        int i62 = carro61.getFiabilidade();
        boolean b63 = carro61.getOcupado();
        org.junit.Assert.assertNotNull(carro19);
        org.junit.Assert.assertTrue(i23 == 0);
        org.junit.Assert.assertTrue(i24 == 3);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str25.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada26);
        org.junit.Assert.assertTrue(b37 == false);
        org.junit.Assert.assertNotNull(coordenada38);
        org.junit.Assert.assertTrue(b39 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "" + "'", str40.equals(""));
        org.junit.Assert.assertNotNull(carro48);
        org.junit.Assert.assertTrue(i52 == 0);
        org.junit.Assert.assertTrue(i53 == 3);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str54.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada55);
        org.junit.Assert.assertTrue(i62 == 100);
        org.junit.Assert.assertTrue(b63 == true);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        Carro carro4 = new Carro();
        carro4.setMatricula("");
        Carro carro7 = carro4.clone();
        carro4.setPrecoBase((double) 0L);
        Carro carro10 = new Carro();
        int i11 = carro10.getLugares();
        int i12 = carro4.compareTo((Veiculo) carro10);
        java.lang.String str13 = carro10.toString();
        Coordenada coordenada14 = carro10.getCoordenadas();
        Carro carro16 = new Carro((int) ' ', (double) 100.0f, (int) (byte) -1, "", coordenada14, false);
        double d17 = carro16.getPrecoBase();
        Carro carro18 = new Carro();
        carro18.setMatricula("");
        Carro carro21 = carro18.clone();
        carro18.setPrecoBase((double) 0L);
        Carro carro24 = new Carro();
        int i25 = carro24.getLugares();
        int i26 = carro18.compareTo((Veiculo) carro24);
        java.lang.String str27 = carro24.toString();
        Coordenada coordenada28 = carro24.getCoordenadas();
        carro16.setCoordenadas(coordenada28);
        org.junit.Assert.assertNotNull(carro7);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(i12 == 3);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str13.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada14);
        org.junit.Assert.assertTrue(d17 == 100.0d);
        org.junit.Assert.assertNotNull(carro21);
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue(i26 == 3);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str27.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada28);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        java.lang.String str9 = carro6.toString();
        int i10 = carro6.getFiabilidade();
        carro6.setPrecoBase(10.0d);
        int i13 = carro6.getFiabilidade();
        carro6.setFiabilidade(100);
        Carro carro16 = new Carro();
        carro16.setMatricula("");
        Carro carro19 = carro16.clone();
        carro16.setPrecoBase((double) 0L);
        Carro carro22 = new Carro(carro16);
        carro22.setPrecoBase((double) (-1.0f));
        carro22.setVelocidadeMedia((int) (short) 0);
        carro22.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Carro carro29 = new Carro(carro22);
        int i30 = carro6.compareTo((Veiculo) carro22);
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertNotNull(carro19);
        org.junit.Assert.assertTrue(i30 == (-33));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        Carro carro4 = new Carro(carro3);
        int i5 = carro1.compareTo((Veiculo) carro3);
        int i6 = carro3.getVelocidadeMedia();
        int i7 = carro3.getVelocidadeMedia();
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertTrue(i7 == 0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        Carro carro4 = new Carro();
        carro4.setMatricula("");
        boolean b8 = carro4.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada9 = carro4.getCoordenadas();
        Carro carro11 = new Carro((int) (short) 0, (double) 'a', 1, "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada9, false);
        java.lang.String str12 = carro11.toString();
        carro11.setVelocidadeMedia((int) 'a');
        java.lang.String str15 = carro11.toString();
        org.junit.Assert.assertTrue(b8 == false);
        org.junit.Assert.assertNotNull(coordenada9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Matrícula: Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 97.0€\nFiabilidade: 1\nLugares: 4\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str12.equals("Matrícula: Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 0km/h\nPreço Base: 97.0€\nFiabilidade: 1\nLugares: 4\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Matrícula: Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 97km/h\nPreço Base: 97.0€\nFiabilidade: 1\nLugares: 4\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str15.equals("Matrícula: Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 97km/h\nPreço Base: 97.0€\nFiabilidade: 1\nLugares: 4\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        carro0.setOcupado(false);
        carro0.setVelocidadeMedia((int) (byte) 1);
        carro0.setFiabilidade((int) (byte) 10);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        java.lang.String str9 = carro6.toString();
        Coordenada coordenada10 = carro6.getCoordenadas();
        Carro carro11 = new Carro();
        int i12 = carro11.getLugares();
        Coordenada coordenada13 = carro11.getCoordenadas();
        carro6.setCoordenadas(coordenada13);
        Carro carro19 = new Carro();
        carro19.setMatricula("");
        Carro carro22 = carro19.clone();
        carro19.setPrecoBase((double) 0L);
        Carro carro25 = new Carro();
        int i26 = carro25.getLugares();
        int i27 = carro19.compareTo((Veiculo) carro25);
        java.lang.String str28 = carro25.toString();
        Coordenada coordenada29 = carro25.getCoordenadas();
        Carro carro30 = new Carro();
        int i31 = carro30.getLugares();
        Coordenada coordenada32 = carro30.getCoordenadas();
        carro25.setCoordenadas(coordenada32);
        Carro carro35 = new Carro((int) (byte) -1, (double) 10, 32, "Matrícula: hi!\nVelocidade Média/km: 0km/h\nPreço Base: 10.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada32, false);
        carro6.setCoordenadas(coordenada32);
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertNotNull(coordenada13);
        org.junit.Assert.assertNotNull(carro22);
        org.junit.Assert.assertTrue(i26 == 0);
        org.junit.Assert.assertTrue(i27 == 3);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str28.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada29);
        org.junit.Assert.assertTrue(i31 == 0);
        org.junit.Assert.assertNotNull(coordenada32);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        carro0.setMatricula("n/a");
        Carro carro6 = new Carro();
        carro6.setMatricula("");
        Carro carro9 = carro6.clone();
        carro6.setPrecoBase((double) 0L);
        Carro carro12 = new Carro();
        int i13 = carro12.getLugares();
        int i14 = carro6.compareTo((Veiculo) carro12);
        java.lang.String str15 = carro12.toString();
        Coordenada coordenada16 = carro12.getCoordenadas();
        Carro carro17 = new Carro();
        int i18 = carro17.getLugares();
        Coordenada coordenada19 = carro17.getCoordenadas();
        carro12.setCoordenadas(coordenada19);
        carro0.setCoordenadas(coordenada19);
        Carro carro22 = new Carro();
        carro22.setMatricula("");
        boolean b26 = carro22.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada27 = carro22.getCoordenadas();
        carro0.setCoordenadas(coordenada27);
        Carro carro29 = new Carro();
        carro29.setMatricula("");
        Carro carro32 = carro29.clone();
        carro29.setPrecoBase((double) 0L);
        Carro carro35 = new Carro();
        int i36 = carro35.getLugares();
        int i37 = carro29.compareTo((Veiculo) carro35);
        java.lang.String str38 = carro35.toString();
        int i39 = carro35.getFiabilidade();
        Carro carro40 = new Carro();
        Carro carro41 = new Carro(carro40);
        Carro carro42 = new Carro(carro41);
        Carro carro43 = new Carro();
        Carro carro44 = new Carro(carro43);
        int i45 = carro41.compareTo((Veiculo) carro43);
        Carro carro46 = new Carro();
        carro46.setMatricula("");
        boolean b50 = carro46.equals((java.lang.Object) (-1.0d));
        boolean b51 = carro41.equals((java.lang.Object) (-1.0d));
        Carro carro52 = new Carro();
        carro52.setMatricula("");
        Carro carro55 = carro52.clone();
        carro52.setPrecoBase((double) 0L);
        Carro carro58 = new Carro();
        int i59 = carro58.getLugares();
        int i60 = carro52.compareTo((Veiculo) carro58);
        java.lang.String str61 = carro58.toString();
        Coordenada coordenada62 = carro58.getCoordenadas();
        carro41.setCoordenadas(coordenada62);
        boolean b64 = carro35.equals((java.lang.Object) carro41);
        java.lang.String str65 = carro35.toString();
        Carro carro66 = new Carro();
        Carro carro67 = new Carro(carro66);
        java.lang.String str68 = carro66.toString();
        carro66.setFiabilidade(0);
        Carro carro71 = carro66.clone();
        carro66.setPrecoBase((double) 0.0f);
        boolean b74 = carro35.equals((java.lang.Object) carro66);
        int i75 = carro0.compareTo((Veiculo) carro35);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(carro9);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(i14 == 3);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str15.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada16);
        org.junit.Assert.assertTrue(i18 == 0);
        org.junit.Assert.assertNotNull(coordenada19);
        org.junit.Assert.assertTrue(b26 == false);
        org.junit.Assert.assertNotNull(coordenada27);
        org.junit.Assert.assertNotNull(carro32);
        org.junit.Assert.assertTrue(i36 == 0);
        org.junit.Assert.assertTrue(i37 == 3);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str38.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i39 == 0);
        org.junit.Assert.assertTrue(i45 == 0);
        org.junit.Assert.assertTrue(b50 == false);
        org.junit.Assert.assertTrue(b51 == false);
        org.junit.Assert.assertNotNull(carro55);
        org.junit.Assert.assertTrue(i59 == 0);
        org.junit.Assert.assertTrue(i60 == 3);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str61.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada62);
        org.junit.Assert.assertTrue(b64 == true);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str65.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str68.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro71);
        org.junit.Assert.assertTrue(b74 == true);
        org.junit.Assert.assertTrue(i75 == 0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro3.setOcupado(true);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        carro6.setVelocidadeMedia(10);
        int i10 = carro3.compareTo((Veiculo) carro6);
        Coordenada coordenada11 = carro3.getCoordenadas();
        int i12 = carro3.getVelocidadeMedia();
        Carro carro13 = new Carro();
        carro13.setMatricula("");
        Carro carro16 = carro13.clone();
        carro13.setPrecoBase((double) 0L);
        Carro carro19 = new Carro(carro13);
        Coordenada coordenada20 = carro13.getCoordenadas();
        carro3.setCoordenadas(coordenada20);
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i10 == 3);
        org.junit.Assert.assertNotNull(coordenada11);
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertNotNull(carro16);
        org.junit.Assert.assertNotNull(coordenada20);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        int i2 = carro1.getFiabilidade();
        Coordenada coordenada3 = carro1.getCoordenadas();
        Carro carro4 = new Carro();
        carro4.setMatricula("");
        boolean b8 = carro4.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada9 = carro4.getCoordenadas();
        boolean b10 = carro4.getOcupado();
        java.lang.String str11 = carro4.getMatricula();
        Carro carro16 = new Carro();
        carro16.setMatricula("");
        Carro carro19 = carro16.clone();
        carro16.setPrecoBase((double) 0L);
        Carro carro22 = new Carro();
        int i23 = carro22.getLugares();
        int i24 = carro16.compareTo((Veiculo) carro22);
        java.lang.String str25 = carro22.toString();
        Coordenada coordenada26 = carro22.getCoordenadas();
        Carro carro28 = new Carro((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada26, false);
        carro4.setCoordenadas(coordenada26);
        Carro carro30 = new Carro();
        carro30.setMatricula("");
        Carro carro33 = carro30.clone();
        carro30.setPrecoBase((double) 0L);
        Carro carro36 = new Carro();
        int i37 = carro36.getLugares();
        int i38 = carro30.compareTo((Veiculo) carro36);
        int i39 = carro36.getFiabilidade();
        Carro carro40 = carro36.clone();
        Coordenada coordenada41 = carro40.getCoordenadas();
        carro4.setCoordenadas(coordenada41);
        boolean b43 = carro1.equals((java.lang.Object) carro4);
        int i44 = carro4.getVelocidadeMedia();
        int i45 = carro4.getVelocidadeMedia();
        org.junit.Assert.assertTrue(i2 == 0);
        org.junit.Assert.assertNotNull(coordenada3);
        org.junit.Assert.assertTrue(b8 == false);
        org.junit.Assert.assertNotNull(coordenada9);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(carro19);
        org.junit.Assert.assertTrue(i23 == 0);
        org.junit.Assert.assertTrue(i24 == 3);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str25.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada26);
        org.junit.Assert.assertNotNull(carro33);
        org.junit.Assert.assertTrue(i37 == 0);
        org.junit.Assert.assertTrue(i38 == 3);
        org.junit.Assert.assertTrue(i39 == 0);
        org.junit.Assert.assertNotNull(carro40);
        org.junit.Assert.assertNotNull(coordenada41);
        org.junit.Assert.assertTrue(b43 == false);
        org.junit.Assert.assertTrue(i44 == 0);
        org.junit.Assert.assertTrue(i45 == 0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro3.setOcupado(true);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        carro6.setVelocidadeMedia(10);
        int i10 = carro3.compareTo((Veiculo) carro6);
        Coordenada coordenada11 = carro3.getCoordenadas();
        int i12 = carro3.getLugares();
        carro3.setPrecoBase((double) 10.0f);
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i10 == 3);
        org.junit.Assert.assertNotNull(coordenada11);
        org.junit.Assert.assertTrue(i12 == 0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        Carro carro2 = carro0.clone();
        Carro carro3 = new Carro(carro2);
        Coordenada coordenada4 = carro3.getCoordenadas();
        Carro carro5 = carro3.clone();
        Carro carro6 = new Carro();
        carro6.setMatricula("");
        boolean b10 = carro6.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada11 = carro6.getCoordenadas();
        boolean b12 = carro6.getOcupado();
        java.lang.String str13 = carro6.getMatricula();
        Carro carro18 = new Carro();
        carro18.setMatricula("");
        Carro carro21 = carro18.clone();
        carro18.setPrecoBase((double) 0L);
        Carro carro24 = new Carro();
        int i25 = carro24.getLugares();
        int i26 = carro18.compareTo((Veiculo) carro24);
        java.lang.String str27 = carro24.toString();
        Coordenada coordenada28 = carro24.getCoordenadas();
        Carro carro30 = new Carro((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada28, false);
        carro6.setCoordenadas(coordenada28);
        boolean b32 = carro3.equals((java.lang.Object) carro6);
        int i33 = carro3.getVelocidadeMedia();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(carro2);
        org.junit.Assert.assertNotNull(coordenada4);
        org.junit.Assert.assertNotNull(carro5);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertNotNull(coordenada11);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(carro21);
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue(i26 == 3);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str27.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada28);
        org.junit.Assert.assertTrue(b32 == false);
        org.junit.Assert.assertTrue(i33 == 0);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        Carro carro4 = new Carro(carro0);
        carro4.setOcupado(true);
        java.lang.String str7 = carro4.getMatricula();
        Carro carro8 = new Carro(carro4);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "n/a" + "'", str7.equals("n/a"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        Carro carro4 = new Carro();
        carro4.setMatricula("");
        java.lang.String str7 = carro4.toString();
        Carro carro8 = new Carro();
        Carro carro9 = new Carro(carro8);
        java.lang.String str10 = carro8.toString();
        carro8.setFiabilidade(0);
        Carro carro13 = carro8.clone();
        Carro carro14 = new Carro();
        Carro carro15 = new Carro(carro14);
        Carro carro16 = new Carro(carro15);
        Carro carro17 = new Carro();
        Carro carro18 = new Carro(carro17);
        int i19 = carro15.compareTo((Veiculo) carro17);
        Carro carro20 = new Carro();
        carro20.setMatricula("");
        boolean b24 = carro20.equals((java.lang.Object) (-1.0d));
        boolean b25 = carro15.equals((java.lang.Object) (-1.0d));
        Carro carro26 = new Carro();
        carro26.setMatricula("");
        Carro carro29 = carro26.clone();
        carro26.setPrecoBase((double) 0L);
        Carro carro32 = new Carro();
        int i33 = carro32.getLugares();
        int i34 = carro26.compareTo((Veiculo) carro32);
        java.lang.String str35 = carro32.toString();
        Coordenada coordenada36 = carro32.getCoordenadas();
        carro15.setCoordenadas(coordenada36);
        carro8.setCoordenadas(coordenada36);
        carro4.setCoordenadas(coordenada36);
        Carro carro41 = new Carro((int) '4', (double) 1.0f, 4, "hi!", coordenada36, false);
        carro41.setFiabilidade(100);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str7.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str10.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro13);
        org.junit.Assert.assertTrue(i19 == 0);
        org.junit.Assert.assertTrue(b24 == false);
        org.junit.Assert.assertTrue(b25 == false);
        org.junit.Assert.assertNotNull(carro29);
        org.junit.Assert.assertTrue(i33 == 0);
        org.junit.Assert.assertTrue(i34 == 3);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str35.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada36);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        java.lang.String str3 = carro0.toString();
        Carro carro4 = carro0.clone();
        Carro carro5 = new Carro();
        carro5.setMatricula("");
        boolean b9 = carro5.equals((java.lang.Object) (-1.0d));
        Carro carro10 = new Carro(carro5);
        int i11 = carro10.getVelocidadeMedia();
        Carro carro12 = new Carro();
        Carro carro13 = new Carro(carro12);
        Carro carro14 = new Carro(carro13);
        Carro carro15 = new Carro();
        Carro carro16 = new Carro(carro15);
        int i17 = carro13.compareTo((Veiculo) carro15);
        Carro carro18 = new Carro();
        carro18.setMatricula("");
        boolean b22 = carro18.equals((java.lang.Object) (-1.0d));
        boolean b23 = carro13.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada24 = carro13.getCoordenadas();
        carro10.setCoordenadas(coordenada24);
        carro10.setMatricula("n/a");
        Coordenada coordenada28 = carro10.getCoordenadas();
        boolean b29 = carro10.getOcupado();
        Coordenada coordenada30 = carro10.getCoordenadas();
        carro4.setCoordenadas(coordenada30);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro4);
        org.junit.Assert.assertTrue(b9 == false);
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(i17 == 0);
        org.junit.Assert.assertTrue(b22 == false);
        org.junit.Assert.assertTrue(b23 == false);
        org.junit.Assert.assertNotNull(coordenada24);
        org.junit.Assert.assertNotNull(coordenada28);
        org.junit.Assert.assertTrue(b29 == false);
        org.junit.Assert.assertNotNull(coordenada30);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carro0.getCoordenadas();
        carro0.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carro0.setFiabilidade(0);
        Carro carro10 = new Carro();
        carro10.setMatricula("");
        Carro carro13 = carro10.clone();
        carro10.setPrecoBase((double) 0L);
        Carro carro16 = new Carro(carro10);
        int i17 = carro0.compareTo((Veiculo) carro10);
        Carro carro18 = new Carro(carro10);
        java.lang.String str19 = carro10.toString();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertNotNull(carro13);
        org.junit.Assert.assertTrue(i17 == (-142));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str19.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        int i4 = carro3.getFiabilidade();
        java.lang.String str5 = carro3.toString();
        carro3.setOcupado(false);
        java.lang.String str8 = carro3.getMatricula();
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str5.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        Carro carro4 = new Carro(carro0);
        java.lang.String str5 = carro0.toString();
        int i6 = carro0.getVelocidadeMedia();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str5.equals("Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i6 == 10);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        Carro carro4 = new Carro(carro3);
        int i5 = carro1.compareTo((Veiculo) carro3);
        Carro carro10 = new Carro();
        carro10.setMatricula("");
        Carro carro13 = carro10.clone();
        carro10.setPrecoBase((double) 0L);
        Carro carro16 = new Carro();
        int i17 = carro16.getLugares();
        int i18 = carro10.compareTo((Veiculo) carro16);
        java.lang.String str19 = carro16.toString();
        Coordenada coordenada20 = carro16.getCoordenadas();
        Carro carro22 = new Carro((int) ' ', (double) 100.0f, (int) (byte) -1, "", coordenada20, false);
        int i23 = carro1.compareTo((Veiculo) carro22);
        java.lang.String str24 = carro22.toString();
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertNotNull(carro13);
        org.junit.Assert.assertTrue(i17 == 0);
        org.junit.Assert.assertTrue(i18 == 3);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str19.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada20);
        org.junit.Assert.assertTrue(i23 == (-3));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Matrícula: \nVelocidade Média/km: 32km/h\nPreço Base: 100.0€\nFiabilidade: -1\nLugares: 4\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str24.equals("Matrícula: \nVelocidade Média/km: 32km/h\nPreço Base: 100.0€\nFiabilidade: -1\nLugares: 4\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        java.lang.String str3 = carro0.toString();
        carro0.setPrecoBase((double) (short) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        Carro carro4 = new Carro(carro3);
        int i5 = carro1.compareTo((Veiculo) carro3);
        carro3.setMatricula("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        int i8 = carro3.getFiabilidade();
        Carro carro9 = carro3.clone();
        Carro carro10 = carro3.clone();
        double d11 = carro3.getPrecoBase();
        double d12 = carro3.getPrecoBase();
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertNotNull(carro9);
        org.junit.Assert.assertNotNull(carro10);
        org.junit.Assert.assertTrue(d11 == 0.0d);
        org.junit.Assert.assertTrue(d12 == 0.0d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Carro carro5 = new Carro(carro0);
        double d6 = carro0.getPrecoBase();
        boolean b7 = carro0.getOcupado();
        carro0.setOcupado(true);
        java.lang.String str10 = carro0.toString();
        Coordenada coordenada11 = carro0.getCoordenadas();
        java.lang.String str12 = carro0.getMatricula();
        Carro carro13 = new Carro();
        carro13.setMatricula("");
        Carro carro16 = carro13.clone();
        carro13.setPrecoBase((double) 0L);
        Carro carro19 = new Carro();
        int i20 = carro19.getLugares();
        int i21 = carro13.compareTo((Veiculo) carro19);
        Carro carro22 = new Carro();
        carro22.setMatricula("");
        Carro carro25 = carro22.clone();
        carro22.setPrecoBase((double) 0L);
        Carro carro28 = new Carro();
        int i29 = carro28.getLugares();
        int i30 = carro22.compareTo((Veiculo) carro28);
        java.lang.String str31 = carro28.toString();
        Coordenada coordenada32 = carro28.getCoordenadas();
        Carro carro33 = new Carro();
        int i34 = carro33.getLugares();
        Coordenada coordenada35 = carro33.getCoordenadas();
        carro28.setCoordenadas(coordenada35);
        Carro carro37 = new Carro(carro28);
        int i38 = carro13.compareTo((Veiculo) carro28);
        int i39 = carro28.getFiabilidade();
        boolean b40 = carro0.equals((java.lang.Object) i39);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue(b7 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n" + "'", str10.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n"));
        org.junit.Assert.assertNotNull(coordenada11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNotNull(carro16);
        org.junit.Assert.assertTrue(i20 == 0);
        org.junit.Assert.assertTrue(i21 == 3);
        org.junit.Assert.assertNotNull(carro25);
        org.junit.Assert.assertTrue(i29 == 0);
        org.junit.Assert.assertTrue(i30 == 3);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str31.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada32);
        org.junit.Assert.assertTrue(i34 == 0);
        org.junit.Assert.assertNotNull(coordenada35);
        org.junit.Assert.assertTrue(i38 == 3);
        org.junit.Assert.assertTrue(i39 == 0);
        org.junit.Assert.assertTrue(b40 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro(carro0);
        carro6.setPrecoBase((double) (-1.0f));
        carro6.setVelocidadeMedia((int) (short) 0);
        carro6.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Carro carro13 = new Carro(carro6);
        carro6.setPrecoBase(1.0d);
        boolean b16 = carro6.getOcupado();
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(b16 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        Carro carro4 = new Carro(carro0);
        Carro carro5 = new Carro(carro4);
        int i6 = carro4.getLugares();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i6 == 0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        java.lang.String str2 = carro0.getMatricula();
        Carro carro3 = new Carro(carro0);
        carro3.setVelocidadeMedia((int) '4');
        Coordenada coordenada6 = carro3.getCoordenadas();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "n/a" + "'", str2.equals("n/a"));
        org.junit.Assert.assertNotNull(coordenada6);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        java.lang.String str9 = carro6.toString();
        int i10 = carro6.getFiabilidade();
        Carro carro11 = new Carro();
        Carro carro12 = new Carro(carro11);
        java.lang.String str13 = carro11.toString();
        carro11.setFiabilidade(0);
        Carro carro16 = carro11.clone();
        int i17 = carro16.getFiabilidade();
        Coordenada coordenada18 = carro16.getCoordenadas();
        carro6.setCoordenadas(coordenada18);
        Carro carro20 = new Carro();
        carro20.setMatricula("");
        Carro carro23 = carro20.clone();
        carro20.setPrecoBase((double) 0L);
        Carro carro26 = new Carro();
        int i27 = carro26.getLugares();
        int i28 = carro20.compareTo((Veiculo) carro26);
        int i29 = carro26.getFiabilidade();
        Carro carro30 = carro26.clone();
        Coordenada coordenada31 = carro30.getCoordenadas();
        boolean b32 = carro6.equals((java.lang.Object) carro30);
        int i33 = carro30.getLugares();
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str13.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro16);
        org.junit.Assert.assertTrue(i17 == 0);
        org.junit.Assert.assertNotNull(coordenada18);
        org.junit.Assert.assertNotNull(carro23);
        org.junit.Assert.assertTrue(i27 == 0);
        org.junit.Assert.assertTrue(i28 == 3);
        org.junit.Assert.assertTrue(i29 == 0);
        org.junit.Assert.assertNotNull(carro30);
        org.junit.Assert.assertNotNull(coordenada31);
        org.junit.Assert.assertTrue(b32 == true);
        org.junit.Assert.assertTrue(i33 == 0);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        Carro carro4 = new Carro(carro3);
        int i5 = carro1.compareTo((Veiculo) carro3);
        Carro carro6 = new Carro();
        carro6.setMatricula("");
        boolean b10 = carro6.equals((java.lang.Object) (-1.0d));
        boolean b11 = carro1.equals((java.lang.Object) (-1.0d));
        Carro carro12 = new Carro(carro1);
        int i13 = carro1.getVelocidadeMedia();
        double d14 = carro1.getPrecoBase();
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertTrue(d14 == 0.0d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Carro carro5 = new Carro(carro0);
        int i6 = carro5.getVelocidadeMedia();
        Carro carro7 = new Carro();
        Carro carro8 = new Carro(carro7);
        Carro carro9 = new Carro(carro8);
        Carro carro10 = new Carro();
        Carro carro11 = new Carro(carro10);
        int i12 = carro8.compareTo((Veiculo) carro10);
        Carro carro13 = new Carro();
        carro13.setMatricula("");
        boolean b17 = carro13.equals((java.lang.Object) (-1.0d));
        boolean b18 = carro8.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada19 = carro8.getCoordenadas();
        carro5.setCoordenadas(coordenada19);
        carro5.setMatricula("n/a");
        Carro carro23 = carro5.clone();
        carro23.setOcupado(true);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertTrue(b17 == false);
        org.junit.Assert.assertTrue(b18 == false);
        org.junit.Assert.assertNotNull(coordenada19);
        org.junit.Assert.assertNotNull(carro23);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro3.setOcupado(true);
        java.lang.String str6 = carro3.toString();
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n" + "'", str6.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Carro carro5 = new Carro(carro0);
        int i6 = carro5.getVelocidadeMedia();
        Carro carro7 = new Carro();
        Carro carro8 = new Carro(carro7);
        Carro carro9 = new Carro(carro8);
        Carro carro10 = new Carro();
        Carro carro11 = new Carro(carro10);
        int i12 = carro8.compareTo((Veiculo) carro10);
        Carro carro13 = new Carro();
        carro13.setMatricula("");
        boolean b17 = carro13.equals((java.lang.Object) (-1.0d));
        boolean b18 = carro8.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada19 = carro8.getCoordenadas();
        carro5.setCoordenadas(coordenada19);
        int i21 = carro5.getLugares();
        Coordenada coordenada22 = carro5.getCoordenadas();
        carro5.setPrecoBase((double) 10.0f);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertTrue(b17 == false);
        org.junit.Assert.assertTrue(b18 == false);
        org.junit.Assert.assertNotNull(coordenada19);
        org.junit.Assert.assertTrue(i21 == 0);
        org.junit.Assert.assertNotNull(coordenada22);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        java.lang.String str2 = carro0.toString();
        carro0.setFiabilidade(0);
        Carro carro5 = carro0.clone();
        int i6 = carro0.getLugares();
        java.lang.Object obj7 = new java.lang.Object();
        boolean b8 = carro0.equals(obj7);
        java.lang.String str9 = carro0.toString();
        Coordenada coordenada10 = carro0.getCoordenadas();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro5);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertTrue(b8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada10);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        Carro carro9 = new Carro(carro6);
        int i10 = carro9.getLugares();
        carro9.setPrecoBase(100.0d);
        int i13 = carro9.getLugares();
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue(i13 == 0);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        java.lang.String str2 = carro0.toString();
        carro0.setFiabilidade(0);
        carro0.setOcupado(true);
        boolean b7 = carro0.getOcupado();
        carro0.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        double d10 = carro0.getPrecoBase();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(b7 == true);
        org.junit.Assert.assertTrue(d10 == 0.0d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        Carro carro4 = new Carro(carro0);
        int i5 = carro0.getVelocidadeMedia();
        carro0.setMatricula("");
        int i8 = carro0.getFiabilidade();
        double d9 = carro0.getPrecoBase();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i5 == 10);
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue(d9 == 0.0d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        java.lang.String str3 = carro0.toString();
        Carro carro4 = carro0.clone();
        carro4.setOcupado(true);
        Carro carro7 = new Carro();
        Carro carro8 = new Carro(carro7);
        java.lang.String str9 = carro7.toString();
        carro7.setFiabilidade(0);
        int i12 = carro7.getFiabilidade();
        Carro carro13 = new Carro(carro7);
        boolean b14 = carro4.equals((java.lang.Object) carro13);
        int i15 = carro4.getVelocidadeMedia();
        int i16 = carro4.getFiabilidade();
        Coordenada coordenada17 = carro4.getCoordenadas();
        Carro carro18 = carro4.clone();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertTrue(i15 == 0);
        org.junit.Assert.assertTrue(i16 == 0);
        org.junit.Assert.assertNotNull(coordenada17);
        org.junit.Assert.assertNotNull(carro18);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        java.lang.String str3 = carro0.toString();
        Carro carro4 = carro0.clone();
        carro4.setOcupado(true);
        Carro carro7 = new Carro();
        Carro carro8 = new Carro(carro7);
        java.lang.String str9 = carro7.toString();
        carro7.setFiabilidade(0);
        int i12 = carro7.getFiabilidade();
        Carro carro13 = new Carro(carro7);
        boolean b14 = carro4.equals((java.lang.Object) carro13);
        boolean b16 = carro4.equals((java.lang.Object) 10L);
        Carro carro21 = new Carro();
        carro21.setMatricula("");
        Carro carro24 = carro21.clone();
        Coordenada coordenada25 = carro24.getCoordenadas();
        Carro carro27 = new Carro((int) (byte) -1, (double) 0, (int) (short) 1, "", coordenada25, false);
        carro27.setOcupado(false);
        int i30 = carro4.compareTo((Veiculo) carro27);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str3.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertTrue(b16 == false);
        org.junit.Assert.assertNotNull(carro24);
        org.junit.Assert.assertNotNull(coordenada25);
        org.junit.Assert.assertTrue(i30 == 0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        Carro carro12 = new Carro();
        carro12.setMatricula("");
        Carro carro15 = carro12.clone();
        carro12.setPrecoBase((double) 0L);
        Carro carro18 = new Carro();
        int i19 = carro18.getLugares();
        int i20 = carro12.compareTo((Veiculo) carro18);
        java.lang.String str21 = carro18.toString();
        Coordenada coordenada22 = carro18.getCoordenadas();
        Carro carro24 = new Carro((int) (byte) 100, 1.0d, (int) (byte) 10, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada22, false);
        Carro carro26 = new Carro((-142), (double) '#', (-1), "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada22, true);
        Carro carro28 = new Carro((int) '#', 10.0d, (-1), "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada22, true);
        Coordenada coordenada29 = carro28.getCoordenadas();
        java.lang.String str30 = carro28.getMatricula();
        java.lang.String str31 = carro28.toString();
        org.junit.Assert.assertNotNull(carro15);
        org.junit.Assert.assertTrue(i19 == 0);
        org.junit.Assert.assertTrue(i20 == 3);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str21.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada22);
        org.junit.Assert.assertNotNull(coordenada29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str30.equals("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Matrícula: Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 35km/h\nPreço Base: 10.0€\nFiabilidade: -1\nLugares: 4\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n" + "'", str31.equals("Matrícula: Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n\nVelocidade Média/km: 35km/h\nPreço Base: 10.0€\nFiabilidade: -1\nLugares: 4\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        int i4 = carro3.getLugares();
        boolean b5 = carro2.equals((java.lang.Object) carro3);
        Carro carro6 = carro3.clone();
        carro6.setVelocidadeMedia((int) (short) 0);
        int i9 = carro6.getLugares();
        boolean b10 = carro6.getOcupado();
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue(b5 == true);
        org.junit.Assert.assertNotNull(carro6);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertTrue(b10 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        Carro carro4 = new Carro(carro3);
        int i5 = carro1.compareTo((Veiculo) carro3);
        Carro carro6 = new Carro();
        carro6.setMatricula("");
        boolean b10 = carro6.equals((java.lang.Object) (-1.0d));
        boolean b11 = carro1.equals((java.lang.Object) (-1.0d));
        Carro carro12 = new Carro(carro1);
        int i13 = carro1.getVelocidadeMedia();
        Carro carro14 = new Carro();
        carro14.setMatricula("");
        Carro carro17 = carro14.clone();
        carro14.setPrecoBase((double) 0L);
        Carro carro20 = new Carro();
        int i21 = carro20.getLugares();
        int i22 = carro14.compareTo((Veiculo) carro20);
        java.lang.String str23 = carro20.toString();
        int i24 = carro20.getFiabilidade();
        boolean b25 = carro1.equals((java.lang.Object) i24);
        carro1.setMatricula("hi!");
        carro1.setFiabilidade((-1));
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertNotNull(carro17);
        org.junit.Assert.assertTrue(i21 == 0);
        org.junit.Assert.assertTrue(i22 == 3);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str23.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i24 == 0);
        org.junit.Assert.assertTrue(b25 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        java.lang.String str2 = carro0.toString();
        double d3 = carro0.getPrecoBase();
        carro0.setOcupado(false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(d3 == 0.0d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        java.lang.String str2 = carro0.getMatricula();
        Carro carro3 = new Carro(carro0);
        carro0.setOcupado(true);
        java.lang.String str6 = carro0.toString();
        Carro carro7 = new Carro();
        int i8 = carro7.getLugares();
        java.lang.String str9 = carro7.getMatricula();
        Carro carro10 = new Carro(carro7);
        int i11 = carro7.getVelocidadeMedia();
        int i12 = carro0.compareTo((Veiculo) carro7);
        carro0.setPrecoBase((double) 4);
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "n/a" + "'", str2.equals("n/a"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n" + "'", str6.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: true\n"));
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "n/a" + "'", str9.equals("n/a"));
        org.junit.Assert.assertTrue(i11 == 0);
        org.junit.Assert.assertTrue(i12 == 0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carro0.getCoordenadas();
        java.lang.String str6 = carro0.toString();
        Carro carro7 = new Carro();
        carro7.setMatricula("");
        Carro carro10 = carro7.clone();
        carro7.setPrecoBase((double) 0L);
        Carro carro13 = new Carro();
        int i14 = carro13.getLugares();
        int i15 = carro7.compareTo((Veiculo) carro13);
        Carro carro16 = new Carro();
        carro16.setMatricula("");
        Carro carro19 = carro16.clone();
        carro16.setPrecoBase((double) 0L);
        Carro carro22 = new Carro();
        int i23 = carro22.getLugares();
        int i24 = carro16.compareTo((Veiculo) carro22);
        java.lang.String str25 = carro22.toString();
        Coordenada coordenada26 = carro22.getCoordenadas();
        Carro carro27 = new Carro();
        int i28 = carro27.getLugares();
        Coordenada coordenada29 = carro27.getCoordenadas();
        carro22.setCoordenadas(coordenada29);
        Carro carro31 = new Carro(carro22);
        int i32 = carro7.compareTo((Veiculo) carro22);
        int i33 = carro22.getFiabilidade();
        int i34 = carro0.compareTo((Veiculo) carro22);
        boolean b35 = carro22.getOcupado();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str6.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro10);
        org.junit.Assert.assertTrue(i14 == 0);
        org.junit.Assert.assertTrue(i15 == 3);
        org.junit.Assert.assertNotNull(carro19);
        org.junit.Assert.assertTrue(i23 == 0);
        org.junit.Assert.assertTrue(i24 == 3);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str25.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada26);
        org.junit.Assert.assertTrue(i28 == 0);
        org.junit.Assert.assertNotNull(coordenada29);
        org.junit.Assert.assertTrue(i32 == 3);
        org.junit.Assert.assertTrue(i33 == 0);
        org.junit.Assert.assertTrue(i34 == 3);
        org.junit.Assert.assertTrue(b35 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setVelocidadeMedia((int) '4');
        Coordenada coordenada6 = carro0.getCoordenadas();
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertNotNull(coordenada6);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        java.lang.String str5 = carro0.getMatricula();
        java.lang.Object obj6 = null;
        boolean b7 = carro0.equals(obj6);
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue(b7 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carro0.getCoordenadas();
        java.lang.String str6 = carro0.toString();
        double d7 = carro0.getPrecoBase();
        Carro carro12 = new Carro();
        carro12.setMatricula("");
        boolean b16 = carro12.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada17 = carro12.getCoordenadas();
        carro12.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carro12.setFiabilidade(0);
        Carro carro22 = new Carro();
        carro22.setMatricula("");
        Carro carro25 = carro22.clone();
        carro22.setPrecoBase((double) 0L);
        Carro carro28 = new Carro(carro22);
        int i29 = carro12.compareTo((Veiculo) carro22);
        Carro carro30 = new Carro(carro22);
        Coordenada coordenada31 = carro30.getCoordenadas();
        Carro carro33 = new Carro((int) (byte) 0, (double) 0L, (int) (byte) 0, "n/a", coordenada31, true);
        boolean b34 = carro0.equals((java.lang.Object) (byte) 0);
        int i35 = carro0.getFiabilidade();
        java.lang.String str36 = carro0.toString();
        java.lang.String str37 = carro0.toString();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str6.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(d7 == 0.0d);
        org.junit.Assert.assertTrue(b16 == false);
        org.junit.Assert.assertNotNull(coordenada17);
        org.junit.Assert.assertNotNull(carro25);
        org.junit.Assert.assertTrue(i29 == (-142));
        org.junit.Assert.assertNotNull(coordenada31);
        org.junit.Assert.assertTrue(b34 == false);
        org.junit.Assert.assertTrue(i35 == 0);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str36.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str37.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        Carro carro4 = new Carro(carro3);
        int i5 = carro1.compareTo((Veiculo) carro3);
        carro3.setMatricula("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        int i8 = carro3.getFiabilidade();
        carro3.setFiabilidade(0);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(i8 == 0);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        java.lang.String str2 = carro0.toString();
        carro0.setFiabilidade(0);
        int i5 = carro0.getFiabilidade();
        Carro carro6 = new Carro();
        carro6.setMatricula("");
        java.lang.String str9 = carro6.toString();
        Carro carro10 = carro6.clone();
        carro10.setOcupado(true);
        Carro carro13 = new Carro();
        Carro carro14 = new Carro(carro13);
        java.lang.String str15 = carro13.toString();
        carro13.setFiabilidade(0);
        int i18 = carro13.getFiabilidade();
        Carro carro19 = new Carro(carro13);
        boolean b20 = carro10.equals((java.lang.Object) carro19);
        carro10.setPrecoBase((double) 1);
        int i23 = carro0.compareTo((Veiculo) carro10);
        carro10.setFiabilidade((int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro10);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str15.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i18 == 0);
        org.junit.Assert.assertTrue(b20 == false);
        org.junit.Assert.assertTrue(i23 == (-3));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        Carro carro4 = new Carro(carro3);
        int i5 = carro1.compareTo((Veiculo) carro3);
        Carro carro6 = new Carro(carro3);
        Carro carro7 = carro6.clone();
        Coordenada coordenada8 = carro6.getCoordenadas();
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertNotNull(carro7);
        org.junit.Assert.assertNotNull(coordenada8);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        Carro carro4 = new Carro(carro3);
        int i5 = carro1.compareTo((Veiculo) carro3);
        int i6 = carro3.getVelocidadeMedia();
        carro3.setVelocidadeMedia((int) (short) 10);
        carro3.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(i6 == 0);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Carro carro5 = new Carro(carro0);
        double d6 = carro0.getPrecoBase();
        java.lang.String str7 = carro0.toString();
        int i8 = carro0.getVelocidadeMedia();
        double d9 = carro0.getPrecoBase();
        int i10 = carro0.getVelocidadeMedia();
        carro0.setFiabilidade((int) (byte) -1);
        java.lang.String str13 = carro0.getMatricula();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertTrue(d6 == 0.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str7.equals("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue(d9 == 0.0d);
        org.junit.Assert.assertTrue(i10 == 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro();
        Carro carro2 = new Carro(carro1);
        int i3 = carro2.getFiabilidade();
        Coordenada coordenada4 = carro2.getCoordenadas();
        carro0.setCoordenadas(coordenada4);
        java.lang.String str6 = carro0.toString();
        int i7 = carro0.getFiabilidade();
        org.junit.Assert.assertTrue(i3 == 0);
        org.junit.Assert.assertNotNull(coordenada4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str6.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i7 == 0);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        int i4 = carro3.getLugares();
        boolean b5 = carro2.equals((java.lang.Object) carro3);
        Carro carro6 = carro3.clone();
        carro6.setVelocidadeMedia((int) (short) 0);
        int i9 = carro6.getLugares();
        carro6.setMatricula("Matrícula: \nVelocidade Média/km: -1km/h\nPreço Base: 0.0€\nFiabilidade: 1\nLugares: 4\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Coordenada coordenada12 = carro6.getCoordenadas();
        org.junit.Assert.assertTrue(i4 == 0);
        org.junit.Assert.assertTrue(b5 == true);
        org.junit.Assert.assertNotNull(carro6);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertNotNull(coordenada12);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        Carro carro4 = new Carro(carro3);
        int i5 = carro1.compareTo((Veiculo) carro3);
        Carro carro6 = new Carro();
        carro6.setMatricula("");
        boolean b10 = carro6.equals((java.lang.Object) (-1.0d));
        boolean b11 = carro1.equals((java.lang.Object) (-1.0d));
        Carro carro12 = new Carro(carro1);
        int i13 = carro1.getVelocidadeMedia();
        Carro carro14 = new Carro();
        carro14.setMatricula("");
        Carro carro17 = carro14.clone();
        carro14.setPrecoBase((double) 0L);
        Carro carro20 = new Carro();
        int i21 = carro20.getLugares();
        int i22 = carro14.compareTo((Veiculo) carro20);
        java.lang.String str23 = carro20.toString();
        int i24 = carro20.getFiabilidade();
        boolean b25 = carro1.equals((java.lang.Object) i24);
        int i26 = carro1.getVelocidadeMedia();
        Carro carro27 = carro1.clone();
        carro1.setOcupado(true);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertTrue(i13 == 0);
        org.junit.Assert.assertNotNull(carro17);
        org.junit.Assert.assertTrue(i21 == 0);
        org.junit.Assert.assertTrue(i22 == 3);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str23.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i24 == 0);
        org.junit.Assert.assertTrue(b25 == false);
        org.junit.Assert.assertTrue(i26 == 0);
        org.junit.Assert.assertNotNull(carro27);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        java.lang.String str2 = carro0.toString();
        carro0.setMatricula("hi!");
        Carro carro5 = carro0.clone();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro5);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carro0.getCoordenadas();
        carro0.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        Carro carro8 = new Carro(carro0);
        Carro carro9 = carro8.clone();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertNotNull(carro9);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        carro0.setMatricula("n/a");
        Carro carro6 = new Carro(carro0);
        carro6.setFiabilidade((-3));
        int i9 = carro6.getFiabilidade();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i9 == (-3));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        boolean b4 = carro0.equals((java.lang.Object) (-1.0d));
        Coordenada coordenada5 = carro0.getCoordenadas();
        carro0.setMatricula("Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carro0.setFiabilidade(0);
        Carro carro10 = new Carro();
        carro10.setMatricula("");
        Carro carro13 = carro10.clone();
        carro10.setPrecoBase((double) 0L);
        Carro carro16 = new Carro(carro10);
        int i17 = carro0.compareTo((Veiculo) carro10);
        Carro carro18 = new Carro(carro10);
        carro18.setOcupado(false);
        java.lang.String str21 = carro18.getMatricula();
        int i22 = carro18.getLugares();
        org.junit.Assert.assertTrue(b4 == false);
        org.junit.Assert.assertNotNull(coordenada5);
        org.junit.Assert.assertNotNull(carro13);
        org.junit.Assert.assertTrue(i17 == (-142));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertTrue(i22 == 0);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        carro0.setVelocidadeMedia(10);
        Carro carro4 = new Carro(carro0);
        Carro carro5 = new Carro(carro4);
        int i6 = carro5.getFiabilidade();
        Carro carro7 = carro5.clone();
        carro7.setOcupado(false);
        Coordenada coordenada10 = carro7.getCoordenadas();
        Carro carro11 = carro7.clone();
        boolean b12 = carro11.getOcupado();
        Carro carro13 = new Carro(carro11);
        java.lang.String str14 = carro13.toString();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertTrue(i6 == 0);
        org.junit.Assert.assertNotNull(carro7);
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertNotNull(carro11);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str14.equals("Matrícula: n/a\nVelocidade Média/km: 10km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        Carro carro4 = new Carro();
        Carro carro5 = new Carro(carro4);
        Carro carro6 = new Carro(carro5);
        Carro carro7 = new Carro();
        Carro carro8 = new Carro(carro7);
        int i9 = carro5.compareTo((Veiculo) carro7);
        Carro carro10 = new Carro();
        carro10.setMatricula("");
        boolean b14 = carro10.equals((java.lang.Object) (-1.0d));
        boolean b15 = carro5.equals((java.lang.Object) (-1.0d));
        Carro carro16 = new Carro(carro5);
        int i17 = carro5.getVelocidadeMedia();
        Carro carro18 = new Carro();
        carro18.setMatricula("");
        Carro carro21 = carro18.clone();
        carro18.setPrecoBase((double) 0L);
        Carro carro24 = new Carro();
        int i25 = carro24.getLugares();
        int i26 = carro18.compareTo((Veiculo) carro24);
        java.lang.String str27 = carro24.toString();
        int i28 = carro24.getFiabilidade();
        boolean b29 = carro5.equals((java.lang.Object) i28);
        int i30 = carro5.getVelocidadeMedia();
        Carro carro31 = carro5.clone();
        Coordenada coordenada32 = carro31.getCoordenadas();
        Carro carro34 = new Carro(3, 10.0d, (int) '4', "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 100.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada32, true);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertTrue(b14 == false);
        org.junit.Assert.assertTrue(b15 == false);
        org.junit.Assert.assertTrue(i17 == 0);
        org.junit.Assert.assertNotNull(carro21);
        org.junit.Assert.assertTrue(i25 == 0);
        org.junit.Assert.assertTrue(i26 == 3);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str27.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i28 == 0);
        org.junit.Assert.assertTrue(b29 == false);
        org.junit.Assert.assertTrue(i30 == 0);
        org.junit.Assert.assertNotNull(carro31);
        org.junit.Assert.assertNotNull(coordenada32);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        Coordenada coordenada2 = carro0.getCoordenadas();
        Carro carro3 = new Carro();
        Carro carro4 = new Carro(carro3);
        java.lang.String str5 = carro3.toString();
        carro3.setFiabilidade(0);
        Carro carro8 = carro3.clone();
        int i9 = carro3.getLugares();
        Carro carro14 = new Carro();
        Carro carro15 = new Carro(carro14);
        Carro carro16 = new Carro(carro15);
        Carro carro17 = new Carro();
        Carro carro18 = new Carro(carro17);
        int i19 = carro15.compareTo((Veiculo) carro17);
        Carro carro20 = new Carro();
        carro20.setMatricula("");
        boolean b24 = carro20.equals((java.lang.Object) (-1.0d));
        boolean b25 = carro15.equals((java.lang.Object) (-1.0d));
        Carro carro26 = new Carro();
        carro26.setMatricula("");
        Carro carro29 = carro26.clone();
        carro26.setPrecoBase((double) 0L);
        Carro carro32 = new Carro();
        int i33 = carro32.getLugares();
        int i34 = carro26.compareTo((Veiculo) carro32);
        java.lang.String str35 = carro32.toString();
        Coordenada coordenada36 = carro32.getCoordenadas();
        carro15.setCoordenadas(coordenada36);
        Carro carro39 = new Carro((-1), 10.0d, (int) (byte) 1, "Matrícula: \nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n", coordenada36, true);
        carro3.setCoordenadas(coordenada36);
        int i41 = carro0.compareTo((Veiculo) carro3);
        Coordenada coordenada42 = carro3.getCoordenadas();
        Coordenada coordenada43 = carro3.getCoordenadas();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(coordenada2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str5.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(carro8);
        org.junit.Assert.assertTrue(i9 == 0);
        org.junit.Assert.assertTrue(i19 == 0);
        org.junit.Assert.assertTrue(b24 == false);
        org.junit.Assert.assertTrue(b25 == false);
        org.junit.Assert.assertNotNull(carro29);
        org.junit.Assert.assertTrue(i33 == 0);
        org.junit.Assert.assertTrue(i34 == 3);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str35.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada36);
        org.junit.Assert.assertTrue(i41 == 0);
        org.junit.Assert.assertNotNull(coordenada42);
        org.junit.Assert.assertNotNull(coordenada43);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        Carro carro0 = new Carro();
        int i1 = carro0.getLugares();
        Carro carro2 = carro0.clone();
        Carro carro3 = new Carro();
        Carro carro4 = new Carro(carro3);
        java.lang.String str5 = carro3.toString();
        carro3.setFiabilidade(0);
        int i8 = carro3.getFiabilidade();
        carro3.setFiabilidade((int) (byte) 0);
        boolean b11 = carro2.equals((java.lang.Object) carro3);
        int i12 = carro3.getLugares();
        org.junit.Assert.assertTrue(i1 == 0);
        org.junit.Assert.assertNotNull(carro2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str5.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(i8 == 0);
        org.junit.Assert.assertTrue(b11 == true);
        org.junit.Assert.assertTrue(i12 == 0);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        Carro carro0 = new Carro();
        carro0.setMatricula("");
        Carro carro3 = carro0.clone();
        carro0.setPrecoBase((double) 0L);
        Carro carro6 = new Carro();
        int i7 = carro6.getLugares();
        int i8 = carro0.compareTo((Veiculo) carro6);
        java.lang.String str9 = carro6.toString();
        Coordenada coordenada10 = carro6.getCoordenadas();
        java.lang.String str11 = carro6.toString();
        carro6.setVelocidadeMedia((int) (short) 0);
        org.junit.Assert.assertNotNull(carro3);
        org.junit.Assert.assertTrue(i7 == 0);
        org.junit.Assert.assertTrue(i8 == 3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str9.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str11.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        java.lang.String str2 = carro0.toString();
        carro0.setFiabilidade(0);
        carro0.setOcupado(true);
        boolean b7 = carro0.getOcupado();
        carro0.setMatricula("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        carro0.setMatricula("Matrícula: n/a\nVelocidade Média/km: 32km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n");
        int i12 = carro0.getVelocidadeMedia();
        Coordenada coordenada13 = carro0.getCoordenadas();
        Coordenada coordenada14 = carro0.getCoordenadas();
        int i15 = carro0.getLugares();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str2.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertTrue(b7 == true);
        org.junit.Assert.assertTrue(i12 == 0);
        org.junit.Assert.assertNotNull(coordenada13);
        org.junit.Assert.assertNotNull(coordenada14);
        org.junit.Assert.assertTrue(i15 == 0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        double d2 = carro1.getPrecoBase();
        int i3 = carro1.getFiabilidade();
        org.junit.Assert.assertTrue(d2 == 0.0d);
        org.junit.Assert.assertTrue(i3 == 0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        Carro carro0 = new Carro();
        Carro carro1 = new Carro(carro0);
        Carro carro2 = new Carro(carro1);
        Carro carro3 = new Carro();
        Carro carro4 = new Carro(carro3);
        int i5 = carro1.compareTo((Veiculo) carro3);
        Carro carro6 = new Carro();
        carro6.setMatricula("");
        boolean b10 = carro6.equals((java.lang.Object) (-1.0d));
        boolean b11 = carro1.equals((java.lang.Object) (-1.0d));
        Carro carro12 = new Carro();
        carro12.setMatricula("");
        Carro carro15 = carro12.clone();
        carro12.setPrecoBase((double) 0L);
        Carro carro18 = new Carro();
        int i19 = carro18.getLugares();
        int i20 = carro12.compareTo((Veiculo) carro18);
        java.lang.String str21 = carro18.toString();
        Coordenada coordenada22 = carro18.getCoordenadas();
        carro1.setCoordenadas(coordenada22);
        carro1.setVelocidadeMedia((-145));
        Coordenada coordenada26 = carro1.getCoordenadas();
        carro1.setFiabilidade(0);
        org.junit.Assert.assertTrue(i5 == 0);
        org.junit.Assert.assertTrue(b10 == false);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertNotNull(carro15);
        org.junit.Assert.assertTrue(i19 == 0);
        org.junit.Assert.assertTrue(i20 == 3);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n" + "'", str21.equals("Matrícula: n/a\nVelocidade Média/km: 0km/h\nPreço Base: 0.0€\nFiabilidade: 0\nLugares: 0\nCoordenadas: Coordenada X: 0 Coordenada Y: 0\nOcupado: false\n"));
        org.junit.Assert.assertNotNull(coordenada22);
        org.junit.Assert.assertNotNull(coordenada26);
    }
}

